module {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %c0_i64 = arith.constant 0 : i64
    %cst = arith.constant 0.44890627722143339 : f64
    %cst_0 = arith.constant 2.2423492602035404 : f64
    %cst_1 = arith.constant -2.5181403996968745 : f64
    %cst_2 = arith.constant 1.0536552218902981 : f64
    %cst_3 = arith.constant 1.3619104989145452 : f64
    %cst_4 = arith.constant 1.4860340580195173 : f64
    %cst_5 = arith.constant -0.22904961114317635 : f64
    %cst_6 = arith.constant -0.48784943517400325 : f64
    %cst_7 = arith.constant -2.9408888113992759 : f64
    %cst_8 = arith.constant -0.67105356997791521 : f64
    %cst_9 = arith.constant 0.75467808616402498 : f64
    %cst_10 = arith.constant 2.000000e-01 : f64
    %cst_11 = arith.constant 3.000000e-01 : f64
    %cst_12 = arith.constant 2.1524411139170914 : f64
    %cst_13 = arith.constant 0.000000e+00 : f64
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c4 = arith.constant 4 : index
    %0 = qtensor.alloc(%c4) {mqt.register_name = "q"} : tensor<4x!qco.qubit>
    qco.gphase(%cst_13)
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<4x!qco.qubit>
    %1 = qco.rz(%cst_12) %result : !qco.qubit -> !qco.qubit
    %2 = qtensor.insert %1 into %out_tensor[%c0] : tensor<4x!qco.qubit>
    %out_tensor_14, %result_15 = qtensor.extract %2[%c0] : tensor<4x!qco.qubit>
    %3 = qco.r(%cst_11, %cst_10) %result_15 : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor_14[%c0] : tensor<4x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %4[%c0] : tensor<4x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %out_tensor_16[%c1] : tensor<4x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_17) targets (%arg0 = %result_19) {
      %73 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %5 = qtensor.insert %targets_out into %out_tensor_18[%c1] : tensor<4x!qco.qubit>
    %6 = qtensor.insert %controls_out into %5[%c0] : tensor<4x!qco.qubit>
    %out_tensor_20, %result_21 = qtensor.extract %6[%c1] : tensor<4x!qco.qubit>
    %7 = qco.rz(%cst_9) %result_21 : !qco.qubit -> !qco.qubit
    %8 = qtensor.insert %7 into %out_tensor_20[%c1] : tensor<4x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %8[%c1] : tensor<4x!qco.qubit>
    %9 = qco.r(%cst_11, %cst_10) %result_23 : !qco.qubit -> !qco.qubit
    %10 = qtensor.insert %9 into %out_tensor_22[%c1] : tensor<4x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %10[%c1] : tensor<4x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %out_tensor_24[%c2] : tensor<4x!qco.qubit>
    %controls_out_28, %targets_out_29 = qco.ctrl(%result_25) targets (%arg0 = %result_27) {
      %73 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qtensor.insert %targets_out_29 into %out_tensor_26[%c2] : tensor<4x!qco.qubit>
    %12 = qtensor.insert %controls_out_28 into %11[%c1] : tensor<4x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %12[%c2] : tensor<4x!qco.qubit>
    %13 = qco.rz(%cst_8) %result_31 : !qco.qubit -> !qco.qubit
    %14 = qtensor.insert %13 into %out_tensor_30[%c2] : tensor<4x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %14[%c2] : tensor<4x!qco.qubit>
    %15 = qco.r(%cst_11, %cst_10) %result_33 : !qco.qubit -> !qco.qubit
    %16 = qtensor.insert %15 into %out_tensor_32[%c2] : tensor<4x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %16[%c2] : tensor<4x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %out_tensor_34[%c3] : tensor<4x!qco.qubit>
    %controls_out_38, %targets_out_39 = qco.ctrl(%result_35) targets (%arg0 = %result_37) {
      %73 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qtensor.insert %targets_out_39 into %out_tensor_36[%c3] : tensor<4x!qco.qubit>
    %18 = qtensor.insert %controls_out_38 into %17[%c2] : tensor<4x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %18[%c3] : tensor<4x!qco.qubit>
    %19 = qco.rz(%cst_7) %result_41 : !qco.qubit -> !qco.qubit
    %20 = qtensor.insert %19 into %out_tensor_40[%c3] : tensor<4x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %20[%c3] : tensor<4x!qco.qubit>
    %21 = qco.r(%cst_11, %cst_10) %result_43 : !qco.qubit -> !qco.qubit
    %22 = qtensor.insert %21 into %out_tensor_42[%c3] : tensor<4x!qco.qubit>
    %out_tensor_44, %result_45 = qtensor.extract %22[%c3] : tensor<4x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %out_tensor_44[%c0] : tensor<4x!qco.qubit>
    %controls_out_48, %targets_out_49 = qco.ctrl(%result_45) targets (%arg0 = %result_47) {
      %73 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qtensor.insert %targets_out_49 into %out_tensor_46[%c0] : tensor<4x!qco.qubit>
    %24 = qtensor.insert %controls_out_48 into %23[%c3] : tensor<4x!qco.qubit>
    %out_tensor_50, %result_51 = qtensor.extract %24[%c0] : tensor<4x!qco.qubit>
    %25 = qco.rz(%cst_6) %result_51 : !qco.qubit -> !qco.qubit
    %26 = qtensor.insert %25 into %out_tensor_50[%c0] : tensor<4x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %26[%c0] : tensor<4x!qco.qubit>
    %27 = qco.r(%cst_11, %cst_10) %result_53 : !qco.qubit -> !qco.qubit
    %28 = qtensor.insert %27 into %out_tensor_52[%c0] : tensor<4x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %28[%c0] : tensor<4x!qco.qubit>
    %out_tensor_56, %result_57 = qtensor.extract %out_tensor_54[%c1] : tensor<4x!qco.qubit>
    %controls_out_58, %targets_out_59 = qco.ctrl(%result_55) targets (%arg0 = %result_57) {
      %73 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qtensor.insert %targets_out_59 into %out_tensor_56[%c1] : tensor<4x!qco.qubit>
    %30 = qtensor.insert %controls_out_58 into %29[%c0] : tensor<4x!qco.qubit>
    %out_tensor_60, %result_61 = qtensor.extract %30[%c1] : tensor<4x!qco.qubit>
    %31 = qco.rz(%cst_5) %result_61 : !qco.qubit -> !qco.qubit
    %32 = qtensor.insert %31 into %out_tensor_60[%c1] : tensor<4x!qco.qubit>
    %out_tensor_62, %result_63 = qtensor.extract %32[%c1] : tensor<4x!qco.qubit>
    %33 = qco.r(%cst_11, %cst_10) %result_63 : !qco.qubit -> !qco.qubit
    %34 = qtensor.insert %33 into %out_tensor_62[%c1] : tensor<4x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %34[%c1] : tensor<4x!qco.qubit>
    %out_tensor_66, %result_67 = qtensor.extract %out_tensor_64[%c2] : tensor<4x!qco.qubit>
    %controls_out_68, %targets_out_69 = qco.ctrl(%result_65) targets (%arg0 = %result_67) {
      %73 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qtensor.insert %targets_out_69 into %out_tensor_66[%c2] : tensor<4x!qco.qubit>
    %36 = qtensor.insert %controls_out_68 into %35[%c1] : tensor<4x!qco.qubit>
    %out_tensor_70, %result_71 = qtensor.extract %36[%c2] : tensor<4x!qco.qubit>
    %37 = qco.rz(%cst_4) %result_71 : !qco.qubit -> !qco.qubit
    %38 = qtensor.insert %37 into %out_tensor_70[%c2] : tensor<4x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %38[%c2] : tensor<4x!qco.qubit>
    %39 = qco.r(%cst_11, %cst_10) %result_73 : !qco.qubit -> !qco.qubit
    %40 = qtensor.insert %39 into %out_tensor_72[%c2] : tensor<4x!qco.qubit>
    %out_tensor_74, %result_75 = qtensor.extract %40[%c2] : tensor<4x!qco.qubit>
    %out_tensor_76, %result_77 = qtensor.extract %out_tensor_74[%c3] : tensor<4x!qco.qubit>
    %controls_out_78, %targets_out_79 = qco.ctrl(%result_75) targets (%arg0 = %result_77) {
      %73 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qtensor.insert %targets_out_79 into %out_tensor_76[%c3] : tensor<4x!qco.qubit>
    %42 = qtensor.insert %controls_out_78 into %41[%c2] : tensor<4x!qco.qubit>
    %out_tensor_80, %result_81 = qtensor.extract %42[%c3] : tensor<4x!qco.qubit>
    %43 = qco.rz(%cst_3) %result_81 : !qco.qubit -> !qco.qubit
    %44 = qtensor.insert %43 into %out_tensor_80[%c3] : tensor<4x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %44[%c3] : tensor<4x!qco.qubit>
    %45 = qco.r(%cst_11, %cst_10) %result_83 : !qco.qubit -> !qco.qubit
    %46 = qtensor.insert %45 into %out_tensor_82[%c3] : tensor<4x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %46[%c3] : tensor<4x!qco.qubit>
    %out_tensor_86, %result_87 = qtensor.extract %out_tensor_84[%c0] : tensor<4x!qco.qubit>
    %controls_out_88, %targets_out_89 = qco.ctrl(%result_85) targets (%arg0 = %result_87) {
      %73 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qtensor.insert %targets_out_89 into %out_tensor_86[%c0] : tensor<4x!qco.qubit>
    %48 = qtensor.insert %controls_out_88 into %47[%c3] : tensor<4x!qco.qubit>
    %out_tensor_90, %result_91 = qtensor.extract %48[%c0] : tensor<4x!qco.qubit>
    %49 = qco.rz(%cst_2) %result_91 : !qco.qubit -> !qco.qubit
    %50 = qtensor.insert %49 into %out_tensor_90[%c0] : tensor<4x!qco.qubit>
    %out_tensor_92, %result_93 = qtensor.extract %50[%c0] : tensor<4x!qco.qubit>
    %51 = qco.r(%cst_11, %cst_10) %result_93 : !qco.qubit -> !qco.qubit
    %52 = qtensor.insert %51 into %out_tensor_92[%c0] : tensor<4x!qco.qubit>
    %out_tensor_94, %result_95 = qtensor.extract %52[%c0] : tensor<4x!qco.qubit>
    %out_tensor_96, %result_97 = qtensor.extract %out_tensor_94[%c1] : tensor<4x!qco.qubit>
    %controls_out_98, %targets_out_99 = qco.ctrl(%result_95) targets (%arg0 = %result_97) {
      %73 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qtensor.insert %targets_out_99 into %out_tensor_96[%c1] : tensor<4x!qco.qubit>
    %54 = qtensor.insert %controls_out_98 into %53[%c0] : tensor<4x!qco.qubit>
    %out_tensor_100, %result_101 = qtensor.extract %54[%c1] : tensor<4x!qco.qubit>
    %55 = qco.rz(%cst_1) %result_101 : !qco.qubit -> !qco.qubit
    %56 = qtensor.insert %55 into %out_tensor_100[%c1] : tensor<4x!qco.qubit>
    %out_tensor_102, %result_103 = qtensor.extract %56[%c1] : tensor<4x!qco.qubit>
    %57 = qco.r(%cst_11, %cst_10) %result_103 : !qco.qubit -> !qco.qubit
    %58 = qtensor.insert %57 into %out_tensor_102[%c1] : tensor<4x!qco.qubit>
    %out_tensor_104, %result_105 = qtensor.extract %58[%c1] : tensor<4x!qco.qubit>
    %out_tensor_106, %result_107 = qtensor.extract %out_tensor_104[%c2] : tensor<4x!qco.qubit>
    %controls_out_108, %targets_out_109 = qco.ctrl(%result_105) targets (%arg0 = %result_107) {
      %73 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qtensor.insert %targets_out_109 into %out_tensor_106[%c2] : tensor<4x!qco.qubit>
    %60 = qtensor.insert %controls_out_108 into %59[%c1] : tensor<4x!qco.qubit>
    %out_tensor_110, %result_111 = qtensor.extract %60[%c2] : tensor<4x!qco.qubit>
    %61 = qco.rz(%cst_0) %result_111 : !qco.qubit -> !qco.qubit
    %62 = qtensor.insert %61 into %out_tensor_110[%c2] : tensor<4x!qco.qubit>
    %out_tensor_112, %result_113 = qtensor.extract %62[%c2] : tensor<4x!qco.qubit>
    %63 = qco.r(%cst_11, %cst_10) %result_113 : !qco.qubit -> !qco.qubit
    %64 = qtensor.insert %63 into %out_tensor_112[%c2] : tensor<4x!qco.qubit>
    %out_tensor_114, %result_115 = qtensor.extract %64[%c2] : tensor<4x!qco.qubit>
    %out_tensor_116, %result_117 = qtensor.extract %out_tensor_114[%c3] : tensor<4x!qco.qubit>
    %controls_out_118, %targets_out_119 = qco.ctrl(%result_115) targets (%arg0 = %result_117) {
      %73 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qtensor.insert %targets_out_119 into %out_tensor_116[%c3] : tensor<4x!qco.qubit>
    %66 = qtensor.insert %controls_out_118 into %65[%c2] : tensor<4x!qco.qubit>
    %out_tensor_120, %result_121 = qtensor.extract %66[%c3] : tensor<4x!qco.qubit>
    %67 = qco.rz(%cst) %result_121 : !qco.qubit -> !qco.qubit
    %68 = qtensor.insert %67 into %out_tensor_120[%c3] : tensor<4x!qco.qubit>
    %out_tensor_122, %result_123 = qtensor.extract %68[%c3] : tensor<4x!qco.qubit>
    %69 = qco.r(%cst_11, %cst_10) %result_123 : !qco.qubit -> !qco.qubit
    %70 = qtensor.insert %69 into %out_tensor_122[%c3] : tensor<4x!qco.qubit>
    %out_tensor_124, %result_125 = qtensor.extract %70[%c3] : tensor<4x!qco.qubit>
    %out_tensor_126, %result_127 = qtensor.extract %out_tensor_124[%c0] : tensor<4x!qco.qubit>
    %controls_out_128, %targets_out_129 = qco.ctrl(%result_125) targets (%arg0 = %result_127) {
      %73 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qtensor.insert %targets_out_129 into %out_tensor_126[%c0] : tensor<4x!qco.qubit>
    %72 = qtensor.insert %controls_out_128 into %71[%c3] : tensor<4x!qco.qubit>
    qtensor.dealloc %72 : tensor<4x!qco.qubit>
    return %c0_i64 : i64
  }
}
