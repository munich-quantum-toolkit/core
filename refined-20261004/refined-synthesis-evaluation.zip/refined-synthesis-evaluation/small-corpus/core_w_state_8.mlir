module {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %c7 = arith.constant 7 : index
    %cst = arith.constant 1.5707963267948968 : f64
    %c6 = arith.constant 6 : index
    %cst_0 = arith.constant 1.9106332362490184 : f64
    %c5 = arith.constant 5 : index
    %cst_1 = arith.constant 2.0943951023931957 : f64
    %c4 = arith.constant 4 : index
    %cst_2 = arith.constant 2.2142974355881808 : f64
    %c3 = arith.constant 3 : index
    %cst_3 = arith.constant 2.3005239830218627 : f64
    %c2 = arith.constant 2 : index
    %cst_4 = arith.constant 2.366399280279432 : f64
    %cst_5 = arith.constant 2.4188584057763776 : f64
    %c1 = arith.constant 1 : index
    %c8 = arith.constant 8 : index
    %c0 = arith.constant 0 : index
    %0 = qtensor.alloc(%c8) {mqt.register_name = "q"} : tensor<8x!qco.qubit>
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<8x!qco.qubit>
    %2 = qco.x %result : !qco.qubit -> !qco.qubit
    %3 = qtensor.insert %2 into %out_tensor[%c0] : tensor<8x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %3[%c0] : tensor<8x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %out_tensor_6[%c1] : tensor<8x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_7) targets (%arg0 = %result_9) {
      %40 = qco.ry(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %4 = qtensor.insert %targets_out into %out_tensor_8[%c1] : tensor<8x!qco.qubit>
    %5 = qtensor.insert %controls_out into %4[%c0] : tensor<8x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %5[%c1] : tensor<8x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %out_tensor_10[%c0] : tensor<8x!qco.qubit>
    %controls_out_14, %targets_out_15 = qco.ctrl(%result_11) targets (%arg0 = %result_13) {
      %40 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %6 = qtensor.insert %targets_out_15 into %out_tensor_12[%c0] : tensor<8x!qco.qubit>
    %7 = qtensor.insert %controls_out_14 into %6[%c1] : tensor<8x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %7[%c1] : tensor<8x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %out_tensor_16[%c2] : tensor<8x!qco.qubit>
    %controls_out_20, %targets_out_21 = qco.ctrl(%result_17) targets (%arg0 = %result_19) {
      %40 = qco.ry(%cst_4) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %8 = qtensor.insert %targets_out_21 into %out_tensor_18[%c2] : tensor<8x!qco.qubit>
    %9 = qtensor.insert %controls_out_20 into %8[%c1] : tensor<8x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %9[%c2] : tensor<8x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %out_tensor_22[%c1] : tensor<8x!qco.qubit>
    %controls_out_26, %targets_out_27 = qco.ctrl(%result_23) targets (%arg0 = %result_25) {
      %40 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %10 = qtensor.insert %targets_out_27 into %out_tensor_24[%c1] : tensor<8x!qco.qubit>
    %11 = qtensor.insert %controls_out_26 into %10[%c2] : tensor<8x!qco.qubit>
    %out_tensor_28, %result_29 = qtensor.extract %11[%c2] : tensor<8x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %out_tensor_28[%c3] : tensor<8x!qco.qubit>
    %controls_out_32, %targets_out_33 = qco.ctrl(%result_29) targets (%arg0 = %result_31) {
      %40 = qco.ry(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qtensor.insert %targets_out_33 into %out_tensor_30[%c3] : tensor<8x!qco.qubit>
    %13 = qtensor.insert %controls_out_32 into %12[%c2] : tensor<8x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %13[%c3] : tensor<8x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %out_tensor_34[%c2] : tensor<8x!qco.qubit>
    %controls_out_38, %targets_out_39 = qco.ctrl(%result_35) targets (%arg0 = %result_37) {
      %40 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qtensor.insert %targets_out_39 into %out_tensor_36[%c2] : tensor<8x!qco.qubit>
    %15 = qtensor.insert %controls_out_38 into %14[%c3] : tensor<8x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %15[%c3] : tensor<8x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %out_tensor_40[%c4] : tensor<8x!qco.qubit>
    %controls_out_44, %targets_out_45 = qco.ctrl(%result_41) targets (%arg0 = %result_43) {
      %40 = qco.ry(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qtensor.insert %targets_out_45 into %out_tensor_42[%c4] : tensor<8x!qco.qubit>
    %17 = qtensor.insert %controls_out_44 into %16[%c3] : tensor<8x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %17[%c4] : tensor<8x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %out_tensor_46[%c3] : tensor<8x!qco.qubit>
    %controls_out_50, %targets_out_51 = qco.ctrl(%result_47) targets (%arg0 = %result_49) {
      %40 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qtensor.insert %targets_out_51 into %out_tensor_48[%c3] : tensor<8x!qco.qubit>
    %19 = qtensor.insert %controls_out_50 into %18[%c4] : tensor<8x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %19[%c4] : tensor<8x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %out_tensor_52[%c5] : tensor<8x!qco.qubit>
    %controls_out_56, %targets_out_57 = qco.ctrl(%result_53) targets (%arg0 = %result_55) {
      %40 = qco.ry(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qtensor.insert %targets_out_57 into %out_tensor_54[%c5] : tensor<8x!qco.qubit>
    %21 = qtensor.insert %controls_out_56 into %20[%c4] : tensor<8x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %21[%c5] : tensor<8x!qco.qubit>
    %out_tensor_60, %result_61 = qtensor.extract %out_tensor_58[%c4] : tensor<8x!qco.qubit>
    %controls_out_62, %targets_out_63 = qco.ctrl(%result_59) targets (%arg0 = %result_61) {
      %40 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qtensor.insert %targets_out_63 into %out_tensor_60[%c4] : tensor<8x!qco.qubit>
    %23 = qtensor.insert %controls_out_62 into %22[%c5] : tensor<8x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %23[%c5] : tensor<8x!qco.qubit>
    %out_tensor_66, %result_67 = qtensor.extract %out_tensor_64[%c6] : tensor<8x!qco.qubit>
    %controls_out_68, %targets_out_69 = qco.ctrl(%result_65) targets (%arg0 = %result_67) {
      %40 = qco.ry(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qtensor.insert %targets_out_69 into %out_tensor_66[%c6] : tensor<8x!qco.qubit>
    %25 = qtensor.insert %controls_out_68 into %24[%c5] : tensor<8x!qco.qubit>
    %out_tensor_70, %result_71 = qtensor.extract %25[%c6] : tensor<8x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %out_tensor_70[%c5] : tensor<8x!qco.qubit>
    %controls_out_74, %targets_out_75 = qco.ctrl(%result_71) targets (%arg0 = %result_73) {
      %40 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qtensor.insert %targets_out_75 into %out_tensor_72[%c5] : tensor<8x!qco.qubit>
    %27 = qtensor.insert %controls_out_74 into %26[%c6] : tensor<8x!qco.qubit>
    %out_tensor_76, %result_77 = qtensor.extract %27[%c6] : tensor<8x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %out_tensor_76[%c7] : tensor<8x!qco.qubit>
    %controls_out_80, %targets_out_81 = qco.ctrl(%result_77) targets (%arg0 = %result_79) {
      %40 = qco.ry(%cst) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qtensor.insert %targets_out_81 into %out_tensor_78[%c7] : tensor<8x!qco.qubit>
    %29 = qtensor.insert %controls_out_80 into %28[%c6] : tensor<8x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %29[%c7] : tensor<8x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %out_tensor_82[%c6] : tensor<8x!qco.qubit>
    %controls_out_86, %targets_out_87 = qco.ctrl(%result_83) targets (%arg0 = %result_85) {
      %40 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qtensor.insert %targets_out_87 into %out_tensor_84[%c6] : tensor<8x!qco.qubit>
    %31 = qtensor.insert %controls_out_86 into %30[%c7] : tensor<8x!qco.qubit>
    %out_tensor_88, %result_89 = qtensor.extract %31[%c0] : tensor<8x!qco.qubit>
    %qubit_out, %result_90 = qco.measure %result_89 : !qco.qubit
    %32 = qtensor.insert %qubit_out into %out_tensor_88[%c0] : tensor<8x!qco.qubit>
    cbit.store %result_90, %1[%c0] : !cbit.reg<8>
    %out_tensor_91, %result_92 = qtensor.extract %32[%c1] : tensor<8x!qco.qubit>
    %qubit_out_93, %result_94 = qco.measure %result_92 : !qco.qubit
    %33 = qtensor.insert %qubit_out_93 into %out_tensor_91[%c1] : tensor<8x!qco.qubit>
    cbit.store %result_94, %1[%c1] : !cbit.reg<8>
    %out_tensor_95, %result_96 = qtensor.extract %33[%c2] : tensor<8x!qco.qubit>
    %qubit_out_97, %result_98 = qco.measure %result_96 : !qco.qubit
    %34 = qtensor.insert %qubit_out_97 into %out_tensor_95[%c2] : tensor<8x!qco.qubit>
    cbit.store %result_98, %1[%c2] : !cbit.reg<8>
    %out_tensor_99, %result_100 = qtensor.extract %34[%c3] : tensor<8x!qco.qubit>
    %qubit_out_101, %result_102 = qco.measure %result_100 : !qco.qubit
    %35 = qtensor.insert %qubit_out_101 into %out_tensor_99[%c3] : tensor<8x!qco.qubit>
    cbit.store %result_102, %1[%c3] : !cbit.reg<8>
    %out_tensor_103, %result_104 = qtensor.extract %35[%c4] : tensor<8x!qco.qubit>
    %qubit_out_105, %result_106 = qco.measure %result_104 : !qco.qubit
    %36 = qtensor.insert %qubit_out_105 into %out_tensor_103[%c4] : tensor<8x!qco.qubit>
    cbit.store %result_106, %1[%c4] : !cbit.reg<8>
    %out_tensor_107, %result_108 = qtensor.extract %36[%c5] : tensor<8x!qco.qubit>
    %qubit_out_109, %result_110 = qco.measure %result_108 : !qco.qubit
    %37 = qtensor.insert %qubit_out_109 into %out_tensor_107[%c5] : tensor<8x!qco.qubit>
    cbit.store %result_110, %1[%c5] : !cbit.reg<8>
    %out_tensor_111, %result_112 = qtensor.extract %37[%c6] : tensor<8x!qco.qubit>
    %qubit_out_113, %result_114 = qco.measure %result_112 : !qco.qubit
    %38 = qtensor.insert %qubit_out_113 into %out_tensor_111[%c6] : tensor<8x!qco.qubit>
    cbit.store %result_114, %1[%c6] : !cbit.reg<8>
    %out_tensor_115, %result_116 = qtensor.extract %38[%c7] : tensor<8x!qco.qubit>
    %qubit_out_117, %result_118 = qco.measure %result_116 : !qco.qubit
    %39 = qtensor.insert %qubit_out_117 into %out_tensor_115[%c7] : tensor<8x!qco.qubit>
    cbit.store %result_118, %1[%c7] : !cbit.reg<8>
    qtensor.dealloc %39 : tensor<8x!qco.qubit>
    return %1 : !cbit.reg<8>
  }
}
