module {
  func.func @main() -> !cbit.reg<5> attributes {mqt.entry_point} {
    %cst = arith.constant 0.19634954084936207 : f64
    %cst_0 = arith.constant 0.39269908169872414 : f64
    %cst_1 = arith.constant 0.78539816339744828 : f64
    %c2 = arith.constant 2 : index
    %cst_2 = arith.constant 1.5707963267948966 : f64
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %0 = qtensor.alloc(%c4) {mqt.register_name = "controls"} : tensor<4x!qco.qubit>
    %1 = qco.alloc : !qco.qubit
    %2 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<5>
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<4x!qco.qubit>
    %3 = qco.h %result : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor[%c0] : tensor<4x!qco.qubit>
    %out_tensor_3, %result_4 = qtensor.extract %4[%c1] : tensor<4x!qco.qubit>
    %5 = qco.h %result_4 : !qco.qubit -> !qco.qubit
    %6 = qtensor.insert %5 into %out_tensor_3[%c1] : tensor<4x!qco.qubit>
    %out_tensor_5, %result_6 = qtensor.extract %6[%c2] : tensor<4x!qco.qubit>
    %7 = qco.h %result_6 : !qco.qubit -> !qco.qubit
    %8 = qtensor.insert %7 into %out_tensor_5[%c2] : tensor<4x!qco.qubit>
    %out_tensor_7, %result_8 = qtensor.extract %8[%c3] : tensor<4x!qco.qubit>
    %9 = qco.h %result_8 : !qco.qubit -> !qco.qubit
    %10 = qtensor.insert %9 into %out_tensor_7[%c3] : tensor<4x!qco.qubit>
    %out_tensor_9, %result_10 = qtensor.extract %10[%c3] : tensor<4x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_10) targets (%arg0 = %1) {
      %19 = qco.ry(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %19 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qtensor.insert %controls_out into %out_tensor_9[%c3] : tensor<4x!qco.qubit>
    %out_tensor_11, %result_12 = qtensor.extract %11[%c2] : tensor<4x!qco.qubit>
    %controls_out_13, %targets_out_14 = qco.ctrl(%result_12) targets (%arg0 = %targets_out) {
      %19 = qco.ry(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %19 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qtensor.insert %controls_out_13 into %out_tensor_11[%c2] : tensor<4x!qco.qubit>
    %out_tensor_15, %result_16 = qtensor.extract %12[%c1] : tensor<4x!qco.qubit>
    %controls_out_17, %targets_out_18 = qco.ctrl(%result_16) targets (%arg0 = %targets_out_14) {
      %19 = qco.ry(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %19 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %13 = qtensor.insert %controls_out_17 into %out_tensor_15[%c1] : tensor<4x!qco.qubit>
    %out_tensor_19, %result_20 = qtensor.extract %13[%c0] : tensor<4x!qco.qubit>
    %controls_out_21, %targets_out_22 = qco.ctrl(%result_20) targets (%arg0 = %targets_out_18) {
      %19 = qco.ry(%cst) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %19 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qtensor.insert %controls_out_21 into %out_tensor_19[%c0] : tensor<4x!qco.qubit>
    %qubit_out, %result_23 = qco.measure %targets_out_22 : !qco.qubit
    cbit.store %result_23, %2[%c0] : !cbit.reg<5>
    %out_tensor_24, %result_25 = qtensor.extract %14[%c0] : tensor<4x!qco.qubit>
    %qubit_out_26, %result_27 = qco.measure %result_25 : !qco.qubit
    %15 = qtensor.insert %qubit_out_26 into %out_tensor_24[%c0] : tensor<4x!qco.qubit>
    cbit.store %result_27, %2[%c1] : !cbit.reg<5>
    %out_tensor_28, %result_29 = qtensor.extract %15[%c1] : tensor<4x!qco.qubit>
    %qubit_out_30, %result_31 = qco.measure %result_29 : !qco.qubit
    %16 = qtensor.insert %qubit_out_30 into %out_tensor_28[%c1] : tensor<4x!qco.qubit>
    cbit.store %result_31, %2[%c2] : !cbit.reg<5>
    %out_tensor_32, %result_33 = qtensor.extract %16[%c2] : tensor<4x!qco.qubit>
    %qubit_out_34, %result_35 = qco.measure %result_33 : !qco.qubit
    %17 = qtensor.insert %qubit_out_34 into %out_tensor_32[%c2] : tensor<4x!qco.qubit>
    cbit.store %result_35, %2[%c3] : !cbit.reg<5>
    %out_tensor_36, %result_37 = qtensor.extract %17[%c3] : tensor<4x!qco.qubit>
    %qubit_out_38, %result_39 = qco.measure %result_37 : !qco.qubit
    %18 = qtensor.insert %qubit_out_38 into %out_tensor_36[%c3] : tensor<4x!qco.qubit>
    cbit.store %result_39, %2[%c4] : !cbit.reg<5>
    qco.sink %qubit_out : !qco.qubit
    qtensor.dealloc %18 : tensor<4x!qco.qubit>
    return %2 : !cbit.reg<5>
  }
}
