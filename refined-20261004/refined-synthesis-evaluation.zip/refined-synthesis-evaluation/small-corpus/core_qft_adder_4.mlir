module {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %c3 = arith.constant 3 : index
    %cst = arith.constant -1.5707963267948966 : f64
    %cst_0 = arith.constant 3.1415926535897931 : f64
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %0 = qtensor.alloc(%c2) {mqt.register_name = "addend"} : tensor<2x!qco.qubit>
    %out_tensor, %result = qtensor.extract %0[%c1] : tensor<2x!qco.qubit>
    %1 = qco.x %result : !qco.qubit -> !qco.qubit
    %2 = qtensor.insert %1 into %out_tensor[%c1] : tensor<2x!qco.qubit>
    %3 = qtensor.alloc(%c2) {mqt.register_name = "sum"} : tensor<2x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %3[%c0] : tensor<2x!qco.qubit>
    %4 = qco.x %result_3 : !qco.qubit -> !qco.qubit
    %5 = qtensor.insert %4 into %out_tensor_2[%c0] : tensor<2x!qco.qubit>
    %6 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %out_tensor_4, %result_5 = qtensor.extract %5[%c1] : tensor<2x!qco.qubit>
    %7 = qco.h %result_5 : !qco.qubit -> !qco.qubit
    %8 = qtensor.insert %7 into %out_tensor_4[%c1] : tensor<2x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %8[%c0] : tensor<2x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %out_tensor_6[%c1] : tensor<2x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_7) targets (%arg0 = %result_9) {
      %29 = qco.p(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %29 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %9 = qtensor.insert %targets_out into %out_tensor_8[%c1] : tensor<2x!qco.qubit>
    %10 = qtensor.insert %controls_out into %9[%c0] : tensor<2x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %10[%c0] : tensor<2x!qco.qubit>
    %11 = qco.h %result_11 : !qco.qubit -> !qco.qubit
    %12 = qtensor.insert %11 into %out_tensor_10[%c0] : tensor<2x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %2[%c1] : tensor<2x!qco.qubit>
    %out_tensor_14, %result_15 = qtensor.extract %12[%c1] : tensor<2x!qco.qubit>
    %controls_out_16, %targets_out_17 = qco.ctrl(%result_13) targets (%arg0 = %result_15) {
      %29 = qco.p(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %29 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %13 = qtensor.insert %targets_out_17 into %out_tensor_14[%c1] : tensor<2x!qco.qubit>
    %14 = qtensor.insert %controls_out_16 into %out_tensor_12[%c1] : tensor<2x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %14[%c0] : tensor<2x!qco.qubit>
    %out_tensor_20, %result_21 = qtensor.extract %13[%c1] : tensor<2x!qco.qubit>
    %controls_out_22, %targets_out_23 = qco.ctrl(%result_19) targets (%arg0 = %result_21) {
      %29 = qco.p(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %29 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qtensor.insert %targets_out_23 into %out_tensor_20[%c1] : tensor<2x!qco.qubit>
    %16 = qtensor.insert %controls_out_22 into %out_tensor_18[%c0] : tensor<2x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %16[%c0] : tensor<2x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %15[%c0] : tensor<2x!qco.qubit>
    %controls_out_28, %targets_out_29 = qco.ctrl(%result_25) targets (%arg0 = %result_27) {
      %29 = qco.p(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %29 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qtensor.insert %targets_out_29 into %out_tensor_26[%c0] : tensor<2x!qco.qubit>
    %18 = qtensor.insert %controls_out_28 into %out_tensor_24[%c0] : tensor<2x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %17[%c0] : tensor<2x!qco.qubit>
    %19 = qco.h %result_31 : !qco.qubit -> !qco.qubit
    %20 = qtensor.insert %19 into %out_tensor_30[%c0] : tensor<2x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %20[%c0] : tensor<2x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %out_tensor_32[%c1] : tensor<2x!qco.qubit>
    %controls_out_36, %targets_out_37 = qco.ctrl(%result_33) targets (%arg0 = %result_35) {
      %29 = qco.p(%cst) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %29 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qtensor.insert %targets_out_37 into %out_tensor_34[%c1] : tensor<2x!qco.qubit>
    %22 = qtensor.insert %controls_out_36 into %21[%c0] : tensor<2x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %22[%c1] : tensor<2x!qco.qubit>
    %23 = qco.h %result_39 : !qco.qubit -> !qco.qubit
    %24 = qtensor.insert %23 into %out_tensor_38[%c1] : tensor<2x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %24[%c0] : tensor<2x!qco.qubit>
    %qubit_out, %result_42 = qco.measure %result_41 : !qco.qubit
    %25 = qtensor.insert %qubit_out into %out_tensor_40[%c0] : tensor<2x!qco.qubit>
    cbit.store %result_42, %6[%c0] : !cbit.reg<4>
    %out_tensor_43, %result_44 = qtensor.extract %25[%c1] : tensor<2x!qco.qubit>
    %qubit_out_45, %result_46 = qco.measure %result_44 : !qco.qubit
    %26 = qtensor.insert %qubit_out_45 into %out_tensor_43[%c1] : tensor<2x!qco.qubit>
    cbit.store %result_46, %6[%c1] : !cbit.reg<4>
    %out_tensor_47, %result_48 = qtensor.extract %18[%c0] : tensor<2x!qco.qubit>
    %qubit_out_49, %result_50 = qco.measure %result_48 : !qco.qubit
    %27 = qtensor.insert %qubit_out_49 into %out_tensor_47[%c0] : tensor<2x!qco.qubit>
    cbit.store %result_50, %6[%c2] : !cbit.reg<4>
    %out_tensor_51, %result_52 = qtensor.extract %27[%c1] : tensor<2x!qco.qubit>
    %qubit_out_53, %result_54 = qco.measure %result_52 : !qco.qubit
    %28 = qtensor.insert %qubit_out_53 into %out_tensor_51[%c1] : tensor<2x!qco.qubit>
    cbit.store %result_54, %6[%c3] : !cbit.reg<4>
    qtensor.dealloc %28 : tensor<2x!qco.qubit>
    qtensor.dealloc %26 : tensor<2x!qco.qubit>
    return %6 : !cbit.reg<4>
  }
}
