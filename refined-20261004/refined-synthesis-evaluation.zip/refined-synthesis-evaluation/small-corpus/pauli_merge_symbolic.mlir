module {
  func.func @main(%arg0: f64 {mqt.input_id = -3033000624479524390794154133784343657 : i128, mqt.input_name = "theta[0]", mqt.parameter_group = {identity = "fdb7dd86-1c01-4fc1-b8da-f3c16e084b97", index = 0 : i64, name = "theta", size = 2 : i64}}, %arg1: f64 {mqt.input_id = -3033000624479524390794154133784343656 : i128, mqt.input_name = "theta[1]", mqt.parameter_group = {identity = "fdb7dd86-1c01-4fc1-b8da-f3c16e084b97", index = 1 : i64, name = "theta", size = 2 : i64}}) -> i64 attributes {mqt.entry_point} {
    %c0_i64 = arith.constant 0 : i64
    %cst = arith.constant 0.000000e+00 : f64
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %0 = qtensor.alloc(%c2) {mqt.register_name = "q"} : tensor<2x!qco.qubit>
    qco.gphase(%cst)
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<2x!qco.qubit>
    %out_tensor_0, %result_1 = qtensor.extract %out_tensor[%c1] : tensor<2x!qco.qubit>
    %qubit0_out, %qubit1_out = qco.rzz(%arg0) %result, %result_1 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %1 = qtensor.insert %qubit1_out into %out_tensor_0[%c1] : tensor<2x!qco.qubit>
    %2 = qtensor.insert %qubit0_out into %1[%c0] : tensor<2x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %2[%c0] : tensor<2x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %out_tensor_2[%c1] : tensor<2x!qco.qubit>
    %qubit0_out_6, %qubit1_out_7 = qco.rzz(%arg1) %result_3, %result_5 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %3 = qtensor.insert %qubit1_out_7 into %out_tensor_4[%c1] : tensor<2x!qco.qubit>
    %4 = qtensor.insert %qubit0_out_6 into %3[%c0] : tensor<2x!qco.qubit>
    qtensor.dealloc %4 : tensor<2x!qco.qubit>
    return %c0_i64 : i64
  }
}
