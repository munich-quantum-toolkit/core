module {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %c3 = arith.constant 3 : index
    %cst = arith.constant 1.5707963267948968 : f64
    %c2 = arith.constant 2 : index
    %cst_0 = arith.constant 1.9106332362490184 : f64
    %cst_1 = arith.constant 2.0943951023931957 : f64
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c0 = arith.constant 0 : index
    %0 = qtensor.alloc(%c4) {mqt.register_name = "q"} : tensor<4x!qco.qubit>
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<4x!qco.qubit>
    %2 = qco.x %result : !qco.qubit -> !qco.qubit
    %3 = qtensor.insert %2 into %out_tensor[%c0] : tensor<4x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %3[%c0] : tensor<4x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %out_tensor_2[%c1] : tensor<4x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_3) targets (%arg0 = %result_5) {
      %20 = qco.ry(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %20 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %4 = qtensor.insert %targets_out into %out_tensor_4[%c1] : tensor<4x!qco.qubit>
    %5 = qtensor.insert %controls_out into %4[%c0] : tensor<4x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %5[%c1] : tensor<4x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %out_tensor_6[%c0] : tensor<4x!qco.qubit>
    %controls_out_10, %targets_out_11 = qco.ctrl(%result_7) targets (%arg0 = %result_9) {
      %20 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %20 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %6 = qtensor.insert %targets_out_11 into %out_tensor_8[%c0] : tensor<4x!qco.qubit>
    %7 = qtensor.insert %controls_out_10 into %6[%c1] : tensor<4x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %7[%c1] : tensor<4x!qco.qubit>
    %out_tensor_14, %result_15 = qtensor.extract %out_tensor_12[%c2] : tensor<4x!qco.qubit>
    %controls_out_16, %targets_out_17 = qco.ctrl(%result_13) targets (%arg0 = %result_15) {
      %20 = qco.ry(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %20 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %8 = qtensor.insert %targets_out_17 into %out_tensor_14[%c2] : tensor<4x!qco.qubit>
    %9 = qtensor.insert %controls_out_16 into %8[%c1] : tensor<4x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %9[%c2] : tensor<4x!qco.qubit>
    %out_tensor_20, %result_21 = qtensor.extract %out_tensor_18[%c1] : tensor<4x!qco.qubit>
    %controls_out_22, %targets_out_23 = qco.ctrl(%result_19) targets (%arg0 = %result_21) {
      %20 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %20 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %10 = qtensor.insert %targets_out_23 into %out_tensor_20[%c1] : tensor<4x!qco.qubit>
    %11 = qtensor.insert %controls_out_22 into %10[%c2] : tensor<4x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %11[%c2] : tensor<4x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %out_tensor_24[%c3] : tensor<4x!qco.qubit>
    %controls_out_28, %targets_out_29 = qco.ctrl(%result_25) targets (%arg0 = %result_27) {
      %20 = qco.ry(%cst) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %20 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qtensor.insert %targets_out_29 into %out_tensor_26[%c3] : tensor<4x!qco.qubit>
    %13 = qtensor.insert %controls_out_28 into %12[%c2] : tensor<4x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %13[%c3] : tensor<4x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %out_tensor_30[%c2] : tensor<4x!qco.qubit>
    %controls_out_34, %targets_out_35 = qco.ctrl(%result_31) targets (%arg0 = %result_33) {
      %20 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %20 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qtensor.insert %targets_out_35 into %out_tensor_32[%c2] : tensor<4x!qco.qubit>
    %15 = qtensor.insert %controls_out_34 into %14[%c3] : tensor<4x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %15[%c0] : tensor<4x!qco.qubit>
    %qubit_out, %result_38 = qco.measure %result_37 : !qco.qubit
    %16 = qtensor.insert %qubit_out into %out_tensor_36[%c0] : tensor<4x!qco.qubit>
    cbit.store %result_38, %1[%c0] : !cbit.reg<4>
    %out_tensor_39, %result_40 = qtensor.extract %16[%c1] : tensor<4x!qco.qubit>
    %qubit_out_41, %result_42 = qco.measure %result_40 : !qco.qubit
    %17 = qtensor.insert %qubit_out_41 into %out_tensor_39[%c1] : tensor<4x!qco.qubit>
    cbit.store %result_42, %1[%c1] : !cbit.reg<4>
    %out_tensor_43, %result_44 = qtensor.extract %17[%c2] : tensor<4x!qco.qubit>
    %qubit_out_45, %result_46 = qco.measure %result_44 : !qco.qubit
    %18 = qtensor.insert %qubit_out_45 into %out_tensor_43[%c2] : tensor<4x!qco.qubit>
    cbit.store %result_46, %1[%c2] : !cbit.reg<4>
    %out_tensor_47, %result_48 = qtensor.extract %18[%c3] : tensor<4x!qco.qubit>
    %qubit_out_49, %result_50 = qco.measure %result_48 : !qco.qubit
    %19 = qtensor.insert %qubit_out_49 into %out_tensor_47[%c3] : tensor<4x!qco.qubit>
    cbit.store %result_50, %1[%c3] : !cbit.reg<4>
    qtensor.dealloc %19 : tensor<4x!qco.qubit>
    return %1 : !cbit.reg<4>
  }
}
