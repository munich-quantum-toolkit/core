module {
  func.func @main() -> !cbit.reg<16> attributes {mqt.entry_point} {
    %c15 = arith.constant 15 : index
    %c14 = arith.constant 14 : index
    %c13 = arith.constant 13 : index
    %c12 = arith.constant 12 : index
    %c11 = arith.constant 11 : index
    %c10 = arith.constant 10 : index
    %c9 = arith.constant 9 : index
    %c8 = arith.constant 8 : index
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c16 = arith.constant 16 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %0 = qtensor.alloc(%c16) {mqt.register_name = "q"} : tensor<16x!qco.qubit>
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<16>
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<16x!qco.qubit>
    %2 = qco.h %result : !qco.qubit -> !qco.qubit
    %3 = qtensor.insert %2 into %out_tensor[%c0] : tensor<16x!qco.qubit>
    %out_tensor_0, %result_1 = qtensor.extract %3[%c0] : tensor<16x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %out_tensor_0[%c1] : tensor<16x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_1) targets (%arg0 = %result_3) {
      %50 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %4 = qtensor.insert %targets_out into %out_tensor_2[%c1] : tensor<16x!qco.qubit>
    %5 = qtensor.insert %controls_out into %4[%c0] : tensor<16x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %5[%c1] : tensor<16x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %out_tensor_4[%c2] : tensor<16x!qco.qubit>
    %controls_out_8, %targets_out_9 = qco.ctrl(%result_5) targets (%arg0 = %result_7) {
      %50 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %6 = qtensor.insert %targets_out_9 into %out_tensor_6[%c2] : tensor<16x!qco.qubit>
    %7 = qtensor.insert %controls_out_8 into %6[%c1] : tensor<16x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %7[%c2] : tensor<16x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %out_tensor_10[%c3] : tensor<16x!qco.qubit>
    %controls_out_14, %targets_out_15 = qco.ctrl(%result_11) targets (%arg0 = %result_13) {
      %50 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %8 = qtensor.insert %targets_out_15 into %out_tensor_12[%c3] : tensor<16x!qco.qubit>
    %9 = qtensor.insert %controls_out_14 into %8[%c2] : tensor<16x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %9[%c3] : tensor<16x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %out_tensor_16[%c4] : tensor<16x!qco.qubit>
    %controls_out_20, %targets_out_21 = qco.ctrl(%result_17) targets (%arg0 = %result_19) {
      %50 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %10 = qtensor.insert %targets_out_21 into %out_tensor_18[%c4] : tensor<16x!qco.qubit>
    %11 = qtensor.insert %controls_out_20 into %10[%c3] : tensor<16x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %11[%c4] : tensor<16x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %out_tensor_22[%c5] : tensor<16x!qco.qubit>
    %controls_out_26, %targets_out_27 = qco.ctrl(%result_23) targets (%arg0 = %result_25) {
      %50 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qtensor.insert %targets_out_27 into %out_tensor_24[%c5] : tensor<16x!qco.qubit>
    %13 = qtensor.insert %controls_out_26 into %12[%c4] : tensor<16x!qco.qubit>
    %out_tensor_28, %result_29 = qtensor.extract %13[%c5] : tensor<16x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %out_tensor_28[%c6] : tensor<16x!qco.qubit>
    %controls_out_32, %targets_out_33 = qco.ctrl(%result_29) targets (%arg0 = %result_31) {
      %50 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qtensor.insert %targets_out_33 into %out_tensor_30[%c6] : tensor<16x!qco.qubit>
    %15 = qtensor.insert %controls_out_32 into %14[%c5] : tensor<16x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %15[%c6] : tensor<16x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %out_tensor_34[%c7] : tensor<16x!qco.qubit>
    %controls_out_38, %targets_out_39 = qco.ctrl(%result_35) targets (%arg0 = %result_37) {
      %50 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qtensor.insert %targets_out_39 into %out_tensor_36[%c7] : tensor<16x!qco.qubit>
    %17 = qtensor.insert %controls_out_38 into %16[%c6] : tensor<16x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %17[%c7] : tensor<16x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %out_tensor_40[%c8] : tensor<16x!qco.qubit>
    %controls_out_44, %targets_out_45 = qco.ctrl(%result_41) targets (%arg0 = %result_43) {
      %50 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qtensor.insert %targets_out_45 into %out_tensor_42[%c8] : tensor<16x!qco.qubit>
    %19 = qtensor.insert %controls_out_44 into %18[%c7] : tensor<16x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %19[%c8] : tensor<16x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %out_tensor_46[%c9] : tensor<16x!qco.qubit>
    %controls_out_50, %targets_out_51 = qco.ctrl(%result_47) targets (%arg0 = %result_49) {
      %50 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qtensor.insert %targets_out_51 into %out_tensor_48[%c9] : tensor<16x!qco.qubit>
    %21 = qtensor.insert %controls_out_50 into %20[%c8] : tensor<16x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %21[%c9] : tensor<16x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %out_tensor_52[%c10] : tensor<16x!qco.qubit>
    %controls_out_56, %targets_out_57 = qco.ctrl(%result_53) targets (%arg0 = %result_55) {
      %50 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qtensor.insert %targets_out_57 into %out_tensor_54[%c10] : tensor<16x!qco.qubit>
    %23 = qtensor.insert %controls_out_56 into %22[%c9] : tensor<16x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %23[%c10] : tensor<16x!qco.qubit>
    %out_tensor_60, %result_61 = qtensor.extract %out_tensor_58[%c11] : tensor<16x!qco.qubit>
    %controls_out_62, %targets_out_63 = qco.ctrl(%result_59) targets (%arg0 = %result_61) {
      %50 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qtensor.insert %targets_out_63 into %out_tensor_60[%c11] : tensor<16x!qco.qubit>
    %25 = qtensor.insert %controls_out_62 into %24[%c10] : tensor<16x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %25[%c11] : tensor<16x!qco.qubit>
    %out_tensor_66, %result_67 = qtensor.extract %out_tensor_64[%c12] : tensor<16x!qco.qubit>
    %controls_out_68, %targets_out_69 = qco.ctrl(%result_65) targets (%arg0 = %result_67) {
      %50 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qtensor.insert %targets_out_69 into %out_tensor_66[%c12] : tensor<16x!qco.qubit>
    %27 = qtensor.insert %controls_out_68 into %26[%c11] : tensor<16x!qco.qubit>
    %out_tensor_70, %result_71 = qtensor.extract %27[%c12] : tensor<16x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %out_tensor_70[%c13] : tensor<16x!qco.qubit>
    %controls_out_74, %targets_out_75 = qco.ctrl(%result_71) targets (%arg0 = %result_73) {
      %50 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qtensor.insert %targets_out_75 into %out_tensor_72[%c13] : tensor<16x!qco.qubit>
    %29 = qtensor.insert %controls_out_74 into %28[%c12] : tensor<16x!qco.qubit>
    %out_tensor_76, %result_77 = qtensor.extract %29[%c13] : tensor<16x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %out_tensor_76[%c14] : tensor<16x!qco.qubit>
    %controls_out_80, %targets_out_81 = qco.ctrl(%result_77) targets (%arg0 = %result_79) {
      %50 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qtensor.insert %targets_out_81 into %out_tensor_78[%c14] : tensor<16x!qco.qubit>
    %31 = qtensor.insert %controls_out_80 into %30[%c13] : tensor<16x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %31[%c14] : tensor<16x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %out_tensor_82[%c15] : tensor<16x!qco.qubit>
    %controls_out_86, %targets_out_87 = qco.ctrl(%result_83) targets (%arg0 = %result_85) {
      %50 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qtensor.insert %targets_out_87 into %out_tensor_84[%c15] : tensor<16x!qco.qubit>
    %33 = qtensor.insert %controls_out_86 into %32[%c14] : tensor<16x!qco.qubit>
    %out_tensor_88, %result_89 = qtensor.extract %33[%c0] : tensor<16x!qco.qubit>
    %qubit_out, %result_90 = qco.measure %result_89 : !qco.qubit
    %34 = qtensor.insert %qubit_out into %out_tensor_88[%c0] : tensor<16x!qco.qubit>
    cbit.store %result_90, %1[%c0] : !cbit.reg<16>
    %out_tensor_91, %result_92 = qtensor.extract %34[%c1] : tensor<16x!qco.qubit>
    %qubit_out_93, %result_94 = qco.measure %result_92 : !qco.qubit
    %35 = qtensor.insert %qubit_out_93 into %out_tensor_91[%c1] : tensor<16x!qco.qubit>
    cbit.store %result_94, %1[%c1] : !cbit.reg<16>
    %out_tensor_95, %result_96 = qtensor.extract %35[%c2] : tensor<16x!qco.qubit>
    %qubit_out_97, %result_98 = qco.measure %result_96 : !qco.qubit
    %36 = qtensor.insert %qubit_out_97 into %out_tensor_95[%c2] : tensor<16x!qco.qubit>
    cbit.store %result_98, %1[%c2] : !cbit.reg<16>
    %out_tensor_99, %result_100 = qtensor.extract %36[%c3] : tensor<16x!qco.qubit>
    %qubit_out_101, %result_102 = qco.measure %result_100 : !qco.qubit
    %37 = qtensor.insert %qubit_out_101 into %out_tensor_99[%c3] : tensor<16x!qco.qubit>
    cbit.store %result_102, %1[%c3] : !cbit.reg<16>
    %out_tensor_103, %result_104 = qtensor.extract %37[%c4] : tensor<16x!qco.qubit>
    %qubit_out_105, %result_106 = qco.measure %result_104 : !qco.qubit
    %38 = qtensor.insert %qubit_out_105 into %out_tensor_103[%c4] : tensor<16x!qco.qubit>
    cbit.store %result_106, %1[%c4] : !cbit.reg<16>
    %out_tensor_107, %result_108 = qtensor.extract %38[%c5] : tensor<16x!qco.qubit>
    %qubit_out_109, %result_110 = qco.measure %result_108 : !qco.qubit
    %39 = qtensor.insert %qubit_out_109 into %out_tensor_107[%c5] : tensor<16x!qco.qubit>
    cbit.store %result_110, %1[%c5] : !cbit.reg<16>
    %out_tensor_111, %result_112 = qtensor.extract %39[%c6] : tensor<16x!qco.qubit>
    %qubit_out_113, %result_114 = qco.measure %result_112 : !qco.qubit
    %40 = qtensor.insert %qubit_out_113 into %out_tensor_111[%c6] : tensor<16x!qco.qubit>
    cbit.store %result_114, %1[%c6] : !cbit.reg<16>
    %out_tensor_115, %result_116 = qtensor.extract %40[%c7] : tensor<16x!qco.qubit>
    %qubit_out_117, %result_118 = qco.measure %result_116 : !qco.qubit
    %41 = qtensor.insert %qubit_out_117 into %out_tensor_115[%c7] : tensor<16x!qco.qubit>
    cbit.store %result_118, %1[%c7] : !cbit.reg<16>
    %out_tensor_119, %result_120 = qtensor.extract %41[%c8] : tensor<16x!qco.qubit>
    %qubit_out_121, %result_122 = qco.measure %result_120 : !qco.qubit
    %42 = qtensor.insert %qubit_out_121 into %out_tensor_119[%c8] : tensor<16x!qco.qubit>
    cbit.store %result_122, %1[%c8] : !cbit.reg<16>
    %out_tensor_123, %result_124 = qtensor.extract %42[%c9] : tensor<16x!qco.qubit>
    %qubit_out_125, %result_126 = qco.measure %result_124 : !qco.qubit
    %43 = qtensor.insert %qubit_out_125 into %out_tensor_123[%c9] : tensor<16x!qco.qubit>
    cbit.store %result_126, %1[%c9] : !cbit.reg<16>
    %out_tensor_127, %result_128 = qtensor.extract %43[%c10] : tensor<16x!qco.qubit>
    %qubit_out_129, %result_130 = qco.measure %result_128 : !qco.qubit
    %44 = qtensor.insert %qubit_out_129 into %out_tensor_127[%c10] : tensor<16x!qco.qubit>
    cbit.store %result_130, %1[%c10] : !cbit.reg<16>
    %out_tensor_131, %result_132 = qtensor.extract %44[%c11] : tensor<16x!qco.qubit>
    %qubit_out_133, %result_134 = qco.measure %result_132 : !qco.qubit
    %45 = qtensor.insert %qubit_out_133 into %out_tensor_131[%c11] : tensor<16x!qco.qubit>
    cbit.store %result_134, %1[%c11] : !cbit.reg<16>
    %out_tensor_135, %result_136 = qtensor.extract %45[%c12] : tensor<16x!qco.qubit>
    %qubit_out_137, %result_138 = qco.measure %result_136 : !qco.qubit
    %46 = qtensor.insert %qubit_out_137 into %out_tensor_135[%c12] : tensor<16x!qco.qubit>
    cbit.store %result_138, %1[%c12] : !cbit.reg<16>
    %out_tensor_139, %result_140 = qtensor.extract %46[%c13] : tensor<16x!qco.qubit>
    %qubit_out_141, %result_142 = qco.measure %result_140 : !qco.qubit
    %47 = qtensor.insert %qubit_out_141 into %out_tensor_139[%c13] : tensor<16x!qco.qubit>
    cbit.store %result_142, %1[%c13] : !cbit.reg<16>
    %out_tensor_143, %result_144 = qtensor.extract %47[%c14] : tensor<16x!qco.qubit>
    %qubit_out_145, %result_146 = qco.measure %result_144 : !qco.qubit
    %48 = qtensor.insert %qubit_out_145 into %out_tensor_143[%c14] : tensor<16x!qco.qubit>
    cbit.store %result_146, %1[%c14] : !cbit.reg<16>
    %out_tensor_147, %result_148 = qtensor.extract %48[%c15] : tensor<16x!qco.qubit>
    %qubit_out_149, %result_150 = qco.measure %result_148 : !qco.qubit
    %49 = qtensor.insert %qubit_out_149 into %out_tensor_147[%c15] : tensor<16x!qco.qubit>
    cbit.store %result_150, %1[%c15] : !cbit.reg<16>
    qtensor.dealloc %49 : tensor<16x!qco.qubit>
    return %1 : !cbit.reg<16>
  }
}
