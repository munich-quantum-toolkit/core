module {
  func.func @main(%arg0: f64 {mqt.input_id = 44246249981895013191645689038461798644 : i128, mqt.input_name = "\CE\B8[0]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 0 : i64, name = "\CE\B8", size = 64 : i64}}, %arg1: f64 {mqt.input_id = 44246249981895013191645689038461798645 : i128, mqt.input_name = "\CE\B8[1]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 1 : i64, name = "\CE\B8", size = 64 : i64}}, %arg2: f64 {mqt.input_id = 44246249981895013191645689038461798646 : i128, mqt.input_name = "\CE\B8[2]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 2 : i64, name = "\CE\B8", size = 64 : i64}}, %arg3: f64 {mqt.input_id = 44246249981895013191645689038461798647 : i128, mqt.input_name = "\CE\B8[3]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 3 : i64, name = "\CE\B8", size = 64 : i64}}, %arg4: f64 {mqt.input_id = 44246249981895013191645689038461798648 : i128, mqt.input_name = "\CE\B8[4]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 4 : i64, name = "\CE\B8", size = 64 : i64}}, %arg5: f64 {mqt.input_id = 44246249981895013191645689038461798649 : i128, mqt.input_name = "\CE\B8[5]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 5 : i64, name = "\CE\B8", size = 64 : i64}}, %arg6: f64 {mqt.input_id = 44246249981895013191645689038461798650 : i128, mqt.input_name = "\CE\B8[6]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 6 : i64, name = "\CE\B8", size = 64 : i64}}, %arg7: f64 {mqt.input_id = 44246249981895013191645689038461798651 : i128, mqt.input_name = "\CE\B8[7]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 7 : i64, name = "\CE\B8", size = 64 : i64}}, %arg8: f64 {mqt.input_id = 44246249981895013191645689038461798652 : i128, mqt.input_name = "\CE\B8[8]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 8 : i64, name = "\CE\B8", size = 64 : i64}}, %arg9: f64 {mqt.input_id = 44246249981895013191645689038461798653 : i128, mqt.input_name = "\CE\B8[9]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 9 : i64, name = "\CE\B8", size = 64 : i64}}, %arg10: f64 {mqt.input_id = 44246249981895013191645689038461798654 : i128, mqt.input_name = "\CE\B8[10]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 10 : i64, name = "\CE\B8", size = 64 : i64}}, %arg11: f64 {mqt.input_id = 44246249981895013191645689038461798655 : i128, mqt.input_name = "\CE\B8[11]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 11 : i64, name = "\CE\B8", size = 64 : i64}}, %arg12: f64 {mqt.input_id = 44246249981895013191645689038461798656 : i128, mqt.input_name = "\CE\B8[12]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 12 : i64, name = "\CE\B8", size = 64 : i64}}, %arg13: f64 {mqt.input_id = 44246249981895013191645689038461798657 : i128, mqt.input_name = "\CE\B8[13]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 13 : i64, name = "\CE\B8", size = 64 : i64}}, %arg14: f64 {mqt.input_id = 44246249981895013191645689038461798658 : i128, mqt.input_name = "\CE\B8[14]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 14 : i64, name = "\CE\B8", size = 64 : i64}}, %arg15: f64 {mqt.input_id = 44246249981895013191645689038461798659 : i128, mqt.input_name = "\CE\B8[15]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 15 : i64, name = "\CE\B8", size = 64 : i64}}, %arg16: f64 {mqt.input_id = 44246249981895013191645689038461798660 : i128, mqt.input_name = "\CE\B8[16]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 16 : i64, name = "\CE\B8", size = 64 : i64}}, %arg17: f64 {mqt.input_id = 44246249981895013191645689038461798661 : i128, mqt.input_name = "\CE\B8[17]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 17 : i64, name = "\CE\B8", size = 64 : i64}}, %arg18: f64 {mqt.input_id = 44246249981895013191645689038461798662 : i128, mqt.input_name = "\CE\B8[18]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 18 : i64, name = "\CE\B8", size = 64 : i64}}, %arg19: f64 {mqt.input_id = 44246249981895013191645689038461798663 : i128, mqt.input_name = "\CE\B8[19]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 19 : i64, name = "\CE\B8", size = 64 : i64}}, %arg20: f64 {mqt.input_id = 44246249981895013191645689038461798664 : i128, mqt.input_name = "\CE\B8[20]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 20 : i64, name = "\CE\B8", size = 64 : i64}}, %arg21: f64 {mqt.input_id = 44246249981895013191645689038461798665 : i128, mqt.input_name = "\CE\B8[21]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 21 : i64, name = "\CE\B8", size = 64 : i64}}, %arg22: f64 {mqt.input_id = 44246249981895013191645689038461798666 : i128, mqt.input_name = "\CE\B8[22]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 22 : i64, name = "\CE\B8", size = 64 : i64}}, %arg23: f64 {mqt.input_id = 44246249981895013191645689038461798667 : i128, mqt.input_name = "\CE\B8[23]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 23 : i64, name = "\CE\B8", size = 64 : i64}}, %arg24: f64 {mqt.input_id = 44246249981895013191645689038461798668 : i128, mqt.input_name = "\CE\B8[24]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 24 : i64, name = "\CE\B8", size = 64 : i64}}, %arg25: f64 {mqt.input_id = 44246249981895013191645689038461798669 : i128, mqt.input_name = "\CE\B8[25]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 25 : i64, name = "\CE\B8", size = 64 : i64}}, %arg26: f64 {mqt.input_id = 44246249981895013191645689038461798670 : i128, mqt.input_name = "\CE\B8[26]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 26 : i64, name = "\CE\B8", size = 64 : i64}}, %arg27: f64 {mqt.input_id = 44246249981895013191645689038461798671 : i128, mqt.input_name = "\CE\B8[27]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 27 : i64, name = "\CE\B8", size = 64 : i64}}, %arg28: f64 {mqt.input_id = 44246249981895013191645689038461798672 : i128, mqt.input_name = "\CE\B8[28]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 28 : i64, name = "\CE\B8", size = 64 : i64}}, %arg29: f64 {mqt.input_id = 44246249981895013191645689038461798673 : i128, mqt.input_name = "\CE\B8[29]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 29 : i64, name = "\CE\B8", size = 64 : i64}}, %arg30: f64 {mqt.input_id = 44246249981895013191645689038461798674 : i128, mqt.input_name = "\CE\B8[30]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 30 : i64, name = "\CE\B8", size = 64 : i64}}, %arg31: f64 {mqt.input_id = 44246249981895013191645689038461798675 : i128, mqt.input_name = "\CE\B8[31]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 31 : i64, name = "\CE\B8", size = 64 : i64}}, %arg32: f64 {mqt.input_id = 44246249981895013191645689038461798676 : i128, mqt.input_name = "\CE\B8[32]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 32 : i64, name = "\CE\B8", size = 64 : i64}}, %arg33: f64 {mqt.input_id = 44246249981895013191645689038461798677 : i128, mqt.input_name = "\CE\B8[33]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 33 : i64, name = "\CE\B8", size = 64 : i64}}, %arg34: f64 {mqt.input_id = 44246249981895013191645689038461798678 : i128, mqt.input_name = "\CE\B8[34]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 34 : i64, name = "\CE\B8", size = 64 : i64}}, %arg35: f64 {mqt.input_id = 44246249981895013191645689038461798679 : i128, mqt.input_name = "\CE\B8[35]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 35 : i64, name = "\CE\B8", size = 64 : i64}}, %arg36: f64 {mqt.input_id = 44246249981895013191645689038461798680 : i128, mqt.input_name = "\CE\B8[36]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 36 : i64, name = "\CE\B8", size = 64 : i64}}, %arg37: f64 {mqt.input_id = 44246249981895013191645689038461798681 : i128, mqt.input_name = "\CE\B8[37]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 37 : i64, name = "\CE\B8", size = 64 : i64}}, %arg38: f64 {mqt.input_id = 44246249981895013191645689038461798682 : i128, mqt.input_name = "\CE\B8[38]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 38 : i64, name = "\CE\B8", size = 64 : i64}}, %arg39: f64 {mqt.input_id = 44246249981895013191645689038461798683 : i128, mqt.input_name = "\CE\B8[39]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 39 : i64, name = "\CE\B8", size = 64 : i64}}, %arg40: f64 {mqt.input_id = 44246249981895013191645689038461798684 : i128, mqt.input_name = "\CE\B8[40]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 40 : i64, name = "\CE\B8", size = 64 : i64}}, %arg41: f64 {mqt.input_id = 44246249981895013191645689038461798685 : i128, mqt.input_name = "\CE\B8[41]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 41 : i64, name = "\CE\B8", size = 64 : i64}}, %arg42: f64 {mqt.input_id = 44246249981895013191645689038461798686 : i128, mqt.input_name = "\CE\B8[42]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 42 : i64, name = "\CE\B8", size = 64 : i64}}, %arg43: f64 {mqt.input_id = 44246249981895013191645689038461798687 : i128, mqt.input_name = "\CE\B8[43]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 43 : i64, name = "\CE\B8", size = 64 : i64}}, %arg44: f64 {mqt.input_id = 44246249981895013191645689038461798688 : i128, mqt.input_name = "\CE\B8[44]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 44 : i64, name = "\CE\B8", size = 64 : i64}}, %arg45: f64 {mqt.input_id = 44246249981895013191645689038461798689 : i128, mqt.input_name = "\CE\B8[45]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 45 : i64, name = "\CE\B8", size = 64 : i64}}, %arg46: f64 {mqt.input_id = 44246249981895013191645689038461798690 : i128, mqt.input_name = "\CE\B8[46]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 46 : i64, name = "\CE\B8", size = 64 : i64}}, %arg47: f64 {mqt.input_id = 44246249981895013191645689038461798691 : i128, mqt.input_name = "\CE\B8[47]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 47 : i64, name = "\CE\B8", size = 64 : i64}}, %arg48: f64 {mqt.input_id = 44246249981895013191645689038461798692 : i128, mqt.input_name = "\CE\B8[48]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 48 : i64, name = "\CE\B8", size = 64 : i64}}, %arg49: f64 {mqt.input_id = 44246249981895013191645689038461798693 : i128, mqt.input_name = "\CE\B8[49]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 49 : i64, name = "\CE\B8", size = 64 : i64}}, %arg50: f64 {mqt.input_id = 44246249981895013191645689038461798694 : i128, mqt.input_name = "\CE\B8[50]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 50 : i64, name = "\CE\B8", size = 64 : i64}}, %arg51: f64 {mqt.input_id = 44246249981895013191645689038461798695 : i128, mqt.input_name = "\CE\B8[51]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 51 : i64, name = "\CE\B8", size = 64 : i64}}, %arg52: f64 {mqt.input_id = 44246249981895013191645689038461798696 : i128, mqt.input_name = "\CE\B8[52]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 52 : i64, name = "\CE\B8", size = 64 : i64}}, %arg53: f64 {mqt.input_id = 44246249981895013191645689038461798697 : i128, mqt.input_name = "\CE\B8[53]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 53 : i64, name = "\CE\B8", size = 64 : i64}}, %arg54: f64 {mqt.input_id = 44246249981895013191645689038461798698 : i128, mqt.input_name = "\CE\B8[54]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 54 : i64, name = "\CE\B8", size = 64 : i64}}, %arg55: f64 {mqt.input_id = 44246249981895013191645689038461798699 : i128, mqt.input_name = "\CE\B8[55]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 55 : i64, name = "\CE\B8", size = 64 : i64}}, %arg56: f64 {mqt.input_id = 44246249981895013191645689038461798700 : i128, mqt.input_name = "\CE\B8[56]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 56 : i64, name = "\CE\B8", size = 64 : i64}}, %arg57: f64 {mqt.input_id = 44246249981895013191645689038461798701 : i128, mqt.input_name = "\CE\B8[57]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 57 : i64, name = "\CE\B8", size = 64 : i64}}, %arg58: f64 {mqt.input_id = 44246249981895013191645689038461798702 : i128, mqt.input_name = "\CE\B8[58]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 58 : i64, name = "\CE\B8", size = 64 : i64}}, %arg59: f64 {mqt.input_id = 44246249981895013191645689038461798703 : i128, mqt.input_name = "\CE\B8[59]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 59 : i64, name = "\CE\B8", size = 64 : i64}}, %arg60: f64 {mqt.input_id = 44246249981895013191645689038461798704 : i128, mqt.input_name = "\CE\B8[60]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 60 : i64, name = "\CE\B8", size = 64 : i64}}, %arg61: f64 {mqt.input_id = 44246249981895013191645689038461798705 : i128, mqt.input_name = "\CE\B8[61]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 61 : i64, name = "\CE\B8", size = 64 : i64}}, %arg62: f64 {mqt.input_id = 44246249981895013191645689038461798706 : i128, mqt.input_name = "\CE\B8[62]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 62 : i64, name = "\CE\B8", size = 64 : i64}}, %arg63: f64 {mqt.input_id = 44246249981895013191645689038461798707 : i128, mqt.input_name = "\CE\B8[63]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 63 : i64, name = "\CE\B8", size = 64 : i64}}) -> i64 attributes {mqt.entry_point} {
    %c0_i64 = arith.constant 0 : i64
    %cst = arith.constant 0.000000e+00 : f64
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c8 = arith.constant 8 : index
    %0 = qtensor.alloc(%c8) {mqt.register_name = "q"} : tensor<8x!qco.qubit>
    qco.gphase(%cst)
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<8x!qco.qubit>
    %1 = qco.ry(%arg0) %result : !qco.qubit -> !qco.qubit
    %2 = qtensor.insert %1 into %out_tensor[%c0] : tensor<8x!qco.qubit>
    %out_tensor_0, %result_1 = qtensor.extract %2[%c1] : tensor<8x!qco.qubit>
    %3 = qco.ry(%arg1) %result_1 : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor_0[%c1] : tensor<8x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %4[%c2] : tensor<8x!qco.qubit>
    %5 = qco.ry(%arg2) %result_3 : !qco.qubit -> !qco.qubit
    %6 = qtensor.insert %5 into %out_tensor_2[%c2] : tensor<8x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %6[%c3] : tensor<8x!qco.qubit>
    %7 = qco.ry(%arg3) %result_5 : !qco.qubit -> !qco.qubit
    %8 = qtensor.insert %7 into %out_tensor_4[%c3] : tensor<8x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %8[%c4] : tensor<8x!qco.qubit>
    %9 = qco.ry(%arg4) %result_7 : !qco.qubit -> !qco.qubit
    %10 = qtensor.insert %9 into %out_tensor_6[%c4] : tensor<8x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %10[%c5] : tensor<8x!qco.qubit>
    %11 = qco.ry(%arg5) %result_9 : !qco.qubit -> !qco.qubit
    %12 = qtensor.insert %11 into %out_tensor_8[%c5] : tensor<8x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %12[%c6] : tensor<8x!qco.qubit>
    %13 = qco.ry(%arg6) %result_11 : !qco.qubit -> !qco.qubit
    %14 = qtensor.insert %13 into %out_tensor_10[%c6] : tensor<8x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %14[%c7] : tensor<8x!qco.qubit>
    %15 = qco.ry(%arg7) %result_13 : !qco.qubit -> !qco.qubit
    %16 = qtensor.insert %15 into %out_tensor_12[%c7] : tensor<8x!qco.qubit>
    %out_tensor_14, %result_15 = qtensor.extract %16[%c0] : tensor<8x!qco.qubit>
    %17 = qco.rz(%arg8) %result_15 : !qco.qubit -> !qco.qubit
    %18 = qtensor.insert %17 into %out_tensor_14[%c0] : tensor<8x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %18[%c1] : tensor<8x!qco.qubit>
    %19 = qco.rz(%arg9) %result_17 : !qco.qubit -> !qco.qubit
    %20 = qtensor.insert %19 into %out_tensor_16[%c1] : tensor<8x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %20[%c2] : tensor<8x!qco.qubit>
    %21 = qco.rz(%arg10) %result_19 : !qco.qubit -> !qco.qubit
    %22 = qtensor.insert %21 into %out_tensor_18[%c2] : tensor<8x!qco.qubit>
    %out_tensor_20, %result_21 = qtensor.extract %22[%c3] : tensor<8x!qco.qubit>
    %23 = qco.rz(%arg11) %result_21 : !qco.qubit -> !qco.qubit
    %24 = qtensor.insert %23 into %out_tensor_20[%c3] : tensor<8x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %24[%c4] : tensor<8x!qco.qubit>
    %25 = qco.rz(%arg12) %result_23 : !qco.qubit -> !qco.qubit
    %26 = qtensor.insert %25 into %out_tensor_22[%c4] : tensor<8x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %26[%c5] : tensor<8x!qco.qubit>
    %27 = qco.rz(%arg13) %result_25 : !qco.qubit -> !qco.qubit
    %28 = qtensor.insert %27 into %out_tensor_24[%c5] : tensor<8x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %28[%c6] : tensor<8x!qco.qubit>
    %29 = qco.rz(%arg14) %result_27 : !qco.qubit -> !qco.qubit
    %30 = qtensor.insert %29 into %out_tensor_26[%c6] : tensor<8x!qco.qubit>
    %out_tensor_28, %result_29 = qtensor.extract %30[%c7] : tensor<8x!qco.qubit>
    %31 = qco.rz(%arg15) %result_29 : !qco.qubit -> !qco.qubit
    %32 = qtensor.insert %31 into %out_tensor_28[%c7] : tensor<8x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %32[%c7] : tensor<8x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %out_tensor_30[%c0] : tensor<8x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_31) targets (%arg64 = %result_33) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %33 = qtensor.insert %targets_out into %out_tensor_32[%c0] : tensor<8x!qco.qubit>
    %34 = qtensor.insert %controls_out into %33[%c7] : tensor<8x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %34[%c0] : tensor<8x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %out_tensor_34[%c1] : tensor<8x!qco.qubit>
    %controls_out_38, %targets_out_39 = qco.ctrl(%result_35) targets (%arg64 = %result_37) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qtensor.insert %targets_out_39 into %out_tensor_36[%c1] : tensor<8x!qco.qubit>
    %36 = qtensor.insert %controls_out_38 into %35[%c0] : tensor<8x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %36[%c1] : tensor<8x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %out_tensor_40[%c2] : tensor<8x!qco.qubit>
    %controls_out_44, %targets_out_45 = qco.ctrl(%result_41) targets (%arg64 = %result_43) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qtensor.insert %targets_out_45 into %out_tensor_42[%c2] : tensor<8x!qco.qubit>
    %38 = qtensor.insert %controls_out_44 into %37[%c1] : tensor<8x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %38[%c2] : tensor<8x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %out_tensor_46[%c3] : tensor<8x!qco.qubit>
    %controls_out_50, %targets_out_51 = qco.ctrl(%result_47) targets (%arg64 = %result_49) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qtensor.insert %targets_out_51 into %out_tensor_48[%c3] : tensor<8x!qco.qubit>
    %40 = qtensor.insert %controls_out_50 into %39[%c2] : tensor<8x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %40[%c3] : tensor<8x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %out_tensor_52[%c4] : tensor<8x!qco.qubit>
    %controls_out_56, %targets_out_57 = qco.ctrl(%result_53) targets (%arg64 = %result_55) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qtensor.insert %targets_out_57 into %out_tensor_54[%c4] : tensor<8x!qco.qubit>
    %42 = qtensor.insert %controls_out_56 into %41[%c3] : tensor<8x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %42[%c4] : tensor<8x!qco.qubit>
    %out_tensor_60, %result_61 = qtensor.extract %out_tensor_58[%c5] : tensor<8x!qco.qubit>
    %controls_out_62, %targets_out_63 = qco.ctrl(%result_59) targets (%arg64 = %result_61) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qtensor.insert %targets_out_63 into %out_tensor_60[%c5] : tensor<8x!qco.qubit>
    %44 = qtensor.insert %controls_out_62 into %43[%c4] : tensor<8x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %44[%c5] : tensor<8x!qco.qubit>
    %out_tensor_66, %result_67 = qtensor.extract %out_tensor_64[%c6] : tensor<8x!qco.qubit>
    %controls_out_68, %targets_out_69 = qco.ctrl(%result_65) targets (%arg64 = %result_67) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qtensor.insert %targets_out_69 into %out_tensor_66[%c6] : tensor<8x!qco.qubit>
    %46 = qtensor.insert %controls_out_68 into %45[%c5] : tensor<8x!qco.qubit>
    %out_tensor_70, %result_71 = qtensor.extract %46[%c6] : tensor<8x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %out_tensor_70[%c7] : tensor<8x!qco.qubit>
    %controls_out_74, %targets_out_75 = qco.ctrl(%result_71) targets (%arg64 = %result_73) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qtensor.insert %targets_out_75 into %out_tensor_72[%c7] : tensor<8x!qco.qubit>
    %48 = qtensor.insert %controls_out_74 into %47[%c6] : tensor<8x!qco.qubit>
    %out_tensor_76, %result_77 = qtensor.extract %48[%c0] : tensor<8x!qco.qubit>
    %49 = qco.ry(%arg16) %result_77 : !qco.qubit -> !qco.qubit
    %50 = qtensor.insert %49 into %out_tensor_76[%c0] : tensor<8x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %50[%c1] : tensor<8x!qco.qubit>
    %51 = qco.ry(%arg17) %result_79 : !qco.qubit -> !qco.qubit
    %52 = qtensor.insert %51 into %out_tensor_78[%c1] : tensor<8x!qco.qubit>
    %out_tensor_80, %result_81 = qtensor.extract %52[%c2] : tensor<8x!qco.qubit>
    %53 = qco.ry(%arg18) %result_81 : !qco.qubit -> !qco.qubit
    %54 = qtensor.insert %53 into %out_tensor_80[%c2] : tensor<8x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %54[%c3] : tensor<8x!qco.qubit>
    %55 = qco.ry(%arg19) %result_83 : !qco.qubit -> !qco.qubit
    %56 = qtensor.insert %55 into %out_tensor_82[%c3] : tensor<8x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %56[%c4] : tensor<8x!qco.qubit>
    %57 = qco.ry(%arg20) %result_85 : !qco.qubit -> !qco.qubit
    %58 = qtensor.insert %57 into %out_tensor_84[%c4] : tensor<8x!qco.qubit>
    %out_tensor_86, %result_87 = qtensor.extract %58[%c5] : tensor<8x!qco.qubit>
    %59 = qco.ry(%arg21) %result_87 : !qco.qubit -> !qco.qubit
    %60 = qtensor.insert %59 into %out_tensor_86[%c5] : tensor<8x!qco.qubit>
    %out_tensor_88, %result_89 = qtensor.extract %60[%c6] : tensor<8x!qco.qubit>
    %61 = qco.ry(%arg22) %result_89 : !qco.qubit -> !qco.qubit
    %62 = qtensor.insert %61 into %out_tensor_88[%c6] : tensor<8x!qco.qubit>
    %out_tensor_90, %result_91 = qtensor.extract %62[%c7] : tensor<8x!qco.qubit>
    %63 = qco.ry(%arg23) %result_91 : !qco.qubit -> !qco.qubit
    %64 = qtensor.insert %63 into %out_tensor_90[%c7] : tensor<8x!qco.qubit>
    %out_tensor_92, %result_93 = qtensor.extract %64[%c0] : tensor<8x!qco.qubit>
    %65 = qco.rz(%arg24) %result_93 : !qco.qubit -> !qco.qubit
    %66 = qtensor.insert %65 into %out_tensor_92[%c0] : tensor<8x!qco.qubit>
    %out_tensor_94, %result_95 = qtensor.extract %66[%c1] : tensor<8x!qco.qubit>
    %67 = qco.rz(%arg25) %result_95 : !qco.qubit -> !qco.qubit
    %68 = qtensor.insert %67 into %out_tensor_94[%c1] : tensor<8x!qco.qubit>
    %out_tensor_96, %result_97 = qtensor.extract %68[%c2] : tensor<8x!qco.qubit>
    %69 = qco.rz(%arg26) %result_97 : !qco.qubit -> !qco.qubit
    %70 = qtensor.insert %69 into %out_tensor_96[%c2] : tensor<8x!qco.qubit>
    %out_tensor_98, %result_99 = qtensor.extract %70[%c3] : tensor<8x!qco.qubit>
    %71 = qco.rz(%arg27) %result_99 : !qco.qubit -> !qco.qubit
    %72 = qtensor.insert %71 into %out_tensor_98[%c3] : tensor<8x!qco.qubit>
    %out_tensor_100, %result_101 = qtensor.extract %72[%c4] : tensor<8x!qco.qubit>
    %73 = qco.rz(%arg28) %result_101 : !qco.qubit -> !qco.qubit
    %74 = qtensor.insert %73 into %out_tensor_100[%c4] : tensor<8x!qco.qubit>
    %out_tensor_102, %result_103 = qtensor.extract %74[%c5] : tensor<8x!qco.qubit>
    %75 = qco.rz(%arg29) %result_103 : !qco.qubit -> !qco.qubit
    %76 = qtensor.insert %75 into %out_tensor_102[%c5] : tensor<8x!qco.qubit>
    %out_tensor_104, %result_105 = qtensor.extract %76[%c6] : tensor<8x!qco.qubit>
    %77 = qco.rz(%arg30) %result_105 : !qco.qubit -> !qco.qubit
    %78 = qtensor.insert %77 into %out_tensor_104[%c6] : tensor<8x!qco.qubit>
    %out_tensor_106, %result_107 = qtensor.extract %78[%c7] : tensor<8x!qco.qubit>
    %79 = qco.rz(%arg31) %result_107 : !qco.qubit -> !qco.qubit
    %80 = qtensor.insert %79 into %out_tensor_106[%c7] : tensor<8x!qco.qubit>
    %out_tensor_108, %result_109 = qtensor.extract %80[%c7] : tensor<8x!qco.qubit>
    %out_tensor_110, %result_111 = qtensor.extract %out_tensor_108[%c0] : tensor<8x!qco.qubit>
    %controls_out_112, %targets_out_113 = qco.ctrl(%result_109) targets (%arg64 = %result_111) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %81 = qtensor.insert %targets_out_113 into %out_tensor_110[%c0] : tensor<8x!qco.qubit>
    %82 = qtensor.insert %controls_out_112 into %81[%c7] : tensor<8x!qco.qubit>
    %out_tensor_114, %result_115 = qtensor.extract %82[%c0] : tensor<8x!qco.qubit>
    %out_tensor_116, %result_117 = qtensor.extract %out_tensor_114[%c1] : tensor<8x!qco.qubit>
    %controls_out_118, %targets_out_119 = qco.ctrl(%result_115) targets (%arg64 = %result_117) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qtensor.insert %targets_out_119 into %out_tensor_116[%c1] : tensor<8x!qco.qubit>
    %84 = qtensor.insert %controls_out_118 into %83[%c0] : tensor<8x!qco.qubit>
    %out_tensor_120, %result_121 = qtensor.extract %84[%c1] : tensor<8x!qco.qubit>
    %out_tensor_122, %result_123 = qtensor.extract %out_tensor_120[%c2] : tensor<8x!qco.qubit>
    %controls_out_124, %targets_out_125 = qco.ctrl(%result_121) targets (%arg64 = %result_123) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %85 = qtensor.insert %targets_out_125 into %out_tensor_122[%c2] : tensor<8x!qco.qubit>
    %86 = qtensor.insert %controls_out_124 into %85[%c1] : tensor<8x!qco.qubit>
    %out_tensor_126, %result_127 = qtensor.extract %86[%c2] : tensor<8x!qco.qubit>
    %out_tensor_128, %result_129 = qtensor.extract %out_tensor_126[%c3] : tensor<8x!qco.qubit>
    %controls_out_130, %targets_out_131 = qco.ctrl(%result_127) targets (%arg64 = %result_129) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %87 = qtensor.insert %targets_out_131 into %out_tensor_128[%c3] : tensor<8x!qco.qubit>
    %88 = qtensor.insert %controls_out_130 into %87[%c2] : tensor<8x!qco.qubit>
    %out_tensor_132, %result_133 = qtensor.extract %88[%c3] : tensor<8x!qco.qubit>
    %out_tensor_134, %result_135 = qtensor.extract %out_tensor_132[%c4] : tensor<8x!qco.qubit>
    %controls_out_136, %targets_out_137 = qco.ctrl(%result_133) targets (%arg64 = %result_135) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %89 = qtensor.insert %targets_out_137 into %out_tensor_134[%c4] : tensor<8x!qco.qubit>
    %90 = qtensor.insert %controls_out_136 into %89[%c3] : tensor<8x!qco.qubit>
    %out_tensor_138, %result_139 = qtensor.extract %90[%c4] : tensor<8x!qco.qubit>
    %out_tensor_140, %result_141 = qtensor.extract %out_tensor_138[%c5] : tensor<8x!qco.qubit>
    %controls_out_142, %targets_out_143 = qco.ctrl(%result_139) targets (%arg64 = %result_141) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %91 = qtensor.insert %targets_out_143 into %out_tensor_140[%c5] : tensor<8x!qco.qubit>
    %92 = qtensor.insert %controls_out_142 into %91[%c4] : tensor<8x!qco.qubit>
    %out_tensor_144, %result_145 = qtensor.extract %92[%c5] : tensor<8x!qco.qubit>
    %out_tensor_146, %result_147 = qtensor.extract %out_tensor_144[%c6] : tensor<8x!qco.qubit>
    %controls_out_148, %targets_out_149 = qco.ctrl(%result_145) targets (%arg64 = %result_147) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %93 = qtensor.insert %targets_out_149 into %out_tensor_146[%c6] : tensor<8x!qco.qubit>
    %94 = qtensor.insert %controls_out_148 into %93[%c5] : tensor<8x!qco.qubit>
    %out_tensor_150, %result_151 = qtensor.extract %94[%c6] : tensor<8x!qco.qubit>
    %out_tensor_152, %result_153 = qtensor.extract %out_tensor_150[%c7] : tensor<8x!qco.qubit>
    %controls_out_154, %targets_out_155 = qco.ctrl(%result_151) targets (%arg64 = %result_153) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %95 = qtensor.insert %targets_out_155 into %out_tensor_152[%c7] : tensor<8x!qco.qubit>
    %96 = qtensor.insert %controls_out_154 into %95[%c6] : tensor<8x!qco.qubit>
    %out_tensor_156, %result_157 = qtensor.extract %96[%c0] : tensor<8x!qco.qubit>
    %97 = qco.ry(%arg32) %result_157 : !qco.qubit -> !qco.qubit
    %98 = qtensor.insert %97 into %out_tensor_156[%c0] : tensor<8x!qco.qubit>
    %out_tensor_158, %result_159 = qtensor.extract %98[%c1] : tensor<8x!qco.qubit>
    %99 = qco.ry(%arg33) %result_159 : !qco.qubit -> !qco.qubit
    %100 = qtensor.insert %99 into %out_tensor_158[%c1] : tensor<8x!qco.qubit>
    %out_tensor_160, %result_161 = qtensor.extract %100[%c2] : tensor<8x!qco.qubit>
    %101 = qco.ry(%arg34) %result_161 : !qco.qubit -> !qco.qubit
    %102 = qtensor.insert %101 into %out_tensor_160[%c2] : tensor<8x!qco.qubit>
    %out_tensor_162, %result_163 = qtensor.extract %102[%c3] : tensor<8x!qco.qubit>
    %103 = qco.ry(%arg35) %result_163 : !qco.qubit -> !qco.qubit
    %104 = qtensor.insert %103 into %out_tensor_162[%c3] : tensor<8x!qco.qubit>
    %out_tensor_164, %result_165 = qtensor.extract %104[%c4] : tensor<8x!qco.qubit>
    %105 = qco.ry(%arg36) %result_165 : !qco.qubit -> !qco.qubit
    %106 = qtensor.insert %105 into %out_tensor_164[%c4] : tensor<8x!qco.qubit>
    %out_tensor_166, %result_167 = qtensor.extract %106[%c5] : tensor<8x!qco.qubit>
    %107 = qco.ry(%arg37) %result_167 : !qco.qubit -> !qco.qubit
    %108 = qtensor.insert %107 into %out_tensor_166[%c5] : tensor<8x!qco.qubit>
    %out_tensor_168, %result_169 = qtensor.extract %108[%c6] : tensor<8x!qco.qubit>
    %109 = qco.ry(%arg38) %result_169 : !qco.qubit -> !qco.qubit
    %110 = qtensor.insert %109 into %out_tensor_168[%c6] : tensor<8x!qco.qubit>
    %out_tensor_170, %result_171 = qtensor.extract %110[%c7] : tensor<8x!qco.qubit>
    %111 = qco.ry(%arg39) %result_171 : !qco.qubit -> !qco.qubit
    %112 = qtensor.insert %111 into %out_tensor_170[%c7] : tensor<8x!qco.qubit>
    %out_tensor_172, %result_173 = qtensor.extract %112[%c0] : tensor<8x!qco.qubit>
    %113 = qco.rz(%arg40) %result_173 : !qco.qubit -> !qco.qubit
    %114 = qtensor.insert %113 into %out_tensor_172[%c0] : tensor<8x!qco.qubit>
    %out_tensor_174, %result_175 = qtensor.extract %114[%c1] : tensor<8x!qco.qubit>
    %115 = qco.rz(%arg41) %result_175 : !qco.qubit -> !qco.qubit
    %116 = qtensor.insert %115 into %out_tensor_174[%c1] : tensor<8x!qco.qubit>
    %out_tensor_176, %result_177 = qtensor.extract %116[%c2] : tensor<8x!qco.qubit>
    %117 = qco.rz(%arg42) %result_177 : !qco.qubit -> !qco.qubit
    %118 = qtensor.insert %117 into %out_tensor_176[%c2] : tensor<8x!qco.qubit>
    %out_tensor_178, %result_179 = qtensor.extract %118[%c3] : tensor<8x!qco.qubit>
    %119 = qco.rz(%arg43) %result_179 : !qco.qubit -> !qco.qubit
    %120 = qtensor.insert %119 into %out_tensor_178[%c3] : tensor<8x!qco.qubit>
    %out_tensor_180, %result_181 = qtensor.extract %120[%c4] : tensor<8x!qco.qubit>
    %121 = qco.rz(%arg44) %result_181 : !qco.qubit -> !qco.qubit
    %122 = qtensor.insert %121 into %out_tensor_180[%c4] : tensor<8x!qco.qubit>
    %out_tensor_182, %result_183 = qtensor.extract %122[%c5] : tensor<8x!qco.qubit>
    %123 = qco.rz(%arg45) %result_183 : !qco.qubit -> !qco.qubit
    %124 = qtensor.insert %123 into %out_tensor_182[%c5] : tensor<8x!qco.qubit>
    %out_tensor_184, %result_185 = qtensor.extract %124[%c6] : tensor<8x!qco.qubit>
    %125 = qco.rz(%arg46) %result_185 : !qco.qubit -> !qco.qubit
    %126 = qtensor.insert %125 into %out_tensor_184[%c6] : tensor<8x!qco.qubit>
    %out_tensor_186, %result_187 = qtensor.extract %126[%c7] : tensor<8x!qco.qubit>
    %127 = qco.rz(%arg47) %result_187 : !qco.qubit -> !qco.qubit
    %128 = qtensor.insert %127 into %out_tensor_186[%c7] : tensor<8x!qco.qubit>
    %out_tensor_188, %result_189 = qtensor.extract %128[%c7] : tensor<8x!qco.qubit>
    %out_tensor_190, %result_191 = qtensor.extract %out_tensor_188[%c0] : tensor<8x!qco.qubit>
    %controls_out_192, %targets_out_193 = qco.ctrl(%result_189) targets (%arg64 = %result_191) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %129 = qtensor.insert %targets_out_193 into %out_tensor_190[%c0] : tensor<8x!qco.qubit>
    %130 = qtensor.insert %controls_out_192 into %129[%c7] : tensor<8x!qco.qubit>
    %out_tensor_194, %result_195 = qtensor.extract %130[%c0] : tensor<8x!qco.qubit>
    %out_tensor_196, %result_197 = qtensor.extract %out_tensor_194[%c1] : tensor<8x!qco.qubit>
    %controls_out_198, %targets_out_199 = qco.ctrl(%result_195) targets (%arg64 = %result_197) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %131 = qtensor.insert %targets_out_199 into %out_tensor_196[%c1] : tensor<8x!qco.qubit>
    %132 = qtensor.insert %controls_out_198 into %131[%c0] : tensor<8x!qco.qubit>
    %out_tensor_200, %result_201 = qtensor.extract %132[%c1] : tensor<8x!qco.qubit>
    %out_tensor_202, %result_203 = qtensor.extract %out_tensor_200[%c2] : tensor<8x!qco.qubit>
    %controls_out_204, %targets_out_205 = qco.ctrl(%result_201) targets (%arg64 = %result_203) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %133 = qtensor.insert %targets_out_205 into %out_tensor_202[%c2] : tensor<8x!qco.qubit>
    %134 = qtensor.insert %controls_out_204 into %133[%c1] : tensor<8x!qco.qubit>
    %out_tensor_206, %result_207 = qtensor.extract %134[%c2] : tensor<8x!qco.qubit>
    %out_tensor_208, %result_209 = qtensor.extract %out_tensor_206[%c3] : tensor<8x!qco.qubit>
    %controls_out_210, %targets_out_211 = qco.ctrl(%result_207) targets (%arg64 = %result_209) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %135 = qtensor.insert %targets_out_211 into %out_tensor_208[%c3] : tensor<8x!qco.qubit>
    %136 = qtensor.insert %controls_out_210 into %135[%c2] : tensor<8x!qco.qubit>
    %out_tensor_212, %result_213 = qtensor.extract %136[%c3] : tensor<8x!qco.qubit>
    %out_tensor_214, %result_215 = qtensor.extract %out_tensor_212[%c4] : tensor<8x!qco.qubit>
    %controls_out_216, %targets_out_217 = qco.ctrl(%result_213) targets (%arg64 = %result_215) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %137 = qtensor.insert %targets_out_217 into %out_tensor_214[%c4] : tensor<8x!qco.qubit>
    %138 = qtensor.insert %controls_out_216 into %137[%c3] : tensor<8x!qco.qubit>
    %out_tensor_218, %result_219 = qtensor.extract %138[%c4] : tensor<8x!qco.qubit>
    %out_tensor_220, %result_221 = qtensor.extract %out_tensor_218[%c5] : tensor<8x!qco.qubit>
    %controls_out_222, %targets_out_223 = qco.ctrl(%result_219) targets (%arg64 = %result_221) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %139 = qtensor.insert %targets_out_223 into %out_tensor_220[%c5] : tensor<8x!qco.qubit>
    %140 = qtensor.insert %controls_out_222 into %139[%c4] : tensor<8x!qco.qubit>
    %out_tensor_224, %result_225 = qtensor.extract %140[%c5] : tensor<8x!qco.qubit>
    %out_tensor_226, %result_227 = qtensor.extract %out_tensor_224[%c6] : tensor<8x!qco.qubit>
    %controls_out_228, %targets_out_229 = qco.ctrl(%result_225) targets (%arg64 = %result_227) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %141 = qtensor.insert %targets_out_229 into %out_tensor_226[%c6] : tensor<8x!qco.qubit>
    %142 = qtensor.insert %controls_out_228 into %141[%c5] : tensor<8x!qco.qubit>
    %out_tensor_230, %result_231 = qtensor.extract %142[%c6] : tensor<8x!qco.qubit>
    %out_tensor_232, %result_233 = qtensor.extract %out_tensor_230[%c7] : tensor<8x!qco.qubit>
    %controls_out_234, %targets_out_235 = qco.ctrl(%result_231) targets (%arg64 = %result_233) {
      %177 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %177 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %143 = qtensor.insert %targets_out_235 into %out_tensor_232[%c7] : tensor<8x!qco.qubit>
    %144 = qtensor.insert %controls_out_234 into %143[%c6] : tensor<8x!qco.qubit>
    %out_tensor_236, %result_237 = qtensor.extract %144[%c0] : tensor<8x!qco.qubit>
    %145 = qco.ry(%arg48) %result_237 : !qco.qubit -> !qco.qubit
    %146 = qtensor.insert %145 into %out_tensor_236[%c0] : tensor<8x!qco.qubit>
    %out_tensor_238, %result_239 = qtensor.extract %146[%c1] : tensor<8x!qco.qubit>
    %147 = qco.ry(%arg49) %result_239 : !qco.qubit -> !qco.qubit
    %148 = qtensor.insert %147 into %out_tensor_238[%c1] : tensor<8x!qco.qubit>
    %out_tensor_240, %result_241 = qtensor.extract %148[%c2] : tensor<8x!qco.qubit>
    %149 = qco.ry(%arg50) %result_241 : !qco.qubit -> !qco.qubit
    %150 = qtensor.insert %149 into %out_tensor_240[%c2] : tensor<8x!qco.qubit>
    %out_tensor_242, %result_243 = qtensor.extract %150[%c3] : tensor<8x!qco.qubit>
    %151 = qco.ry(%arg51) %result_243 : !qco.qubit -> !qco.qubit
    %152 = qtensor.insert %151 into %out_tensor_242[%c3] : tensor<8x!qco.qubit>
    %out_tensor_244, %result_245 = qtensor.extract %152[%c4] : tensor<8x!qco.qubit>
    %153 = qco.ry(%arg52) %result_245 : !qco.qubit -> !qco.qubit
    %154 = qtensor.insert %153 into %out_tensor_244[%c4] : tensor<8x!qco.qubit>
    %out_tensor_246, %result_247 = qtensor.extract %154[%c5] : tensor<8x!qco.qubit>
    %155 = qco.ry(%arg53) %result_247 : !qco.qubit -> !qco.qubit
    %156 = qtensor.insert %155 into %out_tensor_246[%c5] : tensor<8x!qco.qubit>
    %out_tensor_248, %result_249 = qtensor.extract %156[%c6] : tensor<8x!qco.qubit>
    %157 = qco.ry(%arg54) %result_249 : !qco.qubit -> !qco.qubit
    %158 = qtensor.insert %157 into %out_tensor_248[%c6] : tensor<8x!qco.qubit>
    %out_tensor_250, %result_251 = qtensor.extract %158[%c7] : tensor<8x!qco.qubit>
    %159 = qco.ry(%arg55) %result_251 : !qco.qubit -> !qco.qubit
    %160 = qtensor.insert %159 into %out_tensor_250[%c7] : tensor<8x!qco.qubit>
    %out_tensor_252, %result_253 = qtensor.extract %160[%c0] : tensor<8x!qco.qubit>
    %161 = qco.rz(%arg56) %result_253 : !qco.qubit -> !qco.qubit
    %162 = qtensor.insert %161 into %out_tensor_252[%c0] : tensor<8x!qco.qubit>
    %out_tensor_254, %result_255 = qtensor.extract %162[%c1] : tensor<8x!qco.qubit>
    %163 = qco.rz(%arg57) %result_255 : !qco.qubit -> !qco.qubit
    %164 = qtensor.insert %163 into %out_tensor_254[%c1] : tensor<8x!qco.qubit>
    %out_tensor_256, %result_257 = qtensor.extract %164[%c2] : tensor<8x!qco.qubit>
    %165 = qco.rz(%arg58) %result_257 : !qco.qubit -> !qco.qubit
    %166 = qtensor.insert %165 into %out_tensor_256[%c2] : tensor<8x!qco.qubit>
    %out_tensor_258, %result_259 = qtensor.extract %166[%c3] : tensor<8x!qco.qubit>
    %167 = qco.rz(%arg59) %result_259 : !qco.qubit -> !qco.qubit
    %168 = qtensor.insert %167 into %out_tensor_258[%c3] : tensor<8x!qco.qubit>
    %out_tensor_260, %result_261 = qtensor.extract %168[%c4] : tensor<8x!qco.qubit>
    %169 = qco.rz(%arg60) %result_261 : !qco.qubit -> !qco.qubit
    %170 = qtensor.insert %169 into %out_tensor_260[%c4] : tensor<8x!qco.qubit>
    %out_tensor_262, %result_263 = qtensor.extract %170[%c5] : tensor<8x!qco.qubit>
    %171 = qco.rz(%arg61) %result_263 : !qco.qubit -> !qco.qubit
    %172 = qtensor.insert %171 into %out_tensor_262[%c5] : tensor<8x!qco.qubit>
    %out_tensor_264, %result_265 = qtensor.extract %172[%c6] : tensor<8x!qco.qubit>
    %173 = qco.rz(%arg62) %result_265 : !qco.qubit -> !qco.qubit
    %174 = qtensor.insert %173 into %out_tensor_264[%c6] : tensor<8x!qco.qubit>
    %out_tensor_266, %result_267 = qtensor.extract %174[%c7] : tensor<8x!qco.qubit>
    %175 = qco.rz(%arg63) %result_267 : !qco.qubit -> !qco.qubit
    %176 = qtensor.insert %175 into %out_tensor_266[%c7] : tensor<8x!qco.qubit>
    qtensor.dealloc %176 : tensor<8x!qco.qubit>
    return %c0_i64 : i64
  }
}
