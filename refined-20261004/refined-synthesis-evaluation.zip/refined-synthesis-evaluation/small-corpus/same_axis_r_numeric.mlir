module {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %c0_i64 = arith.constant 0 : i64
    %cst = arith.constant 3.700000e-01 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant 0.000000e+00 : f64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %0 = qtensor.alloc(%c2) {mqt.register_name = "q"} : tensor<2x!qco.qubit>
    qco.gphase(%cst_1)
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<2x!qco.qubit>
    %1 = qco.r(%cst_0, %cst) %result : !qco.qubit -> !qco.qubit
    %2 = qtensor.insert %1 into %out_tensor[%c0] : tensor<2x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %2[%c0] : tensor<2x!qco.qubit>
    %3 = qco.r(%cst_0, %cst) %result_3 : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor_2[%c0] : tensor<2x!qco.qubit>
    qtensor.dealloc %4 : tensor<2x!qco.qubit>
    return %c0_i64 : i64
  }
}
