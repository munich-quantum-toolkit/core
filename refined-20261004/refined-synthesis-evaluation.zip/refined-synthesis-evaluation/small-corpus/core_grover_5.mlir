module {
  func.func @main() -> !cbit.reg<5> attributes {mqt.entry_point} {
    %c5 = arith.constant 5 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %0 = qtensor.alloc(%c5) {mqt.register_name = "q"} : tensor<5x!qco.qubit>
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<5>
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<5x!qco.qubit>
    %2 = qco.h %result : !qco.qubit -> !qco.qubit
    %3 = qtensor.insert %2 into %out_tensor[%c0] : tensor<5x!qco.qubit>
    %out_tensor_0, %result_1 = qtensor.extract %3[%c1] : tensor<5x!qco.qubit>
    %4 = qco.h %result_1 : !qco.qubit -> !qco.qubit
    %5 = qtensor.insert %4 into %out_tensor_0[%c1] : tensor<5x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %5[%c2] : tensor<5x!qco.qubit>
    %6 = qco.h %result_3 : !qco.qubit -> !qco.qubit
    %7 = qtensor.insert %6 into %out_tensor_2[%c2] : tensor<5x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %7[%c3] : tensor<5x!qco.qubit>
    %8 = qco.h %result_5 : !qco.qubit -> !qco.qubit
    %9 = qtensor.insert %8 into %out_tensor_4[%c3] : tensor<5x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %9[%c4] : tensor<5x!qco.qubit>
    %10 = qco.h %result_7 : !qco.qubit -> !qco.qubit
    %11 = qtensor.insert %10 into %out_tensor_6[%c4] : tensor<5x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %11[%c1] : tensor<5x!qco.qubit>
    %12 = qco.x %result_9 : !qco.qubit -> !qco.qubit
    %13 = qtensor.insert %12 into %out_tensor_8[%c1] : tensor<5x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %13[%c3] : tensor<5x!qco.qubit>
    %14 = qco.x %result_11 : !qco.qubit -> !qco.qubit
    %15 = qtensor.insert %14 into %out_tensor_10[%c3] : tensor<5x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %15[%c0] : tensor<5x!qco.qubit>
    %out_tensor_14, %result_15 = qtensor.extract %out_tensor_12[%c1] : tensor<5x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %out_tensor_14[%c2] : tensor<5x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %out_tensor_16[%c3] : tensor<5x!qco.qubit>
    %out_tensor_20, %result_21 = qtensor.extract %out_tensor_18[%c4] : tensor<5x!qco.qubit>
    %controls_out:4, %targets_out = qco.ctrl(%result_13, %result_15, %result_17, %result_19) targets (%arg0 = %result_21) {
      %133 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %133 : !qco.qubit
    } : ({!qco.qubit, !qco.qubit, !qco.qubit, !qco.qubit}, {!qco.qubit}) -> ({!qco.qubit, !qco.qubit, !qco.qubit, !qco.qubit}, {!qco.qubit})
    %16 = qtensor.insert %targets_out into %out_tensor_20[%c4] : tensor<5x!qco.qubit>
    %17 = qtensor.insert %controls_out#3 into %16[%c3] : tensor<5x!qco.qubit>
    %18 = qtensor.insert %controls_out#2 into %17[%c2] : tensor<5x!qco.qubit>
    %19 = qtensor.insert %controls_out#1 into %18[%c1] : tensor<5x!qco.qubit>
    %20 = qtensor.insert %controls_out#0 into %19[%c0] : tensor<5x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %20[%c1] : tensor<5x!qco.qubit>
    %21 = qco.x %result_23 : !qco.qubit -> !qco.qubit
    %22 = qtensor.insert %21 into %out_tensor_22[%c1] : tensor<5x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %22[%c3] : tensor<5x!qco.qubit>
    %23 = qco.x %result_25 : !qco.qubit -> !qco.qubit
    %24 = qtensor.insert %23 into %out_tensor_24[%c3] : tensor<5x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %24[%c0] : tensor<5x!qco.qubit>
    %25 = qco.h %result_27 : !qco.qubit -> !qco.qubit
    %26 = qtensor.insert %25 into %out_tensor_26[%c0] : tensor<5x!qco.qubit>
    %out_tensor_28, %result_29 = qtensor.extract %26[%c1] : tensor<5x!qco.qubit>
    %27 = qco.h %result_29 : !qco.qubit -> !qco.qubit
    %28 = qtensor.insert %27 into %out_tensor_28[%c1] : tensor<5x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %28[%c2] : tensor<5x!qco.qubit>
    %29 = qco.h %result_31 : !qco.qubit -> !qco.qubit
    %30 = qtensor.insert %29 into %out_tensor_30[%c2] : tensor<5x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %30[%c3] : tensor<5x!qco.qubit>
    %31 = qco.h %result_33 : !qco.qubit -> !qco.qubit
    %32 = qtensor.insert %31 into %out_tensor_32[%c3] : tensor<5x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %32[%c4] : tensor<5x!qco.qubit>
    %33 = qco.h %result_35 : !qco.qubit -> !qco.qubit
    %34 = qtensor.insert %33 into %out_tensor_34[%c4] : tensor<5x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %34[%c0] : tensor<5x!qco.qubit>
    %35 = qco.x %result_37 : !qco.qubit -> !qco.qubit
    %36 = qtensor.insert %35 into %out_tensor_36[%c0] : tensor<5x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %36[%c1] : tensor<5x!qco.qubit>
    %37 = qco.x %result_39 : !qco.qubit -> !qco.qubit
    %38 = qtensor.insert %37 into %out_tensor_38[%c1] : tensor<5x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %38[%c2] : tensor<5x!qco.qubit>
    %39 = qco.x %result_41 : !qco.qubit -> !qco.qubit
    %40 = qtensor.insert %39 into %out_tensor_40[%c2] : tensor<5x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %40[%c3] : tensor<5x!qco.qubit>
    %41 = qco.x %result_43 : !qco.qubit -> !qco.qubit
    %42 = qtensor.insert %41 into %out_tensor_42[%c3] : tensor<5x!qco.qubit>
    %out_tensor_44, %result_45 = qtensor.extract %42[%c4] : tensor<5x!qco.qubit>
    %43 = qco.x %result_45 : !qco.qubit -> !qco.qubit
    %44 = qtensor.insert %43 into %out_tensor_44[%c4] : tensor<5x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %44[%c0] : tensor<5x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %out_tensor_46[%c1] : tensor<5x!qco.qubit>
    %out_tensor_50, %result_51 = qtensor.extract %out_tensor_48[%c2] : tensor<5x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %out_tensor_50[%c3] : tensor<5x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %out_tensor_52[%c4] : tensor<5x!qco.qubit>
    %controls_out_56:4, %targets_out_57 = qco.ctrl(%result_47, %result_49, %result_51, %result_53) targets (%arg0 = %result_55) {
      %133 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %133 : !qco.qubit
    } : ({!qco.qubit, !qco.qubit, !qco.qubit, !qco.qubit}, {!qco.qubit}) -> ({!qco.qubit, !qco.qubit, !qco.qubit, !qco.qubit}, {!qco.qubit})
    %45 = qtensor.insert %targets_out_57 into %out_tensor_54[%c4] : tensor<5x!qco.qubit>
    %46 = qtensor.insert %controls_out_56#3 into %45[%c3] : tensor<5x!qco.qubit>
    %47 = qtensor.insert %controls_out_56#2 into %46[%c2] : tensor<5x!qco.qubit>
    %48 = qtensor.insert %controls_out_56#1 into %47[%c1] : tensor<5x!qco.qubit>
    %49 = qtensor.insert %controls_out_56#0 into %48[%c0] : tensor<5x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %49[%c0] : tensor<5x!qco.qubit>
    %50 = qco.x %result_59 : !qco.qubit -> !qco.qubit
    %51 = qtensor.insert %50 into %out_tensor_58[%c0] : tensor<5x!qco.qubit>
    %out_tensor_60, %result_61 = qtensor.extract %51[%c1] : tensor<5x!qco.qubit>
    %52 = qco.x %result_61 : !qco.qubit -> !qco.qubit
    %53 = qtensor.insert %52 into %out_tensor_60[%c1] : tensor<5x!qco.qubit>
    %out_tensor_62, %result_63 = qtensor.extract %53[%c2] : tensor<5x!qco.qubit>
    %54 = qco.x %result_63 : !qco.qubit -> !qco.qubit
    %55 = qtensor.insert %54 into %out_tensor_62[%c2] : tensor<5x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %55[%c3] : tensor<5x!qco.qubit>
    %56 = qco.x %result_65 : !qco.qubit -> !qco.qubit
    %57 = qtensor.insert %56 into %out_tensor_64[%c3] : tensor<5x!qco.qubit>
    %out_tensor_66, %result_67 = qtensor.extract %57[%c4] : tensor<5x!qco.qubit>
    %58 = qco.x %result_67 : !qco.qubit -> !qco.qubit
    %59 = qtensor.insert %58 into %out_tensor_66[%c4] : tensor<5x!qco.qubit>
    %out_tensor_68, %result_69 = qtensor.extract %59[%c0] : tensor<5x!qco.qubit>
    %60 = qco.h %result_69 : !qco.qubit -> !qco.qubit
    %61 = qtensor.insert %60 into %out_tensor_68[%c0] : tensor<5x!qco.qubit>
    %out_tensor_70, %result_71 = qtensor.extract %61[%c1] : tensor<5x!qco.qubit>
    %62 = qco.h %result_71 : !qco.qubit -> !qco.qubit
    %63 = qtensor.insert %62 into %out_tensor_70[%c1] : tensor<5x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %63[%c2] : tensor<5x!qco.qubit>
    %64 = qco.h %result_73 : !qco.qubit -> !qco.qubit
    %65 = qtensor.insert %64 into %out_tensor_72[%c2] : tensor<5x!qco.qubit>
    %out_tensor_74, %result_75 = qtensor.extract %65[%c3] : tensor<5x!qco.qubit>
    %66 = qco.h %result_75 : !qco.qubit -> !qco.qubit
    %67 = qtensor.insert %66 into %out_tensor_74[%c3] : tensor<5x!qco.qubit>
    %out_tensor_76, %result_77 = qtensor.extract %67[%c4] : tensor<5x!qco.qubit>
    %68 = qco.h %result_77 : !qco.qubit -> !qco.qubit
    %69 = qtensor.insert %68 into %out_tensor_76[%c4] : tensor<5x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %69[%c1] : tensor<5x!qco.qubit>
    %70 = qco.x %result_79 : !qco.qubit -> !qco.qubit
    %71 = qtensor.insert %70 into %out_tensor_78[%c1] : tensor<5x!qco.qubit>
    %out_tensor_80, %result_81 = qtensor.extract %71[%c3] : tensor<5x!qco.qubit>
    %72 = qco.x %result_81 : !qco.qubit -> !qco.qubit
    %73 = qtensor.insert %72 into %out_tensor_80[%c3] : tensor<5x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %73[%c0] : tensor<5x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %out_tensor_82[%c1] : tensor<5x!qco.qubit>
    %out_tensor_86, %result_87 = qtensor.extract %out_tensor_84[%c2] : tensor<5x!qco.qubit>
    %out_tensor_88, %result_89 = qtensor.extract %out_tensor_86[%c3] : tensor<5x!qco.qubit>
    %out_tensor_90, %result_91 = qtensor.extract %out_tensor_88[%c4] : tensor<5x!qco.qubit>
    %controls_out_92:4, %targets_out_93 = qco.ctrl(%result_83, %result_85, %result_87, %result_89) targets (%arg0 = %result_91) {
      %133 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %133 : !qco.qubit
    } : ({!qco.qubit, !qco.qubit, !qco.qubit, !qco.qubit}, {!qco.qubit}) -> ({!qco.qubit, !qco.qubit, !qco.qubit, !qco.qubit}, {!qco.qubit})
    %74 = qtensor.insert %targets_out_93 into %out_tensor_90[%c4] : tensor<5x!qco.qubit>
    %75 = qtensor.insert %controls_out_92#3 into %74[%c3] : tensor<5x!qco.qubit>
    %76 = qtensor.insert %controls_out_92#2 into %75[%c2] : tensor<5x!qco.qubit>
    %77 = qtensor.insert %controls_out_92#1 into %76[%c1] : tensor<5x!qco.qubit>
    %78 = qtensor.insert %controls_out_92#0 into %77[%c0] : tensor<5x!qco.qubit>
    %out_tensor_94, %result_95 = qtensor.extract %78[%c1] : tensor<5x!qco.qubit>
    %79 = qco.x %result_95 : !qco.qubit -> !qco.qubit
    %80 = qtensor.insert %79 into %out_tensor_94[%c1] : tensor<5x!qco.qubit>
    %out_tensor_96, %result_97 = qtensor.extract %80[%c3] : tensor<5x!qco.qubit>
    %81 = qco.x %result_97 : !qco.qubit -> !qco.qubit
    %82 = qtensor.insert %81 into %out_tensor_96[%c3] : tensor<5x!qco.qubit>
    %out_tensor_98, %result_99 = qtensor.extract %82[%c0] : tensor<5x!qco.qubit>
    %83 = qco.h %result_99 : !qco.qubit -> !qco.qubit
    %84 = qtensor.insert %83 into %out_tensor_98[%c0] : tensor<5x!qco.qubit>
    %out_tensor_100, %result_101 = qtensor.extract %84[%c1] : tensor<5x!qco.qubit>
    %85 = qco.h %result_101 : !qco.qubit -> !qco.qubit
    %86 = qtensor.insert %85 into %out_tensor_100[%c1] : tensor<5x!qco.qubit>
    %out_tensor_102, %result_103 = qtensor.extract %86[%c2] : tensor<5x!qco.qubit>
    %87 = qco.h %result_103 : !qco.qubit -> !qco.qubit
    %88 = qtensor.insert %87 into %out_tensor_102[%c2] : tensor<5x!qco.qubit>
    %out_tensor_104, %result_105 = qtensor.extract %88[%c3] : tensor<5x!qco.qubit>
    %89 = qco.h %result_105 : !qco.qubit -> !qco.qubit
    %90 = qtensor.insert %89 into %out_tensor_104[%c3] : tensor<5x!qco.qubit>
    %out_tensor_106, %result_107 = qtensor.extract %90[%c4] : tensor<5x!qco.qubit>
    %91 = qco.h %result_107 : !qco.qubit -> !qco.qubit
    %92 = qtensor.insert %91 into %out_tensor_106[%c4] : tensor<5x!qco.qubit>
    %out_tensor_108, %result_109 = qtensor.extract %92[%c0] : tensor<5x!qco.qubit>
    %93 = qco.x %result_109 : !qco.qubit -> !qco.qubit
    %94 = qtensor.insert %93 into %out_tensor_108[%c0] : tensor<5x!qco.qubit>
    %out_tensor_110, %result_111 = qtensor.extract %94[%c1] : tensor<5x!qco.qubit>
    %95 = qco.x %result_111 : !qco.qubit -> !qco.qubit
    %96 = qtensor.insert %95 into %out_tensor_110[%c1] : tensor<5x!qco.qubit>
    %out_tensor_112, %result_113 = qtensor.extract %96[%c2] : tensor<5x!qco.qubit>
    %97 = qco.x %result_113 : !qco.qubit -> !qco.qubit
    %98 = qtensor.insert %97 into %out_tensor_112[%c2] : tensor<5x!qco.qubit>
    %out_tensor_114, %result_115 = qtensor.extract %98[%c3] : tensor<5x!qco.qubit>
    %99 = qco.x %result_115 : !qco.qubit -> !qco.qubit
    %100 = qtensor.insert %99 into %out_tensor_114[%c3] : tensor<5x!qco.qubit>
    %out_tensor_116, %result_117 = qtensor.extract %100[%c4] : tensor<5x!qco.qubit>
    %101 = qco.x %result_117 : !qco.qubit -> !qco.qubit
    %102 = qtensor.insert %101 into %out_tensor_116[%c4] : tensor<5x!qco.qubit>
    %out_tensor_118, %result_119 = qtensor.extract %102[%c0] : tensor<5x!qco.qubit>
    %out_tensor_120, %result_121 = qtensor.extract %out_tensor_118[%c1] : tensor<5x!qco.qubit>
    %out_tensor_122, %result_123 = qtensor.extract %out_tensor_120[%c2] : tensor<5x!qco.qubit>
    %out_tensor_124, %result_125 = qtensor.extract %out_tensor_122[%c3] : tensor<5x!qco.qubit>
    %out_tensor_126, %result_127 = qtensor.extract %out_tensor_124[%c4] : tensor<5x!qco.qubit>
    %controls_out_128:4, %targets_out_129 = qco.ctrl(%result_119, %result_121, %result_123, %result_125) targets (%arg0 = %result_127) {
      %133 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %133 : !qco.qubit
    } : ({!qco.qubit, !qco.qubit, !qco.qubit, !qco.qubit}, {!qco.qubit}) -> ({!qco.qubit, !qco.qubit, !qco.qubit, !qco.qubit}, {!qco.qubit})
    %103 = qtensor.insert %targets_out_129 into %out_tensor_126[%c4] : tensor<5x!qco.qubit>
    %104 = qtensor.insert %controls_out_128#3 into %103[%c3] : tensor<5x!qco.qubit>
    %105 = qtensor.insert %controls_out_128#2 into %104[%c2] : tensor<5x!qco.qubit>
    %106 = qtensor.insert %controls_out_128#1 into %105[%c1] : tensor<5x!qco.qubit>
    %107 = qtensor.insert %controls_out_128#0 into %106[%c0] : tensor<5x!qco.qubit>
    %out_tensor_130, %result_131 = qtensor.extract %107[%c0] : tensor<5x!qco.qubit>
    %108 = qco.x %result_131 : !qco.qubit -> !qco.qubit
    %109 = qtensor.insert %108 into %out_tensor_130[%c0] : tensor<5x!qco.qubit>
    %out_tensor_132, %result_133 = qtensor.extract %109[%c1] : tensor<5x!qco.qubit>
    %110 = qco.x %result_133 : !qco.qubit -> !qco.qubit
    %111 = qtensor.insert %110 into %out_tensor_132[%c1] : tensor<5x!qco.qubit>
    %out_tensor_134, %result_135 = qtensor.extract %111[%c2] : tensor<5x!qco.qubit>
    %112 = qco.x %result_135 : !qco.qubit -> !qco.qubit
    %113 = qtensor.insert %112 into %out_tensor_134[%c2] : tensor<5x!qco.qubit>
    %out_tensor_136, %result_137 = qtensor.extract %113[%c3] : tensor<5x!qco.qubit>
    %114 = qco.x %result_137 : !qco.qubit -> !qco.qubit
    %115 = qtensor.insert %114 into %out_tensor_136[%c3] : tensor<5x!qco.qubit>
    %out_tensor_138, %result_139 = qtensor.extract %115[%c4] : tensor<5x!qco.qubit>
    %116 = qco.x %result_139 : !qco.qubit -> !qco.qubit
    %117 = qtensor.insert %116 into %out_tensor_138[%c4] : tensor<5x!qco.qubit>
    %out_tensor_140, %result_141 = qtensor.extract %117[%c0] : tensor<5x!qco.qubit>
    %118 = qco.h %result_141 : !qco.qubit -> !qco.qubit
    %119 = qtensor.insert %118 into %out_tensor_140[%c0] : tensor<5x!qco.qubit>
    %out_tensor_142, %result_143 = qtensor.extract %119[%c1] : tensor<5x!qco.qubit>
    %120 = qco.h %result_143 : !qco.qubit -> !qco.qubit
    %121 = qtensor.insert %120 into %out_tensor_142[%c1] : tensor<5x!qco.qubit>
    %out_tensor_144, %result_145 = qtensor.extract %121[%c2] : tensor<5x!qco.qubit>
    %122 = qco.h %result_145 : !qco.qubit -> !qco.qubit
    %123 = qtensor.insert %122 into %out_tensor_144[%c2] : tensor<5x!qco.qubit>
    %out_tensor_146, %result_147 = qtensor.extract %123[%c3] : tensor<5x!qco.qubit>
    %124 = qco.h %result_147 : !qco.qubit -> !qco.qubit
    %125 = qtensor.insert %124 into %out_tensor_146[%c3] : tensor<5x!qco.qubit>
    %out_tensor_148, %result_149 = qtensor.extract %125[%c4] : tensor<5x!qco.qubit>
    %126 = qco.h %result_149 : !qco.qubit -> !qco.qubit
    %127 = qtensor.insert %126 into %out_tensor_148[%c4] : tensor<5x!qco.qubit>
    %out_tensor_150, %result_151 = qtensor.extract %127[%c0] : tensor<5x!qco.qubit>
    %qubit_out, %result_152 = qco.measure %result_151 : !qco.qubit
    %128 = qtensor.insert %qubit_out into %out_tensor_150[%c0] : tensor<5x!qco.qubit>
    cbit.store %result_152, %1[%c0] : !cbit.reg<5>
    %out_tensor_153, %result_154 = qtensor.extract %128[%c1] : tensor<5x!qco.qubit>
    %qubit_out_155, %result_156 = qco.measure %result_154 : !qco.qubit
    %129 = qtensor.insert %qubit_out_155 into %out_tensor_153[%c1] : tensor<5x!qco.qubit>
    cbit.store %result_156, %1[%c1] : !cbit.reg<5>
    %out_tensor_157, %result_158 = qtensor.extract %129[%c2] : tensor<5x!qco.qubit>
    %qubit_out_159, %result_160 = qco.measure %result_158 : !qco.qubit
    %130 = qtensor.insert %qubit_out_159 into %out_tensor_157[%c2] : tensor<5x!qco.qubit>
    cbit.store %result_160, %1[%c2] : !cbit.reg<5>
    %out_tensor_161, %result_162 = qtensor.extract %130[%c3] : tensor<5x!qco.qubit>
    %qubit_out_163, %result_164 = qco.measure %result_162 : !qco.qubit
    %131 = qtensor.insert %qubit_out_163 into %out_tensor_161[%c3] : tensor<5x!qco.qubit>
    cbit.store %result_164, %1[%c3] : !cbit.reg<5>
    %out_tensor_165, %result_166 = qtensor.extract %131[%c4] : tensor<5x!qco.qubit>
    %qubit_out_167, %result_168 = qco.measure %result_166 : !qco.qubit
    %132 = qtensor.insert %qubit_out_167 into %out_tensor_165[%c4] : tensor<5x!qco.qubit>
    cbit.store %result_168, %1[%c4] : !cbit.reg<5>
    qtensor.dealloc %132 : tensor<5x!qco.qubit>
    return %1 : !cbit.reg<5>
  }
}
