module {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %0 = qtensor.alloc(%c3) {mqt.register_name = "q"} : tensor<3x!qco.qubit>
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<3x!qco.qubit>
    %2 = qco.h %result : !qco.qubit -> !qco.qubit
    %3 = qtensor.insert %2 into %out_tensor[%c0] : tensor<3x!qco.qubit>
    %out_tensor_0, %result_1 = qtensor.extract %3[%c1] : tensor<3x!qco.qubit>
    %4 = qco.h %result_1 : !qco.qubit -> !qco.qubit
    %5 = qtensor.insert %4 into %out_tensor_0[%c1] : tensor<3x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %5[%c2] : tensor<3x!qco.qubit>
    %6 = qco.h %result_3 : !qco.qubit -> !qco.qubit
    %7 = qtensor.insert %6 into %out_tensor_2[%c2] : tensor<3x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %7[%c1] : tensor<3x!qco.qubit>
    %8 = qco.x %result_5 : !qco.qubit -> !qco.qubit
    %9 = qtensor.insert %8 into %out_tensor_4[%c1] : tensor<3x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %9[%c0] : tensor<3x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %out_tensor_6[%c1] : tensor<3x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %out_tensor_8[%c2] : tensor<3x!qco.qubit>
    %controls_out:2, %targets_out = qco.ctrl(%result_7, %result_9) targets (%arg0 = %result_11) {
      %79 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit, !qco.qubit}, {!qco.qubit}) -> ({!qco.qubit, !qco.qubit}, {!qco.qubit})
    %10 = qtensor.insert %targets_out into %out_tensor_10[%c2] : tensor<3x!qco.qubit>
    %11 = qtensor.insert %controls_out#1 into %10[%c1] : tensor<3x!qco.qubit>
    %12 = qtensor.insert %controls_out#0 into %11[%c0] : tensor<3x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %12[%c1] : tensor<3x!qco.qubit>
    %13 = qco.x %result_13 : !qco.qubit -> !qco.qubit
    %14 = qtensor.insert %13 into %out_tensor_12[%c1] : tensor<3x!qco.qubit>
    %out_tensor_14, %result_15 = qtensor.extract %14[%c0] : tensor<3x!qco.qubit>
    %15 = qco.h %result_15 : !qco.qubit -> !qco.qubit
    %16 = qtensor.insert %15 into %out_tensor_14[%c0] : tensor<3x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %16[%c1] : tensor<3x!qco.qubit>
    %17 = qco.h %result_17 : !qco.qubit -> !qco.qubit
    %18 = qtensor.insert %17 into %out_tensor_16[%c1] : tensor<3x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %18[%c2] : tensor<3x!qco.qubit>
    %19 = qco.h %result_19 : !qco.qubit -> !qco.qubit
    %20 = qtensor.insert %19 into %out_tensor_18[%c2] : tensor<3x!qco.qubit>
    %out_tensor_20, %result_21 = qtensor.extract %20[%c0] : tensor<3x!qco.qubit>
    %21 = qco.x %result_21 : !qco.qubit -> !qco.qubit
    %22 = qtensor.insert %21 into %out_tensor_20[%c0] : tensor<3x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %22[%c1] : tensor<3x!qco.qubit>
    %23 = qco.x %result_23 : !qco.qubit -> !qco.qubit
    %24 = qtensor.insert %23 into %out_tensor_22[%c1] : tensor<3x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %24[%c2] : tensor<3x!qco.qubit>
    %25 = qco.x %result_25 : !qco.qubit -> !qco.qubit
    %26 = qtensor.insert %25 into %out_tensor_24[%c2] : tensor<3x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %26[%c0] : tensor<3x!qco.qubit>
    %out_tensor_28, %result_29 = qtensor.extract %out_tensor_26[%c1] : tensor<3x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %out_tensor_28[%c2] : tensor<3x!qco.qubit>
    %controls_out_32:2, %targets_out_33 = qco.ctrl(%result_27, %result_29) targets (%arg0 = %result_31) {
      %79 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit, !qco.qubit}, {!qco.qubit}) -> ({!qco.qubit, !qco.qubit}, {!qco.qubit})
    %27 = qtensor.insert %targets_out_33 into %out_tensor_30[%c2] : tensor<3x!qco.qubit>
    %28 = qtensor.insert %controls_out_32#1 into %27[%c1] : tensor<3x!qco.qubit>
    %29 = qtensor.insert %controls_out_32#0 into %28[%c0] : tensor<3x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %29[%c0] : tensor<3x!qco.qubit>
    %30 = qco.x %result_35 : !qco.qubit -> !qco.qubit
    %31 = qtensor.insert %30 into %out_tensor_34[%c0] : tensor<3x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %31[%c1] : tensor<3x!qco.qubit>
    %32 = qco.x %result_37 : !qco.qubit -> !qco.qubit
    %33 = qtensor.insert %32 into %out_tensor_36[%c1] : tensor<3x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %33[%c2] : tensor<3x!qco.qubit>
    %34 = qco.x %result_39 : !qco.qubit -> !qco.qubit
    %35 = qtensor.insert %34 into %out_tensor_38[%c2] : tensor<3x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %35[%c0] : tensor<3x!qco.qubit>
    %36 = qco.h %result_41 : !qco.qubit -> !qco.qubit
    %37 = qtensor.insert %36 into %out_tensor_40[%c0] : tensor<3x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %37[%c1] : tensor<3x!qco.qubit>
    %38 = qco.h %result_43 : !qco.qubit -> !qco.qubit
    %39 = qtensor.insert %38 into %out_tensor_42[%c1] : tensor<3x!qco.qubit>
    %out_tensor_44, %result_45 = qtensor.extract %39[%c2] : tensor<3x!qco.qubit>
    %40 = qco.h %result_45 : !qco.qubit -> !qco.qubit
    %41 = qtensor.insert %40 into %out_tensor_44[%c2] : tensor<3x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %41[%c1] : tensor<3x!qco.qubit>
    %42 = qco.x %result_47 : !qco.qubit -> !qco.qubit
    %43 = qtensor.insert %42 into %out_tensor_46[%c1] : tensor<3x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %43[%c0] : tensor<3x!qco.qubit>
    %out_tensor_50, %result_51 = qtensor.extract %out_tensor_48[%c1] : tensor<3x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %out_tensor_50[%c2] : tensor<3x!qco.qubit>
    %controls_out_54:2, %targets_out_55 = qco.ctrl(%result_49, %result_51) targets (%arg0 = %result_53) {
      %79 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit, !qco.qubit}, {!qco.qubit}) -> ({!qco.qubit, !qco.qubit}, {!qco.qubit})
    %44 = qtensor.insert %targets_out_55 into %out_tensor_52[%c2] : tensor<3x!qco.qubit>
    %45 = qtensor.insert %controls_out_54#1 into %44[%c1] : tensor<3x!qco.qubit>
    %46 = qtensor.insert %controls_out_54#0 into %45[%c0] : tensor<3x!qco.qubit>
    %out_tensor_56, %result_57 = qtensor.extract %46[%c1] : tensor<3x!qco.qubit>
    %47 = qco.x %result_57 : !qco.qubit -> !qco.qubit
    %48 = qtensor.insert %47 into %out_tensor_56[%c1] : tensor<3x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %48[%c0] : tensor<3x!qco.qubit>
    %49 = qco.h %result_59 : !qco.qubit -> !qco.qubit
    %50 = qtensor.insert %49 into %out_tensor_58[%c0] : tensor<3x!qco.qubit>
    %out_tensor_60, %result_61 = qtensor.extract %50[%c1] : tensor<3x!qco.qubit>
    %51 = qco.h %result_61 : !qco.qubit -> !qco.qubit
    %52 = qtensor.insert %51 into %out_tensor_60[%c1] : tensor<3x!qco.qubit>
    %out_tensor_62, %result_63 = qtensor.extract %52[%c2] : tensor<3x!qco.qubit>
    %53 = qco.h %result_63 : !qco.qubit -> !qco.qubit
    %54 = qtensor.insert %53 into %out_tensor_62[%c2] : tensor<3x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %54[%c0] : tensor<3x!qco.qubit>
    %55 = qco.x %result_65 : !qco.qubit -> !qco.qubit
    %56 = qtensor.insert %55 into %out_tensor_64[%c0] : tensor<3x!qco.qubit>
    %out_tensor_66, %result_67 = qtensor.extract %56[%c1] : tensor<3x!qco.qubit>
    %57 = qco.x %result_67 : !qco.qubit -> !qco.qubit
    %58 = qtensor.insert %57 into %out_tensor_66[%c1] : tensor<3x!qco.qubit>
    %out_tensor_68, %result_69 = qtensor.extract %58[%c2] : tensor<3x!qco.qubit>
    %59 = qco.x %result_69 : !qco.qubit -> !qco.qubit
    %60 = qtensor.insert %59 into %out_tensor_68[%c2] : tensor<3x!qco.qubit>
    %out_tensor_70, %result_71 = qtensor.extract %60[%c0] : tensor<3x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %out_tensor_70[%c1] : tensor<3x!qco.qubit>
    %out_tensor_74, %result_75 = qtensor.extract %out_tensor_72[%c2] : tensor<3x!qco.qubit>
    %controls_out_76:2, %targets_out_77 = qco.ctrl(%result_71, %result_73) targets (%arg0 = %result_75) {
      %79 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit, !qco.qubit}, {!qco.qubit}) -> ({!qco.qubit, !qco.qubit}, {!qco.qubit})
    %61 = qtensor.insert %targets_out_77 into %out_tensor_74[%c2] : tensor<3x!qco.qubit>
    %62 = qtensor.insert %controls_out_76#1 into %61[%c1] : tensor<3x!qco.qubit>
    %63 = qtensor.insert %controls_out_76#0 into %62[%c0] : tensor<3x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %63[%c0] : tensor<3x!qco.qubit>
    %64 = qco.x %result_79 : !qco.qubit -> !qco.qubit
    %65 = qtensor.insert %64 into %out_tensor_78[%c0] : tensor<3x!qco.qubit>
    %out_tensor_80, %result_81 = qtensor.extract %65[%c1] : tensor<3x!qco.qubit>
    %66 = qco.x %result_81 : !qco.qubit -> !qco.qubit
    %67 = qtensor.insert %66 into %out_tensor_80[%c1] : tensor<3x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %67[%c2] : tensor<3x!qco.qubit>
    %68 = qco.x %result_83 : !qco.qubit -> !qco.qubit
    %69 = qtensor.insert %68 into %out_tensor_82[%c2] : tensor<3x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %69[%c0] : tensor<3x!qco.qubit>
    %70 = qco.h %result_85 : !qco.qubit -> !qco.qubit
    %71 = qtensor.insert %70 into %out_tensor_84[%c0] : tensor<3x!qco.qubit>
    %out_tensor_86, %result_87 = qtensor.extract %71[%c1] : tensor<3x!qco.qubit>
    %72 = qco.h %result_87 : !qco.qubit -> !qco.qubit
    %73 = qtensor.insert %72 into %out_tensor_86[%c1] : tensor<3x!qco.qubit>
    %out_tensor_88, %result_89 = qtensor.extract %73[%c2] : tensor<3x!qco.qubit>
    %74 = qco.h %result_89 : !qco.qubit -> !qco.qubit
    %75 = qtensor.insert %74 into %out_tensor_88[%c2] : tensor<3x!qco.qubit>
    %out_tensor_90, %result_91 = qtensor.extract %75[%c0] : tensor<3x!qco.qubit>
    %qubit_out, %result_92 = qco.measure %result_91 : !qco.qubit
    %76 = qtensor.insert %qubit_out into %out_tensor_90[%c0] : tensor<3x!qco.qubit>
    cbit.store %result_92, %1[%c0] : !cbit.reg<3>
    %out_tensor_93, %result_94 = qtensor.extract %76[%c1] : tensor<3x!qco.qubit>
    %qubit_out_95, %result_96 = qco.measure %result_94 : !qco.qubit
    %77 = qtensor.insert %qubit_out_95 into %out_tensor_93[%c1] : tensor<3x!qco.qubit>
    cbit.store %result_96, %1[%c1] : !cbit.reg<3>
    %out_tensor_97, %result_98 = qtensor.extract %77[%c2] : tensor<3x!qco.qubit>
    %qubit_out_99, %result_100 = qco.measure %result_98 : !qco.qubit
    %78 = qtensor.insert %qubit_out_99 into %out_tensor_97[%c2] : tensor<3x!qco.qubit>
    cbit.store %result_100, %1[%c2] : !cbit.reg<3>
    qtensor.dealloc %78 : tensor<3x!qco.qubit>
    return %1 : !cbit.reg<3>
  }
}
