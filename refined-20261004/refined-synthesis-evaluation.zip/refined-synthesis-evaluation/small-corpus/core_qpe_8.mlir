module {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant -0.049087385212340517 : f64
    %cst_0 = arith.constant -0.098174770424681035 : f64
    %cst_1 = arith.constant -0.19634954084936207 : f64
    %cst_2 = arith.constant -0.39269908169872414 : f64
    %cst_3 = arith.constant -0.78539816339744828 : f64
    %cst_4 = arith.constant 3.1415926535897931 : f64
    %cst_5 = arith.constant 4.7123889803846897 : f64
    %cst_6 = arith.constant 2.3561944901923448 : f64
    %c5 = arith.constant 5 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %cst_7 = arith.constant -1.5707963267948966 : f64
    %c6 = arith.constant 6 : index
    %c1 = arith.constant 1 : index
    %c7 = arith.constant 7 : index
    %c0 = arith.constant 0 : index
    %0 = qtensor.alloc(%c7) {mqt.register_name = "query"} : tensor<7x!qco.qubit>
    %1 = qco.alloc : !qco.qubit
    %2 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<7x!qco.qubit>
    %3 = qco.h %result : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor[%c0] : tensor<7x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %4[%c1] : tensor<7x!qco.qubit>
    %5 = qco.h %result_9 : !qco.qubit -> !qco.qubit
    %6 = qtensor.insert %5 into %out_tensor_8[%c1] : tensor<7x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %6[%c2] : tensor<7x!qco.qubit>
    %7 = qco.h %result_11 : !qco.qubit -> !qco.qubit
    %8 = qtensor.insert %7 into %out_tensor_10[%c2] : tensor<7x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %8[%c3] : tensor<7x!qco.qubit>
    %9 = qco.h %result_13 : !qco.qubit -> !qco.qubit
    %10 = qtensor.insert %9 into %out_tensor_12[%c3] : tensor<7x!qco.qubit>
    %out_tensor_14, %result_15 = qtensor.extract %10[%c4] : tensor<7x!qco.qubit>
    %11 = qco.h %result_15 : !qco.qubit -> !qco.qubit
    %12 = qtensor.insert %11 into %out_tensor_14[%c4] : tensor<7x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %12[%c5] : tensor<7x!qco.qubit>
    %13 = qco.h %result_17 : !qco.qubit -> !qco.qubit
    %14 = qtensor.insert %13 into %out_tensor_16[%c5] : tensor<7x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %14[%c6] : tensor<7x!qco.qubit>
    %15 = qco.h %result_19 : !qco.qubit -> !qco.qubit
    %16 = qtensor.insert %15 into %out_tensor_18[%c6] : tensor<7x!qco.qubit>
    %17 = qco.x %1 : !qco.qubit -> !qco.qubit
    %out_tensor_20, %result_21 = qtensor.extract %16[%c6] : tensor<7x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_21) targets (%arg0 = %17) {
      %88 = qco.p(%cst_6) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qtensor.insert %controls_out into %out_tensor_20[%c6] : tensor<7x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %18[%c5] : tensor<7x!qco.qubit>
    %controls_out_24, %targets_out_25 = qco.ctrl(%result_23) targets (%arg0 = %targets_out) {
      %88 = qco.p(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qtensor.insert %controls_out_24 into %out_tensor_22[%c5] : tensor<7x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %19[%c4] : tensor<7x!qco.qubit>
    %controls_out_28, %targets_out_29 = qco.ctrl(%result_27) targets (%arg0 = %targets_out_25) {
      %88 = qco.p(%cst_4) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qtensor.insert %controls_out_28 into %out_tensor_26[%c4] : tensor<7x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %20[%c3] : tensor<7x!qco.qubit>
    %controls_out_32, %targets_out_33 = qco.ctrl(%result_31) targets (%arg0 = %targets_out_29) {
      qco.yield %arg0 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qtensor.insert %controls_out_32 into %out_tensor_30[%c3] : tensor<7x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %21[%c2] : tensor<7x!qco.qubit>
    %controls_out_36, %targets_out_37 = qco.ctrl(%result_35) targets (%arg0 = %targets_out_33) {
      qco.yield %arg0 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qtensor.insert %controls_out_36 into %out_tensor_34[%c2] : tensor<7x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %22[%c1] : tensor<7x!qco.qubit>
    %controls_out_40, %targets_out_41 = qco.ctrl(%result_39) targets (%arg0 = %targets_out_37) {
      qco.yield %arg0 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qtensor.insert %controls_out_40 into %out_tensor_38[%c1] : tensor<7x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %23[%c0] : tensor<7x!qco.qubit>
    %controls_out_44, %targets_out_45 = qco.ctrl(%result_43) targets (%arg0 = %targets_out_41) {
      qco.yield %arg0 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qtensor.insert %controls_out_44 into %out_tensor_42[%c0] : tensor<7x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %24[%c0] : tensor<7x!qco.qubit>
    %25 = qco.h %result_47 : !qco.qubit -> !qco.qubit
    %26 = qtensor.insert %25 into %out_tensor_46[%c0] : tensor<7x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %26[%c0] : tensor<7x!qco.qubit>
    %out_tensor_50, %result_51 = qtensor.extract %out_tensor_48[%c1] : tensor<7x!qco.qubit>
    %controls_out_52, %targets_out_53 = qco.ctrl(%result_49) targets (%arg0 = %result_51) {
      %88 = qco.p(%cst_7) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %27 = qtensor.insert %targets_out_53 into %out_tensor_50[%c1] : tensor<7x!qco.qubit>
    %28 = qtensor.insert %controls_out_52 into %27[%c0] : tensor<7x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %28[%c1] : tensor<7x!qco.qubit>
    %29 = qco.h %result_55 : !qco.qubit -> !qco.qubit
    %30 = qtensor.insert %29 into %out_tensor_54[%c1] : tensor<7x!qco.qubit>
    %out_tensor_56, %result_57 = qtensor.extract %30[%c1] : tensor<7x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %out_tensor_56[%c2] : tensor<7x!qco.qubit>
    %controls_out_60, %targets_out_61 = qco.ctrl(%result_57) targets (%arg0 = %result_59) {
      %88 = qco.p(%cst_7) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qtensor.insert %targets_out_61 into %out_tensor_58[%c2] : tensor<7x!qco.qubit>
    %32 = qtensor.insert %controls_out_60 into %31[%c1] : tensor<7x!qco.qubit>
    %out_tensor_62, %result_63 = qtensor.extract %32[%c0] : tensor<7x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %out_tensor_62[%c2] : tensor<7x!qco.qubit>
    %controls_out_66, %targets_out_67 = qco.ctrl(%result_63) targets (%arg0 = %result_65) {
      %88 = qco.p(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %33 = qtensor.insert %targets_out_67 into %out_tensor_64[%c2] : tensor<7x!qco.qubit>
    %34 = qtensor.insert %controls_out_66 into %33[%c0] : tensor<7x!qco.qubit>
    %out_tensor_68, %result_69 = qtensor.extract %34[%c2] : tensor<7x!qco.qubit>
    %35 = qco.h %result_69 : !qco.qubit -> !qco.qubit
    %36 = qtensor.insert %35 into %out_tensor_68[%c2] : tensor<7x!qco.qubit>
    %out_tensor_70, %result_71 = qtensor.extract %36[%c2] : tensor<7x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %out_tensor_70[%c3] : tensor<7x!qco.qubit>
    %controls_out_74, %targets_out_75 = qco.ctrl(%result_71) targets (%arg0 = %result_73) {
      %88 = qco.p(%cst_7) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qtensor.insert %targets_out_75 into %out_tensor_72[%c3] : tensor<7x!qco.qubit>
    %38 = qtensor.insert %controls_out_74 into %37[%c2] : tensor<7x!qco.qubit>
    %out_tensor_76, %result_77 = qtensor.extract %38[%c1] : tensor<7x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %out_tensor_76[%c3] : tensor<7x!qco.qubit>
    %controls_out_80, %targets_out_81 = qco.ctrl(%result_77) targets (%arg0 = %result_79) {
      %88 = qco.p(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qtensor.insert %targets_out_81 into %out_tensor_78[%c3] : tensor<7x!qco.qubit>
    %40 = qtensor.insert %controls_out_80 into %39[%c1] : tensor<7x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %40[%c0] : tensor<7x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %out_tensor_82[%c3] : tensor<7x!qco.qubit>
    %controls_out_86, %targets_out_87 = qco.ctrl(%result_83) targets (%arg0 = %result_85) {
      %88 = qco.p(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qtensor.insert %targets_out_87 into %out_tensor_84[%c3] : tensor<7x!qco.qubit>
    %42 = qtensor.insert %controls_out_86 into %41[%c0] : tensor<7x!qco.qubit>
    %out_tensor_88, %result_89 = qtensor.extract %42[%c3] : tensor<7x!qco.qubit>
    %43 = qco.h %result_89 : !qco.qubit -> !qco.qubit
    %44 = qtensor.insert %43 into %out_tensor_88[%c3] : tensor<7x!qco.qubit>
    %out_tensor_90, %result_91 = qtensor.extract %44[%c3] : tensor<7x!qco.qubit>
    %out_tensor_92, %result_93 = qtensor.extract %out_tensor_90[%c4] : tensor<7x!qco.qubit>
    %controls_out_94, %targets_out_95 = qco.ctrl(%result_91) targets (%arg0 = %result_93) {
      %88 = qco.p(%cst_7) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qtensor.insert %targets_out_95 into %out_tensor_92[%c4] : tensor<7x!qco.qubit>
    %46 = qtensor.insert %controls_out_94 into %45[%c3] : tensor<7x!qco.qubit>
    %out_tensor_96, %result_97 = qtensor.extract %46[%c2] : tensor<7x!qco.qubit>
    %out_tensor_98, %result_99 = qtensor.extract %out_tensor_96[%c4] : tensor<7x!qco.qubit>
    %controls_out_100, %targets_out_101 = qco.ctrl(%result_97) targets (%arg0 = %result_99) {
      %88 = qco.p(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qtensor.insert %targets_out_101 into %out_tensor_98[%c4] : tensor<7x!qco.qubit>
    %48 = qtensor.insert %controls_out_100 into %47[%c2] : tensor<7x!qco.qubit>
    %out_tensor_102, %result_103 = qtensor.extract %48[%c1] : tensor<7x!qco.qubit>
    %out_tensor_104, %result_105 = qtensor.extract %out_tensor_102[%c4] : tensor<7x!qco.qubit>
    %controls_out_106, %targets_out_107 = qco.ctrl(%result_103) targets (%arg0 = %result_105) {
      %88 = qco.p(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qtensor.insert %targets_out_107 into %out_tensor_104[%c4] : tensor<7x!qco.qubit>
    %50 = qtensor.insert %controls_out_106 into %49[%c1] : tensor<7x!qco.qubit>
    %out_tensor_108, %result_109 = qtensor.extract %50[%c0] : tensor<7x!qco.qubit>
    %out_tensor_110, %result_111 = qtensor.extract %out_tensor_108[%c4] : tensor<7x!qco.qubit>
    %controls_out_112, %targets_out_113 = qco.ctrl(%result_109) targets (%arg0 = %result_111) {
      %88 = qco.p(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %51 = qtensor.insert %targets_out_113 into %out_tensor_110[%c4] : tensor<7x!qco.qubit>
    %52 = qtensor.insert %controls_out_112 into %51[%c0] : tensor<7x!qco.qubit>
    %out_tensor_114, %result_115 = qtensor.extract %52[%c4] : tensor<7x!qco.qubit>
    %53 = qco.h %result_115 : !qco.qubit -> !qco.qubit
    %54 = qtensor.insert %53 into %out_tensor_114[%c4] : tensor<7x!qco.qubit>
    %out_tensor_116, %result_117 = qtensor.extract %54[%c4] : tensor<7x!qco.qubit>
    %out_tensor_118, %result_119 = qtensor.extract %out_tensor_116[%c5] : tensor<7x!qco.qubit>
    %controls_out_120, %targets_out_121 = qco.ctrl(%result_117) targets (%arg0 = %result_119) {
      %88 = qco.p(%cst_7) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qtensor.insert %targets_out_121 into %out_tensor_118[%c5] : tensor<7x!qco.qubit>
    %56 = qtensor.insert %controls_out_120 into %55[%c4] : tensor<7x!qco.qubit>
    %out_tensor_122, %result_123 = qtensor.extract %56[%c3] : tensor<7x!qco.qubit>
    %out_tensor_124, %result_125 = qtensor.extract %out_tensor_122[%c5] : tensor<7x!qco.qubit>
    %controls_out_126, %targets_out_127 = qco.ctrl(%result_123) targets (%arg0 = %result_125) {
      %88 = qco.p(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %57 = qtensor.insert %targets_out_127 into %out_tensor_124[%c5] : tensor<7x!qco.qubit>
    %58 = qtensor.insert %controls_out_126 into %57[%c3] : tensor<7x!qco.qubit>
    %out_tensor_128, %result_129 = qtensor.extract %58[%c2] : tensor<7x!qco.qubit>
    %out_tensor_130, %result_131 = qtensor.extract %out_tensor_128[%c5] : tensor<7x!qco.qubit>
    %controls_out_132, %targets_out_133 = qco.ctrl(%result_129) targets (%arg0 = %result_131) {
      %88 = qco.p(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qtensor.insert %targets_out_133 into %out_tensor_130[%c5] : tensor<7x!qco.qubit>
    %60 = qtensor.insert %controls_out_132 into %59[%c2] : tensor<7x!qco.qubit>
    %out_tensor_134, %result_135 = qtensor.extract %60[%c1] : tensor<7x!qco.qubit>
    %out_tensor_136, %result_137 = qtensor.extract %out_tensor_134[%c5] : tensor<7x!qco.qubit>
    %controls_out_138, %targets_out_139 = qco.ctrl(%result_135) targets (%arg0 = %result_137) {
      %88 = qco.p(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qtensor.insert %targets_out_139 into %out_tensor_136[%c5] : tensor<7x!qco.qubit>
    %62 = qtensor.insert %controls_out_138 into %61[%c1] : tensor<7x!qco.qubit>
    %out_tensor_140, %result_141 = qtensor.extract %62[%c0] : tensor<7x!qco.qubit>
    %out_tensor_142, %result_143 = qtensor.extract %out_tensor_140[%c5] : tensor<7x!qco.qubit>
    %controls_out_144, %targets_out_145 = qco.ctrl(%result_141) targets (%arg0 = %result_143) {
      %88 = qco.p(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %63 = qtensor.insert %targets_out_145 into %out_tensor_142[%c5] : tensor<7x!qco.qubit>
    %64 = qtensor.insert %controls_out_144 into %63[%c0] : tensor<7x!qco.qubit>
    %out_tensor_146, %result_147 = qtensor.extract %64[%c5] : tensor<7x!qco.qubit>
    %65 = qco.h %result_147 : !qco.qubit -> !qco.qubit
    %66 = qtensor.insert %65 into %out_tensor_146[%c5] : tensor<7x!qco.qubit>
    %out_tensor_148, %result_149 = qtensor.extract %66[%c5] : tensor<7x!qco.qubit>
    %out_tensor_150, %result_151 = qtensor.extract %out_tensor_148[%c6] : tensor<7x!qco.qubit>
    %controls_out_152, %targets_out_153 = qco.ctrl(%result_149) targets (%arg0 = %result_151) {
      %88 = qco.p(%cst_7) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %67 = qtensor.insert %targets_out_153 into %out_tensor_150[%c6] : tensor<7x!qco.qubit>
    %68 = qtensor.insert %controls_out_152 into %67[%c5] : tensor<7x!qco.qubit>
    %out_tensor_154, %result_155 = qtensor.extract %68[%c4] : tensor<7x!qco.qubit>
    %out_tensor_156, %result_157 = qtensor.extract %out_tensor_154[%c6] : tensor<7x!qco.qubit>
    %controls_out_158, %targets_out_159 = qco.ctrl(%result_155) targets (%arg0 = %result_157) {
      %88 = qco.p(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qtensor.insert %targets_out_159 into %out_tensor_156[%c6] : tensor<7x!qco.qubit>
    %70 = qtensor.insert %controls_out_158 into %69[%c4] : tensor<7x!qco.qubit>
    %out_tensor_160, %result_161 = qtensor.extract %70[%c3] : tensor<7x!qco.qubit>
    %out_tensor_162, %result_163 = qtensor.extract %out_tensor_160[%c6] : tensor<7x!qco.qubit>
    %controls_out_164, %targets_out_165 = qco.ctrl(%result_161) targets (%arg0 = %result_163) {
      %88 = qco.p(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qtensor.insert %targets_out_165 into %out_tensor_162[%c6] : tensor<7x!qco.qubit>
    %72 = qtensor.insert %controls_out_164 into %71[%c3] : tensor<7x!qco.qubit>
    %out_tensor_166, %result_167 = qtensor.extract %72[%c2] : tensor<7x!qco.qubit>
    %out_tensor_168, %result_169 = qtensor.extract %out_tensor_166[%c6] : tensor<7x!qco.qubit>
    %controls_out_170, %targets_out_171 = qco.ctrl(%result_167) targets (%arg0 = %result_169) {
      %88 = qco.p(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %73 = qtensor.insert %targets_out_171 into %out_tensor_168[%c6] : tensor<7x!qco.qubit>
    %74 = qtensor.insert %controls_out_170 into %73[%c2] : tensor<7x!qco.qubit>
    %out_tensor_172, %result_173 = qtensor.extract %74[%c1] : tensor<7x!qco.qubit>
    %out_tensor_174, %result_175 = qtensor.extract %out_tensor_172[%c6] : tensor<7x!qco.qubit>
    %controls_out_176, %targets_out_177 = qco.ctrl(%result_173) targets (%arg0 = %result_175) {
      %88 = qco.p(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %75 = qtensor.insert %targets_out_177 into %out_tensor_174[%c6] : tensor<7x!qco.qubit>
    %76 = qtensor.insert %controls_out_176 into %75[%c1] : tensor<7x!qco.qubit>
    %out_tensor_178, %result_179 = qtensor.extract %76[%c0] : tensor<7x!qco.qubit>
    %out_tensor_180, %result_181 = qtensor.extract %out_tensor_178[%c6] : tensor<7x!qco.qubit>
    %controls_out_182, %targets_out_183 = qco.ctrl(%result_179) targets (%arg0 = %result_181) {
      %88 = qco.p(%cst) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %88 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qtensor.insert %targets_out_183 into %out_tensor_180[%c6] : tensor<7x!qco.qubit>
    %78 = qtensor.insert %controls_out_182 into %77[%c0] : tensor<7x!qco.qubit>
    %out_tensor_184, %result_185 = qtensor.extract %78[%c6] : tensor<7x!qco.qubit>
    %79 = qco.h %result_185 : !qco.qubit -> !qco.qubit
    %80 = qtensor.insert %79 into %out_tensor_184[%c6] : tensor<7x!qco.qubit>
    %out_tensor_186, %result_187 = qtensor.extract %80[%c0] : tensor<7x!qco.qubit>
    %qubit_out, %result_188 = qco.measure %result_187 : !qco.qubit
    %81 = qtensor.insert %qubit_out into %out_tensor_186[%c0] : tensor<7x!qco.qubit>
    cbit.store %result_188, %2[%c0] : !cbit.reg<7>
    %out_tensor_189, %result_190 = qtensor.extract %81[%c1] : tensor<7x!qco.qubit>
    %qubit_out_191, %result_192 = qco.measure %result_190 : !qco.qubit
    %82 = qtensor.insert %qubit_out_191 into %out_tensor_189[%c1] : tensor<7x!qco.qubit>
    cbit.store %result_192, %2[%c1] : !cbit.reg<7>
    %out_tensor_193, %result_194 = qtensor.extract %82[%c2] : tensor<7x!qco.qubit>
    %qubit_out_195, %result_196 = qco.measure %result_194 : !qco.qubit
    %83 = qtensor.insert %qubit_out_195 into %out_tensor_193[%c2] : tensor<7x!qco.qubit>
    cbit.store %result_196, %2[%c2] : !cbit.reg<7>
    %out_tensor_197, %result_198 = qtensor.extract %83[%c3] : tensor<7x!qco.qubit>
    %qubit_out_199, %result_200 = qco.measure %result_198 : !qco.qubit
    %84 = qtensor.insert %qubit_out_199 into %out_tensor_197[%c3] : tensor<7x!qco.qubit>
    cbit.store %result_200, %2[%c3] : !cbit.reg<7>
    %out_tensor_201, %result_202 = qtensor.extract %84[%c4] : tensor<7x!qco.qubit>
    %qubit_out_203, %result_204 = qco.measure %result_202 : !qco.qubit
    %85 = qtensor.insert %qubit_out_203 into %out_tensor_201[%c4] : tensor<7x!qco.qubit>
    cbit.store %result_204, %2[%c4] : !cbit.reg<7>
    %out_tensor_205, %result_206 = qtensor.extract %85[%c5] : tensor<7x!qco.qubit>
    %qubit_out_207, %result_208 = qco.measure %result_206 : !qco.qubit
    %86 = qtensor.insert %qubit_out_207 into %out_tensor_205[%c5] : tensor<7x!qco.qubit>
    cbit.store %result_208, %2[%c5] : !cbit.reg<7>
    %out_tensor_209, %result_210 = qtensor.extract %86[%c6] : tensor<7x!qco.qubit>
    %qubit_out_211, %result_212 = qco.measure %result_210 : !qco.qubit
    %87 = qtensor.insert %qubit_out_211 into %out_tensor_209[%c6] : tensor<7x!qco.qubit>
    cbit.store %result_212, %2[%c6] : !cbit.reg<7>
    qco.sink %targets_out_45 : !qco.qubit
    qtensor.dealloc %87 : tensor<7x!qco.qubit>
    return %2 : !cbit.reg<7>
  }
}
