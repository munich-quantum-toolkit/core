module {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant -0.78539816339744828 : f64
    %cst_0 = arith.constant 3.1415926535897931 : f64
    %cst_1 = arith.constant 4.7123889803846897 : f64
    %cst_2 = arith.constant 2.3561944901923448 : f64
    %cst_3 = arith.constant -1.5707963267948966 : f64
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c3 = arith.constant 3 : index
    %c0 = arith.constant 0 : index
    %0 = qtensor.alloc(%c3) {mqt.register_name = "query"} : tensor<3x!qco.qubit>
    %1 = qco.alloc : !qco.qubit
    %2 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<3x!qco.qubit>
    %3 = qco.h %result : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor[%c0] : tensor<3x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %4[%c1] : tensor<3x!qco.qubit>
    %5 = qco.h %result_5 : !qco.qubit -> !qco.qubit
    %6 = qtensor.insert %5 into %out_tensor_4[%c1] : tensor<3x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %6[%c2] : tensor<3x!qco.qubit>
    %7 = qco.h %result_7 : !qco.qubit -> !qco.qubit
    %8 = qtensor.insert %7 into %out_tensor_6[%c2] : tensor<3x!qco.qubit>
    %9 = qco.x %1 : !qco.qubit -> !qco.qubit
    %out_tensor_8, %result_9 = qtensor.extract %8[%c2] : tensor<3x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_9) targets (%arg0 = %9) {
      %28 = qco.p(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %28 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %10 = qtensor.insert %controls_out into %out_tensor_8[%c2] : tensor<3x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %10[%c1] : tensor<3x!qco.qubit>
    %controls_out_12, %targets_out_13 = qco.ctrl(%result_11) targets (%arg0 = %targets_out) {
      %28 = qco.p(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %28 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qtensor.insert %controls_out_12 into %out_tensor_10[%c1] : tensor<3x!qco.qubit>
    %out_tensor_14, %result_15 = qtensor.extract %11[%c0] : tensor<3x!qco.qubit>
    %controls_out_16, %targets_out_17 = qco.ctrl(%result_15) targets (%arg0 = %targets_out_13) {
      %28 = qco.p(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %28 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qtensor.insert %controls_out_16 into %out_tensor_14[%c0] : tensor<3x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %12[%c0] : tensor<3x!qco.qubit>
    %13 = qco.h %result_19 : !qco.qubit -> !qco.qubit
    %14 = qtensor.insert %13 into %out_tensor_18[%c0] : tensor<3x!qco.qubit>
    %out_tensor_20, %result_21 = qtensor.extract %14[%c0] : tensor<3x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %out_tensor_20[%c1] : tensor<3x!qco.qubit>
    %controls_out_24, %targets_out_25 = qco.ctrl(%result_21) targets (%arg0 = %result_23) {
      %28 = qco.p(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %28 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qtensor.insert %targets_out_25 into %out_tensor_22[%c1] : tensor<3x!qco.qubit>
    %16 = qtensor.insert %controls_out_24 into %15[%c0] : tensor<3x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %16[%c1] : tensor<3x!qco.qubit>
    %17 = qco.h %result_27 : !qco.qubit -> !qco.qubit
    %18 = qtensor.insert %17 into %out_tensor_26[%c1] : tensor<3x!qco.qubit>
    %out_tensor_28, %result_29 = qtensor.extract %18[%c1] : tensor<3x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %out_tensor_28[%c2] : tensor<3x!qco.qubit>
    %controls_out_32, %targets_out_33 = qco.ctrl(%result_29) targets (%arg0 = %result_31) {
      %28 = qco.p(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %28 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qtensor.insert %targets_out_33 into %out_tensor_30[%c2] : tensor<3x!qco.qubit>
    %20 = qtensor.insert %controls_out_32 into %19[%c1] : tensor<3x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %20[%c0] : tensor<3x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %out_tensor_34[%c2] : tensor<3x!qco.qubit>
    %controls_out_38, %targets_out_39 = qco.ctrl(%result_35) targets (%arg0 = %result_37) {
      %28 = qco.p(%cst) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %28 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qtensor.insert %targets_out_39 into %out_tensor_36[%c2] : tensor<3x!qco.qubit>
    %22 = qtensor.insert %controls_out_38 into %21[%c0] : tensor<3x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %22[%c2] : tensor<3x!qco.qubit>
    %23 = qco.h %result_41 : !qco.qubit -> !qco.qubit
    %24 = qtensor.insert %23 into %out_tensor_40[%c2] : tensor<3x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %24[%c0] : tensor<3x!qco.qubit>
    %qubit_out, %result_44 = qco.measure %result_43 : !qco.qubit
    %25 = qtensor.insert %qubit_out into %out_tensor_42[%c0] : tensor<3x!qco.qubit>
    cbit.store %result_44, %2[%c0] : !cbit.reg<3>
    %out_tensor_45, %result_46 = qtensor.extract %25[%c1] : tensor<3x!qco.qubit>
    %qubit_out_47, %result_48 = qco.measure %result_46 : !qco.qubit
    %26 = qtensor.insert %qubit_out_47 into %out_tensor_45[%c1] : tensor<3x!qco.qubit>
    cbit.store %result_48, %2[%c1] : !cbit.reg<3>
    %out_tensor_49, %result_50 = qtensor.extract %26[%c2] : tensor<3x!qco.qubit>
    %qubit_out_51, %result_52 = qco.measure %result_50 : !qco.qubit
    %27 = qtensor.insert %qubit_out_51 into %out_tensor_49[%c2] : tensor<3x!qco.qubit>
    cbit.store %result_52, %2[%c2] : !cbit.reg<3>
    qco.sink %targets_out_17 : !qco.qubit
    qtensor.dealloc %27 : tensor<3x!qco.qubit>
    return %2 : !cbit.reg<3>
  }
}
