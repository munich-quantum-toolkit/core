module {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 0.39269908169872414 : f64
    %cst_0 = arith.constant 0.78539816339744828 : f64
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %c3 = arith.constant 3 : index
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c2 = arith.constant 2 : index
    %0 = qtensor.alloc(%c4) {mqt.register_name = "query"} : tensor<4x!qco.qubit>
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %out_tensor, %result = qtensor.extract %0[%c2] : tensor<4x!qco.qubit>
    %2 = qco.h %result : !qco.qubit -> !qco.qubit
    %3 = qtensor.insert %2 into %out_tensor[%c2] : tensor<4x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %3[%c3] : tensor<4x!qco.qubit>
    %4 = qco.h %result_3 : !qco.qubit -> !qco.qubit
    %5 = qtensor.insert %4 into %out_tensor_2[%c3] : tensor<4x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %5[%c3] : tensor<4x!qco.qubit>
    %6 = qco.h %result_5 : !qco.qubit -> !qco.qubit
    %7 = qtensor.insert %6 into %out_tensor_4[%c3] : tensor<4x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %7[%c2] : tensor<4x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %out_tensor_6[%c3] : tensor<4x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_7) targets (%arg0 = %result_9) {
      %30 = qco.p(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %8 = qtensor.insert %targets_out into %out_tensor_8[%c3] : tensor<4x!qco.qubit>
    %9 = qtensor.insert %controls_out into %8[%c2] : tensor<4x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %9[%c1] : tensor<4x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %out_tensor_10[%c3] : tensor<4x!qco.qubit>
    %controls_out_14, %targets_out_15 = qco.ctrl(%result_11) targets (%arg0 = %result_13) {
      %30 = qco.p(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %10 = qtensor.insert %targets_out_15 into %out_tensor_12[%c3] : tensor<4x!qco.qubit>
    %11 = qtensor.insert %controls_out_14 into %10[%c1] : tensor<4x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %11[%c0] : tensor<4x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %out_tensor_16[%c3] : tensor<4x!qco.qubit>
    %controls_out_20, %targets_out_21 = qco.ctrl(%result_17) targets (%arg0 = %result_19) {
      %30 = qco.p(%cst) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qtensor.insert %targets_out_21 into %out_tensor_18[%c3] : tensor<4x!qco.qubit>
    %13 = qtensor.insert %controls_out_20 into %12[%c0] : tensor<4x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %13[%c2] : tensor<4x!qco.qubit>
    %14 = qco.h %result_23 : !qco.qubit -> !qco.qubit
    %15 = qtensor.insert %14 into %out_tensor_22[%c2] : tensor<4x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %15[%c1] : tensor<4x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %out_tensor_24[%c2] : tensor<4x!qco.qubit>
    %controls_out_28, %targets_out_29 = qco.ctrl(%result_25) targets (%arg0 = %result_27) {
      %30 = qco.p(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qtensor.insert %targets_out_29 into %out_tensor_26[%c2] : tensor<4x!qco.qubit>
    %17 = qtensor.insert %controls_out_28 into %16[%c1] : tensor<4x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %17[%c0] : tensor<4x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %out_tensor_30[%c2] : tensor<4x!qco.qubit>
    %controls_out_34, %targets_out_35 = qco.ctrl(%result_31) targets (%arg0 = %result_33) {
      %30 = qco.p(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qtensor.insert %targets_out_35 into %out_tensor_32[%c2] : tensor<4x!qco.qubit>
    %19 = qtensor.insert %controls_out_34 into %18[%c0] : tensor<4x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %19[%c1] : tensor<4x!qco.qubit>
    %20 = qco.h %result_37 : !qco.qubit -> !qco.qubit
    %21 = qtensor.insert %20 into %out_tensor_36[%c1] : tensor<4x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %21[%c0] : tensor<4x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %out_tensor_38[%c1] : tensor<4x!qco.qubit>
    %controls_out_42, %targets_out_43 = qco.ctrl(%result_39) targets (%arg0 = %result_41) {
      %30 = qco.p(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qtensor.insert %targets_out_43 into %out_tensor_40[%c1] : tensor<4x!qco.qubit>
    %23 = qtensor.insert %controls_out_42 into %22[%c0] : tensor<4x!qco.qubit>
    %out_tensor_44, %result_45 = qtensor.extract %23[%c0] : tensor<4x!qco.qubit>
    %24 = qco.h %result_45 : !qco.qubit -> !qco.qubit
    %25 = qtensor.insert %24 into %out_tensor_44[%c0] : tensor<4x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %25[%c0] : tensor<4x!qco.qubit>
    %qubit_out, %result_48 = qco.measure %result_47 : !qco.qubit
    %26 = qtensor.insert %qubit_out into %out_tensor_46[%c0] : tensor<4x!qco.qubit>
    cbit.store %result_48, %1[%c3] : !cbit.reg<4>
    %out_tensor_49, %result_50 = qtensor.extract %26[%c1] : tensor<4x!qco.qubit>
    %qubit_out_51, %result_52 = qco.measure %result_50 : !qco.qubit
    %27 = qtensor.insert %qubit_out_51 into %out_tensor_49[%c1] : tensor<4x!qco.qubit>
    cbit.store %result_52, %1[%c2] : !cbit.reg<4>
    %out_tensor_53, %result_54 = qtensor.extract %27[%c2] : tensor<4x!qco.qubit>
    %qubit_out_55, %result_56 = qco.measure %result_54 : !qco.qubit
    %28 = qtensor.insert %qubit_out_55 into %out_tensor_53[%c2] : tensor<4x!qco.qubit>
    cbit.store %result_56, %1[%c1] : !cbit.reg<4>
    %out_tensor_57, %result_58 = qtensor.extract %28[%c3] : tensor<4x!qco.qubit>
    %qubit_out_59, %result_60 = qco.measure %result_58 : !qco.qubit
    %29 = qtensor.insert %qubit_out_59 into %out_tensor_57[%c3] : tensor<4x!qco.qubit>
    cbit.store %result_60, %1[%c0] : !cbit.reg<4>
    qtensor.dealloc %29 : tensor<4x!qco.qubit>
    return %1 : !cbit.reg<4>
  }
}
