module {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %0 = qtensor.alloc(%c4) {mqt.register_name = "q"} : tensor<4x!qco.qubit>
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<4x!qco.qubit>
    %2 = qco.h %result : !qco.qubit -> !qco.qubit
    %3 = qtensor.insert %2 into %out_tensor[%c0] : tensor<4x!qco.qubit>
    %out_tensor_0, %result_1 = qtensor.extract %3[%c0] : tensor<4x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %out_tensor_0[%c1] : tensor<4x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_1) targets (%arg0 = %result_3) {
      %14 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %14 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %4 = qtensor.insert %targets_out into %out_tensor_2[%c1] : tensor<4x!qco.qubit>
    %5 = qtensor.insert %controls_out into %4[%c0] : tensor<4x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %5[%c1] : tensor<4x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %out_tensor_4[%c2] : tensor<4x!qco.qubit>
    %controls_out_8, %targets_out_9 = qco.ctrl(%result_5) targets (%arg0 = %result_7) {
      %14 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %14 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %6 = qtensor.insert %targets_out_9 into %out_tensor_6[%c2] : tensor<4x!qco.qubit>
    %7 = qtensor.insert %controls_out_8 into %6[%c1] : tensor<4x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %7[%c2] : tensor<4x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %out_tensor_10[%c3] : tensor<4x!qco.qubit>
    %controls_out_14, %targets_out_15 = qco.ctrl(%result_11) targets (%arg0 = %result_13) {
      %14 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %14 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %8 = qtensor.insert %targets_out_15 into %out_tensor_12[%c3] : tensor<4x!qco.qubit>
    %9 = qtensor.insert %controls_out_14 into %8[%c2] : tensor<4x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %9[%c0] : tensor<4x!qco.qubit>
    %qubit_out, %result_18 = qco.measure %result_17 : !qco.qubit
    %10 = qtensor.insert %qubit_out into %out_tensor_16[%c0] : tensor<4x!qco.qubit>
    cbit.store %result_18, %1[%c0] : !cbit.reg<4>
    %out_tensor_19, %result_20 = qtensor.extract %10[%c1] : tensor<4x!qco.qubit>
    %qubit_out_21, %result_22 = qco.measure %result_20 : !qco.qubit
    %11 = qtensor.insert %qubit_out_21 into %out_tensor_19[%c1] : tensor<4x!qco.qubit>
    cbit.store %result_22, %1[%c1] : !cbit.reg<4>
    %out_tensor_23, %result_24 = qtensor.extract %11[%c2] : tensor<4x!qco.qubit>
    %qubit_out_25, %result_26 = qco.measure %result_24 : !qco.qubit
    %12 = qtensor.insert %qubit_out_25 into %out_tensor_23[%c2] : tensor<4x!qco.qubit>
    cbit.store %result_26, %1[%c2] : !cbit.reg<4>
    %out_tensor_27, %result_28 = qtensor.extract %12[%c3] : tensor<4x!qco.qubit>
    %qubit_out_29, %result_30 = qco.measure %result_28 : !qco.qubit
    %13 = qtensor.insert %qubit_out_29 into %out_tensor_27[%c3] : tensor<4x!qco.qubit>
    cbit.store %result_30, %1[%c3] : !cbit.reg<4>
    qtensor.dealloc %13 : tensor<4x!qco.qubit>
    return %1 : !cbit.reg<4>
  }
}
