module {
  func.func @main(%arg0: f64 {mqt.input_id = -3033000624479524390794154133784343657 : i128, mqt.input_name = "theta[0]", mqt.parameter_group = {identity = "fdb7dd86-1c01-4fc1-b8da-f3c16e084b97", index = 0 : i64, name = "theta", size = 2 : i64}}) -> i64 attributes {mqt.entry_point} {
    %c0_i64 = arith.constant 0 : i64
    %cst = arith.constant 1.5707963267948966 : f64
    %cst_0 = arith.constant 0.000000e+00 : f64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %0 = qtensor.alloc(%c2) {mqt.register_name = "q"} : tensor<2x!qco.qubit>
    qco.gphase(%cst_0)
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<2x!qco.qubit>
    %1 = qco.r(%cst, %arg0) %result : !qco.qubit -> !qco.qubit
    %2 = qtensor.insert %1 into %out_tensor[%c0] : tensor<2x!qco.qubit>
    %out_tensor_1, %result_2 = qtensor.extract %2[%c0] : tensor<2x!qco.qubit>
    %3 = qco.r(%cst, %arg0) %result_2 : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor_1[%c0] : tensor<2x!qco.qubit>
    qtensor.dealloc %4 : tensor<2x!qco.qubit>
    return %c0_i64 : i64
  }
}
