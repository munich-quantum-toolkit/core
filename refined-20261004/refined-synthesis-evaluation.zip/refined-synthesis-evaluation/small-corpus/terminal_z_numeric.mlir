module {
  func.func @main() -> !cbit.reg<2> attributes {mqt.entry_point} {
    %cst = arith.constant 3.700000e-01 : f64
    %cst_0 = arith.constant 0.000000e+00 : f64
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %0 = qtensor.alloc(%c2) {mqt.register_name = "q"} : tensor<2x!qco.qubit>
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "meas"} : !cbit.reg<2>
    qco.gphase(%cst_0)
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<2x!qco.qubit>
    %2 = qco.h %result : !qco.qubit -> !qco.qubit
    %3 = qtensor.insert %2 into %out_tensor[%c0] : tensor<2x!qco.qubit>
    %out_tensor_1, %result_2 = qtensor.extract %3[%c0] : tensor<2x!qco.qubit>
    %4 = qco.rz(%cst) %result_2 : !qco.qubit -> !qco.qubit
    %5 = qtensor.insert %4 into %out_tensor_1[%c0] : tensor<2x!qco.qubit>
    %out_tensor_3, %result_4 = qtensor.extract %5[%c0] : tensor<2x!qco.qubit>
    %out_tensor_5, %result_6 = qtensor.extract %out_tensor_3[%c1] : tensor<2x!qco.qubit>
    %6:2 = qco.barrier %result_4, %result_6 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %7 = qtensor.insert %6#1 into %out_tensor_5[%c1] : tensor<2x!qco.qubit>
    %8 = qtensor.insert %6#0 into %7[%c0] : tensor<2x!qco.qubit>
    %out_tensor_7, %result_8 = qtensor.extract %8[%c0] : tensor<2x!qco.qubit>
    %qubit_out, %result_9 = qco.measure %result_8 : !qco.qubit
    %9 = qtensor.insert %qubit_out into %out_tensor_7[%c0] : tensor<2x!qco.qubit>
    cbit.store %result_9, %1[%c0] : !cbit.reg<2>
    %out_tensor_10, %result_11 = qtensor.extract %9[%c1] : tensor<2x!qco.qubit>
    %qubit_out_12, %result_13 = qco.measure %result_11 : !qco.qubit
    %10 = qtensor.insert %qubit_out_12 into %out_tensor_10[%c1] : tensor<2x!qco.qubit>
    cbit.store %result_13, %1[%c1] : !cbit.reg<2>
    qtensor.dealloc %10 : tensor<2x!qco.qubit>
    return %1 : !cbit.reg<2>
  }
}
