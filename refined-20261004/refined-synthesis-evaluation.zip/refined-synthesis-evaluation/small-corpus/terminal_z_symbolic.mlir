module {
  func.func @main(%arg0: f64 {mqt.input_id = -3033000624479524390794154133784343657 : i128, mqt.input_name = "theta[0]", mqt.parameter_group = {identity = "fdb7dd86-1c01-4fc1-b8da-f3c16e084b97", index = 0 : i64, name = "theta", size = 2 : i64}}) -> !cbit.reg<2> attributes {mqt.entry_point} {
    %cst = arith.constant 0.000000e+00 : f64
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %0 = qtensor.alloc(%c2) {mqt.register_name = "q"} : tensor<2x!qco.qubit>
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "meas"} : !cbit.reg<2>
    qco.gphase(%cst)
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<2x!qco.qubit>
    %2 = qco.h %result : !qco.qubit -> !qco.qubit
    %3 = qtensor.insert %2 into %out_tensor[%c0] : tensor<2x!qco.qubit>
    %out_tensor_0, %result_1 = qtensor.extract %3[%c0] : tensor<2x!qco.qubit>
    %4 = qco.rz(%arg0) %result_1 : !qco.qubit -> !qco.qubit
    %5 = qtensor.insert %4 into %out_tensor_0[%c0] : tensor<2x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %5[%c0] : tensor<2x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %out_tensor_2[%c1] : tensor<2x!qco.qubit>
    %6:2 = qco.barrier %result_3, %result_5 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %7 = qtensor.insert %6#1 into %out_tensor_4[%c1] : tensor<2x!qco.qubit>
    %8 = qtensor.insert %6#0 into %7[%c0] : tensor<2x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %8[%c0] : tensor<2x!qco.qubit>
    %qubit_out, %result_8 = qco.measure %result_7 : !qco.qubit
    %9 = qtensor.insert %qubit_out into %out_tensor_6[%c0] : tensor<2x!qco.qubit>
    cbit.store %result_8, %1[%c0] : !cbit.reg<2>
    %out_tensor_9, %result_10 = qtensor.extract %9[%c1] : tensor<2x!qco.qubit>
    %qubit_out_11, %result_12 = qco.measure %result_10 : !qco.qubit
    %10 = qtensor.insert %qubit_out_11 into %out_tensor_9[%c1] : tensor<2x!qco.qubit>
    cbit.store %result_12, %1[%c1] : !cbit.reg<2>
    qtensor.dealloc %10 : tensor<2x!qco.qubit>
    return %1 : !cbit.reg<2>
  }
}
