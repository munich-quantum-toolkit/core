module {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %false = arith.constant false
    %true = arith.constant true
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c3 = arith.constant 3 : index
    %c0 = arith.constant 0 : index
    %0 = qco.alloc : !qco.qubit
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %2 = qco.x %0 : !qco.qubit -> !qco.qubit
    %3 = qtensor.alloc(%c3) {mqt.register_name = "query"} : tensor<3x!qco.qubit>
    %out_tensor, %result = qtensor.extract %3[%c0] : tensor<3x!qco.qubit>
    %4 = qco.h %result : !qco.qubit -> !qco.qubit
    %5 = qtensor.insert %4 into %out_tensor[%c0] : tensor<3x!qco.qubit>
    %out_tensor_0, %result_1 = qtensor.extract %5[%c1] : tensor<3x!qco.qubit>
    %6 = qco.h %result_1 : !qco.qubit -> !qco.qubit
    %7 = qtensor.insert %6 into %out_tensor_0[%c1] : tensor<3x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %7[%c2] : tensor<3x!qco.qubit>
    %8 = qco.h %result_3 : !qco.qubit -> !qco.qubit
    %9 = qtensor.insert %8 into %out_tensor_2[%c2] : tensor<3x!qco.qubit>
    %linearResults:2 = qco.if %true args(%arg0 = %9, %arg1 = %2) -> (tensor<3x!qco.qubit>, !qco.qubit) {
      %out_tensor_23, %result_24 = qtensor.extract %arg0[%c0] : tensor<3x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_24) targets (%arg2 = %arg1) {
        %20 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %20 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %19 = qtensor.insert %controls_out into %out_tensor_23[%c0] : tensor<3x!qco.qubit>
      qco.yield %19, %targets_out : tensor<3x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %9, %arg1 = %2) {
      qco.yield %arg0, %arg1 : tensor<3x!qco.qubit>, !qco.qubit
    }
    %linearResults_4:2 = qco.if %false args(%arg0 = %linearResults#0, %arg1 = %linearResults#1) -> (tensor<3x!qco.qubit>, !qco.qubit) {
      %out_tensor_23, %result_24 = qtensor.extract %arg0[%c1] : tensor<3x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_24) targets (%arg2 = %arg1) {
        %20 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %20 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %19 = qtensor.insert %controls_out into %out_tensor_23[%c1] : tensor<3x!qco.qubit>
      qco.yield %19, %targets_out : tensor<3x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults#0, %arg1 = %linearResults#1) {
      qco.yield %arg0, %arg1 : tensor<3x!qco.qubit>, !qco.qubit
    }
    %linearResults_5:2 = qco.if %true args(%arg0 = %linearResults_4#0, %arg1 = %linearResults_4#1) -> (tensor<3x!qco.qubit>, !qco.qubit) {
      %out_tensor_23, %result_24 = qtensor.extract %arg0[%c2] : tensor<3x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_24) targets (%arg2 = %arg1) {
        %20 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %20 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %19 = qtensor.insert %controls_out into %out_tensor_23[%c2] : tensor<3x!qco.qubit>
      qco.yield %19, %targets_out : tensor<3x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_4#0, %arg1 = %linearResults_4#1) {
      qco.yield %arg0, %arg1 : tensor<3x!qco.qubit>, !qco.qubit
    }
    %out_tensor_6, %result_7 = qtensor.extract %linearResults_5#0[%c0] : tensor<3x!qco.qubit>
    %10 = qco.h %result_7 : !qco.qubit -> !qco.qubit
    %11 = qtensor.insert %10 into %out_tensor_6[%c0] : tensor<3x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %11[%c1] : tensor<3x!qco.qubit>
    %12 = qco.h %result_9 : !qco.qubit -> !qco.qubit
    %13 = qtensor.insert %12 into %out_tensor_8[%c1] : tensor<3x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %13[%c2] : tensor<3x!qco.qubit>
    %14 = qco.h %result_11 : !qco.qubit -> !qco.qubit
    %15 = qtensor.insert %14 into %out_tensor_10[%c2] : tensor<3x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %15[%c0] : tensor<3x!qco.qubit>
    %qubit_out, %result_14 = qco.measure %result_13 : !qco.qubit
    %16 = qtensor.insert %qubit_out into %out_tensor_12[%c0] : tensor<3x!qco.qubit>
    cbit.store %result_14, %1[%c0] : !cbit.reg<3>
    %out_tensor_15, %result_16 = qtensor.extract %16[%c1] : tensor<3x!qco.qubit>
    %qubit_out_17, %result_18 = qco.measure %result_16 : !qco.qubit
    %17 = qtensor.insert %qubit_out_17 into %out_tensor_15[%c1] : tensor<3x!qco.qubit>
    cbit.store %result_18, %1[%c1] : !cbit.reg<3>
    %out_tensor_19, %result_20 = qtensor.extract %17[%c2] : tensor<3x!qco.qubit>
    %qubit_out_21, %result_22 = qco.measure %result_20 : !qco.qubit
    %18 = qtensor.insert %qubit_out_21 into %out_tensor_19[%c2] : tensor<3x!qco.qubit>
    cbit.store %result_22, %1[%c2] : !cbit.reg<3>
    qco.sink %linearResults_5#1 : !qco.qubit
    qtensor.dealloc %18 : tensor<3x!qco.qubit>
    return %1 : !cbit.reg<3>
  }
}
