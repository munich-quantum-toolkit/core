module {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %false = arith.constant false
    %true = arith.constant true
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c7 = arith.constant 7 : index
    %c0 = arith.constant 0 : index
    %0 = qco.alloc : !qco.qubit
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %2 = qco.x %0 : !qco.qubit -> !qco.qubit
    %3 = qtensor.alloc(%c7) {mqt.register_name = "query"} : tensor<7x!qco.qubit>
    %out_tensor, %result = qtensor.extract %3[%c0] : tensor<7x!qco.qubit>
    %4 = qco.h %result : !qco.qubit -> !qco.qubit
    %5 = qtensor.insert %4 into %out_tensor[%c0] : tensor<7x!qco.qubit>
    %out_tensor_0, %result_1 = qtensor.extract %5[%c1] : tensor<7x!qco.qubit>
    %6 = qco.h %result_1 : !qco.qubit -> !qco.qubit
    %7 = qtensor.insert %6 into %out_tensor_0[%c1] : tensor<7x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %7[%c2] : tensor<7x!qco.qubit>
    %8 = qco.h %result_3 : !qco.qubit -> !qco.qubit
    %9 = qtensor.insert %8 into %out_tensor_2[%c2] : tensor<7x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %9[%c3] : tensor<7x!qco.qubit>
    %10 = qco.h %result_5 : !qco.qubit -> !qco.qubit
    %11 = qtensor.insert %10 into %out_tensor_4[%c3] : tensor<7x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %11[%c4] : tensor<7x!qco.qubit>
    %12 = qco.h %result_7 : !qco.qubit -> !qco.qubit
    %13 = qtensor.insert %12 into %out_tensor_6[%c4] : tensor<7x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %13[%c5] : tensor<7x!qco.qubit>
    %14 = qco.h %result_9 : !qco.qubit -> !qco.qubit
    %15 = qtensor.insert %14 into %out_tensor_8[%c5] : tensor<7x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %15[%c6] : tensor<7x!qco.qubit>
    %16 = qco.h %result_11 : !qco.qubit -> !qco.qubit
    %17 = qtensor.insert %16 into %out_tensor_10[%c6] : tensor<7x!qco.qubit>
    %linearResults:2 = qco.if %true args(%arg0 = %17, %arg1 = %2) -> (tensor<7x!qco.qubit>, !qco.qubit) {
      %out_tensor_59, %result_60 = qtensor.extract %arg0[%c0] : tensor<7x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_60) targets (%arg2 = %arg1) {
        %40 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %40 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %39 = qtensor.insert %controls_out into %out_tensor_59[%c0] : tensor<7x!qco.qubit>
      qco.yield %39, %targets_out : tensor<7x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %17, %arg1 = %2) {
      qco.yield %arg0, %arg1 : tensor<7x!qco.qubit>, !qco.qubit
    }
    %linearResults_12:2 = qco.if %false args(%arg0 = %linearResults#0, %arg1 = %linearResults#1) -> (tensor<7x!qco.qubit>, !qco.qubit) {
      %out_tensor_59, %result_60 = qtensor.extract %arg0[%c1] : tensor<7x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_60) targets (%arg2 = %arg1) {
        %40 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %40 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %39 = qtensor.insert %controls_out into %out_tensor_59[%c1] : tensor<7x!qco.qubit>
      qco.yield %39, %targets_out : tensor<7x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults#0, %arg1 = %linearResults#1) {
      qco.yield %arg0, %arg1 : tensor<7x!qco.qubit>, !qco.qubit
    }
    %linearResults_13:2 = qco.if %true args(%arg0 = %linearResults_12#0, %arg1 = %linearResults_12#1) -> (tensor<7x!qco.qubit>, !qco.qubit) {
      %out_tensor_59, %result_60 = qtensor.extract %arg0[%c2] : tensor<7x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_60) targets (%arg2 = %arg1) {
        %40 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %40 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %39 = qtensor.insert %controls_out into %out_tensor_59[%c2] : tensor<7x!qco.qubit>
      qco.yield %39, %targets_out : tensor<7x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_12#0, %arg1 = %linearResults_12#1) {
      qco.yield %arg0, %arg1 : tensor<7x!qco.qubit>, !qco.qubit
    }
    %linearResults_14:2 = qco.if %false args(%arg0 = %linearResults_13#0, %arg1 = %linearResults_13#1) -> (tensor<7x!qco.qubit>, !qco.qubit) {
      %out_tensor_59, %result_60 = qtensor.extract %arg0[%c3] : tensor<7x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_60) targets (%arg2 = %arg1) {
        %40 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %40 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %39 = qtensor.insert %controls_out into %out_tensor_59[%c3] : tensor<7x!qco.qubit>
      qco.yield %39, %targets_out : tensor<7x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_13#0, %arg1 = %linearResults_13#1) {
      qco.yield %arg0, %arg1 : tensor<7x!qco.qubit>, !qco.qubit
    }
    %linearResults_15:2 = qco.if %true args(%arg0 = %linearResults_14#0, %arg1 = %linearResults_14#1) -> (tensor<7x!qco.qubit>, !qco.qubit) {
      %out_tensor_59, %result_60 = qtensor.extract %arg0[%c4] : tensor<7x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_60) targets (%arg2 = %arg1) {
        %40 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %40 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %39 = qtensor.insert %controls_out into %out_tensor_59[%c4] : tensor<7x!qco.qubit>
      qco.yield %39, %targets_out : tensor<7x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_14#0, %arg1 = %linearResults_14#1) {
      qco.yield %arg0, %arg1 : tensor<7x!qco.qubit>, !qco.qubit
    }
    %linearResults_16:2 = qco.if %false args(%arg0 = %linearResults_15#0, %arg1 = %linearResults_15#1) -> (tensor<7x!qco.qubit>, !qco.qubit) {
      %out_tensor_59, %result_60 = qtensor.extract %arg0[%c5] : tensor<7x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_60) targets (%arg2 = %arg1) {
        %40 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %40 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %39 = qtensor.insert %controls_out into %out_tensor_59[%c5] : tensor<7x!qco.qubit>
      qco.yield %39, %targets_out : tensor<7x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_15#0, %arg1 = %linearResults_15#1) {
      qco.yield %arg0, %arg1 : tensor<7x!qco.qubit>, !qco.qubit
    }
    %linearResults_17:2 = qco.if %true args(%arg0 = %linearResults_16#0, %arg1 = %linearResults_16#1) -> (tensor<7x!qco.qubit>, !qco.qubit) {
      %out_tensor_59, %result_60 = qtensor.extract %arg0[%c6] : tensor<7x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_60) targets (%arg2 = %arg1) {
        %40 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %40 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %39 = qtensor.insert %controls_out into %out_tensor_59[%c6] : tensor<7x!qco.qubit>
      qco.yield %39, %targets_out : tensor<7x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_16#0, %arg1 = %linearResults_16#1) {
      qco.yield %arg0, %arg1 : tensor<7x!qco.qubit>, !qco.qubit
    }
    %out_tensor_18, %result_19 = qtensor.extract %linearResults_17#0[%c0] : tensor<7x!qco.qubit>
    %18 = qco.h %result_19 : !qco.qubit -> !qco.qubit
    %19 = qtensor.insert %18 into %out_tensor_18[%c0] : tensor<7x!qco.qubit>
    %out_tensor_20, %result_21 = qtensor.extract %19[%c1] : tensor<7x!qco.qubit>
    %20 = qco.h %result_21 : !qco.qubit -> !qco.qubit
    %21 = qtensor.insert %20 into %out_tensor_20[%c1] : tensor<7x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %21[%c2] : tensor<7x!qco.qubit>
    %22 = qco.h %result_23 : !qco.qubit -> !qco.qubit
    %23 = qtensor.insert %22 into %out_tensor_22[%c2] : tensor<7x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %23[%c3] : tensor<7x!qco.qubit>
    %24 = qco.h %result_25 : !qco.qubit -> !qco.qubit
    %25 = qtensor.insert %24 into %out_tensor_24[%c3] : tensor<7x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %25[%c4] : tensor<7x!qco.qubit>
    %26 = qco.h %result_27 : !qco.qubit -> !qco.qubit
    %27 = qtensor.insert %26 into %out_tensor_26[%c4] : tensor<7x!qco.qubit>
    %out_tensor_28, %result_29 = qtensor.extract %27[%c5] : tensor<7x!qco.qubit>
    %28 = qco.h %result_29 : !qco.qubit -> !qco.qubit
    %29 = qtensor.insert %28 into %out_tensor_28[%c5] : tensor<7x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %29[%c6] : tensor<7x!qco.qubit>
    %30 = qco.h %result_31 : !qco.qubit -> !qco.qubit
    %31 = qtensor.insert %30 into %out_tensor_30[%c6] : tensor<7x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %31[%c0] : tensor<7x!qco.qubit>
    %qubit_out, %result_34 = qco.measure %result_33 : !qco.qubit
    %32 = qtensor.insert %qubit_out into %out_tensor_32[%c0] : tensor<7x!qco.qubit>
    cbit.store %result_34, %1[%c0] : !cbit.reg<7>
    %out_tensor_35, %result_36 = qtensor.extract %32[%c1] : tensor<7x!qco.qubit>
    %qubit_out_37, %result_38 = qco.measure %result_36 : !qco.qubit
    %33 = qtensor.insert %qubit_out_37 into %out_tensor_35[%c1] : tensor<7x!qco.qubit>
    cbit.store %result_38, %1[%c1] : !cbit.reg<7>
    %out_tensor_39, %result_40 = qtensor.extract %33[%c2] : tensor<7x!qco.qubit>
    %qubit_out_41, %result_42 = qco.measure %result_40 : !qco.qubit
    %34 = qtensor.insert %qubit_out_41 into %out_tensor_39[%c2] : tensor<7x!qco.qubit>
    cbit.store %result_42, %1[%c2] : !cbit.reg<7>
    %out_tensor_43, %result_44 = qtensor.extract %34[%c3] : tensor<7x!qco.qubit>
    %qubit_out_45, %result_46 = qco.measure %result_44 : !qco.qubit
    %35 = qtensor.insert %qubit_out_45 into %out_tensor_43[%c3] : tensor<7x!qco.qubit>
    cbit.store %result_46, %1[%c3] : !cbit.reg<7>
    %out_tensor_47, %result_48 = qtensor.extract %35[%c4] : tensor<7x!qco.qubit>
    %qubit_out_49, %result_50 = qco.measure %result_48 : !qco.qubit
    %36 = qtensor.insert %qubit_out_49 into %out_tensor_47[%c4] : tensor<7x!qco.qubit>
    cbit.store %result_50, %1[%c4] : !cbit.reg<7>
    %out_tensor_51, %result_52 = qtensor.extract %36[%c5] : tensor<7x!qco.qubit>
    %qubit_out_53, %result_54 = qco.measure %result_52 : !qco.qubit
    %37 = qtensor.insert %qubit_out_53 into %out_tensor_51[%c5] : tensor<7x!qco.qubit>
    cbit.store %result_54, %1[%c5] : !cbit.reg<7>
    %out_tensor_55, %result_56 = qtensor.extract %37[%c6] : tensor<7x!qco.qubit>
    %qubit_out_57, %result_58 = qco.measure %result_56 : !qco.qubit
    %38 = qtensor.insert %qubit_out_57 into %out_tensor_55[%c6] : tensor<7x!qco.qubit>
    cbit.store %result_58, %1[%c6] : !cbit.reg<7>
    qco.sink %linearResults_17#1 : !qco.qubit
    qtensor.dealloc %38 : tensor<7x!qco.qubit>
    return %1 : !cbit.reg<7>
  }
}
