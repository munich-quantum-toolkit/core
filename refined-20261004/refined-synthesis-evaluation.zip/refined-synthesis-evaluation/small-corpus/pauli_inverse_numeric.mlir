module {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %c0_i64 = arith.constant 0 : i64
    %cst = arith.constant -3.700000e-01 : f64
    %cst_0 = arith.constant 3.700000e-01 : f64
    %cst_1 = arith.constant 0.000000e+00 : f64
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %0 = qtensor.alloc(%c2) {mqt.register_name = "q"} : tensor<2x!qco.qubit>
    qco.gphase(%cst_1)
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<2x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %out_tensor[%c1] : tensor<2x!qco.qubit>
    %qubit0_out, %qubit1_out = qco.rzz(%cst_0) %result, %result_3 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %1 = qtensor.insert %qubit1_out into %out_tensor_2[%c1] : tensor<2x!qco.qubit>
    %2 = qtensor.insert %qubit0_out into %1[%c0] : tensor<2x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %2[%c0] : tensor<2x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %out_tensor_4[%c1] : tensor<2x!qco.qubit>
    %qubit0_out_8, %qubit1_out_9 = qco.rzz(%cst) %result_5, %result_7 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %3 = qtensor.insert %qubit1_out_9 into %out_tensor_6[%c1] : tensor<2x!qco.qubit>
    %4 = qtensor.insert %qubit0_out_8 into %3[%c0] : tensor<2x!qco.qubit>
    qtensor.dealloc %4 : tensor<2x!qco.qubit>
    return %c0_i64 : i64
  }
}
