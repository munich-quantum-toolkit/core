module {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant -0.39269908169872414 : f64
    %cst_0 = arith.constant -0.78539816339744828 : f64
    %cst_1 = arith.constant 0.39269908169872414 : f64
    %cst_2 = arith.constant 0.78539816339744828 : f64
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %cst_3 = arith.constant -1.5707963267948966 : f64
    %cst_4 = arith.constant 3.1415926535897931 : f64
    %cst_5 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %0 = qtensor.alloc(%c4) {mqt.register_name = "addend"} : tensor<4x!qco.qubit>
    %out_tensor, %result = qtensor.extract %0[%c3] : tensor<4x!qco.qubit>
    %1 = qco.x %result : !qco.qubit -> !qco.qubit
    %2 = qtensor.insert %1 into %out_tensor[%c3] : tensor<4x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %2[%c1] : tensor<4x!qco.qubit>
    %3 = qco.x %result_7 : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor_6[%c1] : tensor<4x!qco.qubit>
    %5 = qtensor.alloc(%c4) {mqt.register_name = "sum"} : tensor<4x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %5[%c2] : tensor<4x!qco.qubit>
    %6 = qco.x %result_9 : !qco.qubit -> !qco.qubit
    %7 = qtensor.insert %6 into %out_tensor_8[%c2] : tensor<4x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %7[%c0] : tensor<4x!qco.qubit>
    %8 = qco.x %result_11 : !qco.qubit -> !qco.qubit
    %9 = qtensor.insert %8 into %out_tensor_10[%c0] : tensor<4x!qco.qubit>
    %10 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %out_tensor_12, %result_13 = qtensor.extract %9[%c3] : tensor<4x!qco.qubit>
    %11 = qco.h %result_13 : !qco.qubit -> !qco.qubit
    %12 = qtensor.insert %11 into %out_tensor_12[%c3] : tensor<4x!qco.qubit>
    %out_tensor_14, %result_15 = qtensor.extract %12[%c2] : tensor<4x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %out_tensor_14[%c3] : tensor<4x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_15) targets (%arg0 = %result_17) {
      %79 = qco.p(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %13 = qtensor.insert %targets_out into %out_tensor_16[%c3] : tensor<4x!qco.qubit>
    %14 = qtensor.insert %controls_out into %13[%c2] : tensor<4x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %14[%c1] : tensor<4x!qco.qubit>
    %out_tensor_20, %result_21 = qtensor.extract %out_tensor_18[%c3] : tensor<4x!qco.qubit>
    %controls_out_22, %targets_out_23 = qco.ctrl(%result_19) targets (%arg0 = %result_21) {
      %79 = qco.p(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qtensor.insert %targets_out_23 into %out_tensor_20[%c3] : tensor<4x!qco.qubit>
    %16 = qtensor.insert %controls_out_22 into %15[%c1] : tensor<4x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %16[%c0] : tensor<4x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %out_tensor_24[%c3] : tensor<4x!qco.qubit>
    %controls_out_28, %targets_out_29 = qco.ctrl(%result_25) targets (%arg0 = %result_27) {
      %79 = qco.p(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qtensor.insert %targets_out_29 into %out_tensor_26[%c3] : tensor<4x!qco.qubit>
    %18 = qtensor.insert %controls_out_28 into %17[%c0] : tensor<4x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %18[%c2] : tensor<4x!qco.qubit>
    %19 = qco.h %result_31 : !qco.qubit -> !qco.qubit
    %20 = qtensor.insert %19 into %out_tensor_30[%c2] : tensor<4x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %20[%c1] : tensor<4x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %out_tensor_32[%c2] : tensor<4x!qco.qubit>
    %controls_out_36, %targets_out_37 = qco.ctrl(%result_33) targets (%arg0 = %result_35) {
      %79 = qco.p(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qtensor.insert %targets_out_37 into %out_tensor_34[%c2] : tensor<4x!qco.qubit>
    %22 = qtensor.insert %controls_out_36 into %21[%c1] : tensor<4x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %22[%c0] : tensor<4x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %out_tensor_38[%c2] : tensor<4x!qco.qubit>
    %controls_out_42, %targets_out_43 = qco.ctrl(%result_39) targets (%arg0 = %result_41) {
      %79 = qco.p(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qtensor.insert %targets_out_43 into %out_tensor_40[%c2] : tensor<4x!qco.qubit>
    %24 = qtensor.insert %controls_out_42 into %23[%c0] : tensor<4x!qco.qubit>
    %out_tensor_44, %result_45 = qtensor.extract %24[%c1] : tensor<4x!qco.qubit>
    %25 = qco.h %result_45 : !qco.qubit -> !qco.qubit
    %26 = qtensor.insert %25 into %out_tensor_44[%c1] : tensor<4x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %26[%c0] : tensor<4x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %out_tensor_46[%c1] : tensor<4x!qco.qubit>
    %controls_out_50, %targets_out_51 = qco.ctrl(%result_47) targets (%arg0 = %result_49) {
      %79 = qco.p(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %27 = qtensor.insert %targets_out_51 into %out_tensor_48[%c1] : tensor<4x!qco.qubit>
    %28 = qtensor.insert %controls_out_50 into %27[%c0] : tensor<4x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %28[%c0] : tensor<4x!qco.qubit>
    %29 = qco.h %result_53 : !qco.qubit -> !qco.qubit
    %30 = qtensor.insert %29 into %out_tensor_52[%c0] : tensor<4x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %4[%c3] : tensor<4x!qco.qubit>
    %out_tensor_56, %result_57 = qtensor.extract %30[%c3] : tensor<4x!qco.qubit>
    %controls_out_58, %targets_out_59 = qco.ctrl(%result_55) targets (%arg0 = %result_57) {
      %79 = qco.p(%cst_4) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qtensor.insert %targets_out_59 into %out_tensor_56[%c3] : tensor<4x!qco.qubit>
    %32 = qtensor.insert %controls_out_58 into %out_tensor_54[%c3] : tensor<4x!qco.qubit>
    %out_tensor_60, %result_61 = qtensor.extract %32[%c2] : tensor<4x!qco.qubit>
    %out_tensor_62, %result_63 = qtensor.extract %31[%c3] : tensor<4x!qco.qubit>
    %controls_out_64, %targets_out_65 = qco.ctrl(%result_61) targets (%arg0 = %result_63) {
      %79 = qco.p(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %33 = qtensor.insert %targets_out_65 into %out_tensor_62[%c3] : tensor<4x!qco.qubit>
    %34 = qtensor.insert %controls_out_64 into %out_tensor_60[%c2] : tensor<4x!qco.qubit>
    %out_tensor_66, %result_67 = qtensor.extract %34[%c1] : tensor<4x!qco.qubit>
    %out_tensor_68, %result_69 = qtensor.extract %33[%c3] : tensor<4x!qco.qubit>
    %controls_out_70, %targets_out_71 = qco.ctrl(%result_67) targets (%arg0 = %result_69) {
      %79 = qco.p(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qtensor.insert %targets_out_71 into %out_tensor_68[%c3] : tensor<4x!qco.qubit>
    %36 = qtensor.insert %controls_out_70 into %out_tensor_66[%c1] : tensor<4x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %36[%c0] : tensor<4x!qco.qubit>
    %out_tensor_74, %result_75 = qtensor.extract %35[%c3] : tensor<4x!qco.qubit>
    %controls_out_76, %targets_out_77 = qco.ctrl(%result_73) targets (%arg0 = %result_75) {
      %79 = qco.p(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qtensor.insert %targets_out_77 into %out_tensor_74[%c3] : tensor<4x!qco.qubit>
    %38 = qtensor.insert %controls_out_76 into %out_tensor_72[%c0] : tensor<4x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %38[%c2] : tensor<4x!qco.qubit>
    %out_tensor_80, %result_81 = qtensor.extract %37[%c2] : tensor<4x!qco.qubit>
    %controls_out_82, %targets_out_83 = qco.ctrl(%result_79) targets (%arg0 = %result_81) {
      %79 = qco.p(%cst_4) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qtensor.insert %targets_out_83 into %out_tensor_80[%c2] : tensor<4x!qco.qubit>
    %40 = qtensor.insert %controls_out_82 into %out_tensor_78[%c2] : tensor<4x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %40[%c1] : tensor<4x!qco.qubit>
    %out_tensor_86, %result_87 = qtensor.extract %39[%c2] : tensor<4x!qco.qubit>
    %controls_out_88, %targets_out_89 = qco.ctrl(%result_85) targets (%arg0 = %result_87) {
      %79 = qco.p(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qtensor.insert %targets_out_89 into %out_tensor_86[%c2] : tensor<4x!qco.qubit>
    %42 = qtensor.insert %controls_out_88 into %out_tensor_84[%c1] : tensor<4x!qco.qubit>
    %out_tensor_90, %result_91 = qtensor.extract %42[%c0] : tensor<4x!qco.qubit>
    %out_tensor_92, %result_93 = qtensor.extract %41[%c2] : tensor<4x!qco.qubit>
    %controls_out_94, %targets_out_95 = qco.ctrl(%result_91) targets (%arg0 = %result_93) {
      %79 = qco.p(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qtensor.insert %targets_out_95 into %out_tensor_92[%c2] : tensor<4x!qco.qubit>
    %44 = qtensor.insert %controls_out_94 into %out_tensor_90[%c0] : tensor<4x!qco.qubit>
    %out_tensor_96, %result_97 = qtensor.extract %44[%c1] : tensor<4x!qco.qubit>
    %out_tensor_98, %result_99 = qtensor.extract %43[%c1] : tensor<4x!qco.qubit>
    %controls_out_100, %targets_out_101 = qco.ctrl(%result_97) targets (%arg0 = %result_99) {
      %79 = qco.p(%cst_4) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qtensor.insert %targets_out_101 into %out_tensor_98[%c1] : tensor<4x!qco.qubit>
    %46 = qtensor.insert %controls_out_100 into %out_tensor_96[%c1] : tensor<4x!qco.qubit>
    %out_tensor_102, %result_103 = qtensor.extract %46[%c0] : tensor<4x!qco.qubit>
    %out_tensor_104, %result_105 = qtensor.extract %45[%c1] : tensor<4x!qco.qubit>
    %controls_out_106, %targets_out_107 = qco.ctrl(%result_103) targets (%arg0 = %result_105) {
      %79 = qco.p(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qtensor.insert %targets_out_107 into %out_tensor_104[%c1] : tensor<4x!qco.qubit>
    %48 = qtensor.insert %controls_out_106 into %out_tensor_102[%c0] : tensor<4x!qco.qubit>
    %out_tensor_108, %result_109 = qtensor.extract %48[%c0] : tensor<4x!qco.qubit>
    %out_tensor_110, %result_111 = qtensor.extract %47[%c0] : tensor<4x!qco.qubit>
    %controls_out_112, %targets_out_113 = qco.ctrl(%result_109) targets (%arg0 = %result_111) {
      %79 = qco.p(%cst_4) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qtensor.insert %targets_out_113 into %out_tensor_110[%c0] : tensor<4x!qco.qubit>
    %50 = qtensor.insert %controls_out_112 into %out_tensor_108[%c0] : tensor<4x!qco.qubit>
    %out_tensor_114, %result_115 = qtensor.extract %49[%c0] : tensor<4x!qco.qubit>
    %51 = qco.h %result_115 : !qco.qubit -> !qco.qubit
    %52 = qtensor.insert %51 into %out_tensor_114[%c0] : tensor<4x!qco.qubit>
    %out_tensor_116, %result_117 = qtensor.extract %52[%c0] : tensor<4x!qco.qubit>
    %out_tensor_118, %result_119 = qtensor.extract %out_tensor_116[%c1] : tensor<4x!qco.qubit>
    %controls_out_120, %targets_out_121 = qco.ctrl(%result_117) targets (%arg0 = %result_119) {
      %79 = qco.p(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qtensor.insert %targets_out_121 into %out_tensor_118[%c1] : tensor<4x!qco.qubit>
    %54 = qtensor.insert %controls_out_120 into %53[%c0] : tensor<4x!qco.qubit>
    %out_tensor_122, %result_123 = qtensor.extract %54[%c1] : tensor<4x!qco.qubit>
    %55 = qco.h %result_123 : !qco.qubit -> !qco.qubit
    %56 = qtensor.insert %55 into %out_tensor_122[%c1] : tensor<4x!qco.qubit>
    %out_tensor_124, %result_125 = qtensor.extract %56[%c1] : tensor<4x!qco.qubit>
    %out_tensor_126, %result_127 = qtensor.extract %out_tensor_124[%c2] : tensor<4x!qco.qubit>
    %controls_out_128, %targets_out_129 = qco.ctrl(%result_125) targets (%arg0 = %result_127) {
      %79 = qco.p(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %57 = qtensor.insert %targets_out_129 into %out_tensor_126[%c2] : tensor<4x!qco.qubit>
    %58 = qtensor.insert %controls_out_128 into %57[%c1] : tensor<4x!qco.qubit>
    %out_tensor_130, %result_131 = qtensor.extract %58[%c0] : tensor<4x!qco.qubit>
    %out_tensor_132, %result_133 = qtensor.extract %out_tensor_130[%c2] : tensor<4x!qco.qubit>
    %controls_out_134, %targets_out_135 = qco.ctrl(%result_131) targets (%arg0 = %result_133) {
      %79 = qco.p(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qtensor.insert %targets_out_135 into %out_tensor_132[%c2] : tensor<4x!qco.qubit>
    %60 = qtensor.insert %controls_out_134 into %59[%c0] : tensor<4x!qco.qubit>
    %out_tensor_136, %result_137 = qtensor.extract %60[%c2] : tensor<4x!qco.qubit>
    %61 = qco.h %result_137 : !qco.qubit -> !qco.qubit
    %62 = qtensor.insert %61 into %out_tensor_136[%c2] : tensor<4x!qco.qubit>
    %out_tensor_138, %result_139 = qtensor.extract %62[%c2] : tensor<4x!qco.qubit>
    %out_tensor_140, %result_141 = qtensor.extract %out_tensor_138[%c3] : tensor<4x!qco.qubit>
    %controls_out_142, %targets_out_143 = qco.ctrl(%result_139) targets (%arg0 = %result_141) {
      %79 = qco.p(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %63 = qtensor.insert %targets_out_143 into %out_tensor_140[%c3] : tensor<4x!qco.qubit>
    %64 = qtensor.insert %controls_out_142 into %63[%c2] : tensor<4x!qco.qubit>
    %out_tensor_144, %result_145 = qtensor.extract %64[%c1] : tensor<4x!qco.qubit>
    %out_tensor_146, %result_147 = qtensor.extract %out_tensor_144[%c3] : tensor<4x!qco.qubit>
    %controls_out_148, %targets_out_149 = qco.ctrl(%result_145) targets (%arg0 = %result_147) {
      %79 = qco.p(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qtensor.insert %targets_out_149 into %out_tensor_146[%c3] : tensor<4x!qco.qubit>
    %66 = qtensor.insert %controls_out_148 into %65[%c1] : tensor<4x!qco.qubit>
    %out_tensor_150, %result_151 = qtensor.extract %66[%c0] : tensor<4x!qco.qubit>
    %out_tensor_152, %result_153 = qtensor.extract %out_tensor_150[%c3] : tensor<4x!qco.qubit>
    %controls_out_154, %targets_out_155 = qco.ctrl(%result_151) targets (%arg0 = %result_153) {
      %79 = qco.p(%cst) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %79 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %67 = qtensor.insert %targets_out_155 into %out_tensor_152[%c3] : tensor<4x!qco.qubit>
    %68 = qtensor.insert %controls_out_154 into %67[%c0] : tensor<4x!qco.qubit>
    %out_tensor_156, %result_157 = qtensor.extract %68[%c3] : tensor<4x!qco.qubit>
    %69 = qco.h %result_157 : !qco.qubit -> !qco.qubit
    %70 = qtensor.insert %69 into %out_tensor_156[%c3] : tensor<4x!qco.qubit>
    %out_tensor_158, %result_159 = qtensor.extract %70[%c0] : tensor<4x!qco.qubit>
    %qubit_out, %result_160 = qco.measure %result_159 : !qco.qubit
    %71 = qtensor.insert %qubit_out into %out_tensor_158[%c0] : tensor<4x!qco.qubit>
    cbit.store %result_160, %10[%c0] : !cbit.reg<8>
    %out_tensor_161, %result_162 = qtensor.extract %71[%c1] : tensor<4x!qco.qubit>
    %qubit_out_163, %result_164 = qco.measure %result_162 : !qco.qubit
    %72 = qtensor.insert %qubit_out_163 into %out_tensor_161[%c1] : tensor<4x!qco.qubit>
    cbit.store %result_164, %10[%c1] : !cbit.reg<8>
    %out_tensor_165, %result_166 = qtensor.extract %72[%c2] : tensor<4x!qco.qubit>
    %qubit_out_167, %result_168 = qco.measure %result_166 : !qco.qubit
    %73 = qtensor.insert %qubit_out_167 into %out_tensor_165[%c2] : tensor<4x!qco.qubit>
    cbit.store %result_168, %10[%c2] : !cbit.reg<8>
    %out_tensor_169, %result_170 = qtensor.extract %73[%c3] : tensor<4x!qco.qubit>
    %qubit_out_171, %result_172 = qco.measure %result_170 : !qco.qubit
    %74 = qtensor.insert %qubit_out_171 into %out_tensor_169[%c3] : tensor<4x!qco.qubit>
    cbit.store %result_172, %10[%c3] : !cbit.reg<8>
    %out_tensor_173, %result_174 = qtensor.extract %50[%c0] : tensor<4x!qco.qubit>
    %qubit_out_175, %result_176 = qco.measure %result_174 : !qco.qubit
    %75 = qtensor.insert %qubit_out_175 into %out_tensor_173[%c0] : tensor<4x!qco.qubit>
    cbit.store %result_176, %10[%c4] : !cbit.reg<8>
    %out_tensor_177, %result_178 = qtensor.extract %75[%c1] : tensor<4x!qco.qubit>
    %qubit_out_179, %result_180 = qco.measure %result_178 : !qco.qubit
    %76 = qtensor.insert %qubit_out_179 into %out_tensor_177[%c1] : tensor<4x!qco.qubit>
    cbit.store %result_180, %10[%c5] : !cbit.reg<8>
    %out_tensor_181, %result_182 = qtensor.extract %76[%c2] : tensor<4x!qco.qubit>
    %qubit_out_183, %result_184 = qco.measure %result_182 : !qco.qubit
    %77 = qtensor.insert %qubit_out_183 into %out_tensor_181[%c2] : tensor<4x!qco.qubit>
    cbit.store %result_184, %10[%c6] : !cbit.reg<8>
    %out_tensor_185, %result_186 = qtensor.extract %77[%c3] : tensor<4x!qco.qubit>
    %qubit_out_187, %result_188 = qco.measure %result_186 : !qco.qubit
    %78 = qtensor.insert %qubit_out_187 into %out_tensor_185[%c3] : tensor<4x!qco.qubit>
    cbit.store %result_188, %10[%c7] : !cbit.reg<8>
    qtensor.dealloc %78 : tensor<4x!qco.qubit>
    qtensor.dealloc %74 : tensor<4x!qco.qubit>
    return %10 : !cbit.reg<8>
  }
}
