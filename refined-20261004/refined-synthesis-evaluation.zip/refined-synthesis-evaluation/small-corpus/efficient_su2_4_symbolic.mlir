module {
  func.func @main(%arg0: f64 {mqt.input_id = -120262898746132594670008414538420507071 : i128, mqt.input_name = "\CE\B8[0]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 0 : i64, name = "\CE\B8", size = 32 : i64}}, %arg1: f64 {mqt.input_id = -120262898746132594670008414538420507070 : i128, mqt.input_name = "\CE\B8[1]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 1 : i64, name = "\CE\B8", size = 32 : i64}}, %arg2: f64 {mqt.input_id = -120262898746132594670008414538420507069 : i128, mqt.input_name = "\CE\B8[2]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 2 : i64, name = "\CE\B8", size = 32 : i64}}, %arg3: f64 {mqt.input_id = -120262898746132594670008414538420507068 : i128, mqt.input_name = "\CE\B8[3]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 3 : i64, name = "\CE\B8", size = 32 : i64}}, %arg4: f64 {mqt.input_id = -120262898746132594670008414538420507067 : i128, mqt.input_name = "\CE\B8[4]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 4 : i64, name = "\CE\B8", size = 32 : i64}}, %arg5: f64 {mqt.input_id = -120262898746132594670008414538420507066 : i128, mqt.input_name = "\CE\B8[5]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 5 : i64, name = "\CE\B8", size = 32 : i64}}, %arg6: f64 {mqt.input_id = -120262898746132594670008414538420507065 : i128, mqt.input_name = "\CE\B8[6]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 6 : i64, name = "\CE\B8", size = 32 : i64}}, %arg7: f64 {mqt.input_id = -120262898746132594670008414538420507064 : i128, mqt.input_name = "\CE\B8[7]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 7 : i64, name = "\CE\B8", size = 32 : i64}}, %arg8: f64 {mqt.input_id = -120262898746132594670008414538420507063 : i128, mqt.input_name = "\CE\B8[8]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 8 : i64, name = "\CE\B8", size = 32 : i64}}, %arg9: f64 {mqt.input_id = -120262898746132594670008414538420507062 : i128, mqt.input_name = "\CE\B8[9]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 9 : i64, name = "\CE\B8", size = 32 : i64}}, %arg10: f64 {mqt.input_id = -120262898746132594670008414538420507061 : i128, mqt.input_name = "\CE\B8[10]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 10 : i64, name = "\CE\B8", size = 32 : i64}}, %arg11: f64 {mqt.input_id = -120262898746132594670008414538420507060 : i128, mqt.input_name = "\CE\B8[11]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 11 : i64, name = "\CE\B8", size = 32 : i64}}, %arg12: f64 {mqt.input_id = -120262898746132594670008414538420507059 : i128, mqt.input_name = "\CE\B8[12]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 12 : i64, name = "\CE\B8", size = 32 : i64}}, %arg13: f64 {mqt.input_id = -120262898746132594670008414538420507058 : i128, mqt.input_name = "\CE\B8[13]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 13 : i64, name = "\CE\B8", size = 32 : i64}}, %arg14: f64 {mqt.input_id = -120262898746132594670008414538420507057 : i128, mqt.input_name = "\CE\B8[14]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 14 : i64, name = "\CE\B8", size = 32 : i64}}, %arg15: f64 {mqt.input_id = -120262898746132594670008414538420507056 : i128, mqt.input_name = "\CE\B8[15]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 15 : i64, name = "\CE\B8", size = 32 : i64}}, %arg16: f64 {mqt.input_id = -120262898746132594670008414538420507055 : i128, mqt.input_name = "\CE\B8[16]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 16 : i64, name = "\CE\B8", size = 32 : i64}}, %arg17: f64 {mqt.input_id = -120262898746132594670008414538420507054 : i128, mqt.input_name = "\CE\B8[17]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 17 : i64, name = "\CE\B8", size = 32 : i64}}, %arg18: f64 {mqt.input_id = -120262898746132594670008414538420507053 : i128, mqt.input_name = "\CE\B8[18]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 18 : i64, name = "\CE\B8", size = 32 : i64}}, %arg19: f64 {mqt.input_id = -120262898746132594670008414538420507052 : i128, mqt.input_name = "\CE\B8[19]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 19 : i64, name = "\CE\B8", size = 32 : i64}}, %arg20: f64 {mqt.input_id = -120262898746132594670008414538420507051 : i128, mqt.input_name = "\CE\B8[20]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 20 : i64, name = "\CE\B8", size = 32 : i64}}, %arg21: f64 {mqt.input_id = -120262898746132594670008414538420507050 : i128, mqt.input_name = "\CE\B8[21]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 21 : i64, name = "\CE\B8", size = 32 : i64}}, %arg22: f64 {mqt.input_id = -120262898746132594670008414538420507049 : i128, mqt.input_name = "\CE\B8[22]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 22 : i64, name = "\CE\B8", size = 32 : i64}}, %arg23: f64 {mqt.input_id = -120262898746132594670008414538420507048 : i128, mqt.input_name = "\CE\B8[23]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 23 : i64, name = "\CE\B8", size = 32 : i64}}, %arg24: f64 {mqt.input_id = -120262898746132594670008414538420507047 : i128, mqt.input_name = "\CE\B8[24]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 24 : i64, name = "\CE\B8", size = 32 : i64}}, %arg25: f64 {mqt.input_id = -120262898746132594670008414538420507046 : i128, mqt.input_name = "\CE\B8[25]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 25 : i64, name = "\CE\B8", size = 32 : i64}}, %arg26: f64 {mqt.input_id = -120262898746132594670008414538420507045 : i128, mqt.input_name = "\CE\B8[26]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 26 : i64, name = "\CE\B8", size = 32 : i64}}, %arg27: f64 {mqt.input_id = -120262898746132594670008414538420507044 : i128, mqt.input_name = "\CE\B8[27]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 27 : i64, name = "\CE\B8", size = 32 : i64}}, %arg28: f64 {mqt.input_id = -120262898746132594670008414538420507043 : i128, mqt.input_name = "\CE\B8[28]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 28 : i64, name = "\CE\B8", size = 32 : i64}}, %arg29: f64 {mqt.input_id = -120262898746132594670008414538420507042 : i128, mqt.input_name = "\CE\B8[29]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 29 : i64, name = "\CE\B8", size = 32 : i64}}, %arg30: f64 {mqt.input_id = -120262898746132594670008414538420507041 : i128, mqt.input_name = "\CE\B8[30]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 30 : i64, name = "\CE\B8", size = 32 : i64}}, %arg31: f64 {mqt.input_id = -120262898746132594670008414538420507040 : i128, mqt.input_name = "\CE\B8[31]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 31 : i64, name = "\CE\B8", size = 32 : i64}}) -> i64 attributes {mqt.entry_point} {
    %c0_i64 = arith.constant 0 : i64
    %cst = arith.constant 0.000000e+00 : f64
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c4 = arith.constant 4 : index
    %0 = qtensor.alloc(%c4) {mqt.register_name = "q"} : tensor<4x!qco.qubit>
    qco.gphase(%cst)
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<4x!qco.qubit>
    %1 = qco.ry(%arg0) %result : !qco.qubit -> !qco.qubit
    %2 = qtensor.insert %1 into %out_tensor[%c0] : tensor<4x!qco.qubit>
    %out_tensor_0, %result_1 = qtensor.extract %2[%c1] : tensor<4x!qco.qubit>
    %3 = qco.ry(%arg1) %result_1 : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor_0[%c1] : tensor<4x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %4[%c2] : tensor<4x!qco.qubit>
    %5 = qco.ry(%arg2) %result_3 : !qco.qubit -> !qco.qubit
    %6 = qtensor.insert %5 into %out_tensor_2[%c2] : tensor<4x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %6[%c3] : tensor<4x!qco.qubit>
    %7 = qco.ry(%arg3) %result_5 : !qco.qubit -> !qco.qubit
    %8 = qtensor.insert %7 into %out_tensor_4[%c3] : tensor<4x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %8[%c0] : tensor<4x!qco.qubit>
    %9 = qco.rz(%arg4) %result_7 : !qco.qubit -> !qco.qubit
    %10 = qtensor.insert %9 into %out_tensor_6[%c0] : tensor<4x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %10[%c1] : tensor<4x!qco.qubit>
    %11 = qco.rz(%arg5) %result_9 : !qco.qubit -> !qco.qubit
    %12 = qtensor.insert %11 into %out_tensor_8[%c1] : tensor<4x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %12[%c2] : tensor<4x!qco.qubit>
    %13 = qco.rz(%arg6) %result_11 : !qco.qubit -> !qco.qubit
    %14 = qtensor.insert %13 into %out_tensor_10[%c2] : tensor<4x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %14[%c3] : tensor<4x!qco.qubit>
    %15 = qco.rz(%arg7) %result_13 : !qco.qubit -> !qco.qubit
    %16 = qtensor.insert %15 into %out_tensor_12[%c3] : tensor<4x!qco.qubit>
    %out_tensor_14, %result_15 = qtensor.extract %16[%c3] : tensor<4x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %out_tensor_14[%c0] : tensor<4x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_15) targets (%arg32 = %result_17) {
      %89 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qtensor.insert %targets_out into %out_tensor_16[%c0] : tensor<4x!qco.qubit>
    %18 = qtensor.insert %controls_out into %17[%c3] : tensor<4x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %18[%c0] : tensor<4x!qco.qubit>
    %out_tensor_20, %result_21 = qtensor.extract %out_tensor_18[%c1] : tensor<4x!qco.qubit>
    %controls_out_22, %targets_out_23 = qco.ctrl(%result_19) targets (%arg32 = %result_21) {
      %89 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qtensor.insert %targets_out_23 into %out_tensor_20[%c1] : tensor<4x!qco.qubit>
    %20 = qtensor.insert %controls_out_22 into %19[%c0] : tensor<4x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %20[%c1] : tensor<4x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %out_tensor_24[%c2] : tensor<4x!qco.qubit>
    %controls_out_28, %targets_out_29 = qco.ctrl(%result_25) targets (%arg32 = %result_27) {
      %89 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qtensor.insert %targets_out_29 into %out_tensor_26[%c2] : tensor<4x!qco.qubit>
    %22 = qtensor.insert %controls_out_28 into %21[%c1] : tensor<4x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %22[%c2] : tensor<4x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %out_tensor_30[%c3] : tensor<4x!qco.qubit>
    %controls_out_34, %targets_out_35 = qco.ctrl(%result_31) targets (%arg32 = %result_33) {
      %89 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qtensor.insert %targets_out_35 into %out_tensor_32[%c3] : tensor<4x!qco.qubit>
    %24 = qtensor.insert %controls_out_34 into %23[%c2] : tensor<4x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %24[%c0] : tensor<4x!qco.qubit>
    %25 = qco.ry(%arg8) %result_37 : !qco.qubit -> !qco.qubit
    %26 = qtensor.insert %25 into %out_tensor_36[%c0] : tensor<4x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %26[%c1] : tensor<4x!qco.qubit>
    %27 = qco.ry(%arg9) %result_39 : !qco.qubit -> !qco.qubit
    %28 = qtensor.insert %27 into %out_tensor_38[%c1] : tensor<4x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %28[%c2] : tensor<4x!qco.qubit>
    %29 = qco.ry(%arg10) %result_41 : !qco.qubit -> !qco.qubit
    %30 = qtensor.insert %29 into %out_tensor_40[%c2] : tensor<4x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %30[%c3] : tensor<4x!qco.qubit>
    %31 = qco.ry(%arg11) %result_43 : !qco.qubit -> !qco.qubit
    %32 = qtensor.insert %31 into %out_tensor_42[%c3] : tensor<4x!qco.qubit>
    %out_tensor_44, %result_45 = qtensor.extract %32[%c0] : tensor<4x!qco.qubit>
    %33 = qco.rz(%arg12) %result_45 : !qco.qubit -> !qco.qubit
    %34 = qtensor.insert %33 into %out_tensor_44[%c0] : tensor<4x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %34[%c1] : tensor<4x!qco.qubit>
    %35 = qco.rz(%arg13) %result_47 : !qco.qubit -> !qco.qubit
    %36 = qtensor.insert %35 into %out_tensor_46[%c1] : tensor<4x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %36[%c2] : tensor<4x!qco.qubit>
    %37 = qco.rz(%arg14) %result_49 : !qco.qubit -> !qco.qubit
    %38 = qtensor.insert %37 into %out_tensor_48[%c2] : tensor<4x!qco.qubit>
    %out_tensor_50, %result_51 = qtensor.extract %38[%c3] : tensor<4x!qco.qubit>
    %39 = qco.rz(%arg15) %result_51 : !qco.qubit -> !qco.qubit
    %40 = qtensor.insert %39 into %out_tensor_50[%c3] : tensor<4x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %40[%c3] : tensor<4x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %out_tensor_52[%c0] : tensor<4x!qco.qubit>
    %controls_out_56, %targets_out_57 = qco.ctrl(%result_53) targets (%arg32 = %result_55) {
      %89 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qtensor.insert %targets_out_57 into %out_tensor_54[%c0] : tensor<4x!qco.qubit>
    %42 = qtensor.insert %controls_out_56 into %41[%c3] : tensor<4x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %42[%c0] : tensor<4x!qco.qubit>
    %out_tensor_60, %result_61 = qtensor.extract %out_tensor_58[%c1] : tensor<4x!qco.qubit>
    %controls_out_62, %targets_out_63 = qco.ctrl(%result_59) targets (%arg32 = %result_61) {
      %89 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qtensor.insert %targets_out_63 into %out_tensor_60[%c1] : tensor<4x!qco.qubit>
    %44 = qtensor.insert %controls_out_62 into %43[%c0] : tensor<4x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %44[%c1] : tensor<4x!qco.qubit>
    %out_tensor_66, %result_67 = qtensor.extract %out_tensor_64[%c2] : tensor<4x!qco.qubit>
    %controls_out_68, %targets_out_69 = qco.ctrl(%result_65) targets (%arg32 = %result_67) {
      %89 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qtensor.insert %targets_out_69 into %out_tensor_66[%c2] : tensor<4x!qco.qubit>
    %46 = qtensor.insert %controls_out_68 into %45[%c1] : tensor<4x!qco.qubit>
    %out_tensor_70, %result_71 = qtensor.extract %46[%c2] : tensor<4x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %out_tensor_70[%c3] : tensor<4x!qco.qubit>
    %controls_out_74, %targets_out_75 = qco.ctrl(%result_71) targets (%arg32 = %result_73) {
      %89 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qtensor.insert %targets_out_75 into %out_tensor_72[%c3] : tensor<4x!qco.qubit>
    %48 = qtensor.insert %controls_out_74 into %47[%c2] : tensor<4x!qco.qubit>
    %out_tensor_76, %result_77 = qtensor.extract %48[%c0] : tensor<4x!qco.qubit>
    %49 = qco.ry(%arg16) %result_77 : !qco.qubit -> !qco.qubit
    %50 = qtensor.insert %49 into %out_tensor_76[%c0] : tensor<4x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %50[%c1] : tensor<4x!qco.qubit>
    %51 = qco.ry(%arg17) %result_79 : !qco.qubit -> !qco.qubit
    %52 = qtensor.insert %51 into %out_tensor_78[%c1] : tensor<4x!qco.qubit>
    %out_tensor_80, %result_81 = qtensor.extract %52[%c2] : tensor<4x!qco.qubit>
    %53 = qco.ry(%arg18) %result_81 : !qco.qubit -> !qco.qubit
    %54 = qtensor.insert %53 into %out_tensor_80[%c2] : tensor<4x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %54[%c3] : tensor<4x!qco.qubit>
    %55 = qco.ry(%arg19) %result_83 : !qco.qubit -> !qco.qubit
    %56 = qtensor.insert %55 into %out_tensor_82[%c3] : tensor<4x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %56[%c0] : tensor<4x!qco.qubit>
    %57 = qco.rz(%arg20) %result_85 : !qco.qubit -> !qco.qubit
    %58 = qtensor.insert %57 into %out_tensor_84[%c0] : tensor<4x!qco.qubit>
    %out_tensor_86, %result_87 = qtensor.extract %58[%c1] : tensor<4x!qco.qubit>
    %59 = qco.rz(%arg21) %result_87 : !qco.qubit -> !qco.qubit
    %60 = qtensor.insert %59 into %out_tensor_86[%c1] : tensor<4x!qco.qubit>
    %out_tensor_88, %result_89 = qtensor.extract %60[%c2] : tensor<4x!qco.qubit>
    %61 = qco.rz(%arg22) %result_89 : !qco.qubit -> !qco.qubit
    %62 = qtensor.insert %61 into %out_tensor_88[%c2] : tensor<4x!qco.qubit>
    %out_tensor_90, %result_91 = qtensor.extract %62[%c3] : tensor<4x!qco.qubit>
    %63 = qco.rz(%arg23) %result_91 : !qco.qubit -> !qco.qubit
    %64 = qtensor.insert %63 into %out_tensor_90[%c3] : tensor<4x!qco.qubit>
    %out_tensor_92, %result_93 = qtensor.extract %64[%c3] : tensor<4x!qco.qubit>
    %out_tensor_94, %result_95 = qtensor.extract %out_tensor_92[%c0] : tensor<4x!qco.qubit>
    %controls_out_96, %targets_out_97 = qco.ctrl(%result_93) targets (%arg32 = %result_95) {
      %89 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qtensor.insert %targets_out_97 into %out_tensor_94[%c0] : tensor<4x!qco.qubit>
    %66 = qtensor.insert %controls_out_96 into %65[%c3] : tensor<4x!qco.qubit>
    %out_tensor_98, %result_99 = qtensor.extract %66[%c0] : tensor<4x!qco.qubit>
    %out_tensor_100, %result_101 = qtensor.extract %out_tensor_98[%c1] : tensor<4x!qco.qubit>
    %controls_out_102, %targets_out_103 = qco.ctrl(%result_99) targets (%arg32 = %result_101) {
      %89 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %67 = qtensor.insert %targets_out_103 into %out_tensor_100[%c1] : tensor<4x!qco.qubit>
    %68 = qtensor.insert %controls_out_102 into %67[%c0] : tensor<4x!qco.qubit>
    %out_tensor_104, %result_105 = qtensor.extract %68[%c1] : tensor<4x!qco.qubit>
    %out_tensor_106, %result_107 = qtensor.extract %out_tensor_104[%c2] : tensor<4x!qco.qubit>
    %controls_out_108, %targets_out_109 = qco.ctrl(%result_105) targets (%arg32 = %result_107) {
      %89 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qtensor.insert %targets_out_109 into %out_tensor_106[%c2] : tensor<4x!qco.qubit>
    %70 = qtensor.insert %controls_out_108 into %69[%c1] : tensor<4x!qco.qubit>
    %out_tensor_110, %result_111 = qtensor.extract %70[%c2] : tensor<4x!qco.qubit>
    %out_tensor_112, %result_113 = qtensor.extract %out_tensor_110[%c3] : tensor<4x!qco.qubit>
    %controls_out_114, %targets_out_115 = qco.ctrl(%result_111) targets (%arg32 = %result_113) {
      %89 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qtensor.insert %targets_out_115 into %out_tensor_112[%c3] : tensor<4x!qco.qubit>
    %72 = qtensor.insert %controls_out_114 into %71[%c2] : tensor<4x!qco.qubit>
    %out_tensor_116, %result_117 = qtensor.extract %72[%c0] : tensor<4x!qco.qubit>
    %73 = qco.ry(%arg24) %result_117 : !qco.qubit -> !qco.qubit
    %74 = qtensor.insert %73 into %out_tensor_116[%c0] : tensor<4x!qco.qubit>
    %out_tensor_118, %result_119 = qtensor.extract %74[%c1] : tensor<4x!qco.qubit>
    %75 = qco.ry(%arg25) %result_119 : !qco.qubit -> !qco.qubit
    %76 = qtensor.insert %75 into %out_tensor_118[%c1] : tensor<4x!qco.qubit>
    %out_tensor_120, %result_121 = qtensor.extract %76[%c2] : tensor<4x!qco.qubit>
    %77 = qco.ry(%arg26) %result_121 : !qco.qubit -> !qco.qubit
    %78 = qtensor.insert %77 into %out_tensor_120[%c2] : tensor<4x!qco.qubit>
    %out_tensor_122, %result_123 = qtensor.extract %78[%c3] : tensor<4x!qco.qubit>
    %79 = qco.ry(%arg27) %result_123 : !qco.qubit -> !qco.qubit
    %80 = qtensor.insert %79 into %out_tensor_122[%c3] : tensor<4x!qco.qubit>
    %out_tensor_124, %result_125 = qtensor.extract %80[%c0] : tensor<4x!qco.qubit>
    %81 = qco.rz(%arg28) %result_125 : !qco.qubit -> !qco.qubit
    %82 = qtensor.insert %81 into %out_tensor_124[%c0] : tensor<4x!qco.qubit>
    %out_tensor_126, %result_127 = qtensor.extract %82[%c1] : tensor<4x!qco.qubit>
    %83 = qco.rz(%arg29) %result_127 : !qco.qubit -> !qco.qubit
    %84 = qtensor.insert %83 into %out_tensor_126[%c1] : tensor<4x!qco.qubit>
    %out_tensor_128, %result_129 = qtensor.extract %84[%c2] : tensor<4x!qco.qubit>
    %85 = qco.rz(%arg30) %result_129 : !qco.qubit -> !qco.qubit
    %86 = qtensor.insert %85 into %out_tensor_128[%c2] : tensor<4x!qco.qubit>
    %out_tensor_130, %result_131 = qtensor.extract %86[%c3] : tensor<4x!qco.qubit>
    %87 = qco.rz(%arg31) %result_131 : !qco.qubit -> !qco.qubit
    %88 = qtensor.insert %87 into %out_tensor_130[%c3] : tensor<4x!qco.qubit>
    qtensor.dealloc %88 : tensor<4x!qco.qubit>
    return %c0_i64 : i64
  }
}
