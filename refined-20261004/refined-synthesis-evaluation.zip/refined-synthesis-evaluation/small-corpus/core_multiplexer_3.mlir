module {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 0.78539816339744828 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %0 = qtensor.alloc(%c2) {mqt.register_name = "controls"} : tensor<2x!qco.qubit>
    %1 = qco.alloc : !qco.qubit
    %2 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<2x!qco.qubit>
    %3 = qco.h %result : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor[%c0] : tensor<2x!qco.qubit>
    %out_tensor_1, %result_2 = qtensor.extract %4[%c1] : tensor<2x!qco.qubit>
    %5 = qco.h %result_2 : !qco.qubit -> !qco.qubit
    %6 = qtensor.insert %5 into %out_tensor_1[%c1] : tensor<2x!qco.qubit>
    %out_tensor_3, %result_4 = qtensor.extract %6[%c1] : tensor<2x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_4) targets (%arg0 = %1) {
      %11 = qco.ry(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %11 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %7 = qtensor.insert %controls_out into %out_tensor_3[%c1] : tensor<2x!qco.qubit>
    %out_tensor_5, %result_6 = qtensor.extract %7[%c0] : tensor<2x!qco.qubit>
    %controls_out_7, %targets_out_8 = qco.ctrl(%result_6) targets (%arg0 = %targets_out) {
      %11 = qco.ry(%cst) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %11 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %8 = qtensor.insert %controls_out_7 into %out_tensor_5[%c0] : tensor<2x!qco.qubit>
    %qubit_out, %result_9 = qco.measure %targets_out_8 : !qco.qubit
    cbit.store %result_9, %2[%c0] : !cbit.reg<3>
    %out_tensor_10, %result_11 = qtensor.extract %8[%c0] : tensor<2x!qco.qubit>
    %qubit_out_12, %result_13 = qco.measure %result_11 : !qco.qubit
    %9 = qtensor.insert %qubit_out_12 into %out_tensor_10[%c0] : tensor<2x!qco.qubit>
    cbit.store %result_13, %2[%c1] : !cbit.reg<3>
    %out_tensor_14, %result_15 = qtensor.extract %9[%c1] : tensor<2x!qco.qubit>
    %qubit_out_16, %result_17 = qco.measure %result_15 : !qco.qubit
    %10 = qtensor.insert %qubit_out_16 into %out_tensor_14[%c1] : tensor<2x!qco.qubit>
    cbit.store %result_17, %2[%c2] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qtensor.dealloc %10 : tensor<2x!qco.qubit>
    return %2 : !cbit.reg<3>
  }
}
