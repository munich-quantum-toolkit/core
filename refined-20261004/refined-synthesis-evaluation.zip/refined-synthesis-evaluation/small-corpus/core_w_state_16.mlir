module {
  func.func @main() -> !cbit.reg<16> attributes {mqt.entry_point} {
    %c15 = arith.constant 15 : index
    %cst = arith.constant 1.5707963267948968 : f64
    %c14 = arith.constant 14 : index
    %cst_0 = arith.constant 1.9106332362490184 : f64
    %c13 = arith.constant 13 : index
    %cst_1 = arith.constant 2.0943951023931957 : f64
    %c12 = arith.constant 12 : index
    %cst_2 = arith.constant 2.2142974355881808 : f64
    %c11 = arith.constant 11 : index
    %cst_3 = arith.constant 2.3005239830218627 : f64
    %c10 = arith.constant 10 : index
    %cst_4 = arith.constant 2.366399280279432 : f64
    %c9 = arith.constant 9 : index
    %cst_5 = arith.constant 2.4188584057763776 : f64
    %c8 = arith.constant 8 : index
    %cst_6 = arith.constant 2.4619188346815495 : f64
    %c7 = arith.constant 7 : index
    %cst_7 = arith.constant 2.4980915447965089 : f64
    %c6 = arith.constant 6 : index
    %cst_8 = arith.constant 2.5290379152504543 : f64
    %c5 = arith.constant 5 : index
    %cst_9 = arith.constant 2.555907110132642 : f64
    %c4 = arith.constant 4 : index
    %cst_10 = arith.constant 2.5795228505841661 : f64
    %c3 = arith.constant 3 : index
    %cst_11 = arith.constant 2.6004931276326473 : f64
    %c2 = arith.constant 2 : index
    %cst_12 = arith.constant 2.6192778317837448 : f64
    %cst_13 = arith.constant 2.6362321433056359 : f64
    %c1 = arith.constant 1 : index
    %c16 = arith.constant 16 : index
    %c0 = arith.constant 0 : index
    %0 = qtensor.alloc(%c16) {mqt.register_name = "q"} : tensor<16x!qco.qubit>
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<16>
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<16x!qco.qubit>
    %2 = qco.x %result : !qco.qubit -> !qco.qubit
    %3 = qtensor.insert %2 into %out_tensor[%c0] : tensor<16x!qco.qubit>
    %out_tensor_14, %result_15 = qtensor.extract %3[%c0] : tensor<16x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %out_tensor_14[%c1] : tensor<16x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_15) targets (%arg0 = %result_17) {
      %80 = qco.ry(%cst_13) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %4 = qtensor.insert %targets_out into %out_tensor_16[%c1] : tensor<16x!qco.qubit>
    %5 = qtensor.insert %controls_out into %4[%c0] : tensor<16x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %5[%c1] : tensor<16x!qco.qubit>
    %out_tensor_20, %result_21 = qtensor.extract %out_tensor_18[%c0] : tensor<16x!qco.qubit>
    %controls_out_22, %targets_out_23 = qco.ctrl(%result_19) targets (%arg0 = %result_21) {
      %80 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %6 = qtensor.insert %targets_out_23 into %out_tensor_20[%c0] : tensor<16x!qco.qubit>
    %7 = qtensor.insert %controls_out_22 into %6[%c1] : tensor<16x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %7[%c1] : tensor<16x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %out_tensor_24[%c2] : tensor<16x!qco.qubit>
    %controls_out_28, %targets_out_29 = qco.ctrl(%result_25) targets (%arg0 = %result_27) {
      %80 = qco.ry(%cst_12) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %8 = qtensor.insert %targets_out_29 into %out_tensor_26[%c2] : tensor<16x!qco.qubit>
    %9 = qtensor.insert %controls_out_28 into %8[%c1] : tensor<16x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %9[%c2] : tensor<16x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %out_tensor_30[%c1] : tensor<16x!qco.qubit>
    %controls_out_34, %targets_out_35 = qco.ctrl(%result_31) targets (%arg0 = %result_33) {
      %80 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %10 = qtensor.insert %targets_out_35 into %out_tensor_32[%c1] : tensor<16x!qco.qubit>
    %11 = qtensor.insert %controls_out_34 into %10[%c2] : tensor<16x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %11[%c2] : tensor<16x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %out_tensor_36[%c3] : tensor<16x!qco.qubit>
    %controls_out_40, %targets_out_41 = qco.ctrl(%result_37) targets (%arg0 = %result_39) {
      %80 = qco.ry(%cst_11) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qtensor.insert %targets_out_41 into %out_tensor_38[%c3] : tensor<16x!qco.qubit>
    %13 = qtensor.insert %controls_out_40 into %12[%c2] : tensor<16x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %13[%c3] : tensor<16x!qco.qubit>
    %out_tensor_44, %result_45 = qtensor.extract %out_tensor_42[%c2] : tensor<16x!qco.qubit>
    %controls_out_46, %targets_out_47 = qco.ctrl(%result_43) targets (%arg0 = %result_45) {
      %80 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qtensor.insert %targets_out_47 into %out_tensor_44[%c2] : tensor<16x!qco.qubit>
    %15 = qtensor.insert %controls_out_46 into %14[%c3] : tensor<16x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %15[%c3] : tensor<16x!qco.qubit>
    %out_tensor_50, %result_51 = qtensor.extract %out_tensor_48[%c4] : tensor<16x!qco.qubit>
    %controls_out_52, %targets_out_53 = qco.ctrl(%result_49) targets (%arg0 = %result_51) {
      %80 = qco.ry(%cst_10) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qtensor.insert %targets_out_53 into %out_tensor_50[%c4] : tensor<16x!qco.qubit>
    %17 = qtensor.insert %controls_out_52 into %16[%c3] : tensor<16x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %17[%c4] : tensor<16x!qco.qubit>
    %out_tensor_56, %result_57 = qtensor.extract %out_tensor_54[%c3] : tensor<16x!qco.qubit>
    %controls_out_58, %targets_out_59 = qco.ctrl(%result_55) targets (%arg0 = %result_57) {
      %80 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qtensor.insert %targets_out_59 into %out_tensor_56[%c3] : tensor<16x!qco.qubit>
    %19 = qtensor.insert %controls_out_58 into %18[%c4] : tensor<16x!qco.qubit>
    %out_tensor_60, %result_61 = qtensor.extract %19[%c4] : tensor<16x!qco.qubit>
    %out_tensor_62, %result_63 = qtensor.extract %out_tensor_60[%c5] : tensor<16x!qco.qubit>
    %controls_out_64, %targets_out_65 = qco.ctrl(%result_61) targets (%arg0 = %result_63) {
      %80 = qco.ry(%cst_9) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qtensor.insert %targets_out_65 into %out_tensor_62[%c5] : tensor<16x!qco.qubit>
    %21 = qtensor.insert %controls_out_64 into %20[%c4] : tensor<16x!qco.qubit>
    %out_tensor_66, %result_67 = qtensor.extract %21[%c5] : tensor<16x!qco.qubit>
    %out_tensor_68, %result_69 = qtensor.extract %out_tensor_66[%c4] : tensor<16x!qco.qubit>
    %controls_out_70, %targets_out_71 = qco.ctrl(%result_67) targets (%arg0 = %result_69) {
      %80 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qtensor.insert %targets_out_71 into %out_tensor_68[%c4] : tensor<16x!qco.qubit>
    %23 = qtensor.insert %controls_out_70 into %22[%c5] : tensor<16x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %23[%c5] : tensor<16x!qco.qubit>
    %out_tensor_74, %result_75 = qtensor.extract %out_tensor_72[%c6] : tensor<16x!qco.qubit>
    %controls_out_76, %targets_out_77 = qco.ctrl(%result_73) targets (%arg0 = %result_75) {
      %80 = qco.ry(%cst_8) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qtensor.insert %targets_out_77 into %out_tensor_74[%c6] : tensor<16x!qco.qubit>
    %25 = qtensor.insert %controls_out_76 into %24[%c5] : tensor<16x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %25[%c6] : tensor<16x!qco.qubit>
    %out_tensor_80, %result_81 = qtensor.extract %out_tensor_78[%c5] : tensor<16x!qco.qubit>
    %controls_out_82, %targets_out_83 = qco.ctrl(%result_79) targets (%arg0 = %result_81) {
      %80 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qtensor.insert %targets_out_83 into %out_tensor_80[%c5] : tensor<16x!qco.qubit>
    %27 = qtensor.insert %controls_out_82 into %26[%c6] : tensor<16x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %27[%c6] : tensor<16x!qco.qubit>
    %out_tensor_86, %result_87 = qtensor.extract %out_tensor_84[%c7] : tensor<16x!qco.qubit>
    %controls_out_88, %targets_out_89 = qco.ctrl(%result_85) targets (%arg0 = %result_87) {
      %80 = qco.ry(%cst_7) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qtensor.insert %targets_out_89 into %out_tensor_86[%c7] : tensor<16x!qco.qubit>
    %29 = qtensor.insert %controls_out_88 into %28[%c6] : tensor<16x!qco.qubit>
    %out_tensor_90, %result_91 = qtensor.extract %29[%c7] : tensor<16x!qco.qubit>
    %out_tensor_92, %result_93 = qtensor.extract %out_tensor_90[%c6] : tensor<16x!qco.qubit>
    %controls_out_94, %targets_out_95 = qco.ctrl(%result_91) targets (%arg0 = %result_93) {
      %80 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qtensor.insert %targets_out_95 into %out_tensor_92[%c6] : tensor<16x!qco.qubit>
    %31 = qtensor.insert %controls_out_94 into %30[%c7] : tensor<16x!qco.qubit>
    %out_tensor_96, %result_97 = qtensor.extract %31[%c7] : tensor<16x!qco.qubit>
    %out_tensor_98, %result_99 = qtensor.extract %out_tensor_96[%c8] : tensor<16x!qco.qubit>
    %controls_out_100, %targets_out_101 = qco.ctrl(%result_97) targets (%arg0 = %result_99) {
      %80 = qco.ry(%cst_6) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qtensor.insert %targets_out_101 into %out_tensor_98[%c8] : tensor<16x!qco.qubit>
    %33 = qtensor.insert %controls_out_100 into %32[%c7] : tensor<16x!qco.qubit>
    %out_tensor_102, %result_103 = qtensor.extract %33[%c8] : tensor<16x!qco.qubit>
    %out_tensor_104, %result_105 = qtensor.extract %out_tensor_102[%c7] : tensor<16x!qco.qubit>
    %controls_out_106, %targets_out_107 = qco.ctrl(%result_103) targets (%arg0 = %result_105) {
      %80 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qtensor.insert %targets_out_107 into %out_tensor_104[%c7] : tensor<16x!qco.qubit>
    %35 = qtensor.insert %controls_out_106 into %34[%c8] : tensor<16x!qco.qubit>
    %out_tensor_108, %result_109 = qtensor.extract %35[%c8] : tensor<16x!qco.qubit>
    %out_tensor_110, %result_111 = qtensor.extract %out_tensor_108[%c9] : tensor<16x!qco.qubit>
    %controls_out_112, %targets_out_113 = qco.ctrl(%result_109) targets (%arg0 = %result_111) {
      %80 = qco.ry(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qtensor.insert %targets_out_113 into %out_tensor_110[%c9] : tensor<16x!qco.qubit>
    %37 = qtensor.insert %controls_out_112 into %36[%c8] : tensor<16x!qco.qubit>
    %out_tensor_114, %result_115 = qtensor.extract %37[%c9] : tensor<16x!qco.qubit>
    %out_tensor_116, %result_117 = qtensor.extract %out_tensor_114[%c8] : tensor<16x!qco.qubit>
    %controls_out_118, %targets_out_119 = qco.ctrl(%result_115) targets (%arg0 = %result_117) {
      %80 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qtensor.insert %targets_out_119 into %out_tensor_116[%c8] : tensor<16x!qco.qubit>
    %39 = qtensor.insert %controls_out_118 into %38[%c9] : tensor<16x!qco.qubit>
    %out_tensor_120, %result_121 = qtensor.extract %39[%c9] : tensor<16x!qco.qubit>
    %out_tensor_122, %result_123 = qtensor.extract %out_tensor_120[%c10] : tensor<16x!qco.qubit>
    %controls_out_124, %targets_out_125 = qco.ctrl(%result_121) targets (%arg0 = %result_123) {
      %80 = qco.ry(%cst_4) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %40 = qtensor.insert %targets_out_125 into %out_tensor_122[%c10] : tensor<16x!qco.qubit>
    %41 = qtensor.insert %controls_out_124 into %40[%c9] : tensor<16x!qco.qubit>
    %out_tensor_126, %result_127 = qtensor.extract %41[%c10] : tensor<16x!qco.qubit>
    %out_tensor_128, %result_129 = qtensor.extract %out_tensor_126[%c9] : tensor<16x!qco.qubit>
    %controls_out_130, %targets_out_131 = qco.ctrl(%result_127) targets (%arg0 = %result_129) {
      %80 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qtensor.insert %targets_out_131 into %out_tensor_128[%c9] : tensor<16x!qco.qubit>
    %43 = qtensor.insert %controls_out_130 into %42[%c10] : tensor<16x!qco.qubit>
    %out_tensor_132, %result_133 = qtensor.extract %43[%c10] : tensor<16x!qco.qubit>
    %out_tensor_134, %result_135 = qtensor.extract %out_tensor_132[%c11] : tensor<16x!qco.qubit>
    %controls_out_136, %targets_out_137 = qco.ctrl(%result_133) targets (%arg0 = %result_135) {
      %80 = qco.ry(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = qtensor.insert %targets_out_137 into %out_tensor_134[%c11] : tensor<16x!qco.qubit>
    %45 = qtensor.insert %controls_out_136 into %44[%c10] : tensor<16x!qco.qubit>
    %out_tensor_138, %result_139 = qtensor.extract %45[%c11] : tensor<16x!qco.qubit>
    %out_tensor_140, %result_141 = qtensor.extract %out_tensor_138[%c10] : tensor<16x!qco.qubit>
    %controls_out_142, %targets_out_143 = qco.ctrl(%result_139) targets (%arg0 = %result_141) {
      %80 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qtensor.insert %targets_out_143 into %out_tensor_140[%c10] : tensor<16x!qco.qubit>
    %47 = qtensor.insert %controls_out_142 into %46[%c11] : tensor<16x!qco.qubit>
    %out_tensor_144, %result_145 = qtensor.extract %47[%c11] : tensor<16x!qco.qubit>
    %out_tensor_146, %result_147 = qtensor.extract %out_tensor_144[%c12] : tensor<16x!qco.qubit>
    %controls_out_148, %targets_out_149 = qco.ctrl(%result_145) targets (%arg0 = %result_147) {
      %80 = qco.ry(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %48 = qtensor.insert %targets_out_149 into %out_tensor_146[%c12] : tensor<16x!qco.qubit>
    %49 = qtensor.insert %controls_out_148 into %48[%c11] : tensor<16x!qco.qubit>
    %out_tensor_150, %result_151 = qtensor.extract %49[%c12] : tensor<16x!qco.qubit>
    %out_tensor_152, %result_153 = qtensor.extract %out_tensor_150[%c11] : tensor<16x!qco.qubit>
    %controls_out_154, %targets_out_155 = qco.ctrl(%result_151) targets (%arg0 = %result_153) {
      %80 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qtensor.insert %targets_out_155 into %out_tensor_152[%c11] : tensor<16x!qco.qubit>
    %51 = qtensor.insert %controls_out_154 into %50[%c12] : tensor<16x!qco.qubit>
    %out_tensor_156, %result_157 = qtensor.extract %51[%c12] : tensor<16x!qco.qubit>
    %out_tensor_158, %result_159 = qtensor.extract %out_tensor_156[%c13] : tensor<16x!qco.qubit>
    %controls_out_160, %targets_out_161 = qco.ctrl(%result_157) targets (%arg0 = %result_159) {
      %80 = qco.ry(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qtensor.insert %targets_out_161 into %out_tensor_158[%c13] : tensor<16x!qco.qubit>
    %53 = qtensor.insert %controls_out_160 into %52[%c12] : tensor<16x!qco.qubit>
    %out_tensor_162, %result_163 = qtensor.extract %53[%c13] : tensor<16x!qco.qubit>
    %out_tensor_164, %result_165 = qtensor.extract %out_tensor_162[%c12] : tensor<16x!qco.qubit>
    %controls_out_166, %targets_out_167 = qco.ctrl(%result_163) targets (%arg0 = %result_165) {
      %80 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %54 = qtensor.insert %targets_out_167 into %out_tensor_164[%c12] : tensor<16x!qco.qubit>
    %55 = qtensor.insert %controls_out_166 into %54[%c13] : tensor<16x!qco.qubit>
    %out_tensor_168, %result_169 = qtensor.extract %55[%c13] : tensor<16x!qco.qubit>
    %out_tensor_170, %result_171 = qtensor.extract %out_tensor_168[%c14] : tensor<16x!qco.qubit>
    %controls_out_172, %targets_out_173 = qco.ctrl(%result_169) targets (%arg0 = %result_171) {
      %80 = qco.ry(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qtensor.insert %targets_out_173 into %out_tensor_170[%c14] : tensor<16x!qco.qubit>
    %57 = qtensor.insert %controls_out_172 into %56[%c13] : tensor<16x!qco.qubit>
    %out_tensor_174, %result_175 = qtensor.extract %57[%c14] : tensor<16x!qco.qubit>
    %out_tensor_176, %result_177 = qtensor.extract %out_tensor_174[%c13] : tensor<16x!qco.qubit>
    %controls_out_178, %targets_out_179 = qco.ctrl(%result_175) targets (%arg0 = %result_177) {
      %80 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = qtensor.insert %targets_out_179 into %out_tensor_176[%c13] : tensor<16x!qco.qubit>
    %59 = qtensor.insert %controls_out_178 into %58[%c14] : tensor<16x!qco.qubit>
    %out_tensor_180, %result_181 = qtensor.extract %59[%c14] : tensor<16x!qco.qubit>
    %out_tensor_182, %result_183 = qtensor.extract %out_tensor_180[%c15] : tensor<16x!qco.qubit>
    %controls_out_184, %targets_out_185 = qco.ctrl(%result_181) targets (%arg0 = %result_183) {
      %80 = qco.ry(%cst) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qtensor.insert %targets_out_185 into %out_tensor_182[%c15] : tensor<16x!qco.qubit>
    %61 = qtensor.insert %controls_out_184 into %60[%c14] : tensor<16x!qco.qubit>
    %out_tensor_186, %result_187 = qtensor.extract %61[%c15] : tensor<16x!qco.qubit>
    %out_tensor_188, %result_189 = qtensor.extract %out_tensor_186[%c14] : tensor<16x!qco.qubit>
    %controls_out_190, %targets_out_191 = qco.ctrl(%result_187) targets (%arg0 = %result_189) {
      %80 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %62 = qtensor.insert %targets_out_191 into %out_tensor_188[%c14] : tensor<16x!qco.qubit>
    %63 = qtensor.insert %controls_out_190 into %62[%c15] : tensor<16x!qco.qubit>
    %out_tensor_192, %result_193 = qtensor.extract %63[%c0] : tensor<16x!qco.qubit>
    %qubit_out, %result_194 = qco.measure %result_193 : !qco.qubit
    %64 = qtensor.insert %qubit_out into %out_tensor_192[%c0] : tensor<16x!qco.qubit>
    cbit.store %result_194, %1[%c0] : !cbit.reg<16>
    %out_tensor_195, %result_196 = qtensor.extract %64[%c1] : tensor<16x!qco.qubit>
    %qubit_out_197, %result_198 = qco.measure %result_196 : !qco.qubit
    %65 = qtensor.insert %qubit_out_197 into %out_tensor_195[%c1] : tensor<16x!qco.qubit>
    cbit.store %result_198, %1[%c1] : !cbit.reg<16>
    %out_tensor_199, %result_200 = qtensor.extract %65[%c2] : tensor<16x!qco.qubit>
    %qubit_out_201, %result_202 = qco.measure %result_200 : !qco.qubit
    %66 = qtensor.insert %qubit_out_201 into %out_tensor_199[%c2] : tensor<16x!qco.qubit>
    cbit.store %result_202, %1[%c2] : !cbit.reg<16>
    %out_tensor_203, %result_204 = qtensor.extract %66[%c3] : tensor<16x!qco.qubit>
    %qubit_out_205, %result_206 = qco.measure %result_204 : !qco.qubit
    %67 = qtensor.insert %qubit_out_205 into %out_tensor_203[%c3] : tensor<16x!qco.qubit>
    cbit.store %result_206, %1[%c3] : !cbit.reg<16>
    %out_tensor_207, %result_208 = qtensor.extract %67[%c4] : tensor<16x!qco.qubit>
    %qubit_out_209, %result_210 = qco.measure %result_208 : !qco.qubit
    %68 = qtensor.insert %qubit_out_209 into %out_tensor_207[%c4] : tensor<16x!qco.qubit>
    cbit.store %result_210, %1[%c4] : !cbit.reg<16>
    %out_tensor_211, %result_212 = qtensor.extract %68[%c5] : tensor<16x!qco.qubit>
    %qubit_out_213, %result_214 = qco.measure %result_212 : !qco.qubit
    %69 = qtensor.insert %qubit_out_213 into %out_tensor_211[%c5] : tensor<16x!qco.qubit>
    cbit.store %result_214, %1[%c5] : !cbit.reg<16>
    %out_tensor_215, %result_216 = qtensor.extract %69[%c6] : tensor<16x!qco.qubit>
    %qubit_out_217, %result_218 = qco.measure %result_216 : !qco.qubit
    %70 = qtensor.insert %qubit_out_217 into %out_tensor_215[%c6] : tensor<16x!qco.qubit>
    cbit.store %result_218, %1[%c6] : !cbit.reg<16>
    %out_tensor_219, %result_220 = qtensor.extract %70[%c7] : tensor<16x!qco.qubit>
    %qubit_out_221, %result_222 = qco.measure %result_220 : !qco.qubit
    %71 = qtensor.insert %qubit_out_221 into %out_tensor_219[%c7] : tensor<16x!qco.qubit>
    cbit.store %result_222, %1[%c7] : !cbit.reg<16>
    %out_tensor_223, %result_224 = qtensor.extract %71[%c8] : tensor<16x!qco.qubit>
    %qubit_out_225, %result_226 = qco.measure %result_224 : !qco.qubit
    %72 = qtensor.insert %qubit_out_225 into %out_tensor_223[%c8] : tensor<16x!qco.qubit>
    cbit.store %result_226, %1[%c8] : !cbit.reg<16>
    %out_tensor_227, %result_228 = qtensor.extract %72[%c9] : tensor<16x!qco.qubit>
    %qubit_out_229, %result_230 = qco.measure %result_228 : !qco.qubit
    %73 = qtensor.insert %qubit_out_229 into %out_tensor_227[%c9] : tensor<16x!qco.qubit>
    cbit.store %result_230, %1[%c9] : !cbit.reg<16>
    %out_tensor_231, %result_232 = qtensor.extract %73[%c10] : tensor<16x!qco.qubit>
    %qubit_out_233, %result_234 = qco.measure %result_232 : !qco.qubit
    %74 = qtensor.insert %qubit_out_233 into %out_tensor_231[%c10] : tensor<16x!qco.qubit>
    cbit.store %result_234, %1[%c10] : !cbit.reg<16>
    %out_tensor_235, %result_236 = qtensor.extract %74[%c11] : tensor<16x!qco.qubit>
    %qubit_out_237, %result_238 = qco.measure %result_236 : !qco.qubit
    %75 = qtensor.insert %qubit_out_237 into %out_tensor_235[%c11] : tensor<16x!qco.qubit>
    cbit.store %result_238, %1[%c11] : !cbit.reg<16>
    %out_tensor_239, %result_240 = qtensor.extract %75[%c12] : tensor<16x!qco.qubit>
    %qubit_out_241, %result_242 = qco.measure %result_240 : !qco.qubit
    %76 = qtensor.insert %qubit_out_241 into %out_tensor_239[%c12] : tensor<16x!qco.qubit>
    cbit.store %result_242, %1[%c12] : !cbit.reg<16>
    %out_tensor_243, %result_244 = qtensor.extract %76[%c13] : tensor<16x!qco.qubit>
    %qubit_out_245, %result_246 = qco.measure %result_244 : !qco.qubit
    %77 = qtensor.insert %qubit_out_245 into %out_tensor_243[%c13] : tensor<16x!qco.qubit>
    cbit.store %result_246, %1[%c13] : !cbit.reg<16>
    %out_tensor_247, %result_248 = qtensor.extract %77[%c14] : tensor<16x!qco.qubit>
    %qubit_out_249, %result_250 = qco.measure %result_248 : !qco.qubit
    %78 = qtensor.insert %qubit_out_249 into %out_tensor_247[%c14] : tensor<16x!qco.qubit>
    cbit.store %result_250, %1[%c14] : !cbit.reg<16>
    %out_tensor_251, %result_252 = qtensor.extract %78[%c15] : tensor<16x!qco.qubit>
    %qubit_out_253, %result_254 = qco.measure %result_252 : !qco.qubit
    %79 = qtensor.insert %qubit_out_253 into %out_tensor_251[%c15] : tensor<16x!qco.qubit>
    cbit.store %result_254, %1[%c15] : !cbit.reg<16>
    qtensor.dealloc %79 : tensor<16x!qco.qubit>
    return %1 : !cbit.reg<16>
  }
}
