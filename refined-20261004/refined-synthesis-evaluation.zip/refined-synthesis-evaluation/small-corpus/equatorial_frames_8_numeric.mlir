module {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %c0_i64 = arith.constant 0 : i64
    %cst = arith.constant 0.44667939965738057 : f64
    %cst_0 = arith.constant -0.78578727771328527 : f64
    %cst_1 = arith.constant 0.67749184634108328 : f64
    %cst_2 = arith.constant 0.68173504249419858 : f64
    %cst_3 = arith.constant -0.75412162920505033 : f64
    %cst_4 = arith.constant -0.8983357016036182 : f64
    %cst_5 = arith.constant -1.6086132076167963 : f64
    %cst_6 = arith.constant 2.1139475410141673 : f64
    %cst_7 = arith.constant -1.8102325781155384 : f64
    %cst_8 = arith.constant -0.099738680406292524 : f64
    %cst_9 = arith.constant -1.8951235486918137 : f64
    %cst_10 = arith.constant 2.8106168642934932 : f64
    %cst_11 = arith.constant -2.3744762026170969 : f64
    %cst_12 = arith.constant -1.7139284620972948 : f64
    %cst_13 = arith.constant -2.2110733621470455 : f64
    %cst_14 = arith.constant -0.94978341588137427 : f64
    %cst_15 = arith.constant -1.8379654918994144 : f64
    %cst_16 = arith.constant 2.5065443684807649 : f64
    %cst_17 = arith.constant 0.80609780225032868 : f64
    %cst_18 = arith.constant 0.23394886120749891 : f64
    %cst_19 = arith.constant -2.2787565529638361 : f64
    %cst_20 = arith.constant -0.58683529818140912 : f64
    %cst_21 = arith.constant 0.70293570842829123 : f64
    %cst_22 = arith.constant 2.000000e-01 : f64
    %cst_23 = arith.constant 3.000000e-01 : f64
    %cst_24 = arith.constant 0.58077588844307204 : f64
    %cst_25 = arith.constant 0.000000e+00 : f64
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c8 = arith.constant 8 : index
    %0 = qtensor.alloc(%c8) {mqt.register_name = "q"} : tensor<8x!qco.qubit>
    qco.gphase(%cst_25)
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<8x!qco.qubit>
    %1 = qco.rz(%cst_24) %result : !qco.qubit -> !qco.qubit
    %2 = qtensor.insert %1 into %out_tensor[%c0] : tensor<8x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %2[%c0] : tensor<8x!qco.qubit>
    %3 = qco.r(%cst_23, %cst_22) %result_27 : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor_26[%c0] : tensor<8x!qco.qubit>
    %out_tensor_28, %result_29 = qtensor.extract %4[%c0] : tensor<8x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %out_tensor_28[%c1] : tensor<8x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_29) targets (%arg0 = %result_31) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %5 = qtensor.insert %targets_out into %out_tensor_30[%c1] : tensor<8x!qco.qubit>
    %6 = qtensor.insert %controls_out into %5[%c0] : tensor<8x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %6[%c1] : tensor<8x!qco.qubit>
    %7 = qco.rz(%cst_21) %result_33 : !qco.qubit -> !qco.qubit
    %8 = qtensor.insert %7 into %out_tensor_32[%c1] : tensor<8x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %8[%c1] : tensor<8x!qco.qubit>
    %9 = qco.r(%cst_23, %cst_22) %result_35 : !qco.qubit -> !qco.qubit
    %10 = qtensor.insert %9 into %out_tensor_34[%c1] : tensor<8x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %10[%c1] : tensor<8x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %out_tensor_36[%c2] : tensor<8x!qco.qubit>
    %controls_out_40, %targets_out_41 = qco.ctrl(%result_37) targets (%arg0 = %result_39) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qtensor.insert %targets_out_41 into %out_tensor_38[%c2] : tensor<8x!qco.qubit>
    %12 = qtensor.insert %controls_out_40 into %11[%c1] : tensor<8x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %12[%c2] : tensor<8x!qco.qubit>
    %13 = qco.rz(%cst_20) %result_43 : !qco.qubit -> !qco.qubit
    %14 = qtensor.insert %13 into %out_tensor_42[%c2] : tensor<8x!qco.qubit>
    %out_tensor_44, %result_45 = qtensor.extract %14[%c2] : tensor<8x!qco.qubit>
    %15 = qco.r(%cst_23, %cst_22) %result_45 : !qco.qubit -> !qco.qubit
    %16 = qtensor.insert %15 into %out_tensor_44[%c2] : tensor<8x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %16[%c2] : tensor<8x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %out_tensor_46[%c3] : tensor<8x!qco.qubit>
    %controls_out_50, %targets_out_51 = qco.ctrl(%result_47) targets (%arg0 = %result_49) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qtensor.insert %targets_out_51 into %out_tensor_48[%c3] : tensor<8x!qco.qubit>
    %18 = qtensor.insert %controls_out_50 into %17[%c2] : tensor<8x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %18[%c3] : tensor<8x!qco.qubit>
    %19 = qco.rz(%cst_19) %result_53 : !qco.qubit -> !qco.qubit
    %20 = qtensor.insert %19 into %out_tensor_52[%c3] : tensor<8x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %20[%c3] : tensor<8x!qco.qubit>
    %21 = qco.r(%cst_23, %cst_22) %result_55 : !qco.qubit -> !qco.qubit
    %22 = qtensor.insert %21 into %out_tensor_54[%c3] : tensor<8x!qco.qubit>
    %out_tensor_56, %result_57 = qtensor.extract %22[%c3] : tensor<8x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %out_tensor_56[%c4] : tensor<8x!qco.qubit>
    %controls_out_60, %targets_out_61 = qco.ctrl(%result_57) targets (%arg0 = %result_59) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qtensor.insert %targets_out_61 into %out_tensor_58[%c4] : tensor<8x!qco.qubit>
    %24 = qtensor.insert %controls_out_60 into %23[%c3] : tensor<8x!qco.qubit>
    %out_tensor_62, %result_63 = qtensor.extract %24[%c4] : tensor<8x!qco.qubit>
    %25 = qco.rz(%cst_18) %result_63 : !qco.qubit -> !qco.qubit
    %26 = qtensor.insert %25 into %out_tensor_62[%c4] : tensor<8x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %26[%c4] : tensor<8x!qco.qubit>
    %27 = qco.r(%cst_23, %cst_22) %result_65 : !qco.qubit -> !qco.qubit
    %28 = qtensor.insert %27 into %out_tensor_64[%c4] : tensor<8x!qco.qubit>
    %out_tensor_66, %result_67 = qtensor.extract %28[%c4] : tensor<8x!qco.qubit>
    %out_tensor_68, %result_69 = qtensor.extract %out_tensor_66[%c5] : tensor<8x!qco.qubit>
    %controls_out_70, %targets_out_71 = qco.ctrl(%result_67) targets (%arg0 = %result_69) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qtensor.insert %targets_out_71 into %out_tensor_68[%c5] : tensor<8x!qco.qubit>
    %30 = qtensor.insert %controls_out_70 into %29[%c4] : tensor<8x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %30[%c5] : tensor<8x!qco.qubit>
    %31 = qco.rz(%cst_17) %result_73 : !qco.qubit -> !qco.qubit
    %32 = qtensor.insert %31 into %out_tensor_72[%c5] : tensor<8x!qco.qubit>
    %out_tensor_74, %result_75 = qtensor.extract %32[%c5] : tensor<8x!qco.qubit>
    %33 = qco.r(%cst_23, %cst_22) %result_75 : !qco.qubit -> !qco.qubit
    %34 = qtensor.insert %33 into %out_tensor_74[%c5] : tensor<8x!qco.qubit>
    %out_tensor_76, %result_77 = qtensor.extract %34[%c5] : tensor<8x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %out_tensor_76[%c6] : tensor<8x!qco.qubit>
    %controls_out_80, %targets_out_81 = qco.ctrl(%result_77) targets (%arg0 = %result_79) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qtensor.insert %targets_out_81 into %out_tensor_78[%c6] : tensor<8x!qco.qubit>
    %36 = qtensor.insert %controls_out_80 into %35[%c5] : tensor<8x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %36[%c6] : tensor<8x!qco.qubit>
    %37 = qco.rz(%cst_16) %result_83 : !qco.qubit -> !qco.qubit
    %38 = qtensor.insert %37 into %out_tensor_82[%c6] : tensor<8x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %38[%c6] : tensor<8x!qco.qubit>
    %39 = qco.r(%cst_23, %cst_22) %result_85 : !qco.qubit -> !qco.qubit
    %40 = qtensor.insert %39 into %out_tensor_84[%c6] : tensor<8x!qco.qubit>
    %out_tensor_86, %result_87 = qtensor.extract %40[%c6] : tensor<8x!qco.qubit>
    %out_tensor_88, %result_89 = qtensor.extract %out_tensor_86[%c7] : tensor<8x!qco.qubit>
    %controls_out_90, %targets_out_91 = qco.ctrl(%result_87) targets (%arg0 = %result_89) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qtensor.insert %targets_out_91 into %out_tensor_88[%c7] : tensor<8x!qco.qubit>
    %42 = qtensor.insert %controls_out_90 into %41[%c6] : tensor<8x!qco.qubit>
    %out_tensor_92, %result_93 = qtensor.extract %42[%c7] : tensor<8x!qco.qubit>
    %43 = qco.rz(%cst_15) %result_93 : !qco.qubit -> !qco.qubit
    %44 = qtensor.insert %43 into %out_tensor_92[%c7] : tensor<8x!qco.qubit>
    %out_tensor_94, %result_95 = qtensor.extract %44[%c7] : tensor<8x!qco.qubit>
    %45 = qco.r(%cst_23, %cst_22) %result_95 : !qco.qubit -> !qco.qubit
    %46 = qtensor.insert %45 into %out_tensor_94[%c7] : tensor<8x!qco.qubit>
    %out_tensor_96, %result_97 = qtensor.extract %46[%c7] : tensor<8x!qco.qubit>
    %out_tensor_98, %result_99 = qtensor.extract %out_tensor_96[%c0] : tensor<8x!qco.qubit>
    %controls_out_100, %targets_out_101 = qco.ctrl(%result_97) targets (%arg0 = %result_99) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qtensor.insert %targets_out_101 into %out_tensor_98[%c0] : tensor<8x!qco.qubit>
    %48 = qtensor.insert %controls_out_100 into %47[%c7] : tensor<8x!qco.qubit>
    %out_tensor_102, %result_103 = qtensor.extract %48[%c0] : tensor<8x!qco.qubit>
    %49 = qco.rz(%cst_14) %result_103 : !qco.qubit -> !qco.qubit
    %50 = qtensor.insert %49 into %out_tensor_102[%c0] : tensor<8x!qco.qubit>
    %out_tensor_104, %result_105 = qtensor.extract %50[%c0] : tensor<8x!qco.qubit>
    %51 = qco.r(%cst_23, %cst_22) %result_105 : !qco.qubit -> !qco.qubit
    %52 = qtensor.insert %51 into %out_tensor_104[%c0] : tensor<8x!qco.qubit>
    %out_tensor_106, %result_107 = qtensor.extract %52[%c0] : tensor<8x!qco.qubit>
    %out_tensor_108, %result_109 = qtensor.extract %out_tensor_106[%c1] : tensor<8x!qco.qubit>
    %controls_out_110, %targets_out_111 = qco.ctrl(%result_107) targets (%arg0 = %result_109) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qtensor.insert %targets_out_111 into %out_tensor_108[%c1] : tensor<8x!qco.qubit>
    %54 = qtensor.insert %controls_out_110 into %53[%c0] : tensor<8x!qco.qubit>
    %out_tensor_112, %result_113 = qtensor.extract %54[%c1] : tensor<8x!qco.qubit>
    %55 = qco.rz(%cst_13) %result_113 : !qco.qubit -> !qco.qubit
    %56 = qtensor.insert %55 into %out_tensor_112[%c1] : tensor<8x!qco.qubit>
    %out_tensor_114, %result_115 = qtensor.extract %56[%c1] : tensor<8x!qco.qubit>
    %57 = qco.r(%cst_23, %cst_22) %result_115 : !qco.qubit -> !qco.qubit
    %58 = qtensor.insert %57 into %out_tensor_114[%c1] : tensor<8x!qco.qubit>
    %out_tensor_116, %result_117 = qtensor.extract %58[%c1] : tensor<8x!qco.qubit>
    %out_tensor_118, %result_119 = qtensor.extract %out_tensor_116[%c2] : tensor<8x!qco.qubit>
    %controls_out_120, %targets_out_121 = qco.ctrl(%result_117) targets (%arg0 = %result_119) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qtensor.insert %targets_out_121 into %out_tensor_118[%c2] : tensor<8x!qco.qubit>
    %60 = qtensor.insert %controls_out_120 into %59[%c1] : tensor<8x!qco.qubit>
    %out_tensor_122, %result_123 = qtensor.extract %60[%c2] : tensor<8x!qco.qubit>
    %61 = qco.rz(%cst_12) %result_123 : !qco.qubit -> !qco.qubit
    %62 = qtensor.insert %61 into %out_tensor_122[%c2] : tensor<8x!qco.qubit>
    %out_tensor_124, %result_125 = qtensor.extract %62[%c2] : tensor<8x!qco.qubit>
    %63 = qco.r(%cst_23, %cst_22) %result_125 : !qco.qubit -> !qco.qubit
    %64 = qtensor.insert %63 into %out_tensor_124[%c2] : tensor<8x!qco.qubit>
    %out_tensor_126, %result_127 = qtensor.extract %64[%c2] : tensor<8x!qco.qubit>
    %out_tensor_128, %result_129 = qtensor.extract %out_tensor_126[%c3] : tensor<8x!qco.qubit>
    %controls_out_130, %targets_out_131 = qco.ctrl(%result_127) targets (%arg0 = %result_129) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qtensor.insert %targets_out_131 into %out_tensor_128[%c3] : tensor<8x!qco.qubit>
    %66 = qtensor.insert %controls_out_130 into %65[%c2] : tensor<8x!qco.qubit>
    %out_tensor_132, %result_133 = qtensor.extract %66[%c3] : tensor<8x!qco.qubit>
    %67 = qco.rz(%cst_11) %result_133 : !qco.qubit -> !qco.qubit
    %68 = qtensor.insert %67 into %out_tensor_132[%c3] : tensor<8x!qco.qubit>
    %out_tensor_134, %result_135 = qtensor.extract %68[%c3] : tensor<8x!qco.qubit>
    %69 = qco.r(%cst_23, %cst_22) %result_135 : !qco.qubit -> !qco.qubit
    %70 = qtensor.insert %69 into %out_tensor_134[%c3] : tensor<8x!qco.qubit>
    %out_tensor_136, %result_137 = qtensor.extract %70[%c3] : tensor<8x!qco.qubit>
    %out_tensor_138, %result_139 = qtensor.extract %out_tensor_136[%c4] : tensor<8x!qco.qubit>
    %controls_out_140, %targets_out_141 = qco.ctrl(%result_137) targets (%arg0 = %result_139) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qtensor.insert %targets_out_141 into %out_tensor_138[%c4] : tensor<8x!qco.qubit>
    %72 = qtensor.insert %controls_out_140 into %71[%c3] : tensor<8x!qco.qubit>
    %out_tensor_142, %result_143 = qtensor.extract %72[%c4] : tensor<8x!qco.qubit>
    %73 = qco.rz(%cst_10) %result_143 : !qco.qubit -> !qco.qubit
    %74 = qtensor.insert %73 into %out_tensor_142[%c4] : tensor<8x!qco.qubit>
    %out_tensor_144, %result_145 = qtensor.extract %74[%c4] : tensor<8x!qco.qubit>
    %75 = qco.r(%cst_23, %cst_22) %result_145 : !qco.qubit -> !qco.qubit
    %76 = qtensor.insert %75 into %out_tensor_144[%c4] : tensor<8x!qco.qubit>
    %out_tensor_146, %result_147 = qtensor.extract %76[%c4] : tensor<8x!qco.qubit>
    %out_tensor_148, %result_149 = qtensor.extract %out_tensor_146[%c5] : tensor<8x!qco.qubit>
    %controls_out_150, %targets_out_151 = qco.ctrl(%result_147) targets (%arg0 = %result_149) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qtensor.insert %targets_out_151 into %out_tensor_148[%c5] : tensor<8x!qco.qubit>
    %78 = qtensor.insert %controls_out_150 into %77[%c4] : tensor<8x!qco.qubit>
    %out_tensor_152, %result_153 = qtensor.extract %78[%c5] : tensor<8x!qco.qubit>
    %79 = qco.rz(%cst_9) %result_153 : !qco.qubit -> !qco.qubit
    %80 = qtensor.insert %79 into %out_tensor_152[%c5] : tensor<8x!qco.qubit>
    %out_tensor_154, %result_155 = qtensor.extract %80[%c5] : tensor<8x!qco.qubit>
    %81 = qco.r(%cst_23, %cst_22) %result_155 : !qco.qubit -> !qco.qubit
    %82 = qtensor.insert %81 into %out_tensor_154[%c5] : tensor<8x!qco.qubit>
    %out_tensor_156, %result_157 = qtensor.extract %82[%c5] : tensor<8x!qco.qubit>
    %out_tensor_158, %result_159 = qtensor.extract %out_tensor_156[%c6] : tensor<8x!qco.qubit>
    %controls_out_160, %targets_out_161 = qco.ctrl(%result_157) targets (%arg0 = %result_159) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qtensor.insert %targets_out_161 into %out_tensor_158[%c6] : tensor<8x!qco.qubit>
    %84 = qtensor.insert %controls_out_160 into %83[%c5] : tensor<8x!qco.qubit>
    %out_tensor_162, %result_163 = qtensor.extract %84[%c6] : tensor<8x!qco.qubit>
    %85 = qco.rz(%cst_8) %result_163 : !qco.qubit -> !qco.qubit
    %86 = qtensor.insert %85 into %out_tensor_162[%c6] : tensor<8x!qco.qubit>
    %out_tensor_164, %result_165 = qtensor.extract %86[%c6] : tensor<8x!qco.qubit>
    %87 = qco.r(%cst_23, %cst_22) %result_165 : !qco.qubit -> !qco.qubit
    %88 = qtensor.insert %87 into %out_tensor_164[%c6] : tensor<8x!qco.qubit>
    %out_tensor_166, %result_167 = qtensor.extract %88[%c6] : tensor<8x!qco.qubit>
    %out_tensor_168, %result_169 = qtensor.extract %out_tensor_166[%c7] : tensor<8x!qco.qubit>
    %controls_out_170, %targets_out_171 = qco.ctrl(%result_167) targets (%arg0 = %result_169) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %89 = qtensor.insert %targets_out_171 into %out_tensor_168[%c7] : tensor<8x!qco.qubit>
    %90 = qtensor.insert %controls_out_170 into %89[%c6] : tensor<8x!qco.qubit>
    %out_tensor_172, %result_173 = qtensor.extract %90[%c7] : tensor<8x!qco.qubit>
    %91 = qco.rz(%cst_7) %result_173 : !qco.qubit -> !qco.qubit
    %92 = qtensor.insert %91 into %out_tensor_172[%c7] : tensor<8x!qco.qubit>
    %out_tensor_174, %result_175 = qtensor.extract %92[%c7] : tensor<8x!qco.qubit>
    %93 = qco.r(%cst_23, %cst_22) %result_175 : !qco.qubit -> !qco.qubit
    %94 = qtensor.insert %93 into %out_tensor_174[%c7] : tensor<8x!qco.qubit>
    %out_tensor_176, %result_177 = qtensor.extract %94[%c7] : tensor<8x!qco.qubit>
    %out_tensor_178, %result_179 = qtensor.extract %out_tensor_176[%c0] : tensor<8x!qco.qubit>
    %controls_out_180, %targets_out_181 = qco.ctrl(%result_177) targets (%arg0 = %result_179) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %95 = qtensor.insert %targets_out_181 into %out_tensor_178[%c0] : tensor<8x!qco.qubit>
    %96 = qtensor.insert %controls_out_180 into %95[%c7] : tensor<8x!qco.qubit>
    %out_tensor_182, %result_183 = qtensor.extract %96[%c0] : tensor<8x!qco.qubit>
    %97 = qco.rz(%cst_6) %result_183 : !qco.qubit -> !qco.qubit
    %98 = qtensor.insert %97 into %out_tensor_182[%c0] : tensor<8x!qco.qubit>
    %out_tensor_184, %result_185 = qtensor.extract %98[%c0] : tensor<8x!qco.qubit>
    %99 = qco.r(%cst_23, %cst_22) %result_185 : !qco.qubit -> !qco.qubit
    %100 = qtensor.insert %99 into %out_tensor_184[%c0] : tensor<8x!qco.qubit>
    %out_tensor_186, %result_187 = qtensor.extract %100[%c0] : tensor<8x!qco.qubit>
    %out_tensor_188, %result_189 = qtensor.extract %out_tensor_186[%c1] : tensor<8x!qco.qubit>
    %controls_out_190, %targets_out_191 = qco.ctrl(%result_187) targets (%arg0 = %result_189) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %101 = qtensor.insert %targets_out_191 into %out_tensor_188[%c1] : tensor<8x!qco.qubit>
    %102 = qtensor.insert %controls_out_190 into %101[%c0] : tensor<8x!qco.qubit>
    %out_tensor_192, %result_193 = qtensor.extract %102[%c1] : tensor<8x!qco.qubit>
    %103 = qco.rz(%cst_5) %result_193 : !qco.qubit -> !qco.qubit
    %104 = qtensor.insert %103 into %out_tensor_192[%c1] : tensor<8x!qco.qubit>
    %out_tensor_194, %result_195 = qtensor.extract %104[%c1] : tensor<8x!qco.qubit>
    %105 = qco.r(%cst_23, %cst_22) %result_195 : !qco.qubit -> !qco.qubit
    %106 = qtensor.insert %105 into %out_tensor_194[%c1] : tensor<8x!qco.qubit>
    %out_tensor_196, %result_197 = qtensor.extract %106[%c1] : tensor<8x!qco.qubit>
    %out_tensor_198, %result_199 = qtensor.extract %out_tensor_196[%c2] : tensor<8x!qco.qubit>
    %controls_out_200, %targets_out_201 = qco.ctrl(%result_197) targets (%arg0 = %result_199) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %107 = qtensor.insert %targets_out_201 into %out_tensor_198[%c2] : tensor<8x!qco.qubit>
    %108 = qtensor.insert %controls_out_200 into %107[%c1] : tensor<8x!qco.qubit>
    %out_tensor_202, %result_203 = qtensor.extract %108[%c2] : tensor<8x!qco.qubit>
    %109 = qco.rz(%cst_4) %result_203 : !qco.qubit -> !qco.qubit
    %110 = qtensor.insert %109 into %out_tensor_202[%c2] : tensor<8x!qco.qubit>
    %out_tensor_204, %result_205 = qtensor.extract %110[%c2] : tensor<8x!qco.qubit>
    %111 = qco.r(%cst_23, %cst_22) %result_205 : !qco.qubit -> !qco.qubit
    %112 = qtensor.insert %111 into %out_tensor_204[%c2] : tensor<8x!qco.qubit>
    %out_tensor_206, %result_207 = qtensor.extract %112[%c2] : tensor<8x!qco.qubit>
    %out_tensor_208, %result_209 = qtensor.extract %out_tensor_206[%c3] : tensor<8x!qco.qubit>
    %controls_out_210, %targets_out_211 = qco.ctrl(%result_207) targets (%arg0 = %result_209) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %113 = qtensor.insert %targets_out_211 into %out_tensor_208[%c3] : tensor<8x!qco.qubit>
    %114 = qtensor.insert %controls_out_210 into %113[%c2] : tensor<8x!qco.qubit>
    %out_tensor_212, %result_213 = qtensor.extract %114[%c3] : tensor<8x!qco.qubit>
    %115 = qco.rz(%cst_3) %result_213 : !qco.qubit -> !qco.qubit
    %116 = qtensor.insert %115 into %out_tensor_212[%c3] : tensor<8x!qco.qubit>
    %out_tensor_214, %result_215 = qtensor.extract %116[%c3] : tensor<8x!qco.qubit>
    %117 = qco.r(%cst_23, %cst_22) %result_215 : !qco.qubit -> !qco.qubit
    %118 = qtensor.insert %117 into %out_tensor_214[%c3] : tensor<8x!qco.qubit>
    %out_tensor_216, %result_217 = qtensor.extract %118[%c3] : tensor<8x!qco.qubit>
    %out_tensor_218, %result_219 = qtensor.extract %out_tensor_216[%c4] : tensor<8x!qco.qubit>
    %controls_out_220, %targets_out_221 = qco.ctrl(%result_217) targets (%arg0 = %result_219) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %119 = qtensor.insert %targets_out_221 into %out_tensor_218[%c4] : tensor<8x!qco.qubit>
    %120 = qtensor.insert %controls_out_220 into %119[%c3] : tensor<8x!qco.qubit>
    %out_tensor_222, %result_223 = qtensor.extract %120[%c4] : tensor<8x!qco.qubit>
    %121 = qco.rz(%cst_2) %result_223 : !qco.qubit -> !qco.qubit
    %122 = qtensor.insert %121 into %out_tensor_222[%c4] : tensor<8x!qco.qubit>
    %out_tensor_224, %result_225 = qtensor.extract %122[%c4] : tensor<8x!qco.qubit>
    %123 = qco.r(%cst_23, %cst_22) %result_225 : !qco.qubit -> !qco.qubit
    %124 = qtensor.insert %123 into %out_tensor_224[%c4] : tensor<8x!qco.qubit>
    %out_tensor_226, %result_227 = qtensor.extract %124[%c4] : tensor<8x!qco.qubit>
    %out_tensor_228, %result_229 = qtensor.extract %out_tensor_226[%c5] : tensor<8x!qco.qubit>
    %controls_out_230, %targets_out_231 = qco.ctrl(%result_227) targets (%arg0 = %result_229) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %125 = qtensor.insert %targets_out_231 into %out_tensor_228[%c5] : tensor<8x!qco.qubit>
    %126 = qtensor.insert %controls_out_230 into %125[%c4] : tensor<8x!qco.qubit>
    %out_tensor_232, %result_233 = qtensor.extract %126[%c5] : tensor<8x!qco.qubit>
    %127 = qco.rz(%cst_1) %result_233 : !qco.qubit -> !qco.qubit
    %128 = qtensor.insert %127 into %out_tensor_232[%c5] : tensor<8x!qco.qubit>
    %out_tensor_234, %result_235 = qtensor.extract %128[%c5] : tensor<8x!qco.qubit>
    %129 = qco.r(%cst_23, %cst_22) %result_235 : !qco.qubit -> !qco.qubit
    %130 = qtensor.insert %129 into %out_tensor_234[%c5] : tensor<8x!qco.qubit>
    %out_tensor_236, %result_237 = qtensor.extract %130[%c5] : tensor<8x!qco.qubit>
    %out_tensor_238, %result_239 = qtensor.extract %out_tensor_236[%c6] : tensor<8x!qco.qubit>
    %controls_out_240, %targets_out_241 = qco.ctrl(%result_237) targets (%arg0 = %result_239) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %131 = qtensor.insert %targets_out_241 into %out_tensor_238[%c6] : tensor<8x!qco.qubit>
    %132 = qtensor.insert %controls_out_240 into %131[%c5] : tensor<8x!qco.qubit>
    %out_tensor_242, %result_243 = qtensor.extract %132[%c6] : tensor<8x!qco.qubit>
    %133 = qco.rz(%cst_0) %result_243 : !qco.qubit -> !qco.qubit
    %134 = qtensor.insert %133 into %out_tensor_242[%c6] : tensor<8x!qco.qubit>
    %out_tensor_244, %result_245 = qtensor.extract %134[%c6] : tensor<8x!qco.qubit>
    %135 = qco.r(%cst_23, %cst_22) %result_245 : !qco.qubit -> !qco.qubit
    %136 = qtensor.insert %135 into %out_tensor_244[%c6] : tensor<8x!qco.qubit>
    %out_tensor_246, %result_247 = qtensor.extract %136[%c6] : tensor<8x!qco.qubit>
    %out_tensor_248, %result_249 = qtensor.extract %out_tensor_246[%c7] : tensor<8x!qco.qubit>
    %controls_out_250, %targets_out_251 = qco.ctrl(%result_247) targets (%arg0 = %result_249) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %137 = qtensor.insert %targets_out_251 into %out_tensor_248[%c7] : tensor<8x!qco.qubit>
    %138 = qtensor.insert %controls_out_250 into %137[%c6] : tensor<8x!qco.qubit>
    %out_tensor_252, %result_253 = qtensor.extract %138[%c7] : tensor<8x!qco.qubit>
    %139 = qco.rz(%cst) %result_253 : !qco.qubit -> !qco.qubit
    %140 = qtensor.insert %139 into %out_tensor_252[%c7] : tensor<8x!qco.qubit>
    %out_tensor_254, %result_255 = qtensor.extract %140[%c7] : tensor<8x!qco.qubit>
    %141 = qco.r(%cst_23, %cst_22) %result_255 : !qco.qubit -> !qco.qubit
    %142 = qtensor.insert %141 into %out_tensor_254[%c7] : tensor<8x!qco.qubit>
    %out_tensor_256, %result_257 = qtensor.extract %142[%c7] : tensor<8x!qco.qubit>
    %out_tensor_258, %result_259 = qtensor.extract %out_tensor_256[%c0] : tensor<8x!qco.qubit>
    %controls_out_260, %targets_out_261 = qco.ctrl(%result_257) targets (%arg0 = %result_259) {
      %145 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %143 = qtensor.insert %targets_out_261 into %out_tensor_258[%c0] : tensor<8x!qco.qubit>
    %144 = qtensor.insert %controls_out_260 into %143[%c7] : tensor<8x!qco.qubit>
    qtensor.dealloc %144 : tensor<8x!qco.qubit>
    return %c0_i64 : i64
  }
}
