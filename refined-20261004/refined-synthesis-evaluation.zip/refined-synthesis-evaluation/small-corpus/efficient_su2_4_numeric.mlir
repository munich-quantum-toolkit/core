module {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %c0_i64 = arith.constant 0 : i64
    %cst = arith.constant -1.4492145843854549 : f64
    %cst_0 = arith.constant 0.60283548945758003 : f64
    %cst_1 = arith.constant -2.1354467228111282 : f64
    %cst_2 = arith.constant 1.6253491492962171 : f64
    %cst_3 = arith.constant 0.095616300133755772 : f64
    %cst_4 = arith.constant -1.7262384758686895 : f64
    %cst_5 = arith.constant 1.0916915810170105 : f64
    %cst_6 = arith.constant 1.4537324854174329 : f64
    %cst_7 = arith.constant 0.11888888386212537 : f64
    %cst_8 = arith.constant 2.6224857423258001 : f64
    %cst_9 = arith.constant 0.30493142927256844 : f64
    %cst_10 = arith.constant -1.9357630037248432 : f64
    %cst_11 = arith.constant -1.3172597430750992 : f64
    %cst_12 = arith.constant -2.4684606605209627 : f64
    %cst_13 = arith.constant 2.521103001473775 : f64
    %cst_14 = arith.constant 0.310112614383101 : f64
    %cst_15 = arith.constant -0.22518742377257883 : f64
    %cst_16 = arith.constant 2.0688723031329834 : f64
    %cst_17 = arith.constant -0.52768197277200635 : f64
    %cst_18 = arith.constant 0.90583093469478193 : f64
    %cst_19 = arith.constant 0.44890627722143339 : f64
    %cst_20 = arith.constant 2.2423492602035404 : f64
    %cst_21 = arith.constant -2.5181403996968745 : f64
    %cst_22 = arith.constant 1.0536552218902981 : f64
    %cst_23 = arith.constant 1.3619104989145452 : f64
    %cst_24 = arith.constant 1.4860340580195173 : f64
    %cst_25 = arith.constant -0.22904961114317635 : f64
    %cst_26 = arith.constant -0.48784943517400325 : f64
    %cst_27 = arith.constant -2.9408888113992759 : f64
    %cst_28 = arith.constant -0.67105356997791521 : f64
    %cst_29 = arith.constant 0.75467808616402498 : f64
    %cst_30 = arith.constant 2.1524411139170914 : f64
    %cst_31 = arith.constant 0.000000e+00 : f64
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c4 = arith.constant 4 : index
    %0 = qtensor.alloc(%c4) {mqt.register_name = "q"} : tensor<4x!qco.qubit>
    qco.gphase(%cst_31)
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<4x!qco.qubit>
    %1 = qco.ry(%cst_30) %result : !qco.qubit -> !qco.qubit
    %2 = qtensor.insert %1 into %out_tensor[%c0] : tensor<4x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %2[%c1] : tensor<4x!qco.qubit>
    %3 = qco.ry(%cst_29) %result_33 : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor_32[%c1] : tensor<4x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %4[%c2] : tensor<4x!qco.qubit>
    %5 = qco.ry(%cst_28) %result_35 : !qco.qubit -> !qco.qubit
    %6 = qtensor.insert %5 into %out_tensor_34[%c2] : tensor<4x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %6[%c3] : tensor<4x!qco.qubit>
    %7 = qco.ry(%cst_27) %result_37 : !qco.qubit -> !qco.qubit
    %8 = qtensor.insert %7 into %out_tensor_36[%c3] : tensor<4x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %8[%c0] : tensor<4x!qco.qubit>
    %9 = qco.rz(%cst_26) %result_39 : !qco.qubit -> !qco.qubit
    %10 = qtensor.insert %9 into %out_tensor_38[%c0] : tensor<4x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %10[%c1] : tensor<4x!qco.qubit>
    %11 = qco.rz(%cst_25) %result_41 : !qco.qubit -> !qco.qubit
    %12 = qtensor.insert %11 into %out_tensor_40[%c1] : tensor<4x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %12[%c2] : tensor<4x!qco.qubit>
    %13 = qco.rz(%cst_24) %result_43 : !qco.qubit -> !qco.qubit
    %14 = qtensor.insert %13 into %out_tensor_42[%c2] : tensor<4x!qco.qubit>
    %out_tensor_44, %result_45 = qtensor.extract %14[%c3] : tensor<4x!qco.qubit>
    %15 = qco.rz(%cst_23) %result_45 : !qco.qubit -> !qco.qubit
    %16 = qtensor.insert %15 into %out_tensor_44[%c3] : tensor<4x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %16[%c3] : tensor<4x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %out_tensor_46[%c0] : tensor<4x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_47) targets (%arg0 = %result_49) {
      %89 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qtensor.insert %targets_out into %out_tensor_48[%c0] : tensor<4x!qco.qubit>
    %18 = qtensor.insert %controls_out into %17[%c3] : tensor<4x!qco.qubit>
    %out_tensor_50, %result_51 = qtensor.extract %18[%c0] : tensor<4x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %out_tensor_50[%c1] : tensor<4x!qco.qubit>
    %controls_out_54, %targets_out_55 = qco.ctrl(%result_51) targets (%arg0 = %result_53) {
      %89 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qtensor.insert %targets_out_55 into %out_tensor_52[%c1] : tensor<4x!qco.qubit>
    %20 = qtensor.insert %controls_out_54 into %19[%c0] : tensor<4x!qco.qubit>
    %out_tensor_56, %result_57 = qtensor.extract %20[%c1] : tensor<4x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %out_tensor_56[%c2] : tensor<4x!qco.qubit>
    %controls_out_60, %targets_out_61 = qco.ctrl(%result_57) targets (%arg0 = %result_59) {
      %89 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qtensor.insert %targets_out_61 into %out_tensor_58[%c2] : tensor<4x!qco.qubit>
    %22 = qtensor.insert %controls_out_60 into %21[%c1] : tensor<4x!qco.qubit>
    %out_tensor_62, %result_63 = qtensor.extract %22[%c2] : tensor<4x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %out_tensor_62[%c3] : tensor<4x!qco.qubit>
    %controls_out_66, %targets_out_67 = qco.ctrl(%result_63) targets (%arg0 = %result_65) {
      %89 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qtensor.insert %targets_out_67 into %out_tensor_64[%c3] : tensor<4x!qco.qubit>
    %24 = qtensor.insert %controls_out_66 into %23[%c2] : tensor<4x!qco.qubit>
    %out_tensor_68, %result_69 = qtensor.extract %24[%c0] : tensor<4x!qco.qubit>
    %25 = qco.ry(%cst_22) %result_69 : !qco.qubit -> !qco.qubit
    %26 = qtensor.insert %25 into %out_tensor_68[%c0] : tensor<4x!qco.qubit>
    %out_tensor_70, %result_71 = qtensor.extract %26[%c1] : tensor<4x!qco.qubit>
    %27 = qco.ry(%cst_21) %result_71 : !qco.qubit -> !qco.qubit
    %28 = qtensor.insert %27 into %out_tensor_70[%c1] : tensor<4x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %28[%c2] : tensor<4x!qco.qubit>
    %29 = qco.ry(%cst_20) %result_73 : !qco.qubit -> !qco.qubit
    %30 = qtensor.insert %29 into %out_tensor_72[%c2] : tensor<4x!qco.qubit>
    %out_tensor_74, %result_75 = qtensor.extract %30[%c3] : tensor<4x!qco.qubit>
    %31 = qco.ry(%cst_19) %result_75 : !qco.qubit -> !qco.qubit
    %32 = qtensor.insert %31 into %out_tensor_74[%c3] : tensor<4x!qco.qubit>
    %out_tensor_76, %result_77 = qtensor.extract %32[%c0] : tensor<4x!qco.qubit>
    %33 = qco.rz(%cst_18) %result_77 : !qco.qubit -> !qco.qubit
    %34 = qtensor.insert %33 into %out_tensor_76[%c0] : tensor<4x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %34[%c1] : tensor<4x!qco.qubit>
    %35 = qco.rz(%cst_17) %result_79 : !qco.qubit -> !qco.qubit
    %36 = qtensor.insert %35 into %out_tensor_78[%c1] : tensor<4x!qco.qubit>
    %out_tensor_80, %result_81 = qtensor.extract %36[%c2] : tensor<4x!qco.qubit>
    %37 = qco.rz(%cst_16) %result_81 : !qco.qubit -> !qco.qubit
    %38 = qtensor.insert %37 into %out_tensor_80[%c2] : tensor<4x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %38[%c3] : tensor<4x!qco.qubit>
    %39 = qco.rz(%cst_15) %result_83 : !qco.qubit -> !qco.qubit
    %40 = qtensor.insert %39 into %out_tensor_82[%c3] : tensor<4x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %40[%c3] : tensor<4x!qco.qubit>
    %out_tensor_86, %result_87 = qtensor.extract %out_tensor_84[%c0] : tensor<4x!qco.qubit>
    %controls_out_88, %targets_out_89 = qco.ctrl(%result_85) targets (%arg0 = %result_87) {
      %89 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qtensor.insert %targets_out_89 into %out_tensor_86[%c0] : tensor<4x!qco.qubit>
    %42 = qtensor.insert %controls_out_88 into %41[%c3] : tensor<4x!qco.qubit>
    %out_tensor_90, %result_91 = qtensor.extract %42[%c0] : tensor<4x!qco.qubit>
    %out_tensor_92, %result_93 = qtensor.extract %out_tensor_90[%c1] : tensor<4x!qco.qubit>
    %controls_out_94, %targets_out_95 = qco.ctrl(%result_91) targets (%arg0 = %result_93) {
      %89 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qtensor.insert %targets_out_95 into %out_tensor_92[%c1] : tensor<4x!qco.qubit>
    %44 = qtensor.insert %controls_out_94 into %43[%c0] : tensor<4x!qco.qubit>
    %out_tensor_96, %result_97 = qtensor.extract %44[%c1] : tensor<4x!qco.qubit>
    %out_tensor_98, %result_99 = qtensor.extract %out_tensor_96[%c2] : tensor<4x!qco.qubit>
    %controls_out_100, %targets_out_101 = qco.ctrl(%result_97) targets (%arg0 = %result_99) {
      %89 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qtensor.insert %targets_out_101 into %out_tensor_98[%c2] : tensor<4x!qco.qubit>
    %46 = qtensor.insert %controls_out_100 into %45[%c1] : tensor<4x!qco.qubit>
    %out_tensor_102, %result_103 = qtensor.extract %46[%c2] : tensor<4x!qco.qubit>
    %out_tensor_104, %result_105 = qtensor.extract %out_tensor_102[%c3] : tensor<4x!qco.qubit>
    %controls_out_106, %targets_out_107 = qco.ctrl(%result_103) targets (%arg0 = %result_105) {
      %89 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qtensor.insert %targets_out_107 into %out_tensor_104[%c3] : tensor<4x!qco.qubit>
    %48 = qtensor.insert %controls_out_106 into %47[%c2] : tensor<4x!qco.qubit>
    %out_tensor_108, %result_109 = qtensor.extract %48[%c0] : tensor<4x!qco.qubit>
    %49 = qco.ry(%cst_14) %result_109 : !qco.qubit -> !qco.qubit
    %50 = qtensor.insert %49 into %out_tensor_108[%c0] : tensor<4x!qco.qubit>
    %out_tensor_110, %result_111 = qtensor.extract %50[%c1] : tensor<4x!qco.qubit>
    %51 = qco.ry(%cst_13) %result_111 : !qco.qubit -> !qco.qubit
    %52 = qtensor.insert %51 into %out_tensor_110[%c1] : tensor<4x!qco.qubit>
    %out_tensor_112, %result_113 = qtensor.extract %52[%c2] : tensor<4x!qco.qubit>
    %53 = qco.ry(%cst_12) %result_113 : !qco.qubit -> !qco.qubit
    %54 = qtensor.insert %53 into %out_tensor_112[%c2] : tensor<4x!qco.qubit>
    %out_tensor_114, %result_115 = qtensor.extract %54[%c3] : tensor<4x!qco.qubit>
    %55 = qco.ry(%cst_11) %result_115 : !qco.qubit -> !qco.qubit
    %56 = qtensor.insert %55 into %out_tensor_114[%c3] : tensor<4x!qco.qubit>
    %out_tensor_116, %result_117 = qtensor.extract %56[%c0] : tensor<4x!qco.qubit>
    %57 = qco.rz(%cst_10) %result_117 : !qco.qubit -> !qco.qubit
    %58 = qtensor.insert %57 into %out_tensor_116[%c0] : tensor<4x!qco.qubit>
    %out_tensor_118, %result_119 = qtensor.extract %58[%c1] : tensor<4x!qco.qubit>
    %59 = qco.rz(%cst_9) %result_119 : !qco.qubit -> !qco.qubit
    %60 = qtensor.insert %59 into %out_tensor_118[%c1] : tensor<4x!qco.qubit>
    %out_tensor_120, %result_121 = qtensor.extract %60[%c2] : tensor<4x!qco.qubit>
    %61 = qco.rz(%cst_8) %result_121 : !qco.qubit -> !qco.qubit
    %62 = qtensor.insert %61 into %out_tensor_120[%c2] : tensor<4x!qco.qubit>
    %out_tensor_122, %result_123 = qtensor.extract %62[%c3] : tensor<4x!qco.qubit>
    %63 = qco.rz(%cst_7) %result_123 : !qco.qubit -> !qco.qubit
    %64 = qtensor.insert %63 into %out_tensor_122[%c3] : tensor<4x!qco.qubit>
    %out_tensor_124, %result_125 = qtensor.extract %64[%c3] : tensor<4x!qco.qubit>
    %out_tensor_126, %result_127 = qtensor.extract %out_tensor_124[%c0] : tensor<4x!qco.qubit>
    %controls_out_128, %targets_out_129 = qco.ctrl(%result_125) targets (%arg0 = %result_127) {
      %89 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qtensor.insert %targets_out_129 into %out_tensor_126[%c0] : tensor<4x!qco.qubit>
    %66 = qtensor.insert %controls_out_128 into %65[%c3] : tensor<4x!qco.qubit>
    %out_tensor_130, %result_131 = qtensor.extract %66[%c0] : tensor<4x!qco.qubit>
    %out_tensor_132, %result_133 = qtensor.extract %out_tensor_130[%c1] : tensor<4x!qco.qubit>
    %controls_out_134, %targets_out_135 = qco.ctrl(%result_131) targets (%arg0 = %result_133) {
      %89 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %67 = qtensor.insert %targets_out_135 into %out_tensor_132[%c1] : tensor<4x!qco.qubit>
    %68 = qtensor.insert %controls_out_134 into %67[%c0] : tensor<4x!qco.qubit>
    %out_tensor_136, %result_137 = qtensor.extract %68[%c1] : tensor<4x!qco.qubit>
    %out_tensor_138, %result_139 = qtensor.extract %out_tensor_136[%c2] : tensor<4x!qco.qubit>
    %controls_out_140, %targets_out_141 = qco.ctrl(%result_137) targets (%arg0 = %result_139) {
      %89 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qtensor.insert %targets_out_141 into %out_tensor_138[%c2] : tensor<4x!qco.qubit>
    %70 = qtensor.insert %controls_out_140 into %69[%c1] : tensor<4x!qco.qubit>
    %out_tensor_142, %result_143 = qtensor.extract %70[%c2] : tensor<4x!qco.qubit>
    %out_tensor_144, %result_145 = qtensor.extract %out_tensor_142[%c3] : tensor<4x!qco.qubit>
    %controls_out_146, %targets_out_147 = qco.ctrl(%result_143) targets (%arg0 = %result_145) {
      %89 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %89 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qtensor.insert %targets_out_147 into %out_tensor_144[%c3] : tensor<4x!qco.qubit>
    %72 = qtensor.insert %controls_out_146 into %71[%c2] : tensor<4x!qco.qubit>
    %out_tensor_148, %result_149 = qtensor.extract %72[%c0] : tensor<4x!qco.qubit>
    %73 = qco.ry(%cst_6) %result_149 : !qco.qubit -> !qco.qubit
    %74 = qtensor.insert %73 into %out_tensor_148[%c0] : tensor<4x!qco.qubit>
    %out_tensor_150, %result_151 = qtensor.extract %74[%c1] : tensor<4x!qco.qubit>
    %75 = qco.ry(%cst_5) %result_151 : !qco.qubit -> !qco.qubit
    %76 = qtensor.insert %75 into %out_tensor_150[%c1] : tensor<4x!qco.qubit>
    %out_tensor_152, %result_153 = qtensor.extract %76[%c2] : tensor<4x!qco.qubit>
    %77 = qco.ry(%cst_4) %result_153 : !qco.qubit -> !qco.qubit
    %78 = qtensor.insert %77 into %out_tensor_152[%c2] : tensor<4x!qco.qubit>
    %out_tensor_154, %result_155 = qtensor.extract %78[%c3] : tensor<4x!qco.qubit>
    %79 = qco.ry(%cst_3) %result_155 : !qco.qubit -> !qco.qubit
    %80 = qtensor.insert %79 into %out_tensor_154[%c3] : tensor<4x!qco.qubit>
    %out_tensor_156, %result_157 = qtensor.extract %80[%c0] : tensor<4x!qco.qubit>
    %81 = qco.rz(%cst_2) %result_157 : !qco.qubit -> !qco.qubit
    %82 = qtensor.insert %81 into %out_tensor_156[%c0] : tensor<4x!qco.qubit>
    %out_tensor_158, %result_159 = qtensor.extract %82[%c1] : tensor<4x!qco.qubit>
    %83 = qco.rz(%cst_1) %result_159 : !qco.qubit -> !qco.qubit
    %84 = qtensor.insert %83 into %out_tensor_158[%c1] : tensor<4x!qco.qubit>
    %out_tensor_160, %result_161 = qtensor.extract %84[%c2] : tensor<4x!qco.qubit>
    %85 = qco.rz(%cst_0) %result_161 : !qco.qubit -> !qco.qubit
    %86 = qtensor.insert %85 into %out_tensor_160[%c2] : tensor<4x!qco.qubit>
    %out_tensor_162, %result_163 = qtensor.extract %86[%c3] : tensor<4x!qco.qubit>
    %87 = qco.rz(%cst) %result_163 : !qco.qubit -> !qco.qubit
    %88 = qtensor.insert %87 into %out_tensor_162[%c3] : tensor<4x!qco.qubit>
    qtensor.dealloc %88 : tensor<4x!qco.qubit>
    return %c0_i64 : i64
  }
}
