module {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant 0.024543692606170259 : f64
    %cst_0 = arith.constant 0.049087385212340517 : f64
    %cst_1 = arith.constant 0.098174770424681035 : f64
    %cst_2 = arith.constant 0.19634954084936207 : f64
    %cst_3 = arith.constant 0.39269908169872414 : f64
    %cst_4 = arith.constant 0.78539816339744828 : f64
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %cst_5 = arith.constant 1.5707963267948966 : f64
    %c7 = arith.constant 7 : index
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c8 = arith.constant 8 : index
    %c4 = arith.constant 4 : index
    %0 = qtensor.alloc(%c8) {mqt.register_name = "query"} : tensor<8x!qco.qubit>
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %out_tensor, %result = qtensor.extract %0[%c4] : tensor<8x!qco.qubit>
    %2 = qco.h %result : !qco.qubit -> !qco.qubit
    %3 = qtensor.insert %2 into %out_tensor[%c4] : tensor<8x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %3[%c5] : tensor<8x!qco.qubit>
    %4 = qco.h %result_7 : !qco.qubit -> !qco.qubit
    %5 = qtensor.insert %4 into %out_tensor_6[%c5] : tensor<8x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %5[%c6] : tensor<8x!qco.qubit>
    %6 = qco.h %result_9 : !qco.qubit -> !qco.qubit
    %7 = qtensor.insert %6 into %out_tensor_8[%c6] : tensor<8x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %7[%c7] : tensor<8x!qco.qubit>
    %8 = qco.h %result_11 : !qco.qubit -> !qco.qubit
    %9 = qtensor.insert %8 into %out_tensor_10[%c7] : tensor<8x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %9[%c7] : tensor<8x!qco.qubit>
    %10 = qco.h %result_13 : !qco.qubit -> !qco.qubit
    %11 = qtensor.insert %10 into %out_tensor_12[%c7] : tensor<8x!qco.qubit>
    %out_tensor_14, %result_15 = qtensor.extract %11[%c6] : tensor<8x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %out_tensor_14[%c7] : tensor<8x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_15) targets (%arg0 = %result_17) {
      %90 = qco.p(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qtensor.insert %targets_out into %out_tensor_16[%c7] : tensor<8x!qco.qubit>
    %13 = qtensor.insert %controls_out into %12[%c6] : tensor<8x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %13[%c5] : tensor<8x!qco.qubit>
    %out_tensor_20, %result_21 = qtensor.extract %out_tensor_18[%c7] : tensor<8x!qco.qubit>
    %controls_out_22, %targets_out_23 = qco.ctrl(%result_19) targets (%arg0 = %result_21) {
      %90 = qco.p(%cst_4) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qtensor.insert %targets_out_23 into %out_tensor_20[%c7] : tensor<8x!qco.qubit>
    %15 = qtensor.insert %controls_out_22 into %14[%c5] : tensor<8x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %15[%c4] : tensor<8x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %out_tensor_24[%c7] : tensor<8x!qco.qubit>
    %controls_out_28, %targets_out_29 = qco.ctrl(%result_25) targets (%arg0 = %result_27) {
      %90 = qco.p(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qtensor.insert %targets_out_29 into %out_tensor_26[%c7] : tensor<8x!qco.qubit>
    %17 = qtensor.insert %controls_out_28 into %16[%c4] : tensor<8x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %17[%c3] : tensor<8x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %out_tensor_30[%c7] : tensor<8x!qco.qubit>
    %controls_out_34, %targets_out_35 = qco.ctrl(%result_31) targets (%arg0 = %result_33) {
      %90 = qco.p(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qtensor.insert %targets_out_35 into %out_tensor_32[%c7] : tensor<8x!qco.qubit>
    %19 = qtensor.insert %controls_out_34 into %18[%c3] : tensor<8x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %19[%c2] : tensor<8x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %out_tensor_36[%c7] : tensor<8x!qco.qubit>
    %controls_out_40, %targets_out_41 = qco.ctrl(%result_37) targets (%arg0 = %result_39) {
      %90 = qco.p(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qtensor.insert %targets_out_41 into %out_tensor_38[%c7] : tensor<8x!qco.qubit>
    %21 = qtensor.insert %controls_out_40 into %20[%c2] : tensor<8x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %21[%c1] : tensor<8x!qco.qubit>
    %out_tensor_44, %result_45 = qtensor.extract %out_tensor_42[%c7] : tensor<8x!qco.qubit>
    %controls_out_46, %targets_out_47 = qco.ctrl(%result_43) targets (%arg0 = %result_45) {
      %90 = qco.p(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qtensor.insert %targets_out_47 into %out_tensor_44[%c7] : tensor<8x!qco.qubit>
    %23 = qtensor.insert %controls_out_46 into %22[%c1] : tensor<8x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %23[%c0] : tensor<8x!qco.qubit>
    %out_tensor_50, %result_51 = qtensor.extract %out_tensor_48[%c7] : tensor<8x!qco.qubit>
    %controls_out_52, %targets_out_53 = qco.ctrl(%result_49) targets (%arg0 = %result_51) {
      %90 = qco.p(%cst) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qtensor.insert %targets_out_53 into %out_tensor_50[%c7] : tensor<8x!qco.qubit>
    %25 = qtensor.insert %controls_out_52 into %24[%c0] : tensor<8x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %25[%c6] : tensor<8x!qco.qubit>
    %26 = qco.h %result_55 : !qco.qubit -> !qco.qubit
    %27 = qtensor.insert %26 into %out_tensor_54[%c6] : tensor<8x!qco.qubit>
    %out_tensor_56, %result_57 = qtensor.extract %27[%c5] : tensor<8x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %out_tensor_56[%c6] : tensor<8x!qco.qubit>
    %controls_out_60, %targets_out_61 = qco.ctrl(%result_57) targets (%arg0 = %result_59) {
      %90 = qco.p(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qtensor.insert %targets_out_61 into %out_tensor_58[%c6] : tensor<8x!qco.qubit>
    %29 = qtensor.insert %controls_out_60 into %28[%c5] : tensor<8x!qco.qubit>
    %out_tensor_62, %result_63 = qtensor.extract %29[%c4] : tensor<8x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %out_tensor_62[%c6] : tensor<8x!qco.qubit>
    %controls_out_66, %targets_out_67 = qco.ctrl(%result_63) targets (%arg0 = %result_65) {
      %90 = qco.p(%cst_4) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qtensor.insert %targets_out_67 into %out_tensor_64[%c6] : tensor<8x!qco.qubit>
    %31 = qtensor.insert %controls_out_66 into %30[%c4] : tensor<8x!qco.qubit>
    %out_tensor_68, %result_69 = qtensor.extract %31[%c3] : tensor<8x!qco.qubit>
    %out_tensor_70, %result_71 = qtensor.extract %out_tensor_68[%c6] : tensor<8x!qco.qubit>
    %controls_out_72, %targets_out_73 = qco.ctrl(%result_69) targets (%arg0 = %result_71) {
      %90 = qco.p(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qtensor.insert %targets_out_73 into %out_tensor_70[%c6] : tensor<8x!qco.qubit>
    %33 = qtensor.insert %controls_out_72 into %32[%c3] : tensor<8x!qco.qubit>
    %out_tensor_74, %result_75 = qtensor.extract %33[%c2] : tensor<8x!qco.qubit>
    %out_tensor_76, %result_77 = qtensor.extract %out_tensor_74[%c6] : tensor<8x!qco.qubit>
    %controls_out_78, %targets_out_79 = qco.ctrl(%result_75) targets (%arg0 = %result_77) {
      %90 = qco.p(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qtensor.insert %targets_out_79 into %out_tensor_76[%c6] : tensor<8x!qco.qubit>
    %35 = qtensor.insert %controls_out_78 into %34[%c2] : tensor<8x!qco.qubit>
    %out_tensor_80, %result_81 = qtensor.extract %35[%c1] : tensor<8x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %out_tensor_80[%c6] : tensor<8x!qco.qubit>
    %controls_out_84, %targets_out_85 = qco.ctrl(%result_81) targets (%arg0 = %result_83) {
      %90 = qco.p(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qtensor.insert %targets_out_85 into %out_tensor_82[%c6] : tensor<8x!qco.qubit>
    %37 = qtensor.insert %controls_out_84 into %36[%c1] : tensor<8x!qco.qubit>
    %out_tensor_86, %result_87 = qtensor.extract %37[%c0] : tensor<8x!qco.qubit>
    %out_tensor_88, %result_89 = qtensor.extract %out_tensor_86[%c6] : tensor<8x!qco.qubit>
    %controls_out_90, %targets_out_91 = qco.ctrl(%result_87) targets (%arg0 = %result_89) {
      %90 = qco.p(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qtensor.insert %targets_out_91 into %out_tensor_88[%c6] : tensor<8x!qco.qubit>
    %39 = qtensor.insert %controls_out_90 into %38[%c0] : tensor<8x!qco.qubit>
    %out_tensor_92, %result_93 = qtensor.extract %39[%c5] : tensor<8x!qco.qubit>
    %40 = qco.h %result_93 : !qco.qubit -> !qco.qubit
    %41 = qtensor.insert %40 into %out_tensor_92[%c5] : tensor<8x!qco.qubit>
    %out_tensor_94, %result_95 = qtensor.extract %41[%c4] : tensor<8x!qco.qubit>
    %out_tensor_96, %result_97 = qtensor.extract %out_tensor_94[%c5] : tensor<8x!qco.qubit>
    %controls_out_98, %targets_out_99 = qco.ctrl(%result_95) targets (%arg0 = %result_97) {
      %90 = qco.p(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qtensor.insert %targets_out_99 into %out_tensor_96[%c5] : tensor<8x!qco.qubit>
    %43 = qtensor.insert %controls_out_98 into %42[%c4] : tensor<8x!qco.qubit>
    %out_tensor_100, %result_101 = qtensor.extract %43[%c3] : tensor<8x!qco.qubit>
    %out_tensor_102, %result_103 = qtensor.extract %out_tensor_100[%c5] : tensor<8x!qco.qubit>
    %controls_out_104, %targets_out_105 = qco.ctrl(%result_101) targets (%arg0 = %result_103) {
      %90 = qco.p(%cst_4) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = qtensor.insert %targets_out_105 into %out_tensor_102[%c5] : tensor<8x!qco.qubit>
    %45 = qtensor.insert %controls_out_104 into %44[%c3] : tensor<8x!qco.qubit>
    %out_tensor_106, %result_107 = qtensor.extract %45[%c2] : tensor<8x!qco.qubit>
    %out_tensor_108, %result_109 = qtensor.extract %out_tensor_106[%c5] : tensor<8x!qco.qubit>
    %controls_out_110, %targets_out_111 = qco.ctrl(%result_107) targets (%arg0 = %result_109) {
      %90 = qco.p(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qtensor.insert %targets_out_111 into %out_tensor_108[%c5] : tensor<8x!qco.qubit>
    %47 = qtensor.insert %controls_out_110 into %46[%c2] : tensor<8x!qco.qubit>
    %out_tensor_112, %result_113 = qtensor.extract %47[%c1] : tensor<8x!qco.qubit>
    %out_tensor_114, %result_115 = qtensor.extract %out_tensor_112[%c5] : tensor<8x!qco.qubit>
    %controls_out_116, %targets_out_117 = qco.ctrl(%result_113) targets (%arg0 = %result_115) {
      %90 = qco.p(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %48 = qtensor.insert %targets_out_117 into %out_tensor_114[%c5] : tensor<8x!qco.qubit>
    %49 = qtensor.insert %controls_out_116 into %48[%c1] : tensor<8x!qco.qubit>
    %out_tensor_118, %result_119 = qtensor.extract %49[%c0] : tensor<8x!qco.qubit>
    %out_tensor_120, %result_121 = qtensor.extract %out_tensor_118[%c5] : tensor<8x!qco.qubit>
    %controls_out_122, %targets_out_123 = qco.ctrl(%result_119) targets (%arg0 = %result_121) {
      %90 = qco.p(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qtensor.insert %targets_out_123 into %out_tensor_120[%c5] : tensor<8x!qco.qubit>
    %51 = qtensor.insert %controls_out_122 into %50[%c0] : tensor<8x!qco.qubit>
    %out_tensor_124, %result_125 = qtensor.extract %51[%c4] : tensor<8x!qco.qubit>
    %52 = qco.h %result_125 : !qco.qubit -> !qco.qubit
    %53 = qtensor.insert %52 into %out_tensor_124[%c4] : tensor<8x!qco.qubit>
    %out_tensor_126, %result_127 = qtensor.extract %53[%c3] : tensor<8x!qco.qubit>
    %out_tensor_128, %result_129 = qtensor.extract %out_tensor_126[%c4] : tensor<8x!qco.qubit>
    %controls_out_130, %targets_out_131 = qco.ctrl(%result_127) targets (%arg0 = %result_129) {
      %90 = qco.p(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %54 = qtensor.insert %targets_out_131 into %out_tensor_128[%c4] : tensor<8x!qco.qubit>
    %55 = qtensor.insert %controls_out_130 into %54[%c3] : tensor<8x!qco.qubit>
    %out_tensor_132, %result_133 = qtensor.extract %55[%c2] : tensor<8x!qco.qubit>
    %out_tensor_134, %result_135 = qtensor.extract %out_tensor_132[%c4] : tensor<8x!qco.qubit>
    %controls_out_136, %targets_out_137 = qco.ctrl(%result_133) targets (%arg0 = %result_135) {
      %90 = qco.p(%cst_4) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qtensor.insert %targets_out_137 into %out_tensor_134[%c4] : tensor<8x!qco.qubit>
    %57 = qtensor.insert %controls_out_136 into %56[%c2] : tensor<8x!qco.qubit>
    %out_tensor_138, %result_139 = qtensor.extract %57[%c1] : tensor<8x!qco.qubit>
    %out_tensor_140, %result_141 = qtensor.extract %out_tensor_138[%c4] : tensor<8x!qco.qubit>
    %controls_out_142, %targets_out_143 = qco.ctrl(%result_139) targets (%arg0 = %result_141) {
      %90 = qco.p(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = qtensor.insert %targets_out_143 into %out_tensor_140[%c4] : tensor<8x!qco.qubit>
    %59 = qtensor.insert %controls_out_142 into %58[%c1] : tensor<8x!qco.qubit>
    %out_tensor_144, %result_145 = qtensor.extract %59[%c0] : tensor<8x!qco.qubit>
    %out_tensor_146, %result_147 = qtensor.extract %out_tensor_144[%c4] : tensor<8x!qco.qubit>
    %controls_out_148, %targets_out_149 = qco.ctrl(%result_145) targets (%arg0 = %result_147) {
      %90 = qco.p(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qtensor.insert %targets_out_149 into %out_tensor_146[%c4] : tensor<8x!qco.qubit>
    %61 = qtensor.insert %controls_out_148 into %60[%c0] : tensor<8x!qco.qubit>
    %out_tensor_150, %result_151 = qtensor.extract %61[%c3] : tensor<8x!qco.qubit>
    %62 = qco.h %result_151 : !qco.qubit -> !qco.qubit
    %63 = qtensor.insert %62 into %out_tensor_150[%c3] : tensor<8x!qco.qubit>
    %out_tensor_152, %result_153 = qtensor.extract %63[%c2] : tensor<8x!qco.qubit>
    %out_tensor_154, %result_155 = qtensor.extract %out_tensor_152[%c3] : tensor<8x!qco.qubit>
    %controls_out_156, %targets_out_157 = qco.ctrl(%result_153) targets (%arg0 = %result_155) {
      %90 = qco.p(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %64 = qtensor.insert %targets_out_157 into %out_tensor_154[%c3] : tensor<8x!qco.qubit>
    %65 = qtensor.insert %controls_out_156 into %64[%c2] : tensor<8x!qco.qubit>
    %out_tensor_158, %result_159 = qtensor.extract %65[%c1] : tensor<8x!qco.qubit>
    %out_tensor_160, %result_161 = qtensor.extract %out_tensor_158[%c3] : tensor<8x!qco.qubit>
    %controls_out_162, %targets_out_163 = qco.ctrl(%result_159) targets (%arg0 = %result_161) {
      %90 = qco.p(%cst_4) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = qtensor.insert %targets_out_163 into %out_tensor_160[%c3] : tensor<8x!qco.qubit>
    %67 = qtensor.insert %controls_out_162 into %66[%c1] : tensor<8x!qco.qubit>
    %out_tensor_164, %result_165 = qtensor.extract %67[%c0] : tensor<8x!qco.qubit>
    %out_tensor_166, %result_167 = qtensor.extract %out_tensor_164[%c3] : tensor<8x!qco.qubit>
    %controls_out_168, %targets_out_169 = qco.ctrl(%result_165) targets (%arg0 = %result_167) {
      %90 = qco.p(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %68 = qtensor.insert %targets_out_169 into %out_tensor_166[%c3] : tensor<8x!qco.qubit>
    %69 = qtensor.insert %controls_out_168 into %68[%c0] : tensor<8x!qco.qubit>
    %out_tensor_170, %result_171 = qtensor.extract %69[%c2] : tensor<8x!qco.qubit>
    %70 = qco.h %result_171 : !qco.qubit -> !qco.qubit
    %71 = qtensor.insert %70 into %out_tensor_170[%c2] : tensor<8x!qco.qubit>
    %out_tensor_172, %result_173 = qtensor.extract %71[%c1] : tensor<8x!qco.qubit>
    %out_tensor_174, %result_175 = qtensor.extract %out_tensor_172[%c2] : tensor<8x!qco.qubit>
    %controls_out_176, %targets_out_177 = qco.ctrl(%result_173) targets (%arg0 = %result_175) {
      %90 = qco.p(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %72 = qtensor.insert %targets_out_177 into %out_tensor_174[%c2] : tensor<8x!qco.qubit>
    %73 = qtensor.insert %controls_out_176 into %72[%c1] : tensor<8x!qco.qubit>
    %out_tensor_178, %result_179 = qtensor.extract %73[%c0] : tensor<8x!qco.qubit>
    %out_tensor_180, %result_181 = qtensor.extract %out_tensor_178[%c2] : tensor<8x!qco.qubit>
    %controls_out_182, %targets_out_183 = qco.ctrl(%result_179) targets (%arg0 = %result_181) {
      %90 = qco.p(%cst_4) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %74 = qtensor.insert %targets_out_183 into %out_tensor_180[%c2] : tensor<8x!qco.qubit>
    %75 = qtensor.insert %controls_out_182 into %74[%c0] : tensor<8x!qco.qubit>
    %out_tensor_184, %result_185 = qtensor.extract %75[%c1] : tensor<8x!qco.qubit>
    %76 = qco.h %result_185 : !qco.qubit -> !qco.qubit
    %77 = qtensor.insert %76 into %out_tensor_184[%c1] : tensor<8x!qco.qubit>
    %out_tensor_186, %result_187 = qtensor.extract %77[%c0] : tensor<8x!qco.qubit>
    %out_tensor_188, %result_189 = qtensor.extract %out_tensor_186[%c1] : tensor<8x!qco.qubit>
    %controls_out_190, %targets_out_191 = qco.ctrl(%result_187) targets (%arg0 = %result_189) {
      %90 = qco.p(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %90 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %78 = qtensor.insert %targets_out_191 into %out_tensor_188[%c1] : tensor<8x!qco.qubit>
    %79 = qtensor.insert %controls_out_190 into %78[%c0] : tensor<8x!qco.qubit>
    %out_tensor_192, %result_193 = qtensor.extract %79[%c0] : tensor<8x!qco.qubit>
    %80 = qco.h %result_193 : !qco.qubit -> !qco.qubit
    %81 = qtensor.insert %80 into %out_tensor_192[%c0] : tensor<8x!qco.qubit>
    %out_tensor_194, %result_195 = qtensor.extract %81[%c0] : tensor<8x!qco.qubit>
    %qubit_out, %result_196 = qco.measure %result_195 : !qco.qubit
    %82 = qtensor.insert %qubit_out into %out_tensor_194[%c0] : tensor<8x!qco.qubit>
    cbit.store %result_196, %1[%c7] : !cbit.reg<8>
    %out_tensor_197, %result_198 = qtensor.extract %82[%c1] : tensor<8x!qco.qubit>
    %qubit_out_199, %result_200 = qco.measure %result_198 : !qco.qubit
    %83 = qtensor.insert %qubit_out_199 into %out_tensor_197[%c1] : tensor<8x!qco.qubit>
    cbit.store %result_200, %1[%c6] : !cbit.reg<8>
    %out_tensor_201, %result_202 = qtensor.extract %83[%c2] : tensor<8x!qco.qubit>
    %qubit_out_203, %result_204 = qco.measure %result_202 : !qco.qubit
    %84 = qtensor.insert %qubit_out_203 into %out_tensor_201[%c2] : tensor<8x!qco.qubit>
    cbit.store %result_204, %1[%c5] : !cbit.reg<8>
    %out_tensor_205, %result_206 = qtensor.extract %84[%c3] : tensor<8x!qco.qubit>
    %qubit_out_207, %result_208 = qco.measure %result_206 : !qco.qubit
    %85 = qtensor.insert %qubit_out_207 into %out_tensor_205[%c3] : tensor<8x!qco.qubit>
    cbit.store %result_208, %1[%c4] : !cbit.reg<8>
    %out_tensor_209, %result_210 = qtensor.extract %85[%c4] : tensor<8x!qco.qubit>
    %qubit_out_211, %result_212 = qco.measure %result_210 : !qco.qubit
    %86 = qtensor.insert %qubit_out_211 into %out_tensor_209[%c4] : tensor<8x!qco.qubit>
    cbit.store %result_212, %1[%c3] : !cbit.reg<8>
    %out_tensor_213, %result_214 = qtensor.extract %86[%c5] : tensor<8x!qco.qubit>
    %qubit_out_215, %result_216 = qco.measure %result_214 : !qco.qubit
    %87 = qtensor.insert %qubit_out_215 into %out_tensor_213[%c5] : tensor<8x!qco.qubit>
    cbit.store %result_216, %1[%c2] : !cbit.reg<8>
    %out_tensor_217, %result_218 = qtensor.extract %87[%c6] : tensor<8x!qco.qubit>
    %qubit_out_219, %result_220 = qco.measure %result_218 : !qco.qubit
    %88 = qtensor.insert %qubit_out_219 into %out_tensor_217[%c6] : tensor<8x!qco.qubit>
    cbit.store %result_220, %1[%c1] : !cbit.reg<8>
    %out_tensor_221, %result_222 = qtensor.extract %88[%c7] : tensor<8x!qco.qubit>
    %qubit_out_223, %result_224 = qco.measure %result_222 : !qco.qubit
    %89 = qtensor.insert %qubit_out_223 into %out_tensor_221[%c7] : tensor<8x!qco.qubit>
    cbit.store %result_224, %1[%c0] : !cbit.reg<8>
    qtensor.dealloc %89 : tensor<8x!qco.qubit>
    return %1 : !cbit.reg<8>
  }
}
