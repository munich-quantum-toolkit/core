module {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant 0.049087385212340517 : f64
    %cst_0 = arith.constant 0.098174770424681035 : f64
    %cst_1 = arith.constant 0.19634954084936207 : f64
    %cst_2 = arith.constant 0.39269908169872414 : f64
    %cst_3 = arith.constant 0.78539816339744828 : f64
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %cst_4 = arith.constant 1.5707963267948966 : f64
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %0 = qtensor.alloc(%c6) {mqt.register_name = "controls"} : tensor<6x!qco.qubit>
    %1 = qco.alloc : !qco.qubit
    %2 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<6x!qco.qubit>
    %3 = qco.h %result : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor[%c0] : tensor<6x!qco.qubit>
    %out_tensor_5, %result_6 = qtensor.extract %4[%c1] : tensor<6x!qco.qubit>
    %5 = qco.h %result_6 : !qco.qubit -> !qco.qubit
    %6 = qtensor.insert %5 into %out_tensor_5[%c1] : tensor<6x!qco.qubit>
    %out_tensor_7, %result_8 = qtensor.extract %6[%c2] : tensor<6x!qco.qubit>
    %7 = qco.h %result_8 : !qco.qubit -> !qco.qubit
    %8 = qtensor.insert %7 into %out_tensor_7[%c2] : tensor<6x!qco.qubit>
    %out_tensor_9, %result_10 = qtensor.extract %8[%c3] : tensor<6x!qco.qubit>
    %9 = qco.h %result_10 : !qco.qubit -> !qco.qubit
    %10 = qtensor.insert %9 into %out_tensor_9[%c3] : tensor<6x!qco.qubit>
    %out_tensor_11, %result_12 = qtensor.extract %10[%c4] : tensor<6x!qco.qubit>
    %11 = qco.h %result_12 : !qco.qubit -> !qco.qubit
    %12 = qtensor.insert %11 into %out_tensor_11[%c4] : tensor<6x!qco.qubit>
    %out_tensor_13, %result_14 = qtensor.extract %12[%c5] : tensor<6x!qco.qubit>
    %13 = qco.h %result_14 : !qco.qubit -> !qco.qubit
    %14 = qtensor.insert %13 into %out_tensor_13[%c5] : tensor<6x!qco.qubit>
    %out_tensor_15, %result_16 = qtensor.extract %14[%c5] : tensor<6x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_16) targets (%arg0 = %1) {
      %27 = qco.ry(%cst_4) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %27 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qtensor.insert %controls_out into %out_tensor_15[%c5] : tensor<6x!qco.qubit>
    %out_tensor_17, %result_18 = qtensor.extract %15[%c4] : tensor<6x!qco.qubit>
    %controls_out_19, %targets_out_20 = qco.ctrl(%result_18) targets (%arg0 = %targets_out) {
      %27 = qco.ry(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %27 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qtensor.insert %controls_out_19 into %out_tensor_17[%c4] : tensor<6x!qco.qubit>
    %out_tensor_21, %result_22 = qtensor.extract %16[%c3] : tensor<6x!qco.qubit>
    %controls_out_23, %targets_out_24 = qco.ctrl(%result_22) targets (%arg0 = %targets_out_20) {
      %27 = qco.ry(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %27 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qtensor.insert %controls_out_23 into %out_tensor_21[%c3] : tensor<6x!qco.qubit>
    %out_tensor_25, %result_26 = qtensor.extract %17[%c2] : tensor<6x!qco.qubit>
    %controls_out_27, %targets_out_28 = qco.ctrl(%result_26) targets (%arg0 = %targets_out_24) {
      %27 = qco.ry(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %27 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qtensor.insert %controls_out_27 into %out_tensor_25[%c2] : tensor<6x!qco.qubit>
    %out_tensor_29, %result_30 = qtensor.extract %18[%c1] : tensor<6x!qco.qubit>
    %controls_out_31, %targets_out_32 = qco.ctrl(%result_30) targets (%arg0 = %targets_out_28) {
      %27 = qco.ry(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %27 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qtensor.insert %controls_out_31 into %out_tensor_29[%c1] : tensor<6x!qco.qubit>
    %out_tensor_33, %result_34 = qtensor.extract %19[%c0] : tensor<6x!qco.qubit>
    %controls_out_35, %targets_out_36 = qco.ctrl(%result_34) targets (%arg0 = %targets_out_32) {
      %27 = qco.ry(%cst) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %27 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qtensor.insert %controls_out_35 into %out_tensor_33[%c0] : tensor<6x!qco.qubit>
    %qubit_out, %result_37 = qco.measure %targets_out_36 : !qco.qubit
    cbit.store %result_37, %2[%c0] : !cbit.reg<7>
    %out_tensor_38, %result_39 = qtensor.extract %20[%c0] : tensor<6x!qco.qubit>
    %qubit_out_40, %result_41 = qco.measure %result_39 : !qco.qubit
    %21 = qtensor.insert %qubit_out_40 into %out_tensor_38[%c0] : tensor<6x!qco.qubit>
    cbit.store %result_41, %2[%c1] : !cbit.reg<7>
    %out_tensor_42, %result_43 = qtensor.extract %21[%c1] : tensor<6x!qco.qubit>
    %qubit_out_44, %result_45 = qco.measure %result_43 : !qco.qubit
    %22 = qtensor.insert %qubit_out_44 into %out_tensor_42[%c1] : tensor<6x!qco.qubit>
    cbit.store %result_45, %2[%c2] : !cbit.reg<7>
    %out_tensor_46, %result_47 = qtensor.extract %22[%c2] : tensor<6x!qco.qubit>
    %qubit_out_48, %result_49 = qco.measure %result_47 : !qco.qubit
    %23 = qtensor.insert %qubit_out_48 into %out_tensor_46[%c2] : tensor<6x!qco.qubit>
    cbit.store %result_49, %2[%c3] : !cbit.reg<7>
    %out_tensor_50, %result_51 = qtensor.extract %23[%c3] : tensor<6x!qco.qubit>
    %qubit_out_52, %result_53 = qco.measure %result_51 : !qco.qubit
    %24 = qtensor.insert %qubit_out_52 into %out_tensor_50[%c3] : tensor<6x!qco.qubit>
    cbit.store %result_53, %2[%c4] : !cbit.reg<7>
    %out_tensor_54, %result_55 = qtensor.extract %24[%c4] : tensor<6x!qco.qubit>
    %qubit_out_56, %result_57 = qco.measure %result_55 : !qco.qubit
    %25 = qtensor.insert %qubit_out_56 into %out_tensor_54[%c4] : tensor<6x!qco.qubit>
    cbit.store %result_57, %2[%c5] : !cbit.reg<7>
    %out_tensor_58, %result_59 = qtensor.extract %25[%c5] : tensor<6x!qco.qubit>
    %qubit_out_60, %result_61 = qco.measure %result_59 : !qco.qubit
    %26 = qtensor.insert %qubit_out_60 into %out_tensor_58[%c5] : tensor<6x!qco.qubit>
    cbit.store %result_61, %2[%c6] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    qtensor.dealloc %26 : tensor<6x!qco.qubit>
    return %2 : !cbit.reg<7>
  }
}
