module {
  func.func @main(%arg0: f64 {mqt.input_id = 12927349219598359841868690406665925546 : i128, mqt.input_name = "theta[0]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 0 : i64, name = "theta", size = 12 : i64}}, %arg1: f64 {mqt.input_id = 12927349219598359841868690406665925547 : i128, mqt.input_name = "theta[1]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 1 : i64, name = "theta", size = 12 : i64}}, %arg2: f64 {mqt.input_id = 12927349219598359841868690406665925548 : i128, mqt.input_name = "theta[2]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 2 : i64, name = "theta", size = 12 : i64}}, %arg3: f64 {mqt.input_id = 12927349219598359841868690406665925549 : i128, mqt.input_name = "theta[3]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 3 : i64, name = "theta", size = 12 : i64}}, %arg4: f64 {mqt.input_id = 12927349219598359841868690406665925550 : i128, mqt.input_name = "theta[4]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 4 : i64, name = "theta", size = 12 : i64}}, %arg5: f64 {mqt.input_id = 12927349219598359841868690406665925551 : i128, mqt.input_name = "theta[5]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 5 : i64, name = "theta", size = 12 : i64}}, %arg6: f64 {mqt.input_id = 12927349219598359841868690406665925552 : i128, mqt.input_name = "theta[6]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 6 : i64, name = "theta", size = 12 : i64}}, %arg7: f64 {mqt.input_id = 12927349219598359841868690406665925553 : i128, mqt.input_name = "theta[7]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 7 : i64, name = "theta", size = 12 : i64}}, %arg8: f64 {mqt.input_id = 12927349219598359841868690406665925554 : i128, mqt.input_name = "theta[8]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 8 : i64, name = "theta", size = 12 : i64}}, %arg9: f64 {mqt.input_id = 12927349219598359841868690406665925555 : i128, mqt.input_name = "theta[9]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 9 : i64, name = "theta", size = 12 : i64}}, %arg10: f64 {mqt.input_id = 12927349219598359841868690406665925556 : i128, mqt.input_name = "theta[10]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 10 : i64, name = "theta", size = 12 : i64}}, %arg11: f64 {mqt.input_id = 12927349219598359841868690406665925557 : i128, mqt.input_name = "theta[11]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 11 : i64, name = "theta", size = 12 : i64}}) -> i64 attributes {mqt.entry_point} {
    %c0_i64 = arith.constant 0 : i64
    %cst = arith.constant 2.000000e-01 : f64
    %cst_0 = arith.constant 3.000000e-01 : f64
    %cst_1 = arith.constant 0.000000e+00 : f64
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c4 = arith.constant 4 : index
    %0 = qtensor.alloc(%c4) {mqt.register_name = "q"} : tensor<4x!qco.qubit>
    qco.gphase(%cst_1)
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<4x!qco.qubit>
    %1 = qco.rz(%arg0) %result : !qco.qubit -> !qco.qubit
    %2 = qtensor.insert %1 into %out_tensor[%c0] : tensor<4x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %2[%c0] : tensor<4x!qco.qubit>
    %3 = qco.r(%cst_0, %cst) %result_3 : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor_2[%c0] : tensor<4x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %4[%c0] : tensor<4x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %out_tensor_4[%c1] : tensor<4x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_5) targets (%arg12 = %result_7) {
      %73 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %5 = qtensor.insert %targets_out into %out_tensor_6[%c1] : tensor<4x!qco.qubit>
    %6 = qtensor.insert %controls_out into %5[%c0] : tensor<4x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %6[%c1] : tensor<4x!qco.qubit>
    %7 = qco.rz(%arg1) %result_9 : !qco.qubit -> !qco.qubit
    %8 = qtensor.insert %7 into %out_tensor_8[%c1] : tensor<4x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %8[%c1] : tensor<4x!qco.qubit>
    %9 = qco.r(%cst_0, %cst) %result_11 : !qco.qubit -> !qco.qubit
    %10 = qtensor.insert %9 into %out_tensor_10[%c1] : tensor<4x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %10[%c1] : tensor<4x!qco.qubit>
    %out_tensor_14, %result_15 = qtensor.extract %out_tensor_12[%c2] : tensor<4x!qco.qubit>
    %controls_out_16, %targets_out_17 = qco.ctrl(%result_13) targets (%arg12 = %result_15) {
      %73 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qtensor.insert %targets_out_17 into %out_tensor_14[%c2] : tensor<4x!qco.qubit>
    %12 = qtensor.insert %controls_out_16 into %11[%c1] : tensor<4x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %12[%c2] : tensor<4x!qco.qubit>
    %13 = qco.rz(%arg2) %result_19 : !qco.qubit -> !qco.qubit
    %14 = qtensor.insert %13 into %out_tensor_18[%c2] : tensor<4x!qco.qubit>
    %out_tensor_20, %result_21 = qtensor.extract %14[%c2] : tensor<4x!qco.qubit>
    %15 = qco.r(%cst_0, %cst) %result_21 : !qco.qubit -> !qco.qubit
    %16 = qtensor.insert %15 into %out_tensor_20[%c2] : tensor<4x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %16[%c2] : tensor<4x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %out_tensor_22[%c3] : tensor<4x!qco.qubit>
    %controls_out_26, %targets_out_27 = qco.ctrl(%result_23) targets (%arg12 = %result_25) {
      %73 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qtensor.insert %targets_out_27 into %out_tensor_24[%c3] : tensor<4x!qco.qubit>
    %18 = qtensor.insert %controls_out_26 into %17[%c2] : tensor<4x!qco.qubit>
    %out_tensor_28, %result_29 = qtensor.extract %18[%c3] : tensor<4x!qco.qubit>
    %19 = qco.rz(%arg3) %result_29 : !qco.qubit -> !qco.qubit
    %20 = qtensor.insert %19 into %out_tensor_28[%c3] : tensor<4x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %20[%c3] : tensor<4x!qco.qubit>
    %21 = qco.r(%cst_0, %cst) %result_31 : !qco.qubit -> !qco.qubit
    %22 = qtensor.insert %21 into %out_tensor_30[%c3] : tensor<4x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %22[%c3] : tensor<4x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %out_tensor_32[%c0] : tensor<4x!qco.qubit>
    %controls_out_36, %targets_out_37 = qco.ctrl(%result_33) targets (%arg12 = %result_35) {
      %73 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qtensor.insert %targets_out_37 into %out_tensor_34[%c0] : tensor<4x!qco.qubit>
    %24 = qtensor.insert %controls_out_36 into %23[%c3] : tensor<4x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %24[%c0] : tensor<4x!qco.qubit>
    %25 = qco.rz(%arg4) %result_39 : !qco.qubit -> !qco.qubit
    %26 = qtensor.insert %25 into %out_tensor_38[%c0] : tensor<4x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %26[%c0] : tensor<4x!qco.qubit>
    %27 = qco.r(%cst_0, %cst) %result_41 : !qco.qubit -> !qco.qubit
    %28 = qtensor.insert %27 into %out_tensor_40[%c0] : tensor<4x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %28[%c0] : tensor<4x!qco.qubit>
    %out_tensor_44, %result_45 = qtensor.extract %out_tensor_42[%c1] : tensor<4x!qco.qubit>
    %controls_out_46, %targets_out_47 = qco.ctrl(%result_43) targets (%arg12 = %result_45) {
      %73 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qtensor.insert %targets_out_47 into %out_tensor_44[%c1] : tensor<4x!qco.qubit>
    %30 = qtensor.insert %controls_out_46 into %29[%c0] : tensor<4x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %30[%c1] : tensor<4x!qco.qubit>
    %31 = qco.rz(%arg5) %result_49 : !qco.qubit -> !qco.qubit
    %32 = qtensor.insert %31 into %out_tensor_48[%c1] : tensor<4x!qco.qubit>
    %out_tensor_50, %result_51 = qtensor.extract %32[%c1] : tensor<4x!qco.qubit>
    %33 = qco.r(%cst_0, %cst) %result_51 : !qco.qubit -> !qco.qubit
    %34 = qtensor.insert %33 into %out_tensor_50[%c1] : tensor<4x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %34[%c1] : tensor<4x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %out_tensor_52[%c2] : tensor<4x!qco.qubit>
    %controls_out_56, %targets_out_57 = qco.ctrl(%result_53) targets (%arg12 = %result_55) {
      %73 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qtensor.insert %targets_out_57 into %out_tensor_54[%c2] : tensor<4x!qco.qubit>
    %36 = qtensor.insert %controls_out_56 into %35[%c1] : tensor<4x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %36[%c2] : tensor<4x!qco.qubit>
    %37 = qco.rz(%arg6) %result_59 : !qco.qubit -> !qco.qubit
    %38 = qtensor.insert %37 into %out_tensor_58[%c2] : tensor<4x!qco.qubit>
    %out_tensor_60, %result_61 = qtensor.extract %38[%c2] : tensor<4x!qco.qubit>
    %39 = qco.r(%cst_0, %cst) %result_61 : !qco.qubit -> !qco.qubit
    %40 = qtensor.insert %39 into %out_tensor_60[%c2] : tensor<4x!qco.qubit>
    %out_tensor_62, %result_63 = qtensor.extract %40[%c2] : tensor<4x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %out_tensor_62[%c3] : tensor<4x!qco.qubit>
    %controls_out_66, %targets_out_67 = qco.ctrl(%result_63) targets (%arg12 = %result_65) {
      %73 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qtensor.insert %targets_out_67 into %out_tensor_64[%c3] : tensor<4x!qco.qubit>
    %42 = qtensor.insert %controls_out_66 into %41[%c2] : tensor<4x!qco.qubit>
    %out_tensor_68, %result_69 = qtensor.extract %42[%c3] : tensor<4x!qco.qubit>
    %43 = qco.rz(%arg7) %result_69 : !qco.qubit -> !qco.qubit
    %44 = qtensor.insert %43 into %out_tensor_68[%c3] : tensor<4x!qco.qubit>
    %out_tensor_70, %result_71 = qtensor.extract %44[%c3] : tensor<4x!qco.qubit>
    %45 = qco.r(%cst_0, %cst) %result_71 : !qco.qubit -> !qco.qubit
    %46 = qtensor.insert %45 into %out_tensor_70[%c3] : tensor<4x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %46[%c3] : tensor<4x!qco.qubit>
    %out_tensor_74, %result_75 = qtensor.extract %out_tensor_72[%c0] : tensor<4x!qco.qubit>
    %controls_out_76, %targets_out_77 = qco.ctrl(%result_73) targets (%arg12 = %result_75) {
      %73 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qtensor.insert %targets_out_77 into %out_tensor_74[%c0] : tensor<4x!qco.qubit>
    %48 = qtensor.insert %controls_out_76 into %47[%c3] : tensor<4x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %48[%c0] : tensor<4x!qco.qubit>
    %49 = qco.rz(%arg8) %result_79 : !qco.qubit -> !qco.qubit
    %50 = qtensor.insert %49 into %out_tensor_78[%c0] : tensor<4x!qco.qubit>
    %out_tensor_80, %result_81 = qtensor.extract %50[%c0] : tensor<4x!qco.qubit>
    %51 = qco.r(%cst_0, %cst) %result_81 : !qco.qubit -> !qco.qubit
    %52 = qtensor.insert %51 into %out_tensor_80[%c0] : tensor<4x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %52[%c0] : tensor<4x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %out_tensor_82[%c1] : tensor<4x!qco.qubit>
    %controls_out_86, %targets_out_87 = qco.ctrl(%result_83) targets (%arg12 = %result_85) {
      %73 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qtensor.insert %targets_out_87 into %out_tensor_84[%c1] : tensor<4x!qco.qubit>
    %54 = qtensor.insert %controls_out_86 into %53[%c0] : tensor<4x!qco.qubit>
    %out_tensor_88, %result_89 = qtensor.extract %54[%c1] : tensor<4x!qco.qubit>
    %55 = qco.rz(%arg9) %result_89 : !qco.qubit -> !qco.qubit
    %56 = qtensor.insert %55 into %out_tensor_88[%c1] : tensor<4x!qco.qubit>
    %out_tensor_90, %result_91 = qtensor.extract %56[%c1] : tensor<4x!qco.qubit>
    %57 = qco.r(%cst_0, %cst) %result_91 : !qco.qubit -> !qco.qubit
    %58 = qtensor.insert %57 into %out_tensor_90[%c1] : tensor<4x!qco.qubit>
    %out_tensor_92, %result_93 = qtensor.extract %58[%c1] : tensor<4x!qco.qubit>
    %out_tensor_94, %result_95 = qtensor.extract %out_tensor_92[%c2] : tensor<4x!qco.qubit>
    %controls_out_96, %targets_out_97 = qco.ctrl(%result_93) targets (%arg12 = %result_95) {
      %73 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qtensor.insert %targets_out_97 into %out_tensor_94[%c2] : tensor<4x!qco.qubit>
    %60 = qtensor.insert %controls_out_96 into %59[%c1] : tensor<4x!qco.qubit>
    %out_tensor_98, %result_99 = qtensor.extract %60[%c2] : tensor<4x!qco.qubit>
    %61 = qco.rz(%arg10) %result_99 : !qco.qubit -> !qco.qubit
    %62 = qtensor.insert %61 into %out_tensor_98[%c2] : tensor<4x!qco.qubit>
    %out_tensor_100, %result_101 = qtensor.extract %62[%c2] : tensor<4x!qco.qubit>
    %63 = qco.r(%cst_0, %cst) %result_101 : !qco.qubit -> !qco.qubit
    %64 = qtensor.insert %63 into %out_tensor_100[%c2] : tensor<4x!qco.qubit>
    %out_tensor_102, %result_103 = qtensor.extract %64[%c2] : tensor<4x!qco.qubit>
    %out_tensor_104, %result_105 = qtensor.extract %out_tensor_102[%c3] : tensor<4x!qco.qubit>
    %controls_out_106, %targets_out_107 = qco.ctrl(%result_103) targets (%arg12 = %result_105) {
      %73 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qtensor.insert %targets_out_107 into %out_tensor_104[%c3] : tensor<4x!qco.qubit>
    %66 = qtensor.insert %controls_out_106 into %65[%c2] : tensor<4x!qco.qubit>
    %out_tensor_108, %result_109 = qtensor.extract %66[%c3] : tensor<4x!qco.qubit>
    %67 = qco.rz(%arg11) %result_109 : !qco.qubit -> !qco.qubit
    %68 = qtensor.insert %67 into %out_tensor_108[%c3] : tensor<4x!qco.qubit>
    %out_tensor_110, %result_111 = qtensor.extract %68[%c3] : tensor<4x!qco.qubit>
    %69 = qco.r(%cst_0, %cst) %result_111 : !qco.qubit -> !qco.qubit
    %70 = qtensor.insert %69 into %out_tensor_110[%c3] : tensor<4x!qco.qubit>
    %out_tensor_112, %result_113 = qtensor.extract %70[%c3] : tensor<4x!qco.qubit>
    %out_tensor_114, %result_115 = qtensor.extract %out_tensor_112[%c0] : tensor<4x!qco.qubit>
    %controls_out_116, %targets_out_117 = qco.ctrl(%result_113) targets (%arg12 = %result_115) {
      %73 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qtensor.insert %targets_out_117 into %out_tensor_114[%c0] : tensor<4x!qco.qubit>
    %72 = qtensor.insert %controls_out_116 into %71[%c3] : tensor<4x!qco.qubit>
    qtensor.dealloc %72 : tensor<4x!qco.qubit>
    return %c0_i64 : i64
  }
}
