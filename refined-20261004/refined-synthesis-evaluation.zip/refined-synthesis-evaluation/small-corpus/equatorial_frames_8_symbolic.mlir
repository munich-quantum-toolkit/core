module {
  func.func @main(%arg0: f64 {mqt.input_id = 16309916367715198394276235805800677067 : i128, mqt.input_name = "theta[0]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 0 : i64, name = "theta", size = 24 : i64}}, %arg1: f64 {mqt.input_id = 16309916367715198394276235805800677068 : i128, mqt.input_name = "theta[1]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 1 : i64, name = "theta", size = 24 : i64}}, %arg2: f64 {mqt.input_id = 16309916367715198394276235805800677069 : i128, mqt.input_name = "theta[2]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 2 : i64, name = "theta", size = 24 : i64}}, %arg3: f64 {mqt.input_id = 16309916367715198394276235805800677070 : i128, mqt.input_name = "theta[3]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 3 : i64, name = "theta", size = 24 : i64}}, %arg4: f64 {mqt.input_id = 16309916367715198394276235805800677071 : i128, mqt.input_name = "theta[4]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 4 : i64, name = "theta", size = 24 : i64}}, %arg5: f64 {mqt.input_id = 16309916367715198394276235805800677072 : i128, mqt.input_name = "theta[5]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 5 : i64, name = "theta", size = 24 : i64}}, %arg6: f64 {mqt.input_id = 16309916367715198394276235805800677073 : i128, mqt.input_name = "theta[6]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 6 : i64, name = "theta", size = 24 : i64}}, %arg7: f64 {mqt.input_id = 16309916367715198394276235805800677074 : i128, mqt.input_name = "theta[7]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 7 : i64, name = "theta", size = 24 : i64}}, %arg8: f64 {mqt.input_id = 16309916367715198394276235805800677075 : i128, mqt.input_name = "theta[8]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 8 : i64, name = "theta", size = 24 : i64}}, %arg9: f64 {mqt.input_id = 16309916367715198394276235805800677076 : i128, mqt.input_name = "theta[9]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 9 : i64, name = "theta", size = 24 : i64}}, %arg10: f64 {mqt.input_id = 16309916367715198394276235805800677077 : i128, mqt.input_name = "theta[10]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 10 : i64, name = "theta", size = 24 : i64}}, %arg11: f64 {mqt.input_id = 16309916367715198394276235805800677078 : i128, mqt.input_name = "theta[11]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 11 : i64, name = "theta", size = 24 : i64}}, %arg12: f64 {mqt.input_id = 16309916367715198394276235805800677079 : i128, mqt.input_name = "theta[12]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 12 : i64, name = "theta", size = 24 : i64}}, %arg13: f64 {mqt.input_id = 16309916367715198394276235805800677080 : i128, mqt.input_name = "theta[13]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 13 : i64, name = "theta", size = 24 : i64}}, %arg14: f64 {mqt.input_id = 16309916367715198394276235805800677081 : i128, mqt.input_name = "theta[14]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 14 : i64, name = "theta", size = 24 : i64}}, %arg15: f64 {mqt.input_id = 16309916367715198394276235805800677082 : i128, mqt.input_name = "theta[15]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 15 : i64, name = "theta", size = 24 : i64}}, %arg16: f64 {mqt.input_id = 16309916367715198394276235805800677083 : i128, mqt.input_name = "theta[16]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 16 : i64, name = "theta", size = 24 : i64}}, %arg17: f64 {mqt.input_id = 16309916367715198394276235805800677084 : i128, mqt.input_name = "theta[17]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 17 : i64, name = "theta", size = 24 : i64}}, %arg18: f64 {mqt.input_id = 16309916367715198394276235805800677085 : i128, mqt.input_name = "theta[18]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 18 : i64, name = "theta", size = 24 : i64}}, %arg19: f64 {mqt.input_id = 16309916367715198394276235805800677086 : i128, mqt.input_name = "theta[19]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 19 : i64, name = "theta", size = 24 : i64}}, %arg20: f64 {mqt.input_id = 16309916367715198394276235805800677087 : i128, mqt.input_name = "theta[20]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 20 : i64, name = "theta", size = 24 : i64}}, %arg21: f64 {mqt.input_id = 16309916367715198394276235805800677088 : i128, mqt.input_name = "theta[21]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 21 : i64, name = "theta", size = 24 : i64}}, %arg22: f64 {mqt.input_id = 16309916367715198394276235805800677089 : i128, mqt.input_name = "theta[22]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 22 : i64, name = "theta", size = 24 : i64}}, %arg23: f64 {mqt.input_id = 16309916367715198394276235805800677090 : i128, mqt.input_name = "theta[23]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 23 : i64, name = "theta", size = 24 : i64}}) -> i64 attributes {mqt.entry_point} {
    %c0_i64 = arith.constant 0 : i64
    %cst = arith.constant 2.000000e-01 : f64
    %cst_0 = arith.constant 3.000000e-01 : f64
    %cst_1 = arith.constant 0.000000e+00 : f64
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c8 = arith.constant 8 : index
    %0 = qtensor.alloc(%c8) {mqt.register_name = "q"} : tensor<8x!qco.qubit>
    qco.gphase(%cst_1)
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<8x!qco.qubit>
    %1 = qco.rz(%arg0) %result : !qco.qubit -> !qco.qubit
    %2 = qtensor.insert %1 into %out_tensor[%c0] : tensor<8x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %2[%c0] : tensor<8x!qco.qubit>
    %3 = qco.r(%cst_0, %cst) %result_3 : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor_2[%c0] : tensor<8x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %4[%c0] : tensor<8x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %out_tensor_4[%c1] : tensor<8x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_5) targets (%arg24 = %result_7) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %5 = qtensor.insert %targets_out into %out_tensor_6[%c1] : tensor<8x!qco.qubit>
    %6 = qtensor.insert %controls_out into %5[%c0] : tensor<8x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %6[%c1] : tensor<8x!qco.qubit>
    %7 = qco.rz(%arg1) %result_9 : !qco.qubit -> !qco.qubit
    %8 = qtensor.insert %7 into %out_tensor_8[%c1] : tensor<8x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %8[%c1] : tensor<8x!qco.qubit>
    %9 = qco.r(%cst_0, %cst) %result_11 : !qco.qubit -> !qco.qubit
    %10 = qtensor.insert %9 into %out_tensor_10[%c1] : tensor<8x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %10[%c1] : tensor<8x!qco.qubit>
    %out_tensor_14, %result_15 = qtensor.extract %out_tensor_12[%c2] : tensor<8x!qco.qubit>
    %controls_out_16, %targets_out_17 = qco.ctrl(%result_13) targets (%arg24 = %result_15) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qtensor.insert %targets_out_17 into %out_tensor_14[%c2] : tensor<8x!qco.qubit>
    %12 = qtensor.insert %controls_out_16 into %11[%c1] : tensor<8x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %12[%c2] : tensor<8x!qco.qubit>
    %13 = qco.rz(%arg2) %result_19 : !qco.qubit -> !qco.qubit
    %14 = qtensor.insert %13 into %out_tensor_18[%c2] : tensor<8x!qco.qubit>
    %out_tensor_20, %result_21 = qtensor.extract %14[%c2] : tensor<8x!qco.qubit>
    %15 = qco.r(%cst_0, %cst) %result_21 : !qco.qubit -> !qco.qubit
    %16 = qtensor.insert %15 into %out_tensor_20[%c2] : tensor<8x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %16[%c2] : tensor<8x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %out_tensor_22[%c3] : tensor<8x!qco.qubit>
    %controls_out_26, %targets_out_27 = qco.ctrl(%result_23) targets (%arg24 = %result_25) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qtensor.insert %targets_out_27 into %out_tensor_24[%c3] : tensor<8x!qco.qubit>
    %18 = qtensor.insert %controls_out_26 into %17[%c2] : tensor<8x!qco.qubit>
    %out_tensor_28, %result_29 = qtensor.extract %18[%c3] : tensor<8x!qco.qubit>
    %19 = qco.rz(%arg3) %result_29 : !qco.qubit -> !qco.qubit
    %20 = qtensor.insert %19 into %out_tensor_28[%c3] : tensor<8x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %20[%c3] : tensor<8x!qco.qubit>
    %21 = qco.r(%cst_0, %cst) %result_31 : !qco.qubit -> !qco.qubit
    %22 = qtensor.insert %21 into %out_tensor_30[%c3] : tensor<8x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %22[%c3] : tensor<8x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %out_tensor_32[%c4] : tensor<8x!qco.qubit>
    %controls_out_36, %targets_out_37 = qco.ctrl(%result_33) targets (%arg24 = %result_35) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qtensor.insert %targets_out_37 into %out_tensor_34[%c4] : tensor<8x!qco.qubit>
    %24 = qtensor.insert %controls_out_36 into %23[%c3] : tensor<8x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %24[%c4] : tensor<8x!qco.qubit>
    %25 = qco.rz(%arg4) %result_39 : !qco.qubit -> !qco.qubit
    %26 = qtensor.insert %25 into %out_tensor_38[%c4] : tensor<8x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %26[%c4] : tensor<8x!qco.qubit>
    %27 = qco.r(%cst_0, %cst) %result_41 : !qco.qubit -> !qco.qubit
    %28 = qtensor.insert %27 into %out_tensor_40[%c4] : tensor<8x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %28[%c4] : tensor<8x!qco.qubit>
    %out_tensor_44, %result_45 = qtensor.extract %out_tensor_42[%c5] : tensor<8x!qco.qubit>
    %controls_out_46, %targets_out_47 = qco.ctrl(%result_43) targets (%arg24 = %result_45) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qtensor.insert %targets_out_47 into %out_tensor_44[%c5] : tensor<8x!qco.qubit>
    %30 = qtensor.insert %controls_out_46 into %29[%c4] : tensor<8x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %30[%c5] : tensor<8x!qco.qubit>
    %31 = qco.rz(%arg5) %result_49 : !qco.qubit -> !qco.qubit
    %32 = qtensor.insert %31 into %out_tensor_48[%c5] : tensor<8x!qco.qubit>
    %out_tensor_50, %result_51 = qtensor.extract %32[%c5] : tensor<8x!qco.qubit>
    %33 = qco.r(%cst_0, %cst) %result_51 : !qco.qubit -> !qco.qubit
    %34 = qtensor.insert %33 into %out_tensor_50[%c5] : tensor<8x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %34[%c5] : tensor<8x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %out_tensor_52[%c6] : tensor<8x!qco.qubit>
    %controls_out_56, %targets_out_57 = qco.ctrl(%result_53) targets (%arg24 = %result_55) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qtensor.insert %targets_out_57 into %out_tensor_54[%c6] : tensor<8x!qco.qubit>
    %36 = qtensor.insert %controls_out_56 into %35[%c5] : tensor<8x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %36[%c6] : tensor<8x!qco.qubit>
    %37 = qco.rz(%arg6) %result_59 : !qco.qubit -> !qco.qubit
    %38 = qtensor.insert %37 into %out_tensor_58[%c6] : tensor<8x!qco.qubit>
    %out_tensor_60, %result_61 = qtensor.extract %38[%c6] : tensor<8x!qco.qubit>
    %39 = qco.r(%cst_0, %cst) %result_61 : !qco.qubit -> !qco.qubit
    %40 = qtensor.insert %39 into %out_tensor_60[%c6] : tensor<8x!qco.qubit>
    %out_tensor_62, %result_63 = qtensor.extract %40[%c6] : tensor<8x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %out_tensor_62[%c7] : tensor<8x!qco.qubit>
    %controls_out_66, %targets_out_67 = qco.ctrl(%result_63) targets (%arg24 = %result_65) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qtensor.insert %targets_out_67 into %out_tensor_64[%c7] : tensor<8x!qco.qubit>
    %42 = qtensor.insert %controls_out_66 into %41[%c6] : tensor<8x!qco.qubit>
    %out_tensor_68, %result_69 = qtensor.extract %42[%c7] : tensor<8x!qco.qubit>
    %43 = qco.rz(%arg7) %result_69 : !qco.qubit -> !qco.qubit
    %44 = qtensor.insert %43 into %out_tensor_68[%c7] : tensor<8x!qco.qubit>
    %out_tensor_70, %result_71 = qtensor.extract %44[%c7] : tensor<8x!qco.qubit>
    %45 = qco.r(%cst_0, %cst) %result_71 : !qco.qubit -> !qco.qubit
    %46 = qtensor.insert %45 into %out_tensor_70[%c7] : tensor<8x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %46[%c7] : tensor<8x!qco.qubit>
    %out_tensor_74, %result_75 = qtensor.extract %out_tensor_72[%c0] : tensor<8x!qco.qubit>
    %controls_out_76, %targets_out_77 = qco.ctrl(%result_73) targets (%arg24 = %result_75) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qtensor.insert %targets_out_77 into %out_tensor_74[%c0] : tensor<8x!qco.qubit>
    %48 = qtensor.insert %controls_out_76 into %47[%c7] : tensor<8x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %48[%c0] : tensor<8x!qco.qubit>
    %49 = qco.rz(%arg8) %result_79 : !qco.qubit -> !qco.qubit
    %50 = qtensor.insert %49 into %out_tensor_78[%c0] : tensor<8x!qco.qubit>
    %out_tensor_80, %result_81 = qtensor.extract %50[%c0] : tensor<8x!qco.qubit>
    %51 = qco.r(%cst_0, %cst) %result_81 : !qco.qubit -> !qco.qubit
    %52 = qtensor.insert %51 into %out_tensor_80[%c0] : tensor<8x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %52[%c0] : tensor<8x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %out_tensor_82[%c1] : tensor<8x!qco.qubit>
    %controls_out_86, %targets_out_87 = qco.ctrl(%result_83) targets (%arg24 = %result_85) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qtensor.insert %targets_out_87 into %out_tensor_84[%c1] : tensor<8x!qco.qubit>
    %54 = qtensor.insert %controls_out_86 into %53[%c0] : tensor<8x!qco.qubit>
    %out_tensor_88, %result_89 = qtensor.extract %54[%c1] : tensor<8x!qco.qubit>
    %55 = qco.rz(%arg9) %result_89 : !qco.qubit -> !qco.qubit
    %56 = qtensor.insert %55 into %out_tensor_88[%c1] : tensor<8x!qco.qubit>
    %out_tensor_90, %result_91 = qtensor.extract %56[%c1] : tensor<8x!qco.qubit>
    %57 = qco.r(%cst_0, %cst) %result_91 : !qco.qubit -> !qco.qubit
    %58 = qtensor.insert %57 into %out_tensor_90[%c1] : tensor<8x!qco.qubit>
    %out_tensor_92, %result_93 = qtensor.extract %58[%c1] : tensor<8x!qco.qubit>
    %out_tensor_94, %result_95 = qtensor.extract %out_tensor_92[%c2] : tensor<8x!qco.qubit>
    %controls_out_96, %targets_out_97 = qco.ctrl(%result_93) targets (%arg24 = %result_95) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qtensor.insert %targets_out_97 into %out_tensor_94[%c2] : tensor<8x!qco.qubit>
    %60 = qtensor.insert %controls_out_96 into %59[%c1] : tensor<8x!qco.qubit>
    %out_tensor_98, %result_99 = qtensor.extract %60[%c2] : tensor<8x!qco.qubit>
    %61 = qco.rz(%arg10) %result_99 : !qco.qubit -> !qco.qubit
    %62 = qtensor.insert %61 into %out_tensor_98[%c2] : tensor<8x!qco.qubit>
    %out_tensor_100, %result_101 = qtensor.extract %62[%c2] : tensor<8x!qco.qubit>
    %63 = qco.r(%cst_0, %cst) %result_101 : !qco.qubit -> !qco.qubit
    %64 = qtensor.insert %63 into %out_tensor_100[%c2] : tensor<8x!qco.qubit>
    %out_tensor_102, %result_103 = qtensor.extract %64[%c2] : tensor<8x!qco.qubit>
    %out_tensor_104, %result_105 = qtensor.extract %out_tensor_102[%c3] : tensor<8x!qco.qubit>
    %controls_out_106, %targets_out_107 = qco.ctrl(%result_103) targets (%arg24 = %result_105) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qtensor.insert %targets_out_107 into %out_tensor_104[%c3] : tensor<8x!qco.qubit>
    %66 = qtensor.insert %controls_out_106 into %65[%c2] : tensor<8x!qco.qubit>
    %out_tensor_108, %result_109 = qtensor.extract %66[%c3] : tensor<8x!qco.qubit>
    %67 = qco.rz(%arg11) %result_109 : !qco.qubit -> !qco.qubit
    %68 = qtensor.insert %67 into %out_tensor_108[%c3] : tensor<8x!qco.qubit>
    %out_tensor_110, %result_111 = qtensor.extract %68[%c3] : tensor<8x!qco.qubit>
    %69 = qco.r(%cst_0, %cst) %result_111 : !qco.qubit -> !qco.qubit
    %70 = qtensor.insert %69 into %out_tensor_110[%c3] : tensor<8x!qco.qubit>
    %out_tensor_112, %result_113 = qtensor.extract %70[%c3] : tensor<8x!qco.qubit>
    %out_tensor_114, %result_115 = qtensor.extract %out_tensor_112[%c4] : tensor<8x!qco.qubit>
    %controls_out_116, %targets_out_117 = qco.ctrl(%result_113) targets (%arg24 = %result_115) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qtensor.insert %targets_out_117 into %out_tensor_114[%c4] : tensor<8x!qco.qubit>
    %72 = qtensor.insert %controls_out_116 into %71[%c3] : tensor<8x!qco.qubit>
    %out_tensor_118, %result_119 = qtensor.extract %72[%c4] : tensor<8x!qco.qubit>
    %73 = qco.rz(%arg12) %result_119 : !qco.qubit -> !qco.qubit
    %74 = qtensor.insert %73 into %out_tensor_118[%c4] : tensor<8x!qco.qubit>
    %out_tensor_120, %result_121 = qtensor.extract %74[%c4] : tensor<8x!qco.qubit>
    %75 = qco.r(%cst_0, %cst) %result_121 : !qco.qubit -> !qco.qubit
    %76 = qtensor.insert %75 into %out_tensor_120[%c4] : tensor<8x!qco.qubit>
    %out_tensor_122, %result_123 = qtensor.extract %76[%c4] : tensor<8x!qco.qubit>
    %out_tensor_124, %result_125 = qtensor.extract %out_tensor_122[%c5] : tensor<8x!qco.qubit>
    %controls_out_126, %targets_out_127 = qco.ctrl(%result_123) targets (%arg24 = %result_125) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qtensor.insert %targets_out_127 into %out_tensor_124[%c5] : tensor<8x!qco.qubit>
    %78 = qtensor.insert %controls_out_126 into %77[%c4] : tensor<8x!qco.qubit>
    %out_tensor_128, %result_129 = qtensor.extract %78[%c5] : tensor<8x!qco.qubit>
    %79 = qco.rz(%arg13) %result_129 : !qco.qubit -> !qco.qubit
    %80 = qtensor.insert %79 into %out_tensor_128[%c5] : tensor<8x!qco.qubit>
    %out_tensor_130, %result_131 = qtensor.extract %80[%c5] : tensor<8x!qco.qubit>
    %81 = qco.r(%cst_0, %cst) %result_131 : !qco.qubit -> !qco.qubit
    %82 = qtensor.insert %81 into %out_tensor_130[%c5] : tensor<8x!qco.qubit>
    %out_tensor_132, %result_133 = qtensor.extract %82[%c5] : tensor<8x!qco.qubit>
    %out_tensor_134, %result_135 = qtensor.extract %out_tensor_132[%c6] : tensor<8x!qco.qubit>
    %controls_out_136, %targets_out_137 = qco.ctrl(%result_133) targets (%arg24 = %result_135) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qtensor.insert %targets_out_137 into %out_tensor_134[%c6] : tensor<8x!qco.qubit>
    %84 = qtensor.insert %controls_out_136 into %83[%c5] : tensor<8x!qco.qubit>
    %out_tensor_138, %result_139 = qtensor.extract %84[%c6] : tensor<8x!qco.qubit>
    %85 = qco.rz(%arg14) %result_139 : !qco.qubit -> !qco.qubit
    %86 = qtensor.insert %85 into %out_tensor_138[%c6] : tensor<8x!qco.qubit>
    %out_tensor_140, %result_141 = qtensor.extract %86[%c6] : tensor<8x!qco.qubit>
    %87 = qco.r(%cst_0, %cst) %result_141 : !qco.qubit -> !qco.qubit
    %88 = qtensor.insert %87 into %out_tensor_140[%c6] : tensor<8x!qco.qubit>
    %out_tensor_142, %result_143 = qtensor.extract %88[%c6] : tensor<8x!qco.qubit>
    %out_tensor_144, %result_145 = qtensor.extract %out_tensor_142[%c7] : tensor<8x!qco.qubit>
    %controls_out_146, %targets_out_147 = qco.ctrl(%result_143) targets (%arg24 = %result_145) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %89 = qtensor.insert %targets_out_147 into %out_tensor_144[%c7] : tensor<8x!qco.qubit>
    %90 = qtensor.insert %controls_out_146 into %89[%c6] : tensor<8x!qco.qubit>
    %out_tensor_148, %result_149 = qtensor.extract %90[%c7] : tensor<8x!qco.qubit>
    %91 = qco.rz(%arg15) %result_149 : !qco.qubit -> !qco.qubit
    %92 = qtensor.insert %91 into %out_tensor_148[%c7] : tensor<8x!qco.qubit>
    %out_tensor_150, %result_151 = qtensor.extract %92[%c7] : tensor<8x!qco.qubit>
    %93 = qco.r(%cst_0, %cst) %result_151 : !qco.qubit -> !qco.qubit
    %94 = qtensor.insert %93 into %out_tensor_150[%c7] : tensor<8x!qco.qubit>
    %out_tensor_152, %result_153 = qtensor.extract %94[%c7] : tensor<8x!qco.qubit>
    %out_tensor_154, %result_155 = qtensor.extract %out_tensor_152[%c0] : tensor<8x!qco.qubit>
    %controls_out_156, %targets_out_157 = qco.ctrl(%result_153) targets (%arg24 = %result_155) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %95 = qtensor.insert %targets_out_157 into %out_tensor_154[%c0] : tensor<8x!qco.qubit>
    %96 = qtensor.insert %controls_out_156 into %95[%c7] : tensor<8x!qco.qubit>
    %out_tensor_158, %result_159 = qtensor.extract %96[%c0] : tensor<8x!qco.qubit>
    %97 = qco.rz(%arg16) %result_159 : !qco.qubit -> !qco.qubit
    %98 = qtensor.insert %97 into %out_tensor_158[%c0] : tensor<8x!qco.qubit>
    %out_tensor_160, %result_161 = qtensor.extract %98[%c0] : tensor<8x!qco.qubit>
    %99 = qco.r(%cst_0, %cst) %result_161 : !qco.qubit -> !qco.qubit
    %100 = qtensor.insert %99 into %out_tensor_160[%c0] : tensor<8x!qco.qubit>
    %out_tensor_162, %result_163 = qtensor.extract %100[%c0] : tensor<8x!qco.qubit>
    %out_tensor_164, %result_165 = qtensor.extract %out_tensor_162[%c1] : tensor<8x!qco.qubit>
    %controls_out_166, %targets_out_167 = qco.ctrl(%result_163) targets (%arg24 = %result_165) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %101 = qtensor.insert %targets_out_167 into %out_tensor_164[%c1] : tensor<8x!qco.qubit>
    %102 = qtensor.insert %controls_out_166 into %101[%c0] : tensor<8x!qco.qubit>
    %out_tensor_168, %result_169 = qtensor.extract %102[%c1] : tensor<8x!qco.qubit>
    %103 = qco.rz(%arg17) %result_169 : !qco.qubit -> !qco.qubit
    %104 = qtensor.insert %103 into %out_tensor_168[%c1] : tensor<8x!qco.qubit>
    %out_tensor_170, %result_171 = qtensor.extract %104[%c1] : tensor<8x!qco.qubit>
    %105 = qco.r(%cst_0, %cst) %result_171 : !qco.qubit -> !qco.qubit
    %106 = qtensor.insert %105 into %out_tensor_170[%c1] : tensor<8x!qco.qubit>
    %out_tensor_172, %result_173 = qtensor.extract %106[%c1] : tensor<8x!qco.qubit>
    %out_tensor_174, %result_175 = qtensor.extract %out_tensor_172[%c2] : tensor<8x!qco.qubit>
    %controls_out_176, %targets_out_177 = qco.ctrl(%result_173) targets (%arg24 = %result_175) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %107 = qtensor.insert %targets_out_177 into %out_tensor_174[%c2] : tensor<8x!qco.qubit>
    %108 = qtensor.insert %controls_out_176 into %107[%c1] : tensor<8x!qco.qubit>
    %out_tensor_178, %result_179 = qtensor.extract %108[%c2] : tensor<8x!qco.qubit>
    %109 = qco.rz(%arg18) %result_179 : !qco.qubit -> !qco.qubit
    %110 = qtensor.insert %109 into %out_tensor_178[%c2] : tensor<8x!qco.qubit>
    %out_tensor_180, %result_181 = qtensor.extract %110[%c2] : tensor<8x!qco.qubit>
    %111 = qco.r(%cst_0, %cst) %result_181 : !qco.qubit -> !qco.qubit
    %112 = qtensor.insert %111 into %out_tensor_180[%c2] : tensor<8x!qco.qubit>
    %out_tensor_182, %result_183 = qtensor.extract %112[%c2] : tensor<8x!qco.qubit>
    %out_tensor_184, %result_185 = qtensor.extract %out_tensor_182[%c3] : tensor<8x!qco.qubit>
    %controls_out_186, %targets_out_187 = qco.ctrl(%result_183) targets (%arg24 = %result_185) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %113 = qtensor.insert %targets_out_187 into %out_tensor_184[%c3] : tensor<8x!qco.qubit>
    %114 = qtensor.insert %controls_out_186 into %113[%c2] : tensor<8x!qco.qubit>
    %out_tensor_188, %result_189 = qtensor.extract %114[%c3] : tensor<8x!qco.qubit>
    %115 = qco.rz(%arg19) %result_189 : !qco.qubit -> !qco.qubit
    %116 = qtensor.insert %115 into %out_tensor_188[%c3] : tensor<8x!qco.qubit>
    %out_tensor_190, %result_191 = qtensor.extract %116[%c3] : tensor<8x!qco.qubit>
    %117 = qco.r(%cst_0, %cst) %result_191 : !qco.qubit -> !qco.qubit
    %118 = qtensor.insert %117 into %out_tensor_190[%c3] : tensor<8x!qco.qubit>
    %out_tensor_192, %result_193 = qtensor.extract %118[%c3] : tensor<8x!qco.qubit>
    %out_tensor_194, %result_195 = qtensor.extract %out_tensor_192[%c4] : tensor<8x!qco.qubit>
    %controls_out_196, %targets_out_197 = qco.ctrl(%result_193) targets (%arg24 = %result_195) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %119 = qtensor.insert %targets_out_197 into %out_tensor_194[%c4] : tensor<8x!qco.qubit>
    %120 = qtensor.insert %controls_out_196 into %119[%c3] : tensor<8x!qco.qubit>
    %out_tensor_198, %result_199 = qtensor.extract %120[%c4] : tensor<8x!qco.qubit>
    %121 = qco.rz(%arg20) %result_199 : !qco.qubit -> !qco.qubit
    %122 = qtensor.insert %121 into %out_tensor_198[%c4] : tensor<8x!qco.qubit>
    %out_tensor_200, %result_201 = qtensor.extract %122[%c4] : tensor<8x!qco.qubit>
    %123 = qco.r(%cst_0, %cst) %result_201 : !qco.qubit -> !qco.qubit
    %124 = qtensor.insert %123 into %out_tensor_200[%c4] : tensor<8x!qco.qubit>
    %out_tensor_202, %result_203 = qtensor.extract %124[%c4] : tensor<8x!qco.qubit>
    %out_tensor_204, %result_205 = qtensor.extract %out_tensor_202[%c5] : tensor<8x!qco.qubit>
    %controls_out_206, %targets_out_207 = qco.ctrl(%result_203) targets (%arg24 = %result_205) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %125 = qtensor.insert %targets_out_207 into %out_tensor_204[%c5] : tensor<8x!qco.qubit>
    %126 = qtensor.insert %controls_out_206 into %125[%c4] : tensor<8x!qco.qubit>
    %out_tensor_208, %result_209 = qtensor.extract %126[%c5] : tensor<8x!qco.qubit>
    %127 = qco.rz(%arg21) %result_209 : !qco.qubit -> !qco.qubit
    %128 = qtensor.insert %127 into %out_tensor_208[%c5] : tensor<8x!qco.qubit>
    %out_tensor_210, %result_211 = qtensor.extract %128[%c5] : tensor<8x!qco.qubit>
    %129 = qco.r(%cst_0, %cst) %result_211 : !qco.qubit -> !qco.qubit
    %130 = qtensor.insert %129 into %out_tensor_210[%c5] : tensor<8x!qco.qubit>
    %out_tensor_212, %result_213 = qtensor.extract %130[%c5] : tensor<8x!qco.qubit>
    %out_tensor_214, %result_215 = qtensor.extract %out_tensor_212[%c6] : tensor<8x!qco.qubit>
    %controls_out_216, %targets_out_217 = qco.ctrl(%result_213) targets (%arg24 = %result_215) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %131 = qtensor.insert %targets_out_217 into %out_tensor_214[%c6] : tensor<8x!qco.qubit>
    %132 = qtensor.insert %controls_out_216 into %131[%c5] : tensor<8x!qco.qubit>
    %out_tensor_218, %result_219 = qtensor.extract %132[%c6] : tensor<8x!qco.qubit>
    %133 = qco.rz(%arg22) %result_219 : !qco.qubit -> !qco.qubit
    %134 = qtensor.insert %133 into %out_tensor_218[%c6] : tensor<8x!qco.qubit>
    %out_tensor_220, %result_221 = qtensor.extract %134[%c6] : tensor<8x!qco.qubit>
    %135 = qco.r(%cst_0, %cst) %result_221 : !qco.qubit -> !qco.qubit
    %136 = qtensor.insert %135 into %out_tensor_220[%c6] : tensor<8x!qco.qubit>
    %out_tensor_222, %result_223 = qtensor.extract %136[%c6] : tensor<8x!qco.qubit>
    %out_tensor_224, %result_225 = qtensor.extract %out_tensor_222[%c7] : tensor<8x!qco.qubit>
    %controls_out_226, %targets_out_227 = qco.ctrl(%result_223) targets (%arg24 = %result_225) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %137 = qtensor.insert %targets_out_227 into %out_tensor_224[%c7] : tensor<8x!qco.qubit>
    %138 = qtensor.insert %controls_out_226 into %137[%c6] : tensor<8x!qco.qubit>
    %out_tensor_228, %result_229 = qtensor.extract %138[%c7] : tensor<8x!qco.qubit>
    %139 = qco.rz(%arg23) %result_229 : !qco.qubit -> !qco.qubit
    %140 = qtensor.insert %139 into %out_tensor_228[%c7] : tensor<8x!qco.qubit>
    %out_tensor_230, %result_231 = qtensor.extract %140[%c7] : tensor<8x!qco.qubit>
    %141 = qco.r(%cst_0, %cst) %result_231 : !qco.qubit -> !qco.qubit
    %142 = qtensor.insert %141 into %out_tensor_230[%c7] : tensor<8x!qco.qubit>
    %out_tensor_232, %result_233 = qtensor.extract %142[%c7] : tensor<8x!qco.qubit>
    %out_tensor_234, %result_235 = qtensor.extract %out_tensor_232[%c0] : tensor<8x!qco.qubit>
    %controls_out_236, %targets_out_237 = qco.ctrl(%result_233) targets (%arg24 = %result_235) {
      %145 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %143 = qtensor.insert %targets_out_237 into %out_tensor_234[%c0] : tensor<8x!qco.qubit>
    %144 = qtensor.insert %controls_out_236 into %143[%c7] : tensor<8x!qco.qubit>
    qtensor.dealloc %144 : tensor<8x!qco.qubit>
    return %c0_i64 : i64
  }
}
