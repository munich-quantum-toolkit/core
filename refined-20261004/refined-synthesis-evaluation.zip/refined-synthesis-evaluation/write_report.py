"""Write the results summary from the archived rows and separate pass profiles."""
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
DATA = {name: {p.parent.name: json.loads(p.read_text()) for p in directory.glob('*/results.jsonl')}
        for name, directory in {'main': ROOT/'final-results/main', 'previous': ROOT/'previous-results', 'updated': ROOT/'final-results/pr2578'}.items()}
assert all(len(rows) == 398 for rows in DATA.values())
assert all(r['status'] == 'exported' and r['validation']['passed'] for r in DATA['updated'].values())
labels = {'iqm_r_cz': 'IQM R/CZ', 'ibm_sxz_cx': 'IBM CX', 'ibm_sxz_cz': 'IBM CZ', 'ibm_fractional_bounded': 'IBM fractional', 'rxrz_rzz_unbounded': 'RX/RZ/RZZ', 'ionq_fixed_r_zz': 'IonQ fixed R/RZ/RZZ', 'rigetti_rx_cz': 'Rigetti fixed RX/RZ/CZ'}
lines = ['🤖 *AI text below* 🤖', '', '# Native synthesis: approximation, frames, and cleanup', '',
'Updated Core PR #2578 reuses the existing Weyl fidelity policy and Z-frame propagation. The evaluation repeats the frozen large-circuit corpus: 68 inputs, 24–156 qubits, and 398 case/target combinations per compiler.', '',
'## Changes', '',
'- Numeric direct Pauli, fractional, and square-root-iSWAP resynthesis use the existing average gate fidelity floor of `1 - 1e-12` per decomposition. Negligible nonlocal angles may disappear. This is not a whole-circuit error budget; unbound runtime angles remain exact.',
'- Z-frame propagation also serves native RZ targets. It runs after local fusion to preserve physical-gate quality and leaves isolated native RZ parameters unchanged. Existing barrier, control-flow, phase, and scalar-dominance handling is shared.',
'- MLIR module cleanup owns canonicalization and dead-symbol removal after inlining. The inliner no longer repeats callable canonicalization. Dead-value analysis after placement remains necessary.', '',
'## Representative results', '',
'Each cell lists native **1Q / 2Q gates; median synthesis milliseconds**. Main cannot represent the bounded fractional contract. Previous PR times are archived measurements from the earlier experiment, not an interleaved rerun.', '',
'| Circuit / target | Upstream main | Previous PR | Updated PR |', '|---|---:|---:|---:|']
for case, target, title in [
 ('core_qft_54','iqm_r_cz','QFT-54 / IQM'),
 ('core_qft_156','ibm_sxz_cz','QFT-156 / IBM CZ'),
 ('core_qft_156','ibm_fractional_bounded','QFT-156 / IBM fractional'),
 ('efficient_su2_156_symbolic','ibm_sxz_cz','Symbolic SU2-156 / IBM CZ'),
 ('pauli_layers_156_symbolic','ibm_fractional_bounded','Symbolic Pauli-156 / IBM fractional'),
 ('core_grover_54','iqm_r_cz','Grover-54 / IQM')]:
 cells=[]
 for revision in DATA:
  r=DATA[revision][case+'__'+target]
  cells.append(f"{r['native_1q']:,} / {r['native_2q']:,}; {r['synthesis_ms']:.1f} ms" if r['status']=='exported' else r['status'].replace('_',' '))
 lines.append('| '+title+' | '+' | '.join(cells)+' |')
lines += ['', '![Runtime scaling](plots/refined_scaling.png)', '', '![Gate counts](plots/refined_gate_counts.png)', '',
'RZ is separated from other one-qubit gates in the count plot because virtual-Z savings do not directly measure physical gate cost.', '',
'## Aggregate results and regressions', '',
'All 398 updated cases export and satisfy their native gate and angle contracts. Main has 267 validated exports, 68 unsupported-capability cases, and 63 synthesis failures. The previous PR also has 398 valid exports.', '',
'Ratios below are medians of per-case updated/baseline synthesis times; lower is faster. Main ratios include only jointly successful cases.', '',
'| Target | Cases vs main | Time / main | Cases vs previous | Time / previous |', '|---|---:|---:|---:|---:|']
for target in sorted({r['target'] for r in DATA['updated'].values()}):
 ratios=[]
 for baseline in ['main','previous']:
  pairs=[(r,DATA['updated'][key]) for key,r in DATA[baseline].items() if r['target']==target and r['status']=='exported']
  ratios += [str(len(pairs)), f"{statistics.median(b['synthesis_ms']/a['synthesis_ms'] for a,b in pairs):.3f}×" if pairs else '—']
 lines.append('| '+labels.get(target,target)+' | '+' | '.join(ratios)+' |')
lines += ['', 'Gate quality is not monotonic for every circuit. Compared with the previous PR:','']
for metric,label in [('native_1q','total 1Q gates'),('native_1q_non_rz','non-RZ 1Q gates'),('native_2q','2Q gates'),('depth','total depth'),('two_qubit_depth','2Q depth')]:
 changes=[(r[metric]/DATA['previous'][key][metric],key,DATA['previous'][key][metric],r[metric]) for key,r in DATA['updated'].items() if r[metric]>DATA['previous'][key][metric]>0]
 if changes:
  ratio,key,a,b=max(changes)
  lines.append(f'- {len(changes)}/398 cases increase {label}; largest relative increase: {a:,} → {b:,} ({(ratio-1)*100:.1f}%) for `{key}`.')
 else: lines.append(f'- No increase in {label}.')
lines += ['', 'The frame pass itself only commutes or merges native RZ on non-equatorial targets. Small changes to other gates reflect the changed cleanup/fusion order and numerical decompositions. A measured candidate that ran frames before local fusion increased physical RX count by 25% on symbolic fractional Pauli layers; that ordering was rejected. Final regression tests protect physical-gate counts and full matrices.', '',
'## Approximation and frame probes', '',
'The controlled-phase probe now drops the nonlocal part of `CP(pi/2^20)` on IQM, IBM CZ, and unrestricted RZZ targets. `CP(pi/2^19)` retains its entangler. The maximum full complex-matrix error at the first dropped probe is approximately `7.49e-7`, including global phase. Native gates already accepted by a target remain eligible for preservation; this policy applies to resynthesis.', '',
'![Approximation policy](plots/angle_policy.png)', '',
'In a CZ star, the 54- and 156-qubit probes merge 53 and 155 RZ gates respectively into one RZ, retaining every CZ. The three-qubit form is checked against its full matrix.', '',
'## Remaining bottlenecks', '',
'![Pass breakdown](plots/pass_breakdown.png)', '']
profiles=json.loads((ROOT/'plots/pass_profiles.json').read_text())
lines += ['| Profile | Previous inliner | Updated inliner | Previous pass total | Updated pass total |','|---|---:|---:|---:|---:|']
for old in profiles:
 if not old['profile'].endswith('__previous'):continue
 new=next(p for p in profiles if p['profile']==old['profile'].removesuffix('__previous')+'__updated')
 a,b=old['seconds'],new['seconds']
 lines.append(f"| {old['profile'].removeprefix('passes_').removesuffix('__previous')} | {a.get('InlinerPass',0)*1000:.1f} ms | {b.get('InlinerPass',0)*1000:.1f} ms | {a['Total']*1000:.1f} ms | {b['Total']*1000:.1f} ms |")
lines += ['',
'These three-run pass profiles include instrumentation and verification overhead; their totals are separate from the uninstrumented benchmark medians. Canonicalization and dead-value analysis remain visible costs. QFT-156 still spends about a third of its pass time in module canonicalization and a further sixth in dead-value analysis. Grover-54 spends about half in native synthesis. The final circuit size and expression conversion also affect Qiskit export. Broader pass-pipeline and exporter changes remain follow-up work.', '',
'## Validation and measurement limits', '',
'- The complete C++ suite passes 3,922 tests, with one existing job-ID test skipped. All 791 Python MLIR/Qiskit tests pass. Repository lint and whole-file C++ lint pass.',
'- The separate frozen smaller suite passes all 400 semantic/export cases, using full matrices, sampled statevectors, or benchmark output checks according to circuit size. Small-suite timings are excluded from performance claims.',
'- Large-width results verify native gate/angle contracts at three bindings for symbolic circuits. They do not prove full-width semantic equivalence. Full statevectors are not feasible at these widths.',
'- One warmup and five timed samples on CPU 5, one numerical-library thread, DGX Spark ARM64, Release O3/LTO, LLVM/MLIR 23.1, Python 3.14.7, Qiskit 2.5.2. The plots show min–max bands, not confidence intervals.',
'- Main was measured during the same evaluation; final PR measurements were rerun after a pass-order correction. The previous PR data is historical. Contended timing runs were discarded; the final wide rerun detects compiler activity and retries affected cases. Three pairs with over 30% synthesis-sample spread were repeated on both compilers; originals remain in the archive. Small timing differences can reflect machine noise.',
'- All-to-all targets isolate synthesis. Routing, calibration fidelity, device scheduling, and hardware execution are excluded. IQM is tested through 54 qubits, IBM contracts through 156.', '',
'See [reproduction and provenance](README.md), [raw results](plots/raw_results.csv), [aggregate ratios](plots/summary.json), and [pass profiles](plots/pass_profiles.json). The downloadable archive contains frozen inputs, raw samples, worker metadata, validation output, scripts, source patch, and figures.', '']
(ROOT/'report.md').write_text('\n'.join(lines))
