"""Large-width extension of the frozen synthesis experiment; no repository edits."""
from __future__ import annotations
import argparse
from collections import Counter
from fractions import Fraction
import json
import math
import os
from pathlib import Path
import re
import resource
import statistics
import subprocess
import sys
import time
import evaluate as h

ROOT = Path(__file__).resolve().parent
CHECKOUTS = {'main': Path('/home/nvidia/.codex/experiments/core-synthesis-20261003/main'),
             'pr2578': Path('/home/nvidia/.codex/worktrees/pr2578-audit/core')}
WIDTHS = [24,36,54,104,156]

def target_names(n):
    names = [x for x in h.targets() if x != 'rigetti_rx_iswap']
    return names if n <= 54 else [x for x in names if x.startswith('ibm_') or x == 'rxrz_rzz_unbounded']

def generate(args):
    import numpy as np
    from qiskit import QuantumCircuit, qpy
    from qiskit.circuit import ParameterVector
    from qiskit.circuit.library import efficient_su2
    from mqt.core.mlir import QCProgram
    from mqt.core.bench import ghz,qft,w_state,qpe,grover,multiplexer,qft_adder,bv
    corpus=ROOT/'corpus'; corpus.mkdir(exist_ok=True)
    cases=[]
    def save(case,program,circuit=None,instance=None):
        program.unroll_quantum_loops()
        path=corpus/(case['id']+'.mlir');path.write_text(program.ir)
        case.update(input=path.name,input_sha256=h.sha(path),input_bytes=path.stat().st_size,
                    input_quantum_ops=len(re.findall(r'\bqco\.[a-z_]+',program.ir)),targets=target_names(case['qubits']))
        if circuit is not None:
            path=corpus/(case['id']+'.qpy')
            with path.open('wb') as stream:qpy.dump(circuit,stream)
            case.update(reference=path.name,reference_sha256=h.sha(path))
        if instance is not None:
            case.update(instance_specification=json.loads(instance.instance_specification_json),
                        benchmark_class=type(instance).__name__,benchmark_module=type(instance).__module__)
        cases.append(case)
        print(case['id'],case['input_bytes'],flush=True)
    for n in WIDTHS:
        half=n//2
        instances=[('ghz',ghz.GHZ(ghz.Options(qubits=n))),
          ('qft',qft.QFT(qft.Options(qubits=n,period_exponent=n//2))),
          ('w_state',w_state.WState(w_state.Options(qubits=n))),
          ('qpe',qpe.QPE(qpe.Options(precision=n-1,phase=Fraction(3,8)))),
          *([('grover',grover.Grover(grover.Options(marked_bitstring=('10'*n)[:n],iterations=2)))] if n<=62 else []),
          ('multiplexer',multiplexer.Multiplexer(multiplexer.Options(qubits=n))),
          ('qft_adder',qft_adder.QFTAdder(qft_adder.Options(addend=('10'*half)[:half],accumulator=('01'*half)[:half]))),
          ('bv',bv.BV(bv.Options(hidden_bitstring=('10'*n)[:n-1])))]
        for family,instance in instances:
            save(dict(id=f'core_{family}_{n}',family=family,origin='core',qubits=n,mode='numeric',measured=True),instance.generate().to_qco(),instance=instance)
        for symbolic in [False,True]:
            mode='symbolic' if symbolic else 'numeric'
            for family in ['efficient_su2','pauli_layers','equatorial_frames']:
                if family=='efficient_su2': circuit=efficient_su2(n,reps=3,entanglement='circular')
                else:
                    circuit=QuantumCircuit(n);pars=ParameterVector('theta',3*n)
                    for layer in range(3):
                        for q in range(n):
                            a=pars[layer*n+q];r=(q+1)%n
                            if family=='pauli_layers':
                                circuit.ry(a/3,q);circuit.rzz(a,q,r);circuit.rxx(a/2,q,r)
                            else:
                                circuit.rz(a,q);circuit.r(.3,.2,q);circuit.cz(q,r)
                if not symbolic:circuit=circuit.assign_parameters(np.random.default_rng(h.SEED+n).uniform(-3,3,circuit.num_parameters))
                save(dict(id=f'{family}_{n}_{mode}',family=family,origin='synthetic',qubits=n,mode=mode,measured=False),QCProgram.from_qiskit(circuit).to_qco(),circuit=circuit)
    h.dump(corpus/'manifest.json',dict(cases=cases,targets={k:v for k,v in h.targets().items() if k!='rigetti_rx_iswap'},generator=h.metadata(CHECKOUTS['pr2578']),extension_sha256=h.sha(Path(__file__))))

def native_check(case,program,out,corpus,shots,target):
    if out is None:return dict(kind='native_contract_only',passed=False,reason='Export unavailable')
    import numpy as np
    allowed=h.targets()[target]
    errors=[];checked=0
    def matches(op,cap):
        if op.name not in {cap['name'],cap.get('canonical_name',cap['name'])} or op.num_qubits!=cap['arity']:
            return False
        values=[float(v) for v in op.params]
        fixed=cap.get('fixed_parameters',[None]*cap.get('num_parameters',0))
        if op.name==cap['name'] and len(values)==sum(v is None for v in fixed) and len(values)!=len(fixed):
            free=iter(values);values=[next(free) if v is None else v for v in fixed]
        if len(values)!=cap.get('num_parameters',0):return False
        if not all(math.isfinite(v) for v in values):return False
        if any(v is not None and abs(a-v)>1e-9 for a,v in zip(values,fixed)):return False
        bounds=cap.get('parameter_bounds',[])
        return all(b is None or b[0]-1e-9<=a<=b[1]+1e-9 for a,b in zip(values,bounds))
    for sample in range(3 if out.num_parameters else 1):
        bindings=dict(zip(out.parameters,np.random.default_rng(h.SEED+sample).uniform(-8,8,out.num_parameters),strict=True))
        bound=out.assign_parameters(bindings)
        for inst in bound.data:
            op=inst.operation
            if op.name=='barrier':continue
            if not any(matches(op,cap) for cap in allowed):errors.append(f'Unsupported {op.name}: {op.params}')
            checked+=1
    return dict(kind='native_contract_only',passed=not errors,errors=errors[:10],checked_instructions=checked,bindings=3 if out.num_parameters else 1,semantic_equivalence='not checked at large width')

def worker(args):
    resource.setrlimit(resource.RLIMIT_AS,(12*1024**3,12*1024**3))
    case=next(c for c in json.loads((ROOT/'corpus/manifest.json').read_text())['cases'] if c['id']==args.case)
    h.validate=lambda c,p,o,corpus,shots:native_check(c,p,o,corpus,shots,args.target)
    original_record=h.record
    def record(output,row):
        row.update(input_quantum_ops=case['input_quantum_ops'],input_bytes=case['input_bytes'],
                   peak_rss_mib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024)
        original_record(output,row)
    h.record=record
    h.run(argparse.Namespace(checkout=CHECKOUTS[args.revision],corpus=ROOT/'corpus',output=args.output,
        case='^'+re.escape(args.case)+'$',target='^'+re.escape(args.target)+'$',repetitions=args.repetitions,shots=0,save_ir=False))

def sweep(args):
    manifest=json.loads((ROOT/'corpus/manifest.json').read_text());out=args.output;out.mkdir(parents=True,exist_ok=True)
    jobs=[(c,t) for c in manifest['cases'] if re.search(args.case,c['id']) for t in c['targets'] if re.search(args.target,t)]
    h.dump(out/'sweep.json',dict(manifest_sha256=h.sha(ROOT/'corpus/manifest.json'),extension_sha256=h.sha(Path(__file__)),timeout_seconds=args.timeout,repetitions=args.repetitions,jobs=len(jobs)*2,validation='native contracts only; no full-width semantic oracle'))
    for i,(case,target) in enumerate(jobs):
        for revision in (['main','pr2578'] if i%2==0 else ['pr2578','main']):
            directory=out/revision/(case['id']+'__'+target)
            if (directory/'done.json').exists():continue
            directory.mkdir(parents=True,exist_ok=True)
            command=['taskset','-c','5',str(CHECKOUTS[revision]/'.venv/bin/python'),str(Path(__file__).resolve()),'worker','--revision',revision,'--case',case['id'],'--target',target,'--output',str(directory),'--repetitions',str(args.repetitions)]
            env=os.environ|dict(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',QISKIT_NUM_PROCS='1')
            start=time.monotonic();status='complete'
            with (directory/'stdout.log').open('w') as stdout,(directory/'stderr.log').open('w') as stderr:
                try:
                    process=subprocess.run(command,env=env,stdout=stdout,stderr=stderr,timeout=args.timeout)
                    if process.returncode:status=f'process_exit_{process.returncode}'
                except subprocess.TimeoutExpired:status='timeout'
            if not (directory/'results.jsonl').exists():
                row={k:case[k] for k in ['family','origin','qubits','mode','input_quantum_ops','input_bytes']}
                row.update(case=case['id'],target=target,status=status,timeout_seconds=args.timeout)
                (directory/'results.jsonl').write_text(json.dumps(row)+'\n')
            h.dump(directory/'done.json',dict(status=status,wall_seconds=time.monotonic()-start,command=command))
            row=json.loads((directory/'results.jsonl').read_text().splitlines()[-1]);print(revision,row['case'],target,row['status'],round(row.get('synthesis_ms',0),2),flush=True)

def profile(args):
    from mqt.core.mlir import CompilerTarget as T,QCOProgram,TargetEnvironment,PayloadSpecification,PayloadFormat,CompilationOptions
    case=next(c for c in json.loads((ROOT/'corpus/manifest.json').read_text())['cases'] if c['id']==args.case)
    target=T(args.device_width or case['qubits'],connectivity=T.Connectivity.all_to_all(),native_operations=T.NativeOperations([T.OperationCapability(**op) for op in h.targets()[args.target]]))
    env=TargetEnvironment(target,PayloadSpecification(PayloadFormat('openqasm','3.0')))
    source=QCOProgram.from_mlir_file(ROOT/'corpus'/case['input'])
    samples=[]
    for trial in range(args.repetitions):
        program=source.copy();start=time.perf_counter_ns()
        program.synthesize_for_target(env,options=CompilationOptions(seed=h.SEED,enable_timing=args.timing,enable_statistics=args.timing))
        samples.append((time.perf_counter_ns()-start)/1e6)
    print(json.dumps(dict(case=args.case,target=args.target,device_width=args.device_width or case['qubits'],samples_ms=samples,median_ms=statistics.median(samples))))
    if args.export_profile:
        import cProfile,pstats
        p=cProfile.Profile();p.enable();circuit=program.to_qiskit(target=target);p.disable()
        p.dump_stats(args.export_profile);pstats.Stats(p).sort_stats('cumulative').print_stats(25)

if __name__=='__main__':
    parser=argparse.ArgumentParser();subs=parser.add_subparsers(dest='command',required=True)
    subs.add_parser('generate')
    for name in ['worker','sweep','profile']:
        p=subs.add_parser(name);p.add_argument('--case',default='.');p.add_argument('--target',default='.')
        p.add_argument('--repetitions',type=int,default=5)
        if name in ['worker','sweep']:p.add_argument('--output',type=Path,required=True)
        if name=='worker':p.add_argument('--revision',choices=CHECKOUTS,required=True)
        if name=='sweep':p.add_argument('--timeout',type=int,default=180)
        if name=='profile':
            p.add_argument('--timing',action='store_true');p.add_argument('--device-width',type=int);p.add_argument('--export-profile')
    args=parser.parse_args();globals()[args.command](args)
