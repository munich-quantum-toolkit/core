"""Repeat both compilers for every pair with over 30% synthesis sample spread."""
import json
from pathlib import Path
import re
import shutil
import subprocess
import time
ROOT=Path(__file__).resolve().parent
jobs=json.loads((ROOT/'variance-rerun-selection.json').read_text())
def busy():
 return subprocess.run(['ps','-C','ld,ld.lld,clang,clang++,clang-tidy,cc1plus','-o','pid=,comm='],capture_output=True,text=True).stdout.strip()
for job in jobs:
 key=job['case']+'__'+job['target']
 for revision in ['main','pr2578']:
  source=ROOT/'final-results'/revision/key
  dest=ROOT/'variance-originals'/revision/key;dest.parent.mkdir(parents=True,exist_ok=True);shutil.move(source,dest)
 while True:
  while busy():time.sleep(5)
  command=['python3',str(ROOT/'large.py'),'sweep','--output',str(ROOT/'final-results'),'--case','^'+re.escape(job['case'])+'$','--target','^'+re.escape(job['target'])+'$','--repetitions','5']
  child=subprocess.Popen(command);activity=[]
  while child.poll() is None:
   if load:=busy():activity.append({'time':time.time(),'processes':load})
   time.sleep(.5)
  if child.returncode:raise RuntimeError('Sweep failed')
  if not activity:break
  for revision in ['main','pr2578']:
   source=ROOT/'final-results'/revision/key
   dest=ROOT/'variance-originals'/revision/(key+'__contended_'+str(time.time_ns()));shutil.move(source,dest)
   (dest/'compiler-activity.json').write_text(json.dumps(activity,indent=2)+'\n')
 print('Completed pair',key,flush=True)
