"""Compare frozen inputs across main, the previous PR, and the refinement."""
import csv
import json
from pathlib import Path
import statistics
from collections import Counter

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'core-synthesis-large-20261004'
OUT = ROOT / 'plots'
OUT.mkdir(exist_ok=True)
DIRECTORIES = {'main': ROOT/'final-results/main', 'previous': ROOT/'previous-results',
               'updated': ROOT/'final-results/pr2578'}
DATA = {name: {(r['case'], r['target']): r for p in path.glob('*/results.jsonl')
               for r in [json.loads(p.read_text())]} for name, path in DIRECTORIES.items()}
LABELS = {'main': 'Upstream main', 'previous': 'Previous PR', 'updated': 'Updated PR'}
COLORS = {'main': '#5279a6', 'previous': '#8c8c8c', 'updated': '#14836d'}
def good(row):
    return row.get('status') == 'exported' and row.get('validation', {}).get('passed')
def save(fig, name):
    for extension in ('png', 'pdf', 'svg'):
        fig.savefig(OUT/f'{name}.{extension}', dpi=180)
    plt.close(fig)

fields = sorted(set().union(*(r for data in DATA.values() for r in data.values())))
with (OUT/'raw_results.csv').open('w', newline='') as file:
    writer = csv.DictWriter(file, fieldnames=['revision'] + fields, lineterminator='\n')
    writer.writeheader()
    for revision, data in DATA.items():
        for key in sorted(data):
            row = data[key]
            writer.writerow({'revision': revision, **{k: json.dumps(v) if isinstance(v, (dict, list)) else v for k, v in row.items()}})

targets = [('iqm_r_cz', 'IQM R/CZ', 54), ('ibm_sxz_cz', 'IBM SX/X/RZ + CZ', 156),
           ('ibm_fractional_bounded', 'IBM fractional', 156)]
fig, axes = plt.subplots(2, 3, figsize=(14, 8), layout='constrained')
for column, (target, title, width) in enumerate(targets):
    for row, (family, mode, caption) in enumerate([('qft', 'numeric', 'QFT'), ('efficient_su2', 'symbolic', 'Symbolic EfficientSU2')]):
        ax = axes[row, column]
        for revision, data in DATA.items():
            selected = sorted((r for r in data.values() if r['target'] == target and r['family'] == family and r['mode'] == mode and good(r)), key=lambda r: r['qubits'])
            if not selected:
                continue
            x = [r['qubits'] for r in selected]
            ax.plot(x, [r['synthesis_ms'] for r in selected], 'o-', color=COLORS[revision], label=LABELS[revision])
            ax.fill_between(x, [min(r['synthesis_samples_ms']) for r in selected], [max(r['synthesis_samples_ms']) for r in selected], color=COLORS[revision], alpha=.12)
        ax.set(title=title+' · '+caption, xlabel='Circuit qubits', ylabel='Synthesis (ms)')
        ax.set_ylim(bottom=0)
        ax.grid(alpha=.2)
axes[0, 0].legend()
fig.suptitle('Synthesis after consistent approximation, Z-frame merging, and cleanup reduction\nFive samples, one pinned CPU; bands show min–max; all-to-all targets, no routing')
save(fig, 'refined_scaling')

families = [('qft', 'numeric', 'QFT'), ('w_state', 'numeric', 'W state'),
            ('efficient_su2', 'symbolic', 'SU2 sym.'), ('pauli_layers', 'numeric', 'Pauli num.'),
            ('pauli_layers', 'symbolic', 'Pauli sym.')]
fig, axes = plt.subplots(2, 3, figsize=(15, 8), layout='constrained')
for column, (target, title, width) in enumerate(targets):
    for row, metric in enumerate(('native_1q', 'native_2q')):
        ax = axes[row, column]
        for index, (revision, data) in enumerate(DATA.items()):
            for i, (family, mode, _) in enumerate(families):
                entry = next((r for r in data.values() if r['target'] == target and r['qubits'] == width and r['family'] == family and r['mode'] == mode and good(r)), None)
                x = i + (index-1)*.26
                if entry:
                    height = entry['native_1q_non_rz'] if row == 0 else entry[metric]
                    ax.bar(x, height, width=.25, color=COLORS[revision], label=LABELS[revision] if i == 0 else None)
                    if row == 0 and entry['native_rz']:
                        ax.bar(x, entry['native_rz'], bottom=height, width=.25, color=COLORS[revision], alpha=.3, hatch='///')
                    ax.annotate(f'{entry[metric]:,}', (x, entry[metric]), xytext=(0,3), textcoords='offset points', rotation=90, ha='center', va='bottom', fontsize=6)
                else:
                    ax.text(x, .01, '×', transform=ax.get_xaxis_transform(), ha='center', color=COLORS[revision])
        ax.set_xticks(range(len(families)), [f[2] for f in families], rotation=20, ha='right')
        ax.set(title=f'{title} · {width} qubits', ylabel='Native '+('1Q' if row == 0 else '2Q')+' gates')
        ax.margins(y=.4)
        ax.grid(axis='y', alpha=.2)
axes[0, 0].legend()
fig.suptitle('Native gate counts at the largest tested widths\nSolid 1Q bars exclude RZ; hatched portions are RZ; × = unsupported')
save(fig, 'refined_gate_counts')

summary = []
for base in ('main', 'previous'):
    for target in sorted({r['target'] for r in DATA['updated'].values()}):
        pairs = [(r, DATA['updated'][key]) for key, r in DATA[base].items() if r['target'] == target and key in DATA['updated'] and good(r) and good(DATA['updated'][key])]
        for metric in ('synthesis_ms', 'export_ms', 'native_1q', 'native_1q_non_rz', 'native_2q', 'depth', 'scalar_ops', 'peak_rss_mib'):
            ratios = [b[metric]/a[metric] for a,b in pairs if isinstance(a.get(metric), (int,float)) and a[metric] > 0]
            if ratios:
                summary.append(dict(baseline=base, target=target, metric=metric, pairs=len(ratios), median_ratio=statistics.median(ratios), min_ratio=min(ratios), max_ratio=max(ratios), increases=sum(r>1.0000001 for r in ratios)))
(OUT/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
status = {revision: dict(Counter(r['status'] for r in data.values())) for revision, data in DATA.items()}
(OUT/'status.json').write_text(json.dumps(status, indent=2)+'\n')
print(json.dumps(status))
for row in summary:
    if row['metric'] == 'synthesis_ms':
        print(row)
