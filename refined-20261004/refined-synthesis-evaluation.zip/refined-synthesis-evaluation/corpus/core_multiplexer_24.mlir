module {
  func.func @main() -> !cbit.reg<24> attributes {mqt.entry_point} {
    %cst = arith.constant 3.7450702829239286E-7 : f64
    %cst_0 = arith.constant 7.4901405658478573E-7 : f64
    %cst_1 = arith.constant 1.4980281131695715E-6 : f64
    %cst_2 = arith.constant 2.9960562263391429E-6 : f64
    %cst_3 = arith.constant 5.9921124526782858E-6 : f64
    %cst_4 = arith.constant 1.1984224905356572E-5 : f64
    %cst_5 = arith.constant 2.3968449810713143E-5 : f64
    %cst_6 = arith.constant 4.7936899621426287E-5 : f64
    %cst_7 = arith.constant 9.5873799242852573E-5 : f64
    %cst_8 = arith.constant 1.9174759848570515E-4 : f64
    %cst_9 = arith.constant 3.8349519697141029E-4 : f64
    %cst_10 = arith.constant 7.6699039394282058E-4 : f64
    %cst_11 = arith.constant 0.0015339807878856412 : f64
    %cst_12 = arith.constant 0.0030679615757712823 : f64
    %cst_13 = arith.constant 0.0061359231515425647 : f64
    %cst_14 = arith.constant 0.012271846303085129 : f64
    %cst_15 = arith.constant 0.024543692606170259 : f64
    %cst_16 = arith.constant 0.049087385212340517 : f64
    %cst_17 = arith.constant 0.098174770424681035 : f64
    %cst_18 = arith.constant 0.19634954084936207 : f64
    %cst_19 = arith.constant 0.39269908169872414 : f64
    %cst_20 = arith.constant 0.78539816339744828 : f64
    %c21 = arith.constant 21 : index
    %c20 = arith.constant 20 : index
    %c19 = arith.constant 19 : index
    %c18 = arith.constant 18 : index
    %c17 = arith.constant 17 : index
    %c16 = arith.constant 16 : index
    %c15 = arith.constant 15 : index
    %c14 = arith.constant 14 : index
    %c13 = arith.constant 13 : index
    %c12 = arith.constant 12 : index
    %c11 = arith.constant 11 : index
    %c10 = arith.constant 10 : index
    %c9 = arith.constant 9 : index
    %c8 = arith.constant 8 : index
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %cst_21 = arith.constant 1.5707963267948966 : f64
    %c22 = arith.constant 22 : index
    %c23 = arith.constant 23 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %0 = qtensor.alloc(%c23) {mqt.register_name = "controls"} : tensor<23x!qco.qubit>
    %1 = qco.alloc : !qco.qubit
    %2 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<24>
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<23x!qco.qubit>
    %3 = qco.h %result : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor[%c0] : tensor<23x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %4[%c1] : tensor<23x!qco.qubit>
    %5 = qco.h %result_23 : !qco.qubit -> !qco.qubit
    %6 = qtensor.insert %5 into %out_tensor_22[%c1] : tensor<23x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %6[%c2] : tensor<23x!qco.qubit>
    %7 = qco.h %result_25 : !qco.qubit -> !qco.qubit
    %8 = qtensor.insert %7 into %out_tensor_24[%c2] : tensor<23x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %8[%c3] : tensor<23x!qco.qubit>
    %9 = qco.h %result_27 : !qco.qubit -> !qco.qubit
    %10 = qtensor.insert %9 into %out_tensor_26[%c3] : tensor<23x!qco.qubit>
    %out_tensor_28, %result_29 = qtensor.extract %10[%c4] : tensor<23x!qco.qubit>
    %11 = qco.h %result_29 : !qco.qubit -> !qco.qubit
    %12 = qtensor.insert %11 into %out_tensor_28[%c4] : tensor<23x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %12[%c5] : tensor<23x!qco.qubit>
    %13 = qco.h %result_31 : !qco.qubit -> !qco.qubit
    %14 = qtensor.insert %13 into %out_tensor_30[%c5] : tensor<23x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %14[%c6] : tensor<23x!qco.qubit>
    %15 = qco.h %result_33 : !qco.qubit -> !qco.qubit
    %16 = qtensor.insert %15 into %out_tensor_32[%c6] : tensor<23x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %16[%c7] : tensor<23x!qco.qubit>
    %17 = qco.h %result_35 : !qco.qubit -> !qco.qubit
    %18 = qtensor.insert %17 into %out_tensor_34[%c7] : tensor<23x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %18[%c8] : tensor<23x!qco.qubit>
    %19 = qco.h %result_37 : !qco.qubit -> !qco.qubit
    %20 = qtensor.insert %19 into %out_tensor_36[%c8] : tensor<23x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %20[%c9] : tensor<23x!qco.qubit>
    %21 = qco.h %result_39 : !qco.qubit -> !qco.qubit
    %22 = qtensor.insert %21 into %out_tensor_38[%c9] : tensor<23x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %22[%c10] : tensor<23x!qco.qubit>
    %23 = qco.h %result_41 : !qco.qubit -> !qco.qubit
    %24 = qtensor.insert %23 into %out_tensor_40[%c10] : tensor<23x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %24[%c11] : tensor<23x!qco.qubit>
    %25 = qco.h %result_43 : !qco.qubit -> !qco.qubit
    %26 = qtensor.insert %25 into %out_tensor_42[%c11] : tensor<23x!qco.qubit>
    %out_tensor_44, %result_45 = qtensor.extract %26[%c12] : tensor<23x!qco.qubit>
    %27 = qco.h %result_45 : !qco.qubit -> !qco.qubit
    %28 = qtensor.insert %27 into %out_tensor_44[%c12] : tensor<23x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %28[%c13] : tensor<23x!qco.qubit>
    %29 = qco.h %result_47 : !qco.qubit -> !qco.qubit
    %30 = qtensor.insert %29 into %out_tensor_46[%c13] : tensor<23x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %30[%c14] : tensor<23x!qco.qubit>
    %31 = qco.h %result_49 : !qco.qubit -> !qco.qubit
    %32 = qtensor.insert %31 into %out_tensor_48[%c14] : tensor<23x!qco.qubit>
    %out_tensor_50, %result_51 = qtensor.extract %32[%c15] : tensor<23x!qco.qubit>
    %33 = qco.h %result_51 : !qco.qubit -> !qco.qubit
    %34 = qtensor.insert %33 into %out_tensor_50[%c15] : tensor<23x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %34[%c16] : tensor<23x!qco.qubit>
    %35 = qco.h %result_53 : !qco.qubit -> !qco.qubit
    %36 = qtensor.insert %35 into %out_tensor_52[%c16] : tensor<23x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %36[%c17] : tensor<23x!qco.qubit>
    %37 = qco.h %result_55 : !qco.qubit -> !qco.qubit
    %38 = qtensor.insert %37 into %out_tensor_54[%c17] : tensor<23x!qco.qubit>
    %out_tensor_56, %result_57 = qtensor.extract %38[%c18] : tensor<23x!qco.qubit>
    %39 = qco.h %result_57 : !qco.qubit -> !qco.qubit
    %40 = qtensor.insert %39 into %out_tensor_56[%c18] : tensor<23x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %40[%c19] : tensor<23x!qco.qubit>
    %41 = qco.h %result_59 : !qco.qubit -> !qco.qubit
    %42 = qtensor.insert %41 into %out_tensor_58[%c19] : tensor<23x!qco.qubit>
    %out_tensor_60, %result_61 = qtensor.extract %42[%c20] : tensor<23x!qco.qubit>
    %43 = qco.h %result_61 : !qco.qubit -> !qco.qubit
    %44 = qtensor.insert %43 into %out_tensor_60[%c20] : tensor<23x!qco.qubit>
    %out_tensor_62, %result_63 = qtensor.extract %44[%c21] : tensor<23x!qco.qubit>
    %45 = qco.h %result_63 : !qco.qubit -> !qco.qubit
    %46 = qtensor.insert %45 into %out_tensor_62[%c21] : tensor<23x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %46[%c22] : tensor<23x!qco.qubit>
    %47 = qco.h %result_65 : !qco.qubit -> !qco.qubit
    %48 = qtensor.insert %47 into %out_tensor_64[%c22] : tensor<23x!qco.qubit>
    %out_tensor_66, %result_67 = qtensor.extract %48[%c22] : tensor<23x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_67) targets (%arg0 = %1) {
      %95 = qco.ry(%cst_21) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qtensor.insert %controls_out into %out_tensor_66[%c22] : tensor<23x!qco.qubit>
    %out_tensor_68, %result_69 = qtensor.extract %49[%c21] : tensor<23x!qco.qubit>
    %controls_out_70, %targets_out_71 = qco.ctrl(%result_69) targets (%arg0 = %targets_out) {
      %95 = qco.ry(%cst_20) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qtensor.insert %controls_out_70 into %out_tensor_68[%c21] : tensor<23x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %50[%c20] : tensor<23x!qco.qubit>
    %controls_out_74, %targets_out_75 = qco.ctrl(%result_73) targets (%arg0 = %targets_out_71) {
      %95 = qco.ry(%cst_19) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %51 = qtensor.insert %controls_out_74 into %out_tensor_72[%c20] : tensor<23x!qco.qubit>
    %out_tensor_76, %result_77 = qtensor.extract %51[%c19] : tensor<23x!qco.qubit>
    %controls_out_78, %targets_out_79 = qco.ctrl(%result_77) targets (%arg0 = %targets_out_75) {
      %95 = qco.ry(%cst_18) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qtensor.insert %controls_out_78 into %out_tensor_76[%c19] : tensor<23x!qco.qubit>
    %out_tensor_80, %result_81 = qtensor.extract %52[%c18] : tensor<23x!qco.qubit>
    %controls_out_82, %targets_out_83 = qco.ctrl(%result_81) targets (%arg0 = %targets_out_79) {
      %95 = qco.ry(%cst_17) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qtensor.insert %controls_out_82 into %out_tensor_80[%c18] : tensor<23x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %53[%c17] : tensor<23x!qco.qubit>
    %controls_out_86, %targets_out_87 = qco.ctrl(%result_85) targets (%arg0 = %targets_out_83) {
      %95 = qco.ry(%cst_16) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %54 = qtensor.insert %controls_out_86 into %out_tensor_84[%c17] : tensor<23x!qco.qubit>
    %out_tensor_88, %result_89 = qtensor.extract %54[%c16] : tensor<23x!qco.qubit>
    %controls_out_90, %targets_out_91 = qco.ctrl(%result_89) targets (%arg0 = %targets_out_87) {
      %95 = qco.ry(%cst_15) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qtensor.insert %controls_out_90 into %out_tensor_88[%c16] : tensor<23x!qco.qubit>
    %out_tensor_92, %result_93 = qtensor.extract %55[%c15] : tensor<23x!qco.qubit>
    %controls_out_94, %targets_out_95 = qco.ctrl(%result_93) targets (%arg0 = %targets_out_91) {
      %95 = qco.ry(%cst_14) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qtensor.insert %controls_out_94 into %out_tensor_92[%c15] : tensor<23x!qco.qubit>
    %out_tensor_96, %result_97 = qtensor.extract %56[%c14] : tensor<23x!qco.qubit>
    %controls_out_98, %targets_out_99 = qco.ctrl(%result_97) targets (%arg0 = %targets_out_95) {
      %95 = qco.ry(%cst_13) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %57 = qtensor.insert %controls_out_98 into %out_tensor_96[%c14] : tensor<23x!qco.qubit>
    %out_tensor_100, %result_101 = qtensor.extract %57[%c13] : tensor<23x!qco.qubit>
    %controls_out_102, %targets_out_103 = qco.ctrl(%result_101) targets (%arg0 = %targets_out_99) {
      %95 = qco.ry(%cst_12) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = qtensor.insert %controls_out_102 into %out_tensor_100[%c13] : tensor<23x!qco.qubit>
    %out_tensor_104, %result_105 = qtensor.extract %58[%c12] : tensor<23x!qco.qubit>
    %controls_out_106, %targets_out_107 = qco.ctrl(%result_105) targets (%arg0 = %targets_out_103) {
      %95 = qco.ry(%cst_11) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qtensor.insert %controls_out_106 into %out_tensor_104[%c12] : tensor<23x!qco.qubit>
    %out_tensor_108, %result_109 = qtensor.extract %59[%c11] : tensor<23x!qco.qubit>
    %controls_out_110, %targets_out_111 = qco.ctrl(%result_109) targets (%arg0 = %targets_out_107) {
      %95 = qco.ry(%cst_10) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qtensor.insert %controls_out_110 into %out_tensor_108[%c11] : tensor<23x!qco.qubit>
    %out_tensor_112, %result_113 = qtensor.extract %60[%c10] : tensor<23x!qco.qubit>
    %controls_out_114, %targets_out_115 = qco.ctrl(%result_113) targets (%arg0 = %targets_out_111) {
      %95 = qco.ry(%cst_9) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qtensor.insert %controls_out_114 into %out_tensor_112[%c10] : tensor<23x!qco.qubit>
    %out_tensor_116, %result_117 = qtensor.extract %61[%c9] : tensor<23x!qco.qubit>
    %controls_out_118, %targets_out_119 = qco.ctrl(%result_117) targets (%arg0 = %targets_out_115) {
      %95 = qco.ry(%cst_8) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %62 = qtensor.insert %controls_out_118 into %out_tensor_116[%c9] : tensor<23x!qco.qubit>
    %out_tensor_120, %result_121 = qtensor.extract %62[%c8] : tensor<23x!qco.qubit>
    %controls_out_122, %targets_out_123 = qco.ctrl(%result_121) targets (%arg0 = %targets_out_119) {
      %95 = qco.ry(%cst_7) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %63 = qtensor.insert %controls_out_122 into %out_tensor_120[%c8] : tensor<23x!qco.qubit>
    %out_tensor_124, %result_125 = qtensor.extract %63[%c7] : tensor<23x!qco.qubit>
    %controls_out_126, %targets_out_127 = qco.ctrl(%result_125) targets (%arg0 = %targets_out_123) {
      %95 = qco.ry(%cst_6) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %64 = qtensor.insert %controls_out_126 into %out_tensor_124[%c7] : tensor<23x!qco.qubit>
    %out_tensor_128, %result_129 = qtensor.extract %64[%c6] : tensor<23x!qco.qubit>
    %controls_out_130, %targets_out_131 = qco.ctrl(%result_129) targets (%arg0 = %targets_out_127) {
      %95 = qco.ry(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qtensor.insert %controls_out_130 into %out_tensor_128[%c6] : tensor<23x!qco.qubit>
    %out_tensor_132, %result_133 = qtensor.extract %65[%c5] : tensor<23x!qco.qubit>
    %controls_out_134, %targets_out_135 = qco.ctrl(%result_133) targets (%arg0 = %targets_out_131) {
      %95 = qco.ry(%cst_4) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = qtensor.insert %controls_out_134 into %out_tensor_132[%c5] : tensor<23x!qco.qubit>
    %out_tensor_136, %result_137 = qtensor.extract %66[%c4] : tensor<23x!qco.qubit>
    %controls_out_138, %targets_out_139 = qco.ctrl(%result_137) targets (%arg0 = %targets_out_135) {
      %95 = qco.ry(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %67 = qtensor.insert %controls_out_138 into %out_tensor_136[%c4] : tensor<23x!qco.qubit>
    %out_tensor_140, %result_141 = qtensor.extract %67[%c3] : tensor<23x!qco.qubit>
    %controls_out_142, %targets_out_143 = qco.ctrl(%result_141) targets (%arg0 = %targets_out_139) {
      %95 = qco.ry(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %68 = qtensor.insert %controls_out_142 into %out_tensor_140[%c3] : tensor<23x!qco.qubit>
    %out_tensor_144, %result_145 = qtensor.extract %68[%c2] : tensor<23x!qco.qubit>
    %controls_out_146, %targets_out_147 = qco.ctrl(%result_145) targets (%arg0 = %targets_out_143) {
      %95 = qco.ry(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qtensor.insert %controls_out_146 into %out_tensor_144[%c2] : tensor<23x!qco.qubit>
    %out_tensor_148, %result_149 = qtensor.extract %69[%c1] : tensor<23x!qco.qubit>
    %controls_out_150, %targets_out_151 = qco.ctrl(%result_149) targets (%arg0 = %targets_out_147) {
      %95 = qco.ry(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %70 = qtensor.insert %controls_out_150 into %out_tensor_148[%c1] : tensor<23x!qco.qubit>
    %out_tensor_152, %result_153 = qtensor.extract %70[%c0] : tensor<23x!qco.qubit>
    %controls_out_154, %targets_out_155 = qco.ctrl(%result_153) targets (%arg0 = %targets_out_151) {
      %95 = qco.ry(%cst) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %95 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qtensor.insert %controls_out_154 into %out_tensor_152[%c0] : tensor<23x!qco.qubit>
    %qubit_out, %result_156 = qco.measure %targets_out_155 : !qco.qubit
    cbit.store %result_156, %2[%c0] : !cbit.reg<24>
    %out_tensor_157, %result_158 = qtensor.extract %71[%c0] : tensor<23x!qco.qubit>
    %qubit_out_159, %result_160 = qco.measure %result_158 : !qco.qubit
    %72 = qtensor.insert %qubit_out_159 into %out_tensor_157[%c0] : tensor<23x!qco.qubit>
    cbit.store %result_160, %2[%c1] : !cbit.reg<24>
    %out_tensor_161, %result_162 = qtensor.extract %72[%c1] : tensor<23x!qco.qubit>
    %qubit_out_163, %result_164 = qco.measure %result_162 : !qco.qubit
    %73 = qtensor.insert %qubit_out_163 into %out_tensor_161[%c1] : tensor<23x!qco.qubit>
    cbit.store %result_164, %2[%c2] : !cbit.reg<24>
    %out_tensor_165, %result_166 = qtensor.extract %73[%c2] : tensor<23x!qco.qubit>
    %qubit_out_167, %result_168 = qco.measure %result_166 : !qco.qubit
    %74 = qtensor.insert %qubit_out_167 into %out_tensor_165[%c2] : tensor<23x!qco.qubit>
    cbit.store %result_168, %2[%c3] : !cbit.reg<24>
    %out_tensor_169, %result_170 = qtensor.extract %74[%c3] : tensor<23x!qco.qubit>
    %qubit_out_171, %result_172 = qco.measure %result_170 : !qco.qubit
    %75 = qtensor.insert %qubit_out_171 into %out_tensor_169[%c3] : tensor<23x!qco.qubit>
    cbit.store %result_172, %2[%c4] : !cbit.reg<24>
    %out_tensor_173, %result_174 = qtensor.extract %75[%c4] : tensor<23x!qco.qubit>
    %qubit_out_175, %result_176 = qco.measure %result_174 : !qco.qubit
    %76 = qtensor.insert %qubit_out_175 into %out_tensor_173[%c4] : tensor<23x!qco.qubit>
    cbit.store %result_176, %2[%c5] : !cbit.reg<24>
    %out_tensor_177, %result_178 = qtensor.extract %76[%c5] : tensor<23x!qco.qubit>
    %qubit_out_179, %result_180 = qco.measure %result_178 : !qco.qubit
    %77 = qtensor.insert %qubit_out_179 into %out_tensor_177[%c5] : tensor<23x!qco.qubit>
    cbit.store %result_180, %2[%c6] : !cbit.reg<24>
    %out_tensor_181, %result_182 = qtensor.extract %77[%c6] : tensor<23x!qco.qubit>
    %qubit_out_183, %result_184 = qco.measure %result_182 : !qco.qubit
    %78 = qtensor.insert %qubit_out_183 into %out_tensor_181[%c6] : tensor<23x!qco.qubit>
    cbit.store %result_184, %2[%c7] : !cbit.reg<24>
    %out_tensor_185, %result_186 = qtensor.extract %78[%c7] : tensor<23x!qco.qubit>
    %qubit_out_187, %result_188 = qco.measure %result_186 : !qco.qubit
    %79 = qtensor.insert %qubit_out_187 into %out_tensor_185[%c7] : tensor<23x!qco.qubit>
    cbit.store %result_188, %2[%c8] : !cbit.reg<24>
    %out_tensor_189, %result_190 = qtensor.extract %79[%c8] : tensor<23x!qco.qubit>
    %qubit_out_191, %result_192 = qco.measure %result_190 : !qco.qubit
    %80 = qtensor.insert %qubit_out_191 into %out_tensor_189[%c8] : tensor<23x!qco.qubit>
    cbit.store %result_192, %2[%c9] : !cbit.reg<24>
    %out_tensor_193, %result_194 = qtensor.extract %80[%c9] : tensor<23x!qco.qubit>
    %qubit_out_195, %result_196 = qco.measure %result_194 : !qco.qubit
    %81 = qtensor.insert %qubit_out_195 into %out_tensor_193[%c9] : tensor<23x!qco.qubit>
    cbit.store %result_196, %2[%c10] : !cbit.reg<24>
    %out_tensor_197, %result_198 = qtensor.extract %81[%c10] : tensor<23x!qco.qubit>
    %qubit_out_199, %result_200 = qco.measure %result_198 : !qco.qubit
    %82 = qtensor.insert %qubit_out_199 into %out_tensor_197[%c10] : tensor<23x!qco.qubit>
    cbit.store %result_200, %2[%c11] : !cbit.reg<24>
    %out_tensor_201, %result_202 = qtensor.extract %82[%c11] : tensor<23x!qco.qubit>
    %qubit_out_203, %result_204 = qco.measure %result_202 : !qco.qubit
    %83 = qtensor.insert %qubit_out_203 into %out_tensor_201[%c11] : tensor<23x!qco.qubit>
    cbit.store %result_204, %2[%c12] : !cbit.reg<24>
    %out_tensor_205, %result_206 = qtensor.extract %83[%c12] : tensor<23x!qco.qubit>
    %qubit_out_207, %result_208 = qco.measure %result_206 : !qco.qubit
    %84 = qtensor.insert %qubit_out_207 into %out_tensor_205[%c12] : tensor<23x!qco.qubit>
    cbit.store %result_208, %2[%c13] : !cbit.reg<24>
    %out_tensor_209, %result_210 = qtensor.extract %84[%c13] : tensor<23x!qco.qubit>
    %qubit_out_211, %result_212 = qco.measure %result_210 : !qco.qubit
    %85 = qtensor.insert %qubit_out_211 into %out_tensor_209[%c13] : tensor<23x!qco.qubit>
    cbit.store %result_212, %2[%c14] : !cbit.reg<24>
    %out_tensor_213, %result_214 = qtensor.extract %85[%c14] : tensor<23x!qco.qubit>
    %qubit_out_215, %result_216 = qco.measure %result_214 : !qco.qubit
    %86 = qtensor.insert %qubit_out_215 into %out_tensor_213[%c14] : tensor<23x!qco.qubit>
    cbit.store %result_216, %2[%c15] : !cbit.reg<24>
    %out_tensor_217, %result_218 = qtensor.extract %86[%c15] : tensor<23x!qco.qubit>
    %qubit_out_219, %result_220 = qco.measure %result_218 : !qco.qubit
    %87 = qtensor.insert %qubit_out_219 into %out_tensor_217[%c15] : tensor<23x!qco.qubit>
    cbit.store %result_220, %2[%c16] : !cbit.reg<24>
    %out_tensor_221, %result_222 = qtensor.extract %87[%c16] : tensor<23x!qco.qubit>
    %qubit_out_223, %result_224 = qco.measure %result_222 : !qco.qubit
    %88 = qtensor.insert %qubit_out_223 into %out_tensor_221[%c16] : tensor<23x!qco.qubit>
    cbit.store %result_224, %2[%c17] : !cbit.reg<24>
    %out_tensor_225, %result_226 = qtensor.extract %88[%c17] : tensor<23x!qco.qubit>
    %qubit_out_227, %result_228 = qco.measure %result_226 : !qco.qubit
    %89 = qtensor.insert %qubit_out_227 into %out_tensor_225[%c17] : tensor<23x!qco.qubit>
    cbit.store %result_228, %2[%c18] : !cbit.reg<24>
    %out_tensor_229, %result_230 = qtensor.extract %89[%c18] : tensor<23x!qco.qubit>
    %qubit_out_231, %result_232 = qco.measure %result_230 : !qco.qubit
    %90 = qtensor.insert %qubit_out_231 into %out_tensor_229[%c18] : tensor<23x!qco.qubit>
    cbit.store %result_232, %2[%c19] : !cbit.reg<24>
    %out_tensor_233, %result_234 = qtensor.extract %90[%c19] : tensor<23x!qco.qubit>
    %qubit_out_235, %result_236 = qco.measure %result_234 : !qco.qubit
    %91 = qtensor.insert %qubit_out_235 into %out_tensor_233[%c19] : tensor<23x!qco.qubit>
    cbit.store %result_236, %2[%c20] : !cbit.reg<24>
    %out_tensor_237, %result_238 = qtensor.extract %91[%c20] : tensor<23x!qco.qubit>
    %qubit_out_239, %result_240 = qco.measure %result_238 : !qco.qubit
    %92 = qtensor.insert %qubit_out_239 into %out_tensor_237[%c20] : tensor<23x!qco.qubit>
    cbit.store %result_240, %2[%c21] : !cbit.reg<24>
    %out_tensor_241, %result_242 = qtensor.extract %92[%c21] : tensor<23x!qco.qubit>
    %qubit_out_243, %result_244 = qco.measure %result_242 : !qco.qubit
    %93 = qtensor.insert %qubit_out_243 into %out_tensor_241[%c21] : tensor<23x!qco.qubit>
    cbit.store %result_244, %2[%c22] : !cbit.reg<24>
    %out_tensor_245, %result_246 = qtensor.extract %93[%c22] : tensor<23x!qco.qubit>
    %qubit_out_247, %result_248 = qco.measure %result_246 : !qco.qubit
    %94 = qtensor.insert %qubit_out_247 into %out_tensor_245[%c22] : tensor<23x!qco.qubit>
    cbit.store %result_248, %2[%c23] : !cbit.reg<24>
    qco.sink %qubit_out : !qco.qubit
    qtensor.dealloc %94 : tensor<23x!qco.qubit>
    return %2 : !cbit.reg<24>
  }
}
