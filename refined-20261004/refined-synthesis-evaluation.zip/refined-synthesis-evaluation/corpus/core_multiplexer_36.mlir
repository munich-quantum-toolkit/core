module {
  func.func @main() -> !cbit.reg<36> attributes {mqt.entry_point} {
    %cst = arith.constant 9.1432379954197477E-11 : f64
    %cst_0 = arith.constant 1.8286475990839495E-10 : f64
    %cst_1 = arith.constant 3.6572951981678991E-10 : f64
    %cst_2 = arith.constant 7.3145903963357981E-10 : f64
    %cst_3 = arith.constant 1.4629180792671596E-9 : f64
    %cst_4 = arith.constant 2.9258361585343192E-9 : f64
    %cst_5 = arith.constant 5.8516723170686385E-9 : f64
    %cst_6 = arith.constant 1.1703344634137277E-8 : f64
    %cst_7 = arith.constant 2.3406689268274554E-8 : f64
    %cst_8 = arith.constant 4.6813378536549108E-8 : f64
    %cst_9 = arith.constant 9.3626757073098215E-8 : f64
    %cst_10 = arith.constant 1.8725351414619643E-7 : f64
    %cst_11 = arith.constant 3.7450702829239286E-7 : f64
    %cst_12 = arith.constant 7.4901405658478573E-7 : f64
    %cst_13 = arith.constant 1.4980281131695715E-6 : f64
    %cst_14 = arith.constant 2.9960562263391429E-6 : f64
    %cst_15 = arith.constant 5.9921124526782858E-6 : f64
    %cst_16 = arith.constant 1.1984224905356572E-5 : f64
    %cst_17 = arith.constant 2.3968449810713143E-5 : f64
    %cst_18 = arith.constant 4.7936899621426287E-5 : f64
    %cst_19 = arith.constant 9.5873799242852573E-5 : f64
    %cst_20 = arith.constant 1.9174759848570515E-4 : f64
    %cst_21 = arith.constant 3.8349519697141029E-4 : f64
    %cst_22 = arith.constant 7.6699039394282058E-4 : f64
    %cst_23 = arith.constant 0.0015339807878856412 : f64
    %cst_24 = arith.constant 0.0030679615757712823 : f64
    %cst_25 = arith.constant 0.0061359231515425647 : f64
    %cst_26 = arith.constant 0.012271846303085129 : f64
    %cst_27 = arith.constant 0.024543692606170259 : f64
    %cst_28 = arith.constant 0.049087385212340517 : f64
    %cst_29 = arith.constant 0.098174770424681035 : f64
    %cst_30 = arith.constant 0.19634954084936207 : f64
    %cst_31 = arith.constant 0.39269908169872414 : f64
    %cst_32 = arith.constant 0.78539816339744828 : f64
    %c33 = arith.constant 33 : index
    %c32 = arith.constant 32 : index
    %c31 = arith.constant 31 : index
    %c30 = arith.constant 30 : index
    %c29 = arith.constant 29 : index
    %c28 = arith.constant 28 : index
    %c27 = arith.constant 27 : index
    %c26 = arith.constant 26 : index
    %c25 = arith.constant 25 : index
    %c24 = arith.constant 24 : index
    %c23 = arith.constant 23 : index
    %c22 = arith.constant 22 : index
    %c21 = arith.constant 21 : index
    %c20 = arith.constant 20 : index
    %c19 = arith.constant 19 : index
    %c18 = arith.constant 18 : index
    %c17 = arith.constant 17 : index
    %c16 = arith.constant 16 : index
    %c15 = arith.constant 15 : index
    %c14 = arith.constant 14 : index
    %c13 = arith.constant 13 : index
    %c12 = arith.constant 12 : index
    %c11 = arith.constant 11 : index
    %c10 = arith.constant 10 : index
    %c9 = arith.constant 9 : index
    %c8 = arith.constant 8 : index
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %cst_33 = arith.constant 1.5707963267948966 : f64
    %c34 = arith.constant 34 : index
    %c35 = arith.constant 35 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %0 = qtensor.alloc(%c35) {mqt.register_name = "controls"} : tensor<35x!qco.qubit>
    %1 = qco.alloc : !qco.qubit
    %2 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<36>
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<35x!qco.qubit>
    %3 = qco.h %result : !qco.qubit -> !qco.qubit
    %4 = qtensor.insert %3 into %out_tensor[%c0] : tensor<35x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %4[%c1] : tensor<35x!qco.qubit>
    %5 = qco.h %result_35 : !qco.qubit -> !qco.qubit
    %6 = qtensor.insert %5 into %out_tensor_34[%c1] : tensor<35x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %6[%c2] : tensor<35x!qco.qubit>
    %7 = qco.h %result_37 : !qco.qubit -> !qco.qubit
    %8 = qtensor.insert %7 into %out_tensor_36[%c2] : tensor<35x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %8[%c3] : tensor<35x!qco.qubit>
    %9 = qco.h %result_39 : !qco.qubit -> !qco.qubit
    %10 = qtensor.insert %9 into %out_tensor_38[%c3] : tensor<35x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %10[%c4] : tensor<35x!qco.qubit>
    %11 = qco.h %result_41 : !qco.qubit -> !qco.qubit
    %12 = qtensor.insert %11 into %out_tensor_40[%c4] : tensor<35x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %12[%c5] : tensor<35x!qco.qubit>
    %13 = qco.h %result_43 : !qco.qubit -> !qco.qubit
    %14 = qtensor.insert %13 into %out_tensor_42[%c5] : tensor<35x!qco.qubit>
    %out_tensor_44, %result_45 = qtensor.extract %14[%c6] : tensor<35x!qco.qubit>
    %15 = qco.h %result_45 : !qco.qubit -> !qco.qubit
    %16 = qtensor.insert %15 into %out_tensor_44[%c6] : tensor<35x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %16[%c7] : tensor<35x!qco.qubit>
    %17 = qco.h %result_47 : !qco.qubit -> !qco.qubit
    %18 = qtensor.insert %17 into %out_tensor_46[%c7] : tensor<35x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %18[%c8] : tensor<35x!qco.qubit>
    %19 = qco.h %result_49 : !qco.qubit -> !qco.qubit
    %20 = qtensor.insert %19 into %out_tensor_48[%c8] : tensor<35x!qco.qubit>
    %out_tensor_50, %result_51 = qtensor.extract %20[%c9] : tensor<35x!qco.qubit>
    %21 = qco.h %result_51 : !qco.qubit -> !qco.qubit
    %22 = qtensor.insert %21 into %out_tensor_50[%c9] : tensor<35x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %22[%c10] : tensor<35x!qco.qubit>
    %23 = qco.h %result_53 : !qco.qubit -> !qco.qubit
    %24 = qtensor.insert %23 into %out_tensor_52[%c10] : tensor<35x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %24[%c11] : tensor<35x!qco.qubit>
    %25 = qco.h %result_55 : !qco.qubit -> !qco.qubit
    %26 = qtensor.insert %25 into %out_tensor_54[%c11] : tensor<35x!qco.qubit>
    %out_tensor_56, %result_57 = qtensor.extract %26[%c12] : tensor<35x!qco.qubit>
    %27 = qco.h %result_57 : !qco.qubit -> !qco.qubit
    %28 = qtensor.insert %27 into %out_tensor_56[%c12] : tensor<35x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %28[%c13] : tensor<35x!qco.qubit>
    %29 = qco.h %result_59 : !qco.qubit -> !qco.qubit
    %30 = qtensor.insert %29 into %out_tensor_58[%c13] : tensor<35x!qco.qubit>
    %out_tensor_60, %result_61 = qtensor.extract %30[%c14] : tensor<35x!qco.qubit>
    %31 = qco.h %result_61 : !qco.qubit -> !qco.qubit
    %32 = qtensor.insert %31 into %out_tensor_60[%c14] : tensor<35x!qco.qubit>
    %out_tensor_62, %result_63 = qtensor.extract %32[%c15] : tensor<35x!qco.qubit>
    %33 = qco.h %result_63 : !qco.qubit -> !qco.qubit
    %34 = qtensor.insert %33 into %out_tensor_62[%c15] : tensor<35x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %34[%c16] : tensor<35x!qco.qubit>
    %35 = qco.h %result_65 : !qco.qubit -> !qco.qubit
    %36 = qtensor.insert %35 into %out_tensor_64[%c16] : tensor<35x!qco.qubit>
    %out_tensor_66, %result_67 = qtensor.extract %36[%c17] : tensor<35x!qco.qubit>
    %37 = qco.h %result_67 : !qco.qubit -> !qco.qubit
    %38 = qtensor.insert %37 into %out_tensor_66[%c17] : tensor<35x!qco.qubit>
    %out_tensor_68, %result_69 = qtensor.extract %38[%c18] : tensor<35x!qco.qubit>
    %39 = qco.h %result_69 : !qco.qubit -> !qco.qubit
    %40 = qtensor.insert %39 into %out_tensor_68[%c18] : tensor<35x!qco.qubit>
    %out_tensor_70, %result_71 = qtensor.extract %40[%c19] : tensor<35x!qco.qubit>
    %41 = qco.h %result_71 : !qco.qubit -> !qco.qubit
    %42 = qtensor.insert %41 into %out_tensor_70[%c19] : tensor<35x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %42[%c20] : tensor<35x!qco.qubit>
    %43 = qco.h %result_73 : !qco.qubit -> !qco.qubit
    %44 = qtensor.insert %43 into %out_tensor_72[%c20] : tensor<35x!qco.qubit>
    %out_tensor_74, %result_75 = qtensor.extract %44[%c21] : tensor<35x!qco.qubit>
    %45 = qco.h %result_75 : !qco.qubit -> !qco.qubit
    %46 = qtensor.insert %45 into %out_tensor_74[%c21] : tensor<35x!qco.qubit>
    %out_tensor_76, %result_77 = qtensor.extract %46[%c22] : tensor<35x!qco.qubit>
    %47 = qco.h %result_77 : !qco.qubit -> !qco.qubit
    %48 = qtensor.insert %47 into %out_tensor_76[%c22] : tensor<35x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %48[%c23] : tensor<35x!qco.qubit>
    %49 = qco.h %result_79 : !qco.qubit -> !qco.qubit
    %50 = qtensor.insert %49 into %out_tensor_78[%c23] : tensor<35x!qco.qubit>
    %out_tensor_80, %result_81 = qtensor.extract %50[%c24] : tensor<35x!qco.qubit>
    %51 = qco.h %result_81 : !qco.qubit -> !qco.qubit
    %52 = qtensor.insert %51 into %out_tensor_80[%c24] : tensor<35x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %52[%c25] : tensor<35x!qco.qubit>
    %53 = qco.h %result_83 : !qco.qubit -> !qco.qubit
    %54 = qtensor.insert %53 into %out_tensor_82[%c25] : tensor<35x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %54[%c26] : tensor<35x!qco.qubit>
    %55 = qco.h %result_85 : !qco.qubit -> !qco.qubit
    %56 = qtensor.insert %55 into %out_tensor_84[%c26] : tensor<35x!qco.qubit>
    %out_tensor_86, %result_87 = qtensor.extract %56[%c27] : tensor<35x!qco.qubit>
    %57 = qco.h %result_87 : !qco.qubit -> !qco.qubit
    %58 = qtensor.insert %57 into %out_tensor_86[%c27] : tensor<35x!qco.qubit>
    %out_tensor_88, %result_89 = qtensor.extract %58[%c28] : tensor<35x!qco.qubit>
    %59 = qco.h %result_89 : !qco.qubit -> !qco.qubit
    %60 = qtensor.insert %59 into %out_tensor_88[%c28] : tensor<35x!qco.qubit>
    %out_tensor_90, %result_91 = qtensor.extract %60[%c29] : tensor<35x!qco.qubit>
    %61 = qco.h %result_91 : !qco.qubit -> !qco.qubit
    %62 = qtensor.insert %61 into %out_tensor_90[%c29] : tensor<35x!qco.qubit>
    %out_tensor_92, %result_93 = qtensor.extract %62[%c30] : tensor<35x!qco.qubit>
    %63 = qco.h %result_93 : !qco.qubit -> !qco.qubit
    %64 = qtensor.insert %63 into %out_tensor_92[%c30] : tensor<35x!qco.qubit>
    %out_tensor_94, %result_95 = qtensor.extract %64[%c31] : tensor<35x!qco.qubit>
    %65 = qco.h %result_95 : !qco.qubit -> !qco.qubit
    %66 = qtensor.insert %65 into %out_tensor_94[%c31] : tensor<35x!qco.qubit>
    %out_tensor_96, %result_97 = qtensor.extract %66[%c32] : tensor<35x!qco.qubit>
    %67 = qco.h %result_97 : !qco.qubit -> !qco.qubit
    %68 = qtensor.insert %67 into %out_tensor_96[%c32] : tensor<35x!qco.qubit>
    %out_tensor_98, %result_99 = qtensor.extract %68[%c33] : tensor<35x!qco.qubit>
    %69 = qco.h %result_99 : !qco.qubit -> !qco.qubit
    %70 = qtensor.insert %69 into %out_tensor_98[%c33] : tensor<35x!qco.qubit>
    %out_tensor_100, %result_101 = qtensor.extract %70[%c34] : tensor<35x!qco.qubit>
    %71 = qco.h %result_101 : !qco.qubit -> !qco.qubit
    %72 = qtensor.insert %71 into %out_tensor_100[%c34] : tensor<35x!qco.qubit>
    %out_tensor_102, %result_103 = qtensor.extract %72[%c34] : tensor<35x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_103) targets (%arg0 = %1) {
      %143 = qco.ry(%cst_33) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %73 = qtensor.insert %controls_out into %out_tensor_102[%c34] : tensor<35x!qco.qubit>
    %out_tensor_104, %result_105 = qtensor.extract %73[%c33] : tensor<35x!qco.qubit>
    %controls_out_106, %targets_out_107 = qco.ctrl(%result_105) targets (%arg0 = %targets_out) {
      %143 = qco.ry(%cst_32) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %74 = qtensor.insert %controls_out_106 into %out_tensor_104[%c33] : tensor<35x!qco.qubit>
    %out_tensor_108, %result_109 = qtensor.extract %74[%c32] : tensor<35x!qco.qubit>
    %controls_out_110, %targets_out_111 = qco.ctrl(%result_109) targets (%arg0 = %targets_out_107) {
      %143 = qco.ry(%cst_31) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %75 = qtensor.insert %controls_out_110 into %out_tensor_108[%c32] : tensor<35x!qco.qubit>
    %out_tensor_112, %result_113 = qtensor.extract %75[%c31] : tensor<35x!qco.qubit>
    %controls_out_114, %targets_out_115 = qco.ctrl(%result_113) targets (%arg0 = %targets_out_111) {
      %143 = qco.ry(%cst_30) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %76 = qtensor.insert %controls_out_114 into %out_tensor_112[%c31] : tensor<35x!qco.qubit>
    %out_tensor_116, %result_117 = qtensor.extract %76[%c30] : tensor<35x!qco.qubit>
    %controls_out_118, %targets_out_119 = qco.ctrl(%result_117) targets (%arg0 = %targets_out_115) {
      %143 = qco.ry(%cst_29) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qtensor.insert %controls_out_118 into %out_tensor_116[%c30] : tensor<35x!qco.qubit>
    %out_tensor_120, %result_121 = qtensor.extract %77[%c29] : tensor<35x!qco.qubit>
    %controls_out_122, %targets_out_123 = qco.ctrl(%result_121) targets (%arg0 = %targets_out_119) {
      %143 = qco.ry(%cst_28) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %78 = qtensor.insert %controls_out_122 into %out_tensor_120[%c29] : tensor<35x!qco.qubit>
    %out_tensor_124, %result_125 = qtensor.extract %78[%c28] : tensor<35x!qco.qubit>
    %controls_out_126, %targets_out_127 = qco.ctrl(%result_125) targets (%arg0 = %targets_out_123) {
      %143 = qco.ry(%cst_27) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %79 = qtensor.insert %controls_out_126 into %out_tensor_124[%c28] : tensor<35x!qco.qubit>
    %out_tensor_128, %result_129 = qtensor.extract %79[%c27] : tensor<35x!qco.qubit>
    %controls_out_130, %targets_out_131 = qco.ctrl(%result_129) targets (%arg0 = %targets_out_127) {
      %143 = qco.ry(%cst_26) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %80 = qtensor.insert %controls_out_130 into %out_tensor_128[%c27] : tensor<35x!qco.qubit>
    %out_tensor_132, %result_133 = qtensor.extract %80[%c26] : tensor<35x!qco.qubit>
    %controls_out_134, %targets_out_135 = qco.ctrl(%result_133) targets (%arg0 = %targets_out_131) {
      %143 = qco.ry(%cst_25) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %81 = qtensor.insert %controls_out_134 into %out_tensor_132[%c26] : tensor<35x!qco.qubit>
    %out_tensor_136, %result_137 = qtensor.extract %81[%c25] : tensor<35x!qco.qubit>
    %controls_out_138, %targets_out_139 = qco.ctrl(%result_137) targets (%arg0 = %targets_out_135) {
      %143 = qco.ry(%cst_24) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %82 = qtensor.insert %controls_out_138 into %out_tensor_136[%c25] : tensor<35x!qco.qubit>
    %out_tensor_140, %result_141 = qtensor.extract %82[%c24] : tensor<35x!qco.qubit>
    %controls_out_142, %targets_out_143 = qco.ctrl(%result_141) targets (%arg0 = %targets_out_139) {
      %143 = qco.ry(%cst_23) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qtensor.insert %controls_out_142 into %out_tensor_140[%c24] : tensor<35x!qco.qubit>
    %out_tensor_144, %result_145 = qtensor.extract %83[%c23] : tensor<35x!qco.qubit>
    %controls_out_146, %targets_out_147 = qco.ctrl(%result_145) targets (%arg0 = %targets_out_143) {
      %143 = qco.ry(%cst_22) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %84 = qtensor.insert %controls_out_146 into %out_tensor_144[%c23] : tensor<35x!qco.qubit>
    %out_tensor_148, %result_149 = qtensor.extract %84[%c22] : tensor<35x!qco.qubit>
    %controls_out_150, %targets_out_151 = qco.ctrl(%result_149) targets (%arg0 = %targets_out_147) {
      %143 = qco.ry(%cst_21) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %85 = qtensor.insert %controls_out_150 into %out_tensor_148[%c22] : tensor<35x!qco.qubit>
    %out_tensor_152, %result_153 = qtensor.extract %85[%c21] : tensor<35x!qco.qubit>
    %controls_out_154, %targets_out_155 = qco.ctrl(%result_153) targets (%arg0 = %targets_out_151) {
      %143 = qco.ry(%cst_20) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %86 = qtensor.insert %controls_out_154 into %out_tensor_152[%c21] : tensor<35x!qco.qubit>
    %out_tensor_156, %result_157 = qtensor.extract %86[%c20] : tensor<35x!qco.qubit>
    %controls_out_158, %targets_out_159 = qco.ctrl(%result_157) targets (%arg0 = %targets_out_155) {
      %143 = qco.ry(%cst_19) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %87 = qtensor.insert %controls_out_158 into %out_tensor_156[%c20] : tensor<35x!qco.qubit>
    %out_tensor_160, %result_161 = qtensor.extract %87[%c19] : tensor<35x!qco.qubit>
    %controls_out_162, %targets_out_163 = qco.ctrl(%result_161) targets (%arg0 = %targets_out_159) {
      %143 = qco.ry(%cst_18) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %88 = qtensor.insert %controls_out_162 into %out_tensor_160[%c19] : tensor<35x!qco.qubit>
    %out_tensor_164, %result_165 = qtensor.extract %88[%c18] : tensor<35x!qco.qubit>
    %controls_out_166, %targets_out_167 = qco.ctrl(%result_165) targets (%arg0 = %targets_out_163) {
      %143 = qco.ry(%cst_17) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %89 = qtensor.insert %controls_out_166 into %out_tensor_164[%c18] : tensor<35x!qco.qubit>
    %out_tensor_168, %result_169 = qtensor.extract %89[%c17] : tensor<35x!qco.qubit>
    %controls_out_170, %targets_out_171 = qco.ctrl(%result_169) targets (%arg0 = %targets_out_167) {
      %143 = qco.ry(%cst_16) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %90 = qtensor.insert %controls_out_170 into %out_tensor_168[%c17] : tensor<35x!qco.qubit>
    %out_tensor_172, %result_173 = qtensor.extract %90[%c16] : tensor<35x!qco.qubit>
    %controls_out_174, %targets_out_175 = qco.ctrl(%result_173) targets (%arg0 = %targets_out_171) {
      %143 = qco.ry(%cst_15) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %91 = qtensor.insert %controls_out_174 into %out_tensor_172[%c16] : tensor<35x!qco.qubit>
    %out_tensor_176, %result_177 = qtensor.extract %91[%c15] : tensor<35x!qco.qubit>
    %controls_out_178, %targets_out_179 = qco.ctrl(%result_177) targets (%arg0 = %targets_out_175) {
      %143 = qco.ry(%cst_14) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %92 = qtensor.insert %controls_out_178 into %out_tensor_176[%c15] : tensor<35x!qco.qubit>
    %out_tensor_180, %result_181 = qtensor.extract %92[%c14] : tensor<35x!qco.qubit>
    %controls_out_182, %targets_out_183 = qco.ctrl(%result_181) targets (%arg0 = %targets_out_179) {
      %143 = qco.ry(%cst_13) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %93 = qtensor.insert %controls_out_182 into %out_tensor_180[%c14] : tensor<35x!qco.qubit>
    %out_tensor_184, %result_185 = qtensor.extract %93[%c13] : tensor<35x!qco.qubit>
    %controls_out_186, %targets_out_187 = qco.ctrl(%result_185) targets (%arg0 = %targets_out_183) {
      %143 = qco.ry(%cst_12) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %94 = qtensor.insert %controls_out_186 into %out_tensor_184[%c13] : tensor<35x!qco.qubit>
    %out_tensor_188, %result_189 = qtensor.extract %94[%c12] : tensor<35x!qco.qubit>
    %controls_out_190, %targets_out_191 = qco.ctrl(%result_189) targets (%arg0 = %targets_out_187) {
      %143 = qco.ry(%cst_11) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %95 = qtensor.insert %controls_out_190 into %out_tensor_188[%c12] : tensor<35x!qco.qubit>
    %out_tensor_192, %result_193 = qtensor.extract %95[%c11] : tensor<35x!qco.qubit>
    %controls_out_194, %targets_out_195 = qco.ctrl(%result_193) targets (%arg0 = %targets_out_191) {
      %143 = qco.ry(%cst_10) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %96 = qtensor.insert %controls_out_194 into %out_tensor_192[%c11] : tensor<35x!qco.qubit>
    %out_tensor_196, %result_197 = qtensor.extract %96[%c10] : tensor<35x!qco.qubit>
    %controls_out_198, %targets_out_199 = qco.ctrl(%result_197) targets (%arg0 = %targets_out_195) {
      %143 = qco.ry(%cst_9) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %97 = qtensor.insert %controls_out_198 into %out_tensor_196[%c10] : tensor<35x!qco.qubit>
    %out_tensor_200, %result_201 = qtensor.extract %97[%c9] : tensor<35x!qco.qubit>
    %controls_out_202, %targets_out_203 = qco.ctrl(%result_201) targets (%arg0 = %targets_out_199) {
      %143 = qco.ry(%cst_8) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %98 = qtensor.insert %controls_out_202 into %out_tensor_200[%c9] : tensor<35x!qco.qubit>
    %out_tensor_204, %result_205 = qtensor.extract %98[%c8] : tensor<35x!qco.qubit>
    %controls_out_206, %targets_out_207 = qco.ctrl(%result_205) targets (%arg0 = %targets_out_203) {
      %143 = qco.ry(%cst_7) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %99 = qtensor.insert %controls_out_206 into %out_tensor_204[%c8] : tensor<35x!qco.qubit>
    %out_tensor_208, %result_209 = qtensor.extract %99[%c7] : tensor<35x!qco.qubit>
    %controls_out_210, %targets_out_211 = qco.ctrl(%result_209) targets (%arg0 = %targets_out_207) {
      %143 = qco.ry(%cst_6) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %100 = qtensor.insert %controls_out_210 into %out_tensor_208[%c7] : tensor<35x!qco.qubit>
    %out_tensor_212, %result_213 = qtensor.extract %100[%c6] : tensor<35x!qco.qubit>
    %controls_out_214, %targets_out_215 = qco.ctrl(%result_213) targets (%arg0 = %targets_out_211) {
      %143 = qco.ry(%cst_5) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %101 = qtensor.insert %controls_out_214 into %out_tensor_212[%c6] : tensor<35x!qco.qubit>
    %out_tensor_216, %result_217 = qtensor.extract %101[%c5] : tensor<35x!qco.qubit>
    %controls_out_218, %targets_out_219 = qco.ctrl(%result_217) targets (%arg0 = %targets_out_215) {
      %143 = qco.ry(%cst_4) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %102 = qtensor.insert %controls_out_218 into %out_tensor_216[%c5] : tensor<35x!qco.qubit>
    %out_tensor_220, %result_221 = qtensor.extract %102[%c4] : tensor<35x!qco.qubit>
    %controls_out_222, %targets_out_223 = qco.ctrl(%result_221) targets (%arg0 = %targets_out_219) {
      %143 = qco.ry(%cst_3) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %103 = qtensor.insert %controls_out_222 into %out_tensor_220[%c4] : tensor<35x!qco.qubit>
    %out_tensor_224, %result_225 = qtensor.extract %103[%c3] : tensor<35x!qco.qubit>
    %controls_out_226, %targets_out_227 = qco.ctrl(%result_225) targets (%arg0 = %targets_out_223) {
      %143 = qco.ry(%cst_2) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %104 = qtensor.insert %controls_out_226 into %out_tensor_224[%c3] : tensor<35x!qco.qubit>
    %out_tensor_228, %result_229 = qtensor.extract %104[%c2] : tensor<35x!qco.qubit>
    %controls_out_230, %targets_out_231 = qco.ctrl(%result_229) targets (%arg0 = %targets_out_227) {
      %143 = qco.ry(%cst_1) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %105 = qtensor.insert %controls_out_230 into %out_tensor_228[%c2] : tensor<35x!qco.qubit>
    %out_tensor_232, %result_233 = qtensor.extract %105[%c1] : tensor<35x!qco.qubit>
    %controls_out_234, %targets_out_235 = qco.ctrl(%result_233) targets (%arg0 = %targets_out_231) {
      %143 = qco.ry(%cst_0) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %106 = qtensor.insert %controls_out_234 into %out_tensor_232[%c1] : tensor<35x!qco.qubit>
    %out_tensor_236, %result_237 = qtensor.extract %106[%c0] : tensor<35x!qco.qubit>
    %controls_out_238, %targets_out_239 = qco.ctrl(%result_237) targets (%arg0 = %targets_out_235) {
      %143 = qco.ry(%cst) %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %143 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %107 = qtensor.insert %controls_out_238 into %out_tensor_236[%c0] : tensor<35x!qco.qubit>
    %qubit_out, %result_240 = qco.measure %targets_out_239 : !qco.qubit
    cbit.store %result_240, %2[%c0] : !cbit.reg<36>
    %out_tensor_241, %result_242 = qtensor.extract %107[%c0] : tensor<35x!qco.qubit>
    %qubit_out_243, %result_244 = qco.measure %result_242 : !qco.qubit
    %108 = qtensor.insert %qubit_out_243 into %out_tensor_241[%c0] : tensor<35x!qco.qubit>
    cbit.store %result_244, %2[%c1] : !cbit.reg<36>
    %out_tensor_245, %result_246 = qtensor.extract %108[%c1] : tensor<35x!qco.qubit>
    %qubit_out_247, %result_248 = qco.measure %result_246 : !qco.qubit
    %109 = qtensor.insert %qubit_out_247 into %out_tensor_245[%c1] : tensor<35x!qco.qubit>
    cbit.store %result_248, %2[%c2] : !cbit.reg<36>
    %out_tensor_249, %result_250 = qtensor.extract %109[%c2] : tensor<35x!qco.qubit>
    %qubit_out_251, %result_252 = qco.measure %result_250 : !qco.qubit
    %110 = qtensor.insert %qubit_out_251 into %out_tensor_249[%c2] : tensor<35x!qco.qubit>
    cbit.store %result_252, %2[%c3] : !cbit.reg<36>
    %out_tensor_253, %result_254 = qtensor.extract %110[%c3] : tensor<35x!qco.qubit>
    %qubit_out_255, %result_256 = qco.measure %result_254 : !qco.qubit
    %111 = qtensor.insert %qubit_out_255 into %out_tensor_253[%c3] : tensor<35x!qco.qubit>
    cbit.store %result_256, %2[%c4] : !cbit.reg<36>
    %out_tensor_257, %result_258 = qtensor.extract %111[%c4] : tensor<35x!qco.qubit>
    %qubit_out_259, %result_260 = qco.measure %result_258 : !qco.qubit
    %112 = qtensor.insert %qubit_out_259 into %out_tensor_257[%c4] : tensor<35x!qco.qubit>
    cbit.store %result_260, %2[%c5] : !cbit.reg<36>
    %out_tensor_261, %result_262 = qtensor.extract %112[%c5] : tensor<35x!qco.qubit>
    %qubit_out_263, %result_264 = qco.measure %result_262 : !qco.qubit
    %113 = qtensor.insert %qubit_out_263 into %out_tensor_261[%c5] : tensor<35x!qco.qubit>
    cbit.store %result_264, %2[%c6] : !cbit.reg<36>
    %out_tensor_265, %result_266 = qtensor.extract %113[%c6] : tensor<35x!qco.qubit>
    %qubit_out_267, %result_268 = qco.measure %result_266 : !qco.qubit
    %114 = qtensor.insert %qubit_out_267 into %out_tensor_265[%c6] : tensor<35x!qco.qubit>
    cbit.store %result_268, %2[%c7] : !cbit.reg<36>
    %out_tensor_269, %result_270 = qtensor.extract %114[%c7] : tensor<35x!qco.qubit>
    %qubit_out_271, %result_272 = qco.measure %result_270 : !qco.qubit
    %115 = qtensor.insert %qubit_out_271 into %out_tensor_269[%c7] : tensor<35x!qco.qubit>
    cbit.store %result_272, %2[%c8] : !cbit.reg<36>
    %out_tensor_273, %result_274 = qtensor.extract %115[%c8] : tensor<35x!qco.qubit>
    %qubit_out_275, %result_276 = qco.measure %result_274 : !qco.qubit
    %116 = qtensor.insert %qubit_out_275 into %out_tensor_273[%c8] : tensor<35x!qco.qubit>
    cbit.store %result_276, %2[%c9] : !cbit.reg<36>
    %out_tensor_277, %result_278 = qtensor.extract %116[%c9] : tensor<35x!qco.qubit>
    %qubit_out_279, %result_280 = qco.measure %result_278 : !qco.qubit
    %117 = qtensor.insert %qubit_out_279 into %out_tensor_277[%c9] : tensor<35x!qco.qubit>
    cbit.store %result_280, %2[%c10] : !cbit.reg<36>
    %out_tensor_281, %result_282 = qtensor.extract %117[%c10] : tensor<35x!qco.qubit>
    %qubit_out_283, %result_284 = qco.measure %result_282 : !qco.qubit
    %118 = qtensor.insert %qubit_out_283 into %out_tensor_281[%c10] : tensor<35x!qco.qubit>
    cbit.store %result_284, %2[%c11] : !cbit.reg<36>
    %out_tensor_285, %result_286 = qtensor.extract %118[%c11] : tensor<35x!qco.qubit>
    %qubit_out_287, %result_288 = qco.measure %result_286 : !qco.qubit
    %119 = qtensor.insert %qubit_out_287 into %out_tensor_285[%c11] : tensor<35x!qco.qubit>
    cbit.store %result_288, %2[%c12] : !cbit.reg<36>
    %out_tensor_289, %result_290 = qtensor.extract %119[%c12] : tensor<35x!qco.qubit>
    %qubit_out_291, %result_292 = qco.measure %result_290 : !qco.qubit
    %120 = qtensor.insert %qubit_out_291 into %out_tensor_289[%c12] : tensor<35x!qco.qubit>
    cbit.store %result_292, %2[%c13] : !cbit.reg<36>
    %out_tensor_293, %result_294 = qtensor.extract %120[%c13] : tensor<35x!qco.qubit>
    %qubit_out_295, %result_296 = qco.measure %result_294 : !qco.qubit
    %121 = qtensor.insert %qubit_out_295 into %out_tensor_293[%c13] : tensor<35x!qco.qubit>
    cbit.store %result_296, %2[%c14] : !cbit.reg<36>
    %out_tensor_297, %result_298 = qtensor.extract %121[%c14] : tensor<35x!qco.qubit>
    %qubit_out_299, %result_300 = qco.measure %result_298 : !qco.qubit
    %122 = qtensor.insert %qubit_out_299 into %out_tensor_297[%c14] : tensor<35x!qco.qubit>
    cbit.store %result_300, %2[%c15] : !cbit.reg<36>
    %out_tensor_301, %result_302 = qtensor.extract %122[%c15] : tensor<35x!qco.qubit>
    %qubit_out_303, %result_304 = qco.measure %result_302 : !qco.qubit
    %123 = qtensor.insert %qubit_out_303 into %out_tensor_301[%c15] : tensor<35x!qco.qubit>
    cbit.store %result_304, %2[%c16] : !cbit.reg<36>
    %out_tensor_305, %result_306 = qtensor.extract %123[%c16] : tensor<35x!qco.qubit>
    %qubit_out_307, %result_308 = qco.measure %result_306 : !qco.qubit
    %124 = qtensor.insert %qubit_out_307 into %out_tensor_305[%c16] : tensor<35x!qco.qubit>
    cbit.store %result_308, %2[%c17] : !cbit.reg<36>
    %out_tensor_309, %result_310 = qtensor.extract %124[%c17] : tensor<35x!qco.qubit>
    %qubit_out_311, %result_312 = qco.measure %result_310 : !qco.qubit
    %125 = qtensor.insert %qubit_out_311 into %out_tensor_309[%c17] : tensor<35x!qco.qubit>
    cbit.store %result_312, %2[%c18] : !cbit.reg<36>
    %out_tensor_313, %result_314 = qtensor.extract %125[%c18] : tensor<35x!qco.qubit>
    %qubit_out_315, %result_316 = qco.measure %result_314 : !qco.qubit
    %126 = qtensor.insert %qubit_out_315 into %out_tensor_313[%c18] : tensor<35x!qco.qubit>
    cbit.store %result_316, %2[%c19] : !cbit.reg<36>
    %out_tensor_317, %result_318 = qtensor.extract %126[%c19] : tensor<35x!qco.qubit>
    %qubit_out_319, %result_320 = qco.measure %result_318 : !qco.qubit
    %127 = qtensor.insert %qubit_out_319 into %out_tensor_317[%c19] : tensor<35x!qco.qubit>
    cbit.store %result_320, %2[%c20] : !cbit.reg<36>
    %out_tensor_321, %result_322 = qtensor.extract %127[%c20] : tensor<35x!qco.qubit>
    %qubit_out_323, %result_324 = qco.measure %result_322 : !qco.qubit
    %128 = qtensor.insert %qubit_out_323 into %out_tensor_321[%c20] : tensor<35x!qco.qubit>
    cbit.store %result_324, %2[%c21] : !cbit.reg<36>
    %out_tensor_325, %result_326 = qtensor.extract %128[%c21] : tensor<35x!qco.qubit>
    %qubit_out_327, %result_328 = qco.measure %result_326 : !qco.qubit
    %129 = qtensor.insert %qubit_out_327 into %out_tensor_325[%c21] : tensor<35x!qco.qubit>
    cbit.store %result_328, %2[%c22] : !cbit.reg<36>
    %out_tensor_329, %result_330 = qtensor.extract %129[%c22] : tensor<35x!qco.qubit>
    %qubit_out_331, %result_332 = qco.measure %result_330 : !qco.qubit
    %130 = qtensor.insert %qubit_out_331 into %out_tensor_329[%c22] : tensor<35x!qco.qubit>
    cbit.store %result_332, %2[%c23] : !cbit.reg<36>
    %out_tensor_333, %result_334 = qtensor.extract %130[%c23] : tensor<35x!qco.qubit>
    %qubit_out_335, %result_336 = qco.measure %result_334 : !qco.qubit
    %131 = qtensor.insert %qubit_out_335 into %out_tensor_333[%c23] : tensor<35x!qco.qubit>
    cbit.store %result_336, %2[%c24] : !cbit.reg<36>
    %out_tensor_337, %result_338 = qtensor.extract %131[%c24] : tensor<35x!qco.qubit>
    %qubit_out_339, %result_340 = qco.measure %result_338 : !qco.qubit
    %132 = qtensor.insert %qubit_out_339 into %out_tensor_337[%c24] : tensor<35x!qco.qubit>
    cbit.store %result_340, %2[%c25] : !cbit.reg<36>
    %out_tensor_341, %result_342 = qtensor.extract %132[%c25] : tensor<35x!qco.qubit>
    %qubit_out_343, %result_344 = qco.measure %result_342 : !qco.qubit
    %133 = qtensor.insert %qubit_out_343 into %out_tensor_341[%c25] : tensor<35x!qco.qubit>
    cbit.store %result_344, %2[%c26] : !cbit.reg<36>
    %out_tensor_345, %result_346 = qtensor.extract %133[%c26] : tensor<35x!qco.qubit>
    %qubit_out_347, %result_348 = qco.measure %result_346 : !qco.qubit
    %134 = qtensor.insert %qubit_out_347 into %out_tensor_345[%c26] : tensor<35x!qco.qubit>
    cbit.store %result_348, %2[%c27] : !cbit.reg<36>
    %out_tensor_349, %result_350 = qtensor.extract %134[%c27] : tensor<35x!qco.qubit>
    %qubit_out_351, %result_352 = qco.measure %result_350 : !qco.qubit
    %135 = qtensor.insert %qubit_out_351 into %out_tensor_349[%c27] : tensor<35x!qco.qubit>
    cbit.store %result_352, %2[%c28] : !cbit.reg<36>
    %out_tensor_353, %result_354 = qtensor.extract %135[%c28] : tensor<35x!qco.qubit>
    %qubit_out_355, %result_356 = qco.measure %result_354 : !qco.qubit
    %136 = qtensor.insert %qubit_out_355 into %out_tensor_353[%c28] : tensor<35x!qco.qubit>
    cbit.store %result_356, %2[%c29] : !cbit.reg<36>
    %out_tensor_357, %result_358 = qtensor.extract %136[%c29] : tensor<35x!qco.qubit>
    %qubit_out_359, %result_360 = qco.measure %result_358 : !qco.qubit
    %137 = qtensor.insert %qubit_out_359 into %out_tensor_357[%c29] : tensor<35x!qco.qubit>
    cbit.store %result_360, %2[%c30] : !cbit.reg<36>
    %out_tensor_361, %result_362 = qtensor.extract %137[%c30] : tensor<35x!qco.qubit>
    %qubit_out_363, %result_364 = qco.measure %result_362 : !qco.qubit
    %138 = qtensor.insert %qubit_out_363 into %out_tensor_361[%c30] : tensor<35x!qco.qubit>
    cbit.store %result_364, %2[%c31] : !cbit.reg<36>
    %out_tensor_365, %result_366 = qtensor.extract %138[%c31] : tensor<35x!qco.qubit>
    %qubit_out_367, %result_368 = qco.measure %result_366 : !qco.qubit
    %139 = qtensor.insert %qubit_out_367 into %out_tensor_365[%c31] : tensor<35x!qco.qubit>
    cbit.store %result_368, %2[%c32] : !cbit.reg<36>
    %out_tensor_369, %result_370 = qtensor.extract %139[%c32] : tensor<35x!qco.qubit>
    %qubit_out_371, %result_372 = qco.measure %result_370 : !qco.qubit
    %140 = qtensor.insert %qubit_out_371 into %out_tensor_369[%c32] : tensor<35x!qco.qubit>
    cbit.store %result_372, %2[%c33] : !cbit.reg<36>
    %out_tensor_373, %result_374 = qtensor.extract %140[%c33] : tensor<35x!qco.qubit>
    %qubit_out_375, %result_376 = qco.measure %result_374 : !qco.qubit
    %141 = qtensor.insert %qubit_out_375 into %out_tensor_373[%c33] : tensor<35x!qco.qubit>
    cbit.store %result_376, %2[%c34] : !cbit.reg<36>
    %out_tensor_377, %result_378 = qtensor.extract %141[%c34] : tensor<35x!qco.qubit>
    %qubit_out_379, %result_380 = qco.measure %result_378 : !qco.qubit
    %142 = qtensor.insert %qubit_out_379 into %out_tensor_377[%c34] : tensor<35x!qco.qubit>
    cbit.store %result_380, %2[%c35] : !cbit.reg<36>
    qco.sink %qubit_out : !qco.qubit
    qtensor.dealloc %142 : tensor<35x!qco.qubit>
    return %2 : !cbit.reg<36>
  }
}
