module {
  func.func @main() -> !cbit.reg<23> attributes {mqt.entry_point} {
    %false = arith.constant false
    %true = arith.constant true
    %c22 = arith.constant 22 : index
    %c21 = arith.constant 21 : index
    %c20 = arith.constant 20 : index
    %c19 = arith.constant 19 : index
    %c18 = arith.constant 18 : index
    %c17 = arith.constant 17 : index
    %c16 = arith.constant 16 : index
    %c15 = arith.constant 15 : index
    %c14 = arith.constant 14 : index
    %c13 = arith.constant 13 : index
    %c12 = arith.constant 12 : index
    %c11 = arith.constant 11 : index
    %c10 = arith.constant 10 : index
    %c9 = arith.constant 9 : index
    %c8 = arith.constant 8 : index
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c23 = arith.constant 23 : index
    %c0 = arith.constant 0 : index
    %0 = qco.alloc : !qco.qubit
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<23>
    %2 = qco.x %0 : !qco.qubit -> !qco.qubit
    %3 = qtensor.alloc(%c23) {mqt.register_name = "query"} : tensor<23x!qco.qubit>
    %out_tensor, %result = qtensor.extract %3[%c0] : tensor<23x!qco.qubit>
    %4 = qco.h %result : !qco.qubit -> !qco.qubit
    %5 = qtensor.insert %4 into %out_tensor[%c0] : tensor<23x!qco.qubit>
    %out_tensor_0, %result_1 = qtensor.extract %5[%c1] : tensor<23x!qco.qubit>
    %6 = qco.h %result_1 : !qco.qubit -> !qco.qubit
    %7 = qtensor.insert %6 into %out_tensor_0[%c1] : tensor<23x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %7[%c2] : tensor<23x!qco.qubit>
    %8 = qco.h %result_3 : !qco.qubit -> !qco.qubit
    %9 = qtensor.insert %8 into %out_tensor_2[%c2] : tensor<23x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %9[%c3] : tensor<23x!qco.qubit>
    %10 = qco.h %result_5 : !qco.qubit -> !qco.qubit
    %11 = qtensor.insert %10 into %out_tensor_4[%c3] : tensor<23x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %11[%c4] : tensor<23x!qco.qubit>
    %12 = qco.h %result_7 : !qco.qubit -> !qco.qubit
    %13 = qtensor.insert %12 into %out_tensor_6[%c4] : tensor<23x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %13[%c5] : tensor<23x!qco.qubit>
    %14 = qco.h %result_9 : !qco.qubit -> !qco.qubit
    %15 = qtensor.insert %14 into %out_tensor_8[%c5] : tensor<23x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %15[%c6] : tensor<23x!qco.qubit>
    %16 = qco.h %result_11 : !qco.qubit -> !qco.qubit
    %17 = qtensor.insert %16 into %out_tensor_10[%c6] : tensor<23x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %17[%c7] : tensor<23x!qco.qubit>
    %18 = qco.h %result_13 : !qco.qubit -> !qco.qubit
    %19 = qtensor.insert %18 into %out_tensor_12[%c7] : tensor<23x!qco.qubit>
    %out_tensor_14, %result_15 = qtensor.extract %19[%c8] : tensor<23x!qco.qubit>
    %20 = qco.h %result_15 : !qco.qubit -> !qco.qubit
    %21 = qtensor.insert %20 into %out_tensor_14[%c8] : tensor<23x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %21[%c9] : tensor<23x!qco.qubit>
    %22 = qco.h %result_17 : !qco.qubit -> !qco.qubit
    %23 = qtensor.insert %22 into %out_tensor_16[%c9] : tensor<23x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %23[%c10] : tensor<23x!qco.qubit>
    %24 = qco.h %result_19 : !qco.qubit -> !qco.qubit
    %25 = qtensor.insert %24 into %out_tensor_18[%c10] : tensor<23x!qco.qubit>
    %out_tensor_20, %result_21 = qtensor.extract %25[%c11] : tensor<23x!qco.qubit>
    %26 = qco.h %result_21 : !qco.qubit -> !qco.qubit
    %27 = qtensor.insert %26 into %out_tensor_20[%c11] : tensor<23x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %27[%c12] : tensor<23x!qco.qubit>
    %28 = qco.h %result_23 : !qco.qubit -> !qco.qubit
    %29 = qtensor.insert %28 into %out_tensor_22[%c12] : tensor<23x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %29[%c13] : tensor<23x!qco.qubit>
    %30 = qco.h %result_25 : !qco.qubit -> !qco.qubit
    %31 = qtensor.insert %30 into %out_tensor_24[%c13] : tensor<23x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %31[%c14] : tensor<23x!qco.qubit>
    %32 = qco.h %result_27 : !qco.qubit -> !qco.qubit
    %33 = qtensor.insert %32 into %out_tensor_26[%c14] : tensor<23x!qco.qubit>
    %out_tensor_28, %result_29 = qtensor.extract %33[%c15] : tensor<23x!qco.qubit>
    %34 = qco.h %result_29 : !qco.qubit -> !qco.qubit
    %35 = qtensor.insert %34 into %out_tensor_28[%c15] : tensor<23x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %35[%c16] : tensor<23x!qco.qubit>
    %36 = qco.h %result_31 : !qco.qubit -> !qco.qubit
    %37 = qtensor.insert %36 into %out_tensor_30[%c16] : tensor<23x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %37[%c17] : tensor<23x!qco.qubit>
    %38 = qco.h %result_33 : !qco.qubit -> !qco.qubit
    %39 = qtensor.insert %38 into %out_tensor_32[%c17] : tensor<23x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %39[%c18] : tensor<23x!qco.qubit>
    %40 = qco.h %result_35 : !qco.qubit -> !qco.qubit
    %41 = qtensor.insert %40 into %out_tensor_34[%c18] : tensor<23x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %41[%c19] : tensor<23x!qco.qubit>
    %42 = qco.h %result_37 : !qco.qubit -> !qco.qubit
    %43 = qtensor.insert %42 into %out_tensor_36[%c19] : tensor<23x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %43[%c20] : tensor<23x!qco.qubit>
    %44 = qco.h %result_39 : !qco.qubit -> !qco.qubit
    %45 = qtensor.insert %44 into %out_tensor_38[%c20] : tensor<23x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %45[%c21] : tensor<23x!qco.qubit>
    %46 = qco.h %result_41 : !qco.qubit -> !qco.qubit
    %47 = qtensor.insert %46 into %out_tensor_40[%c21] : tensor<23x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %47[%c22] : tensor<23x!qco.qubit>
    %48 = qco.h %result_43 : !qco.qubit -> !qco.qubit
    %49 = qtensor.insert %48 into %out_tensor_42[%c22] : tensor<23x!qco.qubit>
    %linearResults:2 = qco.if %true args(%arg0 = %49, %arg1 = %2) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c0] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c0] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %49, %arg1 = %2) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_44:2 = qco.if %false args(%arg0 = %linearResults#0, %arg1 = %linearResults#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c1] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c1] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults#0, %arg1 = %linearResults#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_45:2 = qco.if %true args(%arg0 = %linearResults_44#0, %arg1 = %linearResults_44#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c2] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c2] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_44#0, %arg1 = %linearResults_44#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_46:2 = qco.if %false args(%arg0 = %linearResults_45#0, %arg1 = %linearResults_45#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c3] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c3] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_45#0, %arg1 = %linearResults_45#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_47:2 = qco.if %true args(%arg0 = %linearResults_46#0, %arg1 = %linearResults_46#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c4] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c4] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_46#0, %arg1 = %linearResults_46#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_48:2 = qco.if %false args(%arg0 = %linearResults_47#0, %arg1 = %linearResults_47#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c5] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c5] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_47#0, %arg1 = %linearResults_47#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_49:2 = qco.if %true args(%arg0 = %linearResults_48#0, %arg1 = %linearResults_48#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c6] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c6] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_48#0, %arg1 = %linearResults_48#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_50:2 = qco.if %false args(%arg0 = %linearResults_49#0, %arg1 = %linearResults_49#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c7] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c7] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_49#0, %arg1 = %linearResults_49#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_51:2 = qco.if %true args(%arg0 = %linearResults_50#0, %arg1 = %linearResults_50#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c8] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c8] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_50#0, %arg1 = %linearResults_50#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_52:2 = qco.if %false args(%arg0 = %linearResults_51#0, %arg1 = %linearResults_51#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c9] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c9] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_51#0, %arg1 = %linearResults_51#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_53:2 = qco.if %true args(%arg0 = %linearResults_52#0, %arg1 = %linearResults_52#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c10] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c10] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_52#0, %arg1 = %linearResults_52#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_54:2 = qco.if %false args(%arg0 = %linearResults_53#0, %arg1 = %linearResults_53#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c11] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c11] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_53#0, %arg1 = %linearResults_53#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_55:2 = qco.if %true args(%arg0 = %linearResults_54#0, %arg1 = %linearResults_54#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c12] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c12] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_54#0, %arg1 = %linearResults_54#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_56:2 = qco.if %false args(%arg0 = %linearResults_55#0, %arg1 = %linearResults_55#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c13] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c13] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_55#0, %arg1 = %linearResults_55#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_57:2 = qco.if %true args(%arg0 = %linearResults_56#0, %arg1 = %linearResults_56#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c14] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c14] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_56#0, %arg1 = %linearResults_56#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_58:2 = qco.if %false args(%arg0 = %linearResults_57#0, %arg1 = %linearResults_57#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c15] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c15] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_57#0, %arg1 = %linearResults_57#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_59:2 = qco.if %true args(%arg0 = %linearResults_58#0, %arg1 = %linearResults_58#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c16] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c16] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_58#0, %arg1 = %linearResults_58#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_60:2 = qco.if %false args(%arg0 = %linearResults_59#0, %arg1 = %linearResults_59#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c17] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c17] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_59#0, %arg1 = %linearResults_59#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_61:2 = qco.if %true args(%arg0 = %linearResults_60#0, %arg1 = %linearResults_60#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c18] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c18] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_60#0, %arg1 = %linearResults_60#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_62:2 = qco.if %false args(%arg0 = %linearResults_61#0, %arg1 = %linearResults_61#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c19] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c19] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_61#0, %arg1 = %linearResults_61#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_63:2 = qco.if %true args(%arg0 = %linearResults_62#0, %arg1 = %linearResults_62#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c20] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c20] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_62#0, %arg1 = %linearResults_62#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_64:2 = qco.if %false args(%arg0 = %linearResults_63#0, %arg1 = %linearResults_63#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c21] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c21] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_63#0, %arg1 = %linearResults_63#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %linearResults_65:2 = qco.if %true args(%arg0 = %linearResults_64#0, %arg1 = %linearResults_64#1) -> (tensor<23x!qco.qubit>, !qco.qubit) {
      %out_tensor_203, %result_204 = qtensor.extract %arg0[%c22] : tensor<23x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_204) targets (%arg2 = %arg1) {
        %120 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %120 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %119 = qtensor.insert %controls_out into %out_tensor_203[%c22] : tensor<23x!qco.qubit>
      qco.yield %119, %targets_out : tensor<23x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_64#0, %arg1 = %linearResults_64#1) {
      qco.yield %arg0, %arg1 : tensor<23x!qco.qubit>, !qco.qubit
    }
    %out_tensor_66, %result_67 = qtensor.extract %linearResults_65#0[%c0] : tensor<23x!qco.qubit>
    %50 = qco.h %result_67 : !qco.qubit -> !qco.qubit
    %51 = qtensor.insert %50 into %out_tensor_66[%c0] : tensor<23x!qco.qubit>
    %out_tensor_68, %result_69 = qtensor.extract %51[%c1] : tensor<23x!qco.qubit>
    %52 = qco.h %result_69 : !qco.qubit -> !qco.qubit
    %53 = qtensor.insert %52 into %out_tensor_68[%c1] : tensor<23x!qco.qubit>
    %out_tensor_70, %result_71 = qtensor.extract %53[%c2] : tensor<23x!qco.qubit>
    %54 = qco.h %result_71 : !qco.qubit -> !qco.qubit
    %55 = qtensor.insert %54 into %out_tensor_70[%c2] : tensor<23x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %55[%c3] : tensor<23x!qco.qubit>
    %56 = qco.h %result_73 : !qco.qubit -> !qco.qubit
    %57 = qtensor.insert %56 into %out_tensor_72[%c3] : tensor<23x!qco.qubit>
    %out_tensor_74, %result_75 = qtensor.extract %57[%c4] : tensor<23x!qco.qubit>
    %58 = qco.h %result_75 : !qco.qubit -> !qco.qubit
    %59 = qtensor.insert %58 into %out_tensor_74[%c4] : tensor<23x!qco.qubit>
    %out_tensor_76, %result_77 = qtensor.extract %59[%c5] : tensor<23x!qco.qubit>
    %60 = qco.h %result_77 : !qco.qubit -> !qco.qubit
    %61 = qtensor.insert %60 into %out_tensor_76[%c5] : tensor<23x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %61[%c6] : tensor<23x!qco.qubit>
    %62 = qco.h %result_79 : !qco.qubit -> !qco.qubit
    %63 = qtensor.insert %62 into %out_tensor_78[%c6] : tensor<23x!qco.qubit>
    %out_tensor_80, %result_81 = qtensor.extract %63[%c7] : tensor<23x!qco.qubit>
    %64 = qco.h %result_81 : !qco.qubit -> !qco.qubit
    %65 = qtensor.insert %64 into %out_tensor_80[%c7] : tensor<23x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %65[%c8] : tensor<23x!qco.qubit>
    %66 = qco.h %result_83 : !qco.qubit -> !qco.qubit
    %67 = qtensor.insert %66 into %out_tensor_82[%c8] : tensor<23x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %67[%c9] : tensor<23x!qco.qubit>
    %68 = qco.h %result_85 : !qco.qubit -> !qco.qubit
    %69 = qtensor.insert %68 into %out_tensor_84[%c9] : tensor<23x!qco.qubit>
    %out_tensor_86, %result_87 = qtensor.extract %69[%c10] : tensor<23x!qco.qubit>
    %70 = qco.h %result_87 : !qco.qubit -> !qco.qubit
    %71 = qtensor.insert %70 into %out_tensor_86[%c10] : tensor<23x!qco.qubit>
    %out_tensor_88, %result_89 = qtensor.extract %71[%c11] : tensor<23x!qco.qubit>
    %72 = qco.h %result_89 : !qco.qubit -> !qco.qubit
    %73 = qtensor.insert %72 into %out_tensor_88[%c11] : tensor<23x!qco.qubit>
    %out_tensor_90, %result_91 = qtensor.extract %73[%c12] : tensor<23x!qco.qubit>
    %74 = qco.h %result_91 : !qco.qubit -> !qco.qubit
    %75 = qtensor.insert %74 into %out_tensor_90[%c12] : tensor<23x!qco.qubit>
    %out_tensor_92, %result_93 = qtensor.extract %75[%c13] : tensor<23x!qco.qubit>
    %76 = qco.h %result_93 : !qco.qubit -> !qco.qubit
    %77 = qtensor.insert %76 into %out_tensor_92[%c13] : tensor<23x!qco.qubit>
    %out_tensor_94, %result_95 = qtensor.extract %77[%c14] : tensor<23x!qco.qubit>
    %78 = qco.h %result_95 : !qco.qubit -> !qco.qubit
    %79 = qtensor.insert %78 into %out_tensor_94[%c14] : tensor<23x!qco.qubit>
    %out_tensor_96, %result_97 = qtensor.extract %79[%c15] : tensor<23x!qco.qubit>
    %80 = qco.h %result_97 : !qco.qubit -> !qco.qubit
    %81 = qtensor.insert %80 into %out_tensor_96[%c15] : tensor<23x!qco.qubit>
    %out_tensor_98, %result_99 = qtensor.extract %81[%c16] : tensor<23x!qco.qubit>
    %82 = qco.h %result_99 : !qco.qubit -> !qco.qubit
    %83 = qtensor.insert %82 into %out_tensor_98[%c16] : tensor<23x!qco.qubit>
    %out_tensor_100, %result_101 = qtensor.extract %83[%c17] : tensor<23x!qco.qubit>
    %84 = qco.h %result_101 : !qco.qubit -> !qco.qubit
    %85 = qtensor.insert %84 into %out_tensor_100[%c17] : tensor<23x!qco.qubit>
    %out_tensor_102, %result_103 = qtensor.extract %85[%c18] : tensor<23x!qco.qubit>
    %86 = qco.h %result_103 : !qco.qubit -> !qco.qubit
    %87 = qtensor.insert %86 into %out_tensor_102[%c18] : tensor<23x!qco.qubit>
    %out_tensor_104, %result_105 = qtensor.extract %87[%c19] : tensor<23x!qco.qubit>
    %88 = qco.h %result_105 : !qco.qubit -> !qco.qubit
    %89 = qtensor.insert %88 into %out_tensor_104[%c19] : tensor<23x!qco.qubit>
    %out_tensor_106, %result_107 = qtensor.extract %89[%c20] : tensor<23x!qco.qubit>
    %90 = qco.h %result_107 : !qco.qubit -> !qco.qubit
    %91 = qtensor.insert %90 into %out_tensor_106[%c20] : tensor<23x!qco.qubit>
    %out_tensor_108, %result_109 = qtensor.extract %91[%c21] : tensor<23x!qco.qubit>
    %92 = qco.h %result_109 : !qco.qubit -> !qco.qubit
    %93 = qtensor.insert %92 into %out_tensor_108[%c21] : tensor<23x!qco.qubit>
    %out_tensor_110, %result_111 = qtensor.extract %93[%c22] : tensor<23x!qco.qubit>
    %94 = qco.h %result_111 : !qco.qubit -> !qco.qubit
    %95 = qtensor.insert %94 into %out_tensor_110[%c22] : tensor<23x!qco.qubit>
    %out_tensor_112, %result_113 = qtensor.extract %95[%c0] : tensor<23x!qco.qubit>
    %qubit_out, %result_114 = qco.measure %result_113 : !qco.qubit
    %96 = qtensor.insert %qubit_out into %out_tensor_112[%c0] : tensor<23x!qco.qubit>
    cbit.store %result_114, %1[%c0] : !cbit.reg<23>
    %out_tensor_115, %result_116 = qtensor.extract %96[%c1] : tensor<23x!qco.qubit>
    %qubit_out_117, %result_118 = qco.measure %result_116 : !qco.qubit
    %97 = qtensor.insert %qubit_out_117 into %out_tensor_115[%c1] : tensor<23x!qco.qubit>
    cbit.store %result_118, %1[%c1] : !cbit.reg<23>
    %out_tensor_119, %result_120 = qtensor.extract %97[%c2] : tensor<23x!qco.qubit>
    %qubit_out_121, %result_122 = qco.measure %result_120 : !qco.qubit
    %98 = qtensor.insert %qubit_out_121 into %out_tensor_119[%c2] : tensor<23x!qco.qubit>
    cbit.store %result_122, %1[%c2] : !cbit.reg<23>
    %out_tensor_123, %result_124 = qtensor.extract %98[%c3] : tensor<23x!qco.qubit>
    %qubit_out_125, %result_126 = qco.measure %result_124 : !qco.qubit
    %99 = qtensor.insert %qubit_out_125 into %out_tensor_123[%c3] : tensor<23x!qco.qubit>
    cbit.store %result_126, %1[%c3] : !cbit.reg<23>
    %out_tensor_127, %result_128 = qtensor.extract %99[%c4] : tensor<23x!qco.qubit>
    %qubit_out_129, %result_130 = qco.measure %result_128 : !qco.qubit
    %100 = qtensor.insert %qubit_out_129 into %out_tensor_127[%c4] : tensor<23x!qco.qubit>
    cbit.store %result_130, %1[%c4] : !cbit.reg<23>
    %out_tensor_131, %result_132 = qtensor.extract %100[%c5] : tensor<23x!qco.qubit>
    %qubit_out_133, %result_134 = qco.measure %result_132 : !qco.qubit
    %101 = qtensor.insert %qubit_out_133 into %out_tensor_131[%c5] : tensor<23x!qco.qubit>
    cbit.store %result_134, %1[%c5] : !cbit.reg<23>
    %out_tensor_135, %result_136 = qtensor.extract %101[%c6] : tensor<23x!qco.qubit>
    %qubit_out_137, %result_138 = qco.measure %result_136 : !qco.qubit
    %102 = qtensor.insert %qubit_out_137 into %out_tensor_135[%c6] : tensor<23x!qco.qubit>
    cbit.store %result_138, %1[%c6] : !cbit.reg<23>
    %out_tensor_139, %result_140 = qtensor.extract %102[%c7] : tensor<23x!qco.qubit>
    %qubit_out_141, %result_142 = qco.measure %result_140 : !qco.qubit
    %103 = qtensor.insert %qubit_out_141 into %out_tensor_139[%c7] : tensor<23x!qco.qubit>
    cbit.store %result_142, %1[%c7] : !cbit.reg<23>
    %out_tensor_143, %result_144 = qtensor.extract %103[%c8] : tensor<23x!qco.qubit>
    %qubit_out_145, %result_146 = qco.measure %result_144 : !qco.qubit
    %104 = qtensor.insert %qubit_out_145 into %out_tensor_143[%c8] : tensor<23x!qco.qubit>
    cbit.store %result_146, %1[%c8] : !cbit.reg<23>
    %out_tensor_147, %result_148 = qtensor.extract %104[%c9] : tensor<23x!qco.qubit>
    %qubit_out_149, %result_150 = qco.measure %result_148 : !qco.qubit
    %105 = qtensor.insert %qubit_out_149 into %out_tensor_147[%c9] : tensor<23x!qco.qubit>
    cbit.store %result_150, %1[%c9] : !cbit.reg<23>
    %out_tensor_151, %result_152 = qtensor.extract %105[%c10] : tensor<23x!qco.qubit>
    %qubit_out_153, %result_154 = qco.measure %result_152 : !qco.qubit
    %106 = qtensor.insert %qubit_out_153 into %out_tensor_151[%c10] : tensor<23x!qco.qubit>
    cbit.store %result_154, %1[%c10] : !cbit.reg<23>
    %out_tensor_155, %result_156 = qtensor.extract %106[%c11] : tensor<23x!qco.qubit>
    %qubit_out_157, %result_158 = qco.measure %result_156 : !qco.qubit
    %107 = qtensor.insert %qubit_out_157 into %out_tensor_155[%c11] : tensor<23x!qco.qubit>
    cbit.store %result_158, %1[%c11] : !cbit.reg<23>
    %out_tensor_159, %result_160 = qtensor.extract %107[%c12] : tensor<23x!qco.qubit>
    %qubit_out_161, %result_162 = qco.measure %result_160 : !qco.qubit
    %108 = qtensor.insert %qubit_out_161 into %out_tensor_159[%c12] : tensor<23x!qco.qubit>
    cbit.store %result_162, %1[%c12] : !cbit.reg<23>
    %out_tensor_163, %result_164 = qtensor.extract %108[%c13] : tensor<23x!qco.qubit>
    %qubit_out_165, %result_166 = qco.measure %result_164 : !qco.qubit
    %109 = qtensor.insert %qubit_out_165 into %out_tensor_163[%c13] : tensor<23x!qco.qubit>
    cbit.store %result_166, %1[%c13] : !cbit.reg<23>
    %out_tensor_167, %result_168 = qtensor.extract %109[%c14] : tensor<23x!qco.qubit>
    %qubit_out_169, %result_170 = qco.measure %result_168 : !qco.qubit
    %110 = qtensor.insert %qubit_out_169 into %out_tensor_167[%c14] : tensor<23x!qco.qubit>
    cbit.store %result_170, %1[%c14] : !cbit.reg<23>
    %out_tensor_171, %result_172 = qtensor.extract %110[%c15] : tensor<23x!qco.qubit>
    %qubit_out_173, %result_174 = qco.measure %result_172 : !qco.qubit
    %111 = qtensor.insert %qubit_out_173 into %out_tensor_171[%c15] : tensor<23x!qco.qubit>
    cbit.store %result_174, %1[%c15] : !cbit.reg<23>
    %out_tensor_175, %result_176 = qtensor.extract %111[%c16] : tensor<23x!qco.qubit>
    %qubit_out_177, %result_178 = qco.measure %result_176 : !qco.qubit
    %112 = qtensor.insert %qubit_out_177 into %out_tensor_175[%c16] : tensor<23x!qco.qubit>
    cbit.store %result_178, %1[%c16] : !cbit.reg<23>
    %out_tensor_179, %result_180 = qtensor.extract %112[%c17] : tensor<23x!qco.qubit>
    %qubit_out_181, %result_182 = qco.measure %result_180 : !qco.qubit
    %113 = qtensor.insert %qubit_out_181 into %out_tensor_179[%c17] : tensor<23x!qco.qubit>
    cbit.store %result_182, %1[%c17] : !cbit.reg<23>
    %out_tensor_183, %result_184 = qtensor.extract %113[%c18] : tensor<23x!qco.qubit>
    %qubit_out_185, %result_186 = qco.measure %result_184 : !qco.qubit
    %114 = qtensor.insert %qubit_out_185 into %out_tensor_183[%c18] : tensor<23x!qco.qubit>
    cbit.store %result_186, %1[%c18] : !cbit.reg<23>
    %out_tensor_187, %result_188 = qtensor.extract %114[%c19] : tensor<23x!qco.qubit>
    %qubit_out_189, %result_190 = qco.measure %result_188 : !qco.qubit
    %115 = qtensor.insert %qubit_out_189 into %out_tensor_187[%c19] : tensor<23x!qco.qubit>
    cbit.store %result_190, %1[%c19] : !cbit.reg<23>
    %out_tensor_191, %result_192 = qtensor.extract %115[%c20] : tensor<23x!qco.qubit>
    %qubit_out_193, %result_194 = qco.measure %result_192 : !qco.qubit
    %116 = qtensor.insert %qubit_out_193 into %out_tensor_191[%c20] : tensor<23x!qco.qubit>
    cbit.store %result_194, %1[%c20] : !cbit.reg<23>
    %out_tensor_195, %result_196 = qtensor.extract %116[%c21] : tensor<23x!qco.qubit>
    %qubit_out_197, %result_198 = qco.measure %result_196 : !qco.qubit
    %117 = qtensor.insert %qubit_out_197 into %out_tensor_195[%c21] : tensor<23x!qco.qubit>
    cbit.store %result_198, %1[%c21] : !cbit.reg<23>
    %out_tensor_199, %result_200 = qtensor.extract %117[%c22] : tensor<23x!qco.qubit>
    %qubit_out_201, %result_202 = qco.measure %result_200 : !qco.qubit
    %118 = qtensor.insert %qubit_out_201 into %out_tensor_199[%c22] : tensor<23x!qco.qubit>
    cbit.store %result_202, %1[%c22] : !cbit.reg<23>
    qco.sink %linearResults_65#1 : !qco.qubit
    qtensor.dealloc %118 : tensor<23x!qco.qubit>
    return %1 : !cbit.reg<23>
  }
}
