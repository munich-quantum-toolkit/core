module {
  func.func @main() -> !cbit.reg<24> attributes {mqt.entry_point} {
    %c23 = arith.constant 23 : index
    %c22 = arith.constant 22 : index
    %c21 = arith.constant 21 : index
    %c20 = arith.constant 20 : index
    %c19 = arith.constant 19 : index
    %c18 = arith.constant 18 : index
    %c17 = arith.constant 17 : index
    %c16 = arith.constant 16 : index
    %c15 = arith.constant 15 : index
    %c14 = arith.constant 14 : index
    %c13 = arith.constant 13 : index
    %c12 = arith.constant 12 : index
    %c11 = arith.constant 11 : index
    %c10 = arith.constant 10 : index
    %c9 = arith.constant 9 : index
    %c8 = arith.constant 8 : index
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c24 = arith.constant 24 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %0 = qtensor.alloc(%c24) {mqt.register_name = "q"} : tensor<24x!qco.qubit>
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<24>
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<24x!qco.qubit>
    %2 = qco.h %result : !qco.qubit -> !qco.qubit
    %3 = qtensor.insert %2 into %out_tensor[%c0] : tensor<24x!qco.qubit>
    %out_tensor_0, %result_1 = qtensor.extract %3[%c0] : tensor<24x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %out_tensor_0[%c1] : tensor<24x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_1) targets (%arg0 = %result_3) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %4 = qtensor.insert %targets_out into %out_tensor_2[%c1] : tensor<24x!qco.qubit>
    %5 = qtensor.insert %controls_out into %4[%c0] : tensor<24x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %5[%c1] : tensor<24x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %out_tensor_4[%c2] : tensor<24x!qco.qubit>
    %controls_out_8, %targets_out_9 = qco.ctrl(%result_5) targets (%arg0 = %result_7) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %6 = qtensor.insert %targets_out_9 into %out_tensor_6[%c2] : tensor<24x!qco.qubit>
    %7 = qtensor.insert %controls_out_8 into %6[%c1] : tensor<24x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %7[%c2] : tensor<24x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %out_tensor_10[%c3] : tensor<24x!qco.qubit>
    %controls_out_14, %targets_out_15 = qco.ctrl(%result_11) targets (%arg0 = %result_13) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %8 = qtensor.insert %targets_out_15 into %out_tensor_12[%c3] : tensor<24x!qco.qubit>
    %9 = qtensor.insert %controls_out_14 into %8[%c2] : tensor<24x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %9[%c3] : tensor<24x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %out_tensor_16[%c4] : tensor<24x!qco.qubit>
    %controls_out_20, %targets_out_21 = qco.ctrl(%result_17) targets (%arg0 = %result_19) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %10 = qtensor.insert %targets_out_21 into %out_tensor_18[%c4] : tensor<24x!qco.qubit>
    %11 = qtensor.insert %controls_out_20 into %10[%c3] : tensor<24x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %11[%c4] : tensor<24x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %out_tensor_22[%c5] : tensor<24x!qco.qubit>
    %controls_out_26, %targets_out_27 = qco.ctrl(%result_23) targets (%arg0 = %result_25) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qtensor.insert %targets_out_27 into %out_tensor_24[%c5] : tensor<24x!qco.qubit>
    %13 = qtensor.insert %controls_out_26 into %12[%c4] : tensor<24x!qco.qubit>
    %out_tensor_28, %result_29 = qtensor.extract %13[%c5] : tensor<24x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %out_tensor_28[%c6] : tensor<24x!qco.qubit>
    %controls_out_32, %targets_out_33 = qco.ctrl(%result_29) targets (%arg0 = %result_31) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qtensor.insert %targets_out_33 into %out_tensor_30[%c6] : tensor<24x!qco.qubit>
    %15 = qtensor.insert %controls_out_32 into %14[%c5] : tensor<24x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %15[%c6] : tensor<24x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %out_tensor_34[%c7] : tensor<24x!qco.qubit>
    %controls_out_38, %targets_out_39 = qco.ctrl(%result_35) targets (%arg0 = %result_37) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qtensor.insert %targets_out_39 into %out_tensor_36[%c7] : tensor<24x!qco.qubit>
    %17 = qtensor.insert %controls_out_38 into %16[%c6] : tensor<24x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %17[%c7] : tensor<24x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %out_tensor_40[%c8] : tensor<24x!qco.qubit>
    %controls_out_44, %targets_out_45 = qco.ctrl(%result_41) targets (%arg0 = %result_43) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qtensor.insert %targets_out_45 into %out_tensor_42[%c8] : tensor<24x!qco.qubit>
    %19 = qtensor.insert %controls_out_44 into %18[%c7] : tensor<24x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %19[%c8] : tensor<24x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %out_tensor_46[%c9] : tensor<24x!qco.qubit>
    %controls_out_50, %targets_out_51 = qco.ctrl(%result_47) targets (%arg0 = %result_49) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qtensor.insert %targets_out_51 into %out_tensor_48[%c9] : tensor<24x!qco.qubit>
    %21 = qtensor.insert %controls_out_50 into %20[%c8] : tensor<24x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %21[%c9] : tensor<24x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %out_tensor_52[%c10] : tensor<24x!qco.qubit>
    %controls_out_56, %targets_out_57 = qco.ctrl(%result_53) targets (%arg0 = %result_55) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qtensor.insert %targets_out_57 into %out_tensor_54[%c10] : tensor<24x!qco.qubit>
    %23 = qtensor.insert %controls_out_56 into %22[%c9] : tensor<24x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %23[%c10] : tensor<24x!qco.qubit>
    %out_tensor_60, %result_61 = qtensor.extract %out_tensor_58[%c11] : tensor<24x!qco.qubit>
    %controls_out_62, %targets_out_63 = qco.ctrl(%result_59) targets (%arg0 = %result_61) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qtensor.insert %targets_out_63 into %out_tensor_60[%c11] : tensor<24x!qco.qubit>
    %25 = qtensor.insert %controls_out_62 into %24[%c10] : tensor<24x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %25[%c11] : tensor<24x!qco.qubit>
    %out_tensor_66, %result_67 = qtensor.extract %out_tensor_64[%c12] : tensor<24x!qco.qubit>
    %controls_out_68, %targets_out_69 = qco.ctrl(%result_65) targets (%arg0 = %result_67) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qtensor.insert %targets_out_69 into %out_tensor_66[%c12] : tensor<24x!qco.qubit>
    %27 = qtensor.insert %controls_out_68 into %26[%c11] : tensor<24x!qco.qubit>
    %out_tensor_70, %result_71 = qtensor.extract %27[%c12] : tensor<24x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %out_tensor_70[%c13] : tensor<24x!qco.qubit>
    %controls_out_74, %targets_out_75 = qco.ctrl(%result_71) targets (%arg0 = %result_73) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qtensor.insert %targets_out_75 into %out_tensor_72[%c13] : tensor<24x!qco.qubit>
    %29 = qtensor.insert %controls_out_74 into %28[%c12] : tensor<24x!qco.qubit>
    %out_tensor_76, %result_77 = qtensor.extract %29[%c13] : tensor<24x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %out_tensor_76[%c14] : tensor<24x!qco.qubit>
    %controls_out_80, %targets_out_81 = qco.ctrl(%result_77) targets (%arg0 = %result_79) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qtensor.insert %targets_out_81 into %out_tensor_78[%c14] : tensor<24x!qco.qubit>
    %31 = qtensor.insert %controls_out_80 into %30[%c13] : tensor<24x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %31[%c14] : tensor<24x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %out_tensor_82[%c15] : tensor<24x!qco.qubit>
    %controls_out_86, %targets_out_87 = qco.ctrl(%result_83) targets (%arg0 = %result_85) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qtensor.insert %targets_out_87 into %out_tensor_84[%c15] : tensor<24x!qco.qubit>
    %33 = qtensor.insert %controls_out_86 into %32[%c14] : tensor<24x!qco.qubit>
    %out_tensor_88, %result_89 = qtensor.extract %33[%c15] : tensor<24x!qco.qubit>
    %out_tensor_90, %result_91 = qtensor.extract %out_tensor_88[%c16] : tensor<24x!qco.qubit>
    %controls_out_92, %targets_out_93 = qco.ctrl(%result_89) targets (%arg0 = %result_91) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qtensor.insert %targets_out_93 into %out_tensor_90[%c16] : tensor<24x!qco.qubit>
    %35 = qtensor.insert %controls_out_92 into %34[%c15] : tensor<24x!qco.qubit>
    %out_tensor_94, %result_95 = qtensor.extract %35[%c16] : tensor<24x!qco.qubit>
    %out_tensor_96, %result_97 = qtensor.extract %out_tensor_94[%c17] : tensor<24x!qco.qubit>
    %controls_out_98, %targets_out_99 = qco.ctrl(%result_95) targets (%arg0 = %result_97) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qtensor.insert %targets_out_99 into %out_tensor_96[%c17] : tensor<24x!qco.qubit>
    %37 = qtensor.insert %controls_out_98 into %36[%c16] : tensor<24x!qco.qubit>
    %out_tensor_100, %result_101 = qtensor.extract %37[%c17] : tensor<24x!qco.qubit>
    %out_tensor_102, %result_103 = qtensor.extract %out_tensor_100[%c18] : tensor<24x!qco.qubit>
    %controls_out_104, %targets_out_105 = qco.ctrl(%result_101) targets (%arg0 = %result_103) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qtensor.insert %targets_out_105 into %out_tensor_102[%c18] : tensor<24x!qco.qubit>
    %39 = qtensor.insert %controls_out_104 into %38[%c17] : tensor<24x!qco.qubit>
    %out_tensor_106, %result_107 = qtensor.extract %39[%c18] : tensor<24x!qco.qubit>
    %out_tensor_108, %result_109 = qtensor.extract %out_tensor_106[%c19] : tensor<24x!qco.qubit>
    %controls_out_110, %targets_out_111 = qco.ctrl(%result_107) targets (%arg0 = %result_109) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %40 = qtensor.insert %targets_out_111 into %out_tensor_108[%c19] : tensor<24x!qco.qubit>
    %41 = qtensor.insert %controls_out_110 into %40[%c18] : tensor<24x!qco.qubit>
    %out_tensor_112, %result_113 = qtensor.extract %41[%c19] : tensor<24x!qco.qubit>
    %out_tensor_114, %result_115 = qtensor.extract %out_tensor_112[%c20] : tensor<24x!qco.qubit>
    %controls_out_116, %targets_out_117 = qco.ctrl(%result_113) targets (%arg0 = %result_115) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qtensor.insert %targets_out_117 into %out_tensor_114[%c20] : tensor<24x!qco.qubit>
    %43 = qtensor.insert %controls_out_116 into %42[%c19] : tensor<24x!qco.qubit>
    %out_tensor_118, %result_119 = qtensor.extract %43[%c20] : tensor<24x!qco.qubit>
    %out_tensor_120, %result_121 = qtensor.extract %out_tensor_118[%c21] : tensor<24x!qco.qubit>
    %controls_out_122, %targets_out_123 = qco.ctrl(%result_119) targets (%arg0 = %result_121) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = qtensor.insert %targets_out_123 into %out_tensor_120[%c21] : tensor<24x!qco.qubit>
    %45 = qtensor.insert %controls_out_122 into %44[%c20] : tensor<24x!qco.qubit>
    %out_tensor_124, %result_125 = qtensor.extract %45[%c21] : tensor<24x!qco.qubit>
    %out_tensor_126, %result_127 = qtensor.extract %out_tensor_124[%c22] : tensor<24x!qco.qubit>
    %controls_out_128, %targets_out_129 = qco.ctrl(%result_125) targets (%arg0 = %result_127) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qtensor.insert %targets_out_129 into %out_tensor_126[%c22] : tensor<24x!qco.qubit>
    %47 = qtensor.insert %controls_out_128 into %46[%c21] : tensor<24x!qco.qubit>
    %out_tensor_130, %result_131 = qtensor.extract %47[%c22] : tensor<24x!qco.qubit>
    %out_tensor_132, %result_133 = qtensor.extract %out_tensor_130[%c23] : tensor<24x!qco.qubit>
    %controls_out_134, %targets_out_135 = qco.ctrl(%result_131) targets (%arg0 = %result_133) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %48 = qtensor.insert %targets_out_135 into %out_tensor_132[%c23] : tensor<24x!qco.qubit>
    %49 = qtensor.insert %controls_out_134 into %48[%c22] : tensor<24x!qco.qubit>
    %out_tensor_136, %result_137 = qtensor.extract %49[%c0] : tensor<24x!qco.qubit>
    %qubit_out, %result_138 = qco.measure %result_137 : !qco.qubit
    %50 = qtensor.insert %qubit_out into %out_tensor_136[%c0] : tensor<24x!qco.qubit>
    cbit.store %result_138, %1[%c0] : !cbit.reg<24>
    %out_tensor_139, %result_140 = qtensor.extract %50[%c1] : tensor<24x!qco.qubit>
    %qubit_out_141, %result_142 = qco.measure %result_140 : !qco.qubit
    %51 = qtensor.insert %qubit_out_141 into %out_tensor_139[%c1] : tensor<24x!qco.qubit>
    cbit.store %result_142, %1[%c1] : !cbit.reg<24>
    %out_tensor_143, %result_144 = qtensor.extract %51[%c2] : tensor<24x!qco.qubit>
    %qubit_out_145, %result_146 = qco.measure %result_144 : !qco.qubit
    %52 = qtensor.insert %qubit_out_145 into %out_tensor_143[%c2] : tensor<24x!qco.qubit>
    cbit.store %result_146, %1[%c2] : !cbit.reg<24>
    %out_tensor_147, %result_148 = qtensor.extract %52[%c3] : tensor<24x!qco.qubit>
    %qubit_out_149, %result_150 = qco.measure %result_148 : !qco.qubit
    %53 = qtensor.insert %qubit_out_149 into %out_tensor_147[%c3] : tensor<24x!qco.qubit>
    cbit.store %result_150, %1[%c3] : !cbit.reg<24>
    %out_tensor_151, %result_152 = qtensor.extract %53[%c4] : tensor<24x!qco.qubit>
    %qubit_out_153, %result_154 = qco.measure %result_152 : !qco.qubit
    %54 = qtensor.insert %qubit_out_153 into %out_tensor_151[%c4] : tensor<24x!qco.qubit>
    cbit.store %result_154, %1[%c4] : !cbit.reg<24>
    %out_tensor_155, %result_156 = qtensor.extract %54[%c5] : tensor<24x!qco.qubit>
    %qubit_out_157, %result_158 = qco.measure %result_156 : !qco.qubit
    %55 = qtensor.insert %qubit_out_157 into %out_tensor_155[%c5] : tensor<24x!qco.qubit>
    cbit.store %result_158, %1[%c5] : !cbit.reg<24>
    %out_tensor_159, %result_160 = qtensor.extract %55[%c6] : tensor<24x!qco.qubit>
    %qubit_out_161, %result_162 = qco.measure %result_160 : !qco.qubit
    %56 = qtensor.insert %qubit_out_161 into %out_tensor_159[%c6] : tensor<24x!qco.qubit>
    cbit.store %result_162, %1[%c6] : !cbit.reg<24>
    %out_tensor_163, %result_164 = qtensor.extract %56[%c7] : tensor<24x!qco.qubit>
    %qubit_out_165, %result_166 = qco.measure %result_164 : !qco.qubit
    %57 = qtensor.insert %qubit_out_165 into %out_tensor_163[%c7] : tensor<24x!qco.qubit>
    cbit.store %result_166, %1[%c7] : !cbit.reg<24>
    %out_tensor_167, %result_168 = qtensor.extract %57[%c8] : tensor<24x!qco.qubit>
    %qubit_out_169, %result_170 = qco.measure %result_168 : !qco.qubit
    %58 = qtensor.insert %qubit_out_169 into %out_tensor_167[%c8] : tensor<24x!qco.qubit>
    cbit.store %result_170, %1[%c8] : !cbit.reg<24>
    %out_tensor_171, %result_172 = qtensor.extract %58[%c9] : tensor<24x!qco.qubit>
    %qubit_out_173, %result_174 = qco.measure %result_172 : !qco.qubit
    %59 = qtensor.insert %qubit_out_173 into %out_tensor_171[%c9] : tensor<24x!qco.qubit>
    cbit.store %result_174, %1[%c9] : !cbit.reg<24>
    %out_tensor_175, %result_176 = qtensor.extract %59[%c10] : tensor<24x!qco.qubit>
    %qubit_out_177, %result_178 = qco.measure %result_176 : !qco.qubit
    %60 = qtensor.insert %qubit_out_177 into %out_tensor_175[%c10] : tensor<24x!qco.qubit>
    cbit.store %result_178, %1[%c10] : !cbit.reg<24>
    %out_tensor_179, %result_180 = qtensor.extract %60[%c11] : tensor<24x!qco.qubit>
    %qubit_out_181, %result_182 = qco.measure %result_180 : !qco.qubit
    %61 = qtensor.insert %qubit_out_181 into %out_tensor_179[%c11] : tensor<24x!qco.qubit>
    cbit.store %result_182, %1[%c11] : !cbit.reg<24>
    %out_tensor_183, %result_184 = qtensor.extract %61[%c12] : tensor<24x!qco.qubit>
    %qubit_out_185, %result_186 = qco.measure %result_184 : !qco.qubit
    %62 = qtensor.insert %qubit_out_185 into %out_tensor_183[%c12] : tensor<24x!qco.qubit>
    cbit.store %result_186, %1[%c12] : !cbit.reg<24>
    %out_tensor_187, %result_188 = qtensor.extract %62[%c13] : tensor<24x!qco.qubit>
    %qubit_out_189, %result_190 = qco.measure %result_188 : !qco.qubit
    %63 = qtensor.insert %qubit_out_189 into %out_tensor_187[%c13] : tensor<24x!qco.qubit>
    cbit.store %result_190, %1[%c13] : !cbit.reg<24>
    %out_tensor_191, %result_192 = qtensor.extract %63[%c14] : tensor<24x!qco.qubit>
    %qubit_out_193, %result_194 = qco.measure %result_192 : !qco.qubit
    %64 = qtensor.insert %qubit_out_193 into %out_tensor_191[%c14] : tensor<24x!qco.qubit>
    cbit.store %result_194, %1[%c14] : !cbit.reg<24>
    %out_tensor_195, %result_196 = qtensor.extract %64[%c15] : tensor<24x!qco.qubit>
    %qubit_out_197, %result_198 = qco.measure %result_196 : !qco.qubit
    %65 = qtensor.insert %qubit_out_197 into %out_tensor_195[%c15] : tensor<24x!qco.qubit>
    cbit.store %result_198, %1[%c15] : !cbit.reg<24>
    %out_tensor_199, %result_200 = qtensor.extract %65[%c16] : tensor<24x!qco.qubit>
    %qubit_out_201, %result_202 = qco.measure %result_200 : !qco.qubit
    %66 = qtensor.insert %qubit_out_201 into %out_tensor_199[%c16] : tensor<24x!qco.qubit>
    cbit.store %result_202, %1[%c16] : !cbit.reg<24>
    %out_tensor_203, %result_204 = qtensor.extract %66[%c17] : tensor<24x!qco.qubit>
    %qubit_out_205, %result_206 = qco.measure %result_204 : !qco.qubit
    %67 = qtensor.insert %qubit_out_205 into %out_tensor_203[%c17] : tensor<24x!qco.qubit>
    cbit.store %result_206, %1[%c17] : !cbit.reg<24>
    %out_tensor_207, %result_208 = qtensor.extract %67[%c18] : tensor<24x!qco.qubit>
    %qubit_out_209, %result_210 = qco.measure %result_208 : !qco.qubit
    %68 = qtensor.insert %qubit_out_209 into %out_tensor_207[%c18] : tensor<24x!qco.qubit>
    cbit.store %result_210, %1[%c18] : !cbit.reg<24>
    %out_tensor_211, %result_212 = qtensor.extract %68[%c19] : tensor<24x!qco.qubit>
    %qubit_out_213, %result_214 = qco.measure %result_212 : !qco.qubit
    %69 = qtensor.insert %qubit_out_213 into %out_tensor_211[%c19] : tensor<24x!qco.qubit>
    cbit.store %result_214, %1[%c19] : !cbit.reg<24>
    %out_tensor_215, %result_216 = qtensor.extract %69[%c20] : tensor<24x!qco.qubit>
    %qubit_out_217, %result_218 = qco.measure %result_216 : !qco.qubit
    %70 = qtensor.insert %qubit_out_217 into %out_tensor_215[%c20] : tensor<24x!qco.qubit>
    cbit.store %result_218, %1[%c20] : !cbit.reg<24>
    %out_tensor_219, %result_220 = qtensor.extract %70[%c21] : tensor<24x!qco.qubit>
    %qubit_out_221, %result_222 = qco.measure %result_220 : !qco.qubit
    %71 = qtensor.insert %qubit_out_221 into %out_tensor_219[%c21] : tensor<24x!qco.qubit>
    cbit.store %result_222, %1[%c21] : !cbit.reg<24>
    %out_tensor_223, %result_224 = qtensor.extract %71[%c22] : tensor<24x!qco.qubit>
    %qubit_out_225, %result_226 = qco.measure %result_224 : !qco.qubit
    %72 = qtensor.insert %qubit_out_225 into %out_tensor_223[%c22] : tensor<24x!qco.qubit>
    cbit.store %result_226, %1[%c22] : !cbit.reg<24>
    %out_tensor_227, %result_228 = qtensor.extract %72[%c23] : tensor<24x!qco.qubit>
    %qubit_out_229, %result_230 = qco.measure %result_228 : !qco.qubit
    %73 = qtensor.insert %qubit_out_229 into %out_tensor_227[%c23] : tensor<24x!qco.qubit>
    cbit.store %result_230, %1[%c23] : !cbit.reg<24>
    qtensor.dealloc %73 : tensor<24x!qco.qubit>
    return %1 : !cbit.reg<24>
  }
}
