module {
  func.func @main() -> !cbit.reg<36> attributes {mqt.entry_point} {
    %c35 = arith.constant 35 : index
    %c34 = arith.constant 34 : index
    %c33 = arith.constant 33 : index
    %c32 = arith.constant 32 : index
    %c31 = arith.constant 31 : index
    %c30 = arith.constant 30 : index
    %c29 = arith.constant 29 : index
    %c28 = arith.constant 28 : index
    %c27 = arith.constant 27 : index
    %c26 = arith.constant 26 : index
    %c25 = arith.constant 25 : index
    %c24 = arith.constant 24 : index
    %c23 = arith.constant 23 : index
    %c22 = arith.constant 22 : index
    %c21 = arith.constant 21 : index
    %c20 = arith.constant 20 : index
    %c19 = arith.constant 19 : index
    %c18 = arith.constant 18 : index
    %c17 = arith.constant 17 : index
    %c16 = arith.constant 16 : index
    %c15 = arith.constant 15 : index
    %c14 = arith.constant 14 : index
    %c13 = arith.constant 13 : index
    %c12 = arith.constant 12 : index
    %c11 = arith.constant 11 : index
    %c10 = arith.constant 10 : index
    %c9 = arith.constant 9 : index
    %c8 = arith.constant 8 : index
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c36 = arith.constant 36 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %0 = qtensor.alloc(%c36) {mqt.register_name = "q"} : tensor<36x!qco.qubit>
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<36>
    %out_tensor, %result = qtensor.extract %0[%c0] : tensor<36x!qco.qubit>
    %2 = qco.h %result : !qco.qubit -> !qco.qubit
    %3 = qtensor.insert %2 into %out_tensor[%c0] : tensor<36x!qco.qubit>
    %out_tensor_0, %result_1 = qtensor.extract %3[%c0] : tensor<36x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %out_tensor_0[%c1] : tensor<36x!qco.qubit>
    %controls_out, %targets_out = qco.ctrl(%result_1) targets (%arg0 = %result_3) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %4 = qtensor.insert %targets_out into %out_tensor_2[%c1] : tensor<36x!qco.qubit>
    %5 = qtensor.insert %controls_out into %4[%c0] : tensor<36x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %5[%c1] : tensor<36x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %out_tensor_4[%c2] : tensor<36x!qco.qubit>
    %controls_out_8, %targets_out_9 = qco.ctrl(%result_5) targets (%arg0 = %result_7) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %6 = qtensor.insert %targets_out_9 into %out_tensor_6[%c2] : tensor<36x!qco.qubit>
    %7 = qtensor.insert %controls_out_8 into %6[%c1] : tensor<36x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %7[%c2] : tensor<36x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %out_tensor_10[%c3] : tensor<36x!qco.qubit>
    %controls_out_14, %targets_out_15 = qco.ctrl(%result_11) targets (%arg0 = %result_13) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %8 = qtensor.insert %targets_out_15 into %out_tensor_12[%c3] : tensor<36x!qco.qubit>
    %9 = qtensor.insert %controls_out_14 into %8[%c2] : tensor<36x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %9[%c3] : tensor<36x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %out_tensor_16[%c4] : tensor<36x!qco.qubit>
    %controls_out_20, %targets_out_21 = qco.ctrl(%result_17) targets (%arg0 = %result_19) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %10 = qtensor.insert %targets_out_21 into %out_tensor_18[%c4] : tensor<36x!qco.qubit>
    %11 = qtensor.insert %controls_out_20 into %10[%c3] : tensor<36x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %11[%c4] : tensor<36x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %out_tensor_22[%c5] : tensor<36x!qco.qubit>
    %controls_out_26, %targets_out_27 = qco.ctrl(%result_23) targets (%arg0 = %result_25) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qtensor.insert %targets_out_27 into %out_tensor_24[%c5] : tensor<36x!qco.qubit>
    %13 = qtensor.insert %controls_out_26 into %12[%c4] : tensor<36x!qco.qubit>
    %out_tensor_28, %result_29 = qtensor.extract %13[%c5] : tensor<36x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %out_tensor_28[%c6] : tensor<36x!qco.qubit>
    %controls_out_32, %targets_out_33 = qco.ctrl(%result_29) targets (%arg0 = %result_31) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qtensor.insert %targets_out_33 into %out_tensor_30[%c6] : tensor<36x!qco.qubit>
    %15 = qtensor.insert %controls_out_32 into %14[%c5] : tensor<36x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %15[%c6] : tensor<36x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %out_tensor_34[%c7] : tensor<36x!qco.qubit>
    %controls_out_38, %targets_out_39 = qco.ctrl(%result_35) targets (%arg0 = %result_37) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qtensor.insert %targets_out_39 into %out_tensor_36[%c7] : tensor<36x!qco.qubit>
    %17 = qtensor.insert %controls_out_38 into %16[%c6] : tensor<36x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %17[%c7] : tensor<36x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %out_tensor_40[%c8] : tensor<36x!qco.qubit>
    %controls_out_44, %targets_out_45 = qco.ctrl(%result_41) targets (%arg0 = %result_43) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qtensor.insert %targets_out_45 into %out_tensor_42[%c8] : tensor<36x!qco.qubit>
    %19 = qtensor.insert %controls_out_44 into %18[%c7] : tensor<36x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %19[%c8] : tensor<36x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %out_tensor_46[%c9] : tensor<36x!qco.qubit>
    %controls_out_50, %targets_out_51 = qco.ctrl(%result_47) targets (%arg0 = %result_49) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qtensor.insert %targets_out_51 into %out_tensor_48[%c9] : tensor<36x!qco.qubit>
    %21 = qtensor.insert %controls_out_50 into %20[%c8] : tensor<36x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %21[%c9] : tensor<36x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %out_tensor_52[%c10] : tensor<36x!qco.qubit>
    %controls_out_56, %targets_out_57 = qco.ctrl(%result_53) targets (%arg0 = %result_55) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qtensor.insert %targets_out_57 into %out_tensor_54[%c10] : tensor<36x!qco.qubit>
    %23 = qtensor.insert %controls_out_56 into %22[%c9] : tensor<36x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %23[%c10] : tensor<36x!qco.qubit>
    %out_tensor_60, %result_61 = qtensor.extract %out_tensor_58[%c11] : tensor<36x!qco.qubit>
    %controls_out_62, %targets_out_63 = qco.ctrl(%result_59) targets (%arg0 = %result_61) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qtensor.insert %targets_out_63 into %out_tensor_60[%c11] : tensor<36x!qco.qubit>
    %25 = qtensor.insert %controls_out_62 into %24[%c10] : tensor<36x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %25[%c11] : tensor<36x!qco.qubit>
    %out_tensor_66, %result_67 = qtensor.extract %out_tensor_64[%c12] : tensor<36x!qco.qubit>
    %controls_out_68, %targets_out_69 = qco.ctrl(%result_65) targets (%arg0 = %result_67) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qtensor.insert %targets_out_69 into %out_tensor_66[%c12] : tensor<36x!qco.qubit>
    %27 = qtensor.insert %controls_out_68 into %26[%c11] : tensor<36x!qco.qubit>
    %out_tensor_70, %result_71 = qtensor.extract %27[%c12] : tensor<36x!qco.qubit>
    %out_tensor_72, %result_73 = qtensor.extract %out_tensor_70[%c13] : tensor<36x!qco.qubit>
    %controls_out_74, %targets_out_75 = qco.ctrl(%result_71) targets (%arg0 = %result_73) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qtensor.insert %targets_out_75 into %out_tensor_72[%c13] : tensor<36x!qco.qubit>
    %29 = qtensor.insert %controls_out_74 into %28[%c12] : tensor<36x!qco.qubit>
    %out_tensor_76, %result_77 = qtensor.extract %29[%c13] : tensor<36x!qco.qubit>
    %out_tensor_78, %result_79 = qtensor.extract %out_tensor_76[%c14] : tensor<36x!qco.qubit>
    %controls_out_80, %targets_out_81 = qco.ctrl(%result_77) targets (%arg0 = %result_79) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qtensor.insert %targets_out_81 into %out_tensor_78[%c14] : tensor<36x!qco.qubit>
    %31 = qtensor.insert %controls_out_80 into %30[%c13] : tensor<36x!qco.qubit>
    %out_tensor_82, %result_83 = qtensor.extract %31[%c14] : tensor<36x!qco.qubit>
    %out_tensor_84, %result_85 = qtensor.extract %out_tensor_82[%c15] : tensor<36x!qco.qubit>
    %controls_out_86, %targets_out_87 = qco.ctrl(%result_83) targets (%arg0 = %result_85) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qtensor.insert %targets_out_87 into %out_tensor_84[%c15] : tensor<36x!qco.qubit>
    %33 = qtensor.insert %controls_out_86 into %32[%c14] : tensor<36x!qco.qubit>
    %out_tensor_88, %result_89 = qtensor.extract %33[%c15] : tensor<36x!qco.qubit>
    %out_tensor_90, %result_91 = qtensor.extract %out_tensor_88[%c16] : tensor<36x!qco.qubit>
    %controls_out_92, %targets_out_93 = qco.ctrl(%result_89) targets (%arg0 = %result_91) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qtensor.insert %targets_out_93 into %out_tensor_90[%c16] : tensor<36x!qco.qubit>
    %35 = qtensor.insert %controls_out_92 into %34[%c15] : tensor<36x!qco.qubit>
    %out_tensor_94, %result_95 = qtensor.extract %35[%c16] : tensor<36x!qco.qubit>
    %out_tensor_96, %result_97 = qtensor.extract %out_tensor_94[%c17] : tensor<36x!qco.qubit>
    %controls_out_98, %targets_out_99 = qco.ctrl(%result_95) targets (%arg0 = %result_97) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qtensor.insert %targets_out_99 into %out_tensor_96[%c17] : tensor<36x!qco.qubit>
    %37 = qtensor.insert %controls_out_98 into %36[%c16] : tensor<36x!qco.qubit>
    %out_tensor_100, %result_101 = qtensor.extract %37[%c17] : tensor<36x!qco.qubit>
    %out_tensor_102, %result_103 = qtensor.extract %out_tensor_100[%c18] : tensor<36x!qco.qubit>
    %controls_out_104, %targets_out_105 = qco.ctrl(%result_101) targets (%arg0 = %result_103) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qtensor.insert %targets_out_105 into %out_tensor_102[%c18] : tensor<36x!qco.qubit>
    %39 = qtensor.insert %controls_out_104 into %38[%c17] : tensor<36x!qco.qubit>
    %out_tensor_106, %result_107 = qtensor.extract %39[%c18] : tensor<36x!qco.qubit>
    %out_tensor_108, %result_109 = qtensor.extract %out_tensor_106[%c19] : tensor<36x!qco.qubit>
    %controls_out_110, %targets_out_111 = qco.ctrl(%result_107) targets (%arg0 = %result_109) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %40 = qtensor.insert %targets_out_111 into %out_tensor_108[%c19] : tensor<36x!qco.qubit>
    %41 = qtensor.insert %controls_out_110 into %40[%c18] : tensor<36x!qco.qubit>
    %out_tensor_112, %result_113 = qtensor.extract %41[%c19] : tensor<36x!qco.qubit>
    %out_tensor_114, %result_115 = qtensor.extract %out_tensor_112[%c20] : tensor<36x!qco.qubit>
    %controls_out_116, %targets_out_117 = qco.ctrl(%result_113) targets (%arg0 = %result_115) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qtensor.insert %targets_out_117 into %out_tensor_114[%c20] : tensor<36x!qco.qubit>
    %43 = qtensor.insert %controls_out_116 into %42[%c19] : tensor<36x!qco.qubit>
    %out_tensor_118, %result_119 = qtensor.extract %43[%c20] : tensor<36x!qco.qubit>
    %out_tensor_120, %result_121 = qtensor.extract %out_tensor_118[%c21] : tensor<36x!qco.qubit>
    %controls_out_122, %targets_out_123 = qco.ctrl(%result_119) targets (%arg0 = %result_121) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = qtensor.insert %targets_out_123 into %out_tensor_120[%c21] : tensor<36x!qco.qubit>
    %45 = qtensor.insert %controls_out_122 into %44[%c20] : tensor<36x!qco.qubit>
    %out_tensor_124, %result_125 = qtensor.extract %45[%c21] : tensor<36x!qco.qubit>
    %out_tensor_126, %result_127 = qtensor.extract %out_tensor_124[%c22] : tensor<36x!qco.qubit>
    %controls_out_128, %targets_out_129 = qco.ctrl(%result_125) targets (%arg0 = %result_127) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qtensor.insert %targets_out_129 into %out_tensor_126[%c22] : tensor<36x!qco.qubit>
    %47 = qtensor.insert %controls_out_128 into %46[%c21] : tensor<36x!qco.qubit>
    %out_tensor_130, %result_131 = qtensor.extract %47[%c22] : tensor<36x!qco.qubit>
    %out_tensor_132, %result_133 = qtensor.extract %out_tensor_130[%c23] : tensor<36x!qco.qubit>
    %controls_out_134, %targets_out_135 = qco.ctrl(%result_131) targets (%arg0 = %result_133) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %48 = qtensor.insert %targets_out_135 into %out_tensor_132[%c23] : tensor<36x!qco.qubit>
    %49 = qtensor.insert %controls_out_134 into %48[%c22] : tensor<36x!qco.qubit>
    %out_tensor_136, %result_137 = qtensor.extract %49[%c23] : tensor<36x!qco.qubit>
    %out_tensor_138, %result_139 = qtensor.extract %out_tensor_136[%c24] : tensor<36x!qco.qubit>
    %controls_out_140, %targets_out_141 = qco.ctrl(%result_137) targets (%arg0 = %result_139) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qtensor.insert %targets_out_141 into %out_tensor_138[%c24] : tensor<36x!qco.qubit>
    %51 = qtensor.insert %controls_out_140 into %50[%c23] : tensor<36x!qco.qubit>
    %out_tensor_142, %result_143 = qtensor.extract %51[%c24] : tensor<36x!qco.qubit>
    %out_tensor_144, %result_145 = qtensor.extract %out_tensor_142[%c25] : tensor<36x!qco.qubit>
    %controls_out_146, %targets_out_147 = qco.ctrl(%result_143) targets (%arg0 = %result_145) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qtensor.insert %targets_out_147 into %out_tensor_144[%c25] : tensor<36x!qco.qubit>
    %53 = qtensor.insert %controls_out_146 into %52[%c24] : tensor<36x!qco.qubit>
    %out_tensor_148, %result_149 = qtensor.extract %53[%c25] : tensor<36x!qco.qubit>
    %out_tensor_150, %result_151 = qtensor.extract %out_tensor_148[%c26] : tensor<36x!qco.qubit>
    %controls_out_152, %targets_out_153 = qco.ctrl(%result_149) targets (%arg0 = %result_151) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %54 = qtensor.insert %targets_out_153 into %out_tensor_150[%c26] : tensor<36x!qco.qubit>
    %55 = qtensor.insert %controls_out_152 into %54[%c25] : tensor<36x!qco.qubit>
    %out_tensor_154, %result_155 = qtensor.extract %55[%c26] : tensor<36x!qco.qubit>
    %out_tensor_156, %result_157 = qtensor.extract %out_tensor_154[%c27] : tensor<36x!qco.qubit>
    %controls_out_158, %targets_out_159 = qco.ctrl(%result_155) targets (%arg0 = %result_157) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qtensor.insert %targets_out_159 into %out_tensor_156[%c27] : tensor<36x!qco.qubit>
    %57 = qtensor.insert %controls_out_158 into %56[%c26] : tensor<36x!qco.qubit>
    %out_tensor_160, %result_161 = qtensor.extract %57[%c27] : tensor<36x!qco.qubit>
    %out_tensor_162, %result_163 = qtensor.extract %out_tensor_160[%c28] : tensor<36x!qco.qubit>
    %controls_out_164, %targets_out_165 = qco.ctrl(%result_161) targets (%arg0 = %result_163) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = qtensor.insert %targets_out_165 into %out_tensor_162[%c28] : tensor<36x!qco.qubit>
    %59 = qtensor.insert %controls_out_164 into %58[%c27] : tensor<36x!qco.qubit>
    %out_tensor_166, %result_167 = qtensor.extract %59[%c28] : tensor<36x!qco.qubit>
    %out_tensor_168, %result_169 = qtensor.extract %out_tensor_166[%c29] : tensor<36x!qco.qubit>
    %controls_out_170, %targets_out_171 = qco.ctrl(%result_167) targets (%arg0 = %result_169) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qtensor.insert %targets_out_171 into %out_tensor_168[%c29] : tensor<36x!qco.qubit>
    %61 = qtensor.insert %controls_out_170 into %60[%c28] : tensor<36x!qco.qubit>
    %out_tensor_172, %result_173 = qtensor.extract %61[%c29] : tensor<36x!qco.qubit>
    %out_tensor_174, %result_175 = qtensor.extract %out_tensor_172[%c30] : tensor<36x!qco.qubit>
    %controls_out_176, %targets_out_177 = qco.ctrl(%result_173) targets (%arg0 = %result_175) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %62 = qtensor.insert %targets_out_177 into %out_tensor_174[%c30] : tensor<36x!qco.qubit>
    %63 = qtensor.insert %controls_out_176 into %62[%c29] : tensor<36x!qco.qubit>
    %out_tensor_178, %result_179 = qtensor.extract %63[%c30] : tensor<36x!qco.qubit>
    %out_tensor_180, %result_181 = qtensor.extract %out_tensor_178[%c31] : tensor<36x!qco.qubit>
    %controls_out_182, %targets_out_183 = qco.ctrl(%result_179) targets (%arg0 = %result_181) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %64 = qtensor.insert %targets_out_183 into %out_tensor_180[%c31] : tensor<36x!qco.qubit>
    %65 = qtensor.insert %controls_out_182 into %64[%c30] : tensor<36x!qco.qubit>
    %out_tensor_184, %result_185 = qtensor.extract %65[%c31] : tensor<36x!qco.qubit>
    %out_tensor_186, %result_187 = qtensor.extract %out_tensor_184[%c32] : tensor<36x!qco.qubit>
    %controls_out_188, %targets_out_189 = qco.ctrl(%result_185) targets (%arg0 = %result_187) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = qtensor.insert %targets_out_189 into %out_tensor_186[%c32] : tensor<36x!qco.qubit>
    %67 = qtensor.insert %controls_out_188 into %66[%c31] : tensor<36x!qco.qubit>
    %out_tensor_190, %result_191 = qtensor.extract %67[%c32] : tensor<36x!qco.qubit>
    %out_tensor_192, %result_193 = qtensor.extract %out_tensor_190[%c33] : tensor<36x!qco.qubit>
    %controls_out_194, %targets_out_195 = qco.ctrl(%result_191) targets (%arg0 = %result_193) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %68 = qtensor.insert %targets_out_195 into %out_tensor_192[%c33] : tensor<36x!qco.qubit>
    %69 = qtensor.insert %controls_out_194 into %68[%c32] : tensor<36x!qco.qubit>
    %out_tensor_196, %result_197 = qtensor.extract %69[%c33] : tensor<36x!qco.qubit>
    %out_tensor_198, %result_199 = qtensor.extract %out_tensor_196[%c34] : tensor<36x!qco.qubit>
    %controls_out_200, %targets_out_201 = qco.ctrl(%result_197) targets (%arg0 = %result_199) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %70 = qtensor.insert %targets_out_201 into %out_tensor_198[%c34] : tensor<36x!qco.qubit>
    %71 = qtensor.insert %controls_out_200 into %70[%c33] : tensor<36x!qco.qubit>
    %out_tensor_202, %result_203 = qtensor.extract %71[%c34] : tensor<36x!qco.qubit>
    %out_tensor_204, %result_205 = qtensor.extract %out_tensor_202[%c35] : tensor<36x!qco.qubit>
    %controls_out_206, %targets_out_207 = qco.ctrl(%result_203) targets (%arg0 = %result_205) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %72 = qtensor.insert %targets_out_207 into %out_tensor_204[%c35] : tensor<36x!qco.qubit>
    %73 = qtensor.insert %controls_out_206 into %72[%c34] : tensor<36x!qco.qubit>
    %out_tensor_208, %result_209 = qtensor.extract %73[%c0] : tensor<36x!qco.qubit>
    %qubit_out, %result_210 = qco.measure %result_209 : !qco.qubit
    %74 = qtensor.insert %qubit_out into %out_tensor_208[%c0] : tensor<36x!qco.qubit>
    cbit.store %result_210, %1[%c0] : !cbit.reg<36>
    %out_tensor_211, %result_212 = qtensor.extract %74[%c1] : tensor<36x!qco.qubit>
    %qubit_out_213, %result_214 = qco.measure %result_212 : !qco.qubit
    %75 = qtensor.insert %qubit_out_213 into %out_tensor_211[%c1] : tensor<36x!qco.qubit>
    cbit.store %result_214, %1[%c1] : !cbit.reg<36>
    %out_tensor_215, %result_216 = qtensor.extract %75[%c2] : tensor<36x!qco.qubit>
    %qubit_out_217, %result_218 = qco.measure %result_216 : !qco.qubit
    %76 = qtensor.insert %qubit_out_217 into %out_tensor_215[%c2] : tensor<36x!qco.qubit>
    cbit.store %result_218, %1[%c2] : !cbit.reg<36>
    %out_tensor_219, %result_220 = qtensor.extract %76[%c3] : tensor<36x!qco.qubit>
    %qubit_out_221, %result_222 = qco.measure %result_220 : !qco.qubit
    %77 = qtensor.insert %qubit_out_221 into %out_tensor_219[%c3] : tensor<36x!qco.qubit>
    cbit.store %result_222, %1[%c3] : !cbit.reg<36>
    %out_tensor_223, %result_224 = qtensor.extract %77[%c4] : tensor<36x!qco.qubit>
    %qubit_out_225, %result_226 = qco.measure %result_224 : !qco.qubit
    %78 = qtensor.insert %qubit_out_225 into %out_tensor_223[%c4] : tensor<36x!qco.qubit>
    cbit.store %result_226, %1[%c4] : !cbit.reg<36>
    %out_tensor_227, %result_228 = qtensor.extract %78[%c5] : tensor<36x!qco.qubit>
    %qubit_out_229, %result_230 = qco.measure %result_228 : !qco.qubit
    %79 = qtensor.insert %qubit_out_229 into %out_tensor_227[%c5] : tensor<36x!qco.qubit>
    cbit.store %result_230, %1[%c5] : !cbit.reg<36>
    %out_tensor_231, %result_232 = qtensor.extract %79[%c6] : tensor<36x!qco.qubit>
    %qubit_out_233, %result_234 = qco.measure %result_232 : !qco.qubit
    %80 = qtensor.insert %qubit_out_233 into %out_tensor_231[%c6] : tensor<36x!qco.qubit>
    cbit.store %result_234, %1[%c6] : !cbit.reg<36>
    %out_tensor_235, %result_236 = qtensor.extract %80[%c7] : tensor<36x!qco.qubit>
    %qubit_out_237, %result_238 = qco.measure %result_236 : !qco.qubit
    %81 = qtensor.insert %qubit_out_237 into %out_tensor_235[%c7] : tensor<36x!qco.qubit>
    cbit.store %result_238, %1[%c7] : !cbit.reg<36>
    %out_tensor_239, %result_240 = qtensor.extract %81[%c8] : tensor<36x!qco.qubit>
    %qubit_out_241, %result_242 = qco.measure %result_240 : !qco.qubit
    %82 = qtensor.insert %qubit_out_241 into %out_tensor_239[%c8] : tensor<36x!qco.qubit>
    cbit.store %result_242, %1[%c8] : !cbit.reg<36>
    %out_tensor_243, %result_244 = qtensor.extract %82[%c9] : tensor<36x!qco.qubit>
    %qubit_out_245, %result_246 = qco.measure %result_244 : !qco.qubit
    %83 = qtensor.insert %qubit_out_245 into %out_tensor_243[%c9] : tensor<36x!qco.qubit>
    cbit.store %result_246, %1[%c9] : !cbit.reg<36>
    %out_tensor_247, %result_248 = qtensor.extract %83[%c10] : tensor<36x!qco.qubit>
    %qubit_out_249, %result_250 = qco.measure %result_248 : !qco.qubit
    %84 = qtensor.insert %qubit_out_249 into %out_tensor_247[%c10] : tensor<36x!qco.qubit>
    cbit.store %result_250, %1[%c10] : !cbit.reg<36>
    %out_tensor_251, %result_252 = qtensor.extract %84[%c11] : tensor<36x!qco.qubit>
    %qubit_out_253, %result_254 = qco.measure %result_252 : !qco.qubit
    %85 = qtensor.insert %qubit_out_253 into %out_tensor_251[%c11] : tensor<36x!qco.qubit>
    cbit.store %result_254, %1[%c11] : !cbit.reg<36>
    %out_tensor_255, %result_256 = qtensor.extract %85[%c12] : tensor<36x!qco.qubit>
    %qubit_out_257, %result_258 = qco.measure %result_256 : !qco.qubit
    %86 = qtensor.insert %qubit_out_257 into %out_tensor_255[%c12] : tensor<36x!qco.qubit>
    cbit.store %result_258, %1[%c12] : !cbit.reg<36>
    %out_tensor_259, %result_260 = qtensor.extract %86[%c13] : tensor<36x!qco.qubit>
    %qubit_out_261, %result_262 = qco.measure %result_260 : !qco.qubit
    %87 = qtensor.insert %qubit_out_261 into %out_tensor_259[%c13] : tensor<36x!qco.qubit>
    cbit.store %result_262, %1[%c13] : !cbit.reg<36>
    %out_tensor_263, %result_264 = qtensor.extract %87[%c14] : tensor<36x!qco.qubit>
    %qubit_out_265, %result_266 = qco.measure %result_264 : !qco.qubit
    %88 = qtensor.insert %qubit_out_265 into %out_tensor_263[%c14] : tensor<36x!qco.qubit>
    cbit.store %result_266, %1[%c14] : !cbit.reg<36>
    %out_tensor_267, %result_268 = qtensor.extract %88[%c15] : tensor<36x!qco.qubit>
    %qubit_out_269, %result_270 = qco.measure %result_268 : !qco.qubit
    %89 = qtensor.insert %qubit_out_269 into %out_tensor_267[%c15] : tensor<36x!qco.qubit>
    cbit.store %result_270, %1[%c15] : !cbit.reg<36>
    %out_tensor_271, %result_272 = qtensor.extract %89[%c16] : tensor<36x!qco.qubit>
    %qubit_out_273, %result_274 = qco.measure %result_272 : !qco.qubit
    %90 = qtensor.insert %qubit_out_273 into %out_tensor_271[%c16] : tensor<36x!qco.qubit>
    cbit.store %result_274, %1[%c16] : !cbit.reg<36>
    %out_tensor_275, %result_276 = qtensor.extract %90[%c17] : tensor<36x!qco.qubit>
    %qubit_out_277, %result_278 = qco.measure %result_276 : !qco.qubit
    %91 = qtensor.insert %qubit_out_277 into %out_tensor_275[%c17] : tensor<36x!qco.qubit>
    cbit.store %result_278, %1[%c17] : !cbit.reg<36>
    %out_tensor_279, %result_280 = qtensor.extract %91[%c18] : tensor<36x!qco.qubit>
    %qubit_out_281, %result_282 = qco.measure %result_280 : !qco.qubit
    %92 = qtensor.insert %qubit_out_281 into %out_tensor_279[%c18] : tensor<36x!qco.qubit>
    cbit.store %result_282, %1[%c18] : !cbit.reg<36>
    %out_tensor_283, %result_284 = qtensor.extract %92[%c19] : tensor<36x!qco.qubit>
    %qubit_out_285, %result_286 = qco.measure %result_284 : !qco.qubit
    %93 = qtensor.insert %qubit_out_285 into %out_tensor_283[%c19] : tensor<36x!qco.qubit>
    cbit.store %result_286, %1[%c19] : !cbit.reg<36>
    %out_tensor_287, %result_288 = qtensor.extract %93[%c20] : tensor<36x!qco.qubit>
    %qubit_out_289, %result_290 = qco.measure %result_288 : !qco.qubit
    %94 = qtensor.insert %qubit_out_289 into %out_tensor_287[%c20] : tensor<36x!qco.qubit>
    cbit.store %result_290, %1[%c20] : !cbit.reg<36>
    %out_tensor_291, %result_292 = qtensor.extract %94[%c21] : tensor<36x!qco.qubit>
    %qubit_out_293, %result_294 = qco.measure %result_292 : !qco.qubit
    %95 = qtensor.insert %qubit_out_293 into %out_tensor_291[%c21] : tensor<36x!qco.qubit>
    cbit.store %result_294, %1[%c21] : !cbit.reg<36>
    %out_tensor_295, %result_296 = qtensor.extract %95[%c22] : tensor<36x!qco.qubit>
    %qubit_out_297, %result_298 = qco.measure %result_296 : !qco.qubit
    %96 = qtensor.insert %qubit_out_297 into %out_tensor_295[%c22] : tensor<36x!qco.qubit>
    cbit.store %result_298, %1[%c22] : !cbit.reg<36>
    %out_tensor_299, %result_300 = qtensor.extract %96[%c23] : tensor<36x!qco.qubit>
    %qubit_out_301, %result_302 = qco.measure %result_300 : !qco.qubit
    %97 = qtensor.insert %qubit_out_301 into %out_tensor_299[%c23] : tensor<36x!qco.qubit>
    cbit.store %result_302, %1[%c23] : !cbit.reg<36>
    %out_tensor_303, %result_304 = qtensor.extract %97[%c24] : tensor<36x!qco.qubit>
    %qubit_out_305, %result_306 = qco.measure %result_304 : !qco.qubit
    %98 = qtensor.insert %qubit_out_305 into %out_tensor_303[%c24] : tensor<36x!qco.qubit>
    cbit.store %result_306, %1[%c24] : !cbit.reg<36>
    %out_tensor_307, %result_308 = qtensor.extract %98[%c25] : tensor<36x!qco.qubit>
    %qubit_out_309, %result_310 = qco.measure %result_308 : !qco.qubit
    %99 = qtensor.insert %qubit_out_309 into %out_tensor_307[%c25] : tensor<36x!qco.qubit>
    cbit.store %result_310, %1[%c25] : !cbit.reg<36>
    %out_tensor_311, %result_312 = qtensor.extract %99[%c26] : tensor<36x!qco.qubit>
    %qubit_out_313, %result_314 = qco.measure %result_312 : !qco.qubit
    %100 = qtensor.insert %qubit_out_313 into %out_tensor_311[%c26] : tensor<36x!qco.qubit>
    cbit.store %result_314, %1[%c26] : !cbit.reg<36>
    %out_tensor_315, %result_316 = qtensor.extract %100[%c27] : tensor<36x!qco.qubit>
    %qubit_out_317, %result_318 = qco.measure %result_316 : !qco.qubit
    %101 = qtensor.insert %qubit_out_317 into %out_tensor_315[%c27] : tensor<36x!qco.qubit>
    cbit.store %result_318, %1[%c27] : !cbit.reg<36>
    %out_tensor_319, %result_320 = qtensor.extract %101[%c28] : tensor<36x!qco.qubit>
    %qubit_out_321, %result_322 = qco.measure %result_320 : !qco.qubit
    %102 = qtensor.insert %qubit_out_321 into %out_tensor_319[%c28] : tensor<36x!qco.qubit>
    cbit.store %result_322, %1[%c28] : !cbit.reg<36>
    %out_tensor_323, %result_324 = qtensor.extract %102[%c29] : tensor<36x!qco.qubit>
    %qubit_out_325, %result_326 = qco.measure %result_324 : !qco.qubit
    %103 = qtensor.insert %qubit_out_325 into %out_tensor_323[%c29] : tensor<36x!qco.qubit>
    cbit.store %result_326, %1[%c29] : !cbit.reg<36>
    %out_tensor_327, %result_328 = qtensor.extract %103[%c30] : tensor<36x!qco.qubit>
    %qubit_out_329, %result_330 = qco.measure %result_328 : !qco.qubit
    %104 = qtensor.insert %qubit_out_329 into %out_tensor_327[%c30] : tensor<36x!qco.qubit>
    cbit.store %result_330, %1[%c30] : !cbit.reg<36>
    %out_tensor_331, %result_332 = qtensor.extract %104[%c31] : tensor<36x!qco.qubit>
    %qubit_out_333, %result_334 = qco.measure %result_332 : !qco.qubit
    %105 = qtensor.insert %qubit_out_333 into %out_tensor_331[%c31] : tensor<36x!qco.qubit>
    cbit.store %result_334, %1[%c31] : !cbit.reg<36>
    %out_tensor_335, %result_336 = qtensor.extract %105[%c32] : tensor<36x!qco.qubit>
    %qubit_out_337, %result_338 = qco.measure %result_336 : !qco.qubit
    %106 = qtensor.insert %qubit_out_337 into %out_tensor_335[%c32] : tensor<36x!qco.qubit>
    cbit.store %result_338, %1[%c32] : !cbit.reg<36>
    %out_tensor_339, %result_340 = qtensor.extract %106[%c33] : tensor<36x!qco.qubit>
    %qubit_out_341, %result_342 = qco.measure %result_340 : !qco.qubit
    %107 = qtensor.insert %qubit_out_341 into %out_tensor_339[%c33] : tensor<36x!qco.qubit>
    cbit.store %result_342, %1[%c33] : !cbit.reg<36>
    %out_tensor_343, %result_344 = qtensor.extract %107[%c34] : tensor<36x!qco.qubit>
    %qubit_out_345, %result_346 = qco.measure %result_344 : !qco.qubit
    %108 = qtensor.insert %qubit_out_345 into %out_tensor_343[%c34] : tensor<36x!qco.qubit>
    cbit.store %result_346, %1[%c34] : !cbit.reg<36>
    %out_tensor_347, %result_348 = qtensor.extract %108[%c35] : tensor<36x!qco.qubit>
    %qubit_out_349, %result_350 = qco.measure %result_348 : !qco.qubit
    %109 = qtensor.insert %qubit_out_349 into %out_tensor_347[%c35] : tensor<36x!qco.qubit>
    cbit.store %result_350, %1[%c35] : !cbit.reg<36>
    qtensor.dealloc %109 : tensor<36x!qco.qubit>
    return %1 : !cbit.reg<36>
  }
}
