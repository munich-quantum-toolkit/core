module {
  func.func @main() -> !cbit.reg<35> attributes {mqt.entry_point} {
    %false = arith.constant false
    %true = arith.constant true
    %c34 = arith.constant 34 : index
    %c33 = arith.constant 33 : index
    %c32 = arith.constant 32 : index
    %c31 = arith.constant 31 : index
    %c30 = arith.constant 30 : index
    %c29 = arith.constant 29 : index
    %c28 = arith.constant 28 : index
    %c27 = arith.constant 27 : index
    %c26 = arith.constant 26 : index
    %c25 = arith.constant 25 : index
    %c24 = arith.constant 24 : index
    %c23 = arith.constant 23 : index
    %c22 = arith.constant 22 : index
    %c21 = arith.constant 21 : index
    %c20 = arith.constant 20 : index
    %c19 = arith.constant 19 : index
    %c18 = arith.constant 18 : index
    %c17 = arith.constant 17 : index
    %c16 = arith.constant 16 : index
    %c15 = arith.constant 15 : index
    %c14 = arith.constant 14 : index
    %c13 = arith.constant 13 : index
    %c12 = arith.constant 12 : index
    %c11 = arith.constant 11 : index
    %c10 = arith.constant 10 : index
    %c9 = arith.constant 9 : index
    %c8 = arith.constant 8 : index
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c35 = arith.constant 35 : index
    %c0 = arith.constant 0 : index
    %0 = qco.alloc : !qco.qubit
    %1 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<35>
    %2 = qco.x %0 : !qco.qubit -> !qco.qubit
    %3 = qtensor.alloc(%c35) {mqt.register_name = "query"} : tensor<35x!qco.qubit>
    %out_tensor, %result = qtensor.extract %3[%c0] : tensor<35x!qco.qubit>
    %4 = qco.h %result : !qco.qubit -> !qco.qubit
    %5 = qtensor.insert %4 into %out_tensor[%c0] : tensor<35x!qco.qubit>
    %out_tensor_0, %result_1 = qtensor.extract %5[%c1] : tensor<35x!qco.qubit>
    %6 = qco.h %result_1 : !qco.qubit -> !qco.qubit
    %7 = qtensor.insert %6 into %out_tensor_0[%c1] : tensor<35x!qco.qubit>
    %out_tensor_2, %result_3 = qtensor.extract %7[%c2] : tensor<35x!qco.qubit>
    %8 = qco.h %result_3 : !qco.qubit -> !qco.qubit
    %9 = qtensor.insert %8 into %out_tensor_2[%c2] : tensor<35x!qco.qubit>
    %out_tensor_4, %result_5 = qtensor.extract %9[%c3] : tensor<35x!qco.qubit>
    %10 = qco.h %result_5 : !qco.qubit -> !qco.qubit
    %11 = qtensor.insert %10 into %out_tensor_4[%c3] : tensor<35x!qco.qubit>
    %out_tensor_6, %result_7 = qtensor.extract %11[%c4] : tensor<35x!qco.qubit>
    %12 = qco.h %result_7 : !qco.qubit -> !qco.qubit
    %13 = qtensor.insert %12 into %out_tensor_6[%c4] : tensor<35x!qco.qubit>
    %out_tensor_8, %result_9 = qtensor.extract %13[%c5] : tensor<35x!qco.qubit>
    %14 = qco.h %result_9 : !qco.qubit -> !qco.qubit
    %15 = qtensor.insert %14 into %out_tensor_8[%c5] : tensor<35x!qco.qubit>
    %out_tensor_10, %result_11 = qtensor.extract %15[%c6] : tensor<35x!qco.qubit>
    %16 = qco.h %result_11 : !qco.qubit -> !qco.qubit
    %17 = qtensor.insert %16 into %out_tensor_10[%c6] : tensor<35x!qco.qubit>
    %out_tensor_12, %result_13 = qtensor.extract %17[%c7] : tensor<35x!qco.qubit>
    %18 = qco.h %result_13 : !qco.qubit -> !qco.qubit
    %19 = qtensor.insert %18 into %out_tensor_12[%c7] : tensor<35x!qco.qubit>
    %out_tensor_14, %result_15 = qtensor.extract %19[%c8] : tensor<35x!qco.qubit>
    %20 = qco.h %result_15 : !qco.qubit -> !qco.qubit
    %21 = qtensor.insert %20 into %out_tensor_14[%c8] : tensor<35x!qco.qubit>
    %out_tensor_16, %result_17 = qtensor.extract %21[%c9] : tensor<35x!qco.qubit>
    %22 = qco.h %result_17 : !qco.qubit -> !qco.qubit
    %23 = qtensor.insert %22 into %out_tensor_16[%c9] : tensor<35x!qco.qubit>
    %out_tensor_18, %result_19 = qtensor.extract %23[%c10] : tensor<35x!qco.qubit>
    %24 = qco.h %result_19 : !qco.qubit -> !qco.qubit
    %25 = qtensor.insert %24 into %out_tensor_18[%c10] : tensor<35x!qco.qubit>
    %out_tensor_20, %result_21 = qtensor.extract %25[%c11] : tensor<35x!qco.qubit>
    %26 = qco.h %result_21 : !qco.qubit -> !qco.qubit
    %27 = qtensor.insert %26 into %out_tensor_20[%c11] : tensor<35x!qco.qubit>
    %out_tensor_22, %result_23 = qtensor.extract %27[%c12] : tensor<35x!qco.qubit>
    %28 = qco.h %result_23 : !qco.qubit -> !qco.qubit
    %29 = qtensor.insert %28 into %out_tensor_22[%c12] : tensor<35x!qco.qubit>
    %out_tensor_24, %result_25 = qtensor.extract %29[%c13] : tensor<35x!qco.qubit>
    %30 = qco.h %result_25 : !qco.qubit -> !qco.qubit
    %31 = qtensor.insert %30 into %out_tensor_24[%c13] : tensor<35x!qco.qubit>
    %out_tensor_26, %result_27 = qtensor.extract %31[%c14] : tensor<35x!qco.qubit>
    %32 = qco.h %result_27 : !qco.qubit -> !qco.qubit
    %33 = qtensor.insert %32 into %out_tensor_26[%c14] : tensor<35x!qco.qubit>
    %out_tensor_28, %result_29 = qtensor.extract %33[%c15] : tensor<35x!qco.qubit>
    %34 = qco.h %result_29 : !qco.qubit -> !qco.qubit
    %35 = qtensor.insert %34 into %out_tensor_28[%c15] : tensor<35x!qco.qubit>
    %out_tensor_30, %result_31 = qtensor.extract %35[%c16] : tensor<35x!qco.qubit>
    %36 = qco.h %result_31 : !qco.qubit -> !qco.qubit
    %37 = qtensor.insert %36 into %out_tensor_30[%c16] : tensor<35x!qco.qubit>
    %out_tensor_32, %result_33 = qtensor.extract %37[%c17] : tensor<35x!qco.qubit>
    %38 = qco.h %result_33 : !qco.qubit -> !qco.qubit
    %39 = qtensor.insert %38 into %out_tensor_32[%c17] : tensor<35x!qco.qubit>
    %out_tensor_34, %result_35 = qtensor.extract %39[%c18] : tensor<35x!qco.qubit>
    %40 = qco.h %result_35 : !qco.qubit -> !qco.qubit
    %41 = qtensor.insert %40 into %out_tensor_34[%c18] : tensor<35x!qco.qubit>
    %out_tensor_36, %result_37 = qtensor.extract %41[%c19] : tensor<35x!qco.qubit>
    %42 = qco.h %result_37 : !qco.qubit -> !qco.qubit
    %43 = qtensor.insert %42 into %out_tensor_36[%c19] : tensor<35x!qco.qubit>
    %out_tensor_38, %result_39 = qtensor.extract %43[%c20] : tensor<35x!qco.qubit>
    %44 = qco.h %result_39 : !qco.qubit -> !qco.qubit
    %45 = qtensor.insert %44 into %out_tensor_38[%c20] : tensor<35x!qco.qubit>
    %out_tensor_40, %result_41 = qtensor.extract %45[%c21] : tensor<35x!qco.qubit>
    %46 = qco.h %result_41 : !qco.qubit -> !qco.qubit
    %47 = qtensor.insert %46 into %out_tensor_40[%c21] : tensor<35x!qco.qubit>
    %out_tensor_42, %result_43 = qtensor.extract %47[%c22] : tensor<35x!qco.qubit>
    %48 = qco.h %result_43 : !qco.qubit -> !qco.qubit
    %49 = qtensor.insert %48 into %out_tensor_42[%c22] : tensor<35x!qco.qubit>
    %out_tensor_44, %result_45 = qtensor.extract %49[%c23] : tensor<35x!qco.qubit>
    %50 = qco.h %result_45 : !qco.qubit -> !qco.qubit
    %51 = qtensor.insert %50 into %out_tensor_44[%c23] : tensor<35x!qco.qubit>
    %out_tensor_46, %result_47 = qtensor.extract %51[%c24] : tensor<35x!qco.qubit>
    %52 = qco.h %result_47 : !qco.qubit -> !qco.qubit
    %53 = qtensor.insert %52 into %out_tensor_46[%c24] : tensor<35x!qco.qubit>
    %out_tensor_48, %result_49 = qtensor.extract %53[%c25] : tensor<35x!qco.qubit>
    %54 = qco.h %result_49 : !qco.qubit -> !qco.qubit
    %55 = qtensor.insert %54 into %out_tensor_48[%c25] : tensor<35x!qco.qubit>
    %out_tensor_50, %result_51 = qtensor.extract %55[%c26] : tensor<35x!qco.qubit>
    %56 = qco.h %result_51 : !qco.qubit -> !qco.qubit
    %57 = qtensor.insert %56 into %out_tensor_50[%c26] : tensor<35x!qco.qubit>
    %out_tensor_52, %result_53 = qtensor.extract %57[%c27] : tensor<35x!qco.qubit>
    %58 = qco.h %result_53 : !qco.qubit -> !qco.qubit
    %59 = qtensor.insert %58 into %out_tensor_52[%c27] : tensor<35x!qco.qubit>
    %out_tensor_54, %result_55 = qtensor.extract %59[%c28] : tensor<35x!qco.qubit>
    %60 = qco.h %result_55 : !qco.qubit -> !qco.qubit
    %61 = qtensor.insert %60 into %out_tensor_54[%c28] : tensor<35x!qco.qubit>
    %out_tensor_56, %result_57 = qtensor.extract %61[%c29] : tensor<35x!qco.qubit>
    %62 = qco.h %result_57 : !qco.qubit -> !qco.qubit
    %63 = qtensor.insert %62 into %out_tensor_56[%c29] : tensor<35x!qco.qubit>
    %out_tensor_58, %result_59 = qtensor.extract %63[%c30] : tensor<35x!qco.qubit>
    %64 = qco.h %result_59 : !qco.qubit -> !qco.qubit
    %65 = qtensor.insert %64 into %out_tensor_58[%c30] : tensor<35x!qco.qubit>
    %out_tensor_60, %result_61 = qtensor.extract %65[%c31] : tensor<35x!qco.qubit>
    %66 = qco.h %result_61 : !qco.qubit -> !qco.qubit
    %67 = qtensor.insert %66 into %out_tensor_60[%c31] : tensor<35x!qco.qubit>
    %out_tensor_62, %result_63 = qtensor.extract %67[%c32] : tensor<35x!qco.qubit>
    %68 = qco.h %result_63 : !qco.qubit -> !qco.qubit
    %69 = qtensor.insert %68 into %out_tensor_62[%c32] : tensor<35x!qco.qubit>
    %out_tensor_64, %result_65 = qtensor.extract %69[%c33] : tensor<35x!qco.qubit>
    %70 = qco.h %result_65 : !qco.qubit -> !qco.qubit
    %71 = qtensor.insert %70 into %out_tensor_64[%c33] : tensor<35x!qco.qubit>
    %out_tensor_66, %result_67 = qtensor.extract %71[%c34] : tensor<35x!qco.qubit>
    %72 = qco.h %result_67 : !qco.qubit -> !qco.qubit
    %73 = qtensor.insert %72 into %out_tensor_66[%c34] : tensor<35x!qco.qubit>
    %linearResults:2 = qco.if %true args(%arg0 = %73, %arg1 = %2) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c0] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c0] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %73, %arg1 = %2) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_68:2 = qco.if %false args(%arg0 = %linearResults#0, %arg1 = %linearResults#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c1] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c1] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults#0, %arg1 = %linearResults#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_69:2 = qco.if %true args(%arg0 = %linearResults_68#0, %arg1 = %linearResults_68#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c2] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c2] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_68#0, %arg1 = %linearResults_68#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_70:2 = qco.if %false args(%arg0 = %linearResults_69#0, %arg1 = %linearResults_69#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c3] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c3] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_69#0, %arg1 = %linearResults_69#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_71:2 = qco.if %true args(%arg0 = %linearResults_70#0, %arg1 = %linearResults_70#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c4] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c4] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_70#0, %arg1 = %linearResults_70#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_72:2 = qco.if %false args(%arg0 = %linearResults_71#0, %arg1 = %linearResults_71#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c5] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c5] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_71#0, %arg1 = %linearResults_71#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_73:2 = qco.if %true args(%arg0 = %linearResults_72#0, %arg1 = %linearResults_72#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c6] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c6] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_72#0, %arg1 = %linearResults_72#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_74:2 = qco.if %false args(%arg0 = %linearResults_73#0, %arg1 = %linearResults_73#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c7] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c7] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_73#0, %arg1 = %linearResults_73#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_75:2 = qco.if %true args(%arg0 = %linearResults_74#0, %arg1 = %linearResults_74#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c8] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c8] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_74#0, %arg1 = %linearResults_74#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_76:2 = qco.if %false args(%arg0 = %linearResults_75#0, %arg1 = %linearResults_75#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c9] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c9] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_75#0, %arg1 = %linearResults_75#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_77:2 = qco.if %true args(%arg0 = %linearResults_76#0, %arg1 = %linearResults_76#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c10] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c10] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_76#0, %arg1 = %linearResults_76#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_78:2 = qco.if %false args(%arg0 = %linearResults_77#0, %arg1 = %linearResults_77#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c11] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c11] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_77#0, %arg1 = %linearResults_77#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_79:2 = qco.if %true args(%arg0 = %linearResults_78#0, %arg1 = %linearResults_78#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c12] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c12] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_78#0, %arg1 = %linearResults_78#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_80:2 = qco.if %false args(%arg0 = %linearResults_79#0, %arg1 = %linearResults_79#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c13] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c13] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_79#0, %arg1 = %linearResults_79#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_81:2 = qco.if %true args(%arg0 = %linearResults_80#0, %arg1 = %linearResults_80#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c14] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c14] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_80#0, %arg1 = %linearResults_80#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_82:2 = qco.if %false args(%arg0 = %linearResults_81#0, %arg1 = %linearResults_81#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c15] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c15] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_81#0, %arg1 = %linearResults_81#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_83:2 = qco.if %true args(%arg0 = %linearResults_82#0, %arg1 = %linearResults_82#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c16] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c16] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_82#0, %arg1 = %linearResults_82#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_84:2 = qco.if %false args(%arg0 = %linearResults_83#0, %arg1 = %linearResults_83#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c17] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c17] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_83#0, %arg1 = %linearResults_83#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_85:2 = qco.if %true args(%arg0 = %linearResults_84#0, %arg1 = %linearResults_84#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c18] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c18] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_84#0, %arg1 = %linearResults_84#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_86:2 = qco.if %false args(%arg0 = %linearResults_85#0, %arg1 = %linearResults_85#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c19] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c19] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_85#0, %arg1 = %linearResults_85#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_87:2 = qco.if %true args(%arg0 = %linearResults_86#0, %arg1 = %linearResults_86#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c20] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c20] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_86#0, %arg1 = %linearResults_86#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_88:2 = qco.if %false args(%arg0 = %linearResults_87#0, %arg1 = %linearResults_87#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c21] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c21] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_87#0, %arg1 = %linearResults_87#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_89:2 = qco.if %true args(%arg0 = %linearResults_88#0, %arg1 = %linearResults_88#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c22] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c22] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_88#0, %arg1 = %linearResults_88#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_90:2 = qco.if %false args(%arg0 = %linearResults_89#0, %arg1 = %linearResults_89#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c23] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c23] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_89#0, %arg1 = %linearResults_89#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_91:2 = qco.if %true args(%arg0 = %linearResults_90#0, %arg1 = %linearResults_90#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c24] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c24] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_90#0, %arg1 = %linearResults_90#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_92:2 = qco.if %false args(%arg0 = %linearResults_91#0, %arg1 = %linearResults_91#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c25] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c25] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_91#0, %arg1 = %linearResults_91#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_93:2 = qco.if %true args(%arg0 = %linearResults_92#0, %arg1 = %linearResults_92#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c26] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c26] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_92#0, %arg1 = %linearResults_92#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_94:2 = qco.if %false args(%arg0 = %linearResults_93#0, %arg1 = %linearResults_93#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c27] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c27] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_93#0, %arg1 = %linearResults_93#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_95:2 = qco.if %true args(%arg0 = %linearResults_94#0, %arg1 = %linearResults_94#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c28] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c28] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_94#0, %arg1 = %linearResults_94#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_96:2 = qco.if %false args(%arg0 = %linearResults_95#0, %arg1 = %linearResults_95#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c29] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c29] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_95#0, %arg1 = %linearResults_95#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_97:2 = qco.if %true args(%arg0 = %linearResults_96#0, %arg1 = %linearResults_96#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c30] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c30] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_96#0, %arg1 = %linearResults_96#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_98:2 = qco.if %false args(%arg0 = %linearResults_97#0, %arg1 = %linearResults_97#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c31] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c31] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_97#0, %arg1 = %linearResults_97#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_99:2 = qco.if %true args(%arg0 = %linearResults_98#0, %arg1 = %linearResults_98#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c32] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c32] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_98#0, %arg1 = %linearResults_98#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_100:2 = qco.if %false args(%arg0 = %linearResults_99#0, %arg1 = %linearResults_99#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c33] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c33] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_99#0, %arg1 = %linearResults_99#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %linearResults_101:2 = qco.if %true args(%arg0 = %linearResults_100#0, %arg1 = %linearResults_100#1) -> (tensor<35x!qco.qubit>, !qco.qubit) {
      %out_tensor_311, %result_312 = qtensor.extract %arg0[%c34] : tensor<35x!qco.qubit>
      %controls_out, %targets_out = qco.ctrl(%result_312) targets (%arg2 = %arg1) {
        %180 = qco.z %arg2 : !qco.qubit -> !qco.qubit
        qco.yield %180 : !qco.qubit
      } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
      %179 = qtensor.insert %controls_out into %out_tensor_311[%c34] : tensor<35x!qco.qubit>
      qco.yield %179, %targets_out : tensor<35x!qco.qubit>, !qco.qubit
    } else args(%arg0 = %linearResults_100#0, %arg1 = %linearResults_100#1) {
      qco.yield %arg0, %arg1 : tensor<35x!qco.qubit>, !qco.qubit
    }
    %out_tensor_102, %result_103 = qtensor.extract %linearResults_101#0[%c0] : tensor<35x!qco.qubit>
    %74 = qco.h %result_103 : !qco.qubit -> !qco.qubit
    %75 = qtensor.insert %74 into %out_tensor_102[%c0] : tensor<35x!qco.qubit>
    %out_tensor_104, %result_105 = qtensor.extract %75[%c1] : tensor<35x!qco.qubit>
    %76 = qco.h %result_105 : !qco.qubit -> !qco.qubit
    %77 = qtensor.insert %76 into %out_tensor_104[%c1] : tensor<35x!qco.qubit>
    %out_tensor_106, %result_107 = qtensor.extract %77[%c2] : tensor<35x!qco.qubit>
    %78 = qco.h %result_107 : !qco.qubit -> !qco.qubit
    %79 = qtensor.insert %78 into %out_tensor_106[%c2] : tensor<35x!qco.qubit>
    %out_tensor_108, %result_109 = qtensor.extract %79[%c3] : tensor<35x!qco.qubit>
    %80 = qco.h %result_109 : !qco.qubit -> !qco.qubit
    %81 = qtensor.insert %80 into %out_tensor_108[%c3] : tensor<35x!qco.qubit>
    %out_tensor_110, %result_111 = qtensor.extract %81[%c4] : tensor<35x!qco.qubit>
    %82 = qco.h %result_111 : !qco.qubit -> !qco.qubit
    %83 = qtensor.insert %82 into %out_tensor_110[%c4] : tensor<35x!qco.qubit>
    %out_tensor_112, %result_113 = qtensor.extract %83[%c5] : tensor<35x!qco.qubit>
    %84 = qco.h %result_113 : !qco.qubit -> !qco.qubit
    %85 = qtensor.insert %84 into %out_tensor_112[%c5] : tensor<35x!qco.qubit>
    %out_tensor_114, %result_115 = qtensor.extract %85[%c6] : tensor<35x!qco.qubit>
    %86 = qco.h %result_115 : !qco.qubit -> !qco.qubit
    %87 = qtensor.insert %86 into %out_tensor_114[%c6] : tensor<35x!qco.qubit>
    %out_tensor_116, %result_117 = qtensor.extract %87[%c7] : tensor<35x!qco.qubit>
    %88 = qco.h %result_117 : !qco.qubit -> !qco.qubit
    %89 = qtensor.insert %88 into %out_tensor_116[%c7] : tensor<35x!qco.qubit>
    %out_tensor_118, %result_119 = qtensor.extract %89[%c8] : tensor<35x!qco.qubit>
    %90 = qco.h %result_119 : !qco.qubit -> !qco.qubit
    %91 = qtensor.insert %90 into %out_tensor_118[%c8] : tensor<35x!qco.qubit>
    %out_tensor_120, %result_121 = qtensor.extract %91[%c9] : tensor<35x!qco.qubit>
    %92 = qco.h %result_121 : !qco.qubit -> !qco.qubit
    %93 = qtensor.insert %92 into %out_tensor_120[%c9] : tensor<35x!qco.qubit>
    %out_tensor_122, %result_123 = qtensor.extract %93[%c10] : tensor<35x!qco.qubit>
    %94 = qco.h %result_123 : !qco.qubit -> !qco.qubit
    %95 = qtensor.insert %94 into %out_tensor_122[%c10] : tensor<35x!qco.qubit>
    %out_tensor_124, %result_125 = qtensor.extract %95[%c11] : tensor<35x!qco.qubit>
    %96 = qco.h %result_125 : !qco.qubit -> !qco.qubit
    %97 = qtensor.insert %96 into %out_tensor_124[%c11] : tensor<35x!qco.qubit>
    %out_tensor_126, %result_127 = qtensor.extract %97[%c12] : tensor<35x!qco.qubit>
    %98 = qco.h %result_127 : !qco.qubit -> !qco.qubit
    %99 = qtensor.insert %98 into %out_tensor_126[%c12] : tensor<35x!qco.qubit>
    %out_tensor_128, %result_129 = qtensor.extract %99[%c13] : tensor<35x!qco.qubit>
    %100 = qco.h %result_129 : !qco.qubit -> !qco.qubit
    %101 = qtensor.insert %100 into %out_tensor_128[%c13] : tensor<35x!qco.qubit>
    %out_tensor_130, %result_131 = qtensor.extract %101[%c14] : tensor<35x!qco.qubit>
    %102 = qco.h %result_131 : !qco.qubit -> !qco.qubit
    %103 = qtensor.insert %102 into %out_tensor_130[%c14] : tensor<35x!qco.qubit>
    %out_tensor_132, %result_133 = qtensor.extract %103[%c15] : tensor<35x!qco.qubit>
    %104 = qco.h %result_133 : !qco.qubit -> !qco.qubit
    %105 = qtensor.insert %104 into %out_tensor_132[%c15] : tensor<35x!qco.qubit>
    %out_tensor_134, %result_135 = qtensor.extract %105[%c16] : tensor<35x!qco.qubit>
    %106 = qco.h %result_135 : !qco.qubit -> !qco.qubit
    %107 = qtensor.insert %106 into %out_tensor_134[%c16] : tensor<35x!qco.qubit>
    %out_tensor_136, %result_137 = qtensor.extract %107[%c17] : tensor<35x!qco.qubit>
    %108 = qco.h %result_137 : !qco.qubit -> !qco.qubit
    %109 = qtensor.insert %108 into %out_tensor_136[%c17] : tensor<35x!qco.qubit>
    %out_tensor_138, %result_139 = qtensor.extract %109[%c18] : tensor<35x!qco.qubit>
    %110 = qco.h %result_139 : !qco.qubit -> !qco.qubit
    %111 = qtensor.insert %110 into %out_tensor_138[%c18] : tensor<35x!qco.qubit>
    %out_tensor_140, %result_141 = qtensor.extract %111[%c19] : tensor<35x!qco.qubit>
    %112 = qco.h %result_141 : !qco.qubit -> !qco.qubit
    %113 = qtensor.insert %112 into %out_tensor_140[%c19] : tensor<35x!qco.qubit>
    %out_tensor_142, %result_143 = qtensor.extract %113[%c20] : tensor<35x!qco.qubit>
    %114 = qco.h %result_143 : !qco.qubit -> !qco.qubit
    %115 = qtensor.insert %114 into %out_tensor_142[%c20] : tensor<35x!qco.qubit>
    %out_tensor_144, %result_145 = qtensor.extract %115[%c21] : tensor<35x!qco.qubit>
    %116 = qco.h %result_145 : !qco.qubit -> !qco.qubit
    %117 = qtensor.insert %116 into %out_tensor_144[%c21] : tensor<35x!qco.qubit>
    %out_tensor_146, %result_147 = qtensor.extract %117[%c22] : tensor<35x!qco.qubit>
    %118 = qco.h %result_147 : !qco.qubit -> !qco.qubit
    %119 = qtensor.insert %118 into %out_tensor_146[%c22] : tensor<35x!qco.qubit>
    %out_tensor_148, %result_149 = qtensor.extract %119[%c23] : tensor<35x!qco.qubit>
    %120 = qco.h %result_149 : !qco.qubit -> !qco.qubit
    %121 = qtensor.insert %120 into %out_tensor_148[%c23] : tensor<35x!qco.qubit>
    %out_tensor_150, %result_151 = qtensor.extract %121[%c24] : tensor<35x!qco.qubit>
    %122 = qco.h %result_151 : !qco.qubit -> !qco.qubit
    %123 = qtensor.insert %122 into %out_tensor_150[%c24] : tensor<35x!qco.qubit>
    %out_tensor_152, %result_153 = qtensor.extract %123[%c25] : tensor<35x!qco.qubit>
    %124 = qco.h %result_153 : !qco.qubit -> !qco.qubit
    %125 = qtensor.insert %124 into %out_tensor_152[%c25] : tensor<35x!qco.qubit>
    %out_tensor_154, %result_155 = qtensor.extract %125[%c26] : tensor<35x!qco.qubit>
    %126 = qco.h %result_155 : !qco.qubit -> !qco.qubit
    %127 = qtensor.insert %126 into %out_tensor_154[%c26] : tensor<35x!qco.qubit>
    %out_tensor_156, %result_157 = qtensor.extract %127[%c27] : tensor<35x!qco.qubit>
    %128 = qco.h %result_157 : !qco.qubit -> !qco.qubit
    %129 = qtensor.insert %128 into %out_tensor_156[%c27] : tensor<35x!qco.qubit>
    %out_tensor_158, %result_159 = qtensor.extract %129[%c28] : tensor<35x!qco.qubit>
    %130 = qco.h %result_159 : !qco.qubit -> !qco.qubit
    %131 = qtensor.insert %130 into %out_tensor_158[%c28] : tensor<35x!qco.qubit>
    %out_tensor_160, %result_161 = qtensor.extract %131[%c29] : tensor<35x!qco.qubit>
    %132 = qco.h %result_161 : !qco.qubit -> !qco.qubit
    %133 = qtensor.insert %132 into %out_tensor_160[%c29] : tensor<35x!qco.qubit>
    %out_tensor_162, %result_163 = qtensor.extract %133[%c30] : tensor<35x!qco.qubit>
    %134 = qco.h %result_163 : !qco.qubit -> !qco.qubit
    %135 = qtensor.insert %134 into %out_tensor_162[%c30] : tensor<35x!qco.qubit>
    %out_tensor_164, %result_165 = qtensor.extract %135[%c31] : tensor<35x!qco.qubit>
    %136 = qco.h %result_165 : !qco.qubit -> !qco.qubit
    %137 = qtensor.insert %136 into %out_tensor_164[%c31] : tensor<35x!qco.qubit>
    %out_tensor_166, %result_167 = qtensor.extract %137[%c32] : tensor<35x!qco.qubit>
    %138 = qco.h %result_167 : !qco.qubit -> !qco.qubit
    %139 = qtensor.insert %138 into %out_tensor_166[%c32] : tensor<35x!qco.qubit>
    %out_tensor_168, %result_169 = qtensor.extract %139[%c33] : tensor<35x!qco.qubit>
    %140 = qco.h %result_169 : !qco.qubit -> !qco.qubit
    %141 = qtensor.insert %140 into %out_tensor_168[%c33] : tensor<35x!qco.qubit>
    %out_tensor_170, %result_171 = qtensor.extract %141[%c34] : tensor<35x!qco.qubit>
    %142 = qco.h %result_171 : !qco.qubit -> !qco.qubit
    %143 = qtensor.insert %142 into %out_tensor_170[%c34] : tensor<35x!qco.qubit>
    %out_tensor_172, %result_173 = qtensor.extract %143[%c0] : tensor<35x!qco.qubit>
    %qubit_out, %result_174 = qco.measure %result_173 : !qco.qubit
    %144 = qtensor.insert %qubit_out into %out_tensor_172[%c0] : tensor<35x!qco.qubit>
    cbit.store %result_174, %1[%c0] : !cbit.reg<35>
    %out_tensor_175, %result_176 = qtensor.extract %144[%c1] : tensor<35x!qco.qubit>
    %qubit_out_177, %result_178 = qco.measure %result_176 : !qco.qubit
    %145 = qtensor.insert %qubit_out_177 into %out_tensor_175[%c1] : tensor<35x!qco.qubit>
    cbit.store %result_178, %1[%c1] : !cbit.reg<35>
    %out_tensor_179, %result_180 = qtensor.extract %145[%c2] : tensor<35x!qco.qubit>
    %qubit_out_181, %result_182 = qco.measure %result_180 : !qco.qubit
    %146 = qtensor.insert %qubit_out_181 into %out_tensor_179[%c2] : tensor<35x!qco.qubit>
    cbit.store %result_182, %1[%c2] : !cbit.reg<35>
    %out_tensor_183, %result_184 = qtensor.extract %146[%c3] : tensor<35x!qco.qubit>
    %qubit_out_185, %result_186 = qco.measure %result_184 : !qco.qubit
    %147 = qtensor.insert %qubit_out_185 into %out_tensor_183[%c3] : tensor<35x!qco.qubit>
    cbit.store %result_186, %1[%c3] : !cbit.reg<35>
    %out_tensor_187, %result_188 = qtensor.extract %147[%c4] : tensor<35x!qco.qubit>
    %qubit_out_189, %result_190 = qco.measure %result_188 : !qco.qubit
    %148 = qtensor.insert %qubit_out_189 into %out_tensor_187[%c4] : tensor<35x!qco.qubit>
    cbit.store %result_190, %1[%c4] : !cbit.reg<35>
    %out_tensor_191, %result_192 = qtensor.extract %148[%c5] : tensor<35x!qco.qubit>
    %qubit_out_193, %result_194 = qco.measure %result_192 : !qco.qubit
    %149 = qtensor.insert %qubit_out_193 into %out_tensor_191[%c5] : tensor<35x!qco.qubit>
    cbit.store %result_194, %1[%c5] : !cbit.reg<35>
    %out_tensor_195, %result_196 = qtensor.extract %149[%c6] : tensor<35x!qco.qubit>
    %qubit_out_197, %result_198 = qco.measure %result_196 : !qco.qubit
    %150 = qtensor.insert %qubit_out_197 into %out_tensor_195[%c6] : tensor<35x!qco.qubit>
    cbit.store %result_198, %1[%c6] : !cbit.reg<35>
    %out_tensor_199, %result_200 = qtensor.extract %150[%c7] : tensor<35x!qco.qubit>
    %qubit_out_201, %result_202 = qco.measure %result_200 : !qco.qubit
    %151 = qtensor.insert %qubit_out_201 into %out_tensor_199[%c7] : tensor<35x!qco.qubit>
    cbit.store %result_202, %1[%c7] : !cbit.reg<35>
    %out_tensor_203, %result_204 = qtensor.extract %151[%c8] : tensor<35x!qco.qubit>
    %qubit_out_205, %result_206 = qco.measure %result_204 : !qco.qubit
    %152 = qtensor.insert %qubit_out_205 into %out_tensor_203[%c8] : tensor<35x!qco.qubit>
    cbit.store %result_206, %1[%c8] : !cbit.reg<35>
    %out_tensor_207, %result_208 = qtensor.extract %152[%c9] : tensor<35x!qco.qubit>
    %qubit_out_209, %result_210 = qco.measure %result_208 : !qco.qubit
    %153 = qtensor.insert %qubit_out_209 into %out_tensor_207[%c9] : tensor<35x!qco.qubit>
    cbit.store %result_210, %1[%c9] : !cbit.reg<35>
    %out_tensor_211, %result_212 = qtensor.extract %153[%c10] : tensor<35x!qco.qubit>
    %qubit_out_213, %result_214 = qco.measure %result_212 : !qco.qubit
    %154 = qtensor.insert %qubit_out_213 into %out_tensor_211[%c10] : tensor<35x!qco.qubit>
    cbit.store %result_214, %1[%c10] : !cbit.reg<35>
    %out_tensor_215, %result_216 = qtensor.extract %154[%c11] : tensor<35x!qco.qubit>
    %qubit_out_217, %result_218 = qco.measure %result_216 : !qco.qubit
    %155 = qtensor.insert %qubit_out_217 into %out_tensor_215[%c11] : tensor<35x!qco.qubit>
    cbit.store %result_218, %1[%c11] : !cbit.reg<35>
    %out_tensor_219, %result_220 = qtensor.extract %155[%c12] : tensor<35x!qco.qubit>
    %qubit_out_221, %result_222 = qco.measure %result_220 : !qco.qubit
    %156 = qtensor.insert %qubit_out_221 into %out_tensor_219[%c12] : tensor<35x!qco.qubit>
    cbit.store %result_222, %1[%c12] : !cbit.reg<35>
    %out_tensor_223, %result_224 = qtensor.extract %156[%c13] : tensor<35x!qco.qubit>
    %qubit_out_225, %result_226 = qco.measure %result_224 : !qco.qubit
    %157 = qtensor.insert %qubit_out_225 into %out_tensor_223[%c13] : tensor<35x!qco.qubit>
    cbit.store %result_226, %1[%c13] : !cbit.reg<35>
    %out_tensor_227, %result_228 = qtensor.extract %157[%c14] : tensor<35x!qco.qubit>
    %qubit_out_229, %result_230 = qco.measure %result_228 : !qco.qubit
    %158 = qtensor.insert %qubit_out_229 into %out_tensor_227[%c14] : tensor<35x!qco.qubit>
    cbit.store %result_230, %1[%c14] : !cbit.reg<35>
    %out_tensor_231, %result_232 = qtensor.extract %158[%c15] : tensor<35x!qco.qubit>
    %qubit_out_233, %result_234 = qco.measure %result_232 : !qco.qubit
    %159 = qtensor.insert %qubit_out_233 into %out_tensor_231[%c15] : tensor<35x!qco.qubit>
    cbit.store %result_234, %1[%c15] : !cbit.reg<35>
    %out_tensor_235, %result_236 = qtensor.extract %159[%c16] : tensor<35x!qco.qubit>
    %qubit_out_237, %result_238 = qco.measure %result_236 : !qco.qubit
    %160 = qtensor.insert %qubit_out_237 into %out_tensor_235[%c16] : tensor<35x!qco.qubit>
    cbit.store %result_238, %1[%c16] : !cbit.reg<35>
    %out_tensor_239, %result_240 = qtensor.extract %160[%c17] : tensor<35x!qco.qubit>
    %qubit_out_241, %result_242 = qco.measure %result_240 : !qco.qubit
    %161 = qtensor.insert %qubit_out_241 into %out_tensor_239[%c17] : tensor<35x!qco.qubit>
    cbit.store %result_242, %1[%c17] : !cbit.reg<35>
    %out_tensor_243, %result_244 = qtensor.extract %161[%c18] : tensor<35x!qco.qubit>
    %qubit_out_245, %result_246 = qco.measure %result_244 : !qco.qubit
    %162 = qtensor.insert %qubit_out_245 into %out_tensor_243[%c18] : tensor<35x!qco.qubit>
    cbit.store %result_246, %1[%c18] : !cbit.reg<35>
    %out_tensor_247, %result_248 = qtensor.extract %162[%c19] : tensor<35x!qco.qubit>
    %qubit_out_249, %result_250 = qco.measure %result_248 : !qco.qubit
    %163 = qtensor.insert %qubit_out_249 into %out_tensor_247[%c19] : tensor<35x!qco.qubit>
    cbit.store %result_250, %1[%c19] : !cbit.reg<35>
    %out_tensor_251, %result_252 = qtensor.extract %163[%c20] : tensor<35x!qco.qubit>
    %qubit_out_253, %result_254 = qco.measure %result_252 : !qco.qubit
    %164 = qtensor.insert %qubit_out_253 into %out_tensor_251[%c20] : tensor<35x!qco.qubit>
    cbit.store %result_254, %1[%c20] : !cbit.reg<35>
    %out_tensor_255, %result_256 = qtensor.extract %164[%c21] : tensor<35x!qco.qubit>
    %qubit_out_257, %result_258 = qco.measure %result_256 : !qco.qubit
    %165 = qtensor.insert %qubit_out_257 into %out_tensor_255[%c21] : tensor<35x!qco.qubit>
    cbit.store %result_258, %1[%c21] : !cbit.reg<35>
    %out_tensor_259, %result_260 = qtensor.extract %165[%c22] : tensor<35x!qco.qubit>
    %qubit_out_261, %result_262 = qco.measure %result_260 : !qco.qubit
    %166 = qtensor.insert %qubit_out_261 into %out_tensor_259[%c22] : tensor<35x!qco.qubit>
    cbit.store %result_262, %1[%c22] : !cbit.reg<35>
    %out_tensor_263, %result_264 = qtensor.extract %166[%c23] : tensor<35x!qco.qubit>
    %qubit_out_265, %result_266 = qco.measure %result_264 : !qco.qubit
    %167 = qtensor.insert %qubit_out_265 into %out_tensor_263[%c23] : tensor<35x!qco.qubit>
    cbit.store %result_266, %1[%c23] : !cbit.reg<35>
    %out_tensor_267, %result_268 = qtensor.extract %167[%c24] : tensor<35x!qco.qubit>
    %qubit_out_269, %result_270 = qco.measure %result_268 : !qco.qubit
    %168 = qtensor.insert %qubit_out_269 into %out_tensor_267[%c24] : tensor<35x!qco.qubit>
    cbit.store %result_270, %1[%c24] : !cbit.reg<35>
    %out_tensor_271, %result_272 = qtensor.extract %168[%c25] : tensor<35x!qco.qubit>
    %qubit_out_273, %result_274 = qco.measure %result_272 : !qco.qubit
    %169 = qtensor.insert %qubit_out_273 into %out_tensor_271[%c25] : tensor<35x!qco.qubit>
    cbit.store %result_274, %1[%c25] : !cbit.reg<35>
    %out_tensor_275, %result_276 = qtensor.extract %169[%c26] : tensor<35x!qco.qubit>
    %qubit_out_277, %result_278 = qco.measure %result_276 : !qco.qubit
    %170 = qtensor.insert %qubit_out_277 into %out_tensor_275[%c26] : tensor<35x!qco.qubit>
    cbit.store %result_278, %1[%c26] : !cbit.reg<35>
    %out_tensor_279, %result_280 = qtensor.extract %170[%c27] : tensor<35x!qco.qubit>
    %qubit_out_281, %result_282 = qco.measure %result_280 : !qco.qubit
    %171 = qtensor.insert %qubit_out_281 into %out_tensor_279[%c27] : tensor<35x!qco.qubit>
    cbit.store %result_282, %1[%c27] : !cbit.reg<35>
    %out_tensor_283, %result_284 = qtensor.extract %171[%c28] : tensor<35x!qco.qubit>
    %qubit_out_285, %result_286 = qco.measure %result_284 : !qco.qubit
    %172 = qtensor.insert %qubit_out_285 into %out_tensor_283[%c28] : tensor<35x!qco.qubit>
    cbit.store %result_286, %1[%c28] : !cbit.reg<35>
    %out_tensor_287, %result_288 = qtensor.extract %172[%c29] : tensor<35x!qco.qubit>
    %qubit_out_289, %result_290 = qco.measure %result_288 : !qco.qubit
    %173 = qtensor.insert %qubit_out_289 into %out_tensor_287[%c29] : tensor<35x!qco.qubit>
    cbit.store %result_290, %1[%c29] : !cbit.reg<35>
    %out_tensor_291, %result_292 = qtensor.extract %173[%c30] : tensor<35x!qco.qubit>
    %qubit_out_293, %result_294 = qco.measure %result_292 : !qco.qubit
    %174 = qtensor.insert %qubit_out_293 into %out_tensor_291[%c30] : tensor<35x!qco.qubit>
    cbit.store %result_294, %1[%c30] : !cbit.reg<35>
    %out_tensor_295, %result_296 = qtensor.extract %174[%c31] : tensor<35x!qco.qubit>
    %qubit_out_297, %result_298 = qco.measure %result_296 : !qco.qubit
    %175 = qtensor.insert %qubit_out_297 into %out_tensor_295[%c31] : tensor<35x!qco.qubit>
    cbit.store %result_298, %1[%c31] : !cbit.reg<35>
    %out_tensor_299, %result_300 = qtensor.extract %175[%c32] : tensor<35x!qco.qubit>
    %qubit_out_301, %result_302 = qco.measure %result_300 : !qco.qubit
    %176 = qtensor.insert %qubit_out_301 into %out_tensor_299[%c32] : tensor<35x!qco.qubit>
    cbit.store %result_302, %1[%c32] : !cbit.reg<35>
    %out_tensor_303, %result_304 = qtensor.extract %176[%c33] : tensor<35x!qco.qubit>
    %qubit_out_305, %result_306 = qco.measure %result_304 : !qco.qubit
    %177 = qtensor.insert %qubit_out_305 into %out_tensor_303[%c33] : tensor<35x!qco.qubit>
    cbit.store %result_306, %1[%c33] : !cbit.reg<35>
    %out_tensor_307, %result_308 = qtensor.extract %177[%c34] : tensor<35x!qco.qubit>
    %qubit_out_309, %result_310 = qco.measure %result_308 : !qco.qubit
    %178 = qtensor.insert %qubit_out_309 into %out_tensor_307[%c34] : tensor<35x!qco.qubit>
    cbit.store %result_310, %1[%c34] : !cbit.reg<35>
    qco.sink %linearResults_101#1 : !qco.qubit
    qtensor.dealloc %178 : tensor<35x!qco.qubit>
    return %1 : !cbit.reg<35>
  }
}
