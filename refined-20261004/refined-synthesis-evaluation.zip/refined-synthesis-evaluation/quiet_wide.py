"""Run remaining wide cases only in intervals without compiler processes."""
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time
import sys
ROOT = Path(__file__).resolve().parent
EXCLUDED = ROOT/'excluded-wide-attempts'
EXCLUDED.mkdir(exist_ok=True)
events=json.loads((ROOT/'excluded-wide-attempts.json').read_text()) if '--resume' in sys.argv else []
def busy():
 return subprocess.run(['ps','-C','ld,ld.lld,clang,clang++,clang-tidy,cc1plus','-o','pid=,comm='],capture_output=True,text=True).stdout.strip()
def exclude(path, reason):
 if not path.exists():return
 destination=EXCLUDED/(path.name+'__'+str(time.time_ns()))
 shutil.move(path,destination)
 events.append({'case':path.name,'reason':reason,'directory':str(destination.relative_to(ROOT))})
 (ROOT/'excluded-wide-attempts.json').write_text(json.dumps(events,indent=2)+'\n')
if '--resume' not in sys.argv:
 for path in (ROOT/'final-results/pr2578').iterdir():
  if re.search(r'_(104|156)(_|__)',path.name):exclude(path,'Restarting entire wide group with compiler-activity detection')
manifest=json.loads((ROOT/'corpus/manifest.json').read_text())
for case in manifest['cases']:
 if case['qubits']<104:continue
 for target in case['targets']:
  path=ROOT/'final-results/pr2578'/(case['id']+'__'+target)
  if (path/'done.json').exists():continue
  while True:
   while busy():time.sleep(5)
   time.sleep(3)
   if busy():continue
   command=['python3',str(ROOT/'large.py'),'sweep','--output',str(ROOT/'final-results'),'--case','^'+re.escape(case['id'])+'$','--target','^'+re.escape(target)+'$','--repetitions','5']
   child=subprocess.Popen(command)
   activity=[]
   while child.poll() is None:
    load=busy()
    if load:activity.append({'time':time.time(),'compiler_processes':load})
    time.sleep(.5)
   if child.returncode:raise RuntimeError(f'Worker sweep failed: {command}')
   if activity:
    exclude(path,activity);print('Discarded overlapping build:',path.name,flush=True)
   else:break
print('Complete; excluded attempts:',len(events),flush=True)
