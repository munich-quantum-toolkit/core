"""Instrument the updated compiler separately from the timing sweep."""
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'core-synthesis-large-20261004'
PYTHON = '/home/nvidia/.codex/worktrees/pr2578-audit/core/.venv/bin/python'
cases = [
    ('core_qft_156', 'ibm_sxz_cz'),
    ('core_qft_156', 'ibm_fractional_bounded'),
    ('efficient_su2_156_symbolic', 'ibm_sxz_cz'),
    ('core_grover_54', 'iqm_r_cz'),
    ('pauli_layers_54_numeric', 'iqm_r_cz'),
]
for case, target in cases:
    stem = 'passes_' + case + '__' + target
    for extension in ('stdout', 'stderr'):
        source = OLD/'profiles'/(stem+'__pr2578.'+extension)
        destination = ROOT/'profiles'/(stem+'__previous.'+extension)
        if not destination.exists():
            shutil.copy2(source, destination)
    while True:
        while subprocess.run(['pgrep', '-x', r'ld|ld.lld|clang|clang\+\+|clang-tidy|cc1plus'], stdout=subprocess.DEVNULL).returncode == 0:
            time.sleep(5)
        with (ROOT/'profiles'/(stem+'__updated.stdout')).open('w') as out, (ROOT/'profiles'/(stem+'__updated.stderr')).open('w') as err:
            subprocess.run(['taskset', '-c', '5', PYTHON, str(ROOT/'large.py'), 'profile', '--case', case,
                            '--target', target, '--repetitions', '3', '--timing'], check=True,
                           stdout=out, stderr=err, env=os.environ | dict(QISKIT_NUM_PROCS='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1'))
        if subprocess.run(['pgrep', '-x', r'ld|ld.lld|clang|clang\+\+|clang-tidy|cc1plus'], stdout=subprocess.DEVNULL).returncode != 0:
            break
    print(case, target, flush=True)
