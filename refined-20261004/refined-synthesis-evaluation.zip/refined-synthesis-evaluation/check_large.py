"""Reject nonnative angles; accept canonical and specialized aliases."""
import math
from qiskit import QuantumCircuit
from qiskit.circuit import Gate
from large import native_check

def check(circuit,target):
    return native_check({},None,circuit,None,0,target)['passed']
q=QuantumCircuit(2);q.rx(math.pi/2,0);q.cz(0,1)
assert check(q,'rigetti_rx_cz')
q.rx(.123,0)
assert not check(q,'rigetti_rx_cz')
q=QuantumCircuit(2);q.append(Gate('gpi2',1,[.123]),[0]);q.rzz(.32,0,1)
assert check(q,'ionq_fixed_r_zz')
q=QuantumCircuit(2);q.rzz(.32,0,1)
assert check(q,'ibm_fractional_bounded')
q.rzz(-.2,0,1)
assert not check(q,'ibm_fractional_bounded')
print('Native contract checker: positive and negative cases passed')
