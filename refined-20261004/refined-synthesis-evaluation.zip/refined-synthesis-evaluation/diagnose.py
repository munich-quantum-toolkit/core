"""Separate diagnostics; excluded from benchmark timing samples."""
import argparse
import json
import math
from pathlib import Path
import statistics
import sys
import time
import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import Operator
import evaluate as h
from mqt.core.mlir import CompilerTarget as T,QCProgram,QCOProgram,TargetEnvironment,PayloadSpecification,PayloadFormat,CompilationOptions
ROOT=Path(__file__).resolve().parent

def environment(name,n):
    target=T(n,connectivity=T.Connectivity.all_to_all(),native_operations=T.NativeOperations([T.OperationCapability(**op) for op in h.targets()[name]]))
    return target,TargetEnvironment(target,PayloadSpecification(PayloadFormat('openqasm','3.0')))

def angle_scan(args):
    for target_name in ['iqm_r_cz','ibm_sxz_cz','rxrz_rzz_unbounded']:
        target,env=environment(target_name,2)
        for exponent in [8,16,18,19,20,21,24,30,40,46,47,48,50]:
            circuit=QuantumCircuit(2);angle=math.pi/2**exponent;circuit.cp(angle,0,1)
            program=QCProgram.from_qiskit(circuit).to_qco();program.synthesize_for_target(env,options=CompilationOptions(seed=h.SEED))
            out=program.to_qiskit(target=target)
            difference=Operator.from_circuit(out).data-Operator(circuit).data
            print(json.dumps(dict(target=target_name,exponent=exponent,angle=angle,max_matrix_error=float(np.max(np.abs(difference))),operator_norm_error=float(np.linalg.norm(difference,ord=2)),**h.counts(out))),flush=True)

def semantic(args):
    import importlib
    case=next(c for c in json.loads((ROOT/'corpus/manifest.json').read_text())['cases'] if c['id']==args.case)
    instance=getattr(importlib.import_module(case['benchmark_module']),case['benchmark_class']).from_instance_specification_json(json.dumps(case['instance_specification']))
    target,env=environment(args.target,case['qubits'])
    program=QCOProgram.from_mlir_file(ROOT/'corpus'/case['input']);program.synthesize_for_target(env,options=CompilationOptions(seed=h.SEED))
    start=time.monotonic();samples=program.sample(shots=128,seed=h.SEED)
    impossible={s:n for s,n in samples.items() if instance.probability(s)==0}
    result=dict(case=args.case,target=args.target,shots=128,unique_outcomes=len(samples),impossible_outcomes=impossible,simulation_seconds=time.monotonic()-start,kind='reference_support_check',passed=not impossible)
    if case['family']=='ghz':
        result.update(h.distribution_check(samples,{'0'*case['qubits']:.5,'1'*case['qubits']:.5}))
    if case['family']=='w_state':
        n=case['qubits'];result.update(h.distribution_check(samples,{format(1<<i,f'0{n}b'):1/n for i in range(n)}))
    print(json.dumps(result),flush=True)


def frame_probe(args):
    for width in [3,54,156]:
        target,env=environment('ibm_sxz_cz',width)
        circuit=QuantumCircuit(width)
        angle_sum=0.
        for i in range(1,width):
            angle=.13+i*.001;angle_sum+=angle
            circuit.rz(angle,0);circuit.cz(0,i)
        program=QCProgram.from_qiskit(circuit).to_qco();program.synthesize_for_target(env,options=CompilationOptions(seed=h.SEED))
        out=program.to_qiskit(target=target)
        result=dict(qubits=width,**h.counts(out),commuted_reference_1q=1,commuted_reference_2q=width-1)
        if width==3:
            reference=QuantumCircuit(width);reference.rz(angle_sum,0)
            for i in range(1,width):reference.cz(0,i)
            result['commuted_matrix_error']=float(np.max(np.abs(Operator(reference).data-Operator(circuit).data)))
            result['compiled_matrix_error']=float(np.max(np.abs(Operator.from_circuit(out).data-Operator(circuit).data)))
        print(json.dumps(result),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['angle_scan','semantic','frame_probe']);p.add_argument('--case');p.add_argument('--target');args=p.parse_args();globals()[args.command](args)
