import json,sys
from pathlib import Path
sys.path.insert(0,'/home/nvidia/.codex/experiments/core-synthesis-cleanup-20261004')
import diagnose
from mqt.core.mlir import QCProgram,CompilationOptions
from qiskit import QuantumCircuit
from qiskit.circuit import Parameter
from qiskit.quantum_info import Operator
import numpy as np
for gate in ['cp','crz','rzz']:
 for reverse in [False,True]:
  for barrier in [False,True]:
   a,b=Parameter('a'),Parameter('b')
   circuit=QuantumCircuit(3)
   getattr(circuit,gate)(a,0,1);circuit.rzz(b,1,2)
   if barrier:circuit.barrier(0)
   else:circuit.rz(b,0)
   getattr(circuit,gate)(-a,*( [1,0] if reverse else [0,1]))
   for target_name in ['iqm_r_cz','ibm_fractional_bounded','rxrz_rzz_unbounded']:
    target,env=diagnose.environment(target_name,3)
    program=QCProgram.from_qiskit(circuit).to_qco();program.synthesize_for_target(env,options=CompilationOptions(seed=2578));out=program.to_qiskit(target=target)
    errors=[]
    for av,bv in [(.31,-.43),(-7.1,2.4)]:
     bind={a:av,b:bv};errors.append(float(np.max(np.abs(Operator(out.assign_parameters(bind,strict=False)).data-Operator(circuit.assign_parameters(bind)).data))))
    assert max(errors)<1e-12,(gate,reverse,barrier,target_name,errors)
    print(json.dumps(dict(gate=gate,reverse=reverse,barrier=barrier,target=target_name,entanglers=sum(i.operation.num_qubits==2 for i in out.data),max_error=max(errors))),flush=True)
