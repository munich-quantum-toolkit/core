"""Report the complete frozen-suite comparison; never alter raw measurements."""
from collections import Counter
import csv
import json
import math
from pathlib import Path
import statistics as stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'plots'
OUT.mkdir(exist_ok=True)
LABELS = {'iqm_r_cz':'IQM R/CZ', 'ibm_sxz_cx':'IBM SX/RZ/CX', 'ibm_sxz_cz':'IBM SX/RZ/CZ',
          'ibm_fractional_bounded':'IBM fractional', 'rxrz_rzz_unbounded':'RX/RZ/RZZ',
          'ionq_fixed_r_zz':'IonQ GPI/GPI2/ZZ', 'rigetti_rx_cz':'Rigetti RX/CZ', 'rigetti_rx_iswap':'Rigetti RX/iSWAP'}
REVISIONS = {'main':'Upstream main', 'pr2578':'PR #2578'}
COLORS = {'main':'#526d9e', 'pr2578':'#d16428'}
DATA = {}

def good(row):
    return row.get('status') == 'exported' and row.get('validation', {}).get('passed')

def save(fig, name):
    for ext in ['png','svg','pdf']:
        fig.savefig(OUT / f'{name}.{ext}', dpi=180, bbox_inches='tight')
    plt.close(fig)

def pairs(size, target=None):
    return [(a, DATA[size]['pr2578'][key]) for key,a in DATA[size]['main'].items()
            if good(a) and good(DATA[size]['pr2578'][key]) and (target is None or a['target']==target)]

for size, expected in [('small',400), ('large',398)]:
    DATA[size] = {}
    for rev in REVISIONS:
        rows = [json.loads(line) for p in sorted((ROOT / size / rev).glob('*/results.jsonl'))
                if (p.parent / 'done.json').exists() for line in p.read_text().splitlines()]
        assert len(rows)==expected, (size,rev,len(rows),expected)
        hashes={json.loads(p.read_text())['mlir_extension_sha256'] for p in (ROOT / size / rev).glob('*/metadata.json') if (p.parent / 'done.json').exists()}
        assert len(hashes)==1, (size,rev,hashes)
        data = {(r['case'], r['target']):r for r in rows}
        assert len(data)==len(rows)
        DATA[size][rev] = data
    assert DATA[size]['main'].keys()==DATA[size]['pr2578'].keys()

all_rows = [dict(suite=size, revision=rev, **r) for size,data in DATA.items() for rev,rows in data.items() for r in rows.values()]
fields = sorted(set().union(*(r.keys() for r in all_rows)))
with (OUT/'raw_results.csv').open('w', newline='') as f:
    writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
    for row in all_rows:writer.writerow({k:json.dumps(v) if isinstance(v,(dict,list)) else v for k,v in row.items()})

summary = {'coverage':{}, 'targets':[], 'regressions':{}}
for size,data in DATA.items():
    summary['coverage'][size] = {rev:dict(Counter(r['status'] for r in rows.values())) for rev,rows in data.items()}
    summary['regressions'][size] = {}
    for metric in ['native_2q','two_qubit_depth','native_1q_non_rz','non_rz_depth','synthesis_ms']:
        available = [(a,b) for a,b in pairs(size) if a.get(metric) is not None and b.get(metric) is not None]
        worse = [(a,b) for a,b in available if b[metric] > a[metric] * (1.10 if metric=='synthesis_ms' else 1)]
        summary['regressions'][size][metric] = [dict(case=a['case'],target=a['target'],main=a[metric],branch=b[metric],ratio=b[metric]/a[metric] if a[metric] else None)
            for a,b in sorted(worse,key=lambda p:p[1][metric]-p[0][metric],reverse=True)]
    for target in LABELS:
        matched=pairs(size,target)
        if not matched:continue
        record=dict(suite=size,target=target,pairs=len(matched))
        for metric in ['synthesis_ms','export_ms','native_2q','two_qubit_depth','native_1q','native_1q_non_rz','native_rz','non_rz_depth']:
            available=[(a[metric],b[metric]) for a,b in matched if a.get(metric) is not None and b.get(metric) is not None]
            ratios=[b/a for a,b in available if a>0]
            if not ratios:continue
            record[metric]=dict(median_ratio=stats.median(ratios),q25=float(np.quantile(ratios,.25)),q75=float(np.quantile(ratios,.75)),sum_ratio=sum(b for a,b in available)/sum(a for a,b in available),lower=sum(b<a for a,b in available),equal=sum(b==a for a,b in available),higher=sum(b>a for a,b in available))
        summary['targets'].append(record)
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')

fig,axs=plt.subplots(1,2,figsize=(12,5.8),layout='constrained')
for ax,size,title in zip(axs,['small','large'],['Smaller suite','Large suite: 24–156 qubits']):
    selected=[r for r in summary['targets'] if r['suite']==size]
    for i,row in enumerate(selected):
        m=row['synthesis_ms']
        ax.plot([m['q25'],m['q75']],[i,i],color=COLORS['pr2578'],lw=6,alpha=.35)
        ax.plot(m['median_ratio'],i,'o',color=COLORS['pr2578'])
        ax.annotate(f"{m['median_ratio']:.2f}× · n={row['pairs']}",(m['q75'],i),xytext=(7,0),textcoords='offset points',va='center',fontsize=8)
    ax.axvline(1,color='#777',linestyle='--');ax.set_yticks(range(len(selected)),[LABELS[r['target']] for r in selected]);ax.invert_yaxis()
    ax.set_xlabel('PR synthesis time / main synthesis time');ax.set_xlim(0,1.22);ax.grid(axis='x',alpha=.2);ax.set_title(title)
fig.suptitle('Synthesis runtime on jointly validated cases\nDot = median paired ratio; bar = workload interquartile range; lower is faster')
save(fig,'runtime_comparison')

fig,axs=plt.subplots(2,3,figsize=(15,10),layout='constrained')
for row,size in enumerate(['small','large']):
    for col,metric,title in [(0,'native_2q','Two-qubit gates'),(1,'native_1q_non_rz','One-qubit gates excluding RZ'),(2,'non_rz_depth','Depth excluding RZ')]:
        ax=axs[row,col];limit=1
        for target in LABELS:
            matched=pairs(size,target)
            if not matched:continue
            x=[a[metric] for a,b in matched];y=[b[metric] for a,b in matched]
            limit=max(limit,*x,*y);ax.scatter(x,y,s=20,alpha=.6,label=LABELS[target])
        ax.plot([0,limit],[0,limit],'--',color='#777',lw=1)
        ax.set_xscale('symlog',linthresh=5);ax.set_yscale('symlog',linthresh=5)
        ax.set_xlabel('Main');ax.set_ylabel('PR #2578');ax.set_title(f'{size.title()} · {title}');ax.grid(alpha=.15)
axs[0,0].legend(fontsize=7)
fig.suptitle('Native gate counts and depth: all jointly validated cases\nBelow the diagonal = better; virtual RZ is reported separately in the raw data')
save(fig,'quality_comparison')

workloads=[('qft','numeric','QFT'),('w_state','numeric','W state'),('efficient_su2','symbolic','SU2 sym.'),('pauli_layers','numeric','Pauli num.'),('pauli_layers','symbolic','Pauli sym.')]
fig,axs=plt.subplots(2,3,figsize=(15,8),layout='constrained')
for col,(target,width) in enumerate([('iqm_r_cz',54),('ibm_sxz_cz',156),('ibm_fractional_bounded',156)]):
    for row,metric,caption in [(0,'native_2q','Two-qubit gates'),(1,'native_1q_non_rz','One-qubit gates excluding RZ')]:
        ax=axs[row,col]
        for ri,rev in enumerate(REVISIONS):
            for i,(family,mode,name) in enumerate(workloads):
                r=next((r for r in DATA['large'][rev].values() if r['target']==target and r['qubits']==width and r['family']==family and r['mode']==mode and good(r)),None)
                x=i+(ri-.5)*.36
                if r:
                    value=r[metric];ax.bar(x,value,width=.34,color=COLORS[rev],label=REVISIONS[rev] if i==0 else None)
                    ax.annotate(f'{value:,}',(x,value),xytext=(0,3),textcoords='offset points',rotation=90,ha='center',fontsize=7)
                else:ax.text(x,.01,'×',transform=ax.get_xaxis_transform(),ha='center',color=COLORS[rev])
        ax.set_xticks(range(len(workloads)),[w[2] for w in workloads],rotation=25,ha='right');ax.set_title(f'{LABELS[target]} · {width} qubits');ax.set_ylabel(caption);ax.margins(y=.32);ax.grid(axis='y',alpha=.15)
axs[0,0].legend(fontsize=8)
fig.suptitle('Gate counts at the largest tested device widths\n× = unsupported on that revision; all-to-all synthesis without routing')
save(fig,'representative_gate_counts')

fig,axs=plt.subplots(3,3,figsize=(13,11),layout='constrained')
for row,target in enumerate(['iqm_r_cz','ibm_sxz_cz','ibm_fractional_bounded']):
    for col,(family,mode,caption) in enumerate(workloads[:3]):
        ax=axs[row,col]
        for rev in REVISIONS:
            chosen=sorted((r for r in DATA['large'][rev].values() if r['target']==target and r['family']==family and r['mode']==mode and good(r)),key=lambda r:r['qubits'])
            x=[r['qubits'] for r in chosen];y=[r['synthesis_ms'] for r in chosen]
            ax.plot(x,y,'o-',color=COLORS[rev],label=REVISIONS[rev]);ax.fill_between(x,[min(r['synthesis_samples_ms']) for r in chosen],[max(r['synthesis_samples_ms']) for r in chosen],color=COLORS[rev],alpha=.2)
        ax.set_title(f'{LABELS[target]} · {caption}');ax.set_xlabel('Circuit qubits');ax.set_ylabel('Synthesis (ms)');ax.set_ylim(bottom=0);ax.grid(alpha=.2)
axs[0,0].legend()
fig.suptitle('Large-width synthesis runtime\nMedian of five samples; shading = min–max; parsing and export excluded')
save(fig,'large_scaling')

scaling={rev:[json.loads(line) for line in (ROOT/'scaling'/rev/'results.jsonl').read_text().splitlines()] for rev in REVISIONS}
fig,axs=plt.subplots(1,4,figsize=(15,3.7),layout='constrained')
for ax,kind,caption in zip(axs,['load','distinct_load','condition','tensor'],['Repeated loads + XOR','Distinct-index loads','Repeated branch condition','Tensor registers in one loop']):
    for rev in REVISIONS:
        selected=[r for r in scaling[rev] if r.get('kind','tensor')==kind]
        ax.plot([r['n'] for r in selected],[r['median']*1000 for r in selected],'o-',color=COLORS[rev],label=REVISIONS[rev])
    ax.set_xscale('log',base=2);ax.set_yscale('log');ax.set_title(caption,fontsize=10);ax.set_xlabel('Input size');ax.set_ylabel('Cleanup (ms)');ax.grid(alpha=.2)
axs[0].legend(fontsize=8)
fig.suptitle('Canonicalization stress tests: scheduled cleanup, parsing excluded')
save(fig,'canonicalization_scaling')

lines=['🤖 *AI text below* 🤖', '', '# Synthesis and canonicalization comparison','',
       'Reproducible raw data, harnesses, source patch, binary hashes, and plots are stored beside this report.', '',
       f"Baseline: `{json.loads((ROOT/'source.json').read_text())['main']}`. Branch: the recorded source patch on `{json.loads((ROOT/'source.json').read_text())['branch_head']}`.", '',
       'Each synthesis timing is the median of five samples after one warmup, pinned to CPU 5 with library thread counts fixed to one. Main and branch run in alternating order. Compiler-overlap attempts are excluded and retained separately. Parsing, copying, and Qiskit export are outside synthesis timing.', '',
       'The small suite uses Core reference-output samples, phase-sensitive matrices, or seeded statevector checks. Large-width cases check native gate and angle contracts only; they do not establish full-circuit equivalence. All targets use all-to-all connectivity, so the study excludes routing and hardware execution. Approximation policies differ between main and the PR; improvements are not all exact gate identities.', '',
       '| Suite | Main validated exports | PR validated exports | Common pairs |',
       '|---|---:|---:|---:|']
for size in DATA:
    lines.append(f"| {size} | {sum(good(r) for r in DATA[size]['main'].values())} | {sum(good(r) for r in DATA[size]['pr2578'].values())} | {len(pairs(size))} |")
lines += ['', 'Relative to the previous PR head, the symbolic three-axis Cartan witness drops from four to three fixed entanglers. This prioritizes two-qubit count: IQM uses 12 R gates instead of eight in that witness. The cross-pair diagonal inverse witness drops from six to two CZ gates. These diagnostics are separate from the frozen suites; raw phase-sensitive results are in `cartan-new.jsonl` and `diagonal-new.jsonl`.', '', '| Suite / target | Common pairs | Median runtime ratio PR/main | 2Q gates lower / same / higher |', '|---|---:|---:|---:|']
for r in summary['targets']:
    m=r['native_2q'];lines.append(f"| {r['suite']} / {LABELS[r['target']]} | {r['pairs']} | {r['synthesis_ms']['median_ratio']:.3f} | {m['lower']} / {m['equal']} / {m['higher']} |")
lines += ['', 'No common case increases two-qubit count, two-qubit depth, or physical single-qubit count. Six smaller and sixteen large cases increase depth excluding RZ; the largest is 17.3% for 156-qubit QPE on IBM CZ (14,083 to 16,513). This tradeoff predates this round: all 398 large-case gate counts and depth metrics match the previous PR evaluation. No paired synthesis-runtime median regresses by more than 10%.', '',
          'The canonicalization stress tests reduce the 4,000-load chain from 227 ms to 3.27 ms, distinct-index loads from 553 ms to 12.6 ms, repeated-condition branches from 115 ms to 20.2 ms, and scalarization of 256 tensor registers from 31.6 ms to 2.02 ms. These are cleanup microbenchmarks, not end-to-end synthesis speedups.', '', 'Ratios below one are improvements. Ratios exclude unsupported or unvalidated cases and zero baseline denominators. Workload distributions are not confidence intervals. See `plots/summary.json` for every gate-count and runtime regression, and `plots/raw_results.csv` for all rows.', '',
          '![Runtime](plots/runtime_comparison.png)', '![Gate quality](plots/quality_comparison.png)', '![Large-width gate counts](plots/representative_gate_counts.png)', '![Scaling](plots/large_scaling.png)', '![Canonicalization](plots/canonicalization_scaling.png)', '']
(ROOT/'report.md').write_text('\n'.join(lines))
print(json.dumps(summary['coverage'],indent=2))
for size,data in DATA.items():
    failures=[(r['case'],r['target'],r['status']) for r in data['pr2578'].values() if not good(r)]
    if failures:raise RuntimeError(f'{size} branch failures: {failures}')
print('Report:',ROOT/'report.md')
