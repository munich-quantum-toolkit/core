import sys,json
sys.path.insert(0,'/home/nvidia/.codex/experiments/core-synthesis-cleanup-20261004')
import diagnose
from qiskit import QuantumCircuit
from qiskit.circuit import Parameter
from qiskit.quantum_info import Operator
from mqt.core.mlir import QCProgram,CompilationOptions
import numpy as np
for symbolic in [False,True]:
    params=[Parameter(s) for s in 'abc'] if symbolic else [.21,.34,.47]
    qc=QuantumCircuit(2);qc.rxx(params[0],0,1);qc.ryy(params[1],0,1);qc.rzz(params[2],0,1)
    for name in ['iqm_r_cz','ibm_sxz_cz','ibm_sxz_cx','rxrz_rzz_unbounded','ibm_fractional_bounded','rigetti_rx_iswap']:
        target,env=diagnose.environment(name,2)
        program=QCProgram.from_qiskit(qc).to_qco();program.synthesize_for_target(env,options=CompilationOptions(seed=2578));out=program.to_qiskit(target=target)
        binds={p:dict(zip('abc',[.21,.34,.47]))[p.name] for p in out.parameters};bound=out.assign_parameters(binds)
        expected=qc.assign_parameters({p:dict(zip('abc',[.21,.34,.47]))[p.name] for p in qc.parameters})
        error=float(np.max(np.abs(Operator.from_circuit(bound).data-Operator(expected).data)))
        print(json.dumps(dict(symbolic=symbolic,target=name,gates=dict(out.count_ops()),entanglers=sum(i.operation.num_qubits==2 for i in out.data),matrix_error=error)),flush=True)
