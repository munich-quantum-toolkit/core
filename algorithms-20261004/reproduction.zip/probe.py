from pathlib import Path
import json,time,statistics,sys,hashlib,os
import mqt.core.mlir as mlir
from mqt.core.mlir import QCOProgram,QCProgram,CompilationOptions
sys.path.insert(0,'/home/nvidia/.codex/experiments/core-synthesis-cleanup-20261004')
import diagnose
from qiskit import QuantumCircuit
from qiskit.circuit import Parameter
from qiskit.quantum_info import Operator
import numpy as np
ROOT=Path(__file__).resolve().parent

def source(kind,n):
    if kind=='load':
        lines=['module { func.func @main(%a: !cbit.reg<1>, %b: !cbit.reg<1>, %i: index) -> i1 attributes {mqt.entry_point} {']
        for i in range(n):
            reg='a' if i%2==0 else 'b'
            lines.append(f'%v{i} = cbit.load %{reg}[%i] : !cbit.reg<1>')
            if i>0:lines.append(f'%s{i} = arith.xori '+('%v0' if i==1 else f'%s{i-1}')+f', %v{i} : i1')
        lines.append(f'return %s{n-1} : i1 }} }}')
    else:
        lines=['module { func.func @main(%c: i1, %q0: !qco.qubit) -> !qco.qubit attributes {mqt.entry_point} {']
        for i in range(n):
            lines.append(f'%q{i+1} = qco.if %c args(%t{i} = %q{i}) -> !qco.qubit {{ %x{i} = qco.x %t{i} : !qco.qubit -> !qco.qubit qco.yield %x{i} : !qco.qubit }} else args(%e{i} = %q{i}) {{ %z{i} = qco.z %e{i} : !qco.qubit -> !qco.qubit qco.yield %z{i} : !qco.qubit }}')
        lines.append(f'return %q{n} : !qco.qubit }} }}')
    return '\n'.join(lines)

def scaling():
    meta=dict(binary=mlir.__file__,binary_sha256=hashlib.sha256(Path(mlir.__file__).read_bytes()).hexdigest(),affinity=sorted(os.sched_getaffinity(0)))
    (ROOT/'metadata.json').write_text(json.dumps(meta,indent=2))
    for kind in ['load','condition']:
        for n in [500,1000,2000,4000]:
            text=source(kind,n)
            for patterns in ['all','filtered']:
                samples=[]
                pipeline='canonicalize{top-down=false max-iterations=-1'+(' filter-dialects=arith,func' if patterns=='filtered' else '')+'}'
                for _ in range(4):
                    program=QCOProgram.from_mlir_str(text)
                    start=time.perf_counter();program.run_pass_pipeline(pipeline);elapsed=time.perf_counter()-start
                    samples.append(elapsed)
                result=dict(kind=kind,n=n,patterns=patterns,samples=samples[1:],median=statistics.median(samples[1:]),output_count=program.ir.count('cbit.load' if kind=='load' else 'qco.if'))
                print(json.dumps(result),flush=True)

def scalarization():
    for n in [16,32,64,128,256]:
        t='tensor<1x!qco.qubit>'
        types=', '.join([t]*n)
        args=', '.join(f'%a{i}: {t}' for i in range(n))
        inits=', '.join(f'%t{i} = %a{i}' for i in range(n))
        lines=[f'module {{ func.func @main(%limit: index, {args}) -> ({types}) attributes {{mqt.entry_point}} {{', '%c0 = arith.constant 0 : index','%c1 = arith.constant 1 : index', f'%out:{n} = scf.for %iv = %c0 to %limit step %c1 iter_args({inits}) -> ({types}) {{']
        for i in range(n):
            lines.extend([f'%rest{i}, %q{i} = qtensor.extract %t{i}[%c0] : {t}', f'%x{i} = qco.x %q{i} : !qco.qubit -> !qco.qubit', f'%new{i} = qtensor.insert %x{i} into %rest{i}[%c0] : {t}'])
        lines += ['scf.yield '+', '.join(f'%new{i}' for i in range(n))+f' : {types}', '}', 'return '+', '.join(f'%out#{i}' for i in range(n))+f' : {types}', '}}']
        text='\n'.join(lines)
        samples=[]
        for _ in range(4):
            program=QCOProgram.from_mlir_str(text)
            start=time.perf_counter();program.run_pass_pipeline('canonicalize{top-down=false max-iterations=-1}');samples.append(time.perf_counter()-start)
        print(json.dumps(dict(n=n,median=statistics.median(samples[1:]),samples=samples[1:],tensor_extracts=program.ir.count('qtensor.extract'),loops=program.ir.count('scf.for'))),flush=True)

def witness():
    for symbolic in [False,True]:
        a=Parameter('a') if symbolic else .31;b=Parameter('b') if symbolic else .43
        circuit=QuantumCircuit(3);circuit.rzz(a,0,1);circuit.rzz(b,1,2);circuit.rzz(-a,0,1)
        reference=QuantumCircuit(3);reference.rzz(b,1,2)
        for name in ['iqm_r_cz','ibm_sxz_cz','rxrz_rzz_unbounded','ibm_fractional_bounded']:
            target,env=diagnose.environment(name,3)
            results=[]
            for c in [circuit,reference]:
                program=QCProgram.from_qiskit(c).to_qco();program.synthesize_for_target(env,options=CompilationOptions(seed=2578));out=program.to_qiskit(target=target)
                bound={p:(.31 if p.name=='a' else .43) for p in out.parameters}
                expected=c.assign_parameters({p:(.31 if p.name=='a' else .43) for p in c.parameters})
                error=float(np.max(np.abs(Operator.from_circuit(out.assign_parameters(bound)).data-Operator(expected).data)))
                results.append(dict(gates=dict(out.count_ops()),entanglers=sum(inst.operation.num_qubits==2 for inst in out.data),matrix_error=error))
            print(json.dumps(dict(symbolic=symbolic,target=name,original=results[0],commuted_reference=results[1])),flush=True)
if __name__=='__main__':globals()[sys.argv[1]]()
