"""Repeat the canonicalization stress inputs with the scheduled replacement pass."""
import contextlib
import hashlib
import json
import os
from pathlib import Path
import statistics
import sys
import time

sys.path.insert(0, '/home/nvidia/.codex/experiments/core-algorithmic-audit-20261004')
import probe
from mqt.core.mlir import QCOProgram
import mqt.core.mlir as mlir

root = Path(__file__).resolve().parent
revision = sys.argv[1]
output = root / 'scaling' / revision
output.mkdir(parents=True, exist_ok=True)
metadata = dict(binary=mlir.__file__, binary_sha256=hashlib.sha256(Path(mlir.__file__).read_bytes()).hexdigest(), affinity=sorted(os.sched_getaffinity(0)))
(output / 'metadata.json').write_text(json.dumps(metadata, indent=2))
with (output / 'results.jsonl').open('w') as stream, contextlib.redirect_stdout(stream):
    for kind in ['load', 'distinct_load', 'condition']:
        for n in [500, 1000, 2000, 4000]:
            if kind == 'distinct_load':
                lines = [f'module {{ func.func @main(%reg: !cbit.reg<{n}>) -> i1 attributes {{mqt.entry_point}} {{']
                for i in range(n):
                    lines += [f'%i{i} = arith.constant {i} : index', f'%v{i} = cbit.load %reg[%i{i}] : !cbit.reg<{n}>']
                    if i:
                        previous = '%v0' if i == 1 else f'%s{i-1}'
                        lines += [f'%s{i} = arith.xori {previous}, %v{i} : i1']
                lines += [f'return %s{n-1} : i1', '}}']
                source = '\n'.join(lines)
            else:
                source = probe.source(kind, n)
            pipeline = ('simplify-classical-control,' if revision == 'pr2578' else '') + 'canonicalize{top-down=' + ('true' if revision == 'pr2578' else 'false') + ' max-iterations=-1}'
            samples = []
            for _ in range(6):
                program = QCOProgram.from_mlir_str(source)
                start = time.perf_counter()
                program.run_pass_pipeline(pipeline)
                samples.append(time.perf_counter() - start)
            print(json.dumps(dict(kind=kind, n=n, median=statistics.median(samples[1:]), samples=samples[1:], output_count=program.ir.count('qco.if' if kind == 'condition' else 'cbit.load'))), flush=True)
    probe.scalarization()
