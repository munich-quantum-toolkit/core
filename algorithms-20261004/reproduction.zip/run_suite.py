"""Repeat the frozen small and large suites without overlapping compiler work."""
import json,os,re,shutil,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CHECKOUTS={'main':Path('/home/nvidia/.codex/experiments/core-synthesis-20261003/main'),
           'pr2578':Path('/home/nvidia/.codex/worktrees/pr2578-audit/core')}
ENV=os.environ|dict(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',QISKIT_NUM_PROCS='1')
def busy():
 return subprocess.run(['ps','-C','ld,ld.lld,clang,clang++,clang-tidy,cc1plus','-o','pid=,comm='],capture_output=True,text=True).stdout.strip()
def run(command,path):
 if (path/'done.json').exists():return
 while True:
  while busy():time.sleep(2)
  path.mkdir(parents=True,exist_ok=True)
  activity=[];start=time.monotonic()
  with (path/'stdout.log').open('w') as out,(path/'stderr.log').open('w') as err:
   proc=subprocess.Popen(command,env=ENV,stdout=out,stderr=err)
   while proc.poll() is None:
    if active:=busy():activity.append(active)
    if time.monotonic()-start>300:
     proc.kill();proc.wait();raise RuntimeError(f'Timeout: {path}')
    time.sleep(.25)
  if proc.returncode:raise RuntimeError(f'Worker failed: {path}')
  if activity:
   excluded=ROOT/'excluded'/(path.name+'__'+str(time.time_ns()));excluded.parent.mkdir(exist_ok=True)
   path.rename(excluded);(excluded/'activity.json').write_text(json.dumps(activity));continue
  (path/'done.json').write_text(json.dumps(dict(command=command,wall_seconds=time.monotonic()-start)))
  rows=[json.loads(line) for line in (path/'results.jsonl').read_text().splitlines()]
  print(str(path.relative_to(ROOT)),len(rows),'rows',round(time.monotonic()-start,2),'seconds',flush=True)
  return
for size in ['small','large']:
 corpus=ROOT/('small-corpus' if size=='small' else 'corpus')
 manifest=json.loads((corpus/'manifest.json').read_text())
 jobs=[(c,None) for c in manifest['cases']] if size=='small' else [(c,t) for c in manifest['cases'] for t in c['targets']]
 for i,(case,target) in enumerate(jobs):
  for revision in (['main','pr2578'] if i%2==0 else ['pr2578','main']):
   checkout=CHECKOUTS[revision];name=case['id']+('__'+target if target else '')
   path=ROOT/size/revision/name
   prefix=['taskset','-c','5',str(checkout/'.venv/bin/python')]
   if size=='small':
    command=prefix+[str(ROOT/'evaluate.py'),'run','--checkout',str(checkout),'--corpus',str(corpus),'--case','^'+re.escape(case['id'])+'$','--output',str(path),'--repetitions','5','--shots','512']
   else:
    command=prefix+[str(ROOT/'large.py'),'worker','--revision',revision,'--case',case['id'],'--target',target,'--output',str(path),'--repetitions','5']
   run(command,path)
print('Complete',flush=True)
