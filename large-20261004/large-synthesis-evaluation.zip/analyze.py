"""Derive all plots and tables from recorded samples, without editing raw results."""
import csv
import json
from pathlib import Path
import statistics
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'plots';OUT.mkdir(exist_ok=True)
DATA={}
for revision in ['main','pr2578']:
    rows=[json.loads(p.read_text()) for p in sorted((ROOT/'final-results'/revision).glob('*/results.jsonl'))]
    DATA[revision]={(r['case'],r['target']):r for r in rows}
fields=sorted(set().union(*(r.keys() for data in DATA.values() for r in data.values())))
with (OUT/'raw_results.csv').open('w',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=['revision']+fields,lineterminator='\n');writer.writeheader()
    for rev,data in DATA.items():
        for row in data.values():writer.writerow({'revision':rev,**{k:json.dumps(v) if isinstance(v,(dict,list)) else v for k,v in row.items()}})
labels={'main':'Upstream main','pr2578':'PR #2578'}
colors={'main':'#5279a6','pr2578':'#c05f24'}

def good(row):return row.get('status')=='exported' and row.get('validation',{}).get('passed')
def save(fig,name):
    for ext in ['png','pdf','svg']:fig.savefig(OUT/(name+'.'+ext),dpi=180)
    plt.close(fig)

workloads=[('qft','numeric','QFT'),('grover','numeric','Grover · two iterations'),('w_state','numeric','W state'),
           ('efficient_su2','symbolic','EfficientSU2 · symbolic'),('pauli_layers','numeric','Pauli layers · numeric'),('pauli_layers','symbolic','Pauli layers · symbolic')]
for target,title in [('iqm_r_cz','IQM R/CZ'),('ibm_sxz_cz','IBM SX/X/RZ + CZ')]:
    fig,axs=plt.subplots(2,3,figsize=(14,8),layout='constrained')
    for ax,(family,mode,caption) in zip(axs.flat,workloads):
        for rev,data in DATA.items():
            selected=sorted((r for r in data.values() if r['target']==target and r['family']==family and r['mode']==mode and good(r)),key=lambda r:r['qubits'])
            if not selected:continue
            x=[r['qubits'] for r in selected];y=[r['synthesis_ms'] for r in selected]
            ax.plot(x,y,'o-',color=colors[rev],label=labels[rev])
            ax.fill_between(x,[min(r['synthesis_samples_ms']) for r in selected],[max(r['synthesis_samples_ms']) for r in selected],alpha=.18,color=colors[rev])
        ax.set_title(caption);ax.set_xlabel('Circuit qubits');ax.set_ylabel('Synthesis (ms)');ax.grid(alpha=.2);ax.set_ylim(bottom=0)
        if family=='pauli_layers' and mode=='symbolic':ax.text(.03,.95,'Main: unsupported',transform=ax.transAxes,va='top',color=colors['main'])
    axs[0,0].legend();fig.suptitle(f'{title}: large-circuit synthesis\nMedian of five samples; shaded range = min–max; all-to-all connectivity, no routing')
    save(fig,'scaling_'+('iqm' if target=='iqm_r_cz' else 'ibm_cz'))

selected_cases=[('qft','numeric','QFT'),('w_state','numeric','W state'),('efficient_su2','symbolic','SU2 sym.'),('pauli_layers','numeric','Pauli num.'),('pauli_layers','symbolic','Pauli sym.')]
fig,axs=plt.subplots(2,3,figsize=(15,8),layout='constrained')
for column,(target,width,title) in enumerate([('iqm_r_cz',54,'IQM · 54 qubits'),('ibm_sxz_cz',156,'IBM CZ · 156 qubits'),('ibm_fractional_bounded',156,'IBM fractional · 156 qubits')]):
    for row,metric in enumerate(['native_1q','native_2q']):
        ax=axs[row,column]
        for ri,(rev,data) in enumerate(DATA.items()):
            for i,(family,mode,caption) in enumerate(selected_cases):
                match=next((r for r in data.values() if r['target']==target and r['qubits']==width and r['family']==family and r['mode']==mode and good(r)),None)
                x=i+(ri-.5)*.36
                if match:
                    value=match[metric];ax.bar(x,value,width=.34,color=colors[rev],label=labels[rev] if i==0 else None)
                    ax.annotate(f'{value:,}',(x,value),xytext=(0,3),textcoords='offset points',rotation=90,ha='center',va='bottom',fontsize=7)
                else:ax.text(x,.01,'×',transform=ax.get_xaxis_transform(),color=colors[rev],ha='center')
        ax.set_xticks(range(len(selected_cases)),[x[2] for x in selected_cases],rotation=25,ha='right');ax.set_ylabel('Native '+('1Q' if row==0 else '2Q')+' gates');ax.set_title(title);ax.margins(y=.32);ax.grid(axis='y',alpha=.2)
axs[0,0].legend();fig.suptitle('Native gate counts at the largest tested widths\n× = unsupported; main and PR use different small-angle approximation policies')
save(fig,'large_gate_counts')

fig,axs=plt.subplots(1,2,figsize=(13,5),layout='constrained')
for ax,target,title in [(axs[0],'iqm_r_cz','IQM'),(axs[1],'ibm_sxz_cz','IBM CZ')]:
    for rev,data in DATA.items():
        selected=sorted((r for r in data.values() if r['target']==target and r['family']=='efficient_su2' and r['mode']=='symbolic' and good(r)),key=lambda r:r['qubits'])
        for metric,style in [('synthesis_ms','-'),('export_ms','--')]:
            ax.plot([r['qubits'] for r in selected],[r[metric] for r in selected],style,marker='o',color=colors[rev],label=labels[rev]+' · '+('synthesis' if metric=='synthesis_ms' else 'export'))
    ax.set_title(title+' · symbolic EfficientSU2');ax.set_xlabel('Circuit qubits');ax.set_ylabel('Time (ms)');ax.set_ylim(bottom=0);ax.grid(alpha=.2);ax.legend(fontsize=8)
fig.suptitle('Synthesis and Qiskit export timed separately')
save(fig,'symbolic_stages')

summary=[]
for target in sorted({r['target'] for d in DATA.values() for r in d.values()}):
    pairs=[(a,DATA['pr2578'][key]) for key,a in DATA['main'].items() if a['target']==target and key in DATA['pr2578'] and good(a) and good(DATA['pr2578'][key])]
    for metric in ['synthesis_ms','export_ms','native_1q','native_2q','depth','peak_rss_mib']:
        ratios=[b[metric]/a[metric] for a,b in pairs if isinstance(a.get(metric),(int,float)) and a[metric]>0]
        if ratios:summary.append(dict(target=target,metric=metric,pairs=len(ratios),median_ratio=statistics.median(ratios),min_ratio=min(ratios),max_ratio=max(ratios)))
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
from collections import Counter
status={rev:dict(Counter(r['status'] for r in data.values())) for rev,data in DATA.items()}
(OUT/'status.json').write_text(json.dumps(status,indent=2)+'\n')
print(json.dumps(status))
for rev,data in DATA.items():
    print(rev,'largest synthesis',sorted([(r.get('synthesis_ms',0),r['case'],r['target']) for r in data.values()],reverse=True)[:8])
print('Wrote',OUT)
