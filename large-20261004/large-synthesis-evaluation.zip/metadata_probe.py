"""Isolate the verification cost of an otherwise inactive SymbolDCE pass."""
import json
from pathlib import Path
import statistics
import time
from mqt.core.mlir import QCOProgram
ROOT=Path(__file__).resolve().parent
for n in [24,54,156]:
    source=QCOProgram.from_mlir_file(ROOT/'corpus'/f'efficient_su2_{n}_symbolic.mlir')
    samples=[]
    for trial in range(6):
        program=source.copy();start=time.perf_counter_ns()
        program.run_pass_pipeline('symbol-dce')
        elapsed=(time.perf_counter_ns()-start)/1e6
        assert program.ir==source.ir
        if trial:samples.append(elapsed)
    print(json.dumps(dict(qubits=n,parameter_count=8*n,samples_ms=samples,median_ms=statistics.median(samples),unchanged_ir=True)),flush=True)
