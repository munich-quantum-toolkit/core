"""Summarize independent pass profiles and exact two-qubit angle probes."""
from collections import defaultdict
import json
from pathlib import Path
import re
import statistics
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'plots';OUT.mkdir(exist_ok=True)
colors={'main':'#5279a6','pr2578':'#c05f24'}
labels={'main':'Upstream main','pr2578':'PR #2578'}
def save(fig,name):
    for ext in ['png','pdf','svg']:fig.savefig(OUT/(name+'.'+ext),dpi=180)
    plt.close(fig)
angles={rev:[json.loads(line) for line in (ROOT/'profiles'/('angles_'+rev+'.stdout')).read_text().splitlines()] for rev in colors}
fig,axs=plt.subplots(2,3,figsize=(14,7),layout='constrained')
for col,(target,title) in enumerate([('iqm_r_cz','IQM R/CZ'),('ibm_sxz_cz','IBM CZ'),('rxrz_rzz_unbounded','RX/RZ/RZZ')]):
    for rev,rows in angles.items():
        chosen=[r for r in rows if r['target']==target];x=[r['exponent'] for r in chosen]
        axs[0,col].step(x,[r['native_2q'] for r in chosen],where='mid',marker='o',color=colors[rev],label=labels[rev])
        axs[1,col].semilogy(x,[max(r['max_matrix_error'],1e-17) for r in chosen],'o-',color=colors[rev])
    axs[0,col].set_title(title);axs[0,col].set_ylabel('Native 2Q gates');axs[0,col].set_yticks([0,1,2])
    axs[1,col].set_ylabel('Max complex-matrix error');axs[1,col].set_xlabel('k in controlled phase π / 2ᵏ');axs[1,col].set_ylim(1e-17,1e-4)
    for ax in axs[:,col]:ax.grid(alpha=.2)
axs[0,0].legend();fig.suptitle('Small-angle approximation differs between numeric Weyl and direct Pauli synthesis\nTwo-qubit probe: exact matrix comparison including phase; errors below 1e-17 shown at plotting floor')
save(fig,'angle_policy')
(ROOT/'plots/angle_scan.json').write_text(json.dumps(angles,indent=2)+'\n')

profiles=[]
for path in sorted((ROOT/'profiles').glob('passes_*.stderr')):
    groups=defaultdict(list)
    sections=path.read_text().split('... Execution time report ...')[1:]
    for section in sections:
        current=defaultdict(float)
        for seconds,name in re.findall(r'^\s+(-?[0-9.]+) \(\s*-?[0-9.]+%\)  (\S.*)$',section,re.M):
            if name in {'Total','Rest'} or name.endswith(' Pipeline'):continue
            current[name]+=float(seconds)
        total_match=re.search(r'Total Execution Time: ([0-9.]+) seconds',section)
        if total_match:current['Total']=float(total_match.group(1))
        for name,value in current.items():groups[name].append(value)
    if groups:
        profiles.append(dict(profile=path.stem,seconds={name:statistics.median(values) for name,values in groups.items()},samples=groups))
(OUT/'pass_profiles.json').write_text(json.dumps(profiles,indent=2)+'\n')
chosen=[p for p in profiles if p['profile'].endswith('__pr2578')]
fig,ax=plt.subplots(figsize=(14,7),layout='constrained')
categories=['Inlining / nested cleanup','Other canonicalization','Dead-value analysis','Native synthesis','CSE','Other passes']
palette=['#8fb6ce','#a9c7c5','#c4aece','#c05f24','#e8c47a','#bcbcbc']
for i,p in enumerate(chosen):
    s=p['seconds'];total=s['Total']
    values=[s.get('InlinerPass',0),s.get('CanonicalizerPass',0),s.get('RemoveDeadValuesPass',0),s.get('TargetNativeSynthesis',0),s.get('CSEPass',0)]
    values.append(max(0,total-sum(values)))
    left=0
    for name,color,value in zip(categories,palette,values):
        pct=value/total*100;ax.barh(i,pct,left=left,color=color,label=name if i==0 else None)
        if pct>6:ax.text(left+pct/2,i,f'{pct:.0f}%',ha='center',va='center',fontsize=8)
        left+=pct
    ax.text(101,i,f'{total*1000:.0f} ms',va='center',fontsize=9)
ax.set_yticks(range(len(chosen)),[p['profile'].removeprefix('passes_').removesuffix('__pr2578').replace('__',' · ').replace('_',' ') for p in chosen],fontsize=9)
ax.set_xlabel('Share of pass-manager time (%)');ax.set_xlim(0,115);ax.legend(loc='lower center',bbox_to_anchor=(.5,1.01),ncols=3,fontsize=9)
ax.set_title('PR pipeline profiles: median of three instrumented runs\nNested inliner canonicalization counted once; instrumentation excluded from benchmark samples',pad=65)
save(fig,'pass_breakdown')
print('Wrote angle-policy and pass-profile figures')
