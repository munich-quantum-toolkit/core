from pathlib import Path
from collections import defaultdict
import csv,hashlib,json,re,statistics
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'core-synthesis-refined-20261004'
OUT=ROOT/'plots';OUT.mkdir(exist_ok=True)
def row(path):return json.loads(path.read_text().splitlines()[-1])
quality=[row(p) for p in sorted((ROOT/'quality').glob('*/results.jsonl'))]
paired=[]
for path in sorted((ROOT/'paired/after').glob('*/results.jsonl')):
 a=row(path);b=row(ROOT/'paired/before'/path.parent.name/path.name)
 paired.append(dict(case=a['case'],target=a['target'],before_ms=b['synthesis_ms'],after_ms=a['synthesis_ms'],ratio=a['synthesis_ms']/b['synthesis_ms'],before_samples=b['synthesis_samples_ms'],after_samples=a['synthesis_samples_ms']))
profiles=[]
for path in sorted((ROOT/'profiles').glob('*.stderr')):
 groups=defaultdict(list)
 for section in path.read_text().split('... Execution time report ...')[1:]:
  current=defaultdict(float)
  for seconds,name in re.findall(r'^\s+(-?[0-9.]+) \(\s*-?[0-9.]+%\)  (\S.*)$',section,re.M):
   if name not in {'Total','Rest'} and not name.endswith(' Pipeline'):current[name]+=float(seconds)
  total=re.search(r'Total Execution Time: ([0-9.]+) seconds',section)
  if total:current['Total']=float(total.group(1))
  for name,value in current.items():groups[name].append(value)
 profiles.append(dict(profile=path.stem,seconds={name:statistics.median(values) for name,values in groups.items()},samples=groups))
summary={'paired':paired,'profiles':profiles,'quality_cases':len(quality),'quality_failures':[r for r in quality if r['status']!='exported'],'comparisons':{}}
for label,directory in [('before',OLD/'final-results/pr2578'),('earlier',OLD/'previous-results')]:
 comparisons={}
 for metric in ['native_1q','native_1q_non_rz','native_2q','native_depth','two_qubit_depth']:
  up=[];down=[]
  for a in quality:
   b=row(directory/(a['case']+'__'+a['target'])/'results.jsonl')
   diff=dict(case=a['case'],target=a['target'],before=b[metric],after=a[metric])
   if a[metric]>b[metric]:up.append(diff)
   elif a[metric]<b[metric]:down.append(diff)
  comparisons[metric]={'increases':up,'decreases':len(down),'unchanged':len(quality)-len(up)-len(down)}
 summary['comparisons'][label]=comparisons
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
fields=['case','target','qubits','mode','native_1q','native_1q_non_rz','native_rz','native_2q','native_depth','non_rz_depth','two_qubit_depth','status']
with (OUT/'quality.csv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');writer.writeheader();writer.writerows(quality)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans'})
labels={'ibm_sxz_cz':'IBM SX/RZ/CZ','ibm_fractional_bounded':'IBM fractional','iqm_r_cz':'IQM R/CZ','rigetti_rx_cz':'Rigetti RX/RZ/CZ','rxrz_rzz_unbounded':'RX/RZ/RZZ'}
def name(r):
 case=r['case'].replace('core_','').replace('efficient_su2','SU2').replace('pauli_layers','Pauli').replace('_symbolic',' symbolic').replace('_numeric',' numeric').replace('_',' ').replace('qft','QFT').replace('grover','Grover')
 return case+' · '+labels.get(r['target'],r['target'])
def save(fig,stem):
 for ext in ['png','svg','pdf']:fig.savefig(OUT/(stem+'.'+ext),dpi=180)
 plt.close(fig)
fig,ax=plt.subplots(figsize=(13,7),layout='constrained')
ordered=sorted(paired,key=lambda r:r['ratio'])
ax.barh(range(len(ordered)),[r['ratio'] for r in ordered],color='#247A8A')
ax.axvline(1,color='#555555',ls='--',lw=1)
ax.set_yticks(range(len(ordered)),[name(r) for r in ordered]);ax.invert_yaxis();ax.set_xlim(0,1.35)
for i,r in enumerate(ordered):
 ax.text(r['ratio']+.02,i,f"{r['before_ms']:.1f} → {r['after_ms']:.1f} ms ({100*(1-r['ratio']):.1f}% faster)",va='center',fontsize=9,bbox=dict(facecolor='white',edgecolor='none',alpha=.85,pad=1))
ax.set_xlabel('Updated / previous synthesis time (lower is better; previous = 1)');ax.grid(axis='x',alpha=.2);ax.set_axisbelow(True)
ax.set_title('Cleanup optimization: fresh paired timings\n5 samples after warm-up · CPU 5 · all-to-all targets · LLVM/MLIR 23.1',pad=16)
save(fig,'cleanup_runtime')
fig,axs=plt.subplots(1,2,figsize=(13,6),layout='constrained')
for ax,target in zip(axs,['ibm_sxz_cz','ibm_fractional_bounded']):
 selected=[next(p for p in profiles if p['profile']==f'core_qft_156__{target}__{rev}') for rev in ['before','after']]
 categories=[('CanonicalizerPass','Canonicalization','#247A8A'),('RemoveDeadValuesPass','Liveness cleanup','#B58BB5'),('TargetNativeSynthesis','Native synthesis','#D98B37'),('CSEPass','CSE','#A3B86C')]
 bottom=[0.,0.]
 for key,label,color in categories:
  values=[p['seconds'].get(key,0)*1000 for p in selected];ax.bar(['Previous','Updated'],values,bottom=bottom,label=label,color=color);bottom=[a+b for a,b in zip(bottom,values)]
 other=[p['seconds']['Total']*1000-b for p,b in zip(selected,bottom)];ax.bar(['Previous','Updated'],other,bottom=bottom,label='Other passes',color='#B8BDC5')
 for i,p in enumerate(selected):ax.text(i,p['seconds']['Total']*1000+14,f"{p['seconds']['Total']*1000:.0f} ms",ha='center')
 ax.set_ylim(0,1150);ax.set_ylabel('Pass-manager time (ms)');ax.set_title('QFT-156 · '+labels[target]);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
handles,legend=axs[0].get_legend_handles_labels();fig.legend(handles,legend,loc='outside lower center',ncols=5)
fig.suptitle('Where the time went\nMedian of 3 separate instrumented runs; nested analyses counted once')
save(fig,'cleanup_passes')
fig,ax=plt.subplots(figsize=(9,4),layout='constrained')
metrics=['native_1q','native_1q_non_rz','native_2q'];metric_labels=['All single-qubit gates','Physical single-qubit gates\n(RZ excluded)','Two-qubit gates']
for i,m in enumerate(metrics):
 values=[summary['comparisons']['before'][m]['decreases'],summary['comparisons']['before'][m]['unchanged'],len(summary['comparisons']['before'][m]['increases'])];left=0
 for label,color,v in zip(['Fewer','Same','More'],['#247A8A','#B8BDC5','#D98B37'],values):
  ax.barh(i,v,left=left,label=label if i==0 else None,color=color)
  if v:ax.text(left+v/2,i,str(v),ha='center',va='center',color='white' if color=='#247A8A' else 'black')
  left+=v
ax.set_yticks(range(3),metric_labels);ax.invert_yaxis();ax.set_xlim(0,398);ax.set_xlabel('Number of circuit/target cases');ax.legend(loc='lower right');ax.set_title('Gate quality after cleanup and numerical fixes\n398 validated cases · 24–156 qubits · compared with the preceding PR version')
save(fig,'cleanup_quality')
print(json.dumps({'paired':len(paired),'quality':len(quality),'profiles':len(profiles)}))
