"""Native-contract/quality sweep, followed by separately paired timing samples."""
import json,os,re,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CURRENT=Path('/home/nvidia/.codex/worktrees/pr2578-audit/core/.venv/bin/python')
BEFORE=ROOT/'baseline-venv/bin/python'
ENV=os.environ|dict(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',QISKIT_NUM_PROCS='1')
def busy():
 return subprocess.run(['ps','-C','ld,ld.lld,clang,clang++,clang-tidy,cc1plus','-o','pid=,comm='],capture_output=True,text=True).stdout.strip()
def run(python,case,target,path,reps):
 if (path/'done.json').exists():return
 path.mkdir(parents=True,exist_ok=True)
 command=['taskset','-c','5',str(python),str(ROOT/'large.py'),'worker','--revision','pr2578','--case',case,'--target',target,'--output',str(path),'--repetitions',str(reps)]
 while True:
  while busy():time.sleep(2)
  activity=[];start=time.monotonic()
  with (path/'stdout.log').open('w') as out,(path/'stderr.log').open('w') as err:
   process=subprocess.Popen(command,env=ENV,stdout=out,stderr=err)
   while process.poll() is None:
    if load:=busy():activity.append(load)
    if time.monotonic()-start>180:
     process.kill();process.wait();raise RuntimeError(f'Timeout: {case}, {target}')
    time.sleep(.25)
  if process.returncode:raise RuntimeError(f'Worker failed: {path}')
  if activity:
   dest=ROOT/'excluded'/(path.name+'__'+str(time.time_ns()));dest.parent.mkdir(exist_ok=True);path.rename(dest);path.mkdir()
   (dest/'activity.json').write_text(json.dumps(activity));continue
  (path/'done.json').write_text(json.dumps(dict(command=command,wall_seconds=time.monotonic()-start)))
  row=json.loads((path/'results.jsonl').read_text().splitlines()[-1]);print(path.parent.name,case,target,row['status'],row['synthesis_ms'],flush=True);break
manifest=json.loads((ROOT/'corpus/manifest.json').read_text())
for case in manifest['cases']:
 for target in case['targets']:run(CURRENT,case['id'],target,ROOT/'quality'/(case['id']+'__'+target),1)
selected=[('core_qft_156','ibm_sxz_cz'),('core_qft_156','ibm_fractional_bounded'),('core_qft_54','iqm_r_cz'),('efficient_su2_156_symbolic','ibm_sxz_cz'),('core_grover_54','iqm_r_cz'),('core_grover_54','ibm_fractional_bounded'),('core_grover_36','rigetti_rx_cz'),('pauli_layers_54_numeric','iqm_r_cz'),('pauli_layers_156_symbolic','ibm_fractional_bounded'),('efficient_su2_36_symbolic','rxrz_rzz_unbounded')]
for i,(case,target) in enumerate(selected):
 for label,python in ([('before',BEFORE),('after',CURRENT)] if i%2==0 else [('after',CURRENT),('before',BEFORE)]):run(python,case,target,ROOT/'paired'/label/(case+'__'+target),5)
