#!/usr/bin/env python3
"""Frozen-input synthesis comparison. All artifacts stay outside the repositories."""
from __future__ import annotations
import argparse
import csv
from datetime import datetime, timezone
from fractions import Fraction
from functools import lru_cache
import hashlib
import importlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import platform
import re
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SEED = 2578

def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def metadata(checkout=None):
    info = dict(time_utc=datetime.now(timezone.utc).isoformat(), python=sys.version,
                executable=sys.executable, platform=platform.platform(), cpu=platform.processor(),
                affinity=sorted(os.sched_getaffinity(0)), seed=SEED,
                packages={p: importlib.metadata.version(p) for p in ['mqt-core', 'qiskit', 'numpy']})
    import mqt.core.mlir
    info['mlir_extension'] = mqt.core.mlir.__file__
    info['harness_sha256'] = sha(Path(__file__))
    info['thread_environment'] = {k:os.environ.get(k) for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','QISKIT_NUM_PROCS']}
    extension=Path(mqt.core.mlir.__file__)
    info['mlir_extension_sha256'] = sha(extension)
    if checkout:
        def git(*args):
            return subprocess.check_output(['git', '-C', str(checkout), *args], text=True).strip()
        info.update(checkout=str(checkout.resolve()), git_head=git('rev-parse','HEAD'),
                    git_status=git('status','--short'), diff_sha256=hashlib.sha256(git('diff','HEAD').encode()).hexdigest())
        for relative in ['build/python/Release/CMakeCache.txt', 'build/release/CMakeCache.txt']:
            cache=checkout/relative
            if cache.exists():
                info[relative] = [s for s in cache.read_text().splitlines() if re.match(r'(CMAKE_(BUILD_TYPE|CXX_COMPILER|CXX_FLAGS[^:]*|INTERPROCEDURAL_OPTIMIZATION)|LLVM_DIR|MLIR_DIR):',s)]
    return info

def targets():
    def gate(name, arity, params=0, **kwargs):
        return dict(name=name, arity=arity, num_parameters=params, **kwargs)
    sxz=[gate('rz',1,1),gate('sx',1),gate('x',1)]
    rxz=[gate('rz',1,1),gate('rx',1,1)]
    rigetti=[gate('rz',1,1)]+[gate(name,1,1,canonical_name='rx',fixed_parameters=[angle])
             for name,angle in [('rxpi',math.pi),('rxpidg',-math.pi),('rxpi2',math.pi/2),('rxpi2dg',-math.pi/2)]]
    result={
        'iqm_r_cz':[gate('r',1,2),gate('cz',2)],
        'ibm_sxz_cx':sxz+[gate('cx',2)],
        'ibm_sxz_cz':sxz+[gate('cz',2)],
        'rxrz_rzz_unbounded':rxz+[gate('rzz',2,1)],
        'ibm_fractional_bounded':sxz+[gate('rx',1,1),
                                     gate('cz',2),gate('rzz',2,1,parameter_bounds=[(0,math.pi/2)])],
        'ionq_fixed_r_zz':[gate('rz',1,1),gate('gpi',1,2,canonical_name='r',fixed_parameters=[math.pi,None]),
                          gate('gpi2',1,2,canonical_name='r',fixed_parameters=[math.pi/2,None]),
                          gate('rzz',2,1)],
        'rigetti_rx_cz':rigetti+[gate('cz',2)],
        'rigetti_rx_iswap':rigetti+[gate('iswap',2)],
    }
    common=[gate('gphase',0,1),gate('measure',1),gate('reset',1)]
    return {name: gates+common for name,gates in result.items()}

def generate(args):
    import numpy as np
    from qiskit import QuantumCircuit, qpy
    from qiskit.circuit import ParameterVector
    from qiskit.circuit.library import efficient_su2
    from mqt.core.mlir import QCProgram
    from mqt.core.bench import ghz,qft,w_state,qpe,grover,multiplexer,qft_adder,bv
    args.corpus.mkdir(parents=True,exist_ok=True)
    cases=[]
    def save(case, program, circuit=None, instance=None):
        program.unroll_quantum_loops()
        path=args.corpus/(case['id']+'.mlir');path.write_text(program.ir)
        case.update(input=path.name,input_sha256=sha(path))
        if circuit is not None:
            path=args.corpus/(case['id']+'.qpy')
            with path.open('wb') as stream:qpy.dump(circuit,stream)
            case.update(reference=path.name,reference_sha256=sha(path))
        if instance is not None:
            case.update(instance_specification=json.loads(instance.instance_specification_json),
                        benchmark_class=type(instance).__name__, benchmark_module=type(instance).__module__)
        cases.append(case)
    for size_index in range(3):
        wide=[4,16,64][size_index];n=[4,8,16][size_index];small=[3,5,7][size_index];half=[2,4,8][size_index]
        instances=[
            ('ghz',wide,ghz.GHZ(ghz.Options(qubits=wide))),
            ('qft',n,qft.QFT(qft.Options(qubits=n,period_exponent=n//2))),
            ('w_state',n,w_state.WState(w_state.Options(qubits=n))),
            ('qpe',n,qpe.QPE(qpe.Options(precision=n-1,phase=Fraction(3,8)))),
            ('grover',small,grover.Grover(grover.Options(marked_bitstring=('10'*small)[:small],iterations=2))),
            ('multiplexer',small,multiplexer.Multiplexer(multiplexer.Options(qubits=small))),
            ('qft_adder',2*half,qft_adder.QFTAdder(qft_adder.Options(addend=('10'*half)[:half],accumulator=('01'*half)[:half]))),
            ('bv',n,bv.BV(bv.Options(hidden_bitstring=('10'*n)[:n-1]))),
        ]
        for name,width,instance in instances:
            case=dict(id=f'core_{name}_{width}',family=name,origin='core',qubits=width,mode='numeric',measured=True)
            save(case,instance.generate().to_qco(),instance=instance)
    for n in [4,8,16]:
        for symbolic in [False,True]:
            mode='symbolic' if symbolic else 'numeric'
            for family in ['efficient_su2','pauli_layers','equatorial_frames']:
                if family=='efficient_su2':
                    circuit=efficient_su2(n,reps=3,entanglement='circular')
                else:
                    circuit=QuantumCircuit(n)
                    pars=ParameterVector('theta',3*n)
                    for layer in range(3):
                        for q in range(n):
                            a=pars[layer*n+q];r=(q+1)%n
                            if family=='pauli_layers':
                                circuit.ry(a/3,q);circuit.rzz(a,q,r);circuit.rxx(a/2,q,r)
                            else:
                                circuit.rz(a,q);circuit.r(.3,.2,q);circuit.cz(q,r)
                if not symbolic:
                    circuit=circuit.assign_parameters(np.random.default_rng(SEED+n).uniform(-3,3,circuit.num_parameters))
                case=dict(id=f'{family}_{n}_{mode}',family=family,origin='synthetic',qubits=n,mode=mode,measured=False)
                save(case,QCProgram.from_qiskit(circuit).to_qco(),circuit=circuit)
    # Tiny kernels keep inverse cancellation and measurement effects visible separately.
    for symbolic in [False,True]:
        mode='symbolic' if symbolic else 'numeric'
        p=ParameterVector('theta',2)
        for family in ['pauli_inverse','pauli_merge','terminal_z','same_axis_r']:
            circuit=QuantumCircuit(2)
            if family=='pauli_inverse':circuit.rzz(p[0],0,1);circuit.rzz(-p[0],0,1)
            elif family=='pauli_merge':circuit.rzz(p[0],0,1);circuit.rzz(p[1],0,1)
            elif family=='terminal_z':circuit.h(0);circuit.rz(p[0],0);circuit.measure_all()
            else:circuit.r(math.pi/2,p[0],0);circuit.r(math.pi/2,p[0],0)
            if not symbolic:circuit=circuit.assign_parameters({x:.37+.13*i for i,x in enumerate(circuit.parameters)})
            case=dict(id=f'{family}_{mode}',family=family,origin='micro',qubits=2,mode=mode,measured=family=='terminal_z')
            save(case,QCProgram.from_qiskit(circuit).to_qco(),circuit=circuit)
    dump(args.corpus/'manifest.json',dict(metadata=metadata(args.checkout),targets=targets(),cases=cases))
    print(f'Wrote {len(cases)} immutable input cases and {len(targets())} target contracts to {args.corpus}')

def timed(fn,repetitions):
    result=fn()  # warm-up is discarded
    samples=[]
    for _ in range(repetitions):
        start=time.perf_counter_ns();result=fn();samples.append((time.perf_counter_ns()-start)/1e6)
    return result,samples

def counts(circuit):
    from collections import Counter
    ignored={'measure','reset','barrier','delay'}
    def leaves(block):
        for inst in block.data:
            if hasattr(inst.operation,'blocks'):
                for region in inst.operation.blocks:yield from leaves(region)
            else:yield inst
    instructions=list(leaves(circuit))
    gates=[x for x in instructions if x.operation.name not in ignored]
    flat=not any(hasattr(x.operation,'blocks') for x in circuit.data)
    return dict(native_1q=sum(x.operation.num_qubits==1 for x in gates),
                native_2q=sum(x.operation.num_qubits==2 for x in gates),
                native_wide=sum(x.operation.num_qubits>2 for x in gates),
                native_rz=sum(x.operation.name=='rz' for x in gates),
                native_1q_non_rz=sum(x.operation.num_qubits==1 and x.operation.name!='rz' for x in gates),
                native_depth=circuit.depth(filter_function=lambda x:x.operation.name not in ignored) if flat else None,
                non_rz_depth=circuit.depth(filter_function=lambda x:x.operation.name not in ignored|{'rz'}) if flat else None,
                depth=circuit.depth() if flat else None,
                two_qubit_depth=circuit.depth(filter_function=lambda x:x.operation.num_qubits==2 and x.operation.name not in ignored) if flat else None,
                count_semantics='static: each control-flow region counted once',
                depth_semantics='flat circuit' if flat else 'unavailable: structured control flow',
                operation_counts=dict(Counter(x.operation.name for x in instructions)))

def permute_state(data, source_to_destination):
    """Permute little-endian qubit axes using O(2**n), never a dense operator."""
    import numpy as np
    n=len(source_to_destination)
    if sorted(source_to_destination)!=list(range(n)) or len(data)!=2**n:
        raise ValueError('State and complete layout permutation must have matching widths')
    inverse=np.argsort(source_to_destination)
    axes=[n-1-int(inverse[destination]) for destination in reversed(range(n))]
    return np.asarray(data).reshape([2]*n).transpose(axes).reshape(-1)

def logical_evolve(state,circuit):
    from qiskit.quantum_info import Statevector
    if circuit.layout is None:return state.evolve(circuit).data
    initial=circuit.layout.initial_index_layout(filter_ancillas=False)
    final=circuit.layout.final_index_layout(filter_ancillas=False)
    physical_data=Statevector(permute_state(state.data,initial)).evolve(circuit).data
    inverse=[final.index(position) for position in range(len(final))]
    return permute_state(physical_data,inverse)

def measurement_probabilities(circuit):
    """Compare reported classical slots using the actual physical measurement map."""
    import numpy as np
    from qiskit.quantum_info import Statevector
    measurement_map=[(circuit.find_bit(inst.qubits[0]).index,circuit.find_bit(inst.clbits[0]).index)
                     for inst in circuit.data if inst.operation.name=='measure']
    if len({c for _,c in measurement_map})!=len(measurement_map):
        raise ValueError('Measurement validation requires distinct final classical outputs')
    body=circuit.remove_final_measurements(inplace=False)
    if any(inst.operation.name in {'measure','reset'} or hasattr(inst.operation,'blocks') for inst in body.data):
        raise ValueError('Probability validation supports terminal measurements only')
    # The zero input is invariant under initial placement; output measurements
    # already carry the physical positions corresponding to final_index_layout.
    probabilities=Statevector.from_instruction(body).probabilities()
    indices=np.arange(len(probabilities),dtype=np.uint64)
    outcomes=np.zeros(len(probabilities),dtype=np.uint64)
    for qubit,cbit in measurement_map:outcomes|=((indices>>qubit)&1)<<cbit
    return np.bincount(outcomes.astype(np.int64),weights=probabilities,minlength=2**circuit.num_clbits)

@lru_cache(maxsize=None)
def reference_distribution(module_name,class_name,specification):
    instance=getattr(importlib.import_module(module_name),class_name).from_instance_specification_json(specification)
    width=instance.output.width
    if width<=16:
        outcomes=(format(i,f'0{width}b') for i in range(2**width))
    elif class_name=='GHZ' and json.loads(specification)['parameters']['basis']=='z':
        outcomes=['0'*width,'1'*width]
    else:raise ValueError('Reference enumeration exceeds the evaluation corpus width')
    probabilities={}
    for outcome in outcomes:
        probability=instance.probability(outcome)
        if probability>0:probabilities[outcome]=probability
    if abs(sum(probabilities.values())-1)>1e-9:
        raise ValueError('Enumerated reference distribution does not sum to one')
    return probabilities

def distribution_check(samples,probabilities,alpha=1e-9):
    # DKW: P(sup_x |empirical_CDF(x)-reference_CDF(x)| > e) <= 2 exp(-2 N e^2).
    shots=sum(samples.values());empirical=reference=deviation=0.
    for outcome in sorted(samples.keys() | probabilities.keys()):
        empirical+=samples.get(outcome,0)/shots;reference+=probabilities.get(outcome,0.)
        deviation=max(deviation,abs(empirical-reference))
    limit=math.sqrt(math.log(2/alpha)/(2*shots))
    impossible={x:c for x,c in samples.items() if probabilities.get(x,0.)==0}
    return dict(cdf_max_deviation=deviation,dkw_limit=limit,false_rejection_bound=alpha,
                reference_support=len(probabilities),impossible_outcomes=impossible,
                passed=not impossible and deviation<=limit)

def validate(case,program,out,corpus,shots):
    import numpy as np
    if case['origin']=='core':
        cls=getattr(importlib.import_module(case['benchmark_module']),case['benchmark_class'])
        instance=cls.from_instance_specification_json(json.dumps(case['instance_specification']))
        samples=program.sample(shots=shots,seed=SEED)
        result=instance.evaluate(samples)
        # This checks declared-output semantics, not the full circuit unitary.
        probabilities=reference_distribution(case['benchmark_module'],case['benchmark_class'],json.dumps(case['instance_specification'],sort_keys=True))
        return dict(kind='core_reference_samples',shots=shots,counts=samples,
                    total_variation_distance=result.total_variation_distance,
                    squared_hellinger_fidelity=result.squared_hellinger_fidelity,
                    **distribution_check(samples,probabilities))
    if out is None:return dict(kind='unavailable',reason='Qiskit export failed')
    from qiskit import qpy
    from qiskit.quantum_info import Operator,random_statevector
    with (corpus/case['reference']).open('rb') as stream:reference=qpy.load(stream)[0]
    errors=[]
    for sample in range(3 if reference.num_parameters else 1):
        values=np.random.default_rng(SEED+sample).uniform(-8,8,len(reference.parameters))
        bindings=dict(zip(reference.parameters,values,strict=True))
        left=reference.assign_parameters(bindings)
        # Cancellation can legitimately leave fewer parameters in output.
        right=out.assign_parameters(bindings,strict=False)
        if case['measured']:
            a=measurement_probabilities(left);b=measurement_probabilities(right)
            errors.append(float(np.max(np.abs(a-b))));kind='measurement_probabilities'
        elif reference.num_qubits<=4:
            errors.append(float(np.max(np.abs(Operator.from_circuit(left).data-Operator.from_circuit(right).data))));kind='full_matrix_including_phase'
        else:
            state=random_statevector(2**reference.num_qubits,seed=SEED+sample)
            errors.append(float(np.max(np.abs(logical_evolve(state,left)-logical_evolve(state,right)))));kind='sample_state_including_phase'
    return dict(kind=kind,max_error=max(errors),samples=errors,passed=max(errors)<1e-8)

def run(args):
    from mqt.core.mlir import CompilerTarget as T,QCOProgram,TargetEnvironment,PayloadSpecification,PayloadFormat,CompilationOptions
    manifest=json.loads((args.corpus/'manifest.json').read_text())
    args.output.mkdir(parents=True,exist_ok=True)
    if (args.output/'results.jsonl').exists():
        raise FileExistsError('Use a fresh output directory; existing samples must not be mixed')
    dump(args.output/'metadata.json',dict(**metadata(args.checkout),repetitions=args.repetitions,
                                        warmups=1,manifest_sha256=sha(args.corpus/'manifest.json')))
    selected=[x for x in manifest['cases'] if re.search(args.case,x['id'])]
    for case in selected:
        path=args.corpus/case['input']
        if sha(path)!=case['input_sha256']:raise ValueError(f'Input changed: {path}')
        try:
            source,parse_samples=timed(lambda:QCOProgram.from_mlir_file(path),args.repetitions)
        except (RuntimeError,ValueError,TypeError) as error:
            for name in manifest['targets']:
                if re.search(args.target,name):
                    record(args.output,dict(case=case['id'],family=case['family'],origin=case['origin'],qubits=case['qubits'],mode=case['mode'],target=name,status='import_failed',error=str(error),input_sha256=case['input_sha256']))
            continue
        for name,ops in manifest['targets'].items():
            if not re.search(args.target,name):continue
            row=dict(case=case['id'],family=case['family'],origin=case['origin'],qubits=case['qubits'],
                     mode=case['mode'],target=name,status='pending',parse_ms=statistics.median(parse_samples),
                     parse_samples_ms=parse_samples,input_sha256=case['input_sha256'])
            try:
                target=T(max(2,case['qubits']),connectivity=T.Connectivity.all_to_all(),
                         native_operations=T.NativeOperations([T.OperationCapability(**op) for op in ops]))
                env=TargetEnvironment(target,PayloadSpecification(PayloadFormat('openqasm','3.0')))
            except (RuntimeError,ValueError,TypeError) as error:
                row.update(status='target_unsupported',error=str(error));record(args.output,row);continue
            synth_samples=[]
            try:
                for trial in range(args.repetitions+1):
                    program=source.copy()  # exclude copying from timed native synthesis
                    start=time.perf_counter_ns();program.synthesize_for_target(env,options=CompilationOptions(seed=SEED))
                    if trial:synth_samples.append((time.perf_counter_ns()-start)/1e6)
                row.update(status='synthesized',synthesis_ms=statistics.median(synth_samples),synthesis_samples_ms=synth_samples,
                           scalar_ops=len(re.findall(r'= (?:arith|math)\.',program.ir)),ir_bytes=len(program.ir.encode()))
                qc=program.to_qc(copy=True)
                row.update(native_1q=qc.num_single_qubit_gates(),native_2q=qc.num_two_qubit_gates())
            except (RuntimeError,ValueError,TypeError) as error:
                row.update(status='synthesis_failed',error=str(error));record(args.output,row);continue
            out=None
            try:
                out,export_samples=timed(lambda:program.to_qiskit(target=target),args.repetitions)
                row.update(status='exported',export_ms=statistics.median(export_samples),export_samples_ms=export_samples,**counts(out))
            except (RuntimeError,ValueError,TypeError) as error:row['export_error']=str(error)
            try:
                row['validation']=validate(case,program,out,args.corpus,args.shots)
                if row['validation'].get('passed') is False:row['status']='validation_failed'
            except Exception as error:row['validation']=dict(kind='failed',error=str(error));row['status']='validation_failed'
            if args.save_ir:(args.output/(case['id']+'__'+name+'.mlir')).write_text(program.ir)
            record(args.output,row)

def record(output,row):
    with (output/'results.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
    print(json.dumps({k:row[k] for k in ['case','target','status','synthesis_ms','native_1q','native_2q','export_ms'] if k in row}),flush=True)

def plot(args):
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.ticker import MaxNLocator, FormatStrFormatter
    labels=['Upstream main','PR 2578']
    meta=[json.loads((folder/'metadata.json').read_text()) for folder in [args.baseline,args.branch]]
    if meta[0]['manifest_sha256']!=meta[1]['manifest_sha256']:
        raise ValueError('Baseline and branch must use the same frozen input/target manifest')
    datasets=[]
    for folder in [args.baseline,args.branch]:
        rows=[json.loads(x) for x in (folder/'results.jsonl').read_text().splitlines()]
        datasets.append({(r['case'],r['target']):r for r in rows})
    args.output.mkdir(parents=True,exist_ok=True)
    fields=sorted(set().union(*(r.keys() for ds in datasets for r in ds.values())))
    with (args.output/'raw_results.csv').open('w') as stream:
        writer=csv.DictWriter(stream,fieldnames=['revision']+fields);writer.writeheader()
        for label,ds in zip(labels,datasets,strict=True):
            for row in ds.values():writer.writerow({'revision':label,**{k:json.dumps(v) if isinstance(v,(dict,list)) else v for k,v in row.items()}})
    pairs=[(datasets[0][key],datasets[1][key]) for key in datasets[0].keys() & datasets[1].keys()
           if datasets[0][key]['origin']!='micro' and datasets[0][key].get('status')=='exported' and datasets[1][key].get('status')=='exported'
           and datasets[0][key].get('validation',{}).get('passed') and datasets[1][key].get('validation',{}).get('passed')]
    names=sorted({r['target'] for ds in datasets for r in ds.values()})
    target_labels={'ibm_fractional_bounded':'IBM fractional','ibm_sxz_cx':'IBM CX',
                   'ibm_sxz_cz':'IBM CZ','ionq_fixed_r_zz':'IonQ fixed R','iqm_r_cz':'IQM',
                   'rigetti_rx_cz':'Rigetti CZ','rigetti_rx_iswap':'RX/iSWAP (expl.)',
                   'rxrz_rzz_unbounded':'RX/RZ/RZZ'}
    display_names=[target_labels.get(name,name) for name in names]
    metrics=['synthesis_ms','native_1q','native_2q','depth']
    titles=['Synthesis time','Native one-qubit gates','Native two-qubit gates','Circuit depth']
    fig,axs=plt.subplots(2,2,figsize=(14,9),layout='constrained')
    summary=[]
    for ax,metric,title in zip(axs.flat,metrics,titles,strict=True):
        ax.axhline(1,color='black',linewidth=.8)
        for i,name in enumerate(names):
            vals=[b[metric]/a[metric] for a,b in pairs if a['target']==name and isinstance(a.get(metric),(int,float)) and a[metric]>0 and isinstance(b.get(metric),(int,float))]
            if vals:
                ax.scatter(np.full(len(vals),i)+np.linspace(-.18,.18,len(vals)),vals,alpha=.4,s=18)
                median=float(np.median(vals));ax.scatter([i],[median],marker='D',s=55,color='black')
                summary.append(dict(target=name,metric=metric,paired_cases=len(vals),median_ratio=median,min_ratio=min(vals),max_ratio=max(vals)))
            else:ax.text(i,.04,'N/A',transform=ax.get_xaxis_transform(),ha='center',va='bottom',fontsize=8,color='#555555')
        ax.set_title(title);ax.set_ylabel('PR / main (lower is better)');ax.set_xticks(range(len(names)),display_names,rotation=30,ha='right',fontsize=8)
        ceiling=max([1.3]+[entry['max_ratio']*1.05 for entry in summary if entry['metric']==metric])
        ax.set_ylim(0,ceiling);ax.set_xlim(-.6,len(names)-.4)
        ax.yaxis.set_major_locator(MaxNLocator(nbins=7));ax.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
        ax.grid(axis='y',alpha=.2)
    fig.suptitle('Identical inputs and native capabilities; validated exports only\nCore benchmarks and scalable kernels; diamonds: median paired ratio; N/A: no paired result')
    for ext in ['png','pdf','svg']:fig.savefig(args.output/('paired_comparison.'+ext),dpi=180)
    plt.close(fig)
    families=sorted({r['family'] for ds in datasets for r in ds.values() if r['origin']!='micro'})
    family_summary=[]
    cmap=plt.get_cmap('RdYlGn_r').copy();cmap.set_bad('#d9d9d9')
    for metric,title in [('synthesis_ms','Synthesis time'),('native_2q','Native two-qubit gates'),('native_1q','Native one-qubit gates')]:
        fig,axs=plt.subplots(1,2,figsize=(18,max(6,3+.47*len(families))),layout='constrained')
        for ax,mode in zip(axs,['numeric','symbolic'],strict=True):
            values=np.full((len(families),len(names)),np.nan)
            entries=[]
            for i,family in enumerate(families):
                for j,name in enumerate(names):
                    ratios=[b[metric]/a[metric] for a,b in pairs
                            if a['family']==family and a['mode']==mode and a['target']==name
                            and isinstance(a.get(metric),(int,float)) and a[metric]>0
                            and isinstance(b.get(metric),(int,float))]
                    if ratios:
                        ratio=float(np.median(ratios));values[i,j]=math.log2(max(ratio,1e-6))
                        entries.append((j,i,f'{ratio:.2f}×\nn={len(ratios)}'))
                        family_summary.append(dict(family=family,mode=mode,target=name,metric=metric,
                                                   paired_cases=len(ratios),median_ratio=ratio,
                                                   min_ratio=min(ratios),max_ratio=max(ratios)))
                    else:entries.append((j,i,'—'))
            image=ax.imshow(np.ma.masked_invalid(values),vmin=-2,vmax=2,cmap=cmap,aspect='auto')
            ax.set_xticks(range(len(names)),display_names,rotation=40,ha='right',fontsize=8)
            ax.set_yticks(range(len(families)),[x.replace('_',' ') for x in families],fontsize=9)
            ax.set_title(mode.capitalize())
            for j,i,text in entries:ax.text(j,i,text,ha='center',va='center',fontsize=7)
        bar=fig.colorbar(image,ax=axs,shrink=.8,ticks=[-2,-1,0,1,2])
        bar.ax.set_yticklabels(['≤0.25×','0.5×','1×','2×','≥4×'])
        bar.set_label('PR / main; lower is better')
        fig.suptitle(f'{title}: median paired ratio by algorithm and native gate set\n'
                     'n = matched sizes; gray = no jointly validated comparison; microcases excluded')
        for ext in ['png','pdf','svg']:fig.savefig(args.output/(f'algorithm_{metric}.'+ext),dpi=180)
        plt.close(fig)
    dump(args.output/'algorithm_summary.json',family_summary)
    fig,axs=plt.subplots(1,2,figsize=(14,5),layout='constrained')
    modes=['numeric','symbolic']
    for ax,label,ds in zip(axs,labels,datasets,strict=True):
        image=np.zeros((len(names),2));texts=[]
        for i,name in enumerate(names):
            for j,mode in enumerate(modes):
                rows=[r for r in ds.values() if r['target']==name and r['mode']==mode]
                passed=sum(r.get('status')=='exported' and r.get('validation',{}).get('passed',False) for r in rows)
                image[i,j]=passed/max(1,len(rows));texts.append((j,i,f'{passed}/{len(rows)}'))
        ax.imshow(image,vmin=0,vmax=1,cmap='YlGn');ax.set_yticks(range(len(names)),display_names,fontsize=9);ax.set_xticks(range(2),modes);ax.set_title(label)
        for j,i,text in texts:ax.text(j,i,text,ha='center',va='center')
    fig.suptitle('Validated native export coverage: successes / attempted cases')
    for ext in ['png','pdf','svg']:fig.savefig(args.output/('applicability.'+ext),dpi=180)
    plt.close(fig)
    representatives=[('core_qft_16','QFT · 16 qubits'),
                     ('efficient_su2_16_numeric','EfficientSU2 · 16 qubits · numeric'),
                     ('pauli_layers_16_symbolic','Pauli layers · 16 qubits · symbolic'),
                     ('equatorial_frames_16_symbolic','Equatorial frames · 16 qubits · symbolic')]
    absolute_metrics=[('native_2q','Native two-qubit gates'),('native_1q_non_rz','Native one-qubit gates excluding RZ'),('synthesis_ms','Synthesis time (ms)')]
    fig,axs=plt.subplots(len(representatives),3,figsize=(20,15),layout='constrained')
    colors=['#547aa5','#c06430'];absolute=[]
    for row_index,(case_id,case_title) in enumerate(representatives):
        for column,(metric,title) in enumerate(absolute_metrics):
            ax=axs[row_index,column];any_values=False
            for revision,(label,ds) in enumerate(zip(labels,datasets,strict=True)):
                offset=(revision-.5)*.36
                for i,name in enumerate(names):
                    row=ds.get((case_id,name),{})
                    value=row.get(metric)
                    if row.get('status')=='exported' and row.get('validation',{}).get('passed') and isinstance(value,(int,float)):
                        any_values=True
                        if metric=='synthesis_ms':ax.scatter(i+offset,value,color=colors[revision],marker='o' if revision==0 else 's',s=24)
                        else:ax.bar(i+offset,value,width=.34,color=colors[revision])
                        ax.annotate(f'{value:.1f}' if metric=='synthesis_ms' else str(value),
                                    (i+offset,value),xytext=(0,3),textcoords='offset points',
                                    ha='center',va='bottom',fontsize=6,rotation=90)
                        absolute.append(dict(case=case_id,target=name,revision=label,metric=metric,value=value))
                    else:
                        ax.text(i+offset,.015,'×',transform=ax.get_xaxis_transform(),color=colors[revision],ha='center',va='bottom',fontsize=11)
            ax.set_title(case_title+'\n'+title,fontsize=10)
            ax.set_xticks(range(len(names)),display_names,rotation=45,ha='right',fontsize=7)
            ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True);ax.set_xlim(-.6,len(names)-.4);ax.margins(y=.2)
            ax.set_ylim(bottom=0)
            if metric=='synthesis_ms':
                ax.yaxis.set_major_locator(MaxNLocator(nbins=5))
                ax.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
                if not any_values:ax.set_ylim(0,1)
    from matplotlib.patches import Patch
    fig.legend(handles=[Patch(facecolor=color,label=label) for color,label in zip(colors,labels,strict=True)],
               loc='outside upper right',ncols=2)
    fig.suptitle('Absolute results on representative largest workloads\n'
                 '× = no validated native export (unsupported or failed); RZ counts remain in raw data')
    for ext in ['png','pdf','svg']:fig.savefig(args.output/('absolute_representatives.'+ext),dpi=180)
    plt.close(fig)
    dump(args.output/'absolute_summary.json',absolute)
    dump(args.output/'paired_summary.json',summary)
    dump(args.output/'comparison_metadata.json',{'baseline':json.loads((args.baseline/'metadata.json').read_text()),'branch':json.loads((args.branch/'metadata.json').read_text()),'plot_matplotlib':matplotlib.__version__,'plot_numpy':np.__version__,
                                              'plot_harness_sha256':sha(Path(__file__)),
                                              'measured_harness_snapshot':str(Path(__file__).with_name('evaluate-measured.py')),
                                              'measured_harness_sha256':sha(Path(__file__).with_name('evaluate-measured.py'))})
    print(f'Wrote CSV, summary, metadata, and PNG/PDF/SVG plots to {args.output}')

def main():
    parser=argparse.ArgumentParser(description=__doc__);subs=parser.add_subparsers(dest='command',required=True)
    for command in ['generate','run']:
        p=subs.add_parser(command);p.add_argument('--corpus',type=Path,default=ROOT/'corpus');p.add_argument('--checkout',type=Path,required=True)
        if command=='run':
            p.add_argument('--output',type=Path,required=True);p.add_argument('--case',default='.');p.add_argument('--target',default='.')
            p.add_argument('--repetitions',type=int,default=5);p.add_argument('--shots',type=int,default=512);p.add_argument('--save-ir',action='store_true')
    p=subs.add_parser('plot');p.add_argument('--baseline',type=Path,required=True);p.add_argument('--branch',type=Path,required=True);p.add_argument('--output',type=Path,default=ROOT/'plots')
    args=parser.parse_args()
    if args.command=='run' and args.repetitions<5:parser.error('Use at least five timed repetitions')
    globals()[args.command](args)
if __name__=='__main__':main()
