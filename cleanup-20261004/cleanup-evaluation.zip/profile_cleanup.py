import os,json,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ENV=os.environ|dict(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',QISKIT_NUM_PROCS='1')
while len(list((ROOT/'paired').glob('*/*/done.json')))<20:time.sleep(2)
(ROOT/'profiles').mkdir(exist_ok=True)
cases=[('core_qft_156','ibm_sxz_cz'),('core_qft_156','ibm_fractional_bounded'),('efficient_su2_156_symbolic','ibm_sxz_cz'),('core_grover_54','iqm_r_cz'),('pauli_layers_54_numeric','iqm_r_cz')]
for case,target in cases:
 for label,python in [('before',ROOT/'baseline-venv/bin/python'),('after',Path('/home/nvidia/.codex/worktrees/pr2578-audit/core/.venv/bin/python'))]:
  path=ROOT/'profiles'/(case+'__'+target+'__'+label)
  with path.with_suffix('.stdout').open('w') as out,path.with_suffix('.stderr').open('w') as err:
   subprocess.run(['taskset','-c','5',str(python),str(ROOT/'large.py'),'profile','--case',case,'--target',target,'--repetitions','3','--timing'],env=ENV,stdout=out,stderr=err,check=True)
  print(case,target,label,flush=True)
(ROOT/'measurements.complete').write_text('Paired timing and pass profiles complete.\n')
