"""Compare rebuilt previous source with current source; no performance claims."""
import json,sys
from pathlib import Path
if '--previous' in sys.argv:
 import importlib.util,mqt.core
 spec=importlib.util.spec_from_file_location('mqt.core.mlir',Path(__file__).with_name('rebuilt-previous-mlir.abi3.so'))
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 sys.modules['mqt.core.mlir']=module;mqt.core.mlir=module
from mqt.core.mlir import QCOProgram,CompilationOptions
from diagnose import environment
import evaluate as h
for case,target in [('efficient_su2_24_symbolic',t) for t in ['ibm_fractional_bounded','ionq_fixed_r_zz','rxrz_rzz_unbounded']]+[('core_w_state_36','ibm_sxz_cx'),('core_multiplexer_24','ibm_sxz_cx')]:
 width=int(case.split('_')[-1] if case.startswith('core_') else case.split('_')[-2]);t,env=environment(target,width)
 program=QCOProgram.from_mlir_file(Path(__file__).parent/'corpus'/(case+'.mlir'));program.synthesize_for_target(env,options=CompilationOptions(seed=h.SEED))
 print(json.dumps(dict(case=case,target=target,**h.counts(program.to_qiskit(target=t)))),flush=True)
