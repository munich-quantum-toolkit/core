module attributes {mqt.layout = {initial = array<i64: 3, 1, 2, 0, 5, 7, 4, 6>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = [], parameter_bounds = [array<f64: 0.000000e+00, 1.5707963267948966>]>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant 0.19634954084936229 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant -3.1415926535897931 : f64
    %cst_2 = arith.constant 0.78539816339744828 : f64
    %cst_3 = arith.constant -0.78539816339744828 : f64
    %cst_4 = arith.constant 0.39269908169872414 : f64
    %cst_5 = arith.constant -0.39269908169872414 : f64
    %cst_6 = arith.constant 0.19634954084936207 : f64
    %cst_7 = arith.constant -0.19634954084936229 : f64
    %cst_8 = arith.constant 1.5707963267948966 : f64
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.rz(%cst_8) %0 : !qco.qubit -> !qco.qubit
    %9 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %10 = qco.rz(%cst_8) %6 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_8) %10 : !qco.qubit -> !qco.qubit
    %cst_9 = arith.constant 2.3561944901923448 : f64
    %12 = qco.rz(%cst_9) %11 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_2) %4, %12 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %13 = qco.rz(%cst_2) %qubit0_out : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_8) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_3) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_4) %qubit1_out : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_8) %7 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_1) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_8) %18 : !qco.qubit -> !qco.qubit
    %qubit0_out_10, %qubit1_out_11 = qco.rzz(%cst_4) %19, %16 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_12 = arith.constant -0.39269908169872281 : f64
    %20 = qco.rz(%cst_12) %qubit0_out_10 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst) %qubit1_out_11 : !qco.qubit -> !qco.qubit
    %qubit0_out_13, %qubit1_out_14 = qco.rzz(%cst_6) %5, %21 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_15 = arith.constant -0.1963495408493614 : f64
    %22 = qco.rz(%cst_15) %qubit0_out_13 : !qco.qubit -> !qco.qubit
    %qubit0_out_16, %qubit1_out_17 = qco.rzz(%cst_2) %20, %15 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %23 = qco.rz(%cst_2) %qubit0_out_16 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_8) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_3) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_4) %qubit1_out_17 : !qco.qubit -> !qco.qubit
    %qubit0_out_18, %qubit1_out_19 = qco.rzz(%cst_4) %22, %26 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %27 = qco.rz(%cst_12) %qubit0_out_18 : !qco.qubit -> !qco.qubit
    %qubit0_out_20, %qubit1_out_21 = qco.rzz(%cst_2) %27, %25 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %28 = qco.rz(%cst_2) %qubit0_out_20 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_0) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_1) %qubit1_out_14 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_0) %30 : !qco.qubit -> !qco.qubit
    %qubit0_out_22, %qubit1_out_23 = qco.rzz(%cst_8) %8, %31 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %32 = qco.rz(%cst_8) %qubit1_out_23 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_1) %32 : !qco.qubit -> !qco.qubit
    %cst_24 = arith.constant -0.78539816339744872 : f64
    %34 = qco.rz(%cst_24) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_8) %qubit0_out_22 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_1) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_8) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_8) %2 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_1) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_8) %39 : !qco.qubit -> !qco.qubit
    %qubit0_out_25, %qubit1_out_26 = qco.rzz(%cst_2) %40, %34 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_27 = arith.constant 0.78539816339744916 : f64
    %41 = qco.rz(%cst_27) %qubit0_out_25 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_4) %qubit1_out_26 : !qco.qubit -> !qco.qubit
    %qubit0_out_28, %qubit1_out_29 = qco.rzz(%cst_4) %1, %42 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %43 = qco.rz(%cst_12) %qubit0_out_28 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst) %qubit1_out_29 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_8) %3 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst_1) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_8) %46 : !qco.qubit -> !qco.qubit
    %qubit0_out_30, %qubit1_out_31 = qco.rzz(%cst_6) %47, %44 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %48 = qco.rz(%cst_15) %qubit0_out_30 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_1) %qubit1_out_19 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_0) %49 : !qco.qubit -> !qco.qubit
    %qubit0_out_32, %qubit1_out_33 = qco.rzz(%cst_8) %41, %50 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %51 = qco.rz(%cst_8) %qubit1_out_33 : !qco.qubit -> !qco.qubit
    %52 = qco.rx(%cst_1) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_24) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_8) %qubit0_out_32 : !qco.qubit -> !qco.qubit
    %55 = qco.rx(%cst_1) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_8) %55 : !qco.qubit -> !qco.qubit
    %qubit0_out_34, %qubit1_out_35 = qco.rzz(%cst_2) %43, %53 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %57 = qco.rz(%cst_27) %qubit0_out_34 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_4) %qubit1_out_35 : !qco.qubit -> !qco.qubit
    %qubit0_out_36, %qubit1_out_37 = qco.rzz(%cst_4) %48, %58 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %59 = qco.rz(%cst_12) %qubit0_out_36 : !qco.qubit -> !qco.qubit
    %60 = qco.rx(%cst_1) %qubit1_out_21 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_0) %60 : !qco.qubit -> !qco.qubit
    %qubit0_out_38, %qubit1_out_39 = qco.rzz(%cst_8) %57, %61 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %62 = qco.rz(%cst_8) %qubit1_out_39 : !qco.qubit -> !qco.qubit
    %63 = qco.rx(%cst_1) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_24) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_8) %qubit0_out_38 : !qco.qubit -> !qco.qubit
    %66 = qco.rx(%cst_1) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_8) %66 : !qco.qubit -> !qco.qubit
    %qubit0_out_40, %qubit1_out_41 = qco.rzz(%cst_2) %59, %64 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %68 = qco.rz(%cst_27) %qubit0_out_40 : !qco.qubit -> !qco.qubit
    %qubit0_out_42, %qubit1_out_43 = qco.rzz(%cst_8) %68, %29 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_44 = arith.constant -1.5707963267948961 : f64
    %69 = qco.rz(%cst_44) %qubit1_out_43 : !qco.qubit -> !qco.qubit
    %70 = qco.rx(%cst_8) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_0) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_8) %qubit0_out_42 : !qco.qubit -> !qco.qubit
    %73 = qco.rx(%cst_1) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_8) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_3) %qubit1_out_41 : !qco.qubit -> !qco.qubit
    %qubit0_out_45, %qubit1_out_46 = qco.rzz(%cst_2) %71, %75 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %76 = qco.rz(%cst_3) %qubit0_out_45 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_8) %qubit1_out_46 : !qco.qubit -> !qco.qubit
    %78 = qco.rx(%cst_8) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_8) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_3) %qubit1_out_37 : !qco.qubit -> !qco.qubit
    %qubit0_out_47, %qubit1_out_48 = qco.rzz(%cst_2) %79, %80 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %81 = qco.rz(%cst_3) %qubit0_out_47 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_5) %qubit1_out_48 : !qco.qubit -> !qco.qubit
    %qubit0_out_49, %qubit1_out_50 = qco.rzz(%cst_4) %76, %82 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %83 = qco.rz(%cst_5) %qubit0_out_49 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_8) %qubit1_out_50 : !qco.qubit -> !qco.qubit
    %85 = qco.rx(%cst_8) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_8) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_3) %qubit1_out_31 : !qco.qubit -> !qco.qubit
    %qubit0_out_51, %qubit1_out_52 = qco.rzz(%cst_2) %86, %87 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %88 = qco.rz(%cst_3) %qubit0_out_51 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_5) %qubit1_out_52 : !qco.qubit -> !qco.qubit
    %qubit0_out_53, %qubit1_out_54 = qco.rzz(%cst_4) %81, %89 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %90 = qco.rz(%cst_5) %qubit0_out_53 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_7) %qubit1_out_54 : !qco.qubit -> !qco.qubit
    %qubit0_out_55, %qubit1_out_56 = qco.rzz(%cst_6) %83, %91 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %92 = qco.rz(%cst_7) %qubit0_out_55 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_8) %qubit1_out_56 : !qco.qubit -> !qco.qubit
    %94 = qco.rx(%cst_8) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_8) %94 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %92 : !qco.qubit
    cbit.store %result, %9[%c0] : !cbit.reg<8>
    %qubit_out_57, %result_58 = qco.measure %90 : !qco.qubit
    cbit.store %result_58, %9[%c1] : !cbit.reg<8>
    %qubit_out_59, %result_60 = qco.measure %88 : !qco.qubit
    cbit.store %result_60, %9[%c2] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_57 : !qco.qubit
    qco.sink %qubit_out_59 : !qco.qubit
    %qubit_out_61, %result_62 = qco.measure %95 : !qco.qubit
    qco.sink %qubit_out_61 : !qco.qubit
    cbit.store %result_62, %9[%c3] : !cbit.reg<8>
    %qubit_out_63, %result_64 = qco.measure %74 : !qco.qubit
    cbit.store %result_64, %9[%c4] : !cbit.reg<8>
    %qubit_out_65, %result_66 = qco.measure %67 : !qco.qubit
    cbit.store %result_66, %9[%c5] : !cbit.reg<8>
    %qubit_out_67, %result_68 = qco.measure %56 : !qco.qubit
    cbit.store %result_68, %9[%c6] : !cbit.reg<8>
    qco.sink %qubit_out_63 : !qco.qubit
    qco.sink %qubit_out_65 : !qco.qubit
    qco.sink %qubit_out_67 : !qco.qubit
    %qubit_out_69, %result_70 = qco.measure %37 : !qco.qubit
    qco.sink %qubit_out_69 : !qco.qubit
    cbit.store %result_70, %9[%c7] : !cbit.reg<8>
    %cst_71 = arith.constant -1.4726215563702159 : f64
    qco.gphase(%cst_71)
    return %9 : !cbit.reg<8>
  }
}
