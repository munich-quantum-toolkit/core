module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant -4.7123889803846897 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %cst_2 = arith.constant 0.000000e+00 : f64
    %cst_3 = arith.constant 3.1415926535897931 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %9 = qco.r(%cst_2, %cst_1) %0 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_3, %cst_2) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_1, %cst_0) %1 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_1, %cst_0) %3 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_1, %cst_0) %5 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_1, %cst_0) %7 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%11) targets (%arg0 = %10) {
      %19 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %19 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_4, %targets_out_5 = qco.ctrl(%12) targets (%arg0 = %targets_out) {
      %19 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %19 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_6, %targets_out_7 = qco.ctrl(%13) targets (%arg0 = %targets_out_5) {
      %19 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %19 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_8, %targets_out_9 = qco.ctrl(%14) targets (%arg0 = %targets_out_7) {
      %19 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %19 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qco.r(%cst_1, %cst) %controls_out : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_1, %cst) %controls_out_4 : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_1, %cst) %controls_out_6 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_1, %cst) %controls_out_8 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %15 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<7>
    %qubit_out_10, %result_11 = qco.measure %2 : !qco.qubit
    cbit.store %result_11, %8[%c1] : !cbit.reg<7>
    %qubit_out_12, %result_13 = qco.measure %16 : !qco.qubit
    cbit.store %result_13, %8[%c2] : !cbit.reg<7>
    %qubit_out_14, %result_15 = qco.measure %4 : !qco.qubit
    cbit.store %result_15, %8[%c3] : !cbit.reg<7>
    %qubit_out_16, %result_17 = qco.measure %17 : !qco.qubit
    cbit.store %result_17, %8[%c4] : !cbit.reg<7>
    %qubit_out_18, %result_19 = qco.measure %6 : !qco.qubit
    cbit.store %result_19, %8[%c5] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_10 : !qco.qubit
    qco.sink %qubit_out_12 : !qco.qubit
    qco.sink %qubit_out_14 : !qco.qubit
    qco.sink %qubit_out_16 : !qco.qubit
    qco.sink %qubit_out_18 : !qco.qubit
    %qubit_out_20, %result_21 = qco.measure %18 : !qco.qubit
    qco.sink %qubit_out_20 : !qco.qubit
    cbit.store %result_21, %8[%c6] : !cbit.reg<7>
    qco.sink %targets_out_9 : !qco.qubit
    qco.gphase(%cst_1)
    return %8 : !cbit.reg<7>
  }
}
