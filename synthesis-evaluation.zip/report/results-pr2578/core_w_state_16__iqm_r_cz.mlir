module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<16> attributes {mqt.entry_point} {
    %cst = arith.constant 4.632431606138109 : f64
    %cst_0 = arith.constant 1.4908389525483157 : f64
    %cst_1 = arith.constant 3.1016139664665023 : f64
    %cst_2 = arith.constant 1.5707963267948968 : f64
    %cst_3 = arith.constant 1.5707963267948959 : f64
    %cst_4 = arith.constant 1.5707963267948943 : f64
    %cst_5 = arith.constant 1.7039326543465436 : f64
    %cst_6 = arith.constant 6.3497534709554095 : f64
    %cst_7 = arith.constant 1.7521161011963868 : f64
    %cst_8 = arith.constant 3.2322525407905385 : f64
    %cst_9 = arith.constant 6.8397846251898091 : f64
    %cst_10 = arith.constant 5.7760868027872494 : f64
    %cst_11 = arith.constant 4.7123889803846897 : f64
    %cst_12 = arith.constant 1.570796326794893 : f64
    %cst_13 = arith.constant 5.4977871437821344 : f64
    %cst_14 = arith.constant 1.5707963267948932 : f64
    %cst_15 = arith.constant -1.6313838466324446 : f64
    %cst_16 = arith.constant -3.1718864135085658 : f64
    %cst_17 = arith.constant -2.4980915447965044 : f64
    %cst_18 = arith.constant -1.5707963267948939 : f64
    %cst_19 = arith.constant -3.6052402625905948 : f64
    %cst_20 = arith.constant 1.7521161011963833 : f64
    %cst_21 = arith.constant -1.5707963267948921 : f64
    %cst_22 = arith.constant 4.9337034227324752 : f64
    %cst_23 = arith.constant 6.373845194380328 : f64
    %cst_24 = arith.constant 4.9337034227324743 : f64
    %cst_25 = arith.constant -4.7864292121325498 : f64
    %cst_26 = arith.constant 6.3938425283534759 : f64
    %cst_27 = arith.constant -4.786429212132548 : f64
    %cst_28 = arith.constant 4.7123889803846843 : f64
    %cst_29 = arith.constant -3.1786127694637223 : f64
    %cst_30 = arith.constant -2.8112952987605313 : f64
    %cst_31 = arith.constant -1.5707963267948948 : f64
    %cst_32 = arith.constant 3.6315499798435185 : f64
    %cst_33 = arith.constant -0.62024948598281338 : f64
    %cst_34 = arith.constant 3.631549979843518 : f64
    %cst_35 = arith.constant -1.5707963267948886 : f64
    %cst_36 = arith.constant -1.5707963267948903 : f64
    %cst_37 = arith.constant 5.7427658069089986 : f64
    %cst_38 = arith.constant 4.7123889803846861 : f64
    %cst_39 = arith.constant -1.570796326794893 : f64
    %cst_40 = arith.constant 4.712388980384687 : f64
    %cst_41 = arith.constant 1.8988215193149856E-15 : f64
    %cst_42 = arith.constant 1.8234765819369745 : f64
    %cst_43 = arith.constant 1.8234765819369743 : f64
    %cst_44 = arith.constant 3.1415926535897913 : f64
    %cst_45 = arith.constant 1.5707963267948948 : f64
    %cst_46 = arith.constant 1.8319537376979209 : f64
    %cst_47 = arith.constant 1.8413460897734701 : f64
    %cst_48 = arith.constant 1.8413460897734681 : f64
    %cst_49 = arith.constant 3.1415926535897896 : f64
    %cst_50 = arith.constant 1.8518312282977105 : f64
    %cst_51 = arith.constant 1.8518312282977094 : f64
    %cst_52 = arith.constant 1.8636390985234712 : f64
    %cst_53 = arith.constant 1.8770736959645653 : f64
    %cst_54 = arith.constant 1.877073695964566 : f64
    %cst_55 = arith.constant 1.8925468811915389 : f64
    %cst_56 = arith.constant 1.8925468811915387 : f64
    %cst_57 = arith.constant 1.9913306620788616 : f64
    %cst_58 = arith.constant 2.0344439357957018 : f64
    %cst_59 = arith.constant 2.0943951023931948 : f64
    %cst_60 = arith.constant 0.95531661812450963 : f64
    %cst_61 = arith.constant 2.1862760354652835 : f64
    %cst_62 = arith.constant 2.3561944901923439 : f64
    %cst_63 = arith.constant 1.570796326794897 : f64
    %cst_64 = arith.constant 2.3561944901923453 : f64
    %cst_65 = arith.constant 2.0943951023931953 : f64
    %cst_66 = arith.constant 2.0344439357957023 : f64
    %cst_67 = arith.constant 1.991330662078862 : f64
    %cst_68 = arith.constant 1.9583930134500767 : f64
    %cst_69 = arith.constant 1.9321634507016041 : f64
    %cst_70 = arith.constant 1.9106332362490184 : f64
    %cst_71 = arith.constant 1.8636390985234721 : f64
    %cst_72 = arith.constant 3.1415926535897931 : f64
    %cst_73 = arith.constant -1.5707963267948966 : f64
    %cst_74 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %c15 = arith.constant 15 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<16>
    %17 = qco.r(%cst_41, %cst_74) %0 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_42, %cst_40) %1 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%17) targets (%arg0 = %18) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.r(%cst_43, %cst_38) %targets_out : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_74, %cst_72) %controls_out : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%20) targets (%arg0 = %19) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.r(%cst_44, %cst_37) %targets_out_76 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_74, %cst_72) %controls_out_75 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_46, %cst_36) %2 : !qco.qubit -> !qco.qubit
    %controls_out_77, %targets_out_78 = qco.ctrl(%21) targets (%arg0 = %23) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.r(%cst_46, %cst_35) %targets_out_78 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_74, %cst_34) %controls_out_77 : !qco.qubit -> !qco.qubit
    %controls_out_79, %targets_out_80 = qco.ctrl(%25) targets (%arg0 = %24) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.r(%cst_72, %cst_33) %targets_out_80 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst_74, %cst_32) %controls_out_79 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_47, %cst_31) %3 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%26) targets (%arg0 = %28) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.r(%cst_48, %cst_31) %targets_out_82 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_74, %cst_30) %controls_out_81 : !qco.qubit -> !qco.qubit
    %controls_out_83, %targets_out_84 = qco.ctrl(%30) targets (%arg0 = %29) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.r(%cst_49, %cst_29) %targets_out_84 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_74, %cst_30) %controls_out_83 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_50, %cst_38) %4 : !qco.qubit -> !qco.qubit
    %controls_out_85, %targets_out_86 = qco.ctrl(%31) targets (%arg0 = %33) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.r(%cst_51, %cst_28) %targets_out_86 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst_74, %cst_27) %controls_out_85 : !qco.qubit -> !qco.qubit
    %controls_out_87, %targets_out_88 = qco.ctrl(%35) targets (%arg0 = %34) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qco.r(%cst_49, %cst_26) %targets_out_88 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%cst_74, %cst_25) %controls_out_87 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst_71, %cst_40) %5 : !qco.qubit -> !qco.qubit
    %controls_out_89, %targets_out_90 = qco.ctrl(%36) targets (%arg0 = %38) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.r(%cst_52, %cst_38) %targets_out_90 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_74, %cst_24) %controls_out_89 : !qco.qubit -> !qco.qubit
    %controls_out_91, %targets_out_92 = qco.ctrl(%40) targets (%arg0 = %39) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.r(%cst_72, %cst_23) %targets_out_92 : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst_74, %cst_22) %controls_out_91 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%cst_53, %cst_39) %6 : !qco.qubit -> !qco.qubit
    %controls_out_93, %targets_out_94 = qco.ctrl(%41) targets (%arg0 = %43) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = qco.r(%cst_54, %cst_21) %targets_out_94 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst_74, %cst_20) %controls_out_93 : !qco.qubit -> !qco.qubit
    %controls_out_95, %targets_out_96 = qco.ctrl(%45) targets (%arg0 = %44) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qco.r(%cst_72, %cst_19) %targets_out_96 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%cst_74, %cst_20) %controls_out_95 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst_55, %cst_31) %7 : !qco.qubit -> !qco.qubit
    %controls_out_97, %targets_out_98 = qco.ctrl(%46) targets (%arg0 = %48) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qco.r(%cst_56, %cst_18) %targets_out_98 : !qco.qubit -> !qco.qubit
    %50 = qco.r(%cst_74, %cst_17) %controls_out_97 : !qco.qubit -> !qco.qubit
    %controls_out_99, %targets_out_100 = qco.ctrl(%50) targets (%arg0 = %49) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %51 = qco.r(%cst_44, %cst_16) %targets_out_100 : !qco.qubit -> !qco.qubit
    %52 = qco.r(%cst_74, %cst_17) %controls_out_99 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst_70, %cst_40) %8 : !qco.qubit -> !qco.qubit
    %controls_out_101, %targets_out_102 = qco.ctrl(%51) targets (%arg0 = %53) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %54 = qco.r(%cst_70, %cst_38) %targets_out_102 : !qco.qubit -> !qco.qubit
    %55 = qco.r(%cst_74, %cst_15) %controls_out_101 : !qco.qubit -> !qco.qubit
    %controls_out_103, %targets_out_104 = qco.ctrl(%55) targets (%arg0 = %54) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qco.r(%cst_44, %cst_49) %targets_out_104 : !qco.qubit -> !qco.qubit
    %57 = qco.r(%cst_74, %cst_15) %controls_out_103 : !qco.qubit -> !qco.qubit
    %58 = qco.r(%cst_69, %cst_40) %9 : !qco.qubit -> !qco.qubit
    %controls_out_105, %targets_out_106 = qco.ctrl(%56) targets (%arg0 = %58) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qco.r(%cst_69, %cst_38) %targets_out_106 : !qco.qubit -> !qco.qubit
    %60 = qco.r(%cst_74, %cst_14) %controls_out_105 : !qco.qubit -> !qco.qubit
    %controls_out_107, %targets_out_108 = qco.ctrl(%60) targets (%arg0 = %59) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qco.r(%cst_72, %cst_13) %targets_out_108 : !qco.qubit -> !qco.qubit
    %62 = qco.r(%cst_74, %cst_12) %controls_out_107 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%cst_68, %cst_11) %10 : !qco.qubit -> !qco.qubit
    %controls_out_109, %targets_out_110 = qco.ctrl(%61) targets (%arg0 = %63) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %64 = qco.r(%cst_68, %cst_11) %targets_out_110 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%cst_74, %cst_49) %controls_out_109 : !qco.qubit -> !qco.qubit
    %controls_out_111, %targets_out_112 = qco.ctrl(%65) targets (%arg0 = %64) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = qco.r(%cst_44, %cst_10) %targets_out_112 : !qco.qubit -> !qco.qubit
    %67 = qco.r(%cst_74, %cst_49) %controls_out_111 : !qco.qubit -> !qco.qubit
    %68 = qco.r(%cst_67, %cst_11) %11 : !qco.qubit -> !qco.qubit
    %controls_out_113, %targets_out_114 = qco.ctrl(%66) targets (%arg0 = %68) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qco.r(%cst_57, %cst_11) %targets_out_114 : !qco.qubit -> !qco.qubit
    %70 = qco.r(%cst_74, %cst_9) %controls_out_113 : !qco.qubit -> !qco.qubit
    %controls_out_115, %targets_out_116 = qco.ctrl(%70) targets (%arg0 = %69) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qco.r(%cst_44, %cst_8) %targets_out_116 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%cst_74, %cst_9) %controls_out_115 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%cst_66, %cst_11) %12 : !qco.qubit -> !qco.qubit
    %controls_out_117, %targets_out_118 = qco.ctrl(%71) targets (%arg0 = %73) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %74 = qco.r(%cst_58, %cst_11) %targets_out_118 : !qco.qubit -> !qco.qubit
    %75 = qco.r(%cst_74, %cst_7) %controls_out_117 : !qco.qubit -> !qco.qubit
    %controls_out_119, %targets_out_120 = qco.ctrl(%75) targets (%arg0 = %74) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %76 = qco.r(%cst_44, %cst_6) %targets_out_120 : !qco.qubit -> !qco.qubit
    %77 = qco.r(%cst_74, %cst_7) %controls_out_119 : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst_65, %cst_11) %13 : !qco.qubit -> !qco.qubit
    %controls_out_121, %targets_out_122 = qco.ctrl(%76) targets (%arg0 = %78) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %79 = qco.r(%cst_59, %cst_11) %targets_out_122 : !qco.qubit -> !qco.qubit
    %80 = qco.r(%cst_74, %cst_5) %controls_out_121 : !qco.qubit -> !qco.qubit
    %controls_out_123, %targets_out_124 = qco.ctrl(%80) targets (%arg0 = %79) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %81 = qco.r(%cst_74, %cst_5) %controls_out_123 : !qco.qubit -> !qco.qubit
    %82 = qco.r(%cst_60, %cst_4) %14 : !qco.qubit -> !qco.qubit
    %controls_out_125, %targets_out_126 = qco.ctrl(%targets_out_124) targets (%arg0 = %82) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qco.r(%cst_61, %cst_3) %targets_out_126 : !qco.qubit -> !qco.qubit
    %84 = qco.r(%cst_74, %cst_2) %controls_out_125 : !qco.qubit -> !qco.qubit
    %controls_out_127, %targets_out_128 = qco.ctrl(%84) targets (%arg0 = %83) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %85 = qco.r(%cst_44, %cst_1) %targets_out_128 : !qco.qubit -> !qco.qubit
    %86 = qco.r(%cst_74, %cst_45) %controls_out_127 : !qco.qubit -> !qco.qubit
    %87 = qco.r(%cst_64, %cst_73) %15 : !qco.qubit -> !qco.qubit
    %controls_out_129, %targets_out_130 = qco.ctrl(%85) targets (%arg0 = %87) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %88 = qco.r(%cst_62, %cst_74) %targets_out_130 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%cst_74, %cst_0) %controls_out_129 : !qco.qubit -> !qco.qubit
    %controls_out_131, %targets_out_132 = qco.ctrl(%89) targets (%arg0 = %88) {
      %91 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %91 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %90 = qco.r(%cst_63, %cst) %controls_out_131 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %22 : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<16>
    %qubit_out_133, %result_134 = qco.measure %27 : !qco.qubit
    cbit.store %result_134, %16[%c1] : !cbit.reg<16>
    %qubit_out_135, %result_136 = qco.measure %32 : !qco.qubit
    cbit.store %result_136, %16[%c2] : !cbit.reg<16>
    %qubit_out_137, %result_138 = qco.measure %37 : !qco.qubit
    cbit.store %result_138, %16[%c3] : !cbit.reg<16>
    %qubit_out_139, %result_140 = qco.measure %42 : !qco.qubit
    cbit.store %result_140, %16[%c4] : !cbit.reg<16>
    %qubit_out_141, %result_142 = qco.measure %47 : !qco.qubit
    cbit.store %result_142, %16[%c5] : !cbit.reg<16>
    %qubit_out_143, %result_144 = qco.measure %52 : !qco.qubit
    cbit.store %result_144, %16[%c6] : !cbit.reg<16>
    %qubit_out_145, %result_146 = qco.measure %57 : !qco.qubit
    cbit.store %result_146, %16[%c7] : !cbit.reg<16>
    %qubit_out_147, %result_148 = qco.measure %62 : !qco.qubit
    cbit.store %result_148, %16[%c8] : !cbit.reg<16>
    %qubit_out_149, %result_150 = qco.measure %67 : !qco.qubit
    cbit.store %result_150, %16[%c9] : !cbit.reg<16>
    %qubit_out_151, %result_152 = qco.measure %72 : !qco.qubit
    cbit.store %result_152, %16[%c10] : !cbit.reg<16>
    %qubit_out_153, %result_154 = qco.measure %77 : !qco.qubit
    cbit.store %result_154, %16[%c11] : !cbit.reg<16>
    %qubit_out_155, %result_156 = qco.measure %81 : !qco.qubit
    cbit.store %result_156, %16[%c12] : !cbit.reg<16>
    %qubit_out_157, %result_158 = qco.measure %86 : !qco.qubit
    cbit.store %result_158, %16[%c13] : !cbit.reg<16>
    %qubit_out_159, %result_160 = qco.measure %90 : !qco.qubit
    cbit.store %result_160, %16[%c14] : !cbit.reg<16>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_133 : !qco.qubit
    qco.sink %qubit_out_135 : !qco.qubit
    qco.sink %qubit_out_137 : !qco.qubit
    qco.sink %qubit_out_139 : !qco.qubit
    qco.sink %qubit_out_141 : !qco.qubit
    qco.sink %qubit_out_143 : !qco.qubit
    qco.sink %qubit_out_145 : !qco.qubit
    qco.sink %qubit_out_147 : !qco.qubit
    qco.sink %qubit_out_149 : !qco.qubit
    qco.sink %qubit_out_151 : !qco.qubit
    qco.sink %qubit_out_153 : !qco.qubit
    qco.sink %qubit_out_155 : !qco.qubit
    qco.sink %qubit_out_157 : !qco.qubit
    qco.sink %qubit_out_159 : !qco.qubit
    %qubit_out_161, %result_162 = qco.measure %targets_out_132 : !qco.qubit
    qco.sink %qubit_out_161 : !qco.qubit
    cbit.store %result_162, %16[%c15] : !cbit.reg<16>
    %cst_163 = arith.constant 2.356194490192367 : f64
    qco.gphase(%cst_163)
    return %16 : !cbit.reg<16>
  }
}
