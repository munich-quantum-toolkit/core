module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<16> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948966 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant -1.5707963267948968 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %c15 = arith.constant 15 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<16>
    %17 = qco.r(%cst_0, %cst) %0 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_1, %cst_0) %1 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%17) targets (%arg0 = %18) {
      %48 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %48 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.r(%cst_0, %cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_1, %cst_0) %2 : !qco.qubit -> !qco.qubit
    %controls_out_2, %targets_out_3 = qco.ctrl(%19) targets (%arg0 = %20) {
      %48 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %48 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.r(%cst_0, %cst_0) %targets_out_3 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_1, %cst_0) %3 : !qco.qubit -> !qco.qubit
    %controls_out_4, %targets_out_5 = qco.ctrl(%21) targets (%arg0 = %22) {
      %48 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %48 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qco.r(%cst_0, %cst_0) %targets_out_5 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_1, %cst_0) %4 : !qco.qubit -> !qco.qubit
    %controls_out_6, %targets_out_7 = qco.ctrl(%23) targets (%arg0 = %24) {
      %48 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %48 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %25 = qco.r(%cst_0, %cst_0) %targets_out_7 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_1, %cst_0) %5 : !qco.qubit -> !qco.qubit
    %controls_out_8, %targets_out_9 = qco.ctrl(%25) targets (%arg0 = %26) {
      %48 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %48 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %27 = qco.r(%cst_0, %cst_0) %targets_out_9 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_1, %cst_0) %6 : !qco.qubit -> !qco.qubit
    %controls_out_10, %targets_out_11 = qco.ctrl(%27) targets (%arg0 = %28) {
      %48 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %48 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.r(%cst_0, %cst_0) %targets_out_11 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_1, %cst_0) %7 : !qco.qubit -> !qco.qubit
    %controls_out_12, %targets_out_13 = qco.ctrl(%29) targets (%arg0 = %30) {
      %48 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %48 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.r(%cst_0, %cst_0) %targets_out_13 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_1, %cst_0) %8 : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%31) targets (%arg0 = %32) {
      %48 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %48 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %33 = qco.r(%cst_0, %cst_0) %targets_out_15 : !qco.qubit -> !qco.qubit
    %34 = qco.r(%cst_1, %cst_0) %9 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%33) targets (%arg0 = %34) {
      %48 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %48 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.r(%cst_0, %cst_0) %targets_out_17 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_1, %cst_0) %10 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%35) targets (%arg0 = %36) {
      %48 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %48 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.r(%cst_0, %cst_0) %targets_out_19 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst_1, %cst_0) %11 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%37) targets (%arg0 = %38) {
      %48 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %48 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.r(%cst_0, %cst_0) %targets_out_21 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_1, %cst_0) %12 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%39) targets (%arg0 = %40) {
      %48 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %48 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.r(%cst_0, %cst_0) %targets_out_23 : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst_1, %cst_0) %13 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%41) targets (%arg0 = %42) {
      %48 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %48 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qco.r(%cst_0, %cst_0) %targets_out_25 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_1, %cst_0) %14 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%43) targets (%arg0 = %44) {
      %48 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %48 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.r(%cst_0, %cst_0) %targets_out_27 : !qco.qubit -> !qco.qubit
    %46 = qco.r(%cst_1, %cst_0) %15 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%45) targets (%arg0 = %46) {
      %48 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %48 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.r(%cst_0, %cst_0) %targets_out_29 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %controls_out : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<16>
    %qubit_out_30, %result_31 = qco.measure %controls_out_2 : !qco.qubit
    cbit.store %result_31, %16[%c1] : !cbit.reg<16>
    %qubit_out_32, %result_33 = qco.measure %controls_out_4 : !qco.qubit
    cbit.store %result_33, %16[%c2] : !cbit.reg<16>
    %qubit_out_34, %result_35 = qco.measure %controls_out_6 : !qco.qubit
    cbit.store %result_35, %16[%c3] : !cbit.reg<16>
    %qubit_out_36, %result_37 = qco.measure %controls_out_8 : !qco.qubit
    cbit.store %result_37, %16[%c4] : !cbit.reg<16>
    %qubit_out_38, %result_39 = qco.measure %controls_out_10 : !qco.qubit
    cbit.store %result_39, %16[%c5] : !cbit.reg<16>
    %qubit_out_40, %result_41 = qco.measure %controls_out_12 : !qco.qubit
    cbit.store %result_41, %16[%c6] : !cbit.reg<16>
    %qubit_out_42, %result_43 = qco.measure %controls_out_14 : !qco.qubit
    cbit.store %result_43, %16[%c7] : !cbit.reg<16>
    %qubit_out_44, %result_45 = qco.measure %controls_out_16 : !qco.qubit
    cbit.store %result_45, %16[%c8] : !cbit.reg<16>
    %qubit_out_46, %result_47 = qco.measure %controls_out_18 : !qco.qubit
    cbit.store %result_47, %16[%c9] : !cbit.reg<16>
    %qubit_out_48, %result_49 = qco.measure %controls_out_20 : !qco.qubit
    cbit.store %result_49, %16[%c10] : !cbit.reg<16>
    %qubit_out_50, %result_51 = qco.measure %controls_out_22 : !qco.qubit
    cbit.store %result_51, %16[%c11] : !cbit.reg<16>
    %qubit_out_52, %result_53 = qco.measure %controls_out_24 : !qco.qubit
    cbit.store %result_53, %16[%c12] : !cbit.reg<16>
    %qubit_out_54, %result_55 = qco.measure %controls_out_26 : !qco.qubit
    cbit.store %result_55, %16[%c13] : !cbit.reg<16>
    %qubit_out_56, %result_57 = qco.measure %controls_out_28 : !qco.qubit
    cbit.store %result_57, %16[%c14] : !cbit.reg<16>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_30 : !qco.qubit
    qco.sink %qubit_out_32 : !qco.qubit
    qco.sink %qubit_out_34 : !qco.qubit
    qco.sink %qubit_out_36 : !qco.qubit
    qco.sink %qubit_out_38 : !qco.qubit
    qco.sink %qubit_out_40 : !qco.qubit
    qco.sink %qubit_out_42 : !qco.qubit
    qco.sink %qubit_out_44 : !qco.qubit
    qco.sink %qubit_out_46 : !qco.qubit
    qco.sink %qubit_out_48 : !qco.qubit
    qco.sink %qubit_out_50 : !qco.qubit
    qco.sink %qubit_out_52 : !qco.qubit
    qco.sink %qubit_out_54 : !qco.qubit
    qco.sink %qubit_out_56 : !qco.qubit
    %qubit_out_58, %result_59 = qco.measure %47 : !qco.qubit
    qco.sink %qubit_out_58 : !qco.qubit
    cbit.store %result_59, %16[%c15] : !cbit.reg<16>
    qco.gphase(%cst_0)
    return %16 : !cbit.reg<16>
  }
}
