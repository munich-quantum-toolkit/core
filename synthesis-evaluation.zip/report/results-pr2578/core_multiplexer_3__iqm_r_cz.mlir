module attributes {mqt.layout = {initial = array<i64: 1, 2, 0>, input_count = 3 : i64, sites = array<i64: 0, 1, 2>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 1.5707963267948968 : f64
    %cst_0 = arith.constant 4.7123889803846897 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %cst_2 = arith.constant 0.78539816339744828 : f64
    %cst_3 = arith.constant 0.39269908169872414 : f64
    %cst_4 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %4 = qco.r(%cst_4, %cst_1) %1 : !qco.qubit -> !qco.qubit
    %5 = qco.r(%cst_4, %cst_1) %2 : !qco.qubit -> !qco.qubit
    %6 = qco.r(%cst_2, %cst_4) %0 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%5) targets (%arg0 = %6) {
      %10 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %10 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %7 = qco.r(%cst_2, %cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_5, %targets_out_6 = qco.ctrl(%controls_out) targets (%arg0 = %7) {
      %10 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %10 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %8 = qco.r(%cst_3, %cst) %targets_out_6 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%4) targets (%arg0 = %8) {
      %10 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %10 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %9 = qco.r(%cst_3, %cst_0) %targets_out_8 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%controls_out_7) targets (%arg0 = %9) {
      %10 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %10 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %qubit_out, %result = qco.measure %targets_out_10 : !qco.qubit
    cbit.store %result, %3[%c0] : !cbit.reg<3>
    %qubit_out_11, %result_12 = qco.measure %controls_out_9 : !qco.qubit
    cbit.store %result_12, %3[%c1] : !cbit.reg<3>
    qco.sink %qubit_out_11 : !qco.qubit
    %qubit_out_13, %result_14 = qco.measure %controls_out_5 : !qco.qubit
    qco.sink %qubit_out_13 : !qco.qubit
    cbit.store %result_14, %3[%c2] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    %cst_15 = arith.constant 3.1415926535897931 : f64
    qco.gphase(%cst_15)
    return %3 : !cbit.reg<3>
  }
}
