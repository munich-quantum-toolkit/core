module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 0>, input_count = 5 : i64, sites = array<i64: 0, 1, 2, 3, 4>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = [], parameter_bounds = [array<f64: 0.000000e+00, 1.5707963267948966>]>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<5> attributes {mqt.entry_point} {
    %cst = arith.constant 0.78539816339744828 : f64
    %cst_0 = arith.constant 0.39269908169872414 : f64
    %cst_1 = arith.constant 0.19634954084936207 : f64
    %cst_2 = arith.constant -3.1415926535897931 : f64
    %cst_3 = arith.constant 0.098174770424681035 : f64
    %cst_4 = arith.constant 1.5707963267948966 : f64
    %cst_5 = arith.constant -1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<5>
    %6 = qco.rz(%cst_5) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.rx(%cst_4) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_4) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_5) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_4) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_4) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_5) %3 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_4) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_4) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_5) %4 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_4) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_4) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_4) %0 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst) %18 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst) %17, %19 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %20 = qco.rz(%cst_4) %qubit0_out : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_2) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_4) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_0) %qubit1_out : !qco.qubit -> !qco.qubit
    %qubit0_out_6, %qubit1_out_7 = qco.rzz(%cst_0) %14, %23 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %24 = qco.rz(%cst_4) %qubit0_out_6 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_2) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_4) %25 : !qco.qubit -> !qco.qubit
    %cst_8 = arith.constant 0.19634954084936229 : f64
    %27 = qco.rz(%cst_8) %qubit1_out_7 : !qco.qubit -> !qco.qubit
    %qubit0_out_9, %qubit1_out_10 = qco.rzz(%cst_1) %11, %27 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %28 = qco.rz(%cst_4) %qubit0_out_9 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_2) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_4) %29 : !qco.qubit -> !qco.qubit
    %cst_11 = arith.constant 0.098174770424681145 : f64
    %31 = qco.rz(%cst_11) %qubit1_out_10 : !qco.qubit -> !qco.qubit
    %qubit0_out_12, %qubit1_out_13 = qco.rzz(%cst_3) %8, %31 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %32 = qco.rz(%cst_4) %qubit0_out_12 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_2) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_4) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_5) %qubit1_out_13 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %35 : !qco.qubit
    cbit.store %result, %5[%c0] : !cbit.reg<5>
    %qubit_out_14, %result_15 = qco.measure %34 : !qco.qubit
    cbit.store %result_15, %5[%c1] : !cbit.reg<5>
    %qubit_out_16, %result_17 = qco.measure %30 : !qco.qubit
    cbit.store %result_17, %5[%c2] : !cbit.reg<5>
    %qubit_out_18, %result_19 = qco.measure %26 : !qco.qubit
    cbit.store %result_19, %5[%c3] : !cbit.reg<5>
    qco.sink %qubit_out_14 : !qco.qubit
    qco.sink %qubit_out_16 : !qco.qubit
    qco.sink %qubit_out_18 : !qco.qubit
    %qubit_out_20, %result_21 = qco.measure %22 : !qco.qubit
    qco.sink %qubit_out_20 : !qco.qubit
    cbit.store %result_21, %5[%c4] : !cbit.reg<5>
    qco.sink %qubit_out : !qco.qubit
    return %5 : !cbit.reg<5>
  }
}
