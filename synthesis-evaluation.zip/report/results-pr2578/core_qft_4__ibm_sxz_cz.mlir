module attributes {mqt.layout = {initial = array<i64: 3, 2, 0, 1>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant -2.9452431127404308 : f64
    %cst_0 = arith.constant 0.19634954084936229 : f64
    %cst_1 = arith.constant -2.7488935718910685 : f64
    %cst_2 = arith.constant 0.39269908169872414 : f64
    %cst_3 = arith.constant -2.3561944901923448 : f64
    %cst_4 = arith.constant -1.5707963267948966 : f64
    %cst_5 = arith.constant 1.5707963267948966 : f64
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.rz(%cst_5) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_5) %6 : !qco.qubit -> !qco.qubit
    %cst_6 = arith.constant -0.78539816339744828 : f64
    %8 = qco.rz(%cst_6) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.sx %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_5) %9 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%7) targets (%arg0 = %10) {
      %81 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %81 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qco.rz(%cst_4) %targets_out : !qco.qubit -> !qco.qubit
    %12 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_3) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_4) %14 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%controls_out) targets (%arg0 = %15) {
      %81 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %81 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.rz(%cst_5) %targets_out_8 : !qco.qubit -> !qco.qubit
    %17 = qco.sx %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_1) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.sx %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_5) %19 : !qco.qubit -> !qco.qubit
    %cst_9 = arith.constant -0.78539816339744872 : f64
    %21 = qco.rz(%cst_9) %controls_out_7 : !qco.qubit -> !qco.qubit
    %22 = qco.sx %21 : !qco.qubit -> !qco.qubit
    %cst_10 = arith.constant -0.78539816339744739 : f64
    %23 = qco.rz(%cst_10) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_4) %24 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%2) targets (%arg0 = %20) {
      %81 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %81 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.rz(%cst_4) %targets_out_12 : !qco.qubit -> !qco.qubit
    %27 = qco.sx %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_1) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.sx %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_4) %29 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%controls_out_11) targets (%arg0 = %30) {
      %81 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %81 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.rz(%cst_5) %targets_out_14 : !qco.qubit -> !qco.qubit
    %32 = qco.sx %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_5) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_2) %controls_out_13 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%3) targets (%arg0 = %35) {
      %81 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %81 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.rz(%cst_4) %targets_out_16 : !qco.qubit -> !qco.qubit
    %38 = qco.sx %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.sx %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_4) %40 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%controls_out_15) targets (%arg0 = %41) {
      %81 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %81 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qco.rz(%cst_5) %targets_out_18 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_4) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_0) %controls_out_17 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%36) targets (%arg0 = %25) {
      %81 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %81 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qco.rz(%cst_4) %targets_out_20 : !qco.qubit -> !qco.qubit
    %47 = qco.sx %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_3) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.sx %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_4) %49 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%controls_out_19) targets (%arg0 = %50) {
      %81 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %81 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %51 = qco.rz(%cst_5) %targets_out_22 : !qco.qubit -> !qco.qubit
    %52 = qco.sx %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_1) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.sx %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_5) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_9) %controls_out_21 : !qco.qubit -> !qco.qubit
    %57 = qco.sx %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_10) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.sx %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_4) %59 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%45) targets (%arg0 = %55) {
      %81 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %81 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qco.rz(%cst_4) %targets_out_24 : !qco.qubit -> !qco.qubit
    %62 = qco.sx %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_1) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.sx %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_4) %64 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%controls_out_23) targets (%arg0 = %65) {
      %81 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %81 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = qco.rz(%cst_5) %targets_out_26 : !qco.qubit -> !qco.qubit
    %67 = qco.sx %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_4) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_2) %controls_out_25 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%69) targets (%arg0 = %60) {
      %81 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %81 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %70 = qco.rz(%cst_4) %targets_out_28 : !qco.qubit -> !qco.qubit
    %71 = qco.sx %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_3) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.sx %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_4) %73 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%controls_out_27) targets (%arg0 = %74) {
      %81 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %81 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %75 = qco.rz(%cst_5) %targets_out_30 : !qco.qubit -> !qco.qubit
    %76 = qco.sx %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_4) %76 : !qco.qubit -> !qco.qubit
    %cst_31 = arith.constant 2.3561944901923448 : f64
    %78 = qco.rz(%cst_31) %controls_out_29 : !qco.qubit -> !qco.qubit
    %79 = qco.sx %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_5) %79 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %80 : !qco.qubit
    cbit.store %result, %4[%c3] : !cbit.reg<4>
    %qubit_out_32, %result_33 = qco.measure %77 : !qco.qubit
    cbit.store %result_33, %4[%c2] : !cbit.reg<4>
    %qubit_out_34, %result_35 = qco.measure %68 : !qco.qubit
    cbit.store %result_35, %4[%c1] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_32 : !qco.qubit
    qco.sink %qubit_out_34 : !qco.qubit
    %qubit_out_36, %result_37 = qco.measure %44 : !qco.qubit
    qco.sink %qubit_out_36 : !qco.qubit
    cbit.store %result_37, %4[%c0] : !cbit.reg<4>
    %cst_38 = arith.constant -1.4726215563702159 : f64
    qco.gphase(%cst_38)
    return %4 : !cbit.reg<4>
  }
}
