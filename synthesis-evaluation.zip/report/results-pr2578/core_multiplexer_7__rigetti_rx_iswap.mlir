module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 0>, input_count = 7 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant -2.3561944901923448 : f64
    %cst_0 = arith.constant -2.7488935718910685 : f64
    %cst_1 = arith.constant -2.9452431127404308 : f64
    %cst_2 = arith.constant -3.0434178831651124 : f64
    %cst_3 = arith.constant -3.0925052683774528 : f64
    %cst_4 = arith.constant -1.5707963267948966 : f64
    %cst_5 = arith.constant -3.1415926535897931 : f64
    %cst_6 = arith.constant -3.1170489609836229 : f64
    %cst_7 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %cst_8 = arith.constant 3.1415926535897931 : f64
    %8 = qco.rx(%cst_8) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_8) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_8) %3 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_8) %4 : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_8) %5 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_8) %6 : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_7) %0 : !qco.qubit -> !qco.qubit
    %cst_9 = arith.constant 0.78539816339744828 : f64
    %15 = qco.rz(%cst_9) %14 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %13, %15 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %16 = qco.rz(%cst_5) %qubit1_out : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_7) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_7) %18 : !qco.qubit -> !qco.qubit
    %qubit0_out_10, %qubit1_out_11 = qco.iswap %qubit0_out, %19 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %20 = qco.rz(%cst_0) %qubit1_out_11 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_4) %qubit0_out_10 : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst_7) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_4) %22 : !qco.qubit -> !qco.qubit
    %qubit0_out_12, %qubit1_out_13 = qco.iswap %12, %20 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %24 = qco.rz(%cst_5) %qubit1_out_13 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_7) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_0) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_7) %26 : !qco.qubit -> !qco.qubit
    %qubit0_out_14, %qubit1_out_15 = qco.iswap %qubit0_out_12, %27 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_16 = arith.constant -2.9452431127404299 : f64
    %28 = qco.rz(%cst_16) %qubit1_out_15 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_4) %qubit0_out_14 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_7) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_4) %30 : !qco.qubit -> !qco.qubit
    %qubit0_out_17, %qubit1_out_18 = qco.iswap %11, %28 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %32 = qco.rz(%cst_5) %qubit1_out_18 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_7) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_1) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_7) %34 : !qco.qubit -> !qco.qubit
    %qubit0_out_19, %qubit1_out_20 = qco.iswap %qubit0_out_17, %35 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %36 = qco.rz(%cst_2) %qubit1_out_20 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_4) %qubit0_out_19 : !qco.qubit -> !qco.qubit
    %38 = qco.rx(%cst_7) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_4) %38 : !qco.qubit -> !qco.qubit
    %qubit0_out_21, %qubit1_out_22 = qco.iswap %10, %36 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %40 = qco.rz(%cst_5) %qubit1_out_22 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_7) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_2) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_7) %42 : !qco.qubit -> !qco.qubit
    %qubit0_out_23, %qubit1_out_24 = qco.iswap %qubit0_out_21, %43 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %44 = qco.rz(%cst_3) %qubit1_out_24 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_4) %qubit0_out_23 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst_7) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_4) %46 : !qco.qubit -> !qco.qubit
    %qubit0_out_25, %qubit1_out_26 = qco.iswap %9, %44 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %48 = qco.rz(%cst_5) %qubit1_out_26 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_7) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_3) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rx(%cst_7) %50 : !qco.qubit -> !qco.qubit
    %qubit0_out_27, %qubit1_out_28 = qco.iswap %qubit0_out_25, %51 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_29 = arith.constant -3.1170489609836221 : f64
    %52 = qco.rz(%cst_29) %qubit1_out_28 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_4) %qubit0_out_27 : !qco.qubit -> !qco.qubit
    %54 = qco.rx(%cst_7) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_4) %54 : !qco.qubit -> !qco.qubit
    %qubit0_out_30, %qubit1_out_31 = qco.iswap %8, %52 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %56 = qco.rz(%cst_5) %qubit1_out_31 : !qco.qubit -> !qco.qubit
    %57 = qco.rx(%cst_7) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_6) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rx(%cst_7) %58 : !qco.qubit -> !qco.qubit
    %qubit0_out_32, %qubit1_out_33 = qco.iswap %qubit0_out_30, %59 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %60 = qco.rx(%cst_7) %qubit1_out_33 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_5) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_4) %qubit0_out_32 : !qco.qubit -> !qco.qubit
    %63 = qco.rx(%cst_7) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_4) %63 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %61 : !qco.qubit
    cbit.store %result, %7[%c0] : !cbit.reg<7>
    %qubit_out_34, %result_35 = qco.measure %64 : !qco.qubit
    cbit.store %result_35, %7[%c1] : !cbit.reg<7>
    %qubit_out_36, %result_37 = qco.measure %55 : !qco.qubit
    cbit.store %result_37, %7[%c2] : !cbit.reg<7>
    %qubit_out_38, %result_39 = qco.measure %47 : !qco.qubit
    cbit.store %result_39, %7[%c3] : !cbit.reg<7>
    %qubit_out_40, %result_41 = qco.measure %39 : !qco.qubit
    cbit.store %result_41, %7[%c4] : !cbit.reg<7>
    %qubit_out_42, %result_43 = qco.measure %31 : !qco.qubit
    cbit.store %result_43, %7[%c5] : !cbit.reg<7>
    qco.sink %qubit_out_34 : !qco.qubit
    qco.sink %qubit_out_36 : !qco.qubit
    qco.sink %qubit_out_38 : !qco.qubit
    qco.sink %qubit_out_40 : !qco.qubit
    qco.sink %qubit_out_42 : !qco.qubit
    %qubit_out_44, %result_45 = qco.measure %23 : !qco.qubit
    qco.sink %qubit_out_44 : !qco.qubit
    cbit.store %result_45, %7[%c6] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    qco.gphase(%cst_8)
    return %7 : !cbit.reg<7>
  }
}
