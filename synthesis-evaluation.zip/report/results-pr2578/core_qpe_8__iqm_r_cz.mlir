module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 7, 0>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant 0.58904862254808599 : f64
    %cst_0 = arith.constant -5.1050880620834134 : f64
    %cst_1 = arith.constant -0.3926990816987237 : f64
    %cst_2 = arith.constant -3.5342917352885168 : f64
    %cst_3 = arith.constant -6.2831853071795862 : f64
    %cst_4 = arith.constant -4.7123889803846897 : f64
    %cst_5 = arith.constant -3.9269908169872414 : f64
    %cst_6 = arith.constant -2.3561944901923448 : f64
    %cst_7 = arith.constant 2.2204460492503131E-16 : f64
    %cst_8 = arith.constant -3.1415926535897931 : f64
    %cst_9 = arith.constant -0.39269908169872458 : f64
    %cst_10 = arith.constant 1.1780972450961726 : f64
    %cst_11 = arith.constant -1.9634954084936203 : f64
    %cst_12 = arith.constant -1.9634954084936216 : f64
    %cst_13 = arith.constant 2.7488935718910685 : f64
    %cst_14 = arith.constant -4.4408920985006262E-16 : f64
    %cst_15 = arith.constant 2.3561944901923448 : f64
    %cst_16 = arith.constant 3.1415926535897931 : f64
    %cst_17 = arith.constant 1.5707963267948968 : f64
    %cst_18 = arith.constant 1.178097245096172 : f64
    %cst_19 = arith.constant 0.78539816339744828 : f64
    %cst_20 = arith.constant 0.024543692606170175 : f64
    %cst_21 = arith.constant 0.024543692606170179 : f64
    %cst_22 = arith.constant 0.049087385212340358 : f64
    %cst_23 = arith.constant 0.098174770424681145 : f64
    %cst_24 = arith.constant 0.19634954084936229 : f64
    %cst_25 = arith.constant 0.39269908169872414 : f64
    %cst_26 = arith.constant 1.5707963267948966 : f64
    %cst_27 = arith.constant -0.78539816339744828 : f64
    %cst_28 = arith.constant -1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %9 = qco.r(%cst_15, %cst_14) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_15, %cst_14) %3 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_15, %cst_14) %4 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_26, %cst_28) %5 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_26, %cst_28) %6 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_26, %cst_28) %7 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_17, %cst_13) %0 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%14) targets (%arg0 = %15) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.r(%cst_18, %cst_18) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%controls_out) targets (%arg0 = %16) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.r(%cst_15, %cst_12) %targets_out_30 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_26, %cst_11) %controls_out_29 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%13) targets (%arg0 = %17) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.r(%cst_15, %cst_10) %targets_out_32 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%controls_out_31) targets (%arg0 = %19) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.r(%cst_4, %cst_9) %targets_out_34 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_16, %cst) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_26, %cst_8) %controls_out_33 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%12) targets (%arg0 = %21) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_37, %targets_out_38 = qco.ctrl(%1) targets (%arg0 = %9) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qco.r(%cst_19, %cst_7) %targets_out_38 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%controls_out_37) targets (%arg0 = %23) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.r(%cst_16, %cst_28) %targets_out_40 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%24) targets (%arg0 = %10) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %25 = qco.r(%cst_19, %cst_7) %targets_out_42 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%controls_out_41) targets (%arg0 = %25) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.r(%cst_25, %cst_16) %targets_out_44 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%controls_out_39) targets (%arg0 = %26) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %27 = qco.r(%cst_25, %cst_7) %targets_out_46 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%controls_out_45) targets (%arg0 = %27) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qco.r(%cst_16, %cst_28) %targets_out_48 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%28) targets (%arg0 = %11) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.r(%cst_19, %cst_7) %targets_out_50 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%controls_out_49) targets (%arg0 = %29) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.r(%cst_25, %cst_16) %targets_out_52 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%controls_out_43) targets (%arg0 = %30) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.r(%cst_25, %cst_7) %targets_out_54 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%controls_out_53) targets (%arg0 = %31) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qco.r(%cst_24, %cst_16) %targets_out_56 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%controls_out_47) targets (%arg0 = %32) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %33 = qco.r(%cst_24, %cst_7) %targets_out_58 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%controls_out_57) targets (%arg0 = %33) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.r(%cst_16, %cst_28) %targets_out_60 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst_26, %cst_27) %controls_out_35 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%34) targets (%arg0 = %35) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qco.r(%cst_19, %cst_6) %targets_out_62 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%controls_out_61) targets (%arg0 = %36) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.r(%cst_25, %cst_19) %targets_out_64 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%controls_out_51) targets (%arg0 = %37) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qco.r(%cst_25, %cst_6) %targets_out_66 : !qco.qubit -> !qco.qubit
    %controls_out_67, %targets_out_68 = qco.ctrl(%controls_out_65) targets (%arg0 = %38) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.r(%cst_24, %cst_19) %targets_out_68 : !qco.qubit -> !qco.qubit
    %controls_out_69, %targets_out_70 = qco.ctrl(%controls_out_55) targets (%arg0 = %39) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %40 = qco.r(%cst_24, %cst_6) %targets_out_70 : !qco.qubit -> !qco.qubit
    %controls_out_71, %targets_out_72 = qco.ctrl(%controls_out_69) targets (%arg0 = %40) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.r(%cst_23, %cst_19) %targets_out_72 : !qco.qubit -> !qco.qubit
    %controls_out_73, %targets_out_74 = qco.ctrl(%controls_out_59) targets (%arg0 = %41) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qco.r(%cst_23, %cst_6) %targets_out_74 : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%controls_out_73) targets (%arg0 = %42) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qco.r(%cst_16, %cst_5) %targets_out_76 : !qco.qubit -> !qco.qubit
    %controls_out_77, %targets_out_78 = qco.ctrl(%43) targets (%arg0 = %22) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = qco.r(%cst_19, %cst_4) %targets_out_78 : !qco.qubit -> !qco.qubit
    %controls_out_79, %targets_out_80 = qco.ctrl(%controls_out_77) targets (%arg0 = %44) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.r(%cst_25, %cst_28) %targets_out_80 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%controls_out_63) targets (%arg0 = %45) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qco.r(%cst_25, %cst_4) %targets_out_82 : !qco.qubit -> !qco.qubit
    %controls_out_83, %targets_out_84 = qco.ctrl(%controls_out_81) targets (%arg0 = %46) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.r(%cst_24, %cst_28) %targets_out_84 : !qco.qubit -> !qco.qubit
    %controls_out_85, %targets_out_86 = qco.ctrl(%controls_out_67) targets (%arg0 = %47) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %48 = qco.r(%cst_24, %cst_4) %targets_out_86 : !qco.qubit -> !qco.qubit
    %controls_out_87, %targets_out_88 = qco.ctrl(%controls_out_85) targets (%arg0 = %48) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qco.r(%cst_23, %cst_28) %targets_out_88 : !qco.qubit -> !qco.qubit
    %controls_out_89, %targets_out_90 = qco.ctrl(%controls_out_71) targets (%arg0 = %49) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qco.r(%cst_23, %cst_4) %targets_out_90 : !qco.qubit -> !qco.qubit
    %controls_out_91, %targets_out_92 = qco.ctrl(%controls_out_89) targets (%arg0 = %50) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %51 = qco.r(%cst_22, %cst_28) %targets_out_92 : !qco.qubit -> !qco.qubit
    %controls_out_93, %targets_out_94 = qco.ctrl(%controls_out_75) targets (%arg0 = %51) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qco.r(%cst_22, %cst_4) %targets_out_94 : !qco.qubit -> !qco.qubit
    %controls_out_95, %targets_out_96 = qco.ctrl(%controls_out_93) targets (%arg0 = %52) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qco.r(%cst_16, %cst_3) %targets_out_96 : !qco.qubit -> !qco.qubit
    %controls_out_97, %targets_out_98 = qco.ctrl(%53) targets (%arg0 = %18) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %54 = qco.r(%cst_19, %cst_2) %targets_out_98 : !qco.qubit -> !qco.qubit
    %controls_out_99, %targets_out_100 = qco.ctrl(%controls_out_97) targets (%arg0 = %54) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.r(%cst_25, %cst_1) %targets_out_100 : !qco.qubit -> !qco.qubit
    %controls_out_101, %targets_out_102 = qco.ctrl(%controls_out_79) targets (%arg0 = %55) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qco.r(%cst_25, %cst_2) %targets_out_102 : !qco.qubit -> !qco.qubit
    %controls_out_103, %targets_out_104 = qco.ctrl(%controls_out_101) targets (%arg0 = %56) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %57 = qco.r(%cst_24, %cst_1) %targets_out_104 : !qco.qubit -> !qco.qubit
    %controls_out_105, %targets_out_106 = qco.ctrl(%controls_out_83) targets (%arg0 = %57) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = qco.r(%cst_24, %cst_2) %targets_out_106 : !qco.qubit -> !qco.qubit
    %controls_out_107, %targets_out_108 = qco.ctrl(%controls_out_105) targets (%arg0 = %58) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qco.r(%cst_23, %cst_1) %targets_out_108 : !qco.qubit -> !qco.qubit
    %controls_out_109, %targets_out_110 = qco.ctrl(%controls_out_87) targets (%arg0 = %59) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qco.r(%cst_23, %cst_2) %targets_out_110 : !qco.qubit -> !qco.qubit
    %controls_out_111, %targets_out_112 = qco.ctrl(%controls_out_109) targets (%arg0 = %60) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qco.r(%cst_22, %cst_1) %targets_out_112 : !qco.qubit -> !qco.qubit
    %controls_out_113, %targets_out_114 = qco.ctrl(%controls_out_91) targets (%arg0 = %61) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %62 = qco.r(%cst_22, %cst_2) %targets_out_114 : !qco.qubit -> !qco.qubit
    %controls_out_115, %targets_out_116 = qco.ctrl(%controls_out_113) targets (%arg0 = %62) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %63 = qco.r(%cst_21, %cst_1) %targets_out_116 : !qco.qubit -> !qco.qubit
    %controls_out_117, %targets_out_118 = qco.ctrl(%controls_out_95) targets (%arg0 = %63) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %64 = qco.r(%cst_20, %cst_2) %targets_out_118 : !qco.qubit -> !qco.qubit
    %controls_out_119, %targets_out_120 = qco.ctrl(%controls_out_117) targets (%arg0 = %64) {
      %66 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %66 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qco.r(%cst_16, %cst_0) %targets_out_120 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %controls_out_119 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<7>
    %qubit_out_121, %result_122 = qco.measure %controls_out_115 : !qco.qubit
    cbit.store %result_122, %8[%c1] : !cbit.reg<7>
    %qubit_out_123, %result_124 = qco.measure %controls_out_111 : !qco.qubit
    cbit.store %result_124, %8[%c2] : !cbit.reg<7>
    %qubit_out_125, %result_126 = qco.measure %controls_out_107 : !qco.qubit
    cbit.store %result_126, %8[%c3] : !cbit.reg<7>
    %qubit_out_127, %result_128 = qco.measure %controls_out_103 : !qco.qubit
    cbit.store %result_128, %8[%c4] : !cbit.reg<7>
    %qubit_out_129, %result_130 = qco.measure %controls_out_99 : !qco.qubit
    cbit.store %result_130, %8[%c5] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_121 : !qco.qubit
    qco.sink %qubit_out_123 : !qco.qubit
    qco.sink %qubit_out_125 : !qco.qubit
    qco.sink %qubit_out_127 : !qco.qubit
    qco.sink %qubit_out_129 : !qco.qubit
    %qubit_out_131, %result_132 = qco.measure %65 : !qco.qubit
    qco.sink %qubit_out_131 : !qco.qubit
    cbit.store %result_132, %8[%c6] : !cbit.reg<7>
    qco.sink %targets_out_36 : !qco.qubit
    %cst_133 = arith.constant 2.5402721847386198 : f64
    qco.gphase(%cst_133)
    return %8 : !cbit.reg<7>
  }
}
