module attributes {mqt.layout = {initial = array<i64: 3, 1, 2, 0, 5, 7, 4, 6>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant 4.4408920985006262E-16 : f64
    %cst_0 = arith.constant 1.5707963267948972 : f64
    %cst_1 = arith.constant 3.9269908169872414 : f64
    %cst_2 = arith.constant -3.5342917352885168 : f64
    %cst_3 = arith.constant -1.9634954084936203 : f64
    %cst_4 = arith.constant 9.6211275016187389 : f64
    %cst_5 = arith.constant 1.1780972450961729 : f64
    %cst_6 = arith.constant 1.1780972450961726 : f64
    %cst_7 = arith.constant -0.3926990816987237 : f64
    %cst_8 = arith.constant 1.570796326794897 : f64
    %cst_9 = arith.constant 8.6393797973719302 : f64
    %cst_10 = arith.constant 7.0685834705770345 : f64
    %cst_11 = arith.constant 6.4795348480289476 : f64
    %cst_12 = arith.constant 0.39269908169872458 : f64
    %cst_13 = arith.constant 3.9269908169872418 : f64
    %cst_14 = arith.constant 1.9634954084936209 : f64
    %cst_15 = arith.constant 2.3561944901923453 : f64
    %cst_16 = arith.constant 7.8539816339744828 : f64
    %cst_17 = arith.constant 5.497787143782138 : f64
    %cst_18 = arith.constant 6.2831853071795862 : f64
    %cst_19 = arith.constant 9.4247779607693793 : f64
    %cst_20 = arith.constant 3.1415926535897936 : f64
    %cst_21 = arith.constant 2.3561944901923448 : f64
    %cst_22 = arith.constant 3.1415926535897931 : f64
    %cst_23 = arith.constant 1.5707963267948966 : f64
    %cst_24 = arith.constant 4.7123889803846897 : f64
    %cst_25 = arith.constant 0.78539816339744828 : f64
    %cst_26 = arith.constant 0.39269908169872414 : f64
    %cst_27 = arith.constant -1.5707963267948966 : f64
    %cst_28 = arith.constant 0.19634954084936229 : f64
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.r(%cst_22, %cst_23) %0 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_22, %cst_23) %1 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_22, %cst_23) %4 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_22, %cst_23) %5 : !qco.qubit -> !qco.qubit
    %12 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %13 = qco.r(%cst_21, %cst_20) %6 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%10) targets (%arg0 = %13) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.r(%cst_25, %cst_19) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%controls_out) targets (%arg0 = %14) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qco.r(%cst_26, %cst_18) %targets_out_30 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_21, %cst_17) %controls_out_29 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%7) targets (%arg0 = %15) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.r(%cst_26, %cst_19) %targets_out_32 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%controls_out_31) targets (%arg0 = %17) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qco.r(%cst_28, %cst_18) %targets_out_34 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%11) targets (%arg0 = %18) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.r(%cst_28, %cst_19) %targets_out_36 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%controls_out_35) targets (%arg0 = %19) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.r(%cst_27, %cst_16) %targets_out_38 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%controls_out_33) targets (%arg0 = %16) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.r(%cst_25, %cst_17) %targets_out_40 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%controls_out_39) targets (%arg0 = %21) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.r(%cst_26, %cst_15) %targets_out_42 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_21, %cst_14) %controls_out_41 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%controls_out_37) targets (%arg0 = %22) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.r(%cst_26, %cst_17) %targets_out_44 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%controls_out_43) targets (%arg0 = %24) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %25 = qco.r(%cst_27, %cst_13) %targets_out_46 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%controls_out_45) targets (%arg0 = %23) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.r(%cst_25, %cst_14) %targets_out_48 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%controls_out_47) targets (%arg0 = %26) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %27 = qco.r(%cst_27, %cst_12) %targets_out_50 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_23, %cst_11) %controls_out_49 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%8) targets (%arg0 = %20) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.r(%cst_23, %cst_10) %targets_out_52 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%2) targets (%arg0 = %29) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.r(%cst_25, %cst_9) %targets_out_54 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%controls_out_53) targets (%arg0 = %30) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.r(%cst_26, %cst_17) %targets_out_56 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%9) targets (%arg0 = %31) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qco.r(%cst_26, %cst_9) %targets_out_58 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%controls_out_57) targets (%arg0 = %32) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %33 = qco.r(%cst_28, %cst_17) %targets_out_60 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%3) targets (%arg0 = %33) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.r(%cst_28, %cst_9) %targets_out_62 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%controls_out_61) targets (%arg0 = %34) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.r(%cst_25, %cst_9) %targets_out_64 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%controls_out_55) targets (%arg0 = %25) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qco.r(%cst_23, %cst_20) %targets_out_66 : !qco.qubit -> !qco.qubit
    %controls_out_67, %targets_out_68 = qco.ctrl(%controls_out_59) targets (%arg0 = %36) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.r(%cst_25, %cst_24) %targets_out_68 : !qco.qubit -> !qco.qubit
    %controls_out_69, %targets_out_70 = qco.ctrl(%controls_out_67) targets (%arg0 = %37) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qco.r(%cst_26, %cst_8) %targets_out_70 : !qco.qubit -> !qco.qubit
    %controls_out_71, %targets_out_72 = qco.ctrl(%controls_out_63) targets (%arg0 = %38) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.r(%cst_26, %cst_24) %targets_out_72 : !qco.qubit -> !qco.qubit
    %controls_out_73, %targets_out_74 = qco.ctrl(%controls_out_71) targets (%arg0 = %39) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %40 = qco.r(%cst_25, %cst_24) %targets_out_74 : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%controls_out_69) targets (%arg0 = %27) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.r(%cst_23, %cst_7) %targets_out_76 : !qco.qubit -> !qco.qubit
    %controls_out_77, %targets_out_78 = qco.ctrl(%controls_out_73) targets (%arg0 = %41) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qco.r(%cst_25, %cst_6) %targets_out_78 : !qco.qubit -> !qco.qubit
    %controls_out_79, %targets_out_80 = qco.ctrl(%controls_out_77) targets (%arg0 = %42) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qco.r(%cst_25, %cst_5) %targets_out_80 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%controls_out_79) targets (%arg0 = %28) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = qco.r(%cst_23, %cst_4) %targets_out_82 : !qco.qubit -> !qco.qubit
    %controls_out_83, %targets_out_84 = qco.ctrl(%44) targets (%arg0 = %43) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.r(%cst_25, %cst_3) %targets_out_84 : !qco.qubit -> !qco.qubit
    %controls_out_85, %targets_out_86 = qco.ctrl(%controls_out_83) targets (%arg0 = %45) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qco.r(%cst_22, %cst_2) %targets_out_86 : !qco.qubit -> !qco.qubit
    %controls_out_87, %targets_out_88 = qco.ctrl(%46) targets (%arg0 = %40) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.r(%cst_25, %cst_0) %targets_out_88 : !qco.qubit -> !qco.qubit
    %controls_out_89, %targets_out_90 = qco.ctrl(%controls_out_87) targets (%arg0 = %47) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %48 = qco.r(%cst_26, %cst_24) %targets_out_90 : !qco.qubit -> !qco.qubit
    %controls_out_91, %targets_out_92 = qco.ctrl(%controls_out_85) targets (%arg0 = %48) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qco.r(%cst_26, %cst_0) %targets_out_92 : !qco.qubit -> !qco.qubit
    %controls_out_93, %targets_out_94 = qco.ctrl(%controls_out_91) targets (%arg0 = %49) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qco.r(%cst_22, %cst) %targets_out_94 : !qco.qubit -> !qco.qubit
    %controls_out_95, %targets_out_96 = qco.ctrl(%50) targets (%arg0 = %35) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %51 = qco.r(%cst_25, %cst_17) %targets_out_96 : !qco.qubit -> !qco.qubit
    %controls_out_97, %targets_out_98 = qco.ctrl(%controls_out_95) targets (%arg0 = %51) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qco.r(%cst_26, %cst_9) %targets_out_98 : !qco.qubit -> !qco.qubit
    %controls_out_99, %targets_out_100 = qco.ctrl(%controls_out_89) targets (%arg0 = %52) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qco.r(%cst_26, %cst_17) %targets_out_100 : !qco.qubit -> !qco.qubit
    %controls_out_101, %targets_out_102 = qco.ctrl(%controls_out_99) targets (%arg0 = %53) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %54 = qco.r(%cst_28, %cst_9) %targets_out_102 : !qco.qubit -> !qco.qubit
    %controls_out_103, %targets_out_104 = qco.ctrl(%controls_out_93) targets (%arg0 = %54) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.r(%cst_28, %cst_17) %targets_out_104 : !qco.qubit -> !qco.qubit
    %controls_out_105, %targets_out_106 = qco.ctrl(%controls_out_103) targets (%arg0 = %55) {
      %57 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %57 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qco.r(%cst_22, %cst_1) %targets_out_106 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %controls_out_105 : !qco.qubit
    cbit.store %result, %12[%c0] : !cbit.reg<8>
    %qubit_out_107, %result_108 = qco.measure %controls_out_101 : !qco.qubit
    cbit.store %result_108, %12[%c1] : !cbit.reg<8>
    %qubit_out_109, %result_110 = qco.measure %controls_out_97 : !qco.qubit
    cbit.store %result_110, %12[%c2] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_107 : !qco.qubit
    qco.sink %qubit_out_109 : !qco.qubit
    %qubit_out_111, %result_112 = qco.measure %56 : !qco.qubit
    qco.sink %qubit_out_111 : !qco.qubit
    cbit.store %result_112, %12[%c3] : !cbit.reg<8>
    %qubit_out_113, %result_114 = qco.measure %controls_out_81 : !qco.qubit
    cbit.store %result_114, %12[%c4] : !cbit.reg<8>
    %qubit_out_115, %result_116 = qco.measure %controls_out_75 : !qco.qubit
    cbit.store %result_116, %12[%c5] : !cbit.reg<8>
    %qubit_out_117, %result_118 = qco.measure %controls_out_65 : !qco.qubit
    cbit.store %result_118, %12[%c6] : !cbit.reg<8>
    qco.sink %qubit_out_113 : !qco.qubit
    qco.sink %qubit_out_115 : !qco.qubit
    qco.sink %qubit_out_117 : !qco.qubit
    %qubit_out_119, %result_120 = qco.measure %controls_out_51 : !qco.qubit
    qco.sink %qubit_out_119 : !qco.qubit
    cbit.store %result_120, %12[%c7] : !cbit.reg<8>
    %cst_121 = arith.constant 1.6689710972195775 : f64
    qco.gphase(%cst_121)
    return %12 : !cbit.reg<8>
  }
}
