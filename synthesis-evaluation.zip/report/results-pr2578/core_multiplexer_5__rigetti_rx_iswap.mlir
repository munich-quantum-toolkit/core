module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 0>, input_count = 5 : i64, sites = array<i64: 0, 1, 2, 3, 4>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<5> attributes {mqt.entry_point} {
    %cst = arith.constant -2.3561944901923448 : f64
    %cst_0 = arith.constant -2.7488935718910685 : f64
    %cst_1 = arith.constant -2.9452431127404308 : f64
    %cst_2 = arith.constant -1.5707963267948966 : f64
    %cst_3 = arith.constant -3.1415926535897931 : f64
    %cst_4 = arith.constant -3.0434178831651124 : f64
    %cst_5 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<5>
    %cst_6 = arith.constant 3.1415926535897931 : f64
    %6 = qco.rx(%cst_6) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.rx(%cst_6) %2 : !qco.qubit -> !qco.qubit
    %8 = qco.rx(%cst_6) %3 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_6) %4 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_5) %0 : !qco.qubit -> !qco.qubit
    %cst_7 = arith.constant 0.78539816339744828 : f64
    %11 = qco.rz(%cst_7) %10 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %9, %11 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %12 = qco.rz(%cst_3) %qubit1_out : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_5) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_5) %14 : !qco.qubit -> !qco.qubit
    %qubit0_out_8, %qubit1_out_9 = qco.iswap %qubit0_out, %15 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %16 = qco.rz(%cst_0) %qubit1_out_9 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_2) %qubit0_out_8 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_5) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_2) %18 : !qco.qubit -> !qco.qubit
    %qubit0_out_10, %qubit1_out_11 = qco.iswap %8, %16 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %20 = qco.rz(%cst_3) %qubit1_out_11 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_5) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_0) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_5) %22 : !qco.qubit -> !qco.qubit
    %qubit0_out_12, %qubit1_out_13 = qco.iswap %qubit0_out_10, %23 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_14 = arith.constant -2.9452431127404299 : f64
    %24 = qco.rz(%cst_14) %qubit1_out_13 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_2) %qubit0_out_12 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_5) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_2) %26 : !qco.qubit -> !qco.qubit
    %qubit0_out_15, %qubit1_out_16 = qco.iswap %7, %24 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %28 = qco.rz(%cst_3) %qubit1_out_16 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_5) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_1) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_5) %30 : !qco.qubit -> !qco.qubit
    %qubit0_out_17, %qubit1_out_18 = qco.iswap %qubit0_out_15, %31 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %32 = qco.rz(%cst_4) %qubit1_out_18 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_2) %qubit0_out_17 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_5) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_2) %34 : !qco.qubit -> !qco.qubit
    %qubit0_out_19, %qubit1_out_20 = qco.iswap %6, %32 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %36 = qco.rz(%cst_3) %qubit1_out_20 : !qco.qubit -> !qco.qubit
    %37 = qco.rx(%cst_5) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_4) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_5) %38 : !qco.qubit -> !qco.qubit
    %qubit0_out_21, %qubit1_out_22 = qco.iswap %qubit0_out_19, %39 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %40 = qco.rx(%cst_5) %qubit1_out_22 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_3) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_2) %qubit0_out_21 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_5) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_2) %43 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %41 : !qco.qubit
    cbit.store %result, %5[%c0] : !cbit.reg<5>
    %qubit_out_23, %result_24 = qco.measure %44 : !qco.qubit
    cbit.store %result_24, %5[%c1] : !cbit.reg<5>
    %qubit_out_25, %result_26 = qco.measure %35 : !qco.qubit
    cbit.store %result_26, %5[%c2] : !cbit.reg<5>
    %qubit_out_27, %result_28 = qco.measure %27 : !qco.qubit
    cbit.store %result_28, %5[%c3] : !cbit.reg<5>
    qco.sink %qubit_out_23 : !qco.qubit
    qco.sink %qubit_out_25 : !qco.qubit
    qco.sink %qubit_out_27 : !qco.qubit
    %qubit_out_29, %result_30 = qco.measure %19 : !qco.qubit
    qco.sink %qubit_out_29 : !qco.qubit
    cbit.store %result_30, %5[%c4] : !cbit.reg<5>
    qco.sink %qubit_out : !qco.qubit
    return %5 : !cbit.reg<5>
  }
}
