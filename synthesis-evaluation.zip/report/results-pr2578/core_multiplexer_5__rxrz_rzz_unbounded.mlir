module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 0>, input_count = 5 : i64, sites = array<i64: 0, 1, 2, 3, 4>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<5> attributes {mqt.entry_point} {
    %cst = arith.constant -5.000000e-01 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %cst_2 = arith.constant 0.78539816339744828 : f64
    %cst_3 = arith.constant 0.39269908169872414 : f64
    %cst_4 = arith.constant 0.19634954084936207 : f64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<5>
    %6 = qco.rz(%cst_0) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.rx(%cst_0) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_0) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_0) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_0) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_0) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_0) %3 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_0) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_0) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_0) %4 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_0) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_0) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_0) %0 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_2) %18 : !qco.qubit -> !qco.qubit
    %20 = arith.mulf %cst_0, %cst : f64
    %qubit0_out, %qubit1_out = qco.rzz(%20) %17, %19 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %21 = qco.rz(%cst_3) %qubit1_out : !qco.qubit -> !qco.qubit
    %22 = arith.mulf %cst_2, %cst : f64
    %qubit0_out_5, %qubit1_out_6 = qco.rzz(%22) %14, %21 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_7 = arith.constant 0.19634954084936229 : f64
    %23 = qco.rz(%cst_7) %qubit1_out_6 : !qco.qubit -> !qco.qubit
    %24 = arith.mulf %cst_3, %cst : f64
    %qubit0_out_8, %qubit1_out_9 = qco.rzz(%24) %11, %23 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_10 = arith.constant 0.098174770424681145 : f64
    %25 = qco.rz(%cst_10) %qubit1_out_9 : !qco.qubit -> !qco.qubit
    %26 = arith.mulf %cst_4, %cst : f64
    %qubit0_out_11, %qubit1_out_12 = qco.rzz(%26) %8, %25 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %27 = qco.rx(%cst_1) %qubit1_out_12 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %27 : !qco.qubit
    cbit.store %result, %5[%c0] : !cbit.reg<5>
    %qubit_out_13, %result_14 = qco.measure %qubit0_out_11 : !qco.qubit
    cbit.store %result_14, %5[%c1] : !cbit.reg<5>
    %qubit_out_15, %result_16 = qco.measure %qubit0_out_8 : !qco.qubit
    cbit.store %result_16, %5[%c2] : !cbit.reg<5>
    %qubit_out_17, %result_18 = qco.measure %qubit0_out_5 : !qco.qubit
    cbit.store %result_18, %5[%c3] : !cbit.reg<5>
    qco.sink %qubit_out_13 : !qco.qubit
    qco.sink %qubit_out_15 : !qco.qubit
    qco.sink %qubit_out_17 : !qco.qubit
    %qubit_out_19, %result_20 = qco.measure %qubit0_out : !qco.qubit
    qco.sink %qubit_out_19 : !qco.qubit
    cbit.store %result_20, %5[%c4] : !cbit.reg<5>
    qco.sink %qubit_out : !qco.qubit
    return %5 : !cbit.reg<5>
  }
}
