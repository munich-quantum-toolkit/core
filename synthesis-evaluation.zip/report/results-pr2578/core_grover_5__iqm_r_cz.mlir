module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4>, input_count = 5 : i64, sites = array<i64: 0, 1, 2, 3, 4>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<5> attributes {mqt.entry_point} {
    %cst = arith.constant 13.940817400304708 : f64
    %cst_0 = arith.constant 0.78539816339745138 : f64
    %cst_1 = arith.constant 2.3561944901923488 : f64
    %cst_2 = arith.constant -0.78539816339744517 : f64
    %cst_3 = arith.constant 2.3561944901923484 : f64
    %cst_4 = arith.constant -1.1780972450961693 : f64
    %cst_5 = arith.constant 1.9634954084936243 : f64
    %cst_6 = arith.constant -1.1780972450961698 : f64
    %cst_7 = arith.constant 1.9634954084936238 : f64
    %cst_8 = arith.constant 18.064157758141313 : f64
    %cst_9 = arith.constant 21.205750411731103 : f64
    %cst_10 = arith.constant 17.278759594743864 : f64
    %cst_11 = arith.constant 14.137166941154071 : f64
    %cst_12 = arith.constant 11.950890905688787 : f64
    %cst_13 = arith.constant 7.8539816339744836 : f64
    %cst_14 = arith.constant 5.4977871437821362 : f64
    %cst_15 = arith.constant 8.023900088701545 : f64
    %cst_16 = arith.constant 10.995574287564278 : f64
    %cst_17 = arith.constant -2.1598449493429834 : f64
    %cst_18 = arith.constant 7.0685834705770336 : f64
    %cst_19 = arith.constant 10.799224746714915 : f64
    %cst_20 = arith.constant -1.5707963267948939 : f64
    %cst_21 = arith.constant 3.1415926535897962 : f64
    %cst_22 = arith.constant 2.2204460492503131E-15 : f64
    %cst_23 = arith.constant 3.1415926535897958 : f64
    %cst_24 = arith.constant -0.39269908169872214 : f64
    %cst_25 = arith.constant 2.7488935718910716 : f64
    %cst_26 = arith.constant -0.39269908169872236 : f64
    %cst_27 = arith.constant 2.7488935718910712 : f64
    %cst_28 = arith.constant 12.566370614359174 : f64
    %cst_29 = arith.constant 18.849555921538759 : f64
    %cst_30 = arith.constant 14.92256510455152 : f64
    %cst_31 = arith.constant 11.780972450961727 : f64
    %cst_32 = arith.constant 9.5946964154964433 : f64
    %cst_33 = arith.constant 5.4977871437821397 : f64
    %cst_34 = arith.constant 6.2831853071795853 : f64
    %cst_35 = arith.constant 5.6677055985092011 : f64
    %cst_36 = arith.constant 4.7123889803846915 : f64
    %cst_37 = arith.constant 8.639379797371932 : f64
    %cst_38 = arith.constant 10.21017612416683 : f64
    %cst_39 = arith.constant 4.7123889803846888 : f64
    %cst_40 = arith.constant 7.6576320931251204 : f64
    %cst_41 = arith.constant 0.78539816339744961 : f64
    %cst_42 = arith.constant 2.3561944901923471 : f64
    %cst_43 = arith.constant -0.78539816339744694 : f64
    %cst_44 = arith.constant 0.78539816339744739 : f64
    %cst_45 = arith.constant 2.3561944901923466 : f64
    %cst_46 = arith.constant -1.1780972450961711 : f64
    %cst_47 = arith.constant 1.9634954084936225 : f64
    %cst_48 = arith.constant -1.1780972450961715 : f64
    %cst_49 = arith.constant 1.178097245096172 : f64
    %cst_50 = arith.constant 1.963495408493622 : f64
    %cst_51 = arith.constant 10.210176124166827 : f64
    %cst_52 = arith.constant 16.493361431346415 : f64
    %cst_53 = arith.constant 12.566370614359172 : f64
    %cst_54 = arith.constant 7.2385019253040959 : f64
    %cst_55 = arith.constant 5.4977871437821371 : f64
    %cst_56 = arith.constant 3.3115111083168549 : f64
    %cst_57 = arith.constant 2.3561944901923453 : f64
    %cst_58 = arith.constant 6.2831853071795871 : f64
    %cst_59 = arith.constant 7.8539816339744846 : f64
    %cst_60 = arith.constant 8.6393797973719302 : f64
    %cst_61 = arith.constant 1.3744467859455343 : f64
    %cst_62 = arith.constant 4.5160394395353274 : f64
    %cst_63 = arith.constant -1.5707963267948957 : f64
    %cst_64 = arith.constant 3.1415926535897944 : f64
    %cst_65 = arith.constant -1.7671458676442588 : f64
    %cst_66 = arith.constant -0.39269908169872392 : f64
    %cst_67 = arith.constant 2.7488935718910699 : f64
    %cst_68 = arith.constant 2.7488935718910694 : f64
    %cst_69 = arith.constant 7.0685834705770345 : f64
    %cst_70 = arith.constant 14.137166941154069 : f64
    %cst_71 = arith.constant 10.210176124166829 : f64
    %cst_72 = arith.constant 7.0685834705770354 : f64
    %cst_73 = arith.constant 4.882307435111751 : f64
    %cst_74 = arith.constant 0.78539816339744872 : f64
    %cst_75 = arith.constant 6.2831853071795862 : f64
    %cst_76 = arith.constant 0.95531661812450963 : f64
    %cst_77 = arith.constant 3.141592653589794 : f64
    %cst_78 = arith.constant 3.9269908169872418 : f64
    %cst_79 = arith.constant 5.4977871437821388 : f64
    %cst_80 = arith.constant 9.4247779607693793 : f64
    %cst_81 = arith.constant 2.3561944901923448 : f64
    %cst_82 = arith.constant 0.78539816339744828 : f64
    %cst_83 = arith.constant 0.78539816339744817 : f64
    %cst_84 = arith.constant 2.0943951023931953 : f64
    %cst_85 = arith.constant 7.8539816339744828 : f64
    %cst_86 = arith.constant 3.1415926535897936 : f64
    %cst_87 = arith.constant 3.1415926535897931 : f64
    %cst_88 = arith.constant 0.78539816339744839 : f64
    %cst_89 = arith.constant 4.4408920985006262E-16 : f64
    %cst_90 = arith.constant 0.19634954084936229 : f64
    %cst_91 = arith.constant 1.5707963267948968 : f64
    %cst_92 = arith.constant -1.5707963267948966 : f64
    %cst_93 = arith.constant 4.7123889803846897 : f64
    %cst_94 = arith.constant 0.000000e+00 : f64
    %cst_95 = arith.constant 0.39269908169872414 : f64
    %cst_96 = arith.constant -0.39269908169872414 : f64
    %cst_97 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<5>
    %6 = qco.r(%cst_97, %cst_92) %0 : !qco.qubit -> !qco.qubit
    %7 = qco.r(%cst_97, %cst_97) %1 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_97, %cst_92) %2 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_97, %cst_97) %3 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_81, %cst_86) %4 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%9) targets (%arg0 = %10) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qco.r(%cst_82, %cst_80) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_98, %targets_out_99 = qco.ctrl(%controls_out) targets (%arg0 = %11) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qco.r(%cst_82, %cst_80) %targets_out_99 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_83, %cst_79) %controls_out_98 : !qco.qubit -> !qco.qubit
    %controls_out_100, %targets_out_101 = qco.ctrl(%8) targets (%arg0 = %13) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.r(%cst_97, %cst_78) %targets_out_101 : !qco.qubit -> !qco.qubit
    %controls_out_102, %targets_out_103 = qco.ctrl(%6) targets (%arg0 = %14) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qco.r(%cst_82, %cst_77) %targets_out_103 : !qco.qubit -> !qco.qubit
    %controls_out_104, %targets_out_105 = qco.ctrl(%7) targets (%arg0 = %15) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.r(%cst_82, %cst_94) %targets_out_105 : !qco.qubit -> !qco.qubit
    %controls_out_106, %targets_out_107 = qco.ctrl(%controls_out_102) targets (%arg0 = %16) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.r(%cst_82, %cst_77) %targets_out_107 : !qco.qubit -> !qco.qubit
    %controls_out_108, %targets_out_109 = qco.ctrl(%controls_out_104) targets (%arg0 = %17) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qco.r(%cst_84, %cst_76) %targets_out_109 : !qco.qubit -> !qco.qubit
    %controls_out_110, %targets_out_111 = qco.ctrl(%controls_out_100) targets (%arg0 = %18) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.r(%cst_82, %cst_87) %targets_out_111 : !qco.qubit -> !qco.qubit
    %controls_out_112, %targets_out_113 = qco.ctrl(%19) targets (%arg0 = %12) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.r(%cst_82, %cst_75) %targets_out_113 : !qco.qubit -> !qco.qubit
    %controls_out_114, %targets_out_115 = qco.ctrl(%controls_out_112) targets (%arg0 = %20) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.r(%cst_95, %cst_75) %targets_out_115 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_83, %cst_74) %controls_out_114 : !qco.qubit -> !qco.qubit
    %controls_out_116, %targets_out_117 = qco.ctrl(%controls_out_110) targets (%arg0 = %22) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qco.r(%cst_84, %cst_73) %targets_out_117 : !qco.qubit -> !qco.qubit
    %controls_out_118, %targets_out_119 = qco.ctrl(%controls_out_108) targets (%arg0 = %23) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.r(%cst_82, %cst_72) %targets_out_119 : !qco.qubit -> !qco.qubit
    %controls_out_120, %targets_out_121 = qco.ctrl(%controls_out_106) targets (%arg0 = %24) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %25 = qco.r(%cst_82, %cst_71) %targets_out_121 : !qco.qubit -> !qco.qubit
    %controls_out_122, %targets_out_123 = qco.ctrl(%controls_out_118) targets (%arg0 = %25) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.r(%cst_82, %cst_72) %targets_out_123 : !qco.qubit -> !qco.qubit
    %controls_out_124, %targets_out_125 = qco.ctrl(%controls_out_120) targets (%arg0 = %26) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %27 = qco.r(%cst_97, %cst_70) %targets_out_125 : !qco.qubit -> !qco.qubit
    %controls_out_126, %targets_out_127 = qco.ctrl(%controls_out_116) targets (%arg0 = %27) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qco.r(%cst_91, %cst_85) %targets_out_127 : !qco.qubit -> !qco.qubit
    %controls_out_128, %targets_out_129 = qco.ctrl(%controls_out_126) targets (%arg0 = %21) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.r(%cst_95, %cst_80) %targets_out_129 : !qco.qubit -> !qco.qubit
    %controls_out_130, %targets_out_131 = qco.ctrl(%controls_out_128) targets (%arg0 = %29) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.r(%cst_95, %cst_80) %targets_out_131 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%cst_88, %cst_68) %controls_out_130 : !qco.qubit -> !qco.qubit
    %controls_out_132, %targets_out_133 = qco.ctrl(%controls_out_122) targets (%arg0 = %31) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qco.r(%cst_82, %cst_96) %targets_out_133 : !qco.qubit -> !qco.qubit
    %controls_out_134, %targets_out_135 = qco.ctrl(%controls_out_124) targets (%arg0 = %32) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %33 = qco.r(%cst_82, %cst_67) %targets_out_135 : !qco.qubit -> !qco.qubit
    %controls_out_136, %targets_out_137 = qco.ctrl(%controls_out_132) targets (%arg0 = %33) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.r(%cst_82, %cst_66) %targets_out_137 : !qco.qubit -> !qco.qubit
    %controls_out_138, %targets_out_139 = qco.ctrl(%34) targets (%arg0 = %30) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.r(%cst_95, %cst_75) %targets_out_139 : !qco.qubit -> !qco.qubit
    %controls_out_140, %targets_out_141 = qco.ctrl(%controls_out_138) targets (%arg0 = %35) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qco.r(%cst_90, %cst_75) %targets_out_141 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%cst_83, %cst_77) %controls_out_140 : !qco.qubit -> !qco.qubit
    %controls_out_142, %targets_out_143 = qco.ctrl(%controls_out_136) targets (%arg0 = %37) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qco.r(%cst_82, %cst_89) %targets_out_143 : !qco.qubit -> !qco.qubit
    %controls_out_144, %targets_out_145 = qco.ctrl(%controls_out_134) targets (%arg0 = %38) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.r(%cst_82, %cst_64) %targets_out_145 : !qco.qubit -> !qco.qubit
    %controls_out_146, %targets_out_147 = qco.ctrl(%controls_out_142) targets (%arg0 = %39) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %40 = qco.r(%cst_91, %cst_63) %targets_out_147 : !qco.qubit -> !qco.qubit
    %controls_out_148, %targets_out_149 = qco.ctrl(%controls_out_146) targets (%arg0 = %36) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.r(%cst_90, %cst_80) %targets_out_149 : !qco.qubit -> !qco.qubit
    %controls_out_150, %targets_out_151 = qco.ctrl(%controls_out_148) targets (%arg0 = %41) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qco.r(%cst_90, %cst_80) %targets_out_151 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%cst_91, %cst_62) %controls_out_150 : !qco.qubit -> !qco.qubit
    %controls_out_152, %targets_out_153 = qco.ctrl(%controls_out_144) targets (%arg0 = %43) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = qco.r(%cst_97, %cst_61) %targets_out_153 : !qco.qubit -> !qco.qubit
    %controls_out_154, %targets_out_155 = qco.ctrl(%44) targets (%arg0 = %42) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.r(%cst_90, %cst_75) %targets_out_155 : !qco.qubit -> !qco.qubit
    %controls_out_156, %targets_out_157 = qco.ctrl(%controls_out_154) targets (%arg0 = %45) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qco.r(%cst_90, %cst_75) %targets_out_157 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%cst_91, %cst_92) %controls_out_156 : !qco.qubit -> !qco.qubit
    %controls_out_158, %targets_out_159 = qco.ctrl(%controls_out_152) targets (%arg0 = %47) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %48 = qco.r(%cst_87, %cst_97) %targets_out_159 : !qco.qubit -> !qco.qubit
    %controls_out_160, %targets_out_161 = qco.ctrl(%controls_out_158) targets (%arg0 = %46) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qco.r(%cst_90, %cst_80) %targets_out_161 : !qco.qubit -> !qco.qubit
    %controls_out_162, %targets_out_163 = qco.ctrl(%controls_out_160) targets (%arg0 = %49) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qco.r(%cst_91, %cst_69) %targets_out_163 : !qco.qubit -> !qco.qubit
    %51 = qco.r(%cst_97, %cst_65) %controls_out_162 : !qco.qubit -> !qco.qubit
    %controls_out_164, %targets_out_165 = qco.ctrl(%28) targets (%arg0 = %50) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qco.r(%cst_82, %cst_60) %targets_out_165 : !qco.qubit -> !qco.qubit
    %controls_out_166, %targets_out_167 = qco.ctrl(%controls_out_164) targets (%arg0 = %52) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qco.r(%cst_82, %cst_60) %targets_out_167 : !qco.qubit -> !qco.qubit
    %54 = qco.r(%cst_83, %cst_59) %controls_out_166 : !qco.qubit -> !qco.qubit
    %controls_out_168, %targets_out_169 = qco.ctrl(%40) targets (%arg0 = %54) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.r(%cst_97, %cst_58) %targets_out_169 : !qco.qubit -> !qco.qubit
    %controls_out_170, %targets_out_171 = qco.ctrl(%51) targets (%arg0 = %55) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qco.r(%cst_82, %cst_79) %targets_out_171 : !qco.qubit -> !qco.qubit
    %controls_out_172, %targets_out_173 = qco.ctrl(%48) targets (%arg0 = %56) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %57 = qco.r(%cst_82, %cst_57) %targets_out_173 : !qco.qubit -> !qco.qubit
    %controls_out_174, %targets_out_175 = qco.ctrl(%controls_out_170) targets (%arg0 = %57) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = qco.r(%cst_82, %cst_79) %targets_out_175 : !qco.qubit -> !qco.qubit
    %controls_out_176, %targets_out_177 = qco.ctrl(%controls_out_172) targets (%arg0 = %58) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qco.r(%cst_84, %cst_56) %targets_out_177 : !qco.qubit -> !qco.qubit
    %controls_out_178, %targets_out_179 = qco.ctrl(%controls_out_168) targets (%arg0 = %59) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qco.r(%cst_82, %cst_79) %targets_out_179 : !qco.qubit -> !qco.qubit
    %controls_out_180, %targets_out_181 = qco.ctrl(%60) targets (%arg0 = %53) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qco.r(%cst_82, %cst_55) %targets_out_181 : !qco.qubit -> !qco.qubit
    %controls_out_182, %targets_out_183 = qco.ctrl(%controls_out_180) targets (%arg0 = %61) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %62 = qco.r(%cst_95, %cst_55) %targets_out_183 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%cst_83, %cst_77) %controls_out_182 : !qco.qubit -> !qco.qubit
    %controls_out_184, %targets_out_185 = qco.ctrl(%controls_out_178) targets (%arg0 = %63) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %64 = qco.r(%cst_84, %cst_54) %targets_out_185 : !qco.qubit -> !qco.qubit
    %controls_out_186, %targets_out_187 = qco.ctrl(%controls_out_176) targets (%arg0 = %64) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qco.r(%cst_82, %cst_80) %targets_out_187 : !qco.qubit -> !qco.qubit
    %controls_out_188, %targets_out_189 = qco.ctrl(%controls_out_174) targets (%arg0 = %65) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = qco.r(%cst_82, %cst_53) %targets_out_189 : !qco.qubit -> !qco.qubit
    %controls_out_190, %targets_out_191 = qco.ctrl(%controls_out_186) targets (%arg0 = %66) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %67 = qco.r(%cst_82, %cst_80) %targets_out_191 : !qco.qubit -> !qco.qubit
    %controls_out_192, %targets_out_193 = qco.ctrl(%controls_out_188) targets (%arg0 = %67) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %68 = qco.r(%cst_97, %cst_52) %targets_out_193 : !qco.qubit -> !qco.qubit
    %controls_out_194, %targets_out_195 = qco.ctrl(%controls_out_184) targets (%arg0 = %68) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qco.r(%cst_91, %cst_51) %targets_out_195 : !qco.qubit -> !qco.qubit
    %controls_out_196, %targets_out_197 = qco.ctrl(%controls_out_194) targets (%arg0 = %62) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %70 = qco.r(%cst_95, %cst_60) %targets_out_197 : !qco.qubit -> !qco.qubit
    %controls_out_198, %targets_out_199 = qco.ctrl(%controls_out_196) targets (%arg0 = %70) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qco.r(%cst_95, %cst_60) %targets_out_199 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%cst_88, %cst_50) %controls_out_198 : !qco.qubit -> !qco.qubit
    %controls_out_200, %targets_out_201 = qco.ctrl(%controls_out_190) targets (%arg0 = %72) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %73 = qco.r(%cst_82, %cst_48) %targets_out_201 : !qco.qubit -> !qco.qubit
    %controls_out_202, %targets_out_203 = qco.ctrl(%controls_out_192) targets (%arg0 = %73) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %74 = qco.r(%cst_82, %cst_47) %targets_out_203 : !qco.qubit -> !qco.qubit
    %controls_out_204, %targets_out_205 = qco.ctrl(%controls_out_200) targets (%arg0 = %74) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %75 = qco.r(%cst_82, %cst_46) %targets_out_205 : !qco.qubit -> !qco.qubit
    %controls_out_206, %targets_out_207 = qco.ctrl(%75) targets (%arg0 = %71) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %76 = qco.r(%cst_95, %cst_55) %targets_out_207 : !qco.qubit -> !qco.qubit
    %controls_out_208, %targets_out_209 = qco.ctrl(%controls_out_206) targets (%arg0 = %76) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qco.r(%cst_90, %cst_55) %targets_out_209 : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst_83, %cst_45) %controls_out_208 : !qco.qubit -> !qco.qubit
    %controls_out_210, %targets_out_211 = qco.ctrl(%controls_out_204) targets (%arg0 = %78) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %79 = qco.r(%cst_82, %cst_43) %targets_out_211 : !qco.qubit -> !qco.qubit
    %controls_out_212, %targets_out_213 = qco.ctrl(%controls_out_202) targets (%arg0 = %79) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %80 = qco.r(%cst_82, %cst_42) %targets_out_213 : !qco.qubit -> !qco.qubit
    %controls_out_214, %targets_out_215 = qco.ctrl(%controls_out_210) targets (%arg0 = %80) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %81 = qco.r(%cst_97, %cst_41) %targets_out_215 : !qco.qubit -> !qco.qubit
    %controls_out_216, %targets_out_217 = qco.ctrl(%controls_out_214) targets (%arg0 = %77) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %82 = qco.r(%cst_90, %cst_60) %targets_out_217 : !qco.qubit -> !qco.qubit
    %controls_out_218, %targets_out_219 = qco.ctrl(%controls_out_216) targets (%arg0 = %82) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qco.r(%cst_90, %cst_60) %targets_out_219 : !qco.qubit -> !qco.qubit
    %84 = qco.r(%cst_91, %cst_40) %controls_out_218 : !qco.qubit -> !qco.qubit
    %controls_out_220, %targets_out_221 = qco.ctrl(%controls_out_212) targets (%arg0 = %84) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %85 = qco.r(%cst_97, %cst_62) %targets_out_221 : !qco.qubit -> !qco.qubit
    %controls_out_222, %targets_out_223 = qco.ctrl(%85) targets (%arg0 = %83) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %86 = qco.r(%cst_90, %cst_55) %targets_out_223 : !qco.qubit -> !qco.qubit
    %controls_out_224, %targets_out_225 = qco.ctrl(%controls_out_222) targets (%arg0 = %86) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %87 = qco.r(%cst_90, %cst_55) %targets_out_225 : !qco.qubit -> !qco.qubit
    %88 = qco.r(%cst_91, %cst_97) %controls_out_224 : !qco.qubit -> !qco.qubit
    %controls_out_226, %targets_out_227 = qco.ctrl(%controls_out_220) targets (%arg0 = %88) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %89 = qco.r(%cst_87, %cst_93) %targets_out_227 : !qco.qubit -> !qco.qubit
    %controls_out_228, %targets_out_229 = qco.ctrl(%controls_out_226) targets (%arg0 = %87) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %90 = qco.r(%cst_90, %cst_60) %targets_out_229 : !qco.qubit -> !qco.qubit
    %controls_out_230, %targets_out_231 = qco.ctrl(%controls_out_228) targets (%arg0 = %90) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %91 = qco.r(%cst_97, %cst_39) %targets_out_231 : !qco.qubit -> !qco.qubit
    %92 = qco.r(%cst_97, %cst_49) %controls_out_230 : !qco.qubit -> !qco.qubit
    %controls_out_232, %targets_out_233 = qco.ctrl(%69) targets (%arg0 = %91) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %93 = qco.r(%cst_82, %cst_80) %targets_out_233 : !qco.qubit -> !qco.qubit
    %controls_out_234, %targets_out_235 = qco.ctrl(%controls_out_232) targets (%arg0 = %93) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %94 = qco.r(%cst_82, %cst_80) %targets_out_235 : !qco.qubit -> !qco.qubit
    %95 = qco.r(%cst_83, %cst_38) %controls_out_234 : !qco.qubit -> !qco.qubit
    %controls_out_236, %targets_out_237 = qco.ctrl(%81) targets (%arg0 = %95) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %96 = qco.r(%cst_97, %cst_37) %targets_out_237 : !qco.qubit -> !qco.qubit
    %controls_out_238, %targets_out_239 = qco.ctrl(%92) targets (%arg0 = %96) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %97 = qco.r(%cst_82, %cst_59) %targets_out_239 : !qco.qubit -> !qco.qubit
    %controls_out_240, %targets_out_241 = qco.ctrl(%89) targets (%arg0 = %97) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %98 = qco.r(%cst_82, %cst_36) %targets_out_241 : !qco.qubit -> !qco.qubit
    %controls_out_242, %targets_out_243 = qco.ctrl(%controls_out_238) targets (%arg0 = %98) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %99 = qco.r(%cst_82, %cst_59) %targets_out_243 : !qco.qubit -> !qco.qubit
    %controls_out_244, %targets_out_245 = qco.ctrl(%controls_out_240) targets (%arg0 = %99) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %100 = qco.r(%cst_84, %cst_35) %targets_out_245 : !qco.qubit -> !qco.qubit
    %controls_out_246, %targets_out_247 = qco.ctrl(%controls_out_236) targets (%arg0 = %100) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %101 = qco.r(%cst_82, %cst_59) %targets_out_247 : !qco.qubit -> !qco.qubit
    %controls_out_248, %targets_out_249 = qco.ctrl(%101) targets (%arg0 = %94) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %102 = qco.r(%cst_82, %cst_34) %targets_out_249 : !qco.qubit -> !qco.qubit
    %controls_out_250, %targets_out_251 = qco.ctrl(%controls_out_248) targets (%arg0 = %102) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %103 = qco.r(%cst_95, %cst_34) %targets_out_251 : !qco.qubit -> !qco.qubit
    %104 = qco.r(%cst_83, %cst_33) %controls_out_250 : !qco.qubit -> !qco.qubit
    %controls_out_252, %targets_out_253 = qco.ctrl(%controls_out_246) targets (%arg0 = %104) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %105 = qco.r(%cst_84, %cst_32) %targets_out_253 : !qco.qubit -> !qco.qubit
    %controls_out_254, %targets_out_255 = qco.ctrl(%controls_out_244) targets (%arg0 = %105) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %106 = qco.r(%cst_82, %cst_31) %targets_out_255 : !qco.qubit -> !qco.qubit
    %controls_out_256, %targets_out_257 = qco.ctrl(%controls_out_242) targets (%arg0 = %106) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %107 = qco.r(%cst_82, %cst_30) %targets_out_257 : !qco.qubit -> !qco.qubit
    %controls_out_258, %targets_out_259 = qco.ctrl(%controls_out_254) targets (%arg0 = %107) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %108 = qco.r(%cst_82, %cst_31) %targets_out_259 : !qco.qubit -> !qco.qubit
    %controls_out_260, %targets_out_261 = qco.ctrl(%controls_out_256) targets (%arg0 = %108) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %109 = qco.r(%cst_97, %cst_29) %targets_out_261 : !qco.qubit -> !qco.qubit
    %controls_out_262, %targets_out_263 = qco.ctrl(%controls_out_252) targets (%arg0 = %109) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %110 = qco.r(%cst_91, %cst_28) %targets_out_263 : !qco.qubit -> !qco.qubit
    %controls_out_264, %targets_out_265 = qco.ctrl(%controls_out_262) targets (%arg0 = %103) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %111 = qco.r(%cst_95, %cst_80) %targets_out_265 : !qco.qubit -> !qco.qubit
    %controls_out_266, %targets_out_267 = qco.ctrl(%controls_out_264) targets (%arg0 = %111) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %112 = qco.r(%cst_95, %cst_80) %targets_out_267 : !qco.qubit -> !qco.qubit
    %113 = qco.r(%cst_88, %cst_27) %controls_out_266 : !qco.qubit -> !qco.qubit
    %controls_out_268, %targets_out_269 = qco.ctrl(%controls_out_258) targets (%arg0 = %113) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %114 = qco.r(%cst_82, %cst_26) %targets_out_269 : !qco.qubit -> !qco.qubit
    %controls_out_270, %targets_out_271 = qco.ctrl(%controls_out_260) targets (%arg0 = %114) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %115 = qco.r(%cst_82, %cst_25) %targets_out_271 : !qco.qubit -> !qco.qubit
    %controls_out_272, %targets_out_273 = qco.ctrl(%controls_out_268) targets (%arg0 = %115) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %116 = qco.r(%cst_82, %cst_24) %targets_out_273 : !qco.qubit -> !qco.qubit
    %controls_out_274, %targets_out_275 = qco.ctrl(%116) targets (%arg0 = %112) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %117 = qco.r(%cst_95, %cst_34) %targets_out_275 : !qco.qubit -> !qco.qubit
    %controls_out_276, %targets_out_277 = qco.ctrl(%controls_out_274) targets (%arg0 = %117) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %118 = qco.r(%cst_90, %cst_34) %targets_out_277 : !qco.qubit -> !qco.qubit
    %119 = qco.r(%cst_83, %cst_23) %controls_out_276 : !qco.qubit -> !qco.qubit
    %controls_out_278, %targets_out_279 = qco.ctrl(%controls_out_272) targets (%arg0 = %119) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %120 = qco.r(%cst_82, %cst_22) %targets_out_279 : !qco.qubit -> !qco.qubit
    %controls_out_280, %targets_out_281 = qco.ctrl(%controls_out_270) targets (%arg0 = %120) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %121 = qco.r(%cst_82, %cst_21) %targets_out_281 : !qco.qubit -> !qco.qubit
    %controls_out_282, %targets_out_283 = qco.ctrl(%controls_out_278) targets (%arg0 = %121) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %122 = qco.r(%cst_91, %cst_20) %targets_out_283 : !qco.qubit -> !qco.qubit
    %controls_out_284, %targets_out_285 = qco.ctrl(%controls_out_282) targets (%arg0 = %118) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %123 = qco.r(%cst_90, %cst_80) %targets_out_285 : !qco.qubit -> !qco.qubit
    %controls_out_286, %targets_out_287 = qco.ctrl(%controls_out_284) targets (%arg0 = %123) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %124 = qco.r(%cst_90, %cst_80) %targets_out_287 : !qco.qubit -> !qco.qubit
    %125 = qco.r(%cst_91, %cst_19) %controls_out_286 : !qco.qubit -> !qco.qubit
    %controls_out_288, %targets_out_289 = qco.ctrl(%controls_out_280) targets (%arg0 = %125) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %126 = qco.r(%cst_97, %cst_40) %targets_out_289 : !qco.qubit -> !qco.qubit
    %controls_out_290, %targets_out_291 = qco.ctrl(%126) targets (%arg0 = %124) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %127 = qco.r(%cst_90, %cst_34) %targets_out_291 : !qco.qubit -> !qco.qubit
    %controls_out_292, %targets_out_293 = qco.ctrl(%controls_out_290) targets (%arg0 = %127) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %128 = qco.r(%cst_90, %cst_34) %targets_out_293 : !qco.qubit -> !qco.qubit
    %129 = qco.r(%cst_91, %cst_93) %controls_out_292 : !qco.qubit -> !qco.qubit
    %controls_out_294, %targets_out_295 = qco.ctrl(%controls_out_288) targets (%arg0 = %129) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %130 = qco.r(%cst_87, %cst_85) %targets_out_295 : !qco.qubit -> !qco.qubit
    %controls_out_296, %targets_out_297 = qco.ctrl(%controls_out_294) targets (%arg0 = %128) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %131 = qco.r(%cst_90, %cst_80) %targets_out_297 : !qco.qubit -> !qco.qubit
    %controls_out_298, %targets_out_299 = qco.ctrl(%controls_out_296) targets (%arg0 = %131) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %132 = qco.r(%cst_91, %cst_18) %targets_out_299 : !qco.qubit -> !qco.qubit
    %133 = qco.r(%cst_97, %cst_17) %controls_out_298 : !qco.qubit -> !qco.qubit
    %controls_out_300, %targets_out_301 = qco.ctrl(%110) targets (%arg0 = %132) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %134 = qco.r(%cst_82, %cst_60) %targets_out_301 : !qco.qubit -> !qco.qubit
    %controls_out_302, %targets_out_303 = qco.ctrl(%controls_out_300) targets (%arg0 = %134) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %135 = qco.r(%cst_82, %cst_60) %targets_out_303 : !qco.qubit -> !qco.qubit
    %136 = qco.r(%cst_83, %cst_28) %controls_out_302 : !qco.qubit -> !qco.qubit
    %controls_out_304, %targets_out_305 = qco.ctrl(%122) targets (%arg0 = %136) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %137 = qco.r(%cst_97, %cst_16) %targets_out_305 : !qco.qubit -> !qco.qubit
    %controls_out_306, %targets_out_307 = qco.ctrl(%133) targets (%arg0 = %137) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %138 = qco.r(%cst_82, %cst_71) %targets_out_307 : !qco.qubit -> !qco.qubit
    %controls_out_308, %targets_out_309 = qco.ctrl(%130) targets (%arg0 = %138) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %139 = qco.r(%cst_82, %cst_72) %targets_out_309 : !qco.qubit -> !qco.qubit
    %controls_out_310, %targets_out_311 = qco.ctrl(%controls_out_306) targets (%arg0 = %139) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %140 = qco.r(%cst_82, %cst_71) %targets_out_311 : !qco.qubit -> !qco.qubit
    %controls_out_312, %targets_out_313 = qco.ctrl(%controls_out_308) targets (%arg0 = %140) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %141 = qco.r(%cst_84, %cst_15) %targets_out_313 : !qco.qubit -> !qco.qubit
    %controls_out_314, %targets_out_315 = qco.ctrl(%controls_out_304) targets (%arg0 = %141) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %142 = qco.r(%cst_82, %cst_71) %targets_out_315 : !qco.qubit -> !qco.qubit
    %controls_out_316, %targets_out_317 = qco.ctrl(%142) targets (%arg0 = %135) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %143 = qco.r(%cst_82, %cst_14) %targets_out_317 : !qco.qubit -> !qco.qubit
    %controls_out_318, %targets_out_319 = qco.ctrl(%controls_out_316) targets (%arg0 = %143) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %144 = qco.r(%cst_95, %cst_14) %targets_out_319 : !qco.qubit -> !qco.qubit
    %145 = qco.r(%cst_83, %cst_13) %controls_out_318 : !qco.qubit -> !qco.qubit
    %controls_out_320, %targets_out_321 = qco.ctrl(%controls_out_314) targets (%arg0 = %145) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %146 = qco.r(%cst_84, %cst_12) %targets_out_321 : !qco.qubit -> !qco.qubit
    %controls_out_322, %targets_out_323 = qco.ctrl(%controls_out_312) targets (%arg0 = %146) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %147 = qco.r(%cst_82, %cst_11) %targets_out_323 : !qco.qubit -> !qco.qubit
    %controls_out_324, %targets_out_325 = qco.ctrl(%controls_out_310) targets (%arg0 = %147) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %148 = qco.r(%cst_82, %cst_10) %targets_out_325 : !qco.qubit -> !qco.qubit
    %controls_out_326, %targets_out_327 = qco.ctrl(%controls_out_322) targets (%arg0 = %148) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %149 = qco.r(%cst_82, %cst_11) %targets_out_327 : !qco.qubit -> !qco.qubit
    %controls_out_328, %targets_out_329 = qco.ctrl(%controls_out_324) targets (%arg0 = %149) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %150 = qco.r(%cst_97, %cst_9) %targets_out_329 : !qco.qubit -> !qco.qubit
    %controls_out_330, %targets_out_331 = qco.ctrl(%controls_out_320) targets (%arg0 = %150) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %151 = qco.r(%cst_97, %cst_8) %targets_out_331 : !qco.qubit -> !qco.qubit
    %controls_out_332, %targets_out_333 = qco.ctrl(%controls_out_330) targets (%arg0 = %144) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %152 = qco.r(%cst_95, %cst_60) %targets_out_333 : !qco.qubit -> !qco.qubit
    %controls_out_334, %targets_out_335 = qco.ctrl(%controls_out_332) targets (%arg0 = %152) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %153 = qco.r(%cst_95, %cst_60) %targets_out_335 : !qco.qubit -> !qco.qubit
    %154 = qco.r(%cst_88, %cst_7) %controls_out_334 : !qco.qubit -> !qco.qubit
    %controls_out_336, %targets_out_337 = qco.ctrl(%controls_out_326) targets (%arg0 = %154) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %155 = qco.r(%cst_82, %cst_6) %targets_out_337 : !qco.qubit -> !qco.qubit
    %controls_out_338, %targets_out_339 = qco.ctrl(%controls_out_328) targets (%arg0 = %155) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %156 = qco.r(%cst_82, %cst_5) %targets_out_339 : !qco.qubit -> !qco.qubit
    %controls_out_340, %targets_out_341 = qco.ctrl(%controls_out_336) targets (%arg0 = %156) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %157 = qco.r(%cst_82, %cst_4) %targets_out_341 : !qco.qubit -> !qco.qubit
    %controls_out_342, %targets_out_343 = qco.ctrl(%157) targets (%arg0 = %153) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %158 = qco.r(%cst_95, %cst_14) %targets_out_343 : !qco.qubit -> !qco.qubit
    %controls_out_344, %targets_out_345 = qco.ctrl(%controls_out_342) targets (%arg0 = %158) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %159 = qco.r(%cst_90, %cst_14) %targets_out_345 : !qco.qubit -> !qco.qubit
    %160 = qco.r(%cst_83, %cst_3) %controls_out_344 : !qco.qubit -> !qco.qubit
    %controls_out_346, %targets_out_347 = qco.ctrl(%controls_out_340) targets (%arg0 = %160) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %161 = qco.r(%cst_82, %cst_2) %targets_out_347 : !qco.qubit -> !qco.qubit
    %controls_out_348, %targets_out_349 = qco.ctrl(%controls_out_338) targets (%arg0 = %161) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %162 = qco.r(%cst_82, %cst_1) %targets_out_349 : !qco.qubit -> !qco.qubit
    %controls_out_350, %targets_out_351 = qco.ctrl(%controls_out_346) targets (%arg0 = %162) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %163 = qco.r(%cst_97, %cst_0) %targets_out_351 : !qco.qubit -> !qco.qubit
    %controls_out_352, %targets_out_353 = qco.ctrl(%controls_out_350) targets (%arg0 = %159) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %164 = qco.r(%cst_90, %cst_60) %targets_out_353 : !qco.qubit -> !qco.qubit
    %controls_out_354, %targets_out_355 = qco.ctrl(%controls_out_352) targets (%arg0 = %164) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %165 = qco.r(%cst_90, %cst_60) %targets_out_355 : !qco.qubit -> !qco.qubit
    %166 = qco.r(%cst_91, %cst) %controls_out_354 : !qco.qubit -> !qco.qubit
    %controls_out_356, %targets_out_357 = qco.ctrl(%controls_out_348) targets (%arg0 = %166) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %167 = qco.r(%cst_97, %cst_19) %targets_out_357 : !qco.qubit -> !qco.qubit
    %controls_out_358, %targets_out_359 = qco.ctrl(%167) targets (%arg0 = %165) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %168 = qco.r(%cst_90, %cst_14) %targets_out_359 : !qco.qubit -> !qco.qubit
    %controls_out_360, %targets_out_361 = qco.ctrl(%controls_out_358) targets (%arg0 = %168) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %169 = qco.r(%cst_90, %cst_14) %targets_out_361 : !qco.qubit -> !qco.qubit
    %170 = qco.r(%cst_91, %cst_13) %controls_out_360 : !qco.qubit -> !qco.qubit
    %controls_out_362, %targets_out_363 = qco.ctrl(%controls_out_356) targets (%arg0 = %170) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_364, %targets_out_365 = qco.ctrl(%controls_out_362) targets (%arg0 = %169) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %171 = qco.r(%cst_90, %cst_60) %targets_out_365 : !qco.qubit -> !qco.qubit
    %controls_out_366, %targets_out_367 = qco.ctrl(%controls_out_364) targets (%arg0 = %171) {
      %174 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %174 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %172 = qco.r(%cst_87, %cst_51) %targets_out_367 : !qco.qubit -> !qco.qubit
    %173 = qco.r(%cst_97, %cst_44) %controls_out_366 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %173 : !qco.qubit
    cbit.store %result, %5[%c0] : !cbit.reg<5>
    %qubit_out_368, %result_369 = qco.measure %targets_out_363 : !qco.qubit
    cbit.store %result_369, %5[%c1] : !cbit.reg<5>
    %qubit_out_370, %result_371 = qco.measure %163 : !qco.qubit
    cbit.store %result_371, %5[%c2] : !cbit.reg<5>
    %qubit_out_372, %result_373 = qco.measure %151 : !qco.qubit
    cbit.store %result_373, %5[%c3] : !cbit.reg<5>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_368 : !qco.qubit
    qco.sink %qubit_out_370 : !qco.qubit
    qco.sink %qubit_out_372 : !qco.qubit
    %qubit_out_374, %result_375 = qco.measure %172 : !qco.qubit
    qco.sink %qubit_out_374 : !qco.qubit
    cbit.store %result_375, %5[%c4] : !cbit.reg<5>
    %cst_376 = arith.constant -1.1780972450961695 : f64
    qco.gphase(%cst_376)
    return %5 : !cbit.reg<5>
  }
}
