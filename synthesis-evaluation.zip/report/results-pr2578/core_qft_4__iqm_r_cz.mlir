module attributes {mqt.layout = {initial = array<i64: 3, 2, 0, 1>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 3.337942194439155 : f64
    %cst_0 = arith.constant 0.39269908169872458 : f64
    %cst_1 = arith.constant -2.3561944901923444 : f64
    %cst_2 = arith.constant 1.9634954084936209 : f64
    %cst_3 = arith.constant -3.9269908169872405 : f64
    %cst_4 = arith.constant -0.78539816339744828 : f64
    %cst_5 = arith.constant 0.78539816339744828 : f64
    %cst_6 = arith.constant 1.5707963267948966 : f64
    %cst_7 = arith.constant 2.3561944901923448 : f64
    %cst_8 = arith.constant 0.19634954084936229 : f64
    %cst_9 = arith.constant 0.39269908169872414 : f64
    %cst_10 = arith.constant -1.5707963267948966 : f64
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.r(%cst_6, %cst_10) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.r(%cst_6, %cst_5) %1 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%5) targets (%arg0 = %6) {
      %22 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %22 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %7 = qco.r(%cst_5, %cst_7) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%controls_out) targets (%arg0 = %7) {
      %22 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %22 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %8 = qco.r(%cst_9, %cst_4) %targets_out_12 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_7, %cst_4) %controls_out_11 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%2) targets (%arg0 = %8) {
      %22 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %22 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %10 = qco.r(%cst_9, %cst_7) %targets_out_14 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%controls_out_13) targets (%arg0 = %10) {
      %22 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %22 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qco.r(%cst_8, %cst_4) %targets_out_16 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%3) targets (%arg0 = %11) {
      %22 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %22 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qco.r(%cst_8, %cst_7) %targets_out_18 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%controls_out_17) targets (%arg0 = %12) {
      %22 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %22 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %13 = qco.r(%cst_10, %cst_5) %targets_out_20 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%controls_out_15) targets (%arg0 = %9) {
      %22 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %22 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.r(%cst_5, %cst_4) %targets_out_22 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%controls_out_21) targets (%arg0 = %14) {
      %22 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %22 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qco.r(%cst_9, %cst_3) %targets_out_24 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_7, %cst_2) %controls_out_23 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%controls_out_19) targets (%arg0 = %15) {
      %22 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %22 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.r(%cst_9, %cst_4) %targets_out_26 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%controls_out_25) targets (%arg0 = %17) {
      %22 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %22 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qco.r(%cst_10, %cst_1) %targets_out_28 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%controls_out_27) targets (%arg0 = %16) {
      %22 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %22 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.r(%cst_5, %cst_2) %targets_out_30 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%controls_out_29) targets (%arg0 = %19) {
      %22 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %22 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.r(%cst_10, %cst_0) %targets_out_32 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_6, %cst) %controls_out_31 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %21 : !qco.qubit
    cbit.store %result, %4[%c3] : !cbit.reg<4>
    %qubit_out_33, %result_34 = qco.measure %20 : !qco.qubit
    cbit.store %result_34, %4[%c2] : !cbit.reg<4>
    %qubit_out_35, %result_36 = qco.measure %18 : !qco.qubit
    cbit.store %result_36, %4[%c1] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_33 : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    %qubit_out_37, %result_38 = qco.measure %13 : !qco.qubit
    qco.sink %qubit_out_37 : !qco.qubit
    cbit.store %result_38, %4[%c0] : !cbit.reg<4>
    %cst_39 = arith.constant 1.6689710972195777 : f64
    qco.gphase(%cst_39)
    return %4 : !cbit.reg<4>
  }
}
