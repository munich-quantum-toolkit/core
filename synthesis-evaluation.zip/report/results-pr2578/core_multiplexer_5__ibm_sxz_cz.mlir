module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 0>, input_count = 5 : i64, sites = array<i64: 0, 1, 2, 3, 4>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<5> attributes {mqt.entry_point} {
    %cst = arith.constant -2.3561944901923448 : f64
    %cst_0 = arith.constant -2.7488935718910685 : f64
    %cst_1 = arith.constant -2.9452431127404308 : f64
    %cst_2 = arith.constant 1.5707963267948966 : f64
    %cst_3 = arith.constant -1.5707963267948966 : f64
    %cst_4 = arith.constant -3.0434178831651124 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<5>
    %6 = qco.rz(%cst_2) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.sx %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_2) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_2) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_2) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_2) %3 : !qco.qubit -> !qco.qubit
    %13 = qco.sx %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_2) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_2) %4 : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_2) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %0 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.sx %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_2) %20 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%17) targets (%arg0 = %21) {
      %58 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %58 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.rz(%cst_3) %targets_out : !qco.qubit -> !qco.qubit
    %23 = qco.sx %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.sx %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_3) %25 : !qco.qubit -> !qco.qubit
    %controls_out_5, %targets_out_6 = qco.ctrl(%controls_out) targets (%arg0 = %26) {
      %58 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %58 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %27 = qco.rz(%cst_2) %targets_out_6 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_0) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.sx %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_2) %30 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%14) targets (%arg0 = %31) {
      %58 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %58 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qco.rz(%cst_3) %targets_out_8 : !qco.qubit -> !qco.qubit
    %33 = qco.sx %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_0) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.sx %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_3) %35 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%controls_out_7) targets (%arg0 = %36) {
      %58 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %58 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.rz(%cst_2) %targets_out_10 : !qco.qubit -> !qco.qubit
    %38 = qco.sx %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_1) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.sx %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_2) %40 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%11) targets (%arg0 = %41) {
      %58 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %58 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qco.rz(%cst_3) %targets_out_12 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_1) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.sx %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_3) %45 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%controls_out_11) targets (%arg0 = %46) {
      %58 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %58 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.rz(%cst_2) %targets_out_14 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_4) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.sx %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_2) %50 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%8) targets (%arg0 = %51) {
      %58 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %58 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qco.rz(%cst_3) %targets_out_16 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_4) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.sx %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_3) %55 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%controls_out_15) targets (%arg0 = %56) {
      %58 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %58 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %57 = qco.rz(%cst_2) %targets_out_18 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %57 : !qco.qubit
    cbit.store %result, %5[%c0] : !cbit.reg<5>
    %qubit_out_19, %result_20 = qco.measure %controls_out_17 : !qco.qubit
    cbit.store %result_20, %5[%c1] : !cbit.reg<5>
    %qubit_out_21, %result_22 = qco.measure %controls_out_13 : !qco.qubit
    cbit.store %result_22, %5[%c2] : !cbit.reg<5>
    %qubit_out_23, %result_24 = qco.measure %controls_out_9 : !qco.qubit
    cbit.store %result_24, %5[%c3] : !cbit.reg<5>
    qco.sink %qubit_out_19 : !qco.qubit
    qco.sink %qubit_out_21 : !qco.qubit
    qco.sink %qubit_out_23 : !qco.qubit
    %qubit_out_25, %result_26 = qco.measure %controls_out_5 : !qco.qubit
    qco.sink %qubit_out_25 : !qco.qubit
    cbit.store %result_26, %5[%c4] : !cbit.reg<5>
    qco.sink %qubit_out : !qco.qubit
    %cst_27 = arith.constant 3.1415926535897931 : f64
    qco.gphase(%cst_27)
    return %5 : !cbit.reg<5>
  }
}
