module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 0>, input_count = 7 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant -2.3561944901923448 : f64
    %cst_0 = arith.constant -2.7488935718910685 : f64
    %cst_1 = arith.constant -2.9452431127404308 : f64
    %cst_2 = arith.constant -3.0434178831651124 : f64
    %cst_3 = arith.constant -3.0925052683774528 : f64
    %cst_4 = arith.constant -1.5707963267948966 : f64
    %cst_5 = arith.constant -3.1170489609836229 : f64
    %cst_6 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %8 = qco.rz(%cst_6) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_6) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_6) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_6) %2 : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_6) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_6) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_6) %3 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_6) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_6) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_6) %4 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_6) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_6) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_6) %5 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_6) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_6) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_6) %6 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_6) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_6) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_6) %0 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_6) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_6) %28 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%25) targets (%arg0 = %29) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.rz(%cst_4) %targets_out : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_6) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_6) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_4) %33 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%controls_out) targets (%arg0 = %34) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_9 = arith.constant 1.5707963267948957 : f64
    %35 = qco.rz(%cst_9) %targets_out_8 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_6) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_0) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rx(%cst_6) %37 : !qco.qubit -> !qco.qubit
    %cst_10 = arith.constant 1.5707963267948974 : f64
    %39 = qco.rz(%cst_10) %38 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%22) targets (%arg0 = %39) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %40 = qco.rz(%cst_4) %targets_out_12 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_6) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_0) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_6) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_4) %43 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%controls_out_11) targets (%arg0 = %44) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.rz(%cst_6) %targets_out_14 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst_6) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_1) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rx(%cst_6) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_6) %48 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%19) targets (%arg0 = %49) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qco.rz(%cst_4) %targets_out_16 : !qco.qubit -> !qco.qubit
    %51 = qco.rx(%cst_6) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_1) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rx(%cst_6) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_4) %53 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%controls_out_15) targets (%arg0 = %54) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.rz(%cst_10) %targets_out_18 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_6) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_2) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_6) %57 : !qco.qubit -> !qco.qubit
    %cst_19 = arith.constant 1.5707963267948948 : f64
    %59 = qco.rz(%cst_19) %58 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%16) targets (%arg0 = %59) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qco.rz(%cst_4) %targets_out_21 : !qco.qubit -> !qco.qubit
    %61 = qco.rx(%cst_6) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_2) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rx(%cst_6) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_4) %63 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%controls_out_20) targets (%arg0 = %64) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qco.rz(%cst_19) %targets_out_23 : !qco.qubit -> !qco.qubit
    %66 = qco.rx(%cst_6) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_3) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rx(%cst_6) %67 : !qco.qubit -> !qco.qubit
    %cst_24 = arith.constant 1.5707963267948983 : f64
    %69 = qco.rz(%cst_24) %68 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%13) targets (%arg0 = %69) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %70 = qco.rz(%cst_4) %targets_out_26 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_6) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_3) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rx(%cst_6) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_4) %73 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%controls_out_25) targets (%arg0 = %74) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_29 = arith.constant 1.570796326794893 : f64
    %75 = qco.rz(%cst_29) %targets_out_28 : !qco.qubit -> !qco.qubit
    %76 = qco.rx(%cst_6) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_5) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rx(%cst_6) %77 : !qco.qubit -> !qco.qubit
    %cst_30 = arith.constant 1.5707963267949001 : f64
    %79 = qco.rz(%cst_30) %78 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%10) targets (%arg0 = %79) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %80 = qco.rz(%cst_4) %targets_out_32 : !qco.qubit -> !qco.qubit
    %81 = qco.rx(%cst_6) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_5) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rx(%cst_6) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_4) %83 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%controls_out_31) targets (%arg0 = %84) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %85 = qco.rz(%cst_6) %targets_out_34 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %85 : !qco.qubit
    cbit.store %result, %7[%c0] : !cbit.reg<7>
    %qubit_out_35, %result_36 = qco.measure %controls_out_33 : !qco.qubit
    cbit.store %result_36, %7[%c1] : !cbit.reg<7>
    %qubit_out_37, %result_38 = qco.measure %controls_out_27 : !qco.qubit
    cbit.store %result_38, %7[%c2] : !cbit.reg<7>
    %qubit_out_39, %result_40 = qco.measure %controls_out_22 : !qco.qubit
    cbit.store %result_40, %7[%c3] : !cbit.reg<7>
    %qubit_out_41, %result_42 = qco.measure %controls_out_17 : !qco.qubit
    cbit.store %result_42, %7[%c4] : !cbit.reg<7>
    %qubit_out_43, %result_44 = qco.measure %controls_out_13 : !qco.qubit
    cbit.store %result_44, %7[%c5] : !cbit.reg<7>
    qco.sink %qubit_out_35 : !qco.qubit
    qco.sink %qubit_out_37 : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    qco.sink %qubit_out_41 : !qco.qubit
    qco.sink %qubit_out_43 : !qco.qubit
    %qubit_out_45, %result_46 = qco.measure %controls_out_7 : !qco.qubit
    qco.sink %qubit_out_45 : !qco.qubit
    cbit.store %result_46, %7[%c6] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    %cst_47 = arith.constant 3.1415926535897931 : f64
    qco.gphase(%cst_47)
    return %7 : !cbit.reg<7>
  }
}
