module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948961 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.rz(%cst_0) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rx(%cst_0) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_0) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_1) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_0) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_0) %9 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_1) %7, %10 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %11 = qco.rx(%cst) %qubit1_out : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_0) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_1) %qubit0_out : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_1) %2 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_0) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_0) %15 : !qco.qubit -> !qco.qubit
    %qubit0_out_2, %qubit1_out_3 = qco.rzz(%cst_1) %12, %16 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %17 = qco.rx(%cst) %qubit1_out_3 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_0) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_1) %qubit0_out_2 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_1) %3 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_0) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_0) %21 : !qco.qubit -> !qco.qubit
    %qubit0_out_4, %qubit1_out_5 = qco.rzz(%cst_1) %18, %22 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %23 = qco.rx(%cst) %qubit1_out_5 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_0) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_1) %qubit0_out_4 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %13 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<4>
    %qubit_out_6, %result_7 = qco.measure %19 : !qco.qubit
    cbit.store %result_7, %4[%c1] : !cbit.reg<4>
    %qubit_out_8, %result_9 = qco.measure %25 : !qco.qubit
    cbit.store %result_9, %4[%c2] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_6 : !qco.qubit
    qco.sink %qubit_out_8 : !qco.qubit
    %qubit_out_10, %result_11 = qco.measure %24 : !qco.qubit
    qco.sink %qubit_out_10 : !qco.qubit
    cbit.store %result_11, %4[%c3] : !cbit.reg<4>
    %cst_12 = arith.constant -0.78539816339744828 : f64
    qco.gphase(%cst_12)
    return %4 : !cbit.reg<4>
  }
}
