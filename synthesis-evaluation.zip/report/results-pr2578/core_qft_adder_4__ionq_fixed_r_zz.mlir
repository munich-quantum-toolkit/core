module attributes {mqt.layout = {initial = array<i64: 1, 0, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "gpi", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = [], fixed_parameters = [3.1415926535897931, unit], canonical_name = "r">, <name = "gpi2", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = [], fixed_parameters = [1.5707963267948966, unit], canonical_name = "r">, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948966 : f64
    %cst_0 = arith.constant 3.1415926535897931 : f64
    %cst_1 = arith.constant -5.000000e-01 : f64
    %cst_2 = arith.constant -0.78539816339744828 : f64
    %cst_3 = arith.constant 0.000000e+00 : f64
    %cst_4 = arith.constant 1.5707963267948966 : f64
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.r(%cst_0, %cst_3) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.r(%cst_0, %cst_3) %2 : !qco.qubit -> !qco.qubit
    %6 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %7 = qco.rz(%cst_4) %3 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_4, %cst_3) %7 : !qco.qubit -> !qco.qubit
    %cst_5 = arith.constant 2.3561944901923448 : f64
    %9 = qco.rz(%cst_5) %8 : !qco.qubit -> !qco.qubit
    %10 = arith.mulf %cst_4, %cst_1 : f64
    %qubit0_out, %qubit1_out = qco.rzz(%10) %5, %9 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_6 = arith.constant -0.78539816339744872 : f64
    %11 = qco.rz(%cst_6) %qubit0_out : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_4, %cst_3) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_0, %cst_3) %qubit1_out : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst) %4 : !qco.qubit -> !qco.qubit
    %qubit0_out_7, %qubit1_out_8 = qco.rzz(%cst) %15, %14 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %16 = qco.r(%cst_0, %cst_3) %qubit1_out_8 : !qco.qubit -> !qco.qubit
    %cst_9 = arith.constant -2.3561944901923448 : f64
    %17 = qco.rz(%cst_9) %16 : !qco.qubit -> !qco.qubit
    %qubit0_out_10, %qubit1_out_11 = qco.rzz(%10) %1, %17 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %18 = qco.rz(%cst_2) %qubit0_out_10 : !qco.qubit -> !qco.qubit
    %qubit0_out_12, %qubit1_out_13 = qco.rzz(%cst) %18, %12 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_14 = arith.constant -1.5707963267948963 : f64
    %19 = qco.rz(%cst_14) %qubit1_out_13 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_4, %cst_3) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_2) %qubit1_out_11 : !qco.qubit -> !qco.qubit
    %23 = arith.mulf %cst, %cst_1 : f64
    %qubit0_out_15, %qubit1_out_16 = qco.rzz(%23) %21, %22 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %24 = qco.rz(%cst_2) %qubit0_out_15 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_4) %qubit1_out_16 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_4, %cst_3) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_4) %26 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %24 : !qco.qubit
    cbit.store %result, %6[%c0] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    %qubit_out_17, %result_18 = qco.measure %27 : !qco.qubit
    qco.sink %qubit_out_17 : !qco.qubit
    cbit.store %result_18, %6[%c1] : !cbit.reg<4>
    %qubit_out_19, %result_20 = qco.measure %qubit0_out_12 : !qco.qubit
    cbit.store %result_20, %6[%c2] : !cbit.reg<4>
    qco.sink %qubit_out_19 : !qco.qubit
    %qubit_out_21, %result_22 = qco.measure %qubit0_out_7 : !qco.qubit
    qco.sink %qubit_out_21 : !qco.qubit
    cbit.store %result_22, %6[%c3] : !cbit.reg<4>
    %cst_23 = arith.constant -1.1780972450961742 : f64
    qco.gphase(%cst_23)
    return %6 : !cbit.reg<4>
  }
}
