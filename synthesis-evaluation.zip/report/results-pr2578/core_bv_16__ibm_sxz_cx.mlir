module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<15> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948966 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<15>
    %17 = qco.rz(%cst) %0 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_0) %1 : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_0) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_0) %3 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_0) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_0) %5 : !qco.qubit -> !qco.qubit
    %27 = qco.sx %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_0) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_0) %7 : !qco.qubit -> !qco.qubit
    %30 = qco.sx %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_0) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_0) %9 : !qco.qubit -> !qco.qubit
    %33 = qco.sx %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_0) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_0) %11 : !qco.qubit -> !qco.qubit
    %36 = qco.sx %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_0) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_0) %13 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_0) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_0) %15 : !qco.qubit -> !qco.qubit
    %42 = qco.sx %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_0) %42 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%22) targets (%arg0 = %19) {
      %71 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %71 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_1, %targets_out_2 = qco.ctrl(%25) targets (%arg0 = %targets_out) {
      %71 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %71 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_3, %targets_out_4 = qco.ctrl(%28) targets (%arg0 = %targets_out_2) {
      %71 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %71 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_5, %targets_out_6 = qco.ctrl(%31) targets (%arg0 = %targets_out_4) {
      %71 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %71 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_7, %targets_out_8 = qco.ctrl(%34) targets (%arg0 = %targets_out_6) {
      %71 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %71 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_9, %targets_out_10 = qco.ctrl(%37) targets (%arg0 = %targets_out_8) {
      %71 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %71 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_11, %targets_out_12 = qco.ctrl(%40) targets (%arg0 = %targets_out_10) {
      %71 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %71 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_13, %targets_out_14 = qco.ctrl(%43) targets (%arg0 = %targets_out_12) {
      %71 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %71 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = qco.rz(%cst_0) %targets_out_14 : !qco.qubit -> !qco.qubit
    %45 = qco.sx %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_0) %controls_out : !qco.qubit -> !qco.qubit
    %48 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_0) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_0) %controls_out_1 : !qco.qubit -> !qco.qubit
    %51 = qco.sx %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_0) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_0) %controls_out_3 : !qco.qubit -> !qco.qubit
    %54 = qco.sx %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_0) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_0) %controls_out_5 : !qco.qubit -> !qco.qubit
    %57 = qco.sx %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_0) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_0) %controls_out_7 : !qco.qubit -> !qco.qubit
    %60 = qco.sx %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_0) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_0) %controls_out_9 : !qco.qubit -> !qco.qubit
    %63 = qco.sx %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_0) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_0) %controls_out_11 : !qco.qubit -> !qco.qubit
    %66 = qco.sx %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_0) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_0) %controls_out_13 : !qco.qubit -> !qco.qubit
    %69 = qco.sx %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_0) %69 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %49 : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<15>
    %qubit_out_15, %result_16 = qco.measure %2 : !qco.qubit
    cbit.store %result_16, %16[%c1] : !cbit.reg<15>
    %qubit_out_17, %result_18 = qco.measure %52 : !qco.qubit
    cbit.store %result_18, %16[%c2] : !cbit.reg<15>
    %qubit_out_19, %result_20 = qco.measure %4 : !qco.qubit
    cbit.store %result_20, %16[%c3] : !cbit.reg<15>
    %qubit_out_21, %result_22 = qco.measure %55 : !qco.qubit
    cbit.store %result_22, %16[%c4] : !cbit.reg<15>
    %qubit_out_23, %result_24 = qco.measure %6 : !qco.qubit
    cbit.store %result_24, %16[%c5] : !cbit.reg<15>
    %qubit_out_25, %result_26 = qco.measure %58 : !qco.qubit
    cbit.store %result_26, %16[%c6] : !cbit.reg<15>
    %qubit_out_27, %result_28 = qco.measure %8 : !qco.qubit
    cbit.store %result_28, %16[%c7] : !cbit.reg<15>
    %qubit_out_29, %result_30 = qco.measure %61 : !qco.qubit
    cbit.store %result_30, %16[%c8] : !cbit.reg<15>
    %qubit_out_31, %result_32 = qco.measure %10 : !qco.qubit
    cbit.store %result_32, %16[%c9] : !cbit.reg<15>
    %qubit_out_33, %result_34 = qco.measure %64 : !qco.qubit
    cbit.store %result_34, %16[%c10] : !cbit.reg<15>
    %qubit_out_35, %result_36 = qco.measure %12 : !qco.qubit
    cbit.store %result_36, %16[%c11] : !cbit.reg<15>
    %qubit_out_37, %result_38 = qco.measure %67 : !qco.qubit
    cbit.store %result_38, %16[%c12] : !cbit.reg<15>
    %qubit_out_39, %result_40 = qco.measure %14 : !qco.qubit
    cbit.store %result_40, %16[%c13] : !cbit.reg<15>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_15 : !qco.qubit
    qco.sink %qubit_out_17 : !qco.qubit
    qco.sink %qubit_out_19 : !qco.qubit
    qco.sink %qubit_out_21 : !qco.qubit
    qco.sink %qubit_out_23 : !qco.qubit
    qco.sink %qubit_out_25 : !qco.qubit
    qco.sink %qubit_out_27 : !qco.qubit
    qco.sink %qubit_out_29 : !qco.qubit
    qco.sink %qubit_out_31 : !qco.qubit
    qco.sink %qubit_out_33 : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    qco.sink %qubit_out_37 : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    %qubit_out_41, %result_42 = qco.measure %70 : !qco.qubit
    qco.sink %qubit_out_41 : !qco.qubit
    cbit.store %result_42, %16[%c14] : !cbit.reg<15>
    qco.sink %46 : !qco.qubit
    return %16 : !cbit.reg<15>
  }
}
