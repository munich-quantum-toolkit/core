module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 0>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant -1.9634954084936211 : f64
    %cst_0 = arith.constant 1.178097245096172 : f64
    %cst_1 = arith.constant -0.78539816339744916 : f64
    %cst_2 = arith.constant 3.1415926535897931 : f64
    %cst_3 = arith.constant -2.3561944901923448 : f64
    %cst_4 = arith.constant -3.1415926535897931 : f64
    %cst_5 = arith.constant -2.7488935718910685 : f64
    %cst_6 = arith.constant -1.5707963267948966 : f64
    %cst_7 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %cst_8 = arith.constant -1.570796326794897 : f64
    %5 = qco.rz(%cst_8) %1 : !qco.qubit -> !qco.qubit
    %6 = qco.rx(%cst_7) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rx(%cst_2) %2 : !qco.qubit -> !qco.qubit
    %8 = qco.rx(%cst_2) %3 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_2) %0 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_0) %9 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %8, %10 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %11 = qco.rz(%cst_4) %qubit1_out : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_7) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_7) %13 : !qco.qubit -> !qco.qubit
    %qubit0_out_9, %qubit1_out_10 = qco.iswap %qubit0_out, %14 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_11 = arith.constant -0.78539816339744828 : f64
    %15 = qco.rz(%cst_11) %qubit1_out_10 : !qco.qubit -> !qco.qubit
    %cst_12 = arith.constant -1.5707963267948963 : f64
    %16 = qco.rz(%cst_12) %qubit0_out_9 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_7) %16 : !qco.qubit -> !qco.qubit
    %cst_13 = arith.constant -1.1780972450961729 : f64
    %18 = qco.rz(%cst_13) %17 : !qco.qubit -> !qco.qubit
    %qubit0_out_14, %qubit1_out_15 = qco.iswap %7, %15 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %19 = qco.rz(%cst_4) %qubit1_out_15 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_7) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_1) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst_7) %21 : !qco.qubit -> !qco.qubit
    %qubit0_out_16, %qubit1_out_17 = qco.iswap %qubit0_out_14, %22 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %23 = qco.rx(%cst_7) %qubit1_out_17 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_4) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_6) %qubit0_out_16 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_7) %25 : !qco.qubit -> !qco.qubit
    %qubit0_out_18, %qubit1_out_19 = qco.iswap %6, %24 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %27 = qco.rx(%cst_2) %qubit1_out_19 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_6) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_4) %qubit0_out_18 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_7) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_6) %30 : !qco.qubit -> !qco.qubit
    %qubit0_out_20, %qubit1_out_21 = qco.iswap %31, %28 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %32 = qco.rz(%cst_6) %qubit1_out_21 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_7) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_7) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_2) %qubit0_out_20 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_6) %35 : !qco.qubit -> !qco.qubit
    %qubit0_out_22, %qubit1_out_23 = qco.iswap %36, %26 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %37 = qco.rx(%cst_7) %qubit1_out_23 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_3) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_7) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_4) %39 : !qco.qubit -> !qco.qubit
    %qubit0_out_24, %qubit1_out_25 = qco.iswap %qubit0_out_22, %40 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %41 = qco.rx(%cst_2) %qubit1_out_25 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_4) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_7) %qubit0_out_24 : !qco.qubit -> !qco.qubit
    %44 = qco.rx(%cst_7) %43 : !qco.qubit -> !qco.qubit
    %cst_26 = arith.constant -2.3561944901923457 : f64
    %45 = qco.rz(%cst_26) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst_7) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_6) %46 : !qco.qubit -> !qco.qubit
    %qubit0_out_27, %qubit1_out_28 = qco.iswap %42, %18 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %48 = qco.rx(%cst_7) %qubit1_out_28 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_3) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_7) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_4) %50 : !qco.qubit -> !qco.qubit
    %qubit0_out_29, %qubit1_out_30 = qco.iswap %qubit0_out_27, %51 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_31 = arith.constant 2.7488935718910685 : f64
    %52 = qco.rz(%cst_31) %qubit1_out_30 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_6) %qubit0_out_29 : !qco.qubit -> !qco.qubit
    %54 = qco.rx(%cst_7) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_3) %54 : !qco.qubit -> !qco.qubit
    %qubit0_out_32, %qubit1_out_33 = qco.iswap %47, %52 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %56 = qco.rx(%cst_7) %qubit1_out_33 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_5) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_7) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_4) %58 : !qco.qubit -> !qco.qubit
    %qubit0_out_34, %qubit1_out_35 = qco.iswap %qubit0_out_32, %59 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_36 = arith.constant -1.5707963267948968 : f64
    %60 = qco.rz(%cst_36) %qubit1_out_35 : !qco.qubit -> !qco.qubit
    %61 = qco.rx(%cst_7) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_7) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_12) %qubit0_out_34 : !qco.qubit -> !qco.qubit
    %64 = qco.rx(%cst_7) %63 : !qco.qubit -> !qco.qubit
    %cst_37 = arith.constant -1.9634954084936203 : f64
    %65 = qco.rz(%cst_37) %64 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %65 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<3>
    %qubit_out_38, %result_39 = qco.measure %55 : !qco.qubit
    cbit.store %result_39, %4[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_38 : !qco.qubit
    %qubit_out_40, %result_41 = qco.measure %62 : !qco.qubit
    qco.sink %qubit_out_40 : !qco.qubit
    cbit.store %result_41, %4[%c2] : !cbit.reg<3>
    qco.sink %34 : !qco.qubit
    %cst_42 = arith.constant 1.5707963267948948 : f64
    qco.gphase(%cst_42)
    return %4 : !cbit.reg<3>
  }
}
