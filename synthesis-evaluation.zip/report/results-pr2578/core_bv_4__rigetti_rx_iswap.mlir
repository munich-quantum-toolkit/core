module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948966 : f64
    %cst_0 = arith.constant 3.1415926535897931 : f64
    %cst_1 = arith.constant -3.1415926535897931 : f64
    %cst_2 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %5 = qco.rx(%cst_2) %0 : !qco.qubit -> !qco.qubit
    %cst_3 = arith.constant -1.570796326794897 : f64
    %6 = qco.rz(%cst_3) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.rx(%cst_2) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_3) %3 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_2) %8 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %7, %5 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %10 = qco.rx(%cst_0) %qubit1_out : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_1) %qubit0_out : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_2) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst) %13 : !qco.qubit -> !qco.qubit
    %qubit0_out_4, %qubit1_out_5 = qco.iswap %14, %11 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %15 = qco.rz(%cst_1) %qubit1_out_5 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_2) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_2) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_1) %qubit0_out_4 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_2) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_2) %19 : !qco.qubit -> !qco.qubit
    %qubit0_out_6, %qubit1_out_7 = qco.iswap %9, %17 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %21 = qco.rx(%cst_0) %qubit1_out_7 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_1) %qubit0_out_6 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_2) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst) %24 : !qco.qubit -> !qco.qubit
    %qubit0_out_8, %qubit1_out_9 = qco.iswap %25, %22 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %26 = qco.rz(%cst) %qubit1_out_9 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_2) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_2) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_1) %qubit0_out_8 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_2) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_2) %30 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %20 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<3>
    %qubit_out_10, %result_11 = qco.measure %2 : !qco.qubit
    cbit.store %result_11, %4[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_10 : !qco.qubit
    %qubit_out_12, %result_13 = qco.measure %31 : !qco.qubit
    qco.sink %qubit_out_12 : !qco.qubit
    cbit.store %result_13, %4[%c2] : !cbit.reg<3>
    qco.sink %28 : !qco.qubit
    %cst_14 = arith.constant -1.7763568394002505E-15 : f64
    qco.gphase(%cst_14)
    return %4 : !cbit.reg<3>
  }
}
