module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 0>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "gpi", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = [], fixed_parameters = [3.1415926535897931, unit], canonical_name = "r">, <name = "gpi2", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = [], fixed_parameters = [1.5707963267948966, unit], canonical_name = "r">, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 1.178097245096172 : f64
    %cst_0 = arith.constant 2.3561944901923448 : f64
    %cst_1 = arith.constant -3.1415926535897931 : f64
    %cst_2 = arith.constant -1.5707963267948966 : f64
    %cst_3 = arith.constant 3.1415926535897931 : f64
    %cst_4 = arith.constant -0.78539816339744828 : f64
    %cst_5 = arith.constant -5.000000e-01 : f64
    %cst_6 = arith.constant -0.39269908169872414 : f64
    %cst_7 = arith.constant 0.000000e+00 : f64
    %cst_8 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %cst_9 = arith.constant 4.7123889803846897 : f64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %5 = qco.rz(%cst_8) %1 : !qco.qubit -> !qco.qubit
    %6 = qco.r(%cst_8, %cst_7) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_8) %2 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_8, %cst_7) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_8) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_8) %3 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_8, %cst_7) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_8) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_3, %cst_7) %0 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst) %13 : !qco.qubit -> !qco.qubit
    %15 = arith.mulf %cst_0, %cst_5 : f64
    %qubit0_out, %qubit1_out = qco.rzz(%15) %12, %14 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_10 = arith.constant 0.3926990816987237 : f64
    %16 = qco.rz(%cst_10) %qubit0_out : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_0) %qubit1_out : !qco.qubit -> !qco.qubit
    %18 = arith.mulf %cst_9, %cst_5 : f64
    %qubit0_out_11, %qubit1_out_12 = qco.rzz(%18) %9, %17 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %19 = qco.rz(%cst_8) %qubit0_out_11 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_3, %cst_7) %qubit1_out_12 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_2) %20 : !qco.qubit -> !qco.qubit
    %qubit0_out_13, %qubit1_out_14 = qco.rzz(%cst_2) %6, %21 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %22 = qco.r(%cst_3, %cst_7) %qubit1_out_14 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_1) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_8) %qubit0_out_13 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_8, %cst_7) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_8) %25 : !qco.qubit -> !qco.qubit
    %27 = arith.mulf %cst_2, %cst_5 : f64
    %qubit0_out_15, %qubit1_out_16 = qco.rzz(%27) %26, %19 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %28 = qco.rz(%cst_4) %qubit0_out_15 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_8) %qubit1_out_16 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_8, %cst_7) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_8) %30 : !qco.qubit -> !qco.qubit
    %qubit0_out_17, %qubit1_out_18 = qco.rzz(%27) %31, %16 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %32 = qco.rz(%cst_4) %qubit0_out_17 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_6) %qubit1_out_18 : !qco.qubit -> !qco.qubit
    %34 = arith.mulf %cst_4, %cst_5 : f64
    %qubit0_out_19, %qubit1_out_20 = qco.rzz(%34) %28, %33 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %35 = qco.rz(%cst_6) %qubit0_out_19 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_8) %qubit1_out_20 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%cst_8, %cst_7) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_8) %37 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %35 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<3>
    %qubit_out_21, %result_22 = qco.measure %32 : !qco.qubit
    cbit.store %result_22, %4[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_21 : !qco.qubit
    %qubit_out_23, %result_24 = qco.measure %38 : !qco.qubit
    qco.sink %qubit_out_23 : !qco.qubit
    cbit.store %result_24, %4[%c2] : !cbit.reg<3>
    qco.sink %23 : !qco.qubit
    %cst_25 = arith.constant 1.5707963267948954 : f64
    qco.gphase(%cst_25)
    return %4 : !cbit.reg<3>
  }
}
