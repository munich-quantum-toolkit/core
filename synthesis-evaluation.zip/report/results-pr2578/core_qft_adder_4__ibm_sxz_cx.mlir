module attributes {mqt.layout = {initial = array<i64: 1, 0, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948963 : f64
    %cst_0 = arith.constant -0.78539816339744828 : f64
    %cst_1 = arith.constant 0.78539816339744828 : f64
    %cst_2 = arith.constant 1.5707963267948966 : f64
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.x %0 : !qco.qubit -> !qco.qubit
    %5 = qco.x %2 : !qco.qubit -> !qco.qubit
    %6 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %7 = qco.rz(%cst_2) %3 : !qco.qubit -> !qco.qubit
    %8 = qco.sx %7 : !qco.qubit -> !qco.qubit
    %cst_3 = arith.constant 2.3561944901923448 : f64
    %9 = qco.rz(%cst_3) %8 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%5) targets (%arg0 = %9) {
      %28 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %28 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %10 = qco.rz(%cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_4, %targets_out_5 = qco.ctrl(%controls_out) targets (%arg0 = %10) {
      %28 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %28 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qco.x %controls_out_4 : !qco.qubit -> !qco.qubit
    %cst_6 = arith.constant -0.78539816339744872 : f64
    %12 = qco.rz(%cst_6) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst) %targets_out_5 : !qco.qubit -> !qco.qubit
    %14 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_2) %14 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%4) targets (%arg0 = %15) {
      %28 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %28 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.rz(%cst_2) %targets_out_8 : !qco.qubit -> !qco.qubit
    %17 = qco.sx %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_0) %17 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%1) targets (%arg0 = %18) {
      %28 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %28 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.rz(%cst_0) %targets_out_10 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%controls_out_9) targets (%arg0 = %19) {
      %28 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %28 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.rz(%cst_1) %controls_out_11 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%20) targets (%arg0 = %12) {
      %28 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %28 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.x %targets_out_14 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_0) %targets_out_12 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%21) targets (%arg0 = %22) {
      %28 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %28 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qco.rz(%cst_1) %targets_out_16 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%controls_out_15) targets (%arg0 = %23) {
      %28 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %28 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.rz(%cst_0) %controls_out_17 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_2) %targets_out_18 : !qco.qubit -> !qco.qubit
    %26 = qco.sx %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_2) %26 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %24 : !qco.qubit
    cbit.store %result, %6[%c0] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    %qubit_out_19, %result_20 = qco.measure %27 : !qco.qubit
    qco.sink %qubit_out_19 : !qco.qubit
    cbit.store %result_20, %6[%c1] : !cbit.reg<4>
    %qubit_out_21, %result_22 = qco.measure %controls_out_13 : !qco.qubit
    cbit.store %result_22, %6[%c2] : !cbit.reg<4>
    qco.sink %qubit_out_21 : !qco.qubit
    %qubit_out_23, %result_24 = qco.measure %controls_out_7 : !qco.qubit
    qco.sink %qubit_out_23 : !qco.qubit
    cbit.store %result_24, %6[%c3] : !cbit.reg<4>
    %cst_25 = arith.constant 0.39269908169872414 : f64
    qco.gphase(%cst_25)
    return %6 : !cbit.reg<4>
  }
}
