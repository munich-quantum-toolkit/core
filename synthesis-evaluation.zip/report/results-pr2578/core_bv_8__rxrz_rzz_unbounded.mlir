module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948966 : f64
    %cst_0 = arith.constant -3.1415926535897931 : f64
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %9 = qco.rz(%cst) %0 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_1) %1 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_1) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_1) %3 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_1) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_1) %5 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_1) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_1) %7 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_1) %16 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst) %11, %9 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %18 = qco.rz(%cst_1) %qubit1_out : !qco.qubit -> !qco.qubit
    %qubit0_out_2, %qubit1_out_3 = qco.rzz(%cst) %13, %18 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %19 = qco.rz(%cst_1) %qubit1_out_3 : !qco.qubit -> !qco.qubit
    %qubit0_out_4, %qubit1_out_5 = qco.rzz(%cst) %15, %19 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %20 = qco.rz(%cst_1) %qubit1_out_5 : !qco.qubit -> !qco.qubit
    %qubit0_out_6, %qubit1_out_7 = qco.rzz(%cst) %17, %20 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %21 = qco.rz(%cst) %qubit1_out_7 : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst_0) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_1) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_1) %qubit0_out : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_1) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_1) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_1) %qubit0_out_2 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_1) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_1) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_1) %qubit0_out_4 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_1) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_1) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_1) %qubit0_out_6 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_1) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_1) %34 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %26 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<7>
    %qubit_out_8, %result_9 = qco.measure %2 : !qco.qubit
    cbit.store %result_9, %8[%c1] : !cbit.reg<7>
    %qubit_out_10, %result_11 = qco.measure %29 : !qco.qubit
    cbit.store %result_11, %8[%c2] : !cbit.reg<7>
    %qubit_out_12, %result_13 = qco.measure %4 : !qco.qubit
    cbit.store %result_13, %8[%c3] : !cbit.reg<7>
    %qubit_out_14, %result_15 = qco.measure %32 : !qco.qubit
    cbit.store %result_15, %8[%c4] : !cbit.reg<7>
    %qubit_out_16, %result_17 = qco.measure %6 : !qco.qubit
    cbit.store %result_17, %8[%c5] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_8 : !qco.qubit
    qco.sink %qubit_out_10 : !qco.qubit
    qco.sink %qubit_out_12 : !qco.qubit
    qco.sink %qubit_out_14 : !qco.qubit
    qco.sink %qubit_out_16 : !qco.qubit
    %qubit_out_18, %result_19 = qco.measure %35 : !qco.qubit
    qco.sink %qubit_out_18 : !qco.qubit
    cbit.store %result_19, %8[%c6] : !cbit.reg<7>
    qco.sink %23 : !qco.qubit
    %cst_20 = arith.constant -1.5707963267949001 : f64
    qco.gphase(%cst_20)
    return %8 : !cbit.reg<7>
  }
}
