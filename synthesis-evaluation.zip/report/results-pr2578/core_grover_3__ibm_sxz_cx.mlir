module attributes {mqt.layout = {initial = array<i64: 0, 1, 2>, input_count = 3 : i64, sites = array<i64: 0, 1, 2>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 0.78539816339744828 : f64
    %cst_0 = arith.constant 2.3561944901923448 : f64
    %cst_1 = arith.constant -0.78539816339744828 : f64
    %cst_2 = arith.constant -1.5707963267948966 : f64
    %cst_3 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %4 = qco.rz(%cst_3) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.sx %4 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_3) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_2) %1 : !qco.qubit -> !qco.qubit
    %8 = qco.sx %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_3) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_3) %2 : !qco.qubit -> !qco.qubit
    %11 = qco.sx %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_3) %11 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%9) targets (%arg0 = %12) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %13 = qco.rz(%cst_1) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_4, %targets_out_5 = qco.ctrl(%6) targets (%arg0 = %13) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.rz(%cst) %targets_out_5 : !qco.qubit -> !qco.qubit
    %controls_out_6, %targets_out_7 = qco.ctrl(%controls_out) targets (%arg0 = %14) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qco.rz(%cst_1) %targets_out_7 : !qco.qubit -> !qco.qubit
    %controls_out_8, %targets_out_9 = qco.ctrl(%controls_out_4) targets (%arg0 = %15) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.rz(%cst) %controls_out_6 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_1) %targets_out_9 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_3) %18 : !qco.qubit -> !qco.qubit
    %controls_out_10, %targets_out_11 = qco.ctrl(%controls_out_8) targets (%arg0 = %16) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.rz(%cst) %controls_out_10 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_1) %targets_out_11 : !qco.qubit -> !qco.qubit
    %controls_out_12, %targets_out_13 = qco.ctrl(%20) targets (%arg0 = %21) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.rz(%cst_2) %targets_out_13 : !qco.qubit -> !qco.qubit
    %23 = qco.sx %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_2) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_2) %controls_out_12 : !qco.qubit -> !qco.qubit
    %26 = qco.sx %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_3) %26 : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%24) targets (%arg0 = %19) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qco.rz(%cst_1) %targets_out_15 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%27) targets (%arg0 = %28) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.rz(%cst) %targets_out_17 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%controls_out_14) targets (%arg0 = %29) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.rz(%cst_1) %targets_out_19 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%controls_out_16) targets (%arg0 = %30) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.rz(%cst) %controls_out_18 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_0) %targets_out_21 : !qco.qubit -> !qco.qubit
    %33 = qco.sx %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_2) %33 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%controls_out_20) targets (%arg0 = %31) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.rz(%cst) %controls_out_22 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_1) %targets_out_23 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%35) targets (%arg0 = %36) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.rz(%cst_3) %controls_out_24 : !qco.qubit -> !qco.qubit
    %38 = qco.sx %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_2) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_2) %targets_out_25 : !qco.qubit -> !qco.qubit
    %41 = qco.sx %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_2) %41 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%42) targets (%arg0 = %34) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qco.rz(%cst_1) %targets_out_27 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%39) targets (%arg0 = %43) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = qco.rz(%cst) %targets_out_29 : !qco.qubit -> !qco.qubit
    %controls_out_30, %targets_out_31 = qco.ctrl(%controls_out_26) targets (%arg0 = %44) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.rz(%cst_1) %targets_out_31 : !qco.qubit -> !qco.qubit
    %controls_out_32, %targets_out_33 = qco.ctrl(%controls_out_28) targets (%arg0 = %45) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qco.rz(%cst) %controls_out_30 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_1) %targets_out_33 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_3) %48 : !qco.qubit -> !qco.qubit
    %controls_out_34, %targets_out_35 = qco.ctrl(%controls_out_32) targets (%arg0 = %46) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qco.rz(%cst) %controls_out_34 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_1) %targets_out_35 : !qco.qubit -> !qco.qubit
    %controls_out_36, %targets_out_37 = qco.ctrl(%50) targets (%arg0 = %51) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qco.rz(%cst_2) %targets_out_37 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_2) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_2) %controls_out_36 : !qco.qubit -> !qco.qubit
    %56 = qco.sx %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_3) %56 : !qco.qubit -> !qco.qubit
    %controls_out_38, %targets_out_39 = qco.ctrl(%54) targets (%arg0 = %49) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = qco.rz(%cst_1) %targets_out_39 : !qco.qubit -> !qco.qubit
    %controls_out_40, %targets_out_41 = qco.ctrl(%57) targets (%arg0 = %58) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qco.rz(%cst) %targets_out_41 : !qco.qubit -> !qco.qubit
    %controls_out_42, %targets_out_43 = qco.ctrl(%controls_out_38) targets (%arg0 = %59) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qco.rz(%cst_1) %targets_out_43 : !qco.qubit -> !qco.qubit
    %controls_out_44, %targets_out_45 = qco.ctrl(%controls_out_40) targets (%arg0 = %60) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qco.rz(%cst) %controls_out_42 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_0) %targets_out_45 : !qco.qubit -> !qco.qubit
    %63 = qco.sx %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_2) %63 : !qco.qubit -> !qco.qubit
    %controls_out_46, %targets_out_47 = qco.ctrl(%controls_out_44) targets (%arg0 = %61) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qco.rz(%cst) %controls_out_46 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_1) %targets_out_47 : !qco.qubit -> !qco.qubit
    %controls_out_48, %targets_out_49 = qco.ctrl(%65) targets (%arg0 = %66) {
      %73 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %73 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %67 = qco.rz(%cst_3) %controls_out_48 : !qco.qubit -> !qco.qubit
    %68 = qco.sx %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_2) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_3) %targets_out_49 : !qco.qubit -> !qco.qubit
    %71 = qco.sx %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_2) %71 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %69 : !qco.qubit
    cbit.store %result, %3[%c0] : !cbit.reg<3>
    %qubit_out_50, %result_51 = qco.measure %72 : !qco.qubit
    cbit.store %result_51, %3[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_50 : !qco.qubit
    %qubit_out_52, %result_53 = qco.measure %64 : !qco.qubit
    qco.sink %qubit_out_52 : !qco.qubit
    cbit.store %result_53, %3[%c2] : !cbit.reg<3>
    %cst_54 = arith.constant -2.3561944901923448 : f64
    qco.gphase(%cst_54)
    return %3 : !cbit.reg<3>
  }
}
