module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 0>, input_count = 7 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant -0.78539816339744828 : f64
    %cst_0 = arith.constant -0.39269908169872414 : f64
    %cst_1 = arith.constant -0.19634954084936229 : f64
    %cst_2 = arith.constant -0.098174770424681145 : f64
    %cst_3 = arith.constant -0.049087385212340351 : f64
    %cst_4 = arith.constant 1.5707963267948966 : f64
    %cst_5 = arith.constant -0.024543692606170175 : f64
    %cst_6 = arith.constant -3.1415926535897931 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %8 = qco.rz(%cst_4) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.sx %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_4) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_4) %2 : !qco.qubit -> !qco.qubit
    %12 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_4) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_4) %3 : !qco.qubit -> !qco.qubit
    %15 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_4) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_4) %4 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_4) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_4) %5 : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_4) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_4) %6 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_4) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.sx %0 : !qco.qubit -> !qco.qubit
    %cst_7 = arith.constant 0.78539816339744828 : f64
    %27 = qco.rz(%cst_7) %26 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%25) targets (%arg0 = %27) {
      %42 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %42 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qco.rz(%cst) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_8, %targets_out_9 = qco.ctrl(%controls_out) targets (%arg0 = %28) {
      %42 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %42 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_10 = arith.constant 0.39269908169872458 : f64
    %29 = qco.rz(%cst_10) %targets_out_9 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%22) targets (%arg0 = %29) {
      %42 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %42 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.rz(%cst_0) %targets_out_12 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%controls_out_11) targets (%arg0 = %30) {
      %42 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %42 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_15 = arith.constant 0.19634954084936229 : f64
    %31 = qco.rz(%cst_15) %targets_out_14 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%19) targets (%arg0 = %31) {
      %42 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %42 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qco.rz(%cst_1) %targets_out_17 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%controls_out_16) targets (%arg0 = %32) {
      %42 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %42 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_20 = arith.constant 0.098174770424680701 : f64
    %33 = qco.rz(%cst_20) %targets_out_19 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%16) targets (%arg0 = %33) {
      %42 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %42 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.rz(%cst_2) %targets_out_22 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%controls_out_21) targets (%arg0 = %34) {
      %42 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %42 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_25 = arith.constant 0.049087385212340351 : f64
    %35 = qco.rz(%cst_25) %targets_out_24 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%13) targets (%arg0 = %35) {
      %42 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %42 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qco.rz(%cst_3) %targets_out_27 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%controls_out_26) targets (%arg0 = %36) {
      %42 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %42 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_30 = arith.constant 0.024543692606170175 : f64
    %37 = qco.rz(%cst_30) %targets_out_29 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%10) targets (%arg0 = %37) {
      %42 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %42 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qco.rz(%cst_5) %targets_out_32 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%controls_out_31) targets (%arg0 = %38) {
      %42 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %42 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.rz(%cst_6) %targets_out_34 : !qco.qubit -> !qco.qubit
    %40 = qco.sx %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_6) %40 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %41 : !qco.qubit
    cbit.store %result, %7[%c0] : !cbit.reg<7>
    %qubit_out_35, %result_36 = qco.measure %controls_out_33 : !qco.qubit
    cbit.store %result_36, %7[%c1] : !cbit.reg<7>
    %qubit_out_37, %result_38 = qco.measure %controls_out_28 : !qco.qubit
    cbit.store %result_38, %7[%c2] : !cbit.reg<7>
    %qubit_out_39, %result_40 = qco.measure %controls_out_23 : !qco.qubit
    cbit.store %result_40, %7[%c3] : !cbit.reg<7>
    %qubit_out_41, %result_42 = qco.measure %controls_out_18 : !qco.qubit
    cbit.store %result_42, %7[%c4] : !cbit.reg<7>
    %qubit_out_43, %result_44 = qco.measure %controls_out_13 : !qco.qubit
    cbit.store %result_44, %7[%c5] : !cbit.reg<7>
    qco.sink %qubit_out_35 : !qco.qubit
    qco.sink %qubit_out_37 : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    qco.sink %qubit_out_41 : !qco.qubit
    qco.sink %qubit_out_43 : !qco.qubit
    %qubit_out_45, %result_46 = qco.measure %controls_out_8 : !qco.qubit
    qco.sink %qubit_out_45 : !qco.qubit
    cbit.store %result_46, %7[%c6] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    return %7 : !cbit.reg<7>
  }
}
