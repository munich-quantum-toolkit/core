module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 0>, input_count = 7 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant 1.5707963267948968 : f64
    %cst_0 = arith.constant 4.7123889803846897 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %cst_2 = arith.constant 0.78539816339744828 : f64
    %cst_3 = arith.constant 0.024543692606170175 : f64
    %cst_4 = arith.constant 0.049087385212340358 : f64
    %cst_5 = arith.constant 0.098174770424681145 : f64
    %cst_6 = arith.constant 0.19634954084936229 : f64
    %cst_7 = arith.constant 0.39269908169872414 : f64
    %cst_8 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %8 = qco.r(%cst_8, %cst_1) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_8, %cst_1) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_8, %cst_1) %3 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_8, %cst_1) %4 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_8, %cst_1) %5 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_8, %cst_1) %6 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_2, %cst_8) %0 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%13) targets (%arg0 = %14) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qco.r(%cst_2, %cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%controls_out) targets (%arg0 = %15) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.r(%cst_7, %cst) %targets_out_10 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%12) targets (%arg0 = %16) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.r(%cst_7, %cst_0) %targets_out_12 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%controls_out_11) targets (%arg0 = %17) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qco.r(%cst_6, %cst) %targets_out_14 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%11) targets (%arg0 = %18) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.r(%cst_6, %cst_0) %targets_out_16 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%controls_out_15) targets (%arg0 = %19) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.r(%cst_5, %cst_8) %targets_out_18 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%10) targets (%arg0 = %20) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.r(%cst_5, %cst_0) %targets_out_20 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%controls_out_19) targets (%arg0 = %21) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.r(%cst_4, %cst_8) %targets_out_22 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%9) targets (%arg0 = %22) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qco.r(%cst_4, %cst_0) %targets_out_24 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%controls_out_23) targets (%arg0 = %23) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.r(%cst_3, %cst) %targets_out_26 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%8) targets (%arg0 = %24) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %25 = qco.r(%cst_3, %cst_0) %targets_out_28 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%controls_out_27) targets (%arg0 = %25) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %qubit_out, %result = qco.measure %targets_out_30 : !qco.qubit
    cbit.store %result, %7[%c0] : !cbit.reg<7>
    %qubit_out_31, %result_32 = qco.measure %controls_out_29 : !qco.qubit
    cbit.store %result_32, %7[%c1] : !cbit.reg<7>
    %qubit_out_33, %result_34 = qco.measure %controls_out_25 : !qco.qubit
    cbit.store %result_34, %7[%c2] : !cbit.reg<7>
    %qubit_out_35, %result_36 = qco.measure %controls_out_21 : !qco.qubit
    cbit.store %result_36, %7[%c3] : !cbit.reg<7>
    %qubit_out_37, %result_38 = qco.measure %controls_out_17 : !qco.qubit
    cbit.store %result_38, %7[%c4] : !cbit.reg<7>
    %qubit_out_39, %result_40 = qco.measure %controls_out_13 : !qco.qubit
    cbit.store %result_40, %7[%c5] : !cbit.reg<7>
    qco.sink %qubit_out_31 : !qco.qubit
    qco.sink %qubit_out_33 : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    qco.sink %qubit_out_37 : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    %qubit_out_41, %result_42 = qco.measure %controls_out_9 : !qco.qubit
    qco.sink %qubit_out_41 : !qco.qubit
    cbit.store %result_42, %7[%c6] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    %cst_43 = arith.constant 3.1415926535897931 : f64
    qco.gphase(%cst_43)
    return %7 : !cbit.reg<7>
  }
}
