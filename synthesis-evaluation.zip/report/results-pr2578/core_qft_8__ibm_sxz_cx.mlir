module attributes {mqt.layout = {initial = array<i64: 7, 6, 5, 4, 0, 1, 2, 3>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant -0.012271846303085088 : f64
    %cst_0 = arith.constant 0.012271846303085088 : f64
    %cst_1 = arith.constant -0.024543692606170175 : f64
    %cst_2 = arith.constant 0.024543692606170175 : f64
    %cst_3 = arith.constant -0.049087385212340351 : f64
    %cst_4 = arith.constant 0.049087385212340351 : f64
    %cst_5 = arith.constant -0.098174770424681145 : f64
    %cst_6 = arith.constant 0.098174770424681145 : f64
    %cst_7 = arith.constant -0.19634954084936229 : f64
    %cst_8 = arith.constant 0.19634954084936229 : f64
    %cst_9 = arith.constant -0.39269908169872414 : f64
    %cst_10 = arith.constant 0.39269908169872414 : f64
    %cst_11 = arith.constant -0.78539816339744828 : f64
    %cst_12 = arith.constant 0.78539816339744828 : f64
    %cst_13 = arith.constant 1.5707963267948966 : f64
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %9 = qco.rz(%cst_13) %0 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_13) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_13) %1 : !qco.qubit -> !qco.qubit
    %13 = qco.sx %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_13) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_13) %2 : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_13) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_12) %3 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%17) targets (%arg0 = %18) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.rz(%cst_11) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%controls_out) targets (%arg0 = %19) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_16 = arith.constant 2.3561944901923448 : f64
    %20 = qco.rz(%cst_16) %controls_out_14 : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_16) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_10) %targets_out_15 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%14) targets (%arg0 = %23) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.rz(%cst_9) %targets_out_18 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%controls_out_17) targets (%arg0 = %24) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %25 = qco.rz(%cst_10) %controls_out_19 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_8) %targets_out_20 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%11) targets (%arg0 = %26) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %27 = qco.rz(%cst_7) %targets_out_22 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%controls_out_21) targets (%arg0 = %27) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qco.rz(%cst_8) %controls_out_23 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_6) %targets_out_24 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%4) targets (%arg0 = %29) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.rz(%cst_5) %targets_out_26 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%controls_out_25) targets (%arg0 = %30) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.rz(%cst_6) %controls_out_27 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_4) %targets_out_28 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%5) targets (%arg0 = %32) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %33 = qco.rz(%cst_3) %targets_out_30 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%controls_out_29) targets (%arg0 = %33) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.rz(%cst_4) %controls_out_31 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_2) %targets_out_32 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%6) targets (%arg0 = %35) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qco.rz(%cst_1) %targets_out_34 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%controls_out_33) targets (%arg0 = %36) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.rz(%cst_2) %controls_out_35 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_0) %targets_out_36 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%7) targets (%arg0 = %38) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.rz(%cst) %targets_out_38 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%controls_out_37) targets (%arg0 = %39) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %40 = qco.rz(%cst_0) %controls_out_39 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%25) targets (%arg0 = %22) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.rz(%cst_11) %targets_out_42 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%controls_out_41) targets (%arg0 = %41) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qco.rz(%cst_16) %controls_out_43 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_16) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_10) %targets_out_44 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%28) targets (%arg0 = %45) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qco.rz(%cst_9) %targets_out_46 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%controls_out_45) targets (%arg0 = %46) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.rz(%cst_10) %controls_out_47 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_8) %targets_out_48 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%31) targets (%arg0 = %48) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qco.rz(%cst_7) %targets_out_50 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%controls_out_49) targets (%arg0 = %49) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qco.rz(%cst_8) %controls_out_51 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_6) %targets_out_52 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%34) targets (%arg0 = %51) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qco.rz(%cst_5) %targets_out_54 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%controls_out_53) targets (%arg0 = %52) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qco.rz(%cst_6) %controls_out_55 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_4) %targets_out_56 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%37) targets (%arg0 = %54) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.rz(%cst_3) %targets_out_58 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%controls_out_57) targets (%arg0 = %55) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qco.rz(%cst_4) %controls_out_59 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_2) %targets_out_60 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%40) targets (%arg0 = %57) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = qco.rz(%cst_1) %targets_out_62 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%controls_out_61) targets (%arg0 = %58) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qco.rz(%cst_2) %controls_out_63 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%47) targets (%arg0 = %44) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qco.rz(%cst_11) %targets_out_66 : !qco.qubit -> !qco.qubit
    %controls_out_67, %targets_out_68 = qco.ctrl(%controls_out_65) targets (%arg0 = %60) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qco.rz(%cst_16) %controls_out_67 : !qco.qubit -> !qco.qubit
    %62 = qco.sx %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_16) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_10) %targets_out_68 : !qco.qubit -> !qco.qubit
    %controls_out_69, %targets_out_70 = qco.ctrl(%50) targets (%arg0 = %64) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qco.rz(%cst_9) %targets_out_70 : !qco.qubit -> !qco.qubit
    %controls_out_71, %targets_out_72 = qco.ctrl(%controls_out_69) targets (%arg0 = %65) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = qco.rz(%cst_10) %controls_out_71 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_8) %targets_out_72 : !qco.qubit -> !qco.qubit
    %controls_out_73, %targets_out_74 = qco.ctrl(%53) targets (%arg0 = %67) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %68 = qco.rz(%cst_7) %targets_out_74 : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%controls_out_73) targets (%arg0 = %68) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qco.rz(%cst_8) %controls_out_75 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_6) %targets_out_76 : !qco.qubit -> !qco.qubit
    %controls_out_77, %targets_out_78 = qco.ctrl(%56) targets (%arg0 = %70) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qco.rz(%cst_5) %targets_out_78 : !qco.qubit -> !qco.qubit
    %controls_out_79, %targets_out_80 = qco.ctrl(%controls_out_77) targets (%arg0 = %71) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %72 = qco.rz(%cst_6) %controls_out_79 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_4) %targets_out_80 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%59) targets (%arg0 = %73) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %74 = qco.rz(%cst_3) %targets_out_82 : !qco.qubit -> !qco.qubit
    %controls_out_83, %targets_out_84 = qco.ctrl(%controls_out_81) targets (%arg0 = %74) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %75 = qco.rz(%cst_4) %controls_out_83 : !qco.qubit -> !qco.qubit
    %controls_out_85, %targets_out_86 = qco.ctrl(%66) targets (%arg0 = %63) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %76 = qco.rz(%cst_11) %targets_out_86 : !qco.qubit -> !qco.qubit
    %controls_out_87, %targets_out_88 = qco.ctrl(%controls_out_85) targets (%arg0 = %76) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qco.rz(%cst_16) %controls_out_87 : !qco.qubit -> !qco.qubit
    %78 = qco.sx %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_16) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_10) %targets_out_88 : !qco.qubit -> !qco.qubit
    %controls_out_89, %targets_out_90 = qco.ctrl(%69) targets (%arg0 = %80) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %81 = qco.rz(%cst_9) %targets_out_90 : !qco.qubit -> !qco.qubit
    %controls_out_91, %targets_out_92 = qco.ctrl(%controls_out_89) targets (%arg0 = %81) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %82 = qco.rz(%cst_10) %controls_out_91 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_8) %targets_out_92 : !qco.qubit -> !qco.qubit
    %controls_out_93, %targets_out_94 = qco.ctrl(%72) targets (%arg0 = %83) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %84 = qco.rz(%cst_7) %targets_out_94 : !qco.qubit -> !qco.qubit
    %controls_out_95, %targets_out_96 = qco.ctrl(%controls_out_93) targets (%arg0 = %84) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %85 = qco.rz(%cst_8) %controls_out_95 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_6) %targets_out_96 : !qco.qubit -> !qco.qubit
    %controls_out_97, %targets_out_98 = qco.ctrl(%75) targets (%arg0 = %86) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %87 = qco.rz(%cst_5) %targets_out_98 : !qco.qubit -> !qco.qubit
    %controls_out_99, %targets_out_100 = qco.ctrl(%controls_out_97) targets (%arg0 = %87) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %88 = qco.rz(%cst_6) %controls_out_99 : !qco.qubit -> !qco.qubit
    %controls_out_101, %targets_out_102 = qco.ctrl(%82) targets (%arg0 = %79) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %89 = qco.rz(%cst_11) %targets_out_102 : !qco.qubit -> !qco.qubit
    %controls_out_103, %targets_out_104 = qco.ctrl(%controls_out_101) targets (%arg0 = %89) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %90 = qco.rz(%cst_16) %controls_out_103 : !qco.qubit -> !qco.qubit
    %91 = qco.sx %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_16) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_10) %targets_out_104 : !qco.qubit -> !qco.qubit
    %controls_out_105, %targets_out_106 = qco.ctrl(%85) targets (%arg0 = %93) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %94 = qco.rz(%cst_9) %targets_out_106 : !qco.qubit -> !qco.qubit
    %controls_out_107, %targets_out_108 = qco.ctrl(%controls_out_105) targets (%arg0 = %94) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %95 = qco.rz(%cst_10) %controls_out_107 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_8) %targets_out_108 : !qco.qubit -> !qco.qubit
    %controls_out_109, %targets_out_110 = qco.ctrl(%88) targets (%arg0 = %96) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %97 = qco.rz(%cst_7) %targets_out_110 : !qco.qubit -> !qco.qubit
    %controls_out_111, %targets_out_112 = qco.ctrl(%controls_out_109) targets (%arg0 = %97) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %98 = qco.rz(%cst_8) %controls_out_111 : !qco.qubit -> !qco.qubit
    %controls_out_113, %targets_out_114 = qco.ctrl(%95) targets (%arg0 = %92) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %99 = qco.rz(%cst_11) %targets_out_114 : !qco.qubit -> !qco.qubit
    %controls_out_115, %targets_out_116 = qco.ctrl(%controls_out_113) targets (%arg0 = %99) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %100 = qco.rz(%cst_16) %controls_out_115 : !qco.qubit -> !qco.qubit
    %101 = qco.sx %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_16) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst_10) %targets_out_116 : !qco.qubit -> !qco.qubit
    %controls_out_117, %targets_out_118 = qco.ctrl(%98) targets (%arg0 = %103) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %104 = qco.rz(%cst_9) %targets_out_118 : !qco.qubit -> !qco.qubit
    %controls_out_119, %targets_out_120 = qco.ctrl(%controls_out_117) targets (%arg0 = %104) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %105 = qco.rz(%cst_10) %controls_out_119 : !qco.qubit -> !qco.qubit
    %controls_out_121, %targets_out_122 = qco.ctrl(%105) targets (%arg0 = %102) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %106 = qco.rz(%cst_11) %targets_out_122 : !qco.qubit -> !qco.qubit
    %controls_out_123, %targets_out_124 = qco.ctrl(%controls_out_121) targets (%arg0 = %106) {
      %110 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %107 = qco.rz(%cst_16) %controls_out_123 : !qco.qubit -> !qco.qubit
    %108 = qco.sx %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rz(%cst_13) %108 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %109 : !qco.qubit
    cbit.store %result, %8[%c7] : !cbit.reg<8>
    %qubit_out_125, %result_126 = qco.measure %targets_out_124 : !qco.qubit
    cbit.store %result_126, %8[%c6] : !cbit.reg<8>
    %qubit_out_127, %result_128 = qco.measure %targets_out_120 : !qco.qubit
    cbit.store %result_128, %8[%c5] : !cbit.reg<8>
    %qubit_out_129, %result_130 = qco.measure %targets_out_112 : !qco.qubit
    cbit.store %result_130, %8[%c4] : !cbit.reg<8>
    %qubit_out_131, %result_132 = qco.measure %targets_out_100 : !qco.qubit
    cbit.store %result_132, %8[%c3] : !cbit.reg<8>
    %qubit_out_133, %result_134 = qco.measure %targets_out_84 : !qco.qubit
    cbit.store %result_134, %8[%c2] : !cbit.reg<8>
    %qubit_out_135, %result_136 = qco.measure %targets_out_64 : !qco.qubit
    cbit.store %result_136, %8[%c1] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_125 : !qco.qubit
    qco.sink %qubit_out_127 : !qco.qubit
    qco.sink %qubit_out_129 : !qco.qubit
    qco.sink %qubit_out_131 : !qco.qubit
    qco.sink %qubit_out_133 : !qco.qubit
    qco.sink %qubit_out_135 : !qco.qubit
    %qubit_out_137, %result_138 = qco.measure %targets_out_40 : !qco.qubit
    qco.sink %qubit_out_137 : !qco.qubit
    cbit.store %result_138, %8[%c0] : !cbit.reg<8>
    %cst_139 = arith.constant 0.0061359231515418777 : f64
    qco.gphase(%cst_139)
    return %8 : !cbit.reg<8>
  }
}
