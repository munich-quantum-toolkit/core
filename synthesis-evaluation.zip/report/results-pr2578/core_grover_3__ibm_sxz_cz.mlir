module attributes {mqt.layout = {initial = array<i64: 0, 1, 2>, input_count = 3 : i64, sites = array<i64: 0, 1, 2>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 0.78539816339744828 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %4 = qco.rz(%cst_1) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.sx %4 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_1) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_0) %1 : !qco.qubit -> !qco.qubit
    %8 = qco.sx %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_1) %8 : !qco.qubit -> !qco.qubit
    %cst_2 = arith.constant -3.1415926535897931 : f64
    %10 = qco.rz(%cst_2) %2 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%9) targets (%arg0 = %10) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qco.rz(%cst_1) %targets_out : !qco.qubit -> !qco.qubit
    %12 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %cst_3 = arith.constant -2.3561944901923439 : f64
    %13 = qco.rz(%cst_3) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_1) %14 : !qco.qubit -> !qco.qubit
    %controls_out_4, %targets_out_5 = qco.ctrl(%6) targets (%arg0 = %15) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_6 = arith.constant -1.5707963267948963 : f64
    %16 = qco.rz(%cst_6) %targets_out_5 : !qco.qubit -> !qco.qubit
    %17 = qco.sx %16 : !qco.qubit -> !qco.qubit
    %cst_7 = arith.constant -2.3561944901923457 : f64
    %18 = qco.rz(%cst_7) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.sx %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_0) %19 : !qco.qubit -> !qco.qubit
    %controls_out_8, %targets_out_9 = qco.ctrl(%controls_out) targets (%arg0 = %20) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.rz(%cst_1) %targets_out_9 : !qco.qubit -> !qco.qubit
    %22 = qco.sx %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_3) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_1) %24 : !qco.qubit -> !qco.qubit
    %controls_out_10, %targets_out_11 = qco.ctrl(%controls_out_4) targets (%arg0 = %25) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_12 = arith.constant -1.5707963267948961 : f64
    %26 = qco.rz(%cst_12) %targets_out_11 : !qco.qubit -> !qco.qubit
    %27 = qco.sx %26 : !qco.qubit -> !qco.qubit
    %cst_13 = arith.constant 2.3561944901923457 : f64
    %28 = qco.rz(%cst_13) %27 : !qco.qubit -> !qco.qubit
    %cst_14 = arith.constant 2.3561944901923448 : f64
    %29 = qco.rz(%cst_14) %controls_out_8 : !qco.qubit -> !qco.qubit
    %30 = qco.sx %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_0) %30 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%controls_out_10) targets (%arg0 = %31) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qco.rz(%cst_1) %targets_out_16 : !qco.qubit -> !qco.qubit
    %33 = qco.sx %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_3) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.sx %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_1) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst) %controls_out_15 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%37) targets (%arg0 = %36) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qco.x %targets_out_18 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_0) %controls_out_17 : !qco.qubit -> !qco.qubit
    %40 = qco.sx %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_1) %40 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%38) targets (%arg0 = %28) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qco.rz(%cst_1) %targets_out_20 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_3) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.sx %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_1) %45 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%41) targets (%arg0 = %46) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.rz(%cst_6) %targets_out_22 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_7) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.sx %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_0) %50 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%controls_out_19) targets (%arg0 = %51) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qco.rz(%cst_1) %targets_out_24 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_3) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.sx %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_1) %55 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%controls_out_21) targets (%arg0 = %56) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %57 = qco.rz(%cst_1) %targets_out_26 : !qco.qubit -> !qco.qubit
    %58 = qco.sx %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_3) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_14) %controls_out_23 : !qco.qubit -> !qco.qubit
    %61 = qco.sx %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_0) %61 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%controls_out_25) targets (%arg0 = %62) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %63 = qco.rz(%cst_1) %targets_out_28 : !qco.qubit -> !qco.qubit
    %64 = qco.sx %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_3) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.sx %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_1) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst) %controls_out_27 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%68) targets (%arg0 = %67) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qco.x %targets_out_30 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_1) %controls_out_29 : !qco.qubit -> !qco.qubit
    %71 = qco.sx %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_0) %71 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%69) targets (%arg0 = %59) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %73 = qco.rz(%cst_1) %targets_out_32 : !qco.qubit -> !qco.qubit
    %74 = qco.sx %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_3) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.sx %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_1) %76 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%72) targets (%arg0 = %77) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %78 = qco.rz(%cst_6) %targets_out_34 : !qco.qubit -> !qco.qubit
    %79 = qco.sx %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_7) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.sx %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_0) %81 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%controls_out_31) targets (%arg0 = %82) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qco.rz(%cst_1) %targets_out_36 : !qco.qubit -> !qco.qubit
    %84 = qco.sx %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_3) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.sx %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_1) %86 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%controls_out_33) targets (%arg0 = %87) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %88 = qco.rz(%cst_12) %targets_out_38 : !qco.qubit -> !qco.qubit
    %89 = qco.sx %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_13) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_14) %controls_out_35 : !qco.qubit -> !qco.qubit
    %92 = qco.sx %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_0) %92 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%controls_out_37) targets (%arg0 = %93) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %94 = qco.rz(%cst_1) %targets_out_40 : !qco.qubit -> !qco.qubit
    %95 = qco.sx %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_3) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.sx %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_1) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst) %controls_out_39 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%99) targets (%arg0 = %98) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %100 = qco.x %targets_out_42 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst_0) %controls_out_41 : !qco.qubit -> !qco.qubit
    %102 = qco.sx %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst_1) %102 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%100) targets (%arg0 = %90) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %104 = qco.rz(%cst_1) %targets_out_44 : !qco.qubit -> !qco.qubit
    %105 = qco.sx %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_3) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.sx %106 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_1) %107 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%103) targets (%arg0 = %108) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %109 = qco.rz(%cst_6) %targets_out_46 : !qco.qubit -> !qco.qubit
    %110 = qco.sx %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_7) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.sx %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_0) %112 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%controls_out_43) targets (%arg0 = %113) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %114 = qco.rz(%cst_1) %targets_out_48 : !qco.qubit -> !qco.qubit
    %115 = qco.sx %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst_3) %115 : !qco.qubit -> !qco.qubit
    %117 = qco.sx %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_1) %117 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%controls_out_45) targets (%arg0 = %118) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %119 = qco.rz(%cst_6) %targets_out_50 : !qco.qubit -> !qco.qubit
    %120 = qco.sx %119 : !qco.qubit -> !qco.qubit
    %cst_51 = arith.constant -2.3561944901923448 : f64
    %121 = qco.rz(%cst_51) %120 : !qco.qubit -> !qco.qubit
    %122 = qco.sx %121 : !qco.qubit -> !qco.qubit
    %123 = qco.rz(%cst_0) %122 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_14) %controls_out_47 : !qco.qubit -> !qco.qubit
    %125 = qco.sx %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst_0) %125 : !qco.qubit -> !qco.qubit
    %controls_out_52, %targets_out_53 = qco.ctrl(%controls_out_49) targets (%arg0 = %126) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %127 = qco.rz(%cst_1) %targets_out_53 : !qco.qubit -> !qco.qubit
    %128 = qco.sx %127 : !qco.qubit -> !qco.qubit
    %129 = qco.rz(%cst_3) %128 : !qco.qubit -> !qco.qubit
    %130 = qco.sx %129 : !qco.qubit -> !qco.qubit
    %131 = qco.rz(%cst_1) %130 : !qco.qubit -> !qco.qubit
    %132 = qco.rz(%cst) %controls_out_52 : !qco.qubit -> !qco.qubit
    %controls_out_54, %targets_out_55 = qco.ctrl(%132) targets (%arg0 = %131) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %133 = qco.rz(%cst_1) %controls_out_54 : !qco.qubit -> !qco.qubit
    %134 = qco.sx %133 : !qco.qubit -> !qco.qubit
    %135 = qco.rz(%cst_0) %134 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %135 : !qco.qubit
    cbit.store %result, %3[%c0] : !cbit.reg<3>
    %qubit_out_56, %result_57 = qco.measure %targets_out_55 : !qco.qubit
    cbit.store %result_57, %3[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_56 : !qco.qubit
    %qubit_out_58, %result_59 = qco.measure %123 : !qco.qubit
    qco.sink %qubit_out_58 : !qco.qubit
    cbit.store %result_59, %3[%c2] : !cbit.reg<3>
    %cst_60 = arith.constant -0.78539816339744872 : f64
    qco.gphase(%cst_60)
    return %3 : !cbit.reg<3>
  }
}
