module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 0>, input_count = 7 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "gpi", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = [], fixed_parameters = [3.1415926535897931, unit], canonical_name = "r">, <name = "gpi2", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = [], fixed_parameters = [1.5707963267948966, unit], canonical_name = "r">, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant -5.000000e-01 : f64
    %cst_0 = arith.constant -3.1415926535897931 : f64
    %cst_1 = arith.constant 0.000000e+00 : f64
    %cst_2 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %cst_3 = arith.constant 0.78539816339744828 : f64
    %cst_4 = arith.constant 0.39269908169872414 : f64
    %cst_5 = arith.constant 0.19634954084936207 : f64
    %cst_6 = arith.constant 0.098174770424681035 : f64
    %cst_7 = arith.constant 0.049087385212340517 : f64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %8 = qco.rz(%cst_2) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_2, %cst_1) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_2) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_2) %2 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_2, %cst_1) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_2) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_2) %3 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_2, %cst_1) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_2) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_2) %4 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_2, %cst_1) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_2) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_2) %5 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_2, %cst_1) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_2) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_2) %6 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_2, %cst_1) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_2) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_2, %cst_1) %0 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_3) %26 : !qco.qubit -> !qco.qubit
    %28 = arith.mulf %cst_2, %cst : f64
    %qubit0_out, %qubit1_out = qco.rzz(%28) %25, %27 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_8 = arith.constant 0.39269908169872458 : f64
    %29 = qco.rz(%cst_8) %qubit1_out : !qco.qubit -> !qco.qubit
    %30 = arith.mulf %cst_3, %cst : f64
    %qubit0_out_9, %qubit1_out_10 = qco.rzz(%30) %22, %29 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_11 = arith.constant 0.19634954084936274 : f64
    %31 = qco.rz(%cst_11) %qubit1_out_10 : !qco.qubit -> !qco.qubit
    %32 = arith.mulf %cst_4, %cst : f64
    %qubit0_out_12, %qubit1_out_13 = qco.rzz(%32) %19, %31 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_14 = arith.constant 0.098174770424680701 : f64
    %33 = qco.rz(%cst_14) %qubit1_out_13 : !qco.qubit -> !qco.qubit
    %34 = arith.mulf %cst_5, %cst : f64
    %qubit0_out_15, %qubit1_out_16 = qco.rzz(%34) %16, %33 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_17 = arith.constant 0.049087385212340795 : f64
    %35 = qco.rz(%cst_17) %qubit1_out_16 : !qco.qubit -> !qco.qubit
    %36 = arith.mulf %cst_6, %cst : f64
    %qubit0_out_18, %qubit1_out_19 = qco.rzz(%36) %13, %35 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_20 = arith.constant 0.02454369260617062 : f64
    %37 = qco.rz(%cst_20) %qubit1_out_19 : !qco.qubit -> !qco.qubit
    %38 = arith.mulf %cst_7, %cst : f64
    %qubit0_out_21, %qubit1_out_22 = qco.rzz(%38) %10, %37 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %39 = qco.rz(%cst_0) %qubit1_out_22 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_2, %cst_1) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_0) %40 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %41 : !qco.qubit
    cbit.store %result, %7[%c0] : !cbit.reg<7>
    %qubit_out_23, %result_24 = qco.measure %qubit0_out_21 : !qco.qubit
    cbit.store %result_24, %7[%c1] : !cbit.reg<7>
    %qubit_out_25, %result_26 = qco.measure %qubit0_out_18 : !qco.qubit
    cbit.store %result_26, %7[%c2] : !cbit.reg<7>
    %qubit_out_27, %result_28 = qco.measure %qubit0_out_15 : !qco.qubit
    cbit.store %result_28, %7[%c3] : !cbit.reg<7>
    %qubit_out_29, %result_30 = qco.measure %qubit0_out_12 : !qco.qubit
    cbit.store %result_30, %7[%c4] : !cbit.reg<7>
    %qubit_out_31, %result_32 = qco.measure %qubit0_out_9 : !qco.qubit
    cbit.store %result_32, %7[%c5] : !cbit.reg<7>
    qco.sink %qubit_out_23 : !qco.qubit
    qco.sink %qubit_out_25 : !qco.qubit
    qco.sink %qubit_out_27 : !qco.qubit
    qco.sink %qubit_out_29 : !qco.qubit
    qco.sink %qubit_out_31 : !qco.qubit
    %qubit_out_33, %result_34 = qco.measure %qubit0_out : !qco.qubit
    qco.sink %qubit_out_33 : !qco.qubit
    cbit.store %result_34, %7[%c6] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    return %7 : !cbit.reg<7>
  }
}
