module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948966 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %5 = qco.rz(%cst) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_0) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.sx %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_0) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_0) %3 : !qco.qubit -> !qco.qubit
    %12 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_0) %12 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%10) targets (%arg0 = %7) {
      %23 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %23 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_1, %targets_out_2 = qco.ctrl(%13) targets (%arg0 = %targets_out) {
      %23 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %23 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.rz(%cst_0) %targets_out_2 : !qco.qubit -> !qco.qubit
    %15 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_0) %controls_out : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_0) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_0) %controls_out_1 : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_0) %21 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %19 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<3>
    %qubit_out_3, %result_4 = qco.measure %2 : !qco.qubit
    cbit.store %result_4, %4[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_3 : !qco.qubit
    %qubit_out_5, %result_6 = qco.measure %22 : !qco.qubit
    qco.sink %qubit_out_5 : !qco.qubit
    cbit.store %result_6, %4[%c2] : !cbit.reg<3>
    qco.sink %16 : !qco.qubit
    %cst_7 = arith.constant 3.1415926535897931 : f64
    qco.gphase(%cst_7)
    return %4 : !cbit.reg<3>
  }
}
