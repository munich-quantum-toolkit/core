module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 7, 0>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant -1.1780972450961724 : f64
    %cst_0 = arith.constant 1.178097245096172 : f64
    %cst_1 = arith.constant -2.3561944901923448 : f64
    %cst_2 = arith.constant 2.3561944901923448 : f64
    %cst_3 = arith.constant -1.5707963267948966 : f64
    %cst_4 = arith.constant -1.5707963267948963 : f64
    %cst_5 = arith.constant -0.78539816339744828 : f64
    %cst_6 = arith.constant 0.39269908169872414 : f64
    %cst_7 = arith.constant -0.39269908169872414 : f64
    %cst_8 = arith.constant 0.19634954084936229 : f64
    %cst_9 = arith.constant -0.19634954084936229 : f64
    %cst_10 = arith.constant 0.098174770424681145 : f64
    %cst_11 = arith.constant -0.098174770424681145 : f64
    %cst_12 = arith.constant 0.049087385212340351 : f64
    %cst_13 = arith.constant -0.049087385212340351 : f64
    %cst_14 = arith.constant 0.024543692606170175 : f64
    %cst_15 = arith.constant -0.024543692606170175 : f64
    %cst_16 = arith.constant 0.78539816339744828 : f64
    %cst_17 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %9 = qco.rz(%cst_17) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_16) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_17) %3 : !qco.qubit -> !qco.qubit
    %13 = qco.sx %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_16) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_17) %4 : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_16) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_17) %5 : !qco.qubit -> !qco.qubit
    %19 = qco.sx %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_17) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_17) %6 : !qco.qubit -> !qco.qubit
    %22 = qco.sx %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_17) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_17) %7 : !qco.qubit -> !qco.qubit
    %25 = qco.sx %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_17) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.x %0 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_0) %27 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%26) targets (%arg0 = %28) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.rz(%cst) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%controls_out) targets (%arg0 = %29) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_20 = arith.constant 0.3926990816987237 : f64
    %30 = qco.rz(%cst_20) %controls_out_18 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_2) %targets_out_19 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%23) targets (%arg0 = %31) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qco.rz(%cst_1) %targets_out_22 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%controls_out_21) targets (%arg0 = %32) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %33 = qco.rz(%cst_17) %controls_out_23 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_4) %targets_out_24 : !qco.qubit -> !qco.qubit
    %35 = qco.sx %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_17) %35 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%20) targets (%arg0 = %36) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.rz(%cst_17) %targets_out_26 : !qco.qubit -> !qco.qubit
    %38 = qco.sx %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_3) %38 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%1) targets (%arg0 = %11) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %40 = qco.rz(%cst_16) %targets_out_28 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%controls_out_27) targets (%arg0 = %40) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.rz(%cst_5) %controls_out_29 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_17) %targets_out_30 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_17) %43 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%44) targets (%arg0 = %14) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.rz(%cst_16) %targets_out_32 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%controls_out_31) targets (%arg0 = %45) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qco.rz(%cst_5) %controls_out_33 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_7) %targets_out_34 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%41) targets (%arg0 = %47) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %48 = qco.rz(%cst_6) %targets_out_36 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%controls_out_35) targets (%arg0 = %48) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qco.rz(%cst_7) %controls_out_37 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_17) %targets_out_38 : !qco.qubit -> !qco.qubit
    %51 = qco.sx %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_17) %51 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%52) targets (%arg0 = %17) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qco.rz(%cst_16) %targets_out_40 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%controls_out_39) targets (%arg0 = %53) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %54 = qco.rz(%cst_5) %controls_out_41 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_7) %targets_out_42 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%46) targets (%arg0 = %55) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qco.rz(%cst_6) %targets_out_44 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%controls_out_43) targets (%arg0 = %56) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %57 = qco.rz(%cst_7) %controls_out_45 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_9) %targets_out_46 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%49) targets (%arg0 = %58) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qco.rz(%cst_8) %targets_out_48 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%controls_out_47) targets (%arg0 = %59) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qco.rz(%cst_9) %controls_out_49 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_17) %targets_out_50 : !qco.qubit -> !qco.qubit
    %62 = qco.sx %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_17) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_5) %controls_out_25 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%63) targets (%arg0 = %64) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qco.rz(%cst_16) %targets_out_52 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%controls_out_51) targets (%arg0 = %65) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = qco.rz(%cst_5) %controls_out_53 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_7) %targets_out_54 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%54) targets (%arg0 = %67) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %68 = qco.rz(%cst_6) %targets_out_56 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%controls_out_55) targets (%arg0 = %68) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qco.rz(%cst_7) %controls_out_57 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_9) %targets_out_58 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%57) targets (%arg0 = %70) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qco.rz(%cst_8) %targets_out_60 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%controls_out_59) targets (%arg0 = %71) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %72 = qco.rz(%cst_9) %controls_out_61 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_11) %targets_out_62 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%60) targets (%arg0 = %73) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %74 = qco.rz(%cst_10) %targets_out_64 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%controls_out_63) targets (%arg0 = %74) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %75 = qco.rz(%cst_11) %controls_out_65 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_17) %targets_out_66 : !qco.qubit -> !qco.qubit
    %77 = qco.sx %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_17) %77 : !qco.qubit -> !qco.qubit
    %controls_out_67, %targets_out_68 = qco.ctrl(%78) targets (%arg0 = %33) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %79 = qco.rz(%cst_16) %targets_out_68 : !qco.qubit -> !qco.qubit
    %controls_out_69, %targets_out_70 = qco.ctrl(%controls_out_67) targets (%arg0 = %79) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %80 = qco.rz(%cst_5) %controls_out_69 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_7) %targets_out_70 : !qco.qubit -> !qco.qubit
    %controls_out_71, %targets_out_72 = qco.ctrl(%66) targets (%arg0 = %81) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %82 = qco.rz(%cst_6) %targets_out_72 : !qco.qubit -> !qco.qubit
    %controls_out_73, %targets_out_74 = qco.ctrl(%controls_out_71) targets (%arg0 = %82) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qco.rz(%cst_7) %controls_out_73 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_9) %targets_out_74 : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%69) targets (%arg0 = %84) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %85 = qco.rz(%cst_8) %targets_out_76 : !qco.qubit -> !qco.qubit
    %controls_out_77, %targets_out_78 = qco.ctrl(%controls_out_75) targets (%arg0 = %85) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %86 = qco.rz(%cst_9) %controls_out_77 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_11) %targets_out_78 : !qco.qubit -> !qco.qubit
    %controls_out_79, %targets_out_80 = qco.ctrl(%72) targets (%arg0 = %87) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %88 = qco.rz(%cst_10) %targets_out_80 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%controls_out_79) targets (%arg0 = %88) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %89 = qco.rz(%cst_11) %controls_out_81 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_13) %targets_out_82 : !qco.qubit -> !qco.qubit
    %controls_out_83, %targets_out_84 = qco.ctrl(%75) targets (%arg0 = %90) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %91 = qco.rz(%cst_12) %targets_out_84 : !qco.qubit -> !qco.qubit
    %controls_out_85, %targets_out_86 = qco.ctrl(%controls_out_83) targets (%arg0 = %91) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %92 = qco.rz(%cst_13) %controls_out_85 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_17) %targets_out_86 : !qco.qubit -> !qco.qubit
    %94 = qco.sx %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_17) %94 : !qco.qubit -> !qco.qubit
    %controls_out_87, %targets_out_88 = qco.ctrl(%95) targets (%arg0 = %30) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %96 = qco.rz(%cst_16) %targets_out_88 : !qco.qubit -> !qco.qubit
    %controls_out_89, %targets_out_90 = qco.ctrl(%controls_out_87) targets (%arg0 = %96) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %97 = qco.rz(%cst_5) %controls_out_89 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_7) %targets_out_90 : !qco.qubit -> !qco.qubit
    %controls_out_91, %targets_out_92 = qco.ctrl(%80) targets (%arg0 = %98) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %99 = qco.rz(%cst_6) %targets_out_92 : !qco.qubit -> !qco.qubit
    %controls_out_93, %targets_out_94 = qco.ctrl(%controls_out_91) targets (%arg0 = %99) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %100 = qco.rz(%cst_7) %controls_out_93 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst_9) %targets_out_94 : !qco.qubit -> !qco.qubit
    %controls_out_95, %targets_out_96 = qco.ctrl(%83) targets (%arg0 = %101) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %102 = qco.rz(%cst_8) %targets_out_96 : !qco.qubit -> !qco.qubit
    %controls_out_97, %targets_out_98 = qco.ctrl(%controls_out_95) targets (%arg0 = %102) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %103 = qco.rz(%cst_9) %controls_out_97 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_11) %targets_out_98 : !qco.qubit -> !qco.qubit
    %controls_out_99, %targets_out_100 = qco.ctrl(%86) targets (%arg0 = %104) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %105 = qco.rz(%cst_10) %targets_out_100 : !qco.qubit -> !qco.qubit
    %controls_out_101, %targets_out_102 = qco.ctrl(%controls_out_99) targets (%arg0 = %105) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %106 = qco.rz(%cst_11) %controls_out_101 : !qco.qubit -> !qco.qubit
    %107 = qco.rz(%cst_13) %targets_out_102 : !qco.qubit -> !qco.qubit
    %controls_out_103, %targets_out_104 = qco.ctrl(%89) targets (%arg0 = %107) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %108 = qco.rz(%cst_12) %targets_out_104 : !qco.qubit -> !qco.qubit
    %controls_out_105, %targets_out_106 = qco.ctrl(%controls_out_103) targets (%arg0 = %108) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %109 = qco.rz(%cst_13) %controls_out_105 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst_15) %targets_out_106 : !qco.qubit -> !qco.qubit
    %controls_out_107, %targets_out_108 = qco.ctrl(%92) targets (%arg0 = %110) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %111 = qco.rz(%cst_14) %targets_out_108 : !qco.qubit -> !qco.qubit
    %controls_out_109, %targets_out_110 = qco.ctrl(%controls_out_107) targets (%arg0 = %111) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %112 = qco.rz(%cst_15) %controls_out_109 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_17) %targets_out_110 : !qco.qubit -> !qco.qubit
    %114 = qco.sx %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_17) %114 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %112 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<7>
    %qubit_out_111, %result_112 = qco.measure %109 : !qco.qubit
    cbit.store %result_112, %8[%c1] : !cbit.reg<7>
    %qubit_out_113, %result_114 = qco.measure %106 : !qco.qubit
    cbit.store %result_114, %8[%c2] : !cbit.reg<7>
    %qubit_out_115, %result_116 = qco.measure %103 : !qco.qubit
    cbit.store %result_116, %8[%c3] : !cbit.reg<7>
    %qubit_out_117, %result_118 = qco.measure %100 : !qco.qubit
    cbit.store %result_118, %8[%c4] : !cbit.reg<7>
    %qubit_out_119, %result_120 = qco.measure %97 : !qco.qubit
    cbit.store %result_120, %8[%c5] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_111 : !qco.qubit
    qco.sink %qubit_out_113 : !qco.qubit
    qco.sink %qubit_out_115 : !qco.qubit
    qco.sink %qubit_out_117 : !qco.qubit
    qco.sink %qubit_out_119 : !qco.qubit
    %qubit_out_121, %result_122 = qco.measure %115 : !qco.qubit
    qco.sink %qubit_out_121 : !qco.qubit
    cbit.store %result_122, %8[%c6] : !cbit.reg<7>
    qco.sink %39 : !qco.qubit
    %cst_123 = arith.constant -0.60132046885117107 : f64
    qco.gphase(%cst_123)
    return %8 : !cbit.reg<7>
  }
}
