module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "gpi", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = [], fixed_parameters = [3.1415926535897931, unit], canonical_name = "r">, <name = "gpi2", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = [], fixed_parameters = [1.5707963267948966, unit], canonical_name = "r">, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<15> attributes {mqt.entry_point} {
    %cst = arith.constant -3.1415926535897931 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant 3.1415926535897931 : f64
    %cst_2 = arith.constant 0.000000e+00 : f64
    %cst_3 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<15>
    %17 = qco.rz(%cst_3) %1 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_3, %cst_2) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_3) %3 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_3, %cst_2) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_3) %5 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_3, %cst_2) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_3) %7 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_3, %cst_2) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_3) %9 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_3, %cst_2) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_3) %11 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_3, %cst_2) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_3) %13 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_3, %cst_2) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_3) %15 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_3, %cst_2) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_0) %0 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_0) %18, %33 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %34 = qco.rz(%cst_3) %qubit1_out : !qco.qubit -> !qco.qubit
    %qubit0_out_4, %qubit1_out_5 = qco.rzz(%cst_0) %20, %34 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %35 = qco.rz(%cst_3) %qubit1_out_5 : !qco.qubit -> !qco.qubit
    %qubit0_out_6, %qubit1_out_7 = qco.rzz(%cst_0) %22, %35 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %36 = qco.rz(%cst_3) %qubit1_out_7 : !qco.qubit -> !qco.qubit
    %qubit0_out_8, %qubit1_out_9 = qco.rzz(%cst_0) %24, %36 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %37 = qco.rz(%cst_3) %qubit1_out_9 : !qco.qubit -> !qco.qubit
    %qubit0_out_10, %qubit1_out_11 = qco.rzz(%cst_0) %26, %37 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %38 = qco.rz(%cst_3) %qubit1_out_11 : !qco.qubit -> !qco.qubit
    %qubit0_out_12, %qubit1_out_13 = qco.rzz(%cst_0) %28, %38 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %39 = qco.rz(%cst_3) %qubit1_out_13 : !qco.qubit -> !qco.qubit
    %qubit0_out_14, %qubit1_out_15 = qco.rzz(%cst_0) %30, %39 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %40 = qco.rz(%cst_3) %qubit1_out_15 : !qco.qubit -> !qco.qubit
    %qubit0_out_16, %qubit1_out_17 = qco.rzz(%cst_0) %32, %40 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %41 = qco.r(%cst_1, %cst_2) %qubit1_out_17 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_3) %qubit0_out : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_3, %cst_2) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_3) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_3) %qubit0_out_4 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%cst_3, %cst_2) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_3) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_3) %qubit0_out_6 : !qco.qubit -> !qco.qubit
    %50 = qco.r(%cst_3, %cst_2) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_3) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_3) %qubit0_out_8 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst_3, %cst_2) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_3) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_3) %qubit0_out_10 : !qco.qubit -> !qco.qubit
    %56 = qco.r(%cst_3, %cst_2) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_3) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_3) %qubit0_out_12 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%cst_3, %cst_2) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_3) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_3) %qubit0_out_14 : !qco.qubit -> !qco.qubit
    %62 = qco.r(%cst_3, %cst_2) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_3) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_3) %qubit0_out_16 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%cst_3, %cst_2) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_3) %65 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %45 : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<15>
    %qubit_out_18, %result_19 = qco.measure %2 : !qco.qubit
    cbit.store %result_19, %16[%c1] : !cbit.reg<15>
    %qubit_out_20, %result_21 = qco.measure %48 : !qco.qubit
    cbit.store %result_21, %16[%c2] : !cbit.reg<15>
    %qubit_out_22, %result_23 = qco.measure %4 : !qco.qubit
    cbit.store %result_23, %16[%c3] : !cbit.reg<15>
    %qubit_out_24, %result_25 = qco.measure %51 : !qco.qubit
    cbit.store %result_25, %16[%c4] : !cbit.reg<15>
    %qubit_out_26, %result_27 = qco.measure %6 : !qco.qubit
    cbit.store %result_27, %16[%c5] : !cbit.reg<15>
    %qubit_out_28, %result_29 = qco.measure %54 : !qco.qubit
    cbit.store %result_29, %16[%c6] : !cbit.reg<15>
    %qubit_out_30, %result_31 = qco.measure %8 : !qco.qubit
    cbit.store %result_31, %16[%c7] : !cbit.reg<15>
    %qubit_out_32, %result_33 = qco.measure %57 : !qco.qubit
    cbit.store %result_33, %16[%c8] : !cbit.reg<15>
    %qubit_out_34, %result_35 = qco.measure %10 : !qco.qubit
    cbit.store %result_35, %16[%c9] : !cbit.reg<15>
    %qubit_out_36, %result_37 = qco.measure %60 : !qco.qubit
    cbit.store %result_37, %16[%c10] : !cbit.reg<15>
    %qubit_out_38, %result_39 = qco.measure %12 : !qco.qubit
    cbit.store %result_39, %16[%c11] : !cbit.reg<15>
    %qubit_out_40, %result_41 = qco.measure %63 : !qco.qubit
    cbit.store %result_41, %16[%c12] : !cbit.reg<15>
    %qubit_out_42, %result_43 = qco.measure %14 : !qco.qubit
    cbit.store %result_43, %16[%c13] : !cbit.reg<15>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_18 : !qco.qubit
    qco.sink %qubit_out_20 : !qco.qubit
    qco.sink %qubit_out_22 : !qco.qubit
    qco.sink %qubit_out_24 : !qco.qubit
    qco.sink %qubit_out_26 : !qco.qubit
    qco.sink %qubit_out_28 : !qco.qubit
    qco.sink %qubit_out_30 : !qco.qubit
    qco.sink %qubit_out_32 : !qco.qubit
    qco.sink %qubit_out_34 : !qco.qubit
    qco.sink %qubit_out_36 : !qco.qubit
    qco.sink %qubit_out_38 : !qco.qubit
    qco.sink %qubit_out_40 : !qco.qubit
    qco.sink %qubit_out_42 : !qco.qubit
    %qubit_out_44, %result_45 = qco.measure %66 : !qco.qubit
    qco.sink %qubit_out_44 : !qco.qubit
    cbit.store %result_45, %16[%c14] : !cbit.reg<15>
    qco.sink %42 : !qco.qubit
    %cst_46 = arith.constant 1.5707963267948895 : f64
    qco.gphase(%cst_46)
    return %16 : !cbit.reg<15>
  }
}
