module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 0>, input_count = 5 : i64, sites = array<i64: 0, 1, 2, 3, 4>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<5> attributes {mqt.entry_point} {
    %cst = arith.constant -0.78539816339744828 : f64
    %cst_0 = arith.constant -0.39269908169872414 : f64
    %cst_1 = arith.constant -0.19634954084936229 : f64
    %cst_2 = arith.constant 1.5707963267948966 : f64
    %cst_3 = arith.constant -0.098174770424681145 : f64
    %cst_4 = arith.constant -3.1415926535897931 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<5>
    %6 = qco.rz(%cst_2) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.sx %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_2) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_2) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_2) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_2) %3 : !qco.qubit -> !qco.qubit
    %13 = qco.sx %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_2) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_2) %4 : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_2) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %0 : !qco.qubit -> !qco.qubit
    %cst_5 = arith.constant 0.78539816339744828 : f64
    %19 = qco.rz(%cst_5) %18 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%17) targets (%arg0 = %19) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.rz(%cst) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_6, %targets_out_7 = qco.ctrl(%controls_out) targets (%arg0 = %20) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_8 = arith.constant 0.39269908169872458 : f64
    %21 = qco.rz(%cst_8) %targets_out_7 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%14) targets (%arg0 = %21) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.rz(%cst_0) %targets_out_10 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%controls_out_9) targets (%arg0 = %22) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_13 = arith.constant 0.19634954084936229 : f64
    %23 = qco.rz(%cst_13) %targets_out_12 : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%11) targets (%arg0 = %23) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.rz(%cst_1) %targets_out_15 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%controls_out_14) targets (%arg0 = %24) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_18 = arith.constant 0.098174770424680701 : f64
    %25 = qco.rz(%cst_18) %targets_out_17 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%8) targets (%arg0 = %25) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.rz(%cst_3) %targets_out_20 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%controls_out_19) targets (%arg0 = %26) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %27 = qco.rz(%cst_4) %targets_out_22 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_4) %28 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %29 : !qco.qubit
    cbit.store %result, %5[%c0] : !cbit.reg<5>
    %qubit_out_23, %result_24 = qco.measure %controls_out_21 : !qco.qubit
    cbit.store %result_24, %5[%c1] : !cbit.reg<5>
    %qubit_out_25, %result_26 = qco.measure %controls_out_16 : !qco.qubit
    cbit.store %result_26, %5[%c2] : !cbit.reg<5>
    %qubit_out_27, %result_28 = qco.measure %controls_out_11 : !qco.qubit
    cbit.store %result_28, %5[%c3] : !cbit.reg<5>
    qco.sink %qubit_out_23 : !qco.qubit
    qco.sink %qubit_out_25 : !qco.qubit
    qco.sink %qubit_out_27 : !qco.qubit
    %qubit_out_29, %result_30 = qco.measure %controls_out_6 : !qco.qubit
    qco.sink %qubit_out_29 : !qco.qubit
    cbit.store %result_30, %5[%c4] : !cbit.reg<5>
    qco.sink %qubit_out : !qco.qubit
    %cst_31 = arith.constant -1.5707963267948966 : f64
    qco.gphase(%cst_31)
    return %5 : !cbit.reg<5>
  }
}
