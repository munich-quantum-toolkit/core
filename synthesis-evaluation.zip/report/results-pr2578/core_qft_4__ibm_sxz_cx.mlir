module attributes {mqt.layout = {initial = array<i64: 3, 2, 0, 1>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant -0.19634954084936229 : f64
    %cst_0 = arith.constant 0.19634954084936229 : f64
    %cst_1 = arith.constant -0.39269908169872414 : f64
    %cst_2 = arith.constant 0.39269908169872414 : f64
    %cst_3 = arith.constant -0.78539816339744828 : f64
    %cst_4 = arith.constant 0.78539816339744828 : f64
    %cst_5 = arith.constant 1.5707963267948966 : f64
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.rz(%cst_5) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_5) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_4) %1 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%7) targets (%arg0 = %8) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %9 = qco.rz(%cst_3) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_6, %targets_out_7 = qco.ctrl(%controls_out) targets (%arg0 = %9) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_8 = arith.constant 2.3561944901923448 : f64
    %10 = qco.rz(%cst_8) %controls_out_6 : !qco.qubit -> !qco.qubit
    %11 = qco.sx %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_8) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_2) %targets_out_7 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%2) targets (%arg0 = %13) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.rz(%cst_1) %targets_out_10 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%controls_out_9) targets (%arg0 = %14) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qco.rz(%cst_2) %controls_out_11 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_0) %targets_out_12 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%3) targets (%arg0 = %16) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.rz(%cst) %targets_out_14 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%controls_out_13) targets (%arg0 = %17) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qco.rz(%cst_0) %controls_out_15 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%15) targets (%arg0 = %12) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.rz(%cst_3) %targets_out_18 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%controls_out_17) targets (%arg0 = %19) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.rz(%cst_8) %controls_out_19 : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_8) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_2) %targets_out_20 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%18) targets (%arg0 = %23) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.rz(%cst_1) %targets_out_22 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%controls_out_21) targets (%arg0 = %24) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %25 = qco.rz(%cst_2) %controls_out_23 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%25) targets (%arg0 = %22) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.rz(%cst_3) %targets_out_26 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%controls_out_25) targets (%arg0 = %26) {
      %30 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %27 = qco.rz(%cst_8) %controls_out_27 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_5) %28 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %29 : !qco.qubit
    cbit.store %result, %4[%c3] : !cbit.reg<4>
    %qubit_out_29, %result_30 = qco.measure %targets_out_28 : !qco.qubit
    cbit.store %result_30, %4[%c2] : !cbit.reg<4>
    %qubit_out_31, %result_32 = qco.measure %targets_out_24 : !qco.qubit
    cbit.store %result_32, %4[%c1] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_29 : !qco.qubit
    qco.sink %qubit_out_31 : !qco.qubit
    %qubit_out_33, %result_34 = qco.measure %targets_out_16 : !qco.qubit
    qco.sink %qubit_out_33 : !qco.qubit
    cbit.store %result_34, %4[%c0] : !cbit.reg<4>
    %cst_35 = arith.constant -1.4726215563702159 : f64
    qco.gphase(%cst_35)
    return %4 : !cbit.reg<4>
  }
}
