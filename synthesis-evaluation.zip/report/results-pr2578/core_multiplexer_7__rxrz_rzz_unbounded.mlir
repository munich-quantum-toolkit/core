module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 0>, input_count = 7 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant -5.000000e-01 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %cst_2 = arith.constant 0.78539816339744828 : f64
    %cst_3 = arith.constant 0.39269908169872414 : f64
    %cst_4 = arith.constant 0.19634954084936207 : f64
    %cst_5 = arith.constant 0.098174770424681035 : f64
    %cst_6 = arith.constant 0.049087385212340517 : f64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %8 = qco.rz(%cst_0) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_0) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_0) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_0) %2 : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_0) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_0) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_0) %3 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_0) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_0) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_0) %4 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_0) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_0) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_0) %5 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_0) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_0) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_0) %6 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_0) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_0) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_0) %0 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_2) %26 : !qco.qubit -> !qco.qubit
    %28 = arith.mulf %cst_0, %cst : f64
    %qubit0_out, %qubit1_out = qco.rzz(%28) %25, %27 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %29 = qco.rz(%cst_3) %qubit1_out : !qco.qubit -> !qco.qubit
    %30 = arith.mulf %cst_2, %cst : f64
    %qubit0_out_7, %qubit1_out_8 = qco.rzz(%30) %22, %29 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_9 = arith.constant 0.19634954084936229 : f64
    %31 = qco.rz(%cst_9) %qubit1_out_8 : !qco.qubit -> !qco.qubit
    %32 = arith.mulf %cst_3, %cst : f64
    %qubit0_out_10, %qubit1_out_11 = qco.rzz(%32) %19, %31 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_12 = arith.constant 0.098174770424681145 : f64
    %33 = qco.rz(%cst_12) %qubit1_out_11 : !qco.qubit -> !qco.qubit
    %34 = arith.mulf %cst_4, %cst : f64
    %qubit0_out_13, %qubit1_out_14 = qco.rzz(%34) %16, %33 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_15 = arith.constant 0.049087385212340351 : f64
    %35 = qco.rz(%cst_15) %qubit1_out_14 : !qco.qubit -> !qco.qubit
    %36 = arith.mulf %cst_5, %cst : f64
    %qubit0_out_16, %qubit1_out_17 = qco.rzz(%36) %13, %35 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_18 = arith.constant 0.024543692606170175 : f64
    %37 = qco.rz(%cst_18) %qubit1_out_17 : !qco.qubit -> !qco.qubit
    %38 = arith.mulf %cst_6, %cst : f64
    %qubit0_out_19, %qubit1_out_20 = qco.rzz(%38) %10, %37 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %39 = qco.rx(%cst_1) %qubit1_out_20 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %39 : !qco.qubit
    cbit.store %result, %7[%c0] : !cbit.reg<7>
    %qubit_out_21, %result_22 = qco.measure %qubit0_out_19 : !qco.qubit
    cbit.store %result_22, %7[%c1] : !cbit.reg<7>
    %qubit_out_23, %result_24 = qco.measure %qubit0_out_16 : !qco.qubit
    cbit.store %result_24, %7[%c2] : !cbit.reg<7>
    %qubit_out_25, %result_26 = qco.measure %qubit0_out_13 : !qco.qubit
    cbit.store %result_26, %7[%c3] : !cbit.reg<7>
    %qubit_out_27, %result_28 = qco.measure %qubit0_out_10 : !qco.qubit
    cbit.store %result_28, %7[%c4] : !cbit.reg<7>
    %qubit_out_29, %result_30 = qco.measure %qubit0_out_7 : !qco.qubit
    cbit.store %result_30, %7[%c5] : !cbit.reg<7>
    qco.sink %qubit_out_21 : !qco.qubit
    qco.sink %qubit_out_23 : !qco.qubit
    qco.sink %qubit_out_25 : !qco.qubit
    qco.sink %qubit_out_27 : !qco.qubit
    qco.sink %qubit_out_29 : !qco.qubit
    %qubit_out_31, %result_32 = qco.measure %qubit0_out : !qco.qubit
    qco.sink %qubit_out_31 : !qco.qubit
    cbit.store %result_32, %7[%c6] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    %cst_33 = arith.constant 3.1415926535897931 : f64
    qco.gphase(%cst_33)
    return %7 : !cbit.reg<7>
  }
}
