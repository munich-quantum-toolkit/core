module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<16> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948966 : f64
    %cst_0 = arith.constant 3.1415926535897931 : f64
    %cst_1 = arith.constant -1.5707963267948974 : f64
    %cst_2 = arith.constant 1.5707963267948966 : f64
    %cst_3 = arith.constant -3.1415926535897931 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %c15 = arith.constant 15 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<16>
    %cst_4 = arith.constant -1.570796326794897 : f64
    %17 = qco.rz(%cst_4) %0 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_2) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_3) %1 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_2) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_1) %20 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %18, %21 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %22 = qco.rx(%cst_0) %qubit1_out : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_3) %qubit0_out : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_2) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst) %25 : !qco.qubit -> !qco.qubit
    %qubit0_out_5, %qubit1_out_6 = qco.iswap %26, %23 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %27 = qco.rz(%cst_2) %qubit1_out_6 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_2) %qubit0_out_5 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_3) %2 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_2) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_1) %30 : !qco.qubit -> !qco.qubit
    %qubit0_out_7, %qubit1_out_8 = qco.iswap %27, %31 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %32 = qco.rx(%cst_0) %qubit1_out_8 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_3) %qubit0_out_7 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_2) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst) %35 : !qco.qubit -> !qco.qubit
    %qubit0_out_9, %qubit1_out_10 = qco.iswap %36, %33 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %37 = qco.rz(%cst_2) %qubit1_out_10 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_2) %qubit0_out_9 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_3) %3 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_2) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_1) %40 : !qco.qubit -> !qco.qubit
    %qubit0_out_11, %qubit1_out_12 = qco.iswap %37, %41 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %42 = qco.rx(%cst_0) %qubit1_out_12 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_3) %qubit0_out_11 : !qco.qubit -> !qco.qubit
    %45 = qco.rx(%cst_2) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst) %45 : !qco.qubit -> !qco.qubit
    %qubit0_out_13, %qubit1_out_14 = qco.iswap %46, %43 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %47 = qco.rz(%cst_2) %qubit1_out_14 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_2) %qubit0_out_13 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_3) %4 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_2) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_1) %50 : !qco.qubit -> !qco.qubit
    %qubit0_out_15, %qubit1_out_16 = qco.iswap %47, %51 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %52 = qco.rx(%cst_0) %qubit1_out_16 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_3) %qubit0_out_15 : !qco.qubit -> !qco.qubit
    %55 = qco.rx(%cst_2) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst) %55 : !qco.qubit -> !qco.qubit
    %qubit0_out_17, %qubit1_out_18 = qco.iswap %56, %53 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %57 = qco.rz(%cst_2) %qubit1_out_18 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_2) %qubit0_out_17 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_3) %5 : !qco.qubit -> !qco.qubit
    %60 = qco.rx(%cst_2) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_1) %60 : !qco.qubit -> !qco.qubit
    %qubit0_out_19, %qubit1_out_20 = qco.iswap %57, %61 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %62 = qco.rx(%cst_0) %qubit1_out_20 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_3) %qubit0_out_19 : !qco.qubit -> !qco.qubit
    %65 = qco.rx(%cst_2) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst) %65 : !qco.qubit -> !qco.qubit
    %qubit0_out_21, %qubit1_out_22 = qco.iswap %66, %63 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %67 = qco.rz(%cst_2) %qubit1_out_22 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_2) %qubit0_out_21 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_3) %6 : !qco.qubit -> !qco.qubit
    %70 = qco.rx(%cst_2) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_1) %70 : !qco.qubit -> !qco.qubit
    %qubit0_out_23, %qubit1_out_24 = qco.iswap %67, %71 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %72 = qco.rx(%cst_0) %qubit1_out_24 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_3) %qubit0_out_23 : !qco.qubit -> !qco.qubit
    %75 = qco.rx(%cst_2) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst) %75 : !qco.qubit -> !qco.qubit
    %qubit0_out_25, %qubit1_out_26 = qco.iswap %76, %73 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %77 = qco.rz(%cst_2) %qubit1_out_26 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_2) %qubit0_out_25 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_3) %7 : !qco.qubit -> !qco.qubit
    %80 = qco.rx(%cst_2) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_1) %80 : !qco.qubit -> !qco.qubit
    %qubit0_out_27, %qubit1_out_28 = qco.iswap %77, %81 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %82 = qco.rx(%cst_0) %qubit1_out_28 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_3) %qubit0_out_27 : !qco.qubit -> !qco.qubit
    %85 = qco.rx(%cst_2) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst) %85 : !qco.qubit -> !qco.qubit
    %qubit0_out_29, %qubit1_out_30 = qco.iswap %86, %83 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %87 = qco.rz(%cst_2) %qubit1_out_30 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_2) %qubit0_out_29 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_3) %8 : !qco.qubit -> !qco.qubit
    %90 = qco.rx(%cst_2) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_1) %90 : !qco.qubit -> !qco.qubit
    %qubit0_out_31, %qubit1_out_32 = qco.iswap %87, %91 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %92 = qco.rx(%cst_0) %qubit1_out_32 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_3) %qubit0_out_31 : !qco.qubit -> !qco.qubit
    %95 = qco.rx(%cst_2) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst) %95 : !qco.qubit -> !qco.qubit
    %qubit0_out_33, %qubit1_out_34 = qco.iswap %96, %93 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %97 = qco.rz(%cst_2) %qubit1_out_34 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_2) %qubit0_out_33 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_3) %9 : !qco.qubit -> !qco.qubit
    %100 = qco.rx(%cst_2) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst_1) %100 : !qco.qubit -> !qco.qubit
    %qubit0_out_35, %qubit1_out_36 = qco.iswap %97, %101 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %102 = qco.rx(%cst_0) %qubit1_out_36 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_3) %qubit0_out_35 : !qco.qubit -> !qco.qubit
    %105 = qco.rx(%cst_2) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst) %105 : !qco.qubit -> !qco.qubit
    %qubit0_out_37, %qubit1_out_38 = qco.iswap %106, %103 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %107 = qco.rz(%cst_2) %qubit1_out_38 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_2) %qubit0_out_37 : !qco.qubit -> !qco.qubit
    %109 = qco.rz(%cst_3) %10 : !qco.qubit -> !qco.qubit
    %110 = qco.rx(%cst_2) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_1) %110 : !qco.qubit -> !qco.qubit
    %qubit0_out_39, %qubit1_out_40 = qco.iswap %107, %111 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %112 = qco.rx(%cst_0) %qubit1_out_40 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst) %112 : !qco.qubit -> !qco.qubit
    %114 = qco.rz(%cst_3) %qubit0_out_39 : !qco.qubit -> !qco.qubit
    %115 = qco.rx(%cst_2) %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst) %115 : !qco.qubit -> !qco.qubit
    %qubit0_out_41, %qubit1_out_42 = qco.iswap %116, %113 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %117 = qco.rz(%cst_2) %qubit1_out_42 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_2) %qubit0_out_41 : !qco.qubit -> !qco.qubit
    %119 = qco.rz(%cst_3) %11 : !qco.qubit -> !qco.qubit
    %120 = qco.rx(%cst_2) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rz(%cst_1) %120 : !qco.qubit -> !qco.qubit
    %qubit0_out_43, %qubit1_out_44 = qco.iswap %117, %121 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %122 = qco.rx(%cst_0) %qubit1_out_44 : !qco.qubit -> !qco.qubit
    %123 = qco.rz(%cst) %122 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_3) %qubit0_out_43 : !qco.qubit -> !qco.qubit
    %125 = qco.rx(%cst_2) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst) %125 : !qco.qubit -> !qco.qubit
    %qubit0_out_45, %qubit1_out_46 = qco.iswap %126, %123 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %127 = qco.rz(%cst_2) %qubit1_out_46 : !qco.qubit -> !qco.qubit
    %128 = qco.rz(%cst_2) %qubit0_out_45 : !qco.qubit -> !qco.qubit
    %129 = qco.rz(%cst_3) %12 : !qco.qubit -> !qco.qubit
    %130 = qco.rx(%cst_2) %129 : !qco.qubit -> !qco.qubit
    %131 = qco.rz(%cst_1) %130 : !qco.qubit -> !qco.qubit
    %qubit0_out_47, %qubit1_out_48 = qco.iswap %127, %131 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %132 = qco.rx(%cst_0) %qubit1_out_48 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.rz(%cst_3) %qubit0_out_47 : !qco.qubit -> !qco.qubit
    %135 = qco.rx(%cst_2) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.rz(%cst) %135 : !qco.qubit -> !qco.qubit
    %qubit0_out_49, %qubit1_out_50 = qco.iswap %136, %133 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %137 = qco.rz(%cst_2) %qubit1_out_50 : !qco.qubit -> !qco.qubit
    %138 = qco.rz(%cst_2) %qubit0_out_49 : !qco.qubit -> !qco.qubit
    %139 = qco.rz(%cst_3) %13 : !qco.qubit -> !qco.qubit
    %140 = qco.rx(%cst_2) %139 : !qco.qubit -> !qco.qubit
    %141 = qco.rz(%cst_1) %140 : !qco.qubit -> !qco.qubit
    %qubit0_out_51, %qubit1_out_52 = qco.iswap %137, %141 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %142 = qco.rx(%cst_0) %qubit1_out_52 : !qco.qubit -> !qco.qubit
    %143 = qco.rz(%cst) %142 : !qco.qubit -> !qco.qubit
    %144 = qco.rz(%cst_3) %qubit0_out_51 : !qco.qubit -> !qco.qubit
    %145 = qco.rx(%cst_2) %144 : !qco.qubit -> !qco.qubit
    %146 = qco.rz(%cst) %145 : !qco.qubit -> !qco.qubit
    %qubit0_out_53, %qubit1_out_54 = qco.iswap %146, %143 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %147 = qco.rz(%cst_2) %qubit1_out_54 : !qco.qubit -> !qco.qubit
    %148 = qco.rz(%cst_2) %qubit0_out_53 : !qco.qubit -> !qco.qubit
    %149 = qco.rz(%cst_3) %14 : !qco.qubit -> !qco.qubit
    %150 = qco.rx(%cst_2) %149 : !qco.qubit -> !qco.qubit
    %151 = qco.rz(%cst_1) %150 : !qco.qubit -> !qco.qubit
    %qubit0_out_55, %qubit1_out_56 = qco.iswap %147, %151 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %152 = qco.rx(%cst_0) %qubit1_out_56 : !qco.qubit -> !qco.qubit
    %153 = qco.rz(%cst) %152 : !qco.qubit -> !qco.qubit
    %154 = qco.rz(%cst_3) %qubit0_out_55 : !qco.qubit -> !qco.qubit
    %155 = qco.rx(%cst_2) %154 : !qco.qubit -> !qco.qubit
    %156 = qco.rz(%cst) %155 : !qco.qubit -> !qco.qubit
    %qubit0_out_57, %qubit1_out_58 = qco.iswap %156, %153 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %157 = qco.rz(%cst_2) %qubit1_out_58 : !qco.qubit -> !qco.qubit
    %158 = qco.rz(%cst_2) %qubit0_out_57 : !qco.qubit -> !qco.qubit
    %159 = qco.rz(%cst_3) %15 : !qco.qubit -> !qco.qubit
    %160 = qco.rx(%cst_2) %159 : !qco.qubit -> !qco.qubit
    %161 = qco.rz(%cst_1) %160 : !qco.qubit -> !qco.qubit
    %qubit0_out_59, %qubit1_out_60 = qco.iswap %157, %161 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %162 = qco.rx(%cst_0) %qubit1_out_60 : !qco.qubit -> !qco.qubit
    %163 = qco.rz(%cst) %162 : !qco.qubit -> !qco.qubit
    %164 = qco.rz(%cst_3) %qubit0_out_59 : !qco.qubit -> !qco.qubit
    %165 = qco.rx(%cst_2) %164 : !qco.qubit -> !qco.qubit
    %166 = qco.rz(%cst) %165 : !qco.qubit -> !qco.qubit
    %qubit0_out_61, %qubit1_out_62 = qco.iswap %166, %163 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %167 = qco.rx(%cst_0) %qubit1_out_62 : !qco.qubit -> !qco.qubit
    %168 = qco.rz(%cst_3) %167 : !qco.qubit -> !qco.qubit
    %169 = qco.rz(%cst_2) %qubit0_out_61 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %28 : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<16>
    %qubit_out_63, %result_64 = qco.measure %38 : !qco.qubit
    cbit.store %result_64, %16[%c1] : !cbit.reg<16>
    %qubit_out_65, %result_66 = qco.measure %48 : !qco.qubit
    cbit.store %result_66, %16[%c2] : !cbit.reg<16>
    %qubit_out_67, %result_68 = qco.measure %58 : !qco.qubit
    cbit.store %result_68, %16[%c3] : !cbit.reg<16>
    %qubit_out_69, %result_70 = qco.measure %68 : !qco.qubit
    cbit.store %result_70, %16[%c4] : !cbit.reg<16>
    %qubit_out_71, %result_72 = qco.measure %78 : !qco.qubit
    cbit.store %result_72, %16[%c5] : !cbit.reg<16>
    %qubit_out_73, %result_74 = qco.measure %88 : !qco.qubit
    cbit.store %result_74, %16[%c6] : !cbit.reg<16>
    %qubit_out_75, %result_76 = qco.measure %98 : !qco.qubit
    cbit.store %result_76, %16[%c7] : !cbit.reg<16>
    %qubit_out_77, %result_78 = qco.measure %108 : !qco.qubit
    cbit.store %result_78, %16[%c8] : !cbit.reg<16>
    %qubit_out_79, %result_80 = qco.measure %118 : !qco.qubit
    cbit.store %result_80, %16[%c9] : !cbit.reg<16>
    %qubit_out_81, %result_82 = qco.measure %128 : !qco.qubit
    cbit.store %result_82, %16[%c10] : !cbit.reg<16>
    %qubit_out_83, %result_84 = qco.measure %138 : !qco.qubit
    cbit.store %result_84, %16[%c11] : !cbit.reg<16>
    %qubit_out_85, %result_86 = qco.measure %148 : !qco.qubit
    cbit.store %result_86, %16[%c12] : !cbit.reg<16>
    %qubit_out_87, %result_88 = qco.measure %158 : !qco.qubit
    cbit.store %result_88, %16[%c13] : !cbit.reg<16>
    %qubit_out_89, %result_90 = qco.measure %169 : !qco.qubit
    cbit.store %result_90, %16[%c14] : !cbit.reg<16>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_63 : !qco.qubit
    qco.sink %qubit_out_65 : !qco.qubit
    qco.sink %qubit_out_67 : !qco.qubit
    qco.sink %qubit_out_69 : !qco.qubit
    qco.sink %qubit_out_71 : !qco.qubit
    qco.sink %qubit_out_73 : !qco.qubit
    qco.sink %qubit_out_75 : !qco.qubit
    qco.sink %qubit_out_77 : !qco.qubit
    qco.sink %qubit_out_79 : !qco.qubit
    qco.sink %qubit_out_81 : !qco.qubit
    qco.sink %qubit_out_83 : !qco.qubit
    qco.sink %qubit_out_85 : !qco.qubit
    qco.sink %qubit_out_87 : !qco.qubit
    qco.sink %qubit_out_89 : !qco.qubit
    %qubit_out_91, %result_92 = qco.measure %168 : !qco.qubit
    qco.sink %qubit_out_91 : !qco.qubit
    cbit.store %result_92, %16[%c15] : !cbit.reg<16>
    %cst_93 = arith.constant -0.7853981633974616 : f64
    qco.gphase(%cst_93)
    return %16 : !cbit.reg<16>
  }
}
