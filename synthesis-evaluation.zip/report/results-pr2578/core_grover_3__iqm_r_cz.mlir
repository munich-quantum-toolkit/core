module attributes {mqt.layout = {initial = array<i64: 0, 1, 2>, input_count = 3 : i64, sites = array<i64: 0, 1, 2>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 10.995574287564276 : f64
    %cst_0 = arith.constant 5.497787143782138 : f64
    %cst_1 = arith.constant 3.926990816987241 : f64
    %cst_2 = arith.constant 8.6393797973719302 : f64
    %cst_3 = arith.constant 6.2831853071795862 : f64
    %cst_4 = arith.constant -0.78539816339744828 : f64
    %cst_5 = arith.constant -5.497787143782138 : f64
    %cst_6 = arith.constant -0.78539816339744783 : f64
    %cst_7 = arith.constant -3.9269908169872423 : f64
    %cst_8 = arith.constant -0.78539816339744872 : f64
    %cst_9 = arith.constant 3.9269908169872414 : f64
    %cst_10 = arith.constant 4.4408920985006262E-16 : f64
    %cst_11 = arith.constant 1.5707963267948961 : f64
    %cst_12 = arith.constant -1.5707963267948966 : f64
    %cst_13 = arith.constant 1.5707963267948966 : f64
    %cst_14 = arith.constant 0.78539816339744828 : f64
    %cst_15 = arith.constant 1.5707963267948968 : f64
    %cst_16 = arith.constant -3.9269908169872414 : f64
    %cst_17 = arith.constant -3.1415926535897931 : f64
    %cst_18 = arith.constant -2.3561944901923448 : f64
    %cst_19 = arith.constant 3.1415926535897931 : f64
    %cst_20 = arith.constant 0.000000e+00 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %4 = qco.r(%cst_13, %cst_12) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.r(%cst_13, %cst_13) %1 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%5) targets (%arg0 = %2) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %6 = qco.r(%cst_14, %cst_17) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%4) targets (%arg0 = %6) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %7 = qco.r(%cst_14, %cst_10) %targets_out_22 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%controls_out) targets (%arg0 = %7) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %8 = qco.r(%cst_14, %cst_17) %targets_out_24 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%controls_out_21) targets (%arg0 = %8) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %9 = qco.r(%cst_13, %cst_12) %targets_out_26 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_15, %cst_9) %controls_out_23 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%controls_out_25) targets (%arg0 = %10) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qco.r(%cst_14, %cst_8) %targets_out_28 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%controls_out_27) targets (%arg0 = %11) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qco.r(%cst_19, %cst_14) %targets_out_30 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_13, %cst_18) %controls_out_29 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%12) targets (%arg0 = %9) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.r(%cst_14, %cst_7) %targets_out_32 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%13) targets (%arg0 = %14) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qco.r(%cst_14, %cst_6) %targets_out_34 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%controls_out_31) targets (%arg0 = %15) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.r(%cst_14, %cst_7) %targets_out_36 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%controls_out_33) targets (%arg0 = %16) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.r(%cst_13, %cst_5) %targets_out_38 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_15, %cst_3) %controls_out_35 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%controls_out_37) targets (%arg0 = %18) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.r(%cst_14, %cst_11) %targets_out_40 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%controls_out_39) targets (%arg0 = %19) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.r(%cst_19, %cst_19) %targets_out_42 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_13, %cst_20) %controls_out_41 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%20) targets (%arg0 = %17) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.r(%cst_14, %cst_17) %targets_out_44 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%21) targets (%arg0 = %22) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qco.r(%cst_14, %cst_10) %targets_out_46 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%controls_out_43) targets (%arg0 = %23) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.r(%cst_14, %cst_17) %targets_out_48 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%controls_out_45) targets (%arg0 = %24) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %25 = qco.r(%cst_13, %cst_12) %targets_out_50 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_15, %cst_2) %controls_out_47 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%controls_out_49) targets (%arg0 = %26) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %27 = qco.r(%cst_14, %cst_1) %targets_out_52 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%controls_out_51) targets (%arg0 = %27) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qco.r(%cst_19, %cst_0) %targets_out_54 : !qco.qubit -> !qco.qubit
    %29 = qco.r(%cst_13, %cst_16) %controls_out_53 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%28) targets (%arg0 = %25) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.r(%cst_14, %cst_7) %targets_out_56 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%29) targets (%arg0 = %30) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.r(%cst_14, %cst_6) %targets_out_58 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%controls_out_55) targets (%arg0 = %31) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qco.r(%cst_14, %cst_7) %targets_out_60 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%controls_out_57) targets (%arg0 = %32) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %33 = qco.r(%cst_14, %cst_4) %targets_out_62 : !qco.qubit -> !qco.qubit
    %34 = qco.r(%cst_15, %cst) %controls_out_59 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%controls_out_61) targets (%arg0 = %34) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.r(%cst_14, %cst_3) %targets_out_64 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%controls_out_63) targets (%arg0 = %35) {
      %37 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %37 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qco.r(%cst_13, %cst_12) %controls_out_65 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %36 : !qco.qubit
    cbit.store %result, %3[%c0] : !cbit.reg<3>
    %qubit_out_67, %result_68 = qco.measure %targets_out_66 : !qco.qubit
    cbit.store %result_68, %3[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_67 : !qco.qubit
    %qubit_out_69, %result_70 = qco.measure %33 : !qco.qubit
    qco.sink %qubit_out_69 : !qco.qubit
    cbit.store %result_70, %3[%c2] : !cbit.reg<3>
    %cst_71 = arith.constant -3.1415926535897927 : f64
    qco.gphase(%cst_71)
    return %3 : !cbit.reg<3>
  }
}
