module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 7, 0>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = [], parameter_bounds = [array<f64: 0.000000e+00, 1.5707963267948966>]>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant 1.178097245096172 : f64
    %cst_0 = arith.constant 1.1780972450961724 : f64
    %cst_1 = arith.constant 2.3561944901923448 : f64
    %cst_2 = arith.constant -1.5707963267948966 : f64
    %cst_3 = arith.constant -3.1415926535897931 : f64
    %cst_4 = arith.constant 0.78539816339744828 : f64
    %cst_5 = arith.constant -0.78539816339744828 : f64
    %cst_6 = arith.constant 0.39269908169872414 : f64
    %cst_7 = arith.constant -0.39269908169872414 : f64
    %cst_8 = arith.constant 0.19634954084936207 : f64
    %cst_9 = arith.constant -0.19634954084936229 : f64
    %cst_10 = arith.constant 0.098174770424681035 : f64
    %cst_11 = arith.constant -0.098174770424681145 : f64
    %cst_12 = arith.constant 0.049087385212340517 : f64
    %cst_13 = arith.constant -0.049087385212340351 : f64
    %cst_14 = arith.constant 0.024543692606170259 : f64
    %cst_15 = arith.constant -0.024543692606170175 : f64
    %cst_16 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %9 = qco.rz(%cst_16) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_16) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_4) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_16) %3 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_16) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_4) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_16) %4 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_16) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_4) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_16) %5 : !qco.qubit -> !qco.qubit
    %cst_17 = arith.constant -1.5707963267948968 : f64
    %19 = qco.rx(%cst_17) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_16) %6 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_16) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_16) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_2) %7 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_16) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_16) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.x %0 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst) %26 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_0) %25, %27 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_18 = arith.constant -1.570796326794897 : f64
    %28 = qco.rz(%cst_18) %qubit0_out : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_3) %28 : !qco.qubit -> !qco.qubit
    %cst_19 = arith.constant -1.178097245096172 : f64
    %30 = qco.rz(%cst_19) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_1) %qubit1_out : !qco.qubit -> !qco.qubit
    %qubit0_out_20, %qubit1_out_21 = qco.rzz(%cst_4) %22, %31 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %32 = qco.rz(%cst_2) %qubit0_out_20 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_3) %qubit1_out_21 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_16) %33 : !qco.qubit -> !qco.qubit
    %qubit0_out_22, %qubit1_out_23 = qco.rzz(%cst_16) %19, %34 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %35 = qco.rz(%cst_2) %qubit1_out_23 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_3) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_16) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_17) %qubit0_out_22 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_3) %38 : !qco.qubit -> !qco.qubit
    %cst_24 = arith.constant -2.3561944901923448 : f64
    %40 = qco.rz(%cst_24) %39 : !qco.qubit -> !qco.qubit
    %qubit0_out_25, %qubit1_out_26 = qco.rzz(%cst_4) %1, %11 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %41 = qco.rz(%cst_5) %qubit0_out_25 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_16) %qubit1_out_26 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_16) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_16) %43 : !qco.qubit -> !qco.qubit
    %qubit0_out_27, %qubit1_out_28 = qco.rzz(%cst_4) %44, %14 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %45 = qco.rz(%cst_5) %qubit0_out_27 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_7) %qubit1_out_28 : !qco.qubit -> !qco.qubit
    %qubit0_out_29, %qubit1_out_30 = qco.rzz(%cst_6) %41, %46 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %47 = qco.rz(%cst_7) %qubit0_out_29 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_16) %qubit1_out_30 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_16) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_16) %49 : !qco.qubit -> !qco.qubit
    %qubit0_out_31, %qubit1_out_32 = qco.rzz(%cst_4) %50, %17 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %51 = qco.rz(%cst_5) %qubit0_out_31 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_7) %qubit1_out_32 : !qco.qubit -> !qco.qubit
    %qubit0_out_33, %qubit1_out_34 = qco.rzz(%cst_6) %45, %52 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %53 = qco.rz(%cst_7) %qubit0_out_33 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_9) %qubit1_out_34 : !qco.qubit -> !qco.qubit
    %qubit0_out_35, %qubit1_out_36 = qco.rzz(%cst_8) %47, %54 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %55 = qco.rz(%cst_9) %qubit0_out_35 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_16) %qubit1_out_36 : !qco.qubit -> !qco.qubit
    %57 = qco.rx(%cst_16) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_16) %57 : !qco.qubit -> !qco.qubit
    %qubit0_out_37, %qubit1_out_38 = qco.rzz(%cst_4) %58, %40 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %59 = qco.rz(%cst_5) %qubit0_out_37 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_7) %qubit1_out_38 : !qco.qubit -> !qco.qubit
    %qubit0_out_39, %qubit1_out_40 = qco.rzz(%cst_6) %51, %60 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %61 = qco.rz(%cst_7) %qubit0_out_39 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_9) %qubit1_out_40 : !qco.qubit -> !qco.qubit
    %qubit0_out_41, %qubit1_out_42 = qco.rzz(%cst_8) %53, %62 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %63 = qco.rz(%cst_9) %qubit0_out_41 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_11) %qubit1_out_42 : !qco.qubit -> !qco.qubit
    %qubit0_out_43, %qubit1_out_44 = qco.rzz(%cst_10) %55, %64 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %65 = qco.rz(%cst_11) %qubit0_out_43 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_16) %qubit1_out_44 : !qco.qubit -> !qco.qubit
    %67 = qco.rx(%cst_16) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_16) %67 : !qco.qubit -> !qco.qubit
    %qubit0_out_45, %qubit1_out_46 = qco.rzz(%cst_4) %68, %32 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %69 = qco.rz(%cst_5) %qubit0_out_45 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_7) %qubit1_out_46 : !qco.qubit -> !qco.qubit
    %qubit0_out_47, %qubit1_out_48 = qco.rzz(%cst_6) %59, %70 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %71 = qco.rz(%cst_7) %qubit0_out_47 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_9) %qubit1_out_48 : !qco.qubit -> !qco.qubit
    %qubit0_out_49, %qubit1_out_50 = qco.rzz(%cst_8) %61, %72 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %73 = qco.rz(%cst_9) %qubit0_out_49 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_11) %qubit1_out_50 : !qco.qubit -> !qco.qubit
    %qubit0_out_51, %qubit1_out_52 = qco.rzz(%cst_10) %63, %74 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %75 = qco.rz(%cst_11) %qubit0_out_51 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_13) %qubit1_out_52 : !qco.qubit -> !qco.qubit
    %qubit0_out_53, %qubit1_out_54 = qco.rzz(%cst_12) %65, %76 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %77 = qco.rz(%cst_13) %qubit0_out_53 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_16) %qubit1_out_54 : !qco.qubit -> !qco.qubit
    %79 = qco.rx(%cst_16) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_16) %79 : !qco.qubit -> !qco.qubit
    %qubit0_out_55, %qubit1_out_56 = qco.rzz(%cst_4) %80, %30 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %81 = qco.rz(%cst_5) %qubit0_out_55 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_7) %qubit1_out_56 : !qco.qubit -> !qco.qubit
    %qubit0_out_57, %qubit1_out_58 = qco.rzz(%cst_6) %69, %82 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %83 = qco.rz(%cst_7) %qubit0_out_57 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_9) %qubit1_out_58 : !qco.qubit -> !qco.qubit
    %qubit0_out_59, %qubit1_out_60 = qco.rzz(%cst_8) %71, %84 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %85 = qco.rz(%cst_9) %qubit0_out_59 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_11) %qubit1_out_60 : !qco.qubit -> !qco.qubit
    %qubit0_out_61, %qubit1_out_62 = qco.rzz(%cst_10) %73, %86 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %87 = qco.rz(%cst_11) %qubit0_out_61 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_13) %qubit1_out_62 : !qco.qubit -> !qco.qubit
    %qubit0_out_63, %qubit1_out_64 = qco.rzz(%cst_12) %75, %88 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %89 = qco.rz(%cst_13) %qubit0_out_63 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_15) %qubit1_out_64 : !qco.qubit -> !qco.qubit
    %qubit0_out_65, %qubit1_out_66 = qco.rzz(%cst_14) %77, %90 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %91 = qco.rz(%cst_15) %qubit0_out_65 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_16) %qubit1_out_66 : !qco.qubit -> !qco.qubit
    %93 = qco.rx(%cst_16) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_16) %93 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %91 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<7>
    %qubit_out_67, %result_68 = qco.measure %89 : !qco.qubit
    cbit.store %result_68, %8[%c1] : !cbit.reg<7>
    %qubit_out_69, %result_70 = qco.measure %87 : !qco.qubit
    cbit.store %result_70, %8[%c2] : !cbit.reg<7>
    %qubit_out_71, %result_72 = qco.measure %85 : !qco.qubit
    cbit.store %result_72, %8[%c3] : !cbit.reg<7>
    %qubit_out_73, %result_74 = qco.measure %83 : !qco.qubit
    cbit.store %result_74, %8[%c4] : !cbit.reg<7>
    %qubit_out_75, %result_76 = qco.measure %81 : !qco.qubit
    cbit.store %result_76, %8[%c5] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_67 : !qco.qubit
    qco.sink %qubit_out_69 : !qco.qubit
    qco.sink %qubit_out_71 : !qco.qubit
    qco.sink %qubit_out_73 : !qco.qubit
    qco.sink %qubit_out_75 : !qco.qubit
    %qubit_out_77, %result_78 = qco.measure %94 : !qco.qubit
    qco.sink %qubit_out_77 : !qco.qubit
    cbit.store %result_78, %8[%c6] : !cbit.reg<7>
    qco.sink %37 : !qco.qubit
    %cst_79 = arith.constant 1.7548740213411724 : f64
    qco.gphase(%cst_79)
    return %8 : !cbit.reg<7>
  }
}
