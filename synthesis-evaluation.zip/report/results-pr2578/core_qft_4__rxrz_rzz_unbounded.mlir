module attributes {mqt.layout = {initial = array<i64: 3, 2, 0, 1>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 0.19634954084936229 : f64
    %cst_0 = arith.constant 0.39269908169872414 : f64
    %cst_1 = arith.constant -5.000000e-01 : f64
    %cst_2 = arith.constant 0.78539816339744828 : f64
    %cst_3 = arith.constant 1.5707963267948966 : f64
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.rz(%cst_3) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rx(%cst_3) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_3) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_2) %1 : !qco.qubit -> !qco.qubit
    %9 = arith.mulf %cst_3, %cst_1 : f64
    %qubit0_out, %qubit1_out = qco.rzz(%9) %7, %8 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_4 = arith.constant 2.3561944901923448 : f64
    %10 = qco.rz(%cst_4) %qubit0_out : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_3) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_4) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_0) %qubit1_out : !qco.qubit -> !qco.qubit
    %14 = arith.mulf %cst_2, %cst_1 : f64
    %qubit0_out_5, %qubit1_out_6 = qco.rzz(%14) %2, %13 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %15 = qco.rz(%cst_0) %qubit0_out_5 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst) %qubit1_out_6 : !qco.qubit -> !qco.qubit
    %17 = arith.mulf %cst_0, %cst_1 : f64
    %qubit0_out_7, %qubit1_out_8 = qco.rzz(%17) %3, %16 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %18 = qco.rz(%cst) %qubit0_out_7 : !qco.qubit -> !qco.qubit
    %qubit0_out_9, %qubit1_out_10 = qco.rzz(%9) %15, %12 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %19 = qco.rz(%cst_4) %qubit0_out_9 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_3) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_4) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_0) %qubit1_out_10 : !qco.qubit -> !qco.qubit
    %qubit0_out_11, %qubit1_out_12 = qco.rzz(%14) %18, %22 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %23 = qco.rz(%cst_0) %qubit0_out_11 : !qco.qubit -> !qco.qubit
    %qubit0_out_13, %qubit1_out_14 = qco.rzz(%9) %23, %21 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %24 = qco.rz(%cst_4) %qubit0_out_13 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_3) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_3) %25 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %26 : !qco.qubit
    cbit.store %result, %4[%c3] : !cbit.reg<4>
    %qubit_out_15, %result_16 = qco.measure %qubit1_out_14 : !qco.qubit
    cbit.store %result_16, %4[%c2] : !cbit.reg<4>
    %qubit_out_17, %result_18 = qco.measure %qubit1_out_12 : !qco.qubit
    cbit.store %result_18, %4[%c1] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_15 : !qco.qubit
    qco.sink %qubit_out_17 : !qco.qubit
    %qubit_out_19, %result_20 = qco.measure %qubit1_out_8 : !qco.qubit
    qco.sink %qubit_out_19 : !qco.qubit
    cbit.store %result_20, %4[%c0] : !cbit.reg<4>
    %cst_21 = arith.constant 1.6689710972195773 : f64
    qco.gphase(%cst_21)
    return %4 : !cbit.reg<4>
  }
}
