module attributes {mqt.layout = {initial = array<i64: 1, 0, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 3.1415926535897931 : f64
    %cst_0 = arith.constant 0.78539816339744828 : f64
    %cst_1 = arith.constant -2.3561944901923448 : f64
    %cst_2 = arith.constant -1.5707963267948966 : f64
    %cst_3 = arith.constant -0.78539816339744828 : f64
    %cst_4 = arith.constant 1.5707963267948966 : f64
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.rx(%cst) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.rx(%cst) %2 : !qco.qubit -> !qco.qubit
    %6 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %7 = qco.rz(%cst_2) %3 : !qco.qubit -> !qco.qubit
    %8 = qco.rx(%cst_4) %7 : !qco.qubit -> !qco.qubit
    %cst_5 = arith.constant -0.78539816339744739 : f64
    %9 = qco.rz(%cst_5) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_4) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_2) %10 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%5) targets (%arg0 = %11) {
      %47 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %47 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qco.rz(%cst_2) %targets_out : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_4) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_1) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_4) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_2) %15 : !qco.qubit -> !qco.qubit
    %controls_out_6, %targets_out_7 = qco.ctrl(%controls_out) targets (%arg0 = %16) {
      %47 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %47 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.rz(%cst_4) %targets_out_7 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_4) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_2) %18 : !qco.qubit -> !qco.qubit
    %cst_8 = arith.constant 2.3561944901923448 : f64
    %20 = qco.rz(%cst_8) %controls_out_6 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_4) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_4) %21 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%4) targets (%arg0 = %19) {
      %47 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %47 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qco.rz(%cst_3) %targets_out_10 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_4) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_4) %24 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%1) targets (%arg0 = %25) {
      %47 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %47 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.rz(%cst_2) %targets_out_12 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_4) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_1) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_4) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_2) %29 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%controls_out_11) targets (%arg0 = %30) {
      %47 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %47 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_15 = arith.constant -1.570796326794897 : f64
    %31 = qco.rz(%cst_15) %targets_out_14 : !qco.qubit -> !qco.qubit
    %32 = qco.rx(%cst_4) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_1) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_4) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_2) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_0) %controls_out_13 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%36) targets (%arg0 = %22) {
      %47 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %47 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.rz(%cst_4) %targets_out_17 : !qco.qubit -> !qco.qubit
    %38 = qco.rx(%cst_4) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_4) %38 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%39) targets (%arg0 = %35) {
      %47 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %47 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %40 = qco.rz(%cst_4) %targets_out_19 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_4) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_1) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_4) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_4) %43 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%controls_out_18) targets (%arg0 = %44) {
      %47 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %47 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.rx(%cst) %targets_out_21 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_3) %controls_out_20 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %46 : !qco.qubit
    cbit.store %result, %6[%c0] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    %qubit_out_22, %result_23 = qco.measure %45 : !qco.qubit
    qco.sink %qubit_out_22 : !qco.qubit
    cbit.store %result_23, %6[%c1] : !cbit.reg<4>
    %qubit_out_24, %result_25 = qco.measure %controls_out_16 : !qco.qubit
    cbit.store %result_25, %6[%c2] : !cbit.reg<4>
    qco.sink %qubit_out_24 : !qco.qubit
    %qubit_out_26, %result_27 = qco.measure %controls_out_9 : !qco.qubit
    qco.sink %qubit_out_26 : !qco.qubit
    cbit.store %result_27, %6[%c3] : !cbit.reg<4>
    %cst_28 = arith.constant 0.39269908169872414 : f64
    qco.gphase(%cst_28)
    return %6 : !cbit.reg<4>
  }
}
