module attributes {mqt.layout = {initial = array<i64: 1, 0, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = [], parameter_bounds = [array<f64: 0.000000e+00, 1.5707963267948966>]>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948966 : f64
    %cst_0 = arith.constant -3.1415926535897931 : f64
    %cst_1 = arith.constant 0.78539816339744828 : f64
    %cst_2 = arith.constant -0.78539816339744828 : f64
    %cst_3 = arith.constant 1.5707963267948966 : f64
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.rz(%cst_3) %0 : !qco.qubit -> !qco.qubit
    %5 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %6 = qco.rz(%cst_3) %3 : !qco.qubit -> !qco.qubit
    %7 = qco.rx(%cst_3) %6 : !qco.qubit -> !qco.qubit
    %cst_4 = arith.constant 2.3561944901923448 : f64
    %8 = qco.rz(%cst_4) %7 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_1) %2, %8 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %9 = qco.rz(%cst_1) %qubit0_out : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_0) %qubit1_out : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst) %11 : !qco.qubit -> !qco.qubit
    %qubit0_out_5, %qubit1_out_6 = qco.rzz(%cst_3) %4, %12 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %13 = qco.rz(%cst_3) %qubit1_out_6 : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_0) %13 : !qco.qubit -> !qco.qubit
    %cst_7 = arith.constant -0.78539816339744872 : f64
    %15 = qco.rz(%cst_7) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_3) %qubit0_out_5 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_0) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_3) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_3) %1 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_0) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_3) %20 : !qco.qubit -> !qco.qubit
    %qubit0_out_8, %qubit1_out_9 = qco.rzz(%cst_1) %21, %15 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_10 = arith.constant 0.78539816339744916 : f64
    %22 = qco.rz(%cst_10) %qubit0_out_8 : !qco.qubit -> !qco.qubit
    %qubit0_out_11, %qubit1_out_12 = qco.rzz(%cst_3) %22, %10 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_13 = arith.constant -1.5707963267948961 : f64
    %23 = qco.rz(%cst_13) %qubit1_out_12 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_3) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_3) %qubit0_out_11 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_0) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_3) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_2) %qubit1_out_9 : !qco.qubit -> !qco.qubit
    %qubit0_out_14, %qubit1_out_15 = qco.rzz(%cst_1) %25, %29 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %30 = qco.rz(%cst_2) %qubit0_out_14 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_3) %qubit1_out_15 : !qco.qubit -> !qco.qubit
    %32 = qco.rx(%cst_3) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_3) %32 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %30 : !qco.qubit
    cbit.store %result, %5[%c0] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    %qubit_out_16, %result_17 = qco.measure %33 : !qco.qubit
    qco.sink %qubit_out_16 : !qco.qubit
    cbit.store %result_17, %5[%c1] : !cbit.reg<4>
    %qubit_out_18, %result_19 = qco.measure %28 : !qco.qubit
    cbit.store %result_19, %5[%c2] : !cbit.reg<4>
    qco.sink %qubit_out_18 : !qco.qubit
    %qubit_out_20, %result_21 = qco.measure %18 : !qco.qubit
    qco.sink %qubit_out_20 : !qco.qubit
    cbit.store %result_21, %5[%c3] : !cbit.reg<4>
    %cst_22 = arith.constant 1.9634954084936194 : f64
    qco.gphase(%cst_22)
    return %5 : !cbit.reg<4>
  }
}
