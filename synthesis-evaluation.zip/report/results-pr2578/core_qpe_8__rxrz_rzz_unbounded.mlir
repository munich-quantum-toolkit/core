module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 7, 0>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant 2.3561944901923448 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant -3.1415926535897931 : f64
    %cst_2 = arith.constant -0.78539816339744828 : f64
    %cst_3 = arith.constant -0.39269908169872414 : f64
    %cst_4 = arith.constant -0.19634954084936229 : f64
    %cst_5 = arith.constant -0.098174770424681145 : f64
    %cst_6 = arith.constant -0.049087385212340351 : f64
    %cst_7 = arith.constant -5.000000e-01 : f64
    %cst_8 = arith.constant -0.024543692606170175 : f64
    %cst_9 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %cst_10 = arith.constant 4.7123889803846897 : f64
    %cst_11 = arith.constant -0.19634954084936207 : f64
    %cst_12 = arith.constant -0.098174770424681035 : f64
    %cst_13 = arith.constant -0.049087385212340517 : f64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %9 = qco.rz(%cst_9) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_9) %9 : !qco.qubit -> !qco.qubit
    %cst_14 = arith.constant 0.78539816339744828 : f64
    %11 = qco.rz(%cst_14) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_9) %3 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_9) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_14) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_9) %4 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_9) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_14) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_9) %5 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_9) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_9) %6 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_9) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_9) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_9) %7 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_9) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_9) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_9) %0 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_1) %26 : !qco.qubit -> !qco.qubit
    %cst_15 = arith.constant 2.7488935718910685 : f64
    %28 = qco.rz(%cst_15) %27 : !qco.qubit -> !qco.qubit
    %29 = arith.mulf %cst, %cst_7 : f64
    %qubit0_out, %qubit1_out = qco.rzz(%29) %25, %28 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_16 = arith.constant 0.3926990816987237 : f64
    %30 = qco.rz(%cst_16) %qubit0_out : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst) %qubit1_out : !qco.qubit -> !qco.qubit
    %32 = arith.mulf %cst_10, %cst_7 : f64
    %qubit0_out_17, %qubit1_out_18 = qco.rzz(%32) %22, %31 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %33 = qco.rz(%cst_9) %qubit0_out_17 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_1) %qubit1_out_18 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_0) %34 : !qco.qubit -> !qco.qubit
    %qubit0_out_19, %qubit1_out_20 = qco.rzz(%cst_0) %19, %35 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %36 = qco.rz(%cst_0) %qubit1_out_20 : !qco.qubit -> !qco.qubit
    %37 = qco.rx(%cst_1) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_9) %37 : !qco.qubit -> !qco.qubit
    %39 = arith.mulf %cst_0, %cst_7 : f64
    %qubit0_out_21, %qubit1_out_22 = qco.rzz(%39) %1, %11 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %40 = qco.rz(%cst_2) %qubit0_out_21 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_9) %qubit1_out_22 : !qco.qubit -> !qco.qubit
    %42 = qco.rx(%cst_9) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_9) %42 : !qco.qubit -> !qco.qubit
    %qubit0_out_23, %qubit1_out_24 = qco.rzz(%39) %43, %14 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %44 = qco.rz(%cst_2) %qubit0_out_23 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_3) %qubit1_out_24 : !qco.qubit -> !qco.qubit
    %46 = arith.mulf %cst_2, %cst_7 : f64
    %qubit0_out_25, %qubit1_out_26 = qco.rzz(%46) %40, %45 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %47 = qco.rz(%cst_3) %qubit0_out_25 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_9) %qubit1_out_26 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_9) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_9) %49 : !qco.qubit -> !qco.qubit
    %qubit0_out_27, %qubit1_out_28 = qco.rzz(%39) %50, %17 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %51 = qco.rz(%cst_2) %qubit0_out_27 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_3) %qubit1_out_28 : !qco.qubit -> !qco.qubit
    %qubit0_out_29, %qubit1_out_30 = qco.rzz(%46) %44, %52 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %53 = qco.rz(%cst_3) %qubit0_out_29 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_4) %qubit1_out_30 : !qco.qubit -> !qco.qubit
    %55 = arith.mulf %cst_3, %cst_7 : f64
    %qubit0_out_31, %qubit1_out_32 = qco.rzz(%55) %47, %54 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %56 = qco.rz(%cst_4) %qubit0_out_31 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_9) %qubit1_out_32 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_9) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_9) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_2) %qubit0_out_19 : !qco.qubit -> !qco.qubit
    %qubit0_out_33, %qubit1_out_34 = qco.rzz(%39) %59, %60 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %61 = qco.rz(%cst_2) %qubit0_out_33 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_3) %qubit1_out_34 : !qco.qubit -> !qco.qubit
    %qubit0_out_35, %qubit1_out_36 = qco.rzz(%46) %51, %62 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %63 = qco.rz(%cst_3) %qubit0_out_35 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_4) %qubit1_out_36 : !qco.qubit -> !qco.qubit
    %qubit0_out_37, %qubit1_out_38 = qco.rzz(%55) %53, %64 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %65 = qco.rz(%cst_4) %qubit0_out_37 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_5) %qubit1_out_38 : !qco.qubit -> !qco.qubit
    %67 = arith.mulf %cst_11, %cst_7 : f64
    %qubit0_out_39, %qubit1_out_40 = qco.rzz(%67) %56, %66 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %68 = qco.rz(%cst_5) %qubit0_out_39 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_9) %qubit1_out_40 : !qco.qubit -> !qco.qubit
    %70 = qco.rx(%cst_9) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_9) %70 : !qco.qubit -> !qco.qubit
    %qubit0_out_41, %qubit1_out_42 = qco.rzz(%39) %71, %33 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %72 = qco.rz(%cst_2) %qubit0_out_41 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_3) %qubit1_out_42 : !qco.qubit -> !qco.qubit
    %qubit0_out_43, %qubit1_out_44 = qco.rzz(%46) %61, %73 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %74 = qco.rz(%cst_3) %qubit0_out_43 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_4) %qubit1_out_44 : !qco.qubit -> !qco.qubit
    %qubit0_out_45, %qubit1_out_46 = qco.rzz(%55) %63, %75 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %76 = qco.rz(%cst_4) %qubit0_out_45 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_5) %qubit1_out_46 : !qco.qubit -> !qco.qubit
    %qubit0_out_47, %qubit1_out_48 = qco.rzz(%67) %65, %77 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %78 = qco.rz(%cst_5) %qubit0_out_47 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_6) %qubit1_out_48 : !qco.qubit -> !qco.qubit
    %80 = arith.mulf %cst_12, %cst_7 : f64
    %qubit0_out_49, %qubit1_out_50 = qco.rzz(%80) %68, %79 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %81 = qco.rz(%cst_6) %qubit0_out_49 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_9) %qubit1_out_50 : !qco.qubit -> !qco.qubit
    %83 = qco.rx(%cst_9) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_9) %83 : !qco.qubit -> !qco.qubit
    %qubit0_out_51, %qubit1_out_52 = qco.rzz(%39) %84, %30 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %85 = qco.rz(%cst_2) %qubit0_out_51 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_3) %qubit1_out_52 : !qco.qubit -> !qco.qubit
    %qubit0_out_53, %qubit1_out_54 = qco.rzz(%46) %72, %86 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %87 = qco.rz(%cst_3) %qubit0_out_53 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_4) %qubit1_out_54 : !qco.qubit -> !qco.qubit
    %qubit0_out_55, %qubit1_out_56 = qco.rzz(%55) %74, %88 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %89 = qco.rz(%cst_4) %qubit0_out_55 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_5) %qubit1_out_56 : !qco.qubit -> !qco.qubit
    %qubit0_out_57, %qubit1_out_58 = qco.rzz(%67) %76, %90 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %91 = qco.rz(%cst_5) %qubit0_out_57 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_6) %qubit1_out_58 : !qco.qubit -> !qco.qubit
    %qubit0_out_59, %qubit1_out_60 = qco.rzz(%80) %78, %92 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %93 = qco.rz(%cst_6) %qubit0_out_59 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_8) %qubit1_out_60 : !qco.qubit -> !qco.qubit
    %95 = arith.mulf %cst_13, %cst_7 : f64
    %qubit0_out_61, %qubit1_out_62 = qco.rzz(%95) %81, %94 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %96 = qco.rz(%cst_8) %qubit0_out_61 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_9) %qubit1_out_62 : !qco.qubit -> !qco.qubit
    %98 = qco.rx(%cst_9) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_9) %98 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %96 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<7>
    %qubit_out_63, %result_64 = qco.measure %93 : !qco.qubit
    cbit.store %result_64, %8[%c1] : !cbit.reg<7>
    %qubit_out_65, %result_66 = qco.measure %91 : !qco.qubit
    cbit.store %result_66, %8[%c2] : !cbit.reg<7>
    %qubit_out_67, %result_68 = qco.measure %89 : !qco.qubit
    cbit.store %result_68, %8[%c3] : !cbit.reg<7>
    %qubit_out_69, %result_70 = qco.measure %87 : !qco.qubit
    cbit.store %result_70, %8[%c4] : !cbit.reg<7>
    %qubit_out_71, %result_72 = qco.measure %85 : !qco.qubit
    cbit.store %result_72, %8[%c5] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_63 : !qco.qubit
    qco.sink %qubit_out_65 : !qco.qubit
    qco.sink %qubit_out_67 : !qco.qubit
    qco.sink %qubit_out_69 : !qco.qubit
    qco.sink %qubit_out_71 : !qco.qubit
    %qubit_out_73, %result_74 = qco.measure %99 : !qco.qubit
    qco.sink %qubit_out_73 : !qco.qubit
    cbit.store %result_74, %8[%c6] : !cbit.reg<7>
    qco.sink %38 : !qco.qubit
    %cst_75 = arith.constant 1.7548740213411722 : f64
    qco.gphase(%cst_75)
    return %8 : !cbit.reg<7>
  }
}
