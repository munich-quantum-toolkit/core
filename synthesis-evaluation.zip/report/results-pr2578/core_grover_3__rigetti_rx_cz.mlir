module attributes {mqt.layout = {initial = array<i64: 0, 1, 2>, input_count = 3 : i64, sites = array<i64: 0, 1, 2>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 0.78539816339744828 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %4 = qco.rz(%cst_1) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.rx(%cst_1) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_1) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_0) %1 : !qco.qubit -> !qco.qubit
    %8 = qco.rx(%cst_1) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_1) %8 : !qco.qubit -> !qco.qubit
    %cst_2 = arith.constant -3.1415926535897931 : f64
    %10 = qco.rz(%cst_2) %2 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%9) targets (%arg0 = %10) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qco.rz(%cst_1) %targets_out : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_1) %11 : !qco.qubit -> !qco.qubit
    %cst_3 = arith.constant -2.3561944901923448 : f64
    %13 = qco.rz(%cst_3) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_1) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_1) %14 : !qco.qubit -> !qco.qubit
    %controls_out_4, %targets_out_5 = qco.ctrl(%6) targets (%arg0 = %15) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_6 = arith.constant -1.5707963267948963 : f64
    %16 = qco.rz(%cst_6) %targets_out_5 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_1) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_3) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_1) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_0) %19 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%controls_out) targets (%arg0 = %20) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.rz(%cst_1) %targets_out_8 : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst_1) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_3) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_1) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_1) %24 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%controls_out_4) targets (%arg0 = %25) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.rz(%cst_0) %targets_out_10 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_1) %26 : !qco.qubit -> !qco.qubit
    %cst_11 = arith.constant 2.3561944901923448 : f64
    %28 = qco.rz(%cst_11) %27 : !qco.qubit -> !qco.qubit
    %cst_12 = arith.constant 2.3561944901923439 : f64
    %29 = qco.rz(%cst_12) %controls_out_7 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_1) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_0) %30 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%controls_out_9) targets (%arg0 = %31) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qco.rz(%cst_1) %targets_out_14 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_1) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_3) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_1) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_1) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst) %controls_out_13 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%37) targets (%arg0 = %36) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_17 = arith.constant 3.1415926535897931 : f64
    %38 = qco.rx(%cst_17) %targets_out_16 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_0) %controls_out_15 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_1) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_1) %40 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%38) targets (%arg0 = %28) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qco.rz(%cst_1) %targets_out_19 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_1) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_3) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rx(%cst_1) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_1) %45 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%41) targets (%arg0 = %46) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.rz(%cst_6) %targets_out_21 : !qco.qubit -> !qco.qubit
    %48 = qco.rx(%cst_1) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_3) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_1) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_0) %50 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%controls_out_18) targets (%arg0 = %51) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qco.rz(%cst_1) %targets_out_23 : !qco.qubit -> !qco.qubit
    %53 = qco.rx(%cst_1) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_3) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rx(%cst_1) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_1) %55 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%controls_out_20) targets (%arg0 = %56) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %57 = qco.rz(%cst_1) %targets_out_25 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_1) %57 : !qco.qubit -> !qco.qubit
    %cst_26 = arith.constant -2.3561944901923439 : f64
    %59 = qco.rz(%cst_26) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_12) %controls_out_22 : !qco.qubit -> !qco.qubit
    %61 = qco.rx(%cst_1) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_0) %61 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%controls_out_24) targets (%arg0 = %62) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %63 = qco.rz(%cst_1) %targets_out_28 : !qco.qubit -> !qco.qubit
    %64 = qco.rx(%cst_1) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_3) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rx(%cst_1) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_1) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst) %controls_out_27 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%68) targets (%arg0 = %67) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qco.rx(%cst_17) %targets_out_30 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_1) %controls_out_29 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_1) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_0) %71 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%69) targets (%arg0 = %59) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %73 = qco.rz(%cst_1) %targets_out_32 : !qco.qubit -> !qco.qubit
    %74 = qco.rx(%cst_1) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_3) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rx(%cst_1) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_1) %76 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%72) targets (%arg0 = %77) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %78 = qco.rz(%cst_6) %targets_out_34 : !qco.qubit -> !qco.qubit
    %79 = qco.rx(%cst_1) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_3) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rx(%cst_1) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_0) %81 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%controls_out_31) targets (%arg0 = %82) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qco.rz(%cst_1) %targets_out_36 : !qco.qubit -> !qco.qubit
    %84 = qco.rx(%cst_1) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_3) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rx(%cst_1) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_1) %86 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%controls_out_33) targets (%arg0 = %87) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %88 = qco.rz(%cst_0) %targets_out_38 : !qco.qubit -> !qco.qubit
    %89 = qco.rx(%cst_1) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_11) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_12) %controls_out_35 : !qco.qubit -> !qco.qubit
    %92 = qco.rx(%cst_1) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_0) %92 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%controls_out_37) targets (%arg0 = %93) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %94 = qco.rz(%cst_1) %targets_out_40 : !qco.qubit -> !qco.qubit
    %95 = qco.rx(%cst_1) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_3) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rx(%cst_1) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_1) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst) %controls_out_39 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%99) targets (%arg0 = %98) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %100 = qco.rx(%cst_17) %targets_out_42 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst_0) %controls_out_41 : !qco.qubit -> !qco.qubit
    %102 = qco.rx(%cst_1) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst_1) %102 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%100) targets (%arg0 = %90) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %104 = qco.rz(%cst_1) %targets_out_44 : !qco.qubit -> !qco.qubit
    %105 = qco.rx(%cst_1) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_3) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rx(%cst_1) %106 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_1) %107 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%103) targets (%arg0 = %108) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %109 = qco.rz(%cst_6) %targets_out_46 : !qco.qubit -> !qco.qubit
    %110 = qco.rx(%cst_1) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_3) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rx(%cst_1) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_0) %112 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%controls_out_43) targets (%arg0 = %113) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %114 = qco.rz(%cst_1) %targets_out_48 : !qco.qubit -> !qco.qubit
    %115 = qco.rx(%cst_1) %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst_3) %115 : !qco.qubit -> !qco.qubit
    %117 = qco.rx(%cst_1) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_1) %117 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%controls_out_45) targets (%arg0 = %118) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %119 = qco.rz(%cst_6) %targets_out_50 : !qco.qubit -> !qco.qubit
    %120 = qco.rx(%cst_1) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rz(%cst_3) %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rx(%cst_1) %121 : !qco.qubit -> !qco.qubit
    %123 = qco.rz(%cst_0) %122 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_12) %controls_out_47 : !qco.qubit -> !qco.qubit
    %125 = qco.rx(%cst_1) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst_0) %125 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%controls_out_49) targets (%arg0 = %126) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %127 = qco.rz(%cst_1) %targets_out_52 : !qco.qubit -> !qco.qubit
    %128 = qco.rx(%cst_1) %127 : !qco.qubit -> !qco.qubit
    %129 = qco.rz(%cst_3) %128 : !qco.qubit -> !qco.qubit
    %130 = qco.rx(%cst_1) %129 : !qco.qubit -> !qco.qubit
    %131 = qco.rz(%cst_1) %130 : !qco.qubit -> !qco.qubit
    %132 = qco.rz(%cst) %controls_out_51 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%132) targets (%arg0 = %131) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %133 = qco.rz(%cst_1) %controls_out_53 : !qco.qubit -> !qco.qubit
    %134 = qco.rx(%cst_1) %133 : !qco.qubit -> !qco.qubit
    %135 = qco.rz(%cst_0) %134 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %135 : !qco.qubit
    cbit.store %result, %3[%c0] : !cbit.reg<3>
    %qubit_out_55, %result_56 = qco.measure %targets_out_54 : !qco.qubit
    cbit.store %result_56, %3[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_55 : !qco.qubit
    %qubit_out_57, %result_58 = qco.measure %123 : !qco.qubit
    qco.sink %qubit_out_57 : !qco.qubit
    cbit.store %result_58, %3[%c2] : !cbit.reg<3>
    qco.gphase(%cst_17)
    return %3 : !cbit.reg<3>
  }
}
