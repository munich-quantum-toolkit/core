module attributes {mqt.layout = {initial = array<i64: 3, 2, 0, 1>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = [], parameter_bounds = [array<f64: 0.000000e+00, 1.5707963267948966>]>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 0.19634954084936229 : f64
    %cst_0 = arith.constant 0.19634954084936207 : f64
    %cst_1 = arith.constant 0.39269908169872414 : f64
    %cst_2 = arith.constant -3.1415926535897931 : f64
    %cst_3 = arith.constant 0.78539816339744828 : f64
    %cst_4 = arith.constant 1.5707963267948966 : f64
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %cst_5 = arith.constant -1.5707963267948966 : f64
    %5 = qco.rz(%cst_5) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rx(%cst_4) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_4) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_3) %1 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_3) %7, %8 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %9 = qco.rz(%cst_3) %qubit0_out : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_4) %9 : !qco.qubit -> !qco.qubit
    %cst_6 = arith.constant -0.78539816339744828 : f64
    %11 = qco.rz(%cst_6) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_1) %qubit1_out : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_4) %2 : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_2) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_4) %14 : !qco.qubit -> !qco.qubit
    %qubit0_out_7, %qubit1_out_8 = qco.rzz(%cst_1) %15, %12 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_9 = arith.constant -0.39269908169872281 : f64
    %16 = qco.rz(%cst_9) %qubit0_out_7 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst) %qubit1_out_8 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_4) %3 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_2) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_4) %19 : !qco.qubit -> !qco.qubit
    %qubit0_out_10, %qubit1_out_11 = qco.rzz(%cst_0) %20, %17 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_12 = arith.constant -0.1963495408493614 : f64
    %21 = qco.rz(%cst_12) %qubit0_out_10 : !qco.qubit -> !qco.qubit
    %qubit0_out_13, %qubit1_out_14 = qco.rzz(%cst_3) %16, %11 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %22 = qco.rz(%cst_3) %qubit0_out_13 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_4) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_6) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_1) %qubit1_out_14 : !qco.qubit -> !qco.qubit
    %qubit0_out_15, %qubit1_out_16 = qco.rzz(%cst_1) %21, %25 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %26 = qco.rz(%cst_9) %qubit0_out_15 : !qco.qubit -> !qco.qubit
    %qubit0_out_17, %qubit1_out_18 = qco.rzz(%cst_3) %26, %24 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_19 = arith.constant 0.78539816339744872 : f64
    %27 = qco.rz(%cst_19) %qubit0_out_17 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_4) %27 : !qco.qubit -> !qco.qubit
    %cst_20 = arith.constant -1.570796326794897 : f64
    %29 = qco.rz(%cst_20) %28 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %29 : !qco.qubit
    cbit.store %result, %4[%c3] : !cbit.reg<4>
    %qubit_out_21, %result_22 = qco.measure %qubit1_out_18 : !qco.qubit
    cbit.store %result_22, %4[%c2] : !cbit.reg<4>
    %qubit_out_23, %result_24 = qco.measure %qubit1_out_16 : !qco.qubit
    cbit.store %result_24, %4[%c1] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_21 : !qco.qubit
    qco.sink %qubit_out_23 : !qco.qubit
    %qubit_out_25, %result_26 = qco.measure %qubit1_out_11 : !qco.qubit
    qco.sink %qubit_out_25 : !qco.qubit
    cbit.store %result_26, %4[%c0] : !cbit.reg<4>
    %cst_27 = arith.constant -1.4726215563702141 : f64
    qco.gphase(%cst_27)
    return %4 : !cbit.reg<4>
  }
}
