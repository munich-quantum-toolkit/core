module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = [], parameter_bounds = [array<f64: 0.000000e+00, 1.5707963267948966>]>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948961 : f64
    %cst_0 = arith.constant -3.1415926535897931 : f64
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %cst_2 = arith.constant -1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.rz(%cst_2) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rx(%cst_1) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_1) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_2) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_1) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_1) %9 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_1) %7, %10 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %11 = qco.rx(%cst_1) %qubit1_out : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_2) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_1) %qubit0_out : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_0) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_2) %2 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_1) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_1) %16 : !qco.qubit -> !qco.qubit
    %qubit0_out_3, %qubit1_out_4 = qco.rzz(%cst_1) %12, %17 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %18 = qco.rx(%cst_1) %qubit1_out_4 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_2) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_1) %qubit0_out_3 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_0) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_2) %3 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_1) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_1) %23 : !qco.qubit -> !qco.qubit
    %qubit0_out_5, %qubit1_out_6 = qco.rzz(%cst_1) %19, %24 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %25 = qco.rx(%cst) %qubit1_out_6 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_1) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_1) %qubit0_out_5 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_0) %27 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %14 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<4>
    %qubit_out_7, %result_8 = qco.measure %21 : !qco.qubit
    cbit.store %result_8, %4[%c1] : !cbit.reg<4>
    %qubit_out_9, %result_10 = qco.measure %28 : !qco.qubit
    cbit.store %result_10, %4[%c2] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_7 : !qco.qubit
    qco.sink %qubit_out_9 : !qco.qubit
    %qubit_out_11, %result_12 = qco.measure %26 : !qco.qubit
    qco.sink %qubit_out_11 : !qco.qubit
    cbit.store %result_12, %4[%c3] : !cbit.reg<4>
    %cst_13 = arith.constant 2.3561944901923475 : f64
    qco.gphase(%cst_13)
    return %4 : !cbit.reg<4>
  }
}
