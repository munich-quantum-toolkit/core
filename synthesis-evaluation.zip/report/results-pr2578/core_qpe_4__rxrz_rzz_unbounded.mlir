module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 0>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 2.3561944901923448 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant -3.1415926535897931 : f64
    %cst_2 = arith.constant -0.78539816339744828 : f64
    %cst_3 = arith.constant -5.000000e-01 : f64
    %cst_4 = arith.constant -0.39269908169872414 : f64
    %cst_5 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %cst_6 = arith.constant 4.7123889803846897 : f64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %5 = qco.rz(%cst_5) %1 : !qco.qubit -> !qco.qubit
    %6 = qco.rx(%cst_5) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_5) %2 : !qco.qubit -> !qco.qubit
    %8 = qco.rx(%cst_5) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_5) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_5) %3 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_5) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_5) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_5) %0 : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_1) %13 : !qco.qubit -> !qco.qubit
    %cst_7 = arith.constant 2.7488935718910685 : f64
    %15 = qco.rz(%cst_7) %14 : !qco.qubit -> !qco.qubit
    %16 = arith.mulf %cst, %cst_3 : f64
    %qubit0_out, %qubit1_out = qco.rzz(%16) %12, %15 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_8 = arith.constant 0.3926990816987237 : f64
    %17 = qco.rz(%cst_8) %qubit0_out : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst) %qubit1_out : !qco.qubit -> !qco.qubit
    %19 = arith.mulf %cst_6, %cst_3 : f64
    %qubit0_out_9, %qubit1_out_10 = qco.rzz(%19) %9, %18 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %20 = qco.rz(%cst_5) %qubit0_out_9 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_1) %qubit1_out_10 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_0) %21 : !qco.qubit -> !qco.qubit
    %qubit0_out_11, %qubit1_out_12 = qco.rzz(%cst_0) %6, %22 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %23 = qco.rz(%cst_0) %qubit1_out_12 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_1) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_5) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_5) %qubit0_out_11 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_5) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_5) %27 : !qco.qubit -> !qco.qubit
    %29 = arith.mulf %cst_0, %cst_3 : f64
    %qubit0_out_13, %qubit1_out_14 = qco.rzz(%29) %28, %20 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %30 = qco.rz(%cst_2) %qubit0_out_13 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_5) %qubit1_out_14 : !qco.qubit -> !qco.qubit
    %32 = qco.rx(%cst_5) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_5) %32 : !qco.qubit -> !qco.qubit
    %qubit0_out_15, %qubit1_out_16 = qco.rzz(%29) %33, %17 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %34 = qco.rz(%cst_2) %qubit0_out_15 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_4) %qubit1_out_16 : !qco.qubit -> !qco.qubit
    %36 = arith.mulf %cst_2, %cst_3 : f64
    %qubit0_out_17, %qubit1_out_18 = qco.rzz(%36) %30, %35 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %37 = qco.rz(%cst_4) %qubit0_out_17 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_5) %qubit1_out_18 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_5) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_5) %39 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %37 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<3>
    %qubit_out_19, %result_20 = qco.measure %34 : !qco.qubit
    cbit.store %result_20, %4[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_19 : !qco.qubit
    %qubit_out_21, %result_22 = qco.measure %40 : !qco.qubit
    qco.sink %qubit_out_21 : !qco.qubit
    cbit.store %result_22, %4[%c2] : !cbit.reg<3>
    qco.sink %25 : !qco.qubit
    %cst_23 = arith.constant 1.5707963267948957 : f64
    qco.gphase(%cst_23)
    return %4 : !cbit.reg<3>
  }
}
