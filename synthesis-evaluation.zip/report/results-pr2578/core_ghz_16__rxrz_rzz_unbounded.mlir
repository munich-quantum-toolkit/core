module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<16> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948961 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %c15 = arith.constant 15 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<16>
    %17 = qco.rz(%cst_0) %0 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_0) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_0) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_1) %1 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_0) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_0) %21 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_1) %19, %22 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %23 = qco.rx(%cst) %qubit1_out : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_0) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_1) %qubit0_out : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_1) %2 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_0) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_0) %27 : !qco.qubit -> !qco.qubit
    %qubit0_out_2, %qubit1_out_3 = qco.rzz(%cst_1) %24, %28 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %29 = qco.rx(%cst) %qubit1_out_3 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_0) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_1) %qubit0_out_2 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_1) %3 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_0) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_0) %33 : !qco.qubit -> !qco.qubit
    %qubit0_out_4, %qubit1_out_5 = qco.rzz(%cst_1) %30, %34 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %35 = qco.rx(%cst) %qubit1_out_5 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_0) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_1) %qubit0_out_4 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_1) %4 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_0) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_0) %39 : !qco.qubit -> !qco.qubit
    %qubit0_out_6, %qubit1_out_7 = qco.rzz(%cst_1) %36, %40 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %41 = qco.rx(%cst) %qubit1_out_7 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_0) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_1) %qubit0_out_6 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_1) %5 : !qco.qubit -> !qco.qubit
    %45 = qco.rx(%cst_0) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_0) %45 : !qco.qubit -> !qco.qubit
    %qubit0_out_8, %qubit1_out_9 = qco.rzz(%cst_1) %42, %46 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %47 = qco.rx(%cst) %qubit1_out_9 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_0) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_1) %qubit0_out_8 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_1) %6 : !qco.qubit -> !qco.qubit
    %51 = qco.rx(%cst_0) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_0) %51 : !qco.qubit -> !qco.qubit
    %qubit0_out_10, %qubit1_out_11 = qco.rzz(%cst_1) %48, %52 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %53 = qco.rx(%cst) %qubit1_out_11 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_0) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_1) %qubit0_out_10 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_1) %7 : !qco.qubit -> !qco.qubit
    %57 = qco.rx(%cst_0) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_0) %57 : !qco.qubit -> !qco.qubit
    %qubit0_out_12, %qubit1_out_13 = qco.rzz(%cst_1) %54, %58 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %59 = qco.rx(%cst) %qubit1_out_13 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_0) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_1) %qubit0_out_12 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_1) %8 : !qco.qubit -> !qco.qubit
    %63 = qco.rx(%cst_0) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_0) %63 : !qco.qubit -> !qco.qubit
    %qubit0_out_14, %qubit1_out_15 = qco.rzz(%cst_1) %60, %64 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %65 = qco.rx(%cst) %qubit1_out_15 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_0) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_1) %qubit0_out_14 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_1) %9 : !qco.qubit -> !qco.qubit
    %69 = qco.rx(%cst_0) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_0) %69 : !qco.qubit -> !qco.qubit
    %qubit0_out_16, %qubit1_out_17 = qco.rzz(%cst_1) %66, %70 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %71 = qco.rx(%cst) %qubit1_out_17 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_0) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_1) %qubit0_out_16 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_1) %10 : !qco.qubit -> !qco.qubit
    %75 = qco.rx(%cst_0) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_0) %75 : !qco.qubit -> !qco.qubit
    %qubit0_out_18, %qubit1_out_19 = qco.rzz(%cst_1) %72, %76 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %77 = qco.rx(%cst) %qubit1_out_19 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_0) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_1) %qubit0_out_18 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_1) %11 : !qco.qubit -> !qco.qubit
    %81 = qco.rx(%cst_0) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_0) %81 : !qco.qubit -> !qco.qubit
    %qubit0_out_20, %qubit1_out_21 = qco.rzz(%cst_1) %78, %82 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %83 = qco.rx(%cst) %qubit1_out_21 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_0) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_1) %qubit0_out_20 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_1) %12 : !qco.qubit -> !qco.qubit
    %87 = qco.rx(%cst_0) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_0) %87 : !qco.qubit -> !qco.qubit
    %qubit0_out_22, %qubit1_out_23 = qco.rzz(%cst_1) %84, %88 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %89 = qco.rx(%cst) %qubit1_out_23 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_0) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_1) %qubit0_out_22 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_1) %13 : !qco.qubit -> !qco.qubit
    %93 = qco.rx(%cst_0) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_0) %93 : !qco.qubit -> !qco.qubit
    %qubit0_out_24, %qubit1_out_25 = qco.rzz(%cst_1) %90, %94 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %95 = qco.rx(%cst) %qubit1_out_25 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_0) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_1) %qubit0_out_24 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_1) %14 : !qco.qubit -> !qco.qubit
    %99 = qco.rx(%cst_0) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_0) %99 : !qco.qubit -> !qco.qubit
    %qubit0_out_26, %qubit1_out_27 = qco.rzz(%cst_1) %96, %100 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %101 = qco.rx(%cst) %qubit1_out_27 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_0) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst_1) %qubit0_out_26 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_1) %15 : !qco.qubit -> !qco.qubit
    %105 = qco.rx(%cst_0) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_0) %105 : !qco.qubit -> !qco.qubit
    %qubit0_out_28, %qubit1_out_29 = qco.rzz(%cst_1) %102, %106 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %107 = qco.rx(%cst) %qubit1_out_29 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_0) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rz(%cst_1) %qubit0_out_28 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %25 : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<16>
    %qubit_out_30, %result_31 = qco.measure %31 : !qco.qubit
    cbit.store %result_31, %16[%c1] : !cbit.reg<16>
    %qubit_out_32, %result_33 = qco.measure %37 : !qco.qubit
    cbit.store %result_33, %16[%c2] : !cbit.reg<16>
    %qubit_out_34, %result_35 = qco.measure %43 : !qco.qubit
    cbit.store %result_35, %16[%c3] : !cbit.reg<16>
    %qubit_out_36, %result_37 = qco.measure %49 : !qco.qubit
    cbit.store %result_37, %16[%c4] : !cbit.reg<16>
    %qubit_out_38, %result_39 = qco.measure %55 : !qco.qubit
    cbit.store %result_39, %16[%c5] : !cbit.reg<16>
    %qubit_out_40, %result_41 = qco.measure %61 : !qco.qubit
    cbit.store %result_41, %16[%c6] : !cbit.reg<16>
    %qubit_out_42, %result_43 = qco.measure %67 : !qco.qubit
    cbit.store %result_43, %16[%c7] : !cbit.reg<16>
    %qubit_out_44, %result_45 = qco.measure %73 : !qco.qubit
    cbit.store %result_45, %16[%c8] : !cbit.reg<16>
    %qubit_out_46, %result_47 = qco.measure %79 : !qco.qubit
    cbit.store %result_47, %16[%c9] : !cbit.reg<16>
    %qubit_out_48, %result_49 = qco.measure %85 : !qco.qubit
    cbit.store %result_49, %16[%c10] : !cbit.reg<16>
    %qubit_out_50, %result_51 = qco.measure %91 : !qco.qubit
    cbit.store %result_51, %16[%c11] : !cbit.reg<16>
    %qubit_out_52, %result_53 = qco.measure %97 : !qco.qubit
    cbit.store %result_53, %16[%c12] : !cbit.reg<16>
    %qubit_out_54, %result_55 = qco.measure %103 : !qco.qubit
    cbit.store %result_55, %16[%c13] : !cbit.reg<16>
    %qubit_out_56, %result_57 = qco.measure %109 : !qco.qubit
    cbit.store %result_57, %16[%c14] : !cbit.reg<16>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_30 : !qco.qubit
    qco.sink %qubit_out_32 : !qco.qubit
    qco.sink %qubit_out_34 : !qco.qubit
    qco.sink %qubit_out_36 : !qco.qubit
    qco.sink %qubit_out_38 : !qco.qubit
    qco.sink %qubit_out_40 : !qco.qubit
    qco.sink %qubit_out_42 : !qco.qubit
    qco.sink %qubit_out_44 : !qco.qubit
    qco.sink %qubit_out_46 : !qco.qubit
    qco.sink %qubit_out_48 : !qco.qubit
    qco.sink %qubit_out_50 : !qco.qubit
    qco.sink %qubit_out_52 : !qco.qubit
    qco.sink %qubit_out_54 : !qco.qubit
    qco.sink %qubit_out_56 : !qco.qubit
    %qubit_out_58, %result_59 = qco.measure %108 : !qco.qubit
    qco.sink %qubit_out_58 : !qco.qubit
    cbit.store %result_59, %16[%c15] : !cbit.reg<16>
    %cst_60 = arith.constant 2.3561944901923448 : f64
    qco.gphase(%cst_60)
    return %16 : !cbit.reg<16>
  }
}
