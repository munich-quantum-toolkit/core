module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<15> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948966 : f64
    %cst_0 = arith.constant 3.1415926535897931 : f64
    %cst_1 = arith.constant -3.1415926535897931 : f64
    %cst_2 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<15>
    %17 = qco.rx(%cst_2) %0 : !qco.qubit -> !qco.qubit
    %cst_3 = arith.constant -1.570796326794897 : f64
    %18 = qco.rz(%cst_3) %1 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_2) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_3) %3 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_2) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_3) %5 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_2) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_3) %7 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_2) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_3) %9 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_2) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_3) %11 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_2) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_3) %13 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_2) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_3) %15 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_2) %32 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %19, %17 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %34 = qco.rx(%cst_0) %qubit1_out : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_1) %qubit0_out : !qco.qubit -> !qco.qubit
    %37 = qco.rx(%cst_2) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst) %37 : !qco.qubit -> !qco.qubit
    %qubit0_out_4, %qubit1_out_5 = qco.iswap %38, %35 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %39 = qco.rz(%cst_1) %qubit1_out_5 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_2) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_2) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_1) %qubit0_out_4 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_2) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_2) %43 : !qco.qubit -> !qco.qubit
    %qubit0_out_6, %qubit1_out_7 = qco.iswap %21, %41 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %45 = qco.rx(%cst_0) %qubit1_out_7 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_1) %qubit0_out_6 : !qco.qubit -> !qco.qubit
    %48 = qco.rx(%cst_2) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst) %48 : !qco.qubit -> !qco.qubit
    %qubit0_out_8, %qubit1_out_9 = qco.iswap %49, %46 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %50 = qco.rz(%cst_1) %qubit1_out_9 : !qco.qubit -> !qco.qubit
    %51 = qco.rx(%cst_2) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_2) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_1) %qubit0_out_8 : !qco.qubit -> !qco.qubit
    %54 = qco.rx(%cst_2) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_2) %54 : !qco.qubit -> !qco.qubit
    %qubit0_out_10, %qubit1_out_11 = qco.iswap %23, %52 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %56 = qco.rx(%cst_0) %qubit1_out_11 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_1) %qubit0_out_10 : !qco.qubit -> !qco.qubit
    %59 = qco.rx(%cst_2) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst) %59 : !qco.qubit -> !qco.qubit
    %qubit0_out_12, %qubit1_out_13 = qco.iswap %60, %57 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %61 = qco.rz(%cst_1) %qubit1_out_13 : !qco.qubit -> !qco.qubit
    %62 = qco.rx(%cst_2) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_2) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_1) %qubit0_out_12 : !qco.qubit -> !qco.qubit
    %65 = qco.rx(%cst_2) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_2) %65 : !qco.qubit -> !qco.qubit
    %qubit0_out_14, %qubit1_out_15 = qco.iswap %25, %63 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %67 = qco.rx(%cst_0) %qubit1_out_15 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_1) %qubit0_out_14 : !qco.qubit -> !qco.qubit
    %70 = qco.rx(%cst_2) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst) %70 : !qco.qubit -> !qco.qubit
    %qubit0_out_16, %qubit1_out_17 = qco.iswap %71, %68 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %72 = qco.rz(%cst_1) %qubit1_out_17 : !qco.qubit -> !qco.qubit
    %73 = qco.rx(%cst_2) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_2) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_1) %qubit0_out_16 : !qco.qubit -> !qco.qubit
    %76 = qco.rx(%cst_2) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_2) %76 : !qco.qubit -> !qco.qubit
    %qubit0_out_18, %qubit1_out_19 = qco.iswap %27, %74 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %78 = qco.rx(%cst_0) %qubit1_out_19 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_1) %qubit0_out_18 : !qco.qubit -> !qco.qubit
    %81 = qco.rx(%cst_2) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst) %81 : !qco.qubit -> !qco.qubit
    %qubit0_out_20, %qubit1_out_21 = qco.iswap %82, %79 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %83 = qco.rz(%cst_1) %qubit1_out_21 : !qco.qubit -> !qco.qubit
    %84 = qco.rx(%cst_2) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_2) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_1) %qubit0_out_20 : !qco.qubit -> !qco.qubit
    %87 = qco.rx(%cst_2) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_2) %87 : !qco.qubit -> !qco.qubit
    %qubit0_out_22, %qubit1_out_23 = qco.iswap %29, %85 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %89 = qco.rx(%cst_0) %qubit1_out_23 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_1) %qubit0_out_22 : !qco.qubit -> !qco.qubit
    %92 = qco.rx(%cst_2) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst) %92 : !qco.qubit -> !qco.qubit
    %qubit0_out_24, %qubit1_out_25 = qco.iswap %93, %90 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %94 = qco.rz(%cst_1) %qubit1_out_25 : !qco.qubit -> !qco.qubit
    %95 = qco.rx(%cst_2) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_2) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_1) %qubit0_out_24 : !qco.qubit -> !qco.qubit
    %98 = qco.rx(%cst_2) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_2) %98 : !qco.qubit -> !qco.qubit
    %qubit0_out_26, %qubit1_out_27 = qco.iswap %31, %96 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %100 = qco.rx(%cst_0) %qubit1_out_27 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_1) %qubit0_out_26 : !qco.qubit -> !qco.qubit
    %103 = qco.rx(%cst_2) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst) %103 : !qco.qubit -> !qco.qubit
    %qubit0_out_28, %qubit1_out_29 = qco.iswap %104, %101 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %105 = qco.rz(%cst_1) %qubit1_out_29 : !qco.qubit -> !qco.qubit
    %106 = qco.rx(%cst_2) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rz(%cst_2) %106 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_1) %qubit0_out_28 : !qco.qubit -> !qco.qubit
    %109 = qco.rx(%cst_2) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst_2) %109 : !qco.qubit -> !qco.qubit
    %qubit0_out_30, %qubit1_out_31 = qco.iswap %33, %107 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %111 = qco.rx(%cst_0) %qubit1_out_31 : !qco.qubit -> !qco.qubit
    %112 = qco.rz(%cst) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_1) %qubit0_out_30 : !qco.qubit -> !qco.qubit
    %114 = qco.rx(%cst_2) %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst) %114 : !qco.qubit -> !qco.qubit
    %qubit0_out_32, %qubit1_out_33 = qco.iswap %115, %112 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %116 = qco.rz(%cst) %qubit1_out_33 : !qco.qubit -> !qco.qubit
    %117 = qco.rx(%cst_2) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_2) %117 : !qco.qubit -> !qco.qubit
    %119 = qco.rz(%cst_1) %qubit0_out_32 : !qco.qubit -> !qco.qubit
    %120 = qco.rx(%cst_2) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rz(%cst_2) %120 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %44 : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<15>
    %qubit_out_34, %result_35 = qco.measure %2 : !qco.qubit
    cbit.store %result_35, %16[%c1] : !cbit.reg<15>
    %qubit_out_36, %result_37 = qco.measure %55 : !qco.qubit
    cbit.store %result_37, %16[%c2] : !cbit.reg<15>
    %qubit_out_38, %result_39 = qco.measure %4 : !qco.qubit
    cbit.store %result_39, %16[%c3] : !cbit.reg<15>
    %qubit_out_40, %result_41 = qco.measure %66 : !qco.qubit
    cbit.store %result_41, %16[%c4] : !cbit.reg<15>
    %qubit_out_42, %result_43 = qco.measure %6 : !qco.qubit
    cbit.store %result_43, %16[%c5] : !cbit.reg<15>
    %qubit_out_44, %result_45 = qco.measure %77 : !qco.qubit
    cbit.store %result_45, %16[%c6] : !cbit.reg<15>
    %qubit_out_46, %result_47 = qco.measure %8 : !qco.qubit
    cbit.store %result_47, %16[%c7] : !cbit.reg<15>
    %qubit_out_48, %result_49 = qco.measure %88 : !qco.qubit
    cbit.store %result_49, %16[%c8] : !cbit.reg<15>
    %qubit_out_50, %result_51 = qco.measure %10 : !qco.qubit
    cbit.store %result_51, %16[%c9] : !cbit.reg<15>
    %qubit_out_52, %result_53 = qco.measure %99 : !qco.qubit
    cbit.store %result_53, %16[%c10] : !cbit.reg<15>
    %qubit_out_54, %result_55 = qco.measure %12 : !qco.qubit
    cbit.store %result_55, %16[%c11] : !cbit.reg<15>
    %qubit_out_56, %result_57 = qco.measure %110 : !qco.qubit
    cbit.store %result_57, %16[%c12] : !cbit.reg<15>
    %qubit_out_58, %result_59 = qco.measure %14 : !qco.qubit
    cbit.store %result_59, %16[%c13] : !cbit.reg<15>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_34 : !qco.qubit
    qco.sink %qubit_out_36 : !qco.qubit
    qco.sink %qubit_out_38 : !qco.qubit
    qco.sink %qubit_out_40 : !qco.qubit
    qco.sink %qubit_out_42 : !qco.qubit
    qco.sink %qubit_out_44 : !qco.qubit
    qco.sink %qubit_out_46 : !qco.qubit
    qco.sink %qubit_out_48 : !qco.qubit
    qco.sink %qubit_out_50 : !qco.qubit
    qco.sink %qubit_out_52 : !qco.qubit
    qco.sink %qubit_out_54 : !qco.qubit
    qco.sink %qubit_out_56 : !qco.qubit
    qco.sink %qubit_out_58 : !qco.qubit
    %qubit_out_60, %result_61 = qco.measure %121 : !qco.qubit
    qco.sink %qubit_out_60 : !qco.qubit
    cbit.store %result_61, %16[%c14] : !cbit.reg<15>
    qco.sink %118 : !qco.qubit
    %cst_62 = arith.constant 1.5707963267948895 : f64
    qco.gphase(%cst_62)
    return %16 : !cbit.reg<15>
  }
}
