module attributes {mqt.layout = {initial = array<i64: 1, 2, 0>, input_count = 3 : i64, sites = array<i64: 0, 1, 2>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "gpi", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = [], fixed_parameters = [3.1415926535897931, unit], canonical_name = "r">, <name = "gpi2", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = [], fixed_parameters = [1.5707963267948966, unit], canonical_name = "r">, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant -5.000000e-01 : f64
    %cst_0 = arith.constant -3.1415926535897931 : f64
    %cst_1 = arith.constant 0.000000e+00 : f64
    %cst_2 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %cst_3 = arith.constant 0.78539816339744828 : f64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %4 = qco.rz(%cst_2) %1 : !qco.qubit -> !qco.qubit
    %5 = qco.r(%cst_2, %cst_1) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_2) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_2) %2 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_2, %cst_1) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_2) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_2, %cst_1) %0 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_3) %10 : !qco.qubit -> !qco.qubit
    %12 = arith.mulf %cst_2, %cst : f64
    %qubit0_out, %qubit1_out = qco.rzz(%12) %9, %11 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_4 = arith.constant 0.39269908169872458 : f64
    %13 = qco.rz(%cst_4) %qubit1_out : !qco.qubit -> !qco.qubit
    %14 = arith.mulf %cst_3, %cst : f64
    %qubit0_out_5, %qubit1_out_6 = qco.rzz(%14) %6, %13 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %15 = qco.rz(%cst_0) %qubit1_out_6 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_2, %cst_1) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_0) %16 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %17 : !qco.qubit
    cbit.store %result, %3[%c0] : !cbit.reg<3>
    %qubit_out_7, %result_8 = qco.measure %qubit0_out_5 : !qco.qubit
    cbit.store %result_8, %3[%c1] : !cbit.reg<3>
    qco.sink %qubit_out_7 : !qco.qubit
    %qubit_out_9, %result_10 = qco.measure %qubit0_out : !qco.qubit
    qco.sink %qubit_out_9 : !qco.qubit
    cbit.store %result_10, %3[%c2] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    return %3 : !cbit.reg<3>
  }
}
