module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 0>, input_count = 7 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant -2.3561944901923448 : f64
    %cst_0 = arith.constant -2.7488935718910685 : f64
    %cst_1 = arith.constant -2.9452431127404308 : f64
    %cst_2 = arith.constant -3.0434178831651124 : f64
    %cst_3 = arith.constant -3.0925052683774528 : f64
    %cst_4 = arith.constant 1.5707963267948966 : f64
    %cst_5 = arith.constant -1.5707963267948966 : f64
    %cst_6 = arith.constant -3.1170489609836229 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %8 = qco.rz(%cst_4) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.sx %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_4) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_4) %2 : !qco.qubit -> !qco.qubit
    %12 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_4) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_4) %3 : !qco.qubit -> !qco.qubit
    %15 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_4) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_4) %4 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_4) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_4) %5 : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_4) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_4) %6 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_4) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.sx %0 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_4) %28 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%25) targets (%arg0 = %29) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.rz(%cst_5) %targets_out : !qco.qubit -> !qco.qubit
    %31 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.sx %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_5) %33 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%controls_out) targets (%arg0 = %34) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.rz(%cst_4) %targets_out_8 : !qco.qubit -> !qco.qubit
    %36 = qco.sx %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_0) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.sx %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_4) %38 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%22) targets (%arg0 = %39) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %40 = qco.rz(%cst_5) %targets_out_10 : !qco.qubit -> !qco.qubit
    %41 = qco.sx %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_0) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_5) %43 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%controls_out_9) targets (%arg0 = %44) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.rz(%cst_4) %targets_out_12 : !qco.qubit -> !qco.qubit
    %46 = qco.sx %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_1) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_4) %48 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%19) targets (%arg0 = %49) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qco.rz(%cst_5) %targets_out_14 : !qco.qubit -> !qco.qubit
    %51 = qco.sx %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_1) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_5) %53 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%controls_out_13) targets (%arg0 = %54) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.rz(%cst_4) %targets_out_16 : !qco.qubit -> !qco.qubit
    %56 = qco.sx %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_2) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.sx %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_4) %58 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%16) targets (%arg0 = %59) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qco.rz(%cst_5) %targets_out_18 : !qco.qubit -> !qco.qubit
    %61 = qco.sx %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_2) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.sx %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_5) %63 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%controls_out_17) targets (%arg0 = %64) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qco.rz(%cst_4) %targets_out_20 : !qco.qubit -> !qco.qubit
    %66 = qco.sx %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_3) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.sx %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_4) %68 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%13) targets (%arg0 = %69) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %70 = qco.rz(%cst_5) %targets_out_22 : !qco.qubit -> !qco.qubit
    %71 = qco.sx %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_3) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.sx %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_5) %73 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%controls_out_21) targets (%arg0 = %74) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %75 = qco.rz(%cst_4) %targets_out_24 : !qco.qubit -> !qco.qubit
    %76 = qco.sx %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_6) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.sx %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_4) %78 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%10) targets (%arg0 = %79) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %80 = qco.rz(%cst_5) %targets_out_26 : !qco.qubit -> !qco.qubit
    %81 = qco.sx %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_6) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.sx %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_5) %83 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%controls_out_25) targets (%arg0 = %84) {
      %86 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %86 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %85 = qco.rz(%cst_4) %targets_out_28 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %85 : !qco.qubit
    cbit.store %result, %7[%c0] : !cbit.reg<7>
    %qubit_out_29, %result_30 = qco.measure %controls_out_27 : !qco.qubit
    cbit.store %result_30, %7[%c1] : !cbit.reg<7>
    %qubit_out_31, %result_32 = qco.measure %controls_out_23 : !qco.qubit
    cbit.store %result_32, %7[%c2] : !cbit.reg<7>
    %qubit_out_33, %result_34 = qco.measure %controls_out_19 : !qco.qubit
    cbit.store %result_34, %7[%c3] : !cbit.reg<7>
    %qubit_out_35, %result_36 = qco.measure %controls_out_15 : !qco.qubit
    cbit.store %result_36, %7[%c4] : !cbit.reg<7>
    %qubit_out_37, %result_38 = qco.measure %controls_out_11 : !qco.qubit
    cbit.store %result_38, %7[%c5] : !cbit.reg<7>
    qco.sink %qubit_out_29 : !qco.qubit
    qco.sink %qubit_out_31 : !qco.qubit
    qco.sink %qubit_out_33 : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    qco.sink %qubit_out_37 : !qco.qubit
    %qubit_out_39, %result_40 = qco.measure %controls_out_7 : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    cbit.store %result_40, %7[%c6] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    qco.gphase(%cst_5)
    return %7 : !cbit.reg<7>
  }
}
