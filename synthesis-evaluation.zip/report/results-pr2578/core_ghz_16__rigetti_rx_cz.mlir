module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<16> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948966 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %c15 = arith.constant 15 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<16>
    %17 = qco.rz(%cst_0) %0 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_0) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_0) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_0) %1 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_0) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst) %21 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%19) targets (%arg0 = %22) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qco.rz(%cst) %targets_out : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_0) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_0) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_0) %2 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_0) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst) %27 : !qco.qubit -> !qco.qubit
    %controls_out_1, %targets_out_2 = qco.ctrl(%25) targets (%arg0 = %28) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.rz(%cst) %targets_out_2 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_0) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_0) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_0) %3 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_0) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst) %33 : !qco.qubit -> !qco.qubit
    %controls_out_3, %targets_out_4 = qco.ctrl(%31) targets (%arg0 = %34) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.rz(%cst) %targets_out_4 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_0) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_0) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_0) %4 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_0) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst) %39 : !qco.qubit -> !qco.qubit
    %controls_out_5, %targets_out_6 = qco.ctrl(%37) targets (%arg0 = %40) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.rz(%cst) %targets_out_6 : !qco.qubit -> !qco.qubit
    %42 = qco.rx(%cst_0) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_0) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_0) %5 : !qco.qubit -> !qco.qubit
    %45 = qco.rx(%cst_0) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst) %45 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%43) targets (%arg0 = %46) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.rz(%cst) %targets_out_8 : !qco.qubit -> !qco.qubit
    %48 = qco.rx(%cst_0) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_0) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_0) %6 : !qco.qubit -> !qco.qubit
    %51 = qco.rx(%cst_0) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst) %51 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%49) targets (%arg0 = %52) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qco.rz(%cst) %targets_out_10 : !qco.qubit -> !qco.qubit
    %54 = qco.rx(%cst_0) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_0) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_0) %7 : !qco.qubit -> !qco.qubit
    %57 = qco.rx(%cst_0) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst) %57 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%55) targets (%arg0 = %58) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qco.rz(%cst) %targets_out_12 : !qco.qubit -> !qco.qubit
    %60 = qco.rx(%cst_0) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_0) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_0) %8 : !qco.qubit -> !qco.qubit
    %63 = qco.rx(%cst_0) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst) %63 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%61) targets (%arg0 = %64) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qco.rz(%cst) %targets_out_14 : !qco.qubit -> !qco.qubit
    %66 = qco.rx(%cst_0) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_0) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_0) %9 : !qco.qubit -> !qco.qubit
    %69 = qco.rx(%cst_0) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst) %69 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%67) targets (%arg0 = %70) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qco.rz(%cst) %targets_out_16 : !qco.qubit -> !qco.qubit
    %72 = qco.rx(%cst_0) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_0) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_0) %10 : !qco.qubit -> !qco.qubit
    %75 = qco.rx(%cst_0) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst) %75 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%73) targets (%arg0 = %76) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qco.rz(%cst) %targets_out_18 : !qco.qubit -> !qco.qubit
    %78 = qco.rx(%cst_0) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_0) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_0) %11 : !qco.qubit -> !qco.qubit
    %81 = qco.rx(%cst_0) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst) %81 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%79) targets (%arg0 = %82) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qco.rz(%cst) %targets_out_20 : !qco.qubit -> !qco.qubit
    %84 = qco.rx(%cst_0) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_0) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_0) %12 : !qco.qubit -> !qco.qubit
    %87 = qco.rx(%cst_0) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst) %87 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%85) targets (%arg0 = %88) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %89 = qco.rz(%cst) %targets_out_22 : !qco.qubit -> !qco.qubit
    %90 = qco.rx(%cst_0) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_0) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_0) %13 : !qco.qubit -> !qco.qubit
    %93 = qco.rx(%cst_0) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst) %93 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%91) targets (%arg0 = %94) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %95 = qco.rz(%cst) %targets_out_24 : !qco.qubit -> !qco.qubit
    %96 = qco.rx(%cst_0) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_0) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_0) %14 : !qco.qubit -> !qco.qubit
    %99 = qco.rx(%cst_0) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst) %99 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%97) targets (%arg0 = %100) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %101 = qco.rz(%cst) %targets_out_26 : !qco.qubit -> !qco.qubit
    %102 = qco.rx(%cst_0) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst_0) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_0) %15 : !qco.qubit -> !qco.qubit
    %105 = qco.rx(%cst_0) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst) %105 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%103) targets (%arg0 = %106) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %107 = qco.rz(%cst) %targets_out_28 : !qco.qubit -> !qco.qubit
    %108 = qco.rx(%cst_0) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rz(%cst_0) %108 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %controls_out : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<16>
    %qubit_out_29, %result_30 = qco.measure %controls_out_1 : !qco.qubit
    cbit.store %result_30, %16[%c1] : !cbit.reg<16>
    %qubit_out_31, %result_32 = qco.measure %controls_out_3 : !qco.qubit
    cbit.store %result_32, %16[%c2] : !cbit.reg<16>
    %qubit_out_33, %result_34 = qco.measure %controls_out_5 : !qco.qubit
    cbit.store %result_34, %16[%c3] : !cbit.reg<16>
    %qubit_out_35, %result_36 = qco.measure %controls_out_7 : !qco.qubit
    cbit.store %result_36, %16[%c4] : !cbit.reg<16>
    %qubit_out_37, %result_38 = qco.measure %controls_out_9 : !qco.qubit
    cbit.store %result_38, %16[%c5] : !cbit.reg<16>
    %qubit_out_39, %result_40 = qco.measure %controls_out_11 : !qco.qubit
    cbit.store %result_40, %16[%c6] : !cbit.reg<16>
    %qubit_out_41, %result_42 = qco.measure %controls_out_13 : !qco.qubit
    cbit.store %result_42, %16[%c7] : !cbit.reg<16>
    %qubit_out_43, %result_44 = qco.measure %controls_out_15 : !qco.qubit
    cbit.store %result_44, %16[%c8] : !cbit.reg<16>
    %qubit_out_45, %result_46 = qco.measure %controls_out_17 : !qco.qubit
    cbit.store %result_46, %16[%c9] : !cbit.reg<16>
    %qubit_out_47, %result_48 = qco.measure %controls_out_19 : !qco.qubit
    cbit.store %result_48, %16[%c10] : !cbit.reg<16>
    %qubit_out_49, %result_50 = qco.measure %controls_out_21 : !qco.qubit
    cbit.store %result_50, %16[%c11] : !cbit.reg<16>
    %qubit_out_51, %result_52 = qco.measure %controls_out_23 : !qco.qubit
    cbit.store %result_52, %16[%c12] : !cbit.reg<16>
    %qubit_out_53, %result_54 = qco.measure %controls_out_25 : !qco.qubit
    cbit.store %result_54, %16[%c13] : !cbit.reg<16>
    %qubit_out_55, %result_56 = qco.measure %controls_out_27 : !qco.qubit
    cbit.store %result_56, %16[%c14] : !cbit.reg<16>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_29 : !qco.qubit
    qco.sink %qubit_out_31 : !qco.qubit
    qco.sink %qubit_out_33 : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    qco.sink %qubit_out_37 : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    qco.sink %qubit_out_41 : !qco.qubit
    qco.sink %qubit_out_43 : !qco.qubit
    qco.sink %qubit_out_45 : !qco.qubit
    qco.sink %qubit_out_47 : !qco.qubit
    qco.sink %qubit_out_49 : !qco.qubit
    qco.sink %qubit_out_51 : !qco.qubit
    qco.sink %qubit_out_53 : !qco.qubit
    qco.sink %qubit_out_55 : !qco.qubit
    %qubit_out_57, %result_58 = qco.measure %109 : !qco.qubit
    qco.sink %qubit_out_57 : !qco.qubit
    cbit.store %result_58, %16[%c15] : !cbit.reg<16>
    qco.gphase(%cst_0)
    return %16 : !cbit.reg<16>
  }
}
