module attributes {mqt.layout = {initial = array<i64: 1, 2, 0>, input_count = 3 : i64, sites = array<i64: 0, 1, 2>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = [], parameter_bounds = [array<f64: 0.000000e+00, 1.5707963267948966>]>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 0.78539816339744828 : f64
    %cst_0 = arith.constant -3.1415926535897931 : f64
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %cst_2 = arith.constant 0.39269908169872414 : f64
    %cst_3 = arith.constant -1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %4 = qco.rz(%cst_3) %1 : !qco.qubit -> !qco.qubit
    %5 = qco.rx(%cst_1) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_1) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_3) %2 : !qco.qubit -> !qco.qubit
    %8 = qco.rx(%cst_1) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_1) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_1) %0 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst) %10 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst) %9, %11 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %12 = qco.rz(%cst_1) %qubit0_out : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_0) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_1) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_2) %qubit1_out : !qco.qubit -> !qco.qubit
    %qubit0_out_4, %qubit1_out_5 = qco.rzz(%cst_2) %6, %15 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %16 = qco.rz(%cst_1) %qubit0_out_4 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_0) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_1) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_3) %qubit1_out_5 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %19 : !qco.qubit
    cbit.store %result, %3[%c0] : !cbit.reg<3>
    %qubit_out_6, %result_7 = qco.measure %18 : !qco.qubit
    cbit.store %result_7, %3[%c1] : !cbit.reg<3>
    qco.sink %qubit_out_6 : !qco.qubit
    %qubit_out_8, %result_9 = qco.measure %14 : !qco.qubit
    qco.sink %qubit_out_8 : !qco.qubit
    cbit.store %result_9, %3[%c2] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    %cst_10 = arith.constant 3.1415926535897931 : f64
    qco.gphase(%cst_10)
    return %3 : !cbit.reg<3>
  }
}
