module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948966 : f64
    %cst_0 = arith.constant 3.1415926535897931 : f64
    %cst_1 = arith.constant -1.5707963267948974 : f64
    %cst_2 = arith.constant 1.5707963267948966 : f64
    %cst_3 = arith.constant -3.1415926535897931 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %cst_4 = arith.constant -1.570796326794897 : f64
    %5 = qco.rz(%cst_4) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rx(%cst_2) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_3) %1 : !qco.qubit -> !qco.qubit
    %8 = qco.rx(%cst_2) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_1) %8 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %6, %9 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %10 = qco.rx(%cst_0) %qubit1_out : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_3) %qubit0_out : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_2) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst) %13 : !qco.qubit -> !qco.qubit
    %qubit0_out_5, %qubit1_out_6 = qco.iswap %14, %11 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %15 = qco.rz(%cst_2) %qubit1_out_6 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_2) %qubit0_out_5 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_3) %2 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_2) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_1) %18 : !qco.qubit -> !qco.qubit
    %qubit0_out_7, %qubit1_out_8 = qco.iswap %15, %19 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %20 = qco.rx(%cst_0) %qubit1_out_8 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_3) %qubit0_out_7 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_2) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst) %23 : !qco.qubit -> !qco.qubit
    %qubit0_out_9, %qubit1_out_10 = qco.iswap %24, %21 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %25 = qco.rz(%cst_2) %qubit1_out_10 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_2) %qubit0_out_9 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_3) %3 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_2) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_1) %28 : !qco.qubit -> !qco.qubit
    %qubit0_out_11, %qubit1_out_12 = qco.iswap %25, %29 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %30 = qco.rx(%cst_0) %qubit1_out_12 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_3) %qubit0_out_11 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_2) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst) %33 : !qco.qubit -> !qco.qubit
    %qubit0_out_13, %qubit1_out_14 = qco.iswap %34, %31 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %35 = qco.rx(%cst_0) %qubit1_out_14 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_3) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_2) %qubit0_out_13 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %16 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<4>
    %qubit_out_15, %result_16 = qco.measure %26 : !qco.qubit
    cbit.store %result_16, %4[%c1] : !cbit.reg<4>
    %qubit_out_17, %result_18 = qco.measure %37 : !qco.qubit
    cbit.store %result_18, %4[%c2] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_15 : !qco.qubit
    qco.sink %qubit_out_17 : !qco.qubit
    %qubit_out_19, %result_20 = qco.measure %36 : !qco.qubit
    qco.sink %qubit_out_19 : !qco.qubit
    cbit.store %result_20, %4[%c3] : !cbit.reg<4>
    %cst_21 = arith.constant 2.3561944901923422 : f64
    qco.gphase(%cst_21)
    return %4 : !cbit.reg<4>
  }
}
