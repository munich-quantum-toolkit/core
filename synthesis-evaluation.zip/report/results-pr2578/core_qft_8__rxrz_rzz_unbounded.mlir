module attributes {mqt.layout = {initial = array<i64: 7, 6, 5, 4, 0, 1, 2, 3>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant 0.012271846303085088 : f64
    %cst_0 = arith.constant 0.024543692606170175 : f64
    %cst_1 = arith.constant 0.049087385212340351 : f64
    %cst_2 = arith.constant 0.098174770424681145 : f64
    %cst_3 = arith.constant 0.19634954084936229 : f64
    %cst_4 = arith.constant 0.39269908169872414 : f64
    %cst_5 = arith.constant -5.000000e-01 : f64
    %cst_6 = arith.constant 0.78539816339744828 : f64
    %cst_7 = arith.constant 1.5707963267948966 : f64
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %cst_8 = arith.constant 0.19634954084936207 : f64
    %cst_9 = arith.constant 0.098174770424681035 : f64
    %cst_10 = arith.constant 0.049087385212340517 : f64
    %cst_11 = arith.constant 0.024543692606170259 : f64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %9 = qco.rz(%cst_7) %0 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_7) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_7) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_7) %1 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_7) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_7) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_7) %2 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_7) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_7) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_6) %3 : !qco.qubit -> !qco.qubit
    %19 = arith.mulf %cst_7, %cst_5 : f64
    %qubit0_out, %qubit1_out = qco.rzz(%19) %17, %18 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_12 = arith.constant 2.3561944901923448 : f64
    %20 = qco.rz(%cst_12) %qubit0_out : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_7) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_12) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_4) %qubit1_out : !qco.qubit -> !qco.qubit
    %24 = arith.mulf %cst_6, %cst_5 : f64
    %qubit0_out_13, %qubit1_out_14 = qco.rzz(%24) %14, %23 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %25 = qco.rz(%cst_4) %qubit0_out_13 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_3) %qubit1_out_14 : !qco.qubit -> !qco.qubit
    %27 = arith.mulf %cst_4, %cst_5 : f64
    %qubit0_out_15, %qubit1_out_16 = qco.rzz(%27) %11, %26 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %28 = qco.rz(%cst_3) %qubit0_out_15 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_2) %qubit1_out_16 : !qco.qubit -> !qco.qubit
    %30 = arith.mulf %cst_8, %cst_5 : f64
    %qubit0_out_17, %qubit1_out_18 = qco.rzz(%30) %4, %29 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %31 = qco.rz(%cst_2) %qubit0_out_17 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_1) %qubit1_out_18 : !qco.qubit -> !qco.qubit
    %33 = arith.mulf %cst_9, %cst_5 : f64
    %qubit0_out_19, %qubit1_out_20 = qco.rzz(%33) %5, %32 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %34 = qco.rz(%cst_1) %qubit0_out_19 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_0) %qubit1_out_20 : !qco.qubit -> !qco.qubit
    %36 = arith.mulf %cst_10, %cst_5 : f64
    %qubit0_out_21, %qubit1_out_22 = qco.rzz(%36) %6, %35 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %37 = qco.rz(%cst_0) %qubit0_out_21 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst) %qubit1_out_22 : !qco.qubit -> !qco.qubit
    %39 = arith.mulf %cst_11, %cst_5 : f64
    %qubit0_out_23, %qubit1_out_24 = qco.rzz(%39) %7, %38 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %40 = qco.rz(%cst) %qubit0_out_23 : !qco.qubit -> !qco.qubit
    %qubit0_out_25, %qubit1_out_26 = qco.rzz(%19) %25, %22 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %41 = qco.rz(%cst_12) %qubit0_out_25 : !qco.qubit -> !qco.qubit
    %42 = qco.rx(%cst_7) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_12) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_4) %qubit1_out_26 : !qco.qubit -> !qco.qubit
    %qubit0_out_27, %qubit1_out_28 = qco.rzz(%24) %28, %44 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %45 = qco.rz(%cst_4) %qubit0_out_27 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_3) %qubit1_out_28 : !qco.qubit -> !qco.qubit
    %qubit0_out_29, %qubit1_out_30 = qco.rzz(%27) %31, %46 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %47 = qco.rz(%cst_3) %qubit0_out_29 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_2) %qubit1_out_30 : !qco.qubit -> !qco.qubit
    %qubit0_out_31, %qubit1_out_32 = qco.rzz(%30) %34, %48 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %49 = qco.rz(%cst_2) %qubit0_out_31 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_1) %qubit1_out_32 : !qco.qubit -> !qco.qubit
    %qubit0_out_33, %qubit1_out_34 = qco.rzz(%33) %37, %50 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %51 = qco.rz(%cst_1) %qubit0_out_33 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_0) %qubit1_out_34 : !qco.qubit -> !qco.qubit
    %qubit0_out_35, %qubit1_out_36 = qco.rzz(%36) %40, %52 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %53 = qco.rz(%cst_0) %qubit0_out_35 : !qco.qubit -> !qco.qubit
    %qubit0_out_37, %qubit1_out_38 = qco.rzz(%19) %45, %43 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %54 = qco.rz(%cst_12) %qubit0_out_37 : !qco.qubit -> !qco.qubit
    %55 = qco.rx(%cst_7) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_12) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_4) %qubit1_out_38 : !qco.qubit -> !qco.qubit
    %qubit0_out_39, %qubit1_out_40 = qco.rzz(%24) %47, %57 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %58 = qco.rz(%cst_4) %qubit0_out_39 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_3) %qubit1_out_40 : !qco.qubit -> !qco.qubit
    %qubit0_out_41, %qubit1_out_42 = qco.rzz(%27) %49, %59 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %60 = qco.rz(%cst_3) %qubit0_out_41 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_2) %qubit1_out_42 : !qco.qubit -> !qco.qubit
    %qubit0_out_43, %qubit1_out_44 = qco.rzz(%30) %51, %61 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %62 = qco.rz(%cst_2) %qubit0_out_43 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_1) %qubit1_out_44 : !qco.qubit -> !qco.qubit
    %qubit0_out_45, %qubit1_out_46 = qco.rzz(%33) %53, %63 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %64 = qco.rz(%cst_1) %qubit0_out_45 : !qco.qubit -> !qco.qubit
    %qubit0_out_47, %qubit1_out_48 = qco.rzz(%19) %58, %56 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %65 = qco.rz(%cst_12) %qubit0_out_47 : !qco.qubit -> !qco.qubit
    %66 = qco.rx(%cst_7) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_12) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_4) %qubit1_out_48 : !qco.qubit -> !qco.qubit
    %qubit0_out_49, %qubit1_out_50 = qco.rzz(%24) %60, %68 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %69 = qco.rz(%cst_4) %qubit0_out_49 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_3) %qubit1_out_50 : !qco.qubit -> !qco.qubit
    %qubit0_out_51, %qubit1_out_52 = qco.rzz(%27) %62, %70 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %71 = qco.rz(%cst_3) %qubit0_out_51 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_2) %qubit1_out_52 : !qco.qubit -> !qco.qubit
    %qubit0_out_53, %qubit1_out_54 = qco.rzz(%30) %64, %72 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %73 = qco.rz(%cst_2) %qubit0_out_53 : !qco.qubit -> !qco.qubit
    %qubit0_out_55, %qubit1_out_56 = qco.rzz(%19) %69, %67 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %74 = qco.rz(%cst_12) %qubit0_out_55 : !qco.qubit -> !qco.qubit
    %75 = qco.rx(%cst_7) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_12) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_4) %qubit1_out_56 : !qco.qubit -> !qco.qubit
    %qubit0_out_57, %qubit1_out_58 = qco.rzz(%24) %71, %77 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %78 = qco.rz(%cst_4) %qubit0_out_57 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_3) %qubit1_out_58 : !qco.qubit -> !qco.qubit
    %qubit0_out_59, %qubit1_out_60 = qco.rzz(%27) %73, %79 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %80 = qco.rz(%cst_3) %qubit0_out_59 : !qco.qubit -> !qco.qubit
    %qubit0_out_61, %qubit1_out_62 = qco.rzz(%19) %78, %76 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %81 = qco.rz(%cst_12) %qubit0_out_61 : !qco.qubit -> !qco.qubit
    %82 = qco.rx(%cst_7) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_12) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_4) %qubit1_out_62 : !qco.qubit -> !qco.qubit
    %qubit0_out_63, %qubit1_out_64 = qco.rzz(%24) %80, %84 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %85 = qco.rz(%cst_4) %qubit0_out_63 : !qco.qubit -> !qco.qubit
    %qubit0_out_65, %qubit1_out_66 = qco.rzz(%19) %85, %83 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %86 = qco.rz(%cst_12) %qubit0_out_65 : !qco.qubit -> !qco.qubit
    %87 = qco.rx(%cst_7) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_7) %87 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %88 : !qco.qubit
    cbit.store %result, %8[%c7] : !cbit.reg<8>
    %qubit_out_67, %result_68 = qco.measure %qubit1_out_66 : !qco.qubit
    cbit.store %result_68, %8[%c6] : !cbit.reg<8>
    %qubit_out_69, %result_70 = qco.measure %qubit1_out_64 : !qco.qubit
    cbit.store %result_70, %8[%c5] : !cbit.reg<8>
    %qubit_out_71, %result_72 = qco.measure %qubit1_out_60 : !qco.qubit
    cbit.store %result_72, %8[%c4] : !cbit.reg<8>
    %qubit_out_73, %result_74 = qco.measure %qubit1_out_54 : !qco.qubit
    cbit.store %result_74, %8[%c3] : !cbit.reg<8>
    %qubit_out_75, %result_76 = qco.measure %qubit1_out_46 : !qco.qubit
    cbit.store %result_76, %8[%c2] : !cbit.reg<8>
    %qubit_out_77, %result_78 = qco.measure %qubit1_out_36 : !qco.qubit
    cbit.store %result_78, %8[%c1] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_67 : !qco.qubit
    qco.sink %qubit_out_69 : !qco.qubit
    qco.sink %qubit_out_71 : !qco.qubit
    qco.sink %qubit_out_73 : !qco.qubit
    qco.sink %qubit_out_75 : !qco.qubit
    qco.sink %qubit_out_77 : !qco.qubit
    %qubit_out_79, %result_80 = qco.measure %qubit1_out_24 : !qco.qubit
    qco.sink %qubit_out_79 : !qco.qubit
    cbit.store %result_80, %8[%c0] : !cbit.reg<8>
    %cst_81 = arith.constant 1.5769322499464389 : f64
    qco.gphase(%cst_81)
    return %8 : !cbit.reg<8>
  }
}
