module attributes {mqt.layout = {initial = array<i64: 3, 2, 0, 1>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant -2.9452431127404308 : f64
    %cst_0 = arith.constant -2.7488935718910685 : f64
    %cst_1 = arith.constant -2.3561944901923448 : f64
    %cst_2 = arith.constant -3.1415926535897931 : f64
    %cst_3 = arith.constant -1.5707963267948966 : f64
    %cst_4 = arith.constant 0.78539816339744828 : f64
    %cst_5 = arith.constant 1.5707963267948966 : f64
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %cst_6 = arith.constant 3.1415926535897931 : f64
    %5 = qco.rx(%cst_6) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_4) %1 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %5, %6 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %7 = qco.rz(%cst_2) %qubit1_out : !qco.qubit -> !qco.qubit
    %8 = qco.rx(%cst_5) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_1) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_5) %9 : !qco.qubit -> !qco.qubit
    %qubit0_out_7, %qubit1_out_8 = qco.iswap %qubit0_out, %10 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_9 = arith.constant -2.748893571891069 : f64
    %11 = qco.rz(%cst_9) %qubit1_out_8 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_5) %qubit0_out_7 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_5) %12 : !qco.qubit -> !qco.qubit
    %cst_10 = arith.constant -0.78539816339744739 : f64
    %14 = qco.rz(%cst_10) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_5) %14 : !qco.qubit -> !qco.qubit
    %cst_11 = arith.constant -0.78539816339744916 : f64
    %16 = qco.rz(%cst_11) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_3) %2 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_5) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_5) %18 : !qco.qubit -> !qco.qubit
    %qubit0_out_12, %qubit1_out_13 = qco.iswap %19, %11 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %20 = qco.rz(%cst_2) %qubit1_out_13 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_5) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_0) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_5) %22 : !qco.qubit -> !qco.qubit
    %qubit0_out_14, %qubit1_out_15 = qco.iswap %qubit0_out_12, %23 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %24 = qco.rz(%cst) %qubit1_out_15 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_3) %qubit0_out_14 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_5) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_0) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_5) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_5) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_3) %3 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_5) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_5) %31 : !qco.qubit -> !qco.qubit
    %qubit0_out_16, %qubit1_out_17 = qco.iswap %32, %24 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %33 = qco.rz(%cst_2) %qubit1_out_17 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_5) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_5) %35 : !qco.qubit -> !qco.qubit
    %qubit0_out_18, %qubit1_out_19 = qco.iswap %qubit0_out_16, %36 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %37 = qco.rz(%cst_2) %qubit1_out_19 : !qco.qubit -> !qco.qubit
    %cst_20 = arith.constant -1.5707963267948968 : f64
    %38 = qco.rz(%cst_20) %qubit0_out_18 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_5) %38 : !qco.qubit -> !qco.qubit
    %cst_21 = arith.constant -2.9452431127404299 : f64
    %40 = qco.rz(%cst_21) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_5) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_5) %41 : !qco.qubit -> !qco.qubit
    %qubit0_out_22, %qubit1_out_23 = qco.iswap %29, %16 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %43 = qco.rz(%cst_2) %qubit1_out_23 : !qco.qubit -> !qco.qubit
    %44 = qco.rx(%cst_5) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_1) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst_5) %45 : !qco.qubit -> !qco.qubit
    %qubit0_out_24, %qubit1_out_25 = qco.iswap %qubit0_out_22, %46 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %47 = qco.rz(%cst_9) %qubit1_out_25 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_5) %qubit0_out_24 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_5) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_10) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rx(%cst_5) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_11) %51 : !qco.qubit -> !qco.qubit
    %qubit0_out_26, %qubit1_out_27 = qco.iswap %42, %47 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %53 = qco.rz(%cst_2) %qubit1_out_27 : !qco.qubit -> !qco.qubit
    %54 = qco.rx(%cst_5) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_0) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_5) %55 : !qco.qubit -> !qco.qubit
    %qubit0_out_28, %qubit1_out_29 = qco.iswap %qubit0_out_26, %56 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %57 = qco.rz(%cst_2) %qubit1_out_29 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_3) %qubit0_out_28 : !qco.qubit -> !qco.qubit
    %59 = qco.rx(%cst_5) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_0) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rx(%cst_5) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_5) %61 : !qco.qubit -> !qco.qubit
    %qubit0_out_30, %qubit1_out_31 = qco.iswap %62, %52 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %63 = qco.rz(%cst_2) %qubit1_out_31 : !qco.qubit -> !qco.qubit
    %64 = qco.rx(%cst_5) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_1) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rx(%cst_5) %65 : !qco.qubit -> !qco.qubit
    %qubit0_out_32, %qubit1_out_33 = qco.iswap %qubit0_out_30, %66 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %67 = qco.rz(%cst_2) %qubit1_out_33 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_5) %qubit0_out_32 : !qco.qubit -> !qco.qubit
    %69 = qco.rx(%cst_5) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_10) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_5) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_3) %71 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %72 : !qco.qubit
    cbit.store %result, %4[%c3] : !cbit.reg<4>
    %qubit_out_34, %result_35 = qco.measure %67 : !qco.qubit
    cbit.store %result_35, %4[%c2] : !cbit.reg<4>
    %qubit_out_36, %result_37 = qco.measure %57 : !qco.qubit
    cbit.store %result_37, %4[%c1] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_34 : !qco.qubit
    qco.sink %qubit_out_36 : !qco.qubit
    %qubit_out_38, %result_39 = qco.measure %37 : !qco.qubit
    qco.sink %qubit_out_38 : !qco.qubit
    cbit.store %result_39, %4[%c0] : !cbit.reg<4>
    %cst_40 = arith.constant -1.4726215563702156 : f64
    qco.gphase(%cst_40)
    return %4 : !cbit.reg<4>
  }
}
