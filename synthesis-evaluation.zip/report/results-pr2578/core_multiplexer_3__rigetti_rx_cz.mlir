module attributes {mqt.layout = {initial = array<i64: 1, 2, 0>, input_count = 3 : i64, sites = array<i64: 0, 1, 2>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant -2.3561944901923448 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant -2.7488935718910685 : f64
    %cst_2 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %4 = qco.rz(%cst_2) %1 : !qco.qubit -> !qco.qubit
    %5 = qco.rx(%cst_2) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_2) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_2) %2 : !qco.qubit -> !qco.qubit
    %8 = qco.rx(%cst_2) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_2) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_2) %0 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_2) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_2) %12 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%9) targets (%arg0 = %13) {
      %30 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.rz(%cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_2) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_2) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_0) %17 : !qco.qubit -> !qco.qubit
    %controls_out_3, %targets_out_4 = qco.ctrl(%controls_out) targets (%arg0 = %18) {
      %30 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_5 = arith.constant 1.5707963267948957 : f64
    %19 = qco.rz(%cst_5) %targets_out_4 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_2) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_1) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst_2) %21 : !qco.qubit -> !qco.qubit
    %cst_6 = arith.constant 1.5707963267948974 : f64
    %23 = qco.rz(%cst_6) %22 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%6) targets (%arg0 = %23) {
      %30 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.rz(%cst_0) %targets_out_8 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_2) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_1) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_2) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_0) %27 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%controls_out_7) targets (%arg0 = %28) {
      %30 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %30 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.rz(%cst_2) %targets_out_10 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %29 : !qco.qubit
    cbit.store %result, %3[%c0] : !cbit.reg<3>
    %qubit_out_11, %result_12 = qco.measure %controls_out_9 : !qco.qubit
    cbit.store %result_12, %3[%c1] : !cbit.reg<3>
    qco.sink %qubit_out_11 : !qco.qubit
    %qubit_out_13, %result_14 = qco.measure %controls_out_3 : !qco.qubit
    qco.sink %qubit_out_13 : !qco.qubit
    cbit.store %result_14, %3[%c2] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    %cst_15 = arith.constant 3.1415926535897931 : f64
    qco.gphase(%cst_15)
    return %3 : !cbit.reg<3>
  }
}
