module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 7, 0>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant -1.9634954084936211 : f64
    %cst_0 = arith.constant -0.78539816339744916 : f64
    %cst_1 = arith.constant -1.570796326794897 : f64
    %cst_2 = arith.constant -2.3561944901923448 : f64
    %cst_3 = arith.constant -0.78539816339744828 : f64
    %cst_4 = arith.constant -2.7488935718910685 : f64
    %cst_5 = arith.constant -0.39269908169872414 : f64
    %cst_6 = arith.constant -2.9452431127404308 : f64
    %cst_7 = arith.constant -0.19634954084936229 : f64
    %cst_8 = arith.constant -3.0434178831651124 : f64
    %cst_9 = arith.constant -0.098174770424681145 : f64
    %cst_10 = arith.constant -3.0925052683774528 : f64
    %cst_11 = arith.constant -0.049087385212340351 : f64
    %cst_12 = arith.constant -3.1170489609836229 : f64
    %cst_13 = arith.constant -1.5707963267948966 : f64
    %cst_14 = arith.constant -0.024543692606170175 : f64
    %cst_15 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %9 = qco.rz(%cst_15) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_0) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_15) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_15) %3 : !qco.qubit -> !qco.qubit
    %15 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_0) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.sx %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_15) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_15) %4 : !qco.qubit -> !qco.qubit
    %20 = qco.sx %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_0) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.sx %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_15) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_15) %5 : !qco.qubit -> !qco.qubit
    %25 = qco.sx %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_15) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_15) %6 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_15) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_15) %7 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_15) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_4) %0 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_13) %34 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%32) targets (%arg0 = %35) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qco.rz(%cst_13) %targets_out : !qco.qubit -> !qco.qubit
    %37 = qco.sx %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_13) %39 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%controls_out) targets (%arg0 = %40) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.rz(%cst_15) %targets_out_17 : !qco.qubit -> !qco.qubit
    %42 = qco.sx %41 : !qco.qubit -> !qco.qubit
    %cst_18 = arith.constant -0.78539816339744739 : f64
    %43 = qco.rz(%cst_18) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.sx %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_15) %44 : !qco.qubit -> !qco.qubit
    %cst_19 = arith.constant -1.1780972450961729 : f64
    %46 = qco.rz(%cst_19) %controls_out_16 : !qco.qubit -> !qco.qubit
    %47 = qco.sx %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_15) %47 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%29) targets (%arg0 = %45) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qco.rz(%cst_1) %targets_out_21 : !qco.qubit -> !qco.qubit
    %50 = qco.sx %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_0) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.sx %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_13) %52 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%controls_out_20) targets (%arg0 = %53) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %54 = qco.rz(%cst_15) %targets_out_23 : !qco.qubit -> !qco.qubit
    %55 = qco.sx %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_13) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.sx %controls_out_22 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_15) %57 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%26) targets (%arg0 = %56) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_26, %targets_out_27 = qco.ctrl(%1) targets (%arg0 = %13) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qco.rz(%cst_15) %targets_out_27 : !qco.qubit -> !qco.qubit
    %60 = qco.sx %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_2) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.sx %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_15) %62 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%controls_out_26) targets (%arg0 = %63) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %64 = qco.x %targets_out_29 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_3) %controls_out_28 : !qco.qubit -> !qco.qubit
    %controls_out_30, %targets_out_31 = qco.ctrl(%64) targets (%arg0 = %18) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = qco.rz(%cst_15) %targets_out_31 : !qco.qubit -> !qco.qubit
    %67 = qco.sx %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_2) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.sx %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_15) %69 : !qco.qubit -> !qco.qubit
    %controls_out_32, %targets_out_33 = qco.ctrl(%controls_out_30) targets (%arg0 = %70) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_34 = arith.constant -1.5707963267948968 : f64
    %71 = qco.rz(%cst_34) %targets_out_33 : !qco.qubit -> !qco.qubit
    %72 = qco.sx %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_4) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.sx %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_13) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_3) %controls_out_32 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%65) targets (%arg0 = %75) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qco.rz(%cst_15) %targets_out_36 : !qco.qubit -> !qco.qubit
    %78 = qco.sx %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_4) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.sx %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_15) %80 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%controls_out_35) targets (%arg0 = %81) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %82 = qco.x %targets_out_38 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_5) %controls_out_37 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%82) targets (%arg0 = %23) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %84 = qco.rz(%cst_15) %targets_out_40 : !qco.qubit -> !qco.qubit
    %85 = qco.sx %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_2) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.sx %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_15) %87 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%controls_out_39) targets (%arg0 = %88) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %89 = qco.rz(%cst_34) %targets_out_42 : !qco.qubit -> !qco.qubit
    %90 = qco.sx %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_4) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.sx %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_13) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_3) %controls_out_41 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%76) targets (%arg0 = %93) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %95 = qco.rz(%cst_15) %targets_out_44 : !qco.qubit -> !qco.qubit
    %96 = qco.sx %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_4) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.sx %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_15) %98 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%controls_out_43) targets (%arg0 = %99) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %100 = qco.rz(%cst_34) %targets_out_46 : !qco.qubit -> !qco.qubit
    %101 = qco.sx %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_6) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.sx %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_13) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst_5) %controls_out_45 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%83) targets (%arg0 = %104) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %106 = qco.rz(%cst_15) %targets_out_48 : !qco.qubit -> !qco.qubit
    %107 = qco.sx %106 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_6) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.sx %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst_15) %109 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%controls_out_47) targets (%arg0 = %110) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %111 = qco.x %targets_out_50 : !qco.qubit -> !qco.qubit
    %112 = qco.rz(%cst_7) %controls_out_49 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_2) %controls_out_24 : !qco.qubit -> !qco.qubit
    %114 = qco.sx %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_15) %114 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%111) targets (%arg0 = %115) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %116 = qco.rz(%cst_15) %targets_out_52 : !qco.qubit -> !qco.qubit
    %117 = qco.sx %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_2) %117 : !qco.qubit -> !qco.qubit
    %119 = qco.sx %118 : !qco.qubit -> !qco.qubit
    %120 = qco.rz(%cst_15) %119 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%controls_out_51) targets (%arg0 = %120) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %121 = qco.rz(%cst_34) %targets_out_54 : !qco.qubit -> !qco.qubit
    %122 = qco.sx %121 : !qco.qubit -> !qco.qubit
    %123 = qco.rz(%cst_4) %122 : !qco.qubit -> !qco.qubit
    %124 = qco.sx %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rz(%cst_13) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst_3) %controls_out_53 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%94) targets (%arg0 = %125) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %127 = qco.rz(%cst_15) %targets_out_56 : !qco.qubit -> !qco.qubit
    %128 = qco.sx %127 : !qco.qubit -> !qco.qubit
    %129 = qco.rz(%cst_4) %128 : !qco.qubit -> !qco.qubit
    %130 = qco.sx %129 : !qco.qubit -> !qco.qubit
    %131 = qco.rz(%cst_15) %130 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%controls_out_55) targets (%arg0 = %131) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %132 = qco.rz(%cst_34) %targets_out_58 : !qco.qubit -> !qco.qubit
    %133 = qco.sx %132 : !qco.qubit -> !qco.qubit
    %134 = qco.rz(%cst_6) %133 : !qco.qubit -> !qco.qubit
    %135 = qco.sx %134 : !qco.qubit -> !qco.qubit
    %136 = qco.rz(%cst_13) %135 : !qco.qubit -> !qco.qubit
    %137 = qco.rz(%cst_5) %controls_out_57 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%105) targets (%arg0 = %136) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %138 = qco.rz(%cst_15) %targets_out_60 : !qco.qubit -> !qco.qubit
    %139 = qco.sx %138 : !qco.qubit -> !qco.qubit
    %140 = qco.rz(%cst_6) %139 : !qco.qubit -> !qco.qubit
    %141 = qco.sx %140 : !qco.qubit -> !qco.qubit
    %142 = qco.rz(%cst_15) %141 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%controls_out_59) targets (%arg0 = %142) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %143 = qco.rz(%cst_13) %targets_out_62 : !qco.qubit -> !qco.qubit
    %144 = qco.sx %143 : !qco.qubit -> !qco.qubit
    %145 = qco.rz(%cst_8) %144 : !qco.qubit -> !qco.qubit
    %146 = qco.sx %145 : !qco.qubit -> !qco.qubit
    %147 = qco.rz(%cst_13) %146 : !qco.qubit -> !qco.qubit
    %148 = qco.rz(%cst_7) %controls_out_61 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%112) targets (%arg0 = %147) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %149 = qco.rz(%cst_15) %targets_out_64 : !qco.qubit -> !qco.qubit
    %150 = qco.sx %149 : !qco.qubit -> !qco.qubit
    %151 = qco.rz(%cst_8) %150 : !qco.qubit -> !qco.qubit
    %152 = qco.sx %151 : !qco.qubit -> !qco.qubit
    %153 = qco.rz(%cst_15) %152 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%controls_out_63) targets (%arg0 = %153) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %154 = qco.x %targets_out_66 : !qco.qubit -> !qco.qubit
    %155 = qco.rz(%cst_9) %controls_out_65 : !qco.qubit -> !qco.qubit
    %controls_out_67, %targets_out_68 = qco.ctrl(%154) targets (%arg0 = %58) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %156 = qco.rz(%cst_15) %targets_out_68 : !qco.qubit -> !qco.qubit
    %157 = qco.sx %156 : !qco.qubit -> !qco.qubit
    %158 = qco.rz(%cst_2) %157 : !qco.qubit -> !qco.qubit
    %159 = qco.sx %158 : !qco.qubit -> !qco.qubit
    %160 = qco.rz(%cst_15) %159 : !qco.qubit -> !qco.qubit
    %controls_out_69, %targets_out_70 = qco.ctrl(%controls_out_67) targets (%arg0 = %160) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %161 = qco.rz(%cst_34) %targets_out_70 : !qco.qubit -> !qco.qubit
    %162 = qco.sx %161 : !qco.qubit -> !qco.qubit
    %163 = qco.rz(%cst_4) %162 : !qco.qubit -> !qco.qubit
    %164 = qco.sx %163 : !qco.qubit -> !qco.qubit
    %165 = qco.rz(%cst_13) %164 : !qco.qubit -> !qco.qubit
    %166 = qco.rz(%cst_3) %controls_out_69 : !qco.qubit -> !qco.qubit
    %controls_out_71, %targets_out_72 = qco.ctrl(%126) targets (%arg0 = %165) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %167 = qco.rz(%cst_15) %targets_out_72 : !qco.qubit -> !qco.qubit
    %168 = qco.sx %167 : !qco.qubit -> !qco.qubit
    %169 = qco.rz(%cst_4) %168 : !qco.qubit -> !qco.qubit
    %170 = qco.sx %169 : !qco.qubit -> !qco.qubit
    %171 = qco.rz(%cst_15) %170 : !qco.qubit -> !qco.qubit
    %controls_out_73, %targets_out_74 = qco.ctrl(%controls_out_71) targets (%arg0 = %171) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %172 = qco.rz(%cst_34) %targets_out_74 : !qco.qubit -> !qco.qubit
    %173 = qco.sx %172 : !qco.qubit -> !qco.qubit
    %174 = qco.rz(%cst_6) %173 : !qco.qubit -> !qco.qubit
    %175 = qco.sx %174 : !qco.qubit -> !qco.qubit
    %176 = qco.rz(%cst_13) %175 : !qco.qubit -> !qco.qubit
    %177 = qco.rz(%cst_5) %controls_out_73 : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%137) targets (%arg0 = %176) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %178 = qco.rz(%cst_15) %targets_out_76 : !qco.qubit -> !qco.qubit
    %179 = qco.sx %178 : !qco.qubit -> !qco.qubit
    %180 = qco.rz(%cst_6) %179 : !qco.qubit -> !qco.qubit
    %181 = qco.sx %180 : !qco.qubit -> !qco.qubit
    %182 = qco.rz(%cst_15) %181 : !qco.qubit -> !qco.qubit
    %controls_out_77, %targets_out_78 = qco.ctrl(%controls_out_75) targets (%arg0 = %182) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %183 = qco.rz(%cst_13) %targets_out_78 : !qco.qubit -> !qco.qubit
    %184 = qco.sx %183 : !qco.qubit -> !qco.qubit
    %185 = qco.rz(%cst_8) %184 : !qco.qubit -> !qco.qubit
    %186 = qco.sx %185 : !qco.qubit -> !qco.qubit
    %187 = qco.rz(%cst_13) %186 : !qco.qubit -> !qco.qubit
    %188 = qco.rz(%cst_7) %controls_out_77 : !qco.qubit -> !qco.qubit
    %controls_out_79, %targets_out_80 = qco.ctrl(%148) targets (%arg0 = %187) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %189 = qco.rz(%cst_15) %targets_out_80 : !qco.qubit -> !qco.qubit
    %190 = qco.sx %189 : !qco.qubit -> !qco.qubit
    %191 = qco.rz(%cst_8) %190 : !qco.qubit -> !qco.qubit
    %192 = qco.sx %191 : !qco.qubit -> !qco.qubit
    %193 = qco.rz(%cst_15) %192 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%controls_out_79) targets (%arg0 = %193) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %194 = qco.rz(%cst_13) %targets_out_82 : !qco.qubit -> !qco.qubit
    %195 = qco.sx %194 : !qco.qubit -> !qco.qubit
    %196 = qco.rz(%cst_10) %195 : !qco.qubit -> !qco.qubit
    %197 = qco.sx %196 : !qco.qubit -> !qco.qubit
    %198 = qco.rz(%cst_13) %197 : !qco.qubit -> !qco.qubit
    %199 = qco.rz(%cst_9) %controls_out_81 : !qco.qubit -> !qco.qubit
    %controls_out_83, %targets_out_84 = qco.ctrl(%155) targets (%arg0 = %198) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %200 = qco.rz(%cst_15) %targets_out_84 : !qco.qubit -> !qco.qubit
    %201 = qco.sx %200 : !qco.qubit -> !qco.qubit
    %202 = qco.rz(%cst_10) %201 : !qco.qubit -> !qco.qubit
    %203 = qco.sx %202 : !qco.qubit -> !qco.qubit
    %204 = qco.rz(%cst_15) %203 : !qco.qubit -> !qco.qubit
    %controls_out_85, %targets_out_86 = qco.ctrl(%controls_out_83) targets (%arg0 = %204) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %205 = qco.x %targets_out_86 : !qco.qubit -> !qco.qubit
    %206 = qco.rz(%cst_11) %controls_out_85 : !qco.qubit -> !qco.qubit
    %controls_out_87, %targets_out_88 = qco.ctrl(%205) targets (%arg0 = %48) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %207 = qco.rz(%cst_15) %targets_out_88 : !qco.qubit -> !qco.qubit
    %208 = qco.sx %207 : !qco.qubit -> !qco.qubit
    %209 = qco.rz(%cst_2) %208 : !qco.qubit -> !qco.qubit
    %210 = qco.sx %209 : !qco.qubit -> !qco.qubit
    %211 = qco.rz(%cst_15) %210 : !qco.qubit -> !qco.qubit
    %controls_out_89, %targets_out_90 = qco.ctrl(%controls_out_87) targets (%arg0 = %211) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %212 = qco.rz(%cst_34) %targets_out_90 : !qco.qubit -> !qco.qubit
    %213 = qco.sx %212 : !qco.qubit -> !qco.qubit
    %214 = qco.rz(%cst_4) %213 : !qco.qubit -> !qco.qubit
    %215 = qco.sx %214 : !qco.qubit -> !qco.qubit
    %216 = qco.rz(%cst_13) %215 : !qco.qubit -> !qco.qubit
    %217 = qco.rz(%cst_3) %controls_out_89 : !qco.qubit -> !qco.qubit
    %controls_out_91, %targets_out_92 = qco.ctrl(%166) targets (%arg0 = %216) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %218 = qco.rz(%cst_15) %targets_out_92 : !qco.qubit -> !qco.qubit
    %219 = qco.sx %218 : !qco.qubit -> !qco.qubit
    %220 = qco.rz(%cst_4) %219 : !qco.qubit -> !qco.qubit
    %221 = qco.sx %220 : !qco.qubit -> !qco.qubit
    %222 = qco.rz(%cst_15) %221 : !qco.qubit -> !qco.qubit
    %controls_out_93, %targets_out_94 = qco.ctrl(%controls_out_91) targets (%arg0 = %222) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %223 = qco.rz(%cst_34) %targets_out_94 : !qco.qubit -> !qco.qubit
    %224 = qco.sx %223 : !qco.qubit -> !qco.qubit
    %225 = qco.rz(%cst_6) %224 : !qco.qubit -> !qco.qubit
    %226 = qco.sx %225 : !qco.qubit -> !qco.qubit
    %227 = qco.rz(%cst_13) %226 : !qco.qubit -> !qco.qubit
    %228 = qco.rz(%cst_5) %controls_out_93 : !qco.qubit -> !qco.qubit
    %controls_out_95, %targets_out_96 = qco.ctrl(%177) targets (%arg0 = %227) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %229 = qco.rz(%cst_15) %targets_out_96 : !qco.qubit -> !qco.qubit
    %230 = qco.sx %229 : !qco.qubit -> !qco.qubit
    %231 = qco.rz(%cst_6) %230 : !qco.qubit -> !qco.qubit
    %232 = qco.sx %231 : !qco.qubit -> !qco.qubit
    %233 = qco.rz(%cst_15) %232 : !qco.qubit -> !qco.qubit
    %controls_out_97, %targets_out_98 = qco.ctrl(%controls_out_95) targets (%arg0 = %233) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %234 = qco.rz(%cst_13) %targets_out_98 : !qco.qubit -> !qco.qubit
    %235 = qco.sx %234 : !qco.qubit -> !qco.qubit
    %236 = qco.rz(%cst_8) %235 : !qco.qubit -> !qco.qubit
    %237 = qco.sx %236 : !qco.qubit -> !qco.qubit
    %238 = qco.rz(%cst_13) %237 : !qco.qubit -> !qco.qubit
    %239 = qco.rz(%cst_7) %controls_out_97 : !qco.qubit -> !qco.qubit
    %controls_out_99, %targets_out_100 = qco.ctrl(%188) targets (%arg0 = %238) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %240 = qco.rz(%cst_15) %targets_out_100 : !qco.qubit -> !qco.qubit
    %241 = qco.sx %240 : !qco.qubit -> !qco.qubit
    %242 = qco.rz(%cst_8) %241 : !qco.qubit -> !qco.qubit
    %243 = qco.sx %242 : !qco.qubit -> !qco.qubit
    %244 = qco.rz(%cst_15) %243 : !qco.qubit -> !qco.qubit
    %controls_out_101, %targets_out_102 = qco.ctrl(%controls_out_99) targets (%arg0 = %244) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %245 = qco.rz(%cst_13) %targets_out_102 : !qco.qubit -> !qco.qubit
    %246 = qco.sx %245 : !qco.qubit -> !qco.qubit
    %247 = qco.rz(%cst_10) %246 : !qco.qubit -> !qco.qubit
    %248 = qco.sx %247 : !qco.qubit -> !qco.qubit
    %249 = qco.rz(%cst_13) %248 : !qco.qubit -> !qco.qubit
    %250 = qco.rz(%cst_9) %controls_out_101 : !qco.qubit -> !qco.qubit
    %controls_out_103, %targets_out_104 = qco.ctrl(%199) targets (%arg0 = %249) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %251 = qco.rz(%cst_15) %targets_out_104 : !qco.qubit -> !qco.qubit
    %252 = qco.sx %251 : !qco.qubit -> !qco.qubit
    %253 = qco.rz(%cst_10) %252 : !qco.qubit -> !qco.qubit
    %254 = qco.sx %253 : !qco.qubit -> !qco.qubit
    %255 = qco.rz(%cst_15) %254 : !qco.qubit -> !qco.qubit
    %controls_out_105, %targets_out_106 = qco.ctrl(%controls_out_103) targets (%arg0 = %255) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %256 = qco.rz(%cst_34) %targets_out_106 : !qco.qubit -> !qco.qubit
    %257 = qco.sx %256 : !qco.qubit -> !qco.qubit
    %cst_107 = arith.constant -3.1170489609836238 : f64
    %258 = qco.rz(%cst_107) %257 : !qco.qubit -> !qco.qubit
    %259 = qco.sx %258 : !qco.qubit -> !qco.qubit
    %260 = qco.rz(%cst_13) %259 : !qco.qubit -> !qco.qubit
    %261 = qco.rz(%cst_11) %controls_out_105 : !qco.qubit -> !qco.qubit
    %controls_out_108, %targets_out_109 = qco.ctrl(%206) targets (%arg0 = %260) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %262 = qco.rz(%cst_15) %targets_out_109 : !qco.qubit -> !qco.qubit
    %263 = qco.sx %262 : !qco.qubit -> !qco.qubit
    %264 = qco.rz(%cst_12) %263 : !qco.qubit -> !qco.qubit
    %265 = qco.sx %264 : !qco.qubit -> !qco.qubit
    %266 = qco.rz(%cst_15) %265 : !qco.qubit -> !qco.qubit
    %controls_out_110, %targets_out_111 = qco.ctrl(%controls_out_108) targets (%arg0 = %266) {
      %269 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %269 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %267 = qco.x %targets_out_111 : !qco.qubit -> !qco.qubit
    %268 = qco.rz(%cst_14) %controls_out_110 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %268 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<7>
    %qubit_out_112, %result_113 = qco.measure %261 : !qco.qubit
    cbit.store %result_113, %8[%c1] : !cbit.reg<7>
    %qubit_out_114, %result_115 = qco.measure %250 : !qco.qubit
    cbit.store %result_115, %8[%c2] : !cbit.reg<7>
    %qubit_out_116, %result_117 = qco.measure %239 : !qco.qubit
    cbit.store %result_117, %8[%c3] : !cbit.reg<7>
    %qubit_out_118, %result_119 = qco.measure %228 : !qco.qubit
    cbit.store %result_119, %8[%c4] : !cbit.reg<7>
    %qubit_out_120, %result_121 = qco.measure %217 : !qco.qubit
    cbit.store %result_121, %8[%c5] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_112 : !qco.qubit
    qco.sink %qubit_out_114 : !qco.qubit
    qco.sink %qubit_out_116 : !qco.qubit
    qco.sink %qubit_out_118 : !qco.qubit
    qco.sink %qubit_out_120 : !qco.qubit
    %qubit_out_122, %result_123 = qco.measure %267 : !qco.qubit
    qco.sink %qubit_out_122 : !qco.qubit
    cbit.store %result_123, %8[%c6] : !cbit.reg<7>
    qco.sink %targets_out_25 : !qco.qubit
    %cst_124 = arith.constant 2.5402721847386225 : f64
    qco.gphase(%cst_124)
    return %8 : !cbit.reg<7>
  }
}
