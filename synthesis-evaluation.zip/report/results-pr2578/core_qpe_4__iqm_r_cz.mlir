module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 0>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 0.58904862254808599 : f64
    %cst_0 = arith.constant -5.1050880620834134 : f64
    %cst_1 = arith.constant -0.3926990816987237 : f64
    %cst_2 = arith.constant -3.5342917352885168 : f64
    %cst_3 = arith.constant -6.2831853071795862 : f64
    %cst_4 = arith.constant -4.7123889803846897 : f64
    %cst_5 = arith.constant -3.1415926535897931 : f64
    %cst_6 = arith.constant -0.39269908169872458 : f64
    %cst_7 = arith.constant 1.1780972450961726 : f64
    %cst_8 = arith.constant -1.9634954084936203 : f64
    %cst_9 = arith.constant -1.9634954084936216 : f64
    %cst_10 = arith.constant 2.7488935718910685 : f64
    %cst_11 = arith.constant 3.1415926535897931 : f64
    %cst_12 = arith.constant 1.5707963267948968 : f64
    %cst_13 = arith.constant 1.178097245096172 : f64
    %cst_14 = arith.constant 2.3561944901923448 : f64
    %cst_15 = arith.constant 0.78539816339744828 : f64
    %cst_16 = arith.constant 0.39269908169872414 : f64
    %cst_17 = arith.constant 1.5707963267948966 : f64
    %cst_18 = arith.constant -1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %5 = qco.r(%cst_17, %cst_18) %1 : !qco.qubit -> !qco.qubit
    %6 = qco.r(%cst_17, %cst_18) %2 : !qco.qubit -> !qco.qubit
    %7 = qco.r(%cst_17, %cst_18) %3 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_12, %cst_10) %0 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%7) targets (%arg0 = %8) {
      %23 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %23 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %9 = qco.r(%cst_13, %cst_13) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%controls_out) targets (%arg0 = %9) {
      %23 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %23 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %10 = qco.r(%cst_14, %cst_9) %targets_out_20 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_17, %cst_8) %controls_out_19 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%6) targets (%arg0 = %10) {
      %23 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %23 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qco.r(%cst_14, %cst_7) %targets_out_22 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%controls_out_21) targets (%arg0 = %12) {
      %23 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %23 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %13 = qco.r(%cst_4, %cst_6) %targets_out_24 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_11, %cst) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_17, %cst_5) %controls_out_23 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%5) targets (%arg0 = %14) {
      %23 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %23 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.r(%cst_17, %cst_4) %controls_out_25 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%16) targets (%arg0 = %15) {
      %23 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %23 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.r(%cst_15, %cst_4) %targets_out_28 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%controls_out_27) targets (%arg0 = %17) {
      %23 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %23 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qco.r(%cst_11, %cst_3) %targets_out_30 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%18) targets (%arg0 = %11) {
      %23 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %23 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.r(%cst_15, %cst_2) %targets_out_32 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%controls_out_31) targets (%arg0 = %19) {
      %23 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %23 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.r(%cst_16, %cst_1) %targets_out_34 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%controls_out_29) targets (%arg0 = %20) {
      %23 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %23 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.r(%cst_16, %cst_2) %targets_out_36 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%controls_out_35) targets (%arg0 = %21) {
      %23 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %23 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.r(%cst_11, %cst_0) %targets_out_38 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %controls_out_37 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<3>
    %qubit_out_39, %result_40 = qco.measure %controls_out_33 : !qco.qubit
    cbit.store %result_40, %4[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    %qubit_out_41, %result_42 = qco.measure %22 : !qco.qubit
    qco.sink %qubit_out_41 : !qco.qubit
    cbit.store %result_42, %4[%c2] : !cbit.reg<3>
    qco.sink %targets_out_26 : !qco.qubit
    qco.gphase(%cst_14)
    return %4 : !cbit.reg<3>
  }
}
