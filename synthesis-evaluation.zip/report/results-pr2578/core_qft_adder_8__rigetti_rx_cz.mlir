module attributes {mqt.layout = {initial = array<i64: 3, 1, 2, 0, 5, 7, 4, 6>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant 3.1415926535897931 : f64
    %cst_0 = arith.constant 0.19634954084936229 : f64
    %cst_1 = arith.constant 0.39269908169872414 : f64
    %cst_2 = arith.constant 0.78539816339744828 : f64
    %cst_3 = arith.constant -2.3561944901923448 : f64
    %cst_4 = arith.constant -0.78539816339744828 : f64
    %cst_5 = arith.constant -2.7488935718910685 : f64
    %cst_6 = arith.constant -0.39269908169872414 : f64
    %cst_7 = arith.constant -2.9452431127404308 : f64
    %cst_8 = arith.constant -1.5707963267948966 : f64
    %cst_9 = arith.constant -0.19634954084936229 : f64
    %cst_10 = arith.constant 1.5707963267948966 : f64
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.rx(%cst) %0 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst) %1 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst) %4 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst) %5 : !qco.qubit -> !qco.qubit
    %12 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %13 = qco.rz(%cst_8) %6 : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_10) %13 : !qco.qubit -> !qco.qubit
    %cst_11 = arith.constant -0.78539816339744739 : f64
    %15 = qco.rz(%cst_11) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_10) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_8) %16 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%10) targets (%arg0 = %17) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qco.rz(%cst_8) %targets_out : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_10) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_3) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_10) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_8) %21 : !qco.qubit -> !qco.qubit
    %controls_out_12, %targets_out_13 = qco.ctrl(%controls_out) targets (%arg0 = %22) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qco.rz(%cst_10) %targets_out_13 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_10) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_5) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_10) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_10) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_4) %controls_out_12 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_10) %28 : !qco.qubit -> !qco.qubit
    %cst_14 = arith.constant -0.78539816339744916 : f64
    %30 = qco.rz(%cst_14) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_10) %30 : !qco.qubit -> !qco.qubit
    %cst_15 = arith.constant -1.5707963267948974 : f64
    %32 = qco.rz(%cst_15) %31 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%7) targets (%arg0 = %27) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %33 = qco.rz(%cst_8) %targets_out_17 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_10) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_5) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_10) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_8) %36 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%controls_out_16) targets (%arg0 = %37) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qco.rz(%cst_10) %targets_out_19 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_10) %38 : !qco.qubit -> !qco.qubit
    %cst_20 = arith.constant -2.9452431127404299 : f64
    %40 = qco.rz(%cst_20) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_10) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_10) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_1) %controls_out_18 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%11) targets (%arg0 = %42) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = qco.rz(%cst_8) %targets_out_22 : !qco.qubit -> !qco.qubit
    %45 = qco.rx(%cst_10) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_7) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rx(%cst_10) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_8) %47 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%controls_out_21) targets (%arg0 = %48) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qco.rz(%cst_10) %targets_out_24 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_10) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_8) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_0) %controls_out_23 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%43) targets (%arg0 = %32) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qco.rz(%cst_8) %targets_out_26 : !qco.qubit -> !qco.qubit
    %54 = qco.rx(%cst_10) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_3) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_10) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_8) %56 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%controls_out_25) targets (%arg0 = %57) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = qco.rz(%cst_10) %targets_out_28 : !qco.qubit -> !qco.qubit
    %59 = qco.rx(%cst_10) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_5) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rx(%cst_10) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_10) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_4) %controls_out_27 : !qco.qubit -> !qco.qubit
    %64 = qco.rx(%cst_10) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_14) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rx(%cst_10) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_15) %66 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%52) targets (%arg0 = %62) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %68 = qco.rz(%cst_8) %targets_out_30 : !qco.qubit -> !qco.qubit
    %69 = qco.rx(%cst_10) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_5) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_10) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_8) %71 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%controls_out_29) targets (%arg0 = %72) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %73 = qco.rz(%cst_10) %targets_out_32 : !qco.qubit -> !qco.qubit
    %74 = qco.rx(%cst_10) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_8) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_1) %controls_out_31 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%76) targets (%arg0 = %67) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qco.rz(%cst_8) %targets_out_34 : !qco.qubit -> !qco.qubit
    %78 = qco.rx(%cst_10) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_3) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rx(%cst_10) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_8) %80 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%controls_out_33) targets (%arg0 = %81) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %82 = qco.rz(%cst_10) %targets_out_36 : !qco.qubit -> !qco.qubit
    %83 = qco.rx(%cst_10) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_8) %83 : !qco.qubit -> !qco.qubit
    %cst_37 = arith.constant 2.3561944901923448 : f64
    %85 = qco.rz(%cst_37) %controls_out_35 : !qco.qubit -> !qco.qubit
    %86 = qco.rx(%cst_10) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_10) %86 : !qco.qubit -> !qco.qubit
    %controls_out_38, %targets_out_39 = qco.ctrl(%8) targets (%arg0 = %51) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %88 = qco.rz(%cst_4) %targets_out_39 : !qco.qubit -> !qco.qubit
    %89 = qco.rx(%cst_10) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_10) %89 : !qco.qubit -> !qco.qubit
    %controls_out_40, %targets_out_41 = qco.ctrl(%2) targets (%arg0 = %90) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %91 = qco.rz(%cst_8) %targets_out_41 : !qco.qubit -> !qco.qubit
    %92 = qco.rx(%cst_10) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_3) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rx(%cst_10) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_8) %94 : !qco.qubit -> !qco.qubit
    %controls_out_42, %targets_out_43 = qco.ctrl(%controls_out_40) targets (%arg0 = %95) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %96 = qco.rz(%cst_10) %targets_out_43 : !qco.qubit -> !qco.qubit
    %97 = qco.rx(%cst_10) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_5) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rx(%cst_10) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_10) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst_2) %controls_out_42 : !qco.qubit -> !qco.qubit
    %controls_out_44, %targets_out_45 = qco.ctrl(%9) targets (%arg0 = %100) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %102 = qco.rz(%cst_8) %targets_out_45 : !qco.qubit -> !qco.qubit
    %103 = qco.rx(%cst_10) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_5) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rx(%cst_10) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_8) %105 : !qco.qubit -> !qco.qubit
    %controls_out_46, %targets_out_47 = qco.ctrl(%controls_out_44) targets (%arg0 = %106) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %107 = qco.rz(%cst_10) %targets_out_47 : !qco.qubit -> !qco.qubit
    %108 = qco.rx(%cst_10) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rz(%cst_20) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rx(%cst_10) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_10) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rz(%cst_1) %controls_out_46 : !qco.qubit -> !qco.qubit
    %controls_out_48, %targets_out_49 = qco.ctrl(%3) targets (%arg0 = %111) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %113 = qco.rz(%cst_8) %targets_out_49 : !qco.qubit -> !qco.qubit
    %114 = qco.rx(%cst_10) %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_7) %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rx(%cst_10) %115 : !qco.qubit -> !qco.qubit
    %117 = qco.rz(%cst_8) %116 : !qco.qubit -> !qco.qubit
    %controls_out_50, %targets_out_51 = qco.ctrl(%controls_out_48) targets (%arg0 = %117) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_52 = arith.constant -1.570796326794897 : f64
    %118 = qco.rz(%cst_52) %targets_out_51 : !qco.qubit -> !qco.qubit
    %119 = qco.rx(%cst_10) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.rz(%cst_3) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rx(%cst_10) %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rz(%cst_8) %121 : !qco.qubit -> !qco.qubit
    %123 = qco.rz(%cst_0) %controls_out_50 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%101) targets (%arg0 = %75) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %124 = qco.rz(%cst_4) %targets_out_54 : !qco.qubit -> !qco.qubit
    %125 = qco.rx(%cst_10) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst_10) %125 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%112) targets (%arg0 = %126) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %127 = qco.rz(%cst_8) %targets_out_56 : !qco.qubit -> !qco.qubit
    %128 = qco.rx(%cst_10) %127 : !qco.qubit -> !qco.qubit
    %129 = qco.rz(%cst_3) %128 : !qco.qubit -> !qco.qubit
    %130 = qco.rx(%cst_10) %129 : !qco.qubit -> !qco.qubit
    %131 = qco.rz(%cst_8) %130 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%controls_out_55) targets (%arg0 = %131) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %132 = qco.rz(%cst_10) %targets_out_58 : !qco.qubit -> !qco.qubit
    %133 = qco.rx(%cst_10) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.rz(%cst_5) %133 : !qco.qubit -> !qco.qubit
    %135 = qco.rx(%cst_10) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.rz(%cst_10) %135 : !qco.qubit -> !qco.qubit
    %137 = qco.rz(%cst_2) %controls_out_57 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%123) targets (%arg0 = %136) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %138 = qco.rz(%cst_8) %targets_out_60 : !qco.qubit -> !qco.qubit
    %139 = qco.rx(%cst_10) %138 : !qco.qubit -> !qco.qubit
    %140 = qco.rz(%cst_5) %139 : !qco.qubit -> !qco.qubit
    %141 = qco.rx(%cst_10) %140 : !qco.qubit -> !qco.qubit
    %142 = qco.rz(%cst_8) %141 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%controls_out_59) targets (%arg0 = %142) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %143 = qco.rz(%cst_52) %targets_out_62 : !qco.qubit -> !qco.qubit
    %144 = qco.rx(%cst_10) %143 : !qco.qubit -> !qco.qubit
    %145 = qco.rz(%cst_3) %144 : !qco.qubit -> !qco.qubit
    %146 = qco.rx(%cst_10) %145 : !qco.qubit -> !qco.qubit
    %147 = qco.rz(%cst_8) %146 : !qco.qubit -> !qco.qubit
    %148 = qco.rz(%cst_1) %controls_out_61 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%137) targets (%arg0 = %84) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %149 = qco.rz(%cst_4) %targets_out_64 : !qco.qubit -> !qco.qubit
    %150 = qco.rx(%cst_10) %149 : !qco.qubit -> !qco.qubit
    %151 = qco.rz(%cst_10) %150 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%148) targets (%arg0 = %151) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %152 = qco.rz(%cst_8) %targets_out_66 : !qco.qubit -> !qco.qubit
    %153 = qco.rx(%cst_10) %152 : !qco.qubit -> !qco.qubit
    %154 = qco.rz(%cst_3) %153 : !qco.qubit -> !qco.qubit
    %155 = qco.rx(%cst_10) %154 : !qco.qubit -> !qco.qubit
    %156 = qco.rz(%cst_8) %155 : !qco.qubit -> !qco.qubit
    %controls_out_67, %targets_out_68 = qco.ctrl(%controls_out_65) targets (%arg0 = %156) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %157 = qco.rz(%cst_52) %targets_out_68 : !qco.qubit -> !qco.qubit
    %158 = qco.rx(%cst_10) %157 : !qco.qubit -> !qco.qubit
    %159 = qco.rz(%cst_3) %158 : !qco.qubit -> !qco.qubit
    %160 = qco.rx(%cst_10) %159 : !qco.qubit -> !qco.qubit
    %161 = qco.rz(%cst_8) %160 : !qco.qubit -> !qco.qubit
    %162 = qco.rz(%cst_2) %controls_out_67 : !qco.qubit -> !qco.qubit
    %controls_out_69, %targets_out_70 = qco.ctrl(%162) targets (%arg0 = %87) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %163 = qco.rz(%cst_10) %targets_out_70 : !qco.qubit -> !qco.qubit
    %164 = qco.rx(%cst_10) %163 : !qco.qubit -> !qco.qubit
    %165 = qco.rz(%cst_10) %164 : !qco.qubit -> !qco.qubit
    %controls_out_71, %targets_out_72 = qco.ctrl(%165) targets (%arg0 = %161) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %166 = qco.rz(%cst_10) %targets_out_72 : !qco.qubit -> !qco.qubit
    %167 = qco.rx(%cst_10) %166 : !qco.qubit -> !qco.qubit
    %168 = qco.rz(%cst_3) %167 : !qco.qubit -> !qco.qubit
    %169 = qco.rx(%cst_10) %168 : !qco.qubit -> !qco.qubit
    %170 = qco.rz(%cst_10) %169 : !qco.qubit -> !qco.qubit
    %controls_out_73, %targets_out_74 = qco.ctrl(%controls_out_71) targets (%arg0 = %170) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %171 = qco.rx(%cst) %targets_out_74 : !qco.qubit -> !qco.qubit
    %172 = qco.rz(%cst_4) %controls_out_73 : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%171) targets (%arg0 = %147) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %173 = qco.rz(%cst_10) %targets_out_76 : !qco.qubit -> !qco.qubit
    %174 = qco.rx(%cst_10) %173 : !qco.qubit -> !qco.qubit
    %175 = qco.rz(%cst_3) %174 : !qco.qubit -> !qco.qubit
    %176 = qco.rx(%cst_10) %175 : !qco.qubit -> !qco.qubit
    %177 = qco.rz(%cst_10) %176 : !qco.qubit -> !qco.qubit
    %controls_out_77, %targets_out_78 = qco.ctrl(%controls_out_75) targets (%arg0 = %177) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_79 = arith.constant -1.5707963267948968 : f64
    %178 = qco.rz(%cst_79) %targets_out_78 : !qco.qubit -> !qco.qubit
    %179 = qco.rx(%cst_10) %178 : !qco.qubit -> !qco.qubit
    %cst_80 = arith.constant -2.7488935718910694 : f64
    %180 = qco.rz(%cst_80) %179 : !qco.qubit -> !qco.qubit
    %181 = qco.rx(%cst_10) %180 : !qco.qubit -> !qco.qubit
    %182 = qco.rz(%cst_8) %181 : !qco.qubit -> !qco.qubit
    %183 = qco.rz(%cst_4) %controls_out_77 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%172) targets (%arg0 = %182) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %184 = qco.rz(%cst_10) %targets_out_82 : !qco.qubit -> !qco.qubit
    %185 = qco.rx(%cst_10) %184 : !qco.qubit -> !qco.qubit
    %186 = qco.rz(%cst_5) %185 : !qco.qubit -> !qco.qubit
    %187 = qco.rx(%cst_10) %186 : !qco.qubit -> !qco.qubit
    %188 = qco.rz(%cst_10) %187 : !qco.qubit -> !qco.qubit
    %controls_out_83, %targets_out_84 = qco.ctrl(%controls_out_81) targets (%arg0 = %188) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %189 = qco.rx(%cst) %targets_out_84 : !qco.qubit -> !qco.qubit
    %190 = qco.rz(%cst_6) %controls_out_83 : !qco.qubit -> !qco.qubit
    %controls_out_85, %targets_out_86 = qco.ctrl(%189) targets (%arg0 = %122) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %191 = qco.rz(%cst_10) %targets_out_86 : !qco.qubit -> !qco.qubit
    %192 = qco.rx(%cst_10) %191 : !qco.qubit -> !qco.qubit
    %193 = qco.rz(%cst_3) %192 : !qco.qubit -> !qco.qubit
    %194 = qco.rx(%cst_10) %193 : !qco.qubit -> !qco.qubit
    %195 = qco.rz(%cst_10) %194 : !qco.qubit -> !qco.qubit
    %controls_out_87, %targets_out_88 = qco.ctrl(%controls_out_85) targets (%arg0 = %195) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %196 = qco.rz(%cst_79) %targets_out_88 : !qco.qubit -> !qco.qubit
    %197 = qco.rx(%cst_10) %196 : !qco.qubit -> !qco.qubit
    %198 = qco.rz(%cst_80) %197 : !qco.qubit -> !qco.qubit
    %199 = qco.rx(%cst_10) %198 : !qco.qubit -> !qco.qubit
    %200 = qco.rz(%cst_8) %199 : !qco.qubit -> !qco.qubit
    %201 = qco.rz(%cst_4) %controls_out_87 : !qco.qubit -> !qco.qubit
    %controls_out_89, %targets_out_90 = qco.ctrl(%183) targets (%arg0 = %200) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %202 = qco.rz(%cst_10) %targets_out_90 : !qco.qubit -> !qco.qubit
    %203 = qco.rx(%cst_10) %202 : !qco.qubit -> !qco.qubit
    %204 = qco.rz(%cst_5) %203 : !qco.qubit -> !qco.qubit
    %205 = qco.rx(%cst_10) %204 : !qco.qubit -> !qco.qubit
    %206 = qco.rz(%cst_10) %205 : !qco.qubit -> !qco.qubit
    %controls_out_91, %targets_out_92 = qco.ctrl(%controls_out_89) targets (%arg0 = %206) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_93 = arith.constant -1.5707963267948972 : f64
    %207 = qco.rz(%cst_93) %targets_out_92 : !qco.qubit -> !qco.qubit
    %208 = qco.rx(%cst_10) %207 : !qco.qubit -> !qco.qubit
    %209 = qco.rz(%cst_7) %208 : !qco.qubit -> !qco.qubit
    %210 = qco.rx(%cst_10) %209 : !qco.qubit -> !qco.qubit
    %211 = qco.rz(%cst_8) %210 : !qco.qubit -> !qco.qubit
    %212 = qco.rz(%cst_6) %controls_out_91 : !qco.qubit -> !qco.qubit
    %controls_out_94, %targets_out_95 = qco.ctrl(%190) targets (%arg0 = %211) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %213 = qco.rz(%cst_10) %targets_out_95 : !qco.qubit -> !qco.qubit
    %214 = qco.rx(%cst_10) %213 : !qco.qubit -> !qco.qubit
    %215 = qco.rz(%cst_7) %214 : !qco.qubit -> !qco.qubit
    %216 = qco.rx(%cst_10) %215 : !qco.qubit -> !qco.qubit
    %217 = qco.rz(%cst_10) %216 : !qco.qubit -> !qco.qubit
    %controls_out_96, %targets_out_97 = qco.ctrl(%controls_out_94) targets (%arg0 = %217) {
      %220 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %220 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %218 = qco.rx(%cst) %targets_out_97 : !qco.qubit -> !qco.qubit
    %219 = qco.rz(%cst_9) %controls_out_96 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %219 : !qco.qubit
    cbit.store %result, %12[%c0] : !cbit.reg<8>
    %qubit_out_98, %result_99 = qco.measure %212 : !qco.qubit
    cbit.store %result_99, %12[%c1] : !cbit.reg<8>
    %qubit_out_100, %result_101 = qco.measure %201 : !qco.qubit
    cbit.store %result_101, %12[%c2] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_98 : !qco.qubit
    qco.sink %qubit_out_100 : !qco.qubit
    %qubit_out_102, %result_103 = qco.measure %218 : !qco.qubit
    qco.sink %qubit_out_102 : !qco.qubit
    cbit.store %result_103, %12[%c3] : !cbit.reg<8>
    %qubit_out_104, %result_105 = qco.measure %controls_out_69 : !qco.qubit
    cbit.store %result_105, %12[%c4] : !cbit.reg<8>
    %qubit_out_106, %result_107 = qco.measure %controls_out_63 : !qco.qubit
    cbit.store %result_107, %12[%c5] : !cbit.reg<8>
    %qubit_out_108, %result_109 = qco.measure %controls_out_53 : !qco.qubit
    cbit.store %result_109, %12[%c6] : !cbit.reg<8>
    qco.sink %qubit_out_104 : !qco.qubit
    qco.sink %qubit_out_106 : !qco.qubit
    qco.sink %qubit_out_108 : !qco.qubit
    %qubit_out_110, %result_111 = qco.measure %controls_out_38 : !qco.qubit
    qco.sink %qubit_out_110 : !qco.qubit
    cbit.store %result_111, %12[%c7] : !cbit.reg<8>
    %cst_112 = arith.constant 1.6689710972195773 : f64
    qco.gphase(%cst_112)
    return %12 : !cbit.reg<8>
  }
}
