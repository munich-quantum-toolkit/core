module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "gpi", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = [], fixed_parameters = [3.1415926535897931, unit], canonical_name = "r">, <name = "gpi2", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = [], fixed_parameters = [1.5707963267948966, unit], canonical_name = "r">, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant -3.1415926535897931 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant 3.1415926535897931 : f64
    %cst_2 = arith.constant 0.000000e+00 : f64
    %cst_3 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %5 = qco.rz(%cst_3) %1 : !qco.qubit -> !qco.qubit
    %6 = qco.r(%cst_3, %cst_2) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_3) %3 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_3, %cst_2) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_0) %0 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_0) %6, %9 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %10 = qco.rz(%cst_3) %qubit1_out : !qco.qubit -> !qco.qubit
    %qubit0_out_4, %qubit1_out_5 = qco.rzz(%cst_0) %8, %10 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %11 = qco.r(%cst_1, %cst_2) %qubit1_out_5 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_3) %qubit0_out : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_3, %cst_2) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_3) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_3) %qubit0_out_4 : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_3, %cst_2) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_3) %17 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %15 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<3>
    %qubit_out_6, %result_7 = qco.measure %2 : !qco.qubit
    cbit.store %result_7, %4[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_6 : !qco.qubit
    %qubit_out_8, %result_9 = qco.measure %18 : !qco.qubit
    qco.sink %qubit_out_8 : !qco.qubit
    cbit.store %result_9, %4[%c2] : !cbit.reg<3>
    qco.sink %12 : !qco.qubit
    %cst_10 = arith.constant -1.7763568394002505E-15 : f64
    qco.gphase(%cst_10)
    return %4 : !cbit.reg<3>
  }
}
