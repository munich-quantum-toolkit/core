module attributes {mqt.layout = {initial = array<i64: 7, 6, 5, 4, 0, 1, 2, 3>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = [], parameter_bounds = [array<f64: 0.000000e+00, 1.5707963267948966>]>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant 0.012271846303085088 : f64
    %cst_0 = arith.constant 0.012271846303085129 : f64
    %cst_1 = arith.constant 0.024543692606170175 : f64
    %cst_2 = arith.constant 0.024543692606170259 : f64
    %cst_3 = arith.constant 0.049087385212340351 : f64
    %cst_4 = arith.constant 0.049087385212340517 : f64
    %cst_5 = arith.constant 0.098174770424681145 : f64
    %cst_6 = arith.constant 0.098174770424681035 : f64
    %cst_7 = arith.constant 0.19634954084936229 : f64
    %cst_8 = arith.constant 0.19634954084936207 : f64
    %cst_9 = arith.constant 0.39269908169872414 : f64
    %cst_10 = arith.constant -3.1415926535897931 : f64
    %cst_11 = arith.constant 0.78539816339744828 : f64
    %cst_12 = arith.constant 1.5707963267948966 : f64
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %cst_13 = arith.constant -1.5707963267948966 : f64
    %9 = qco.rz(%cst_13) %0 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_12) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_12) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_13) %1 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_12) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_12) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_13) %2 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_12) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_12) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_11) %3 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_11) %17, %18 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %19 = qco.rz(%cst_11) %qubit0_out : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_12) %19 : !qco.qubit -> !qco.qubit
    %cst_14 = arith.constant -0.78539816339744828 : f64
    %21 = qco.rz(%cst_14) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_9) %qubit1_out : !qco.qubit -> !qco.qubit
    %qubit0_out_15, %qubit1_out_16 = qco.rzz(%cst_9) %14, %22 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_17 = arith.constant -0.39269908169872281 : f64
    %23 = qco.rz(%cst_17) %qubit0_out_15 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_7) %qubit1_out_16 : !qco.qubit -> !qco.qubit
    %qubit0_out_18, %qubit1_out_19 = qco.rzz(%cst_8) %11, %24 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_20 = arith.constant -0.1963495408493614 : f64
    %25 = qco.rz(%cst_20) %qubit0_out_18 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_5) %qubit1_out_19 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_12) %4 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_10) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_12) %28 : !qco.qubit -> !qco.qubit
    %qubit0_out_21, %qubit1_out_22 = qco.rzz(%cst_6) %29, %26 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_23 = arith.constant -0.098174770424680701 : f64
    %30 = qco.rz(%cst_23) %qubit0_out_21 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_3) %qubit1_out_22 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_12) %5 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_10) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_12) %33 : !qco.qubit -> !qco.qubit
    %qubit0_out_24, %qubit1_out_25 = qco.rzz(%cst_4) %34, %31 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_26 = arith.constant -0.049087385212340351 : f64
    %35 = qco.rz(%cst_26) %qubit0_out_24 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_1) %qubit1_out_25 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_12) %6 : !qco.qubit -> !qco.qubit
    %38 = qco.rx(%cst_10) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_12) %38 : !qco.qubit -> !qco.qubit
    %qubit0_out_27, %qubit1_out_28 = qco.rzz(%cst_2) %39, %36 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_29 = arith.constant -0.024543692606169287 : f64
    %40 = qco.rz(%cst_29) %qubit0_out_27 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst) %qubit1_out_28 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_12) %7 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_10) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_12) %43 : !qco.qubit -> !qco.qubit
    %qubit0_out_30, %qubit1_out_31 = qco.rzz(%cst_0) %44, %41 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_32 = arith.constant -0.012271846303084644 : f64
    %45 = qco.rz(%cst_32) %qubit0_out_30 : !qco.qubit -> !qco.qubit
    %qubit0_out_33, %qubit1_out_34 = qco.rzz(%cst_11) %23, %21 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %46 = qco.rz(%cst_11) %qubit0_out_33 : !qco.qubit -> !qco.qubit
    %47 = qco.rx(%cst_12) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_14) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_9) %qubit1_out_34 : !qco.qubit -> !qco.qubit
    %qubit0_out_35, %qubit1_out_36 = qco.rzz(%cst_9) %25, %49 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %50 = qco.rz(%cst_17) %qubit0_out_35 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_7) %qubit1_out_36 : !qco.qubit -> !qco.qubit
    %qubit0_out_37, %qubit1_out_38 = qco.rzz(%cst_8) %30, %51 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %52 = qco.rz(%cst_20) %qubit0_out_37 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_5) %qubit1_out_38 : !qco.qubit -> !qco.qubit
    %qubit0_out_39, %qubit1_out_40 = qco.rzz(%cst_6) %35, %53 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %54 = qco.rz(%cst_23) %qubit0_out_39 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_3) %qubit1_out_40 : !qco.qubit -> !qco.qubit
    %qubit0_out_41, %qubit1_out_42 = qco.rzz(%cst_4) %40, %55 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %56 = qco.rz(%cst_26) %qubit0_out_41 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_1) %qubit1_out_42 : !qco.qubit -> !qco.qubit
    %qubit0_out_43, %qubit1_out_44 = qco.rzz(%cst_2) %45, %57 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %58 = qco.rz(%cst_29) %qubit0_out_43 : !qco.qubit -> !qco.qubit
    %qubit0_out_45, %qubit1_out_46 = qco.rzz(%cst_11) %50, %48 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %59 = qco.rz(%cst_11) %qubit0_out_45 : !qco.qubit -> !qco.qubit
    %60 = qco.rx(%cst_12) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_14) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_9) %qubit1_out_46 : !qco.qubit -> !qco.qubit
    %qubit0_out_47, %qubit1_out_48 = qco.rzz(%cst_9) %52, %62 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %63 = qco.rz(%cst_17) %qubit0_out_47 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_7) %qubit1_out_48 : !qco.qubit -> !qco.qubit
    %qubit0_out_49, %qubit1_out_50 = qco.rzz(%cst_8) %54, %64 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %65 = qco.rz(%cst_20) %qubit0_out_49 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_5) %qubit1_out_50 : !qco.qubit -> !qco.qubit
    %qubit0_out_51, %qubit1_out_52 = qco.rzz(%cst_6) %56, %66 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %67 = qco.rz(%cst_23) %qubit0_out_51 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_3) %qubit1_out_52 : !qco.qubit -> !qco.qubit
    %qubit0_out_53, %qubit1_out_54 = qco.rzz(%cst_4) %58, %68 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %69 = qco.rz(%cst_26) %qubit0_out_53 : !qco.qubit -> !qco.qubit
    %qubit0_out_55, %qubit1_out_56 = qco.rzz(%cst_11) %63, %61 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %70 = qco.rz(%cst_11) %qubit0_out_55 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_12) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_14) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_9) %qubit1_out_56 : !qco.qubit -> !qco.qubit
    %qubit0_out_57, %qubit1_out_58 = qco.rzz(%cst_9) %65, %73 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %74 = qco.rz(%cst_17) %qubit0_out_57 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_7) %qubit1_out_58 : !qco.qubit -> !qco.qubit
    %qubit0_out_59, %qubit1_out_60 = qco.rzz(%cst_8) %67, %75 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %76 = qco.rz(%cst_20) %qubit0_out_59 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_5) %qubit1_out_60 : !qco.qubit -> !qco.qubit
    %qubit0_out_61, %qubit1_out_62 = qco.rzz(%cst_6) %69, %77 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %78 = qco.rz(%cst_23) %qubit0_out_61 : !qco.qubit -> !qco.qubit
    %qubit0_out_63, %qubit1_out_64 = qco.rzz(%cst_11) %74, %72 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %79 = qco.rz(%cst_11) %qubit0_out_63 : !qco.qubit -> !qco.qubit
    %80 = qco.rx(%cst_12) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_14) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_9) %qubit1_out_64 : !qco.qubit -> !qco.qubit
    %qubit0_out_65, %qubit1_out_66 = qco.rzz(%cst_9) %76, %82 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %83 = qco.rz(%cst_17) %qubit0_out_65 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_7) %qubit1_out_66 : !qco.qubit -> !qco.qubit
    %qubit0_out_67, %qubit1_out_68 = qco.rzz(%cst_8) %78, %84 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %85 = qco.rz(%cst_20) %qubit0_out_67 : !qco.qubit -> !qco.qubit
    %qubit0_out_69, %qubit1_out_70 = qco.rzz(%cst_11) %83, %81 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %86 = qco.rz(%cst_11) %qubit0_out_69 : !qco.qubit -> !qco.qubit
    %87 = qco.rx(%cst_12) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_14) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_9) %qubit1_out_70 : !qco.qubit -> !qco.qubit
    %qubit0_out_71, %qubit1_out_72 = qco.rzz(%cst_9) %85, %89 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %90 = qco.rz(%cst_17) %qubit0_out_71 : !qco.qubit -> !qco.qubit
    %qubit0_out_73, %qubit1_out_74 = qco.rzz(%cst_11) %90, %88 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_75 = arith.constant 0.78539816339744872 : f64
    %91 = qco.rz(%cst_75) %qubit0_out_73 : !qco.qubit -> !qco.qubit
    %92 = qco.rx(%cst_12) %91 : !qco.qubit -> !qco.qubit
    %cst_76 = arith.constant -1.570796326794897 : f64
    %93 = qco.rz(%cst_76) %92 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %93 : !qco.qubit
    cbit.store %result, %8[%c7] : !cbit.reg<8>
    %qubit_out_77, %result_78 = qco.measure %qubit1_out_74 : !qco.qubit
    cbit.store %result_78, %8[%c6] : !cbit.reg<8>
    %qubit_out_79, %result_80 = qco.measure %qubit1_out_72 : !qco.qubit
    cbit.store %result_80, %8[%c5] : !cbit.reg<8>
    %qubit_out_81, %result_82 = qco.measure %qubit1_out_68 : !qco.qubit
    cbit.store %result_82, %8[%c4] : !cbit.reg<8>
    %qubit_out_83, %result_84 = qco.measure %qubit1_out_62 : !qco.qubit
    cbit.store %result_84, %8[%c3] : !cbit.reg<8>
    %qubit_out_85, %result_86 = qco.measure %qubit1_out_54 : !qco.qubit
    cbit.store %result_86, %8[%c2] : !cbit.reg<8>
    %qubit_out_87, %result_88 = qco.measure %qubit1_out_44 : !qco.qubit
    cbit.store %result_88, %8[%c1] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_77 : !qco.qubit
    qco.sink %qubit_out_79 : !qco.qubit
    qco.sink %qubit_out_81 : !qco.qubit
    qco.sink %qubit_out_83 : !qco.qubit
    qco.sink %qubit_out_85 : !qco.qubit
    qco.sink %qubit_out_87 : !qco.qubit
    %qubit_out_89, %result_90 = qco.measure %qubit1_out_31 : !qco.qubit
    qco.sink %qubit_out_89 : !qco.qubit
    cbit.store %result_90, %8[%c0] : !cbit.reg<8>
    %cst_91 = arith.constant -1.5646604036433507 : f64
    qco.gphase(%cst_91)
    return %8 : !cbit.reg<8>
  }
}
