module attributes {mqt.layout = {initial = array<i64: 3, 1, 2, 0, 5, 7, 4, 6>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948963 : f64
    %cst_0 = arith.constant -0.78539816339744828 : f64
    %cst_1 = arith.constant 0.39269908169872414 : f64
    %cst_2 = arith.constant -0.39269908169872414 : f64
    %cst_3 = arith.constant 0.19634954084936229 : f64
    %cst_4 = arith.constant -0.19634954084936229 : f64
    %cst_5 = arith.constant 0.78539816339744828 : f64
    %cst_6 = arith.constant 1.5707963267948966 : f64
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.x %0 : !qco.qubit -> !qco.qubit
    %9 = qco.x %1 : !qco.qubit -> !qco.qubit
    %10 = qco.x %4 : !qco.qubit -> !qco.qubit
    %11 = qco.x %5 : !qco.qubit -> !qco.qubit
    %12 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %13 = qco.rz(%cst_6) %6 : !qco.qubit -> !qco.qubit
    %14 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %cst_7 = arith.constant 2.3561944901923448 : f64
    %15 = qco.rz(%cst_7) %14 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%10) targets (%arg0 = %15) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.rz(%cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_8, %targets_out_9 = qco.ctrl(%controls_out) targets (%arg0 = %16) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.rz(%cst_7) %controls_out_8 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_7) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_1) %targets_out_9 : !qco.qubit -> !qco.qubit
    %controls_out_10, %targets_out_11 = qco.ctrl(%7) targets (%arg0 = %20) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.rz(%cst_2) %targets_out_11 : !qco.qubit -> !qco.qubit
    %controls_out_12, %targets_out_13 = qco.ctrl(%controls_out_10) targets (%arg0 = %21) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.rz(%cst_1) %controls_out_12 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_3) %targets_out_13 : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%11) targets (%arg0 = %23) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.rz(%cst_4) %targets_out_15 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%controls_out_14) targets (%arg0 = %24) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %25 = qco.rz(%cst_3) %controls_out_16 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%22) targets (%arg0 = %19) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.rz(%cst_0) %targets_out_19 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%controls_out_18) targets (%arg0 = %26) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %27 = qco.rz(%cst_7) %controls_out_20 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_7) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_1) %targets_out_21 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%25) targets (%arg0 = %30) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.rz(%cst_2) %targets_out_23 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%controls_out_22) targets (%arg0 = %31) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qco.rz(%cst_1) %controls_out_24 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%32) targets (%arg0 = %29) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %33 = qco.rz(%cst_0) %targets_out_27 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%controls_out_26) targets (%arg0 = %33) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.x %controls_out_28 : !qco.qubit -> !qco.qubit
    %cst_30 = arith.constant -0.78539816339744872 : f64
    %35 = qco.rz(%cst_30) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst) %targets_out_17 : !qco.qubit -> !qco.qubit
    %37 = qco.sx %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_6) %37 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%8) targets (%arg0 = %38) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.rz(%cst_6) %targets_out_32 : !qco.qubit -> !qco.qubit
    %40 = qco.sx %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_0) %40 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%2) targets (%arg0 = %41) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qco.rz(%cst_0) %targets_out_34 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%controls_out_33) targets (%arg0 = %42) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qco.rz(%cst_5) %controls_out_35 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_1) %targets_out_36 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%9) targets (%arg0 = %44) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.rz(%cst_2) %targets_out_38 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%controls_out_37) targets (%arg0 = %45) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qco.rz(%cst_1) %controls_out_39 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_3) %targets_out_40 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%3) targets (%arg0 = %47) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %48 = qco.rz(%cst_4) %targets_out_42 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%controls_out_41) targets (%arg0 = %48) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qco.rz(%cst_3) %controls_out_43 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst) %targets_out_25 : !qco.qubit -> !qco.qubit
    %51 = qco.sx %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_6) %51 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%43) targets (%arg0 = %52) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qco.rz(%cst_6) %targets_out_46 : !qco.qubit -> !qco.qubit
    %54 = qco.sx %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_0) %54 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%46) targets (%arg0 = %55) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qco.rz(%cst_0) %targets_out_48 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%controls_out_47) targets (%arg0 = %56) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %57 = qco.rz(%cst_5) %controls_out_49 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_1) %targets_out_50 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%49) targets (%arg0 = %58) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qco.rz(%cst_2) %targets_out_52 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%controls_out_51) targets (%arg0 = %59) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qco.rz(%cst_1) %controls_out_53 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst) %targets_out_29 : !qco.qubit -> !qco.qubit
    %62 = qco.sx %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_6) %62 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%57) targets (%arg0 = %63) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %64 = qco.rz(%cst_6) %targets_out_56 : !qco.qubit -> !qco.qubit
    %65 = qco.sx %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_0) %65 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%60) targets (%arg0 = %66) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %67 = qco.rz(%cst_0) %targets_out_58 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%controls_out_57) targets (%arg0 = %67) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %68 = qco.rz(%cst_5) %controls_out_59 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%68) targets (%arg0 = %35) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qco.x %targets_out_62 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_0) %targets_out_60 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%69) targets (%arg0 = %70) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qco.rz(%cst_5) %targets_out_64 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%controls_out_63) targets (%arg0 = %71) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %72 = qco.rz(%cst_0) %controls_out_65 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_6) %targets_out_66 : !qco.qubit -> !qco.qubit
    %74 = qco.sx %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_6) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_0) %targets_out_54 : !qco.qubit -> !qco.qubit
    %controls_out_67, %targets_out_68 = qco.ctrl(%75) targets (%arg0 = %76) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qco.rz(%cst_5) %targets_out_68 : !qco.qubit -> !qco.qubit
    %controls_out_69, %targets_out_70 = qco.ctrl(%controls_out_67) targets (%arg0 = %77) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %78 = qco.rz(%cst_0) %controls_out_69 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_2) %targets_out_70 : !qco.qubit -> !qco.qubit
    %controls_out_71, %targets_out_72 = qco.ctrl(%72) targets (%arg0 = %79) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %80 = qco.rz(%cst_1) %targets_out_72 : !qco.qubit -> !qco.qubit
    %controls_out_73, %targets_out_74 = qco.ctrl(%controls_out_71) targets (%arg0 = %80) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %81 = qco.rz(%cst_2) %controls_out_73 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_6) %targets_out_74 : !qco.qubit -> !qco.qubit
    %83 = qco.sx %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_6) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_0) %targets_out_44 : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%84) targets (%arg0 = %85) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %86 = qco.rz(%cst_5) %targets_out_76 : !qco.qubit -> !qco.qubit
    %controls_out_77, %targets_out_78 = qco.ctrl(%controls_out_75) targets (%arg0 = %86) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %87 = qco.rz(%cst_0) %controls_out_77 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_2) %targets_out_78 : !qco.qubit -> !qco.qubit
    %controls_out_79, %targets_out_80 = qco.ctrl(%78) targets (%arg0 = %88) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %89 = qco.rz(%cst_1) %targets_out_80 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%controls_out_79) targets (%arg0 = %89) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %90 = qco.rz(%cst_2) %controls_out_81 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_4) %targets_out_82 : !qco.qubit -> !qco.qubit
    %controls_out_83, %targets_out_84 = qco.ctrl(%81) targets (%arg0 = %91) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %92 = qco.rz(%cst_3) %targets_out_84 : !qco.qubit -> !qco.qubit
    %controls_out_85, %targets_out_86 = qco.ctrl(%controls_out_83) targets (%arg0 = %92) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %93 = qco.rz(%cst_4) %controls_out_85 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_6) %targets_out_86 : !qco.qubit -> !qco.qubit
    %95 = qco.sx %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_6) %95 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %93 : !qco.qubit
    cbit.store %result, %12[%c0] : !cbit.reg<8>
    %qubit_out_87, %result_88 = qco.measure %90 : !qco.qubit
    cbit.store %result_88, %12[%c1] : !cbit.reg<8>
    %qubit_out_89, %result_90 = qco.measure %87 : !qco.qubit
    cbit.store %result_90, %12[%c2] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_87 : !qco.qubit
    qco.sink %qubit_out_89 : !qco.qubit
    %qubit_out_91, %result_92 = qco.measure %96 : !qco.qubit
    qco.sink %qubit_out_91 : !qco.qubit
    cbit.store %result_92, %12[%c3] : !cbit.reg<8>
    %qubit_out_93, %result_94 = qco.measure %controls_out_61 : !qco.qubit
    cbit.store %result_94, %12[%c4] : !cbit.reg<8>
    %qubit_out_95, %result_96 = qco.measure %controls_out_55 : !qco.qubit
    cbit.store %result_96, %12[%c5] : !cbit.reg<8>
    %qubit_out_97, %result_98 = qco.measure %controls_out_45 : !qco.qubit
    cbit.store %result_98, %12[%c6] : !cbit.reg<8>
    qco.sink %qubit_out_93 : !qco.qubit
    qco.sink %qubit_out_95 : !qco.qubit
    qco.sink %qubit_out_97 : !qco.qubit
    %qubit_out_99, %result_100 = qco.measure %controls_out_31 : !qco.qubit
    qco.sink %qubit_out_99 : !qco.qubit
    cbit.store %result_100, %12[%c7] : !cbit.reg<8>
    %cst_101 = arith.constant 1.6689710972195768 : f64
    qco.gphase(%cst_101)
    return %12 : !cbit.reg<8>
  }
}
