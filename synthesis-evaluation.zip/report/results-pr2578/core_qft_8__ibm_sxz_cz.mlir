module attributes {mqt.layout = {initial = array<i64: 7, 6, 5, 4, 0, 1, 2, 3>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant -3.1293208072867085 : f64
    %cst_0 = arith.constant 0.012271846303085088 : f64
    %cst_1 = arith.constant -3.1170489609836229 : f64
    %cst_2 = arith.constant 0.024543692606170175 : f64
    %cst_3 = arith.constant -3.0925052683774528 : f64
    %cst_4 = arith.constant 0.049087385212340351 : f64
    %cst_5 = arith.constant -3.0434178831651124 : f64
    %cst_6 = arith.constant 0.098174770424681145 : f64
    %cst_7 = arith.constant -2.9452431127404308 : f64
    %cst_8 = arith.constant 0.19634954084936229 : f64
    %cst_9 = arith.constant -2.7488935718910685 : f64
    %cst_10 = arith.constant 0.39269908169872414 : f64
    %cst_11 = arith.constant -2.3561944901923448 : f64
    %cst_12 = arith.constant -1.5707963267948966 : f64
    %cst_13 = arith.constant 1.5707963267948966 : f64
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %9 = qco.rz(%cst_13) %0 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_13) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_13) %1 : !qco.qubit -> !qco.qubit
    %13 = qco.sx %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_13) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_13) %2 : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_13) %16 : !qco.qubit -> !qco.qubit
    %cst_14 = arith.constant -0.78539816339744828 : f64
    %18 = qco.rz(%cst_14) %3 : !qco.qubit -> !qco.qubit
    %19 = qco.sx %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_13) %19 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%17) targets (%arg0 = %20) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.rz(%cst_12) %targets_out : !qco.qubit -> !qco.qubit
    %22 = qco.sx %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_11) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_12) %24 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%controls_out) targets (%arg0 = %25) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.rz(%cst_13) %targets_out_16 : !qco.qubit -> !qco.qubit
    %27 = qco.sx %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_9) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.sx %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_13) %29 : !qco.qubit -> !qco.qubit
    %cst_17 = arith.constant -0.78539816339744872 : f64
    %31 = qco.rz(%cst_17) %controls_out_15 : !qco.qubit -> !qco.qubit
    %32 = qco.sx %31 : !qco.qubit -> !qco.qubit
    %cst_18 = arith.constant -0.78539816339744739 : f64
    %33 = qco.rz(%cst_18) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_12) %34 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%14) targets (%arg0 = %30) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qco.rz(%cst_12) %targets_out_20 : !qco.qubit -> !qco.qubit
    %37 = qco.sx %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_9) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_12) %39 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%controls_out_19) targets (%arg0 = %40) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.rz(%cst_13) %targets_out_22 : !qco.qubit -> !qco.qubit
    %42 = qco.sx %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_7) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.sx %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_13) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_10) %controls_out_21 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%11) targets (%arg0 = %45) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.rz(%cst_12) %targets_out_24 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_7) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.sx %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_12) %50 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%controls_out_23) targets (%arg0 = %51) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qco.rz(%cst_13) %targets_out_26 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %52 : !qco.qubit -> !qco.qubit
    %cst_27 = arith.constant -3.0434178831651115 : f64
    %54 = qco.rz(%cst_27) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.sx %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_13) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_8) %controls_out_25 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%4) targets (%arg0 = %56) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = qco.rz(%cst_12) %targets_out_29 : !qco.qubit -> !qco.qubit
    %59 = qco.sx %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_5) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.sx %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_12) %61 : !qco.qubit -> !qco.qubit
    %controls_out_30, %targets_out_31 = qco.ctrl(%controls_out_28) targets (%arg0 = %62) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %63 = qco.rz(%cst_13) %targets_out_31 : !qco.qubit -> !qco.qubit
    %64 = qco.sx %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_3) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.sx %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_13) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_6) %controls_out_30 : !qco.qubit -> !qco.qubit
    %controls_out_32, %targets_out_33 = qco.ctrl(%5) targets (%arg0 = %67) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qco.rz(%cst_12) %targets_out_33 : !qco.qubit -> !qco.qubit
    %70 = qco.sx %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_3) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.sx %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_12) %72 : !qco.qubit -> !qco.qubit
    %controls_out_34, %targets_out_35 = qco.ctrl(%controls_out_32) targets (%arg0 = %73) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_36 = arith.constant 1.5707963267948903 : f64
    %74 = qco.rz(%cst_36) %targets_out_35 : !qco.qubit -> !qco.qubit
    %75 = qco.sx %74 : !qco.qubit -> !qco.qubit
    %cst_37 = arith.constant -3.1170489609836221 : f64
    %76 = qco.rz(%cst_37) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.sx %76 : !qco.qubit -> !qco.qubit
    %cst_38 = arith.constant 1.5707963267949019 : f64
    %78 = qco.rz(%cst_38) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_4) %controls_out_34 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%6) targets (%arg0 = %78) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %80 = qco.rz(%cst_12) %targets_out_40 : !qco.qubit -> !qco.qubit
    %81 = qco.sx %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_1) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.sx %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_12) %83 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%controls_out_39) targets (%arg0 = %84) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_43 = arith.constant 1.5707963267948841 : f64
    %85 = qco.rz(%cst_43) %targets_out_42 : !qco.qubit -> !qco.qubit
    %86 = qco.sx %85 : !qco.qubit -> !qco.qubit
    %cst_44 = arith.constant -3.1293208072867076 : f64
    %87 = qco.rz(%cst_44) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.sx %87 : !qco.qubit -> !qco.qubit
    %cst_45 = arith.constant 1.570796326794909 : f64
    %89 = qco.rz(%cst_45) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_2) %controls_out_41 : !qco.qubit -> !qco.qubit
    %controls_out_46, %targets_out_47 = qco.ctrl(%7) targets (%arg0 = %89) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %91 = qco.rz(%cst_12) %targets_out_47 : !qco.qubit -> !qco.qubit
    %92 = qco.sx %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.sx %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_12) %94 : !qco.qubit -> !qco.qubit
    %controls_out_48, %targets_out_49 = qco.ctrl(%controls_out_46) targets (%arg0 = %95) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %96 = qco.rz(%cst_13) %targets_out_49 : !qco.qubit -> !qco.qubit
    %97 = qco.sx %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_12) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_0) %controls_out_48 : !qco.qubit -> !qco.qubit
    %controls_out_50, %targets_out_51 = qco.ctrl(%46) targets (%arg0 = %35) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %100 = qco.rz(%cst_12) %targets_out_51 : !qco.qubit -> !qco.qubit
    %101 = qco.sx %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_11) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.sx %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_12) %103 : !qco.qubit -> !qco.qubit
    %controls_out_52, %targets_out_53 = qco.ctrl(%controls_out_50) targets (%arg0 = %104) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %105 = qco.rz(%cst_13) %targets_out_53 : !qco.qubit -> !qco.qubit
    %106 = qco.sx %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rz(%cst_9) %106 : !qco.qubit -> !qco.qubit
    %108 = qco.sx %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rz(%cst_13) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst_17) %controls_out_52 : !qco.qubit -> !qco.qubit
    %111 = qco.sx %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rz(%cst_18) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.sx %112 : !qco.qubit -> !qco.qubit
    %114 = qco.rz(%cst_12) %113 : !qco.qubit -> !qco.qubit
    %controls_out_54, %targets_out_55 = qco.ctrl(%57) targets (%arg0 = %109) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %115 = qco.rz(%cst_12) %targets_out_55 : !qco.qubit -> !qco.qubit
    %116 = qco.sx %115 : !qco.qubit -> !qco.qubit
    %117 = qco.rz(%cst_9) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.sx %117 : !qco.qubit -> !qco.qubit
    %119 = qco.rz(%cst_12) %118 : !qco.qubit -> !qco.qubit
    %controls_out_56, %targets_out_57 = qco.ctrl(%controls_out_54) targets (%arg0 = %119) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %120 = qco.rz(%cst_13) %targets_out_57 : !qco.qubit -> !qco.qubit
    %121 = qco.sx %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rz(%cst_7) %121 : !qco.qubit -> !qco.qubit
    %123 = qco.sx %122 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_13) %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rz(%cst_10) %controls_out_56 : !qco.qubit -> !qco.qubit
    %controls_out_58, %targets_out_59 = qco.ctrl(%68) targets (%arg0 = %124) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %126 = qco.rz(%cst_12) %targets_out_59 : !qco.qubit -> !qco.qubit
    %127 = qco.sx %126 : !qco.qubit -> !qco.qubit
    %128 = qco.rz(%cst_7) %127 : !qco.qubit -> !qco.qubit
    %129 = qco.sx %128 : !qco.qubit -> !qco.qubit
    %130 = qco.rz(%cst_12) %129 : !qco.qubit -> !qco.qubit
    %controls_out_60, %targets_out_61 = qco.ctrl(%controls_out_58) targets (%arg0 = %130) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %131 = qco.rz(%cst_13) %targets_out_61 : !qco.qubit -> !qco.qubit
    %132 = qco.sx %131 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst_27) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.sx %133 : !qco.qubit -> !qco.qubit
    %135 = qco.rz(%cst_13) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.rz(%cst_8) %controls_out_60 : !qco.qubit -> !qco.qubit
    %controls_out_62, %targets_out_63 = qco.ctrl(%79) targets (%arg0 = %135) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %137 = qco.rz(%cst_12) %targets_out_63 : !qco.qubit -> !qco.qubit
    %138 = qco.sx %137 : !qco.qubit -> !qco.qubit
    %139 = qco.rz(%cst_5) %138 : !qco.qubit -> !qco.qubit
    %140 = qco.sx %139 : !qco.qubit -> !qco.qubit
    %141 = qco.rz(%cst_12) %140 : !qco.qubit -> !qco.qubit
    %controls_out_64, %targets_out_65 = qco.ctrl(%controls_out_62) targets (%arg0 = %141) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %142 = qco.rz(%cst_13) %targets_out_65 : !qco.qubit -> !qco.qubit
    %143 = qco.sx %142 : !qco.qubit -> !qco.qubit
    %144 = qco.rz(%cst_3) %143 : !qco.qubit -> !qco.qubit
    %145 = qco.sx %144 : !qco.qubit -> !qco.qubit
    %146 = qco.rz(%cst_13) %145 : !qco.qubit -> !qco.qubit
    %147 = qco.rz(%cst_6) %controls_out_64 : !qco.qubit -> !qco.qubit
    %controls_out_66, %targets_out_67 = qco.ctrl(%90) targets (%arg0 = %146) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %148 = qco.rz(%cst_12) %targets_out_67 : !qco.qubit -> !qco.qubit
    %149 = qco.sx %148 : !qco.qubit -> !qco.qubit
    %150 = qco.rz(%cst_3) %149 : !qco.qubit -> !qco.qubit
    %151 = qco.sx %150 : !qco.qubit -> !qco.qubit
    %152 = qco.rz(%cst_12) %151 : !qco.qubit -> !qco.qubit
    %controls_out_68, %targets_out_69 = qco.ctrl(%controls_out_66) targets (%arg0 = %152) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %153 = qco.rz(%cst_36) %targets_out_69 : !qco.qubit -> !qco.qubit
    %154 = qco.sx %153 : !qco.qubit -> !qco.qubit
    %155 = qco.rz(%cst_37) %154 : !qco.qubit -> !qco.qubit
    %156 = qco.sx %155 : !qco.qubit -> !qco.qubit
    %157 = qco.rz(%cst_38) %156 : !qco.qubit -> !qco.qubit
    %158 = qco.rz(%cst_4) %controls_out_68 : !qco.qubit -> !qco.qubit
    %controls_out_70, %targets_out_71 = qco.ctrl(%99) targets (%arg0 = %157) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %159 = qco.rz(%cst_12) %targets_out_71 : !qco.qubit -> !qco.qubit
    %160 = qco.sx %159 : !qco.qubit -> !qco.qubit
    %161 = qco.rz(%cst_1) %160 : !qco.qubit -> !qco.qubit
    %162 = qco.sx %161 : !qco.qubit -> !qco.qubit
    %163 = qco.rz(%cst_12) %162 : !qco.qubit -> !qco.qubit
    %controls_out_72, %targets_out_73 = qco.ctrl(%controls_out_70) targets (%arg0 = %163) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %164 = qco.rz(%cst_13) %targets_out_73 : !qco.qubit -> !qco.qubit
    %165 = qco.sx %164 : !qco.qubit -> !qco.qubit
    %166 = qco.rz(%cst_12) %165 : !qco.qubit -> !qco.qubit
    %167 = qco.rz(%cst_2) %controls_out_72 : !qco.qubit -> !qco.qubit
    %controls_out_74, %targets_out_75 = qco.ctrl(%125) targets (%arg0 = %114) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %168 = qco.rz(%cst_12) %targets_out_75 : !qco.qubit -> !qco.qubit
    %169 = qco.sx %168 : !qco.qubit -> !qco.qubit
    %170 = qco.rz(%cst_11) %169 : !qco.qubit -> !qco.qubit
    %171 = qco.sx %170 : !qco.qubit -> !qco.qubit
    %172 = qco.rz(%cst_12) %171 : !qco.qubit -> !qco.qubit
    %controls_out_76, %targets_out_77 = qco.ctrl(%controls_out_74) targets (%arg0 = %172) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %173 = qco.rz(%cst_13) %targets_out_77 : !qco.qubit -> !qco.qubit
    %174 = qco.sx %173 : !qco.qubit -> !qco.qubit
    %175 = qco.rz(%cst_9) %174 : !qco.qubit -> !qco.qubit
    %176 = qco.sx %175 : !qco.qubit -> !qco.qubit
    %177 = qco.rz(%cst_13) %176 : !qco.qubit -> !qco.qubit
    %178 = qco.rz(%cst_17) %controls_out_76 : !qco.qubit -> !qco.qubit
    %179 = qco.sx %178 : !qco.qubit -> !qco.qubit
    %180 = qco.rz(%cst_18) %179 : !qco.qubit -> !qco.qubit
    %181 = qco.sx %180 : !qco.qubit -> !qco.qubit
    %182 = qco.rz(%cst_12) %181 : !qco.qubit -> !qco.qubit
    %controls_out_78, %targets_out_79 = qco.ctrl(%136) targets (%arg0 = %177) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %183 = qco.rz(%cst_12) %targets_out_79 : !qco.qubit -> !qco.qubit
    %184 = qco.sx %183 : !qco.qubit -> !qco.qubit
    %185 = qco.rz(%cst_9) %184 : !qco.qubit -> !qco.qubit
    %186 = qco.sx %185 : !qco.qubit -> !qco.qubit
    %187 = qco.rz(%cst_12) %186 : !qco.qubit -> !qco.qubit
    %controls_out_80, %targets_out_81 = qco.ctrl(%controls_out_78) targets (%arg0 = %187) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %188 = qco.rz(%cst_13) %targets_out_81 : !qco.qubit -> !qco.qubit
    %189 = qco.sx %188 : !qco.qubit -> !qco.qubit
    %190 = qco.rz(%cst_7) %189 : !qco.qubit -> !qco.qubit
    %191 = qco.sx %190 : !qco.qubit -> !qco.qubit
    %192 = qco.rz(%cst_13) %191 : !qco.qubit -> !qco.qubit
    %193 = qco.rz(%cst_10) %controls_out_80 : !qco.qubit -> !qco.qubit
    %controls_out_82, %targets_out_83 = qco.ctrl(%147) targets (%arg0 = %192) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %194 = qco.rz(%cst_12) %targets_out_83 : !qco.qubit -> !qco.qubit
    %195 = qco.sx %194 : !qco.qubit -> !qco.qubit
    %196 = qco.rz(%cst_7) %195 : !qco.qubit -> !qco.qubit
    %197 = qco.sx %196 : !qco.qubit -> !qco.qubit
    %198 = qco.rz(%cst_12) %197 : !qco.qubit -> !qco.qubit
    %controls_out_84, %targets_out_85 = qco.ctrl(%controls_out_82) targets (%arg0 = %198) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %199 = qco.rz(%cst_13) %targets_out_85 : !qco.qubit -> !qco.qubit
    %200 = qco.sx %199 : !qco.qubit -> !qco.qubit
    %201 = qco.rz(%cst_27) %200 : !qco.qubit -> !qco.qubit
    %202 = qco.sx %201 : !qco.qubit -> !qco.qubit
    %203 = qco.rz(%cst_13) %202 : !qco.qubit -> !qco.qubit
    %204 = qco.rz(%cst_8) %controls_out_84 : !qco.qubit -> !qco.qubit
    %controls_out_86, %targets_out_87 = qco.ctrl(%158) targets (%arg0 = %203) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %205 = qco.rz(%cst_12) %targets_out_87 : !qco.qubit -> !qco.qubit
    %206 = qco.sx %205 : !qco.qubit -> !qco.qubit
    %207 = qco.rz(%cst_5) %206 : !qco.qubit -> !qco.qubit
    %208 = qco.sx %207 : !qco.qubit -> !qco.qubit
    %209 = qco.rz(%cst_12) %208 : !qco.qubit -> !qco.qubit
    %controls_out_88, %targets_out_89 = qco.ctrl(%controls_out_86) targets (%arg0 = %209) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %210 = qco.rz(%cst_13) %targets_out_89 : !qco.qubit -> !qco.qubit
    %211 = qco.sx %210 : !qco.qubit -> !qco.qubit
    %212 = qco.rz(%cst_3) %211 : !qco.qubit -> !qco.qubit
    %213 = qco.sx %212 : !qco.qubit -> !qco.qubit
    %214 = qco.rz(%cst_13) %213 : !qco.qubit -> !qco.qubit
    %215 = qco.rz(%cst_6) %controls_out_88 : !qco.qubit -> !qco.qubit
    %controls_out_90, %targets_out_91 = qco.ctrl(%167) targets (%arg0 = %214) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %216 = qco.rz(%cst_12) %targets_out_91 : !qco.qubit -> !qco.qubit
    %217 = qco.sx %216 : !qco.qubit -> !qco.qubit
    %218 = qco.rz(%cst_3) %217 : !qco.qubit -> !qco.qubit
    %219 = qco.sx %218 : !qco.qubit -> !qco.qubit
    %220 = qco.rz(%cst_12) %219 : !qco.qubit -> !qco.qubit
    %controls_out_92, %targets_out_93 = qco.ctrl(%controls_out_90) targets (%arg0 = %220) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %221 = qco.rz(%cst_13) %targets_out_93 : !qco.qubit -> !qco.qubit
    %222 = qco.sx %221 : !qco.qubit -> !qco.qubit
    %223 = qco.rz(%cst_12) %222 : !qco.qubit -> !qco.qubit
    %224 = qco.rz(%cst_4) %controls_out_92 : !qco.qubit -> !qco.qubit
    %controls_out_94, %targets_out_95 = qco.ctrl(%193) targets (%arg0 = %182) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %225 = qco.rz(%cst_12) %targets_out_95 : !qco.qubit -> !qco.qubit
    %226 = qco.sx %225 : !qco.qubit -> !qco.qubit
    %227 = qco.rz(%cst_11) %226 : !qco.qubit -> !qco.qubit
    %228 = qco.sx %227 : !qco.qubit -> !qco.qubit
    %229 = qco.rz(%cst_12) %228 : !qco.qubit -> !qco.qubit
    %controls_out_96, %targets_out_97 = qco.ctrl(%controls_out_94) targets (%arg0 = %229) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %230 = qco.rz(%cst_13) %targets_out_97 : !qco.qubit -> !qco.qubit
    %231 = qco.sx %230 : !qco.qubit -> !qco.qubit
    %232 = qco.rz(%cst_9) %231 : !qco.qubit -> !qco.qubit
    %233 = qco.sx %232 : !qco.qubit -> !qco.qubit
    %234 = qco.rz(%cst_13) %233 : !qco.qubit -> !qco.qubit
    %235 = qco.rz(%cst_17) %controls_out_96 : !qco.qubit -> !qco.qubit
    %236 = qco.sx %235 : !qco.qubit -> !qco.qubit
    %237 = qco.rz(%cst_18) %236 : !qco.qubit -> !qco.qubit
    %238 = qco.sx %237 : !qco.qubit -> !qco.qubit
    %239 = qco.rz(%cst_12) %238 : !qco.qubit -> !qco.qubit
    %controls_out_98, %targets_out_99 = qco.ctrl(%204) targets (%arg0 = %234) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %240 = qco.rz(%cst_12) %targets_out_99 : !qco.qubit -> !qco.qubit
    %241 = qco.sx %240 : !qco.qubit -> !qco.qubit
    %242 = qco.rz(%cst_9) %241 : !qco.qubit -> !qco.qubit
    %243 = qco.sx %242 : !qco.qubit -> !qco.qubit
    %244 = qco.rz(%cst_12) %243 : !qco.qubit -> !qco.qubit
    %controls_out_100, %targets_out_101 = qco.ctrl(%controls_out_98) targets (%arg0 = %244) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %245 = qco.rz(%cst_13) %targets_out_101 : !qco.qubit -> !qco.qubit
    %246 = qco.sx %245 : !qco.qubit -> !qco.qubit
    %247 = qco.rz(%cst_7) %246 : !qco.qubit -> !qco.qubit
    %248 = qco.sx %247 : !qco.qubit -> !qco.qubit
    %249 = qco.rz(%cst_13) %248 : !qco.qubit -> !qco.qubit
    %250 = qco.rz(%cst_10) %controls_out_100 : !qco.qubit -> !qco.qubit
    %controls_out_102, %targets_out_103 = qco.ctrl(%215) targets (%arg0 = %249) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %251 = qco.rz(%cst_12) %targets_out_103 : !qco.qubit -> !qco.qubit
    %252 = qco.sx %251 : !qco.qubit -> !qco.qubit
    %253 = qco.rz(%cst_7) %252 : !qco.qubit -> !qco.qubit
    %254 = qco.sx %253 : !qco.qubit -> !qco.qubit
    %255 = qco.rz(%cst_12) %254 : !qco.qubit -> !qco.qubit
    %controls_out_104, %targets_out_105 = qco.ctrl(%controls_out_102) targets (%arg0 = %255) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %256 = qco.rz(%cst_13) %targets_out_105 : !qco.qubit -> !qco.qubit
    %257 = qco.sx %256 : !qco.qubit -> !qco.qubit
    %258 = qco.rz(%cst_27) %257 : !qco.qubit -> !qco.qubit
    %259 = qco.sx %258 : !qco.qubit -> !qco.qubit
    %260 = qco.rz(%cst_13) %259 : !qco.qubit -> !qco.qubit
    %261 = qco.rz(%cst_8) %controls_out_104 : !qco.qubit -> !qco.qubit
    %controls_out_106, %targets_out_107 = qco.ctrl(%224) targets (%arg0 = %260) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %262 = qco.rz(%cst_12) %targets_out_107 : !qco.qubit -> !qco.qubit
    %263 = qco.sx %262 : !qco.qubit -> !qco.qubit
    %264 = qco.rz(%cst_5) %263 : !qco.qubit -> !qco.qubit
    %265 = qco.sx %264 : !qco.qubit -> !qco.qubit
    %266 = qco.rz(%cst_12) %265 : !qco.qubit -> !qco.qubit
    %controls_out_108, %targets_out_109 = qco.ctrl(%controls_out_106) targets (%arg0 = %266) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %267 = qco.rz(%cst_13) %targets_out_109 : !qco.qubit -> !qco.qubit
    %268 = qco.sx %267 : !qco.qubit -> !qco.qubit
    %269 = qco.rz(%cst_12) %268 : !qco.qubit -> !qco.qubit
    %270 = qco.rz(%cst_6) %controls_out_108 : !qco.qubit -> !qco.qubit
    %controls_out_110, %targets_out_111 = qco.ctrl(%250) targets (%arg0 = %239) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %271 = qco.rz(%cst_12) %targets_out_111 : !qco.qubit -> !qco.qubit
    %272 = qco.sx %271 : !qco.qubit -> !qco.qubit
    %273 = qco.rz(%cst_11) %272 : !qco.qubit -> !qco.qubit
    %274 = qco.sx %273 : !qco.qubit -> !qco.qubit
    %275 = qco.rz(%cst_12) %274 : !qco.qubit -> !qco.qubit
    %controls_out_112, %targets_out_113 = qco.ctrl(%controls_out_110) targets (%arg0 = %275) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %276 = qco.rz(%cst_13) %targets_out_113 : !qco.qubit -> !qco.qubit
    %277 = qco.sx %276 : !qco.qubit -> !qco.qubit
    %278 = qco.rz(%cst_9) %277 : !qco.qubit -> !qco.qubit
    %279 = qco.sx %278 : !qco.qubit -> !qco.qubit
    %280 = qco.rz(%cst_13) %279 : !qco.qubit -> !qco.qubit
    %281 = qco.rz(%cst_17) %controls_out_112 : !qco.qubit -> !qco.qubit
    %282 = qco.sx %281 : !qco.qubit -> !qco.qubit
    %283 = qco.rz(%cst_18) %282 : !qco.qubit -> !qco.qubit
    %284 = qco.sx %283 : !qco.qubit -> !qco.qubit
    %285 = qco.rz(%cst_12) %284 : !qco.qubit -> !qco.qubit
    %controls_out_114, %targets_out_115 = qco.ctrl(%261) targets (%arg0 = %280) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %286 = qco.rz(%cst_12) %targets_out_115 : !qco.qubit -> !qco.qubit
    %287 = qco.sx %286 : !qco.qubit -> !qco.qubit
    %288 = qco.rz(%cst_9) %287 : !qco.qubit -> !qco.qubit
    %289 = qco.sx %288 : !qco.qubit -> !qco.qubit
    %290 = qco.rz(%cst_12) %289 : !qco.qubit -> !qco.qubit
    %controls_out_116, %targets_out_117 = qco.ctrl(%controls_out_114) targets (%arg0 = %290) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %291 = qco.rz(%cst_13) %targets_out_117 : !qco.qubit -> !qco.qubit
    %292 = qco.sx %291 : !qco.qubit -> !qco.qubit
    %293 = qco.rz(%cst_7) %292 : !qco.qubit -> !qco.qubit
    %294 = qco.sx %293 : !qco.qubit -> !qco.qubit
    %295 = qco.rz(%cst_13) %294 : !qco.qubit -> !qco.qubit
    %296 = qco.rz(%cst_10) %controls_out_116 : !qco.qubit -> !qco.qubit
    %controls_out_118, %targets_out_119 = qco.ctrl(%270) targets (%arg0 = %295) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %297 = qco.rz(%cst_12) %targets_out_119 : !qco.qubit -> !qco.qubit
    %298 = qco.sx %297 : !qco.qubit -> !qco.qubit
    %299 = qco.rz(%cst_7) %298 : !qco.qubit -> !qco.qubit
    %300 = qco.sx %299 : !qco.qubit -> !qco.qubit
    %301 = qco.rz(%cst_12) %300 : !qco.qubit -> !qco.qubit
    %controls_out_120, %targets_out_121 = qco.ctrl(%controls_out_118) targets (%arg0 = %301) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %302 = qco.rz(%cst_13) %targets_out_121 : !qco.qubit -> !qco.qubit
    %303 = qco.sx %302 : !qco.qubit -> !qco.qubit
    %304 = qco.rz(%cst_12) %303 : !qco.qubit -> !qco.qubit
    %305 = qco.rz(%cst_8) %controls_out_120 : !qco.qubit -> !qco.qubit
    %controls_out_122, %targets_out_123 = qco.ctrl(%296) targets (%arg0 = %285) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %306 = qco.rz(%cst_12) %targets_out_123 : !qco.qubit -> !qco.qubit
    %307 = qco.sx %306 : !qco.qubit -> !qco.qubit
    %308 = qco.rz(%cst_11) %307 : !qco.qubit -> !qco.qubit
    %309 = qco.sx %308 : !qco.qubit -> !qco.qubit
    %310 = qco.rz(%cst_12) %309 : !qco.qubit -> !qco.qubit
    %controls_out_124, %targets_out_125 = qco.ctrl(%controls_out_122) targets (%arg0 = %310) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %311 = qco.rz(%cst_13) %targets_out_125 : !qco.qubit -> !qco.qubit
    %312 = qco.sx %311 : !qco.qubit -> !qco.qubit
    %313 = qco.rz(%cst_9) %312 : !qco.qubit -> !qco.qubit
    %314 = qco.sx %313 : !qco.qubit -> !qco.qubit
    %315 = qco.rz(%cst_13) %314 : !qco.qubit -> !qco.qubit
    %316 = qco.rz(%cst_17) %controls_out_124 : !qco.qubit -> !qco.qubit
    %317 = qco.sx %316 : !qco.qubit -> !qco.qubit
    %318 = qco.rz(%cst_18) %317 : !qco.qubit -> !qco.qubit
    %319 = qco.sx %318 : !qco.qubit -> !qco.qubit
    %320 = qco.rz(%cst_12) %319 : !qco.qubit -> !qco.qubit
    %controls_out_126, %targets_out_127 = qco.ctrl(%305) targets (%arg0 = %315) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %321 = qco.rz(%cst_12) %targets_out_127 : !qco.qubit -> !qco.qubit
    %322 = qco.sx %321 : !qco.qubit -> !qco.qubit
    %323 = qco.rz(%cst_9) %322 : !qco.qubit -> !qco.qubit
    %324 = qco.sx %323 : !qco.qubit -> !qco.qubit
    %325 = qco.rz(%cst_12) %324 : !qco.qubit -> !qco.qubit
    %controls_out_128, %targets_out_129 = qco.ctrl(%controls_out_126) targets (%arg0 = %325) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %326 = qco.rz(%cst_13) %targets_out_129 : !qco.qubit -> !qco.qubit
    %327 = qco.sx %326 : !qco.qubit -> !qco.qubit
    %328 = qco.rz(%cst_12) %327 : !qco.qubit -> !qco.qubit
    %329 = qco.rz(%cst_10) %controls_out_128 : !qco.qubit -> !qco.qubit
    %controls_out_130, %targets_out_131 = qco.ctrl(%329) targets (%arg0 = %320) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %330 = qco.rz(%cst_12) %targets_out_131 : !qco.qubit -> !qco.qubit
    %331 = qco.sx %330 : !qco.qubit -> !qco.qubit
    %332 = qco.rz(%cst_11) %331 : !qco.qubit -> !qco.qubit
    %333 = qco.sx %332 : !qco.qubit -> !qco.qubit
    %334 = qco.rz(%cst_12) %333 : !qco.qubit -> !qco.qubit
    %controls_out_132, %targets_out_133 = qco.ctrl(%controls_out_130) targets (%arg0 = %334) {
      %341 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %341 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %335 = qco.rz(%cst_13) %targets_out_133 : !qco.qubit -> !qco.qubit
    %336 = qco.sx %335 : !qco.qubit -> !qco.qubit
    %337 = qco.rz(%cst_12) %336 : !qco.qubit -> !qco.qubit
    %cst_134 = arith.constant 2.3561944901923448 : f64
    %338 = qco.rz(%cst_134) %controls_out_132 : !qco.qubit -> !qco.qubit
    %339 = qco.sx %338 : !qco.qubit -> !qco.qubit
    %340 = qco.rz(%cst_13) %339 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %340 : !qco.qubit
    cbit.store %result, %8[%c7] : !cbit.reg<8>
    %qubit_out_135, %result_136 = qco.measure %337 : !qco.qubit
    cbit.store %result_136, %8[%c6] : !cbit.reg<8>
    %qubit_out_137, %result_138 = qco.measure %328 : !qco.qubit
    cbit.store %result_138, %8[%c5] : !cbit.reg<8>
    %qubit_out_139, %result_140 = qco.measure %304 : !qco.qubit
    cbit.store %result_140, %8[%c4] : !cbit.reg<8>
    %qubit_out_141, %result_142 = qco.measure %269 : !qco.qubit
    cbit.store %result_142, %8[%c3] : !cbit.reg<8>
    %qubit_out_143, %result_144 = qco.measure %223 : !qco.qubit
    cbit.store %result_144, %8[%c2] : !cbit.reg<8>
    %qubit_out_145, %result_146 = qco.measure %166 : !qco.qubit
    cbit.store %result_146, %8[%c1] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_135 : !qco.qubit
    qco.sink %qubit_out_137 : !qco.qubit
    qco.sink %qubit_out_139 : !qco.qubit
    qco.sink %qubit_out_141 : !qco.qubit
    qco.sink %qubit_out_143 : !qco.qubit
    qco.sink %qubit_out_145 : !qco.qubit
    %qubit_out_147, %result_148 = qco.measure %98 : !qco.qubit
    qco.sink %qubit_out_147 : !qco.qubit
    cbit.store %result_148, %8[%c0] : !cbit.reg<8>
    %cst_149 = arith.constant 0.0061359231515427659 : f64
    qco.gphase(%cst_149)
    return %8 : !cbit.reg<8>
  }
}
