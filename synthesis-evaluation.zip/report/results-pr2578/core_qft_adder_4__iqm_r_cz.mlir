module attributes {mqt.layout = {initial = array<i64: 1, 0, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 3.9269908169872414 : f64
    %cst_0 = arith.constant 5.497787143782138 : f64
    %cst_1 = arith.constant 10.210176124166827 : f64
    %cst_2 = arith.constant 8.6393797973719302 : f64
    %cst_3 = arith.constant 7.0685834705770345 : f64
    %cst_4 = arith.constant 7.8539816339744828 : f64
    %cst_5 = arith.constant 9.4247779607693793 : f64
    %cst_6 = arith.constant 3.1415926535897936 : f64
    %cst_7 = arith.constant 2.3561944901923448 : f64
    %cst_8 = arith.constant 1.5707963267948966 : f64
    %cst_9 = arith.constant 3.1415926535897931 : f64
    %cst_10 = arith.constant -1.5707963267948966 : f64
    %cst_11 = arith.constant 0.78539816339744828 : f64
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.r(%cst_9, %cst_8) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.r(%cst_9, %cst_8) %2 : !qco.qubit -> !qco.qubit
    %6 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %7 = qco.r(%cst_7, %cst_6) %3 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%5) targets (%arg0 = %7) {
      %17 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %17 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %8 = qco.r(%cst_11, %cst_5) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_12, %targets_out_13 = qco.ctrl(%controls_out) targets (%arg0 = %8) {
      %17 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %17 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %9 = qco.r(%cst_10, %cst_4) %targets_out_13 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_8, %cst_3) %controls_out_12 : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%4) targets (%arg0 = %9) {
      %17 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %17 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qco.r(%cst_8, %cst_3) %targets_out_15 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%1) targets (%arg0 = %11) {
      %17 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %17 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qco.r(%cst_11, %cst_2) %targets_out_17 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%controls_out_16) targets (%arg0 = %12) {
      %17 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %17 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %13 = qco.r(%cst_11, %cst_2) %targets_out_19 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%controls_out_18) targets (%arg0 = %10) {
      %17 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %17 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.r(%cst_8, %cst_1) %targets_out_21 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%14) targets (%arg0 = %13) {
      %17 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %17 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qco.r(%cst_11, %cst_0) %targets_out_23 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%controls_out_22) targets (%arg0 = %15) {
      %17 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %17 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.r(%cst_9, %cst) %targets_out_25 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %controls_out_24 : !qco.qubit
    cbit.store %result, %6[%c0] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    %qubit_out_26, %result_27 = qco.measure %16 : !qco.qubit
    qco.sink %qubit_out_26 : !qco.qubit
    cbit.store %result_27, %6[%c1] : !cbit.reg<4>
    %qubit_out_28, %result_29 = qco.measure %controls_out_20 : !qco.qubit
    cbit.store %result_29, %6[%c2] : !cbit.reg<4>
    qco.sink %qubit_out_28 : !qco.qubit
    %qubit_out_30, %result_31 = qco.measure %controls_out_14 : !qco.qubit
    qco.sink %qubit_out_30 : !qco.qubit
    cbit.store %result_31, %6[%c3] : !cbit.reg<4>
    %cst_32 = arith.constant -2.748893571891069 : f64
    qco.gphase(%cst_32)
    return %6 : !cbit.reg<4>
  }
}
