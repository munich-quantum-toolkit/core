module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 0>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant -1.9634954084936211 : f64
    %cst_0 = arith.constant -0.78539816339744916 : f64
    %cst_1 = arith.constant -1.570796326794897 : f64
    %cst_2 = arith.constant -2.3561944901923448 : f64
    %cst_3 = arith.constant -0.78539816339744828 : f64
    %cst_4 = arith.constant -2.7488935718910685 : f64
    %cst_5 = arith.constant -1.5707963267948966 : f64
    %cst_6 = arith.constant -0.39269908169872414 : f64
    %cst_7 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %5 = qco.rz(%cst_7) %1 : !qco.qubit -> !qco.qubit
    %6 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_7) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_7) %2 : !qco.qubit -> !qco.qubit
    %9 = qco.sx %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_7) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_7) %3 : !qco.qubit -> !qco.qubit
    %12 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_7) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_4) %0 : !qco.qubit -> !qco.qubit
    %15 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_5) %15 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%13) targets (%arg0 = %16) {
      %68 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %68 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.rz(%cst_5) %targets_out : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.sx %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_5) %20 : !qco.qubit -> !qco.qubit
    %controls_out_8, %targets_out_9 = qco.ctrl(%controls_out) targets (%arg0 = %21) {
      %68 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %68 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.rz(%cst_7) %targets_out_9 : !qco.qubit -> !qco.qubit
    %23 = qco.sx %22 : !qco.qubit -> !qco.qubit
    %cst_10 = arith.constant -0.78539816339744739 : f64
    %24 = qco.rz(%cst_10) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.sx %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_7) %25 : !qco.qubit -> !qco.qubit
    %cst_11 = arith.constant -1.1780972450961729 : f64
    %27 = qco.rz(%cst_11) %controls_out_8 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_7) %28 : !qco.qubit -> !qco.qubit
    %controls_out_12, %targets_out_13 = qco.ctrl(%10) targets (%arg0 = %26) {
      %68 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %68 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.rz(%cst_1) %targets_out_13 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_0) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.sx %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_5) %33 : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%controls_out_12) targets (%arg0 = %34) {
      %68 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %68 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.rz(%cst_7) %targets_out_15 : !qco.qubit -> !qco.qubit
    %36 = qco.sx %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_5) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.sx %controls_out_14 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_7) %38 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%7) targets (%arg0 = %37) {
      %68 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %68 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %40 = qco.rz(%cst_7) %controls_out_16 : !qco.qubit -> !qco.qubit
    %41 = qco.sx %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_7) %41 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%42) targets (%arg0 = %39) {
      %68 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %68 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qco.rz(%cst_7) %targets_out_19 : !qco.qubit -> !qco.qubit
    %44 = qco.sx %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_2) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.sx %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_7) %46 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%controls_out_18) targets (%arg0 = %47) {
      %68 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %68 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %48 = qco.x %targets_out_21 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_3) %controls_out_20 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%48) targets (%arg0 = %29) {
      %68 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %68 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qco.rz(%cst_7) %targets_out_23 : !qco.qubit -> !qco.qubit
    %51 = qco.sx %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_2) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_7) %53 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%controls_out_22) targets (%arg0 = %54) {
      %68 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %68 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_26 = arith.constant -1.5707963267948968 : f64
    %55 = qco.rz(%cst_26) %targets_out_25 : !qco.qubit -> !qco.qubit
    %56 = qco.sx %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_4) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.sx %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_5) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_3) %controls_out_24 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%49) targets (%arg0 = %59) {
      %68 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %68 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qco.rz(%cst_7) %targets_out_28 : !qco.qubit -> !qco.qubit
    %62 = qco.sx %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_4) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.sx %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_7) %64 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%controls_out_27) targets (%arg0 = %65) {
      %68 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %68 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = qco.x %targets_out_30 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_6) %controls_out_29 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %67 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<3>
    %qubit_out_31, %result_32 = qco.measure %60 : !qco.qubit
    cbit.store %result_32, %4[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_31 : !qco.qubit
    %qubit_out_33, %result_34 = qco.measure %66 : !qco.qubit
    qco.sink %qubit_out_33 : !qco.qubit
    cbit.store %result_34, %4[%c2] : !cbit.reg<3>
    qco.sink %targets_out_17 : !qco.qubit
    %cst_35 = arith.constant 0.78539816339744806 : f64
    qco.gphase(%cst_35)
    return %4 : !cbit.reg<3>
  }
}
