module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 0>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant -1.1780972450961724 : f64
    %cst_0 = arith.constant 1.178097245096172 : f64
    %cst_1 = arith.constant -2.3561944901923448 : f64
    %cst_2 = arith.constant 2.3561944901923448 : f64
    %cst_3 = arith.constant -1.5707963267948966 : f64
    %cst_4 = arith.constant -1.5707963267948963 : f64
    %cst_5 = arith.constant -0.78539816339744828 : f64
    %cst_6 = arith.constant 0.39269908169872414 : f64
    %cst_7 = arith.constant -0.39269908169872414 : f64
    %cst_8 = arith.constant 0.78539816339744828 : f64
    %cst_9 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %5 = qco.rz(%cst_9) %1 : !qco.qubit -> !qco.qubit
    %6 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_9) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_9) %2 : !qco.qubit -> !qco.qubit
    %9 = qco.sx %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_9) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_9) %3 : !qco.qubit -> !qco.qubit
    %12 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_9) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.x %0 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_0) %14 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%13) targets (%arg0 = %15) {
      %43 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.rz(%cst) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_10, %targets_out_11 = qco.ctrl(%controls_out) targets (%arg0 = %16) {
      %43 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %cst_12 = arith.constant 0.3926990816987237 : f64
    %17 = qco.rz(%cst_12) %controls_out_10 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_2) %targets_out_11 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%10) targets (%arg0 = %18) {
      %43 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.rz(%cst_1) %targets_out_14 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%controls_out_13) targets (%arg0 = %19) {
      %43 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.rz(%cst_9) %controls_out_15 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_4) %targets_out_16 : !qco.qubit -> !qco.qubit
    %22 = qco.sx %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_9) %22 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%7) targets (%arg0 = %23) {
      %43 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.rz(%cst_9) %targets_out_18 : !qco.qubit -> !qco.qubit
    %25 = qco.sx %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_3) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_9) %controls_out_17 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_9) %28 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%29) targets (%arg0 = %20) {
      %43 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.rz(%cst_8) %targets_out_20 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%controls_out_19) targets (%arg0 = %30) {
      %43 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.rz(%cst_5) %controls_out_21 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_9) %targets_out_22 : !qco.qubit -> !qco.qubit
    %33 = qco.sx %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_9) %33 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%34) targets (%arg0 = %17) {
      %43 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.rz(%cst_8) %targets_out_24 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%controls_out_23) targets (%arg0 = %35) {
      %43 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qco.rz(%cst_5) %controls_out_25 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_7) %targets_out_26 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%31) targets (%arg0 = %37) {
      %43 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qco.rz(%cst_6) %targets_out_28 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%controls_out_27) targets (%arg0 = %38) {
      %43 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.rz(%cst_7) %controls_out_29 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_9) %targets_out_30 : !qco.qubit -> !qco.qubit
    %41 = qco.sx %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_9) %41 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %39 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<3>
    %qubit_out_31, %result_32 = qco.measure %36 : !qco.qubit
    cbit.store %result_32, %4[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_31 : !qco.qubit
    %qubit_out_33, %result_34 = qco.measure %42 : !qco.qubit
    qco.sink %qubit_out_33 : !qco.qubit
    cbit.store %result_34, %4[%c2] : !cbit.reg<3>
    qco.sink %26 : !qco.qubit
    qco.gphase(%cst_1)
    return %4 : !cbit.reg<3>
  }
}
