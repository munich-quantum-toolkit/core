module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = [], parameter_bounds = [array<f64: 0.000000e+00, 1.5707963267948966>]>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<16> attributes {mqt.entry_point} {
    %cst = arith.constant 1.318116071652818 : f64
    %cst_0 = arith.constant 1.3096389158918724 : f64
    %cst_1 = arith.constant 1.3002465638163236 : f64
    %cst_2 = arith.constant 1.289761425292083 : f64
    %cst_3 = arith.constant 1.277953555066321 : f64
    %cst_4 = arith.constant 1.2645189576252271 : f64
    %cst_5 = arith.constant 1.2490457723982544 : f64
    %cst_6 = arith.constant 1.2309594173407747 : f64
    %cst_7 = arith.constant 1.2094292028881888 : f64
    %cst_8 = arith.constant 1.183199640139716 : f64
    %cst_9 = arith.constant 1.1502619915109313 : f64
    %cst_10 = arith.constant 1.1071487177940904 : f64
    %cst_11 = arith.constant 1.0471975511965979 : f64
    %cst_12 = arith.constant 0.95531661812450918 : f64
    %cst_13 = arith.constant 0.78539816339744839 : f64
    %cst_14 = arith.constant -1.5707963267948961 : f64
    %cst_15 = arith.constant -3.1415926535897931 : f64
    %cst_16 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %c15 = arith.constant 15 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<16>
    %17 = qco.rx(%cst_16) %1 : !qco.qubit -> !qco.qubit
    %cst_17 = arith.constant 1.3181160716528177 : f64
    %18 = qco.rz(%cst_17) %17 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst) %0, %18 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_18 = arith.constant -1.5707963267948968 : f64
    %19 = qco.rz(%cst_18) %qubit0_out : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_16) %19 : !qco.qubit -> !qco.qubit
    %cst_19 = arith.constant -1.5707963267948966 : f64
    %21 = qco.rz(%cst_19) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst_16) %qubit1_out : !qco.qubit -> !qco.qubit
    %qubit0_out_20, %qubit1_out_21 = qco.rzz(%cst_16) %22, %21 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %23 = qco.rx(%cst_14) %qubit1_out_21 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_16) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_16) %qubit0_out_20 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_16) %2 : !qco.qubit -> !qco.qubit
    %cst_22 = arith.constant 1.3096389158918722 : f64
    %27 = qco.rz(%cst_22) %26 : !qco.qubit -> !qco.qubit
    %qubit0_out_23, %qubit1_out_24 = qco.rzz(%cst_0) %25, %27 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %28 = qco.rz(%cst_18) %qubit0_out_23 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_16) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_19) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_16) %qubit1_out_24 : !qco.qubit -> !qco.qubit
    %qubit0_out_25, %qubit1_out_26 = qco.rzz(%cst_16) %31, %30 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %32 = qco.rx(%cst_14) %qubit1_out_26 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_16) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_16) %qubit0_out_25 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_16) %3 : !qco.qubit -> !qco.qubit
    %cst_27 = arith.constant 1.3002465638163239 : f64
    %36 = qco.rz(%cst_27) %35 : !qco.qubit -> !qco.qubit
    %qubit0_out_28, %qubit1_out_29 = qco.rzz(%cst_1) %34, %36 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %37 = qco.rz(%cst_18) %qubit0_out_28 : !qco.qubit -> !qco.qubit
    %38 = qco.rx(%cst_16) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_19) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_16) %qubit1_out_29 : !qco.qubit -> !qco.qubit
    %qubit0_out_30, %qubit1_out_31 = qco.rzz(%cst_16) %40, %39 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %41 = qco.rx(%cst_14) %qubit1_out_31 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_16) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_16) %qubit0_out_30 : !qco.qubit -> !qco.qubit
    %44 = qco.rx(%cst_16) %4 : !qco.qubit -> !qco.qubit
    %cst_32 = arith.constant 1.2897614252920828 : f64
    %45 = qco.rz(%cst_32) %44 : !qco.qubit -> !qco.qubit
    %qubit0_out_33, %qubit1_out_34 = qco.rzz(%cst_2) %43, %45 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %46 = qco.rz(%cst_18) %qubit0_out_33 : !qco.qubit -> !qco.qubit
    %47 = qco.rx(%cst_16) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_19) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_16) %qubit1_out_34 : !qco.qubit -> !qco.qubit
    %qubit0_out_35, %qubit1_out_36 = qco.rzz(%cst_16) %49, %48 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %50 = qco.rx(%cst_14) %qubit1_out_36 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_16) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_16) %qubit0_out_35 : !qco.qubit -> !qco.qubit
    %53 = qco.rx(%cst_16) %5 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_3) %53 : !qco.qubit -> !qco.qubit
    %qubit0_out_37, %qubit1_out_38 = qco.rzz(%cst_3) %52, %54 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %55 = qco.rz(%cst_18) %qubit0_out_37 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_16) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_19) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_16) %qubit1_out_38 : !qco.qubit -> !qco.qubit
    %qubit0_out_39, %qubit1_out_40 = qco.rzz(%cst_16) %58, %57 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %59 = qco.rx(%cst_14) %qubit1_out_40 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_16) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_16) %qubit0_out_39 : !qco.qubit -> !qco.qubit
    %62 = qco.rx(%cst_16) %6 : !qco.qubit -> !qco.qubit
    %cst_41 = arith.constant 1.2645189576252269 : f64
    %63 = qco.rz(%cst_41) %62 : !qco.qubit -> !qco.qubit
    %qubit0_out_42, %qubit1_out_43 = qco.rzz(%cst_4) %61, %63 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %64 = qco.rz(%cst_18) %qubit0_out_42 : !qco.qubit -> !qco.qubit
    %65 = qco.rx(%cst_16) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_19) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rx(%cst_16) %qubit1_out_43 : !qco.qubit -> !qco.qubit
    %qubit0_out_44, %qubit1_out_45 = qco.rzz(%cst_16) %67, %66 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %68 = qco.rx(%cst_14) %qubit1_out_45 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_16) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_16) %qubit0_out_44 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_16) %7 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_5) %71 : !qco.qubit -> !qco.qubit
    %qubit0_out_46, %qubit1_out_47 = qco.rzz(%cst_5) %70, %72 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %73 = qco.rz(%cst_18) %qubit0_out_46 : !qco.qubit -> !qco.qubit
    %74 = qco.rx(%cst_16) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_19) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rx(%cst_16) %qubit1_out_47 : !qco.qubit -> !qco.qubit
    %qubit0_out_48, %qubit1_out_49 = qco.rzz(%cst_16) %76, %75 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %77 = qco.rx(%cst_14) %qubit1_out_49 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_16) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_16) %qubit0_out_48 : !qco.qubit -> !qco.qubit
    %80 = qco.rx(%cst_16) %8 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_6) %80 : !qco.qubit -> !qco.qubit
    %qubit0_out_50, %qubit1_out_51 = qco.rzz(%cst_6) %79, %81 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %82 = qco.rz(%cst_18) %qubit0_out_50 : !qco.qubit -> !qco.qubit
    %83 = qco.rx(%cst_16) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_19) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rx(%cst_16) %qubit1_out_51 : !qco.qubit -> !qco.qubit
    %qubit0_out_52, %qubit1_out_53 = qco.rzz(%cst_16) %85, %84 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %86 = qco.rx(%cst_14) %qubit1_out_53 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_16) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_16) %qubit0_out_52 : !qco.qubit -> !qco.qubit
    %89 = qco.rx(%cst_16) %9 : !qco.qubit -> !qco.qubit
    %cst_54 = arith.constant 1.209429202888189 : f64
    %90 = qco.rz(%cst_54) %89 : !qco.qubit -> !qco.qubit
    %qubit0_out_55, %qubit1_out_56 = qco.rzz(%cst_7) %88, %90 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %91 = qco.rz(%cst_18) %qubit0_out_55 : !qco.qubit -> !qco.qubit
    %92 = qco.rx(%cst_16) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_19) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rx(%cst_16) %qubit1_out_56 : !qco.qubit -> !qco.qubit
    %qubit0_out_57, %qubit1_out_58 = qco.rzz(%cst_16) %94, %93 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %95 = qco.rx(%cst_14) %qubit1_out_58 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_16) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_16) %qubit0_out_57 : !qco.qubit -> !qco.qubit
    %98 = qco.rx(%cst_16) %10 : !qco.qubit -> !qco.qubit
    %cst_59 = arith.constant 1.1831996401397156 : f64
    %99 = qco.rz(%cst_59) %98 : !qco.qubit -> !qco.qubit
    %qubit0_out_60, %qubit1_out_61 = qco.rzz(%cst_8) %97, %99 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %100 = qco.rz(%cst_18) %qubit0_out_60 : !qco.qubit -> !qco.qubit
    %101 = qco.rx(%cst_16) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_19) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rx(%cst_16) %qubit1_out_61 : !qco.qubit -> !qco.qubit
    %qubit0_out_62, %qubit1_out_63 = qco.rzz(%cst_16) %103, %102 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %104 = qco.rx(%cst_14) %qubit1_out_63 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst_16) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_16) %qubit0_out_62 : !qco.qubit -> !qco.qubit
    %107 = qco.rx(%cst_16) %11 : !qco.qubit -> !qco.qubit
    %cst_64 = arith.constant 1.1502619915109316 : f64
    %108 = qco.rz(%cst_64) %107 : !qco.qubit -> !qco.qubit
    %qubit0_out_65, %qubit1_out_66 = qco.rzz(%cst_9) %106, %108 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %109 = qco.rz(%cst_18) %qubit0_out_65 : !qco.qubit -> !qco.qubit
    %110 = qco.rx(%cst_16) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_19) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rx(%cst_16) %qubit1_out_66 : !qco.qubit -> !qco.qubit
    %qubit0_out_67, %qubit1_out_68 = qco.rzz(%cst_16) %112, %111 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %113 = qco.rx(%cst_14) %qubit1_out_68 : !qco.qubit -> !qco.qubit
    %114 = qco.rz(%cst_16) %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_16) %qubit0_out_67 : !qco.qubit -> !qco.qubit
    %116 = qco.rx(%cst_16) %12 : !qco.qubit -> !qco.qubit
    %117 = qco.rz(%cst_10) %116 : !qco.qubit -> !qco.qubit
    %qubit0_out_69, %qubit1_out_70 = qco.rzz(%cst_10) %115, %117 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %118 = qco.rz(%cst_18) %qubit0_out_69 : !qco.qubit -> !qco.qubit
    %119 = qco.rx(%cst_16) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.rz(%cst_19) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rx(%cst_16) %qubit1_out_70 : !qco.qubit -> !qco.qubit
    %qubit0_out_71, %qubit1_out_72 = qco.rzz(%cst_16) %121, %120 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %122 = qco.rx(%cst_14) %qubit1_out_72 : !qco.qubit -> !qco.qubit
    %123 = qco.rz(%cst_16) %122 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_16) %qubit0_out_71 : !qco.qubit -> !qco.qubit
    %125 = qco.rx(%cst_16) %13 : !qco.qubit -> !qco.qubit
    %cst_73 = arith.constant 1.0471975511965983 : f64
    %126 = qco.rz(%cst_73) %125 : !qco.qubit -> !qco.qubit
    %qubit0_out_74, %qubit1_out_75 = qco.rzz(%cst_11) %124, %126 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %127 = qco.rz(%cst_18) %qubit0_out_74 : !qco.qubit -> !qco.qubit
    %128 = qco.rx(%cst_16) %127 : !qco.qubit -> !qco.qubit
    %129 = qco.rz(%cst_19) %128 : !qco.qubit -> !qco.qubit
    %130 = qco.rx(%cst_16) %qubit1_out_75 : !qco.qubit -> !qco.qubit
    %qubit0_out_76, %qubit1_out_77 = qco.rzz(%cst_16) %130, %129 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %131 = qco.rx(%cst_14) %qubit1_out_77 : !qco.qubit -> !qco.qubit
    %132 = qco.rz(%cst_16) %131 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst_16) %qubit0_out_76 : !qco.qubit -> !qco.qubit
    %134 = qco.rx(%cst_16) %14 : !qco.qubit -> !qco.qubit
    %cst_78 = arith.constant 0.95531661812450874 : f64
    %135 = qco.rz(%cst_78) %134 : !qco.qubit -> !qco.qubit
    %qubit0_out_79, %qubit1_out_80 = qco.rzz(%cst_12) %133, %135 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %136 = qco.rz(%cst_18) %qubit0_out_79 : !qco.qubit -> !qco.qubit
    %137 = qco.rx(%cst_16) %136 : !qco.qubit -> !qco.qubit
    %138 = qco.rz(%cst_19) %137 : !qco.qubit -> !qco.qubit
    %139 = qco.rx(%cst_16) %qubit1_out_80 : !qco.qubit -> !qco.qubit
    %qubit0_out_81, %qubit1_out_82 = qco.rzz(%cst_16) %139, %138 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %140 = qco.rx(%cst_14) %qubit1_out_82 : !qco.qubit -> !qco.qubit
    %141 = qco.rz(%cst_16) %140 : !qco.qubit -> !qco.qubit
    %142 = qco.rz(%cst_16) %qubit0_out_81 : !qco.qubit -> !qco.qubit
    %143 = qco.rx(%cst_16) %15 : !qco.qubit -> !qco.qubit
    %cst_83 = arith.constant 0.78539816339744828 : f64
    %144 = qco.rz(%cst_83) %143 : !qco.qubit -> !qco.qubit
    %qubit0_out_84, %qubit1_out_85 = qco.rzz(%cst_13) %142, %144 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %145 = qco.rz(%cst_18) %qubit0_out_84 : !qco.qubit -> !qco.qubit
    %146 = qco.rx(%cst_16) %145 : !qco.qubit -> !qco.qubit
    %147 = qco.rz(%cst_19) %146 : !qco.qubit -> !qco.qubit
    %148 = qco.rx(%cst_16) %qubit1_out_85 : !qco.qubit -> !qco.qubit
    %qubit0_out_86, %qubit1_out_87 = qco.rzz(%cst_16) %148, %147 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %149 = qco.rx(%cst_14) %qubit1_out_87 : !qco.qubit -> !qco.qubit
    %150 = qco.rz(%cst_16) %149 : !qco.qubit -> !qco.qubit
    %151 = qco.rz(%cst_16) %qubit0_out_86 : !qco.qubit -> !qco.qubit
    %152 = qco.rx(%cst_15) %151 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %24 : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<16>
    %qubit_out_88, %result_89 = qco.measure %33 : !qco.qubit
    cbit.store %result_89, %16[%c1] : !cbit.reg<16>
    %qubit_out_90, %result_91 = qco.measure %42 : !qco.qubit
    cbit.store %result_91, %16[%c2] : !cbit.reg<16>
    %qubit_out_92, %result_93 = qco.measure %51 : !qco.qubit
    cbit.store %result_93, %16[%c3] : !cbit.reg<16>
    %qubit_out_94, %result_95 = qco.measure %60 : !qco.qubit
    cbit.store %result_95, %16[%c4] : !cbit.reg<16>
    %qubit_out_96, %result_97 = qco.measure %69 : !qco.qubit
    cbit.store %result_97, %16[%c5] : !cbit.reg<16>
    %qubit_out_98, %result_99 = qco.measure %78 : !qco.qubit
    cbit.store %result_99, %16[%c6] : !cbit.reg<16>
    %qubit_out_100, %result_101 = qco.measure %87 : !qco.qubit
    cbit.store %result_101, %16[%c7] : !cbit.reg<16>
    %qubit_out_102, %result_103 = qco.measure %96 : !qco.qubit
    cbit.store %result_103, %16[%c8] : !cbit.reg<16>
    %qubit_out_104, %result_105 = qco.measure %105 : !qco.qubit
    cbit.store %result_105, %16[%c9] : !cbit.reg<16>
    %qubit_out_106, %result_107 = qco.measure %114 : !qco.qubit
    cbit.store %result_107, %16[%c10] : !cbit.reg<16>
    %qubit_out_108, %result_109 = qco.measure %123 : !qco.qubit
    cbit.store %result_109, %16[%c11] : !cbit.reg<16>
    %qubit_out_110, %result_111 = qco.measure %132 : !qco.qubit
    cbit.store %result_111, %16[%c12] : !cbit.reg<16>
    %qubit_out_112, %result_113 = qco.measure %141 : !qco.qubit
    cbit.store %result_113, %16[%c13] : !cbit.reg<16>
    %qubit_out_114, %result_115 = qco.measure %150 : !qco.qubit
    cbit.store %result_115, %16[%c14] : !cbit.reg<16>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_88 : !qco.qubit
    qco.sink %qubit_out_90 : !qco.qubit
    qco.sink %qubit_out_92 : !qco.qubit
    qco.sink %qubit_out_94 : !qco.qubit
    qco.sink %qubit_out_96 : !qco.qubit
    qco.sink %qubit_out_98 : !qco.qubit
    qco.sink %qubit_out_100 : !qco.qubit
    qco.sink %qubit_out_102 : !qco.qubit
    qco.sink %qubit_out_104 : !qco.qubit
    qco.sink %qubit_out_106 : !qco.qubit
    qco.sink %qubit_out_108 : !qco.qubit
    qco.sink %qubit_out_110 : !qco.qubit
    qco.sink %qubit_out_112 : !qco.qubit
    qco.sink %qubit_out_114 : !qco.qubit
    %qubit_out_116, %result_117 = qco.measure %152 : !qco.qubit
    qco.sink %qubit_out_116 : !qco.qubit
    cbit.store %result_117, %16[%c15] : !cbit.reg<16>
    %cst_118 = arith.constant 2.3561944901923582 : f64
    qco.gphase(%cst_118)
    return %16 : !cbit.reg<16>
  }
}
