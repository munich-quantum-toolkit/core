module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 0>, input_count = 5 : i64, sites = array<i64: 0, 1, 2, 3, 4>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<5> attributes {mqt.entry_point} {
    %cst = arith.constant 1.5707963267948968 : f64
    %cst_0 = arith.constant 4.7123889803846897 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %cst_2 = arith.constant 0.78539816339744828 : f64
    %cst_3 = arith.constant 0.098174770424681145 : f64
    %cst_4 = arith.constant 0.19634954084936229 : f64
    %cst_5 = arith.constant 0.39269908169872414 : f64
    %cst_6 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<5>
    %6 = qco.r(%cst_6, %cst_1) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.r(%cst_6, %cst_1) %2 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_6, %cst_1) %3 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_6, %cst_1) %4 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_2, %cst_6) %0 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%9) targets (%arg0 = %10) {
      %18 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %18 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qco.r(%cst_2, %cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%controls_out) targets (%arg0 = %11) {
      %18 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %18 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qco.r(%cst_5, %cst) %targets_out_8 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%8) targets (%arg0 = %12) {
      %18 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %18 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %13 = qco.r(%cst_5, %cst_0) %targets_out_10 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%controls_out_9) targets (%arg0 = %13) {
      %18 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %18 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.r(%cst_4, %cst) %targets_out_12 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%7) targets (%arg0 = %14) {
      %18 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %18 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qco.r(%cst_4, %cst_0) %targets_out_14 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%controls_out_13) targets (%arg0 = %15) {
      %18 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %18 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.r(%cst_3, %cst_6) %targets_out_16 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%6) targets (%arg0 = %16) {
      %18 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %18 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.r(%cst_3, %cst_0) %targets_out_18 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%controls_out_17) targets (%arg0 = %17) {
      %18 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %18 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %qubit_out, %result = qco.measure %targets_out_20 : !qco.qubit
    cbit.store %result, %5[%c0] : !cbit.reg<5>
    %qubit_out_21, %result_22 = qco.measure %controls_out_19 : !qco.qubit
    cbit.store %result_22, %5[%c1] : !cbit.reg<5>
    %qubit_out_23, %result_24 = qco.measure %controls_out_15 : !qco.qubit
    cbit.store %result_24, %5[%c2] : !cbit.reg<5>
    %qubit_out_25, %result_26 = qco.measure %controls_out_11 : !qco.qubit
    cbit.store %result_26, %5[%c3] : !cbit.reg<5>
    qco.sink %qubit_out_21 : !qco.qubit
    qco.sink %qubit_out_23 : !qco.qubit
    qco.sink %qubit_out_25 : !qco.qubit
    %qubit_out_27, %result_28 = qco.measure %controls_out_7 : !qco.qubit
    qco.sink %qubit_out_27 : !qco.qubit
    cbit.store %result_28, %5[%c4] : !cbit.reg<5>
    qco.sink %qubit_out : !qco.qubit
    return %5 : !cbit.reg<5>
  }
}
