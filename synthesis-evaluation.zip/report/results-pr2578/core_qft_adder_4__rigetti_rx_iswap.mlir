module attributes {mqt.layout = {initial = array<i64: 1, 0, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 3.1415926535897931 : f64
    %cst_0 = arith.constant -3.1415926535897931 : f64
    %cst_1 = arith.constant -2.3561944901923448 : f64
    %cst_2 = arith.constant -1.5707963267948966 : f64
    %cst_3 = arith.constant 1.5707963267948966 : f64
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.rz(%cst_2) %0 : !qco.qubit -> !qco.qubit
    %cst_4 = arith.constant -1.5707963267948968 : f64
    %5 = qco.rz(%cst_4) %2 : !qco.qubit -> !qco.qubit
    %6 = qco.rx(%cst_3) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_2) %6 : !qco.qubit -> !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %9 = qco.rz(%cst_3) %3 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_3) %9 : !qco.qubit -> !qco.qubit
    %cst_5 = arith.constant 2.3561944901923448 : f64
    %11 = qco.rz(%cst_5) %10 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %7, %11 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %12 = qco.rz(%cst_0) %qubit1_out : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_3) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_1) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_3) %14 : !qco.qubit -> !qco.qubit
    %qubit0_out_6, %qubit1_out_7 = qco.iswap %qubit0_out, %15 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %16 = qco.rx(%cst_3) %qubit1_out_7 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_0) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_2) %qubit0_out_6 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_3) %18 : !qco.qubit -> !qco.qubit
    %cst_8 = arith.constant -0.78539816339744916 : f64
    %20 = qco.rz(%cst_8) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_3) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_3) %21 : !qco.qubit -> !qco.qubit
    %qubit0_out_9, %qubit1_out_10 = qco.iswap %4, %17 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %23 = qco.rx(%cst) %qubit1_out_10 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_2) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_0) %qubit0_out_9 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_3) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_2) %26 : !qco.qubit -> !qco.qubit
    %qubit0_out_11, %qubit1_out_12 = qco.iswap %27, %24 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_13 = arith.constant -1.5707963267948961 : f64
    %28 = qco.rz(%cst_13) %qubit1_out_12 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_3) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_5) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_3) %qubit0_out_11 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_2) %1 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_3) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_3) %33 : !qco.qubit -> !qco.qubit
    %qubit0_out_14, %qubit1_out_15 = qco.iswap %34, %30 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %35 = qco.rz(%cst_0) %qubit1_out_15 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_3) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_1) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rx(%cst_3) %37 : !qco.qubit -> !qco.qubit
    %qubit0_out_16, %qubit1_out_17 = qco.iswap %qubit0_out_14, %38 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %39 = qco.rz(%cst_5) %qubit1_out_17 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_3) %qubit0_out_16 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_3) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_5) %41 : !qco.qubit -> !qco.qubit
    %qubit0_out_18, %qubit1_out_19 = qco.iswap %42, %22 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %43 = qco.rx(%cst) %qubit1_out_19 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_2) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_0) %qubit0_out_18 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst_3) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_2) %46 : !qco.qubit -> !qco.qubit
    %qubit0_out_20, %qubit1_out_21 = qco.iswap %47, %44 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %48 = qco.rz(%cst_3) %qubit1_out_21 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_3) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_3) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_3) %qubit0_out_20 : !qco.qubit -> !qco.qubit
    %qubit0_out_22, %qubit1_out_23 = qco.iswap %50, %39 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %52 = qco.rx(%cst_3) %qubit1_out_23 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_1) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rx(%cst_3) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_0) %54 : !qco.qubit -> !qco.qubit
    %qubit0_out_24, %qubit1_out_25 = qco.iswap %qubit0_out_22, %55 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %56 = qco.rz(%cst_4) %qubit1_out_25 : !qco.qubit -> !qco.qubit
    %57 = qco.rx(%cst_3) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_3) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_2) %qubit0_out_24 : !qco.qubit -> !qco.qubit
    %60 = qco.rx(%cst_3) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_1) %60 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %61 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    %qubit_out_26, %result_27 = qco.measure %58 : !qco.qubit
    qco.sink %qubit_out_26 : !qco.qubit
    cbit.store %result_27, %8[%c1] : !cbit.reg<4>
    %qubit_out_28, %result_29 = qco.measure %51 : !qco.qubit
    cbit.store %result_29, %8[%c2] : !cbit.reg<4>
    qco.sink %qubit_out_28 : !qco.qubit
    %qubit_out_30, %result_31 = qco.measure %31 : !qco.qubit
    qco.sink %qubit_out_30 : !qco.qubit
    cbit.store %result_31, %8[%c3] : !cbit.reg<4>
    %cst_32 = arith.constant 1.9634954084936189 : f64
    qco.gphase(%cst_32)
    return %8 : !cbit.reg<4>
  }
}
