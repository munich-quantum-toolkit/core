module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 0>, input_count = 7 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = [], parameter_bounds = [array<f64: 0.000000e+00, 1.5707963267948966>]>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant 0.78539816339744828 : f64
    %cst_0 = arith.constant 0.39269908169872414 : f64
    %cst_1 = arith.constant 0.19634954084936207 : f64
    %cst_2 = arith.constant 0.098174770424681035 : f64
    %cst_3 = arith.constant 0.049087385212340517 : f64
    %cst_4 = arith.constant -3.1415926535897931 : f64
    %cst_5 = arith.constant 0.024543692606170259 : f64
    %cst_6 = arith.constant 1.5707963267948966 : f64
    %cst_7 = arith.constant -1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %8 = qco.rz(%cst_7) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_6) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_6) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_7) %2 : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_6) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_6) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_7) %3 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_6) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_6) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_7) %4 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_6) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_6) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_7) %5 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_6) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_6) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_7) %6 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_6) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_6) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_6) %0 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst) %26 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst) %25, %27 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %28 = qco.rz(%cst_6) %qubit0_out : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_4) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_6) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_0) %qubit1_out : !qco.qubit -> !qco.qubit
    %qubit0_out_8, %qubit1_out_9 = qco.rzz(%cst_0) %22, %31 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %32 = qco.rz(%cst_6) %qubit0_out_8 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_4) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_6) %33 : !qco.qubit -> !qco.qubit
    %cst_10 = arith.constant 0.19634954084936229 : f64
    %35 = qco.rz(%cst_10) %qubit1_out_9 : !qco.qubit -> !qco.qubit
    %qubit0_out_11, %qubit1_out_12 = qco.rzz(%cst_1) %19, %35 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %36 = qco.rz(%cst_6) %qubit0_out_11 : !qco.qubit -> !qco.qubit
    %37 = qco.rx(%cst_4) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_6) %37 : !qco.qubit -> !qco.qubit
    %cst_13 = arith.constant 0.098174770424681145 : f64
    %39 = qco.rz(%cst_13) %qubit1_out_12 : !qco.qubit -> !qco.qubit
    %qubit0_out_14, %qubit1_out_15 = qco.rzz(%cst_2) %16, %39 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %40 = qco.rz(%cst_6) %qubit0_out_14 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_4) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_6) %41 : !qco.qubit -> !qco.qubit
    %cst_16 = arith.constant 0.049087385212340351 : f64
    %43 = qco.rz(%cst_16) %qubit1_out_15 : !qco.qubit -> !qco.qubit
    %qubit0_out_17, %qubit1_out_18 = qco.rzz(%cst_3) %13, %43 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %44 = qco.rz(%cst_6) %qubit0_out_17 : !qco.qubit -> !qco.qubit
    %45 = qco.rx(%cst_4) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_6) %45 : !qco.qubit -> !qco.qubit
    %cst_19 = arith.constant 0.024543692606170175 : f64
    %47 = qco.rz(%cst_19) %qubit1_out_18 : !qco.qubit -> !qco.qubit
    %qubit0_out_20, %qubit1_out_21 = qco.rzz(%cst_5) %10, %47 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %48 = qco.rz(%cst_6) %qubit0_out_20 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_4) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_6) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rx(%cst_7) %qubit1_out_21 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %51 : !qco.qubit
    cbit.store %result, %7[%c0] : !cbit.reg<7>
    %qubit_out_22, %result_23 = qco.measure %50 : !qco.qubit
    cbit.store %result_23, %7[%c1] : !cbit.reg<7>
    %qubit_out_24, %result_25 = qco.measure %46 : !qco.qubit
    cbit.store %result_25, %7[%c2] : !cbit.reg<7>
    %qubit_out_26, %result_27 = qco.measure %42 : !qco.qubit
    cbit.store %result_27, %7[%c3] : !cbit.reg<7>
    %qubit_out_28, %result_29 = qco.measure %38 : !qco.qubit
    cbit.store %result_29, %7[%c4] : !cbit.reg<7>
    %qubit_out_30, %result_31 = qco.measure %34 : !qco.qubit
    cbit.store %result_31, %7[%c5] : !cbit.reg<7>
    qco.sink %qubit_out_22 : !qco.qubit
    qco.sink %qubit_out_24 : !qco.qubit
    qco.sink %qubit_out_26 : !qco.qubit
    qco.sink %qubit_out_28 : !qco.qubit
    qco.sink %qubit_out_30 : !qco.qubit
    %qubit_out_32, %result_33 = qco.measure %30 : !qco.qubit
    qco.sink %qubit_out_32 : !qco.qubit
    cbit.store %result_33, %7[%c6] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    %cst_34 = arith.constant 3.1415926535897931 : f64
    qco.gphase(%cst_34)
    return %7 : !cbit.reg<7>
  }
}
