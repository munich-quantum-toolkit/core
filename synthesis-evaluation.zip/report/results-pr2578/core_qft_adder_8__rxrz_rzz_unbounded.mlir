module attributes {mqt.layout = {initial = array<i64: 3, 1, 2, 0, 5, 7, 4, 6>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant 0.19634954084936229 : f64
    %cst_0 = arith.constant 0.39269908169872414 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %cst_2 = arith.constant -3.1415926535897931 : f64
    %cst_3 = arith.constant -0.78539816339744828 : f64
    %cst_4 = arith.constant -0.39269908169872414 : f64
    %cst_5 = arith.constant -5.000000e-01 : f64
    %cst_6 = arith.constant -0.19634954084936229 : f64
    %cst_7 = arith.constant 1.5707963267948966 : f64
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %cst_8 = arith.constant 0.78539816339744828 : f64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.rz(%cst_7) %0 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_2) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_1) %1 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_2) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_1) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_1) %4 : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_2) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_1) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_1) %5 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_2) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_1) %17 : !qco.qubit -> !qco.qubit
    %19 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %20 = qco.rz(%cst_7) %6 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_7) %20 : !qco.qubit -> !qco.qubit
    %cst_9 = arith.constant 2.3561944901923448 : f64
    %22 = qco.rz(%cst_9) %21 : !qco.qubit -> !qco.qubit
    %23 = arith.mulf %cst_7, %cst_5 : f64
    %qubit0_out, %qubit1_out = qco.rzz(%23) %15, %22 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %24 = qco.rz(%cst_9) %qubit0_out : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_7) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_9) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_0) %qubit1_out : !qco.qubit -> !qco.qubit
    %28 = arith.mulf %cst_8, %cst_5 : f64
    %qubit0_out_10, %qubit1_out_11 = qco.rzz(%28) %7, %27 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %29 = qco.rz(%cst_0) %qubit0_out_10 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst) %qubit1_out_11 : !qco.qubit -> !qco.qubit
    %31 = arith.mulf %cst_0, %cst_5 : f64
    %qubit0_out_12, %qubit1_out_13 = qco.rzz(%31) %18, %30 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %32 = qco.rz(%cst) %qubit0_out_12 : !qco.qubit -> !qco.qubit
    %qubit0_out_14, %qubit1_out_15 = qco.rzz(%23) %29, %26 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %33 = qco.rz(%cst_9) %qubit0_out_14 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_7) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_9) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_0) %qubit1_out_15 : !qco.qubit -> !qco.qubit
    %qubit0_out_16, %qubit1_out_17 = qco.rzz(%28) %32, %36 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %37 = qco.rz(%cst_0) %qubit0_out_16 : !qco.qubit -> !qco.qubit
    %qubit0_out_18, %qubit1_out_19 = qco.rzz(%23) %37, %35 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %38 = qco.rz(%cst_3) %qubit0_out_18 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_7) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_2) %qubit1_out_13 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_1) %40 : !qco.qubit -> !qco.qubit
    %qubit0_out_20, %qubit1_out_21 = qco.rzz(%cst_1) %9, %41 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %42 = qco.rz(%cst_7) %qubit1_out_21 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_2) %42 : !qco.qubit -> !qco.qubit
    %cst_22 = arith.constant -0.78539816339744872 : f64
    %44 = qco.rz(%cst_22) %43 : !qco.qubit -> !qco.qubit
    %qubit0_out_23, %qubit1_out_24 = qco.rzz(%23) %2, %44 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %45 = qco.rz(%cst_3) %qubit0_out_23 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_0) %qubit1_out_24 : !qco.qubit -> !qco.qubit
    %qubit0_out_25, %qubit1_out_26 = qco.rzz(%28) %12, %46 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %47 = qco.rz(%cst_0) %qubit0_out_25 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst) %qubit1_out_26 : !qco.qubit -> !qco.qubit
    %qubit0_out_27, %qubit1_out_28 = qco.rzz(%31) %3, %48 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %49 = qco.rz(%cst) %qubit0_out_27 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_2) %qubit1_out_17 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_1) %50 : !qco.qubit -> !qco.qubit
    %qubit0_out_29, %qubit1_out_30 = qco.rzz(%cst_1) %45, %51 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %52 = qco.rz(%cst_7) %qubit1_out_30 : !qco.qubit -> !qco.qubit
    %53 = qco.rx(%cst_2) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_22) %53 : !qco.qubit -> !qco.qubit
    %qubit0_out_31, %qubit1_out_32 = qco.rzz(%23) %47, %54 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %55 = qco.rz(%cst_3) %qubit0_out_31 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_0) %qubit1_out_32 : !qco.qubit -> !qco.qubit
    %qubit0_out_33, %qubit1_out_34 = qco.rzz(%28) %49, %56 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %57 = qco.rz(%cst_0) %qubit0_out_33 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_2) %qubit1_out_19 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_1) %58 : !qco.qubit -> !qco.qubit
    %qubit0_out_35, %qubit1_out_36 = qco.rzz(%cst_1) %55, %59 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %60 = qco.rz(%cst_7) %qubit1_out_36 : !qco.qubit -> !qco.qubit
    %61 = qco.rx(%cst_2) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_22) %61 : !qco.qubit -> !qco.qubit
    %qubit0_out_37, %qubit1_out_38 = qco.rzz(%23) %57, %62 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %63 = qco.rz(%cst_3) %qubit0_out_37 : !qco.qubit -> !qco.qubit
    %qubit0_out_39, %qubit1_out_40 = qco.rzz(%cst_1) %63, %39 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %cst_41 = arith.constant -1.5707963267948961 : f64
    %64 = qco.rz(%cst_41) %qubit1_out_40 : !qco.qubit -> !qco.qubit
    %65 = qco.rx(%cst_7) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_1) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_3) %qubit1_out_38 : !qco.qubit -> !qco.qubit
    %68 = arith.mulf %cst_1, %cst_5 : f64
    %qubit0_out_42, %qubit1_out_43 = qco.rzz(%68) %66, %67 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %69 = qco.rz(%cst_3) %qubit0_out_42 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_7) %qubit1_out_43 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_7) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_7) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_3) %qubit1_out_34 : !qco.qubit -> !qco.qubit
    %qubit0_out_44, %qubit1_out_45 = qco.rzz(%68) %72, %73 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %74 = qco.rz(%cst_3) %qubit0_out_44 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_4) %qubit1_out_45 : !qco.qubit -> !qco.qubit
    %76 = arith.mulf %cst_3, %cst_5 : f64
    %qubit0_out_46, %qubit1_out_47 = qco.rzz(%76) %69, %75 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %77 = qco.rz(%cst_4) %qubit0_out_46 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_7) %qubit1_out_47 : !qco.qubit -> !qco.qubit
    %79 = qco.rx(%cst_7) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_7) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_3) %qubit1_out_28 : !qco.qubit -> !qco.qubit
    %qubit0_out_48, %qubit1_out_49 = qco.rzz(%68) %80, %81 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %82 = qco.rz(%cst_3) %qubit0_out_48 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_4) %qubit1_out_49 : !qco.qubit -> !qco.qubit
    %qubit0_out_50, %qubit1_out_51 = qco.rzz(%76) %74, %83 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %84 = qco.rz(%cst_4) %qubit0_out_50 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_6) %qubit1_out_51 : !qco.qubit -> !qco.qubit
    %86 = arith.mulf %cst_4, %cst_5 : f64
    %qubit0_out_52, %qubit1_out_53 = qco.rzz(%86) %77, %85 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %87 = qco.rz(%cst_6) %qubit0_out_52 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_7) %qubit1_out_53 : !qco.qubit -> !qco.qubit
    %89 = qco.rx(%cst_7) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_7) %89 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %87 : !qco.qubit
    cbit.store %result, %19[%c0] : !cbit.reg<8>
    %qubit_out_54, %result_55 = qco.measure %84 : !qco.qubit
    cbit.store %result_55, %19[%c1] : !cbit.reg<8>
    %qubit_out_56, %result_57 = qco.measure %82 : !qco.qubit
    cbit.store %result_57, %19[%c2] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_54 : !qco.qubit
    qco.sink %qubit_out_56 : !qco.qubit
    %qubit_out_58, %result_59 = qco.measure %90 : !qco.qubit
    qco.sink %qubit_out_58 : !qco.qubit
    cbit.store %result_59, %19[%c3] : !cbit.reg<8>
    %qubit_out_60, %result_61 = qco.measure %qubit0_out_39 : !qco.qubit
    cbit.store %result_61, %19[%c4] : !cbit.reg<8>
    %qubit_out_62, %result_63 = qco.measure %qubit0_out_35 : !qco.qubit
    cbit.store %result_63, %19[%c5] : !cbit.reg<8>
    %qubit_out_64, %result_65 = qco.measure %qubit0_out_29 : !qco.qubit
    cbit.store %result_65, %19[%c6] : !cbit.reg<8>
    qco.sink %qubit_out_60 : !qco.qubit
    qco.sink %qubit_out_62 : !qco.qubit
    qco.sink %qubit_out_64 : !qco.qubit
    %qubit_out_66, %result_67 = qco.measure %qubit0_out_20 : !qco.qubit
    qco.sink %qubit_out_66 : !qco.qubit
    cbit.store %result_67, %19[%c7] : !cbit.reg<8>
    %cst_68 = arith.constant 1.6689710972195744 : f64
    qco.gphase(%cst_68)
    return %19 : !cbit.reg<8>
  }
}
