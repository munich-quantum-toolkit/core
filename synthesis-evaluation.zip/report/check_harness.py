"""Small runnable checks for layout-correct validation and static metrics."""
from pathlib import Path
from tempfile import TemporaryDirectory
import numpy as np
from qiskit import QuantumCircuit, ClassicalRegister, qpy
from qiskit.quantum_info import Operator, random_statevector
from qiskit.transpiler import Layout, TranspileLayout
from evaluate import counts, logical_evolve, measurement_probabilities, validate

for n in [2,3,5]:
    original=QuantumCircuit(n,global_phase=.137)
    original.h(1);original.cz(0,1);original.ry(.723,0)
    if n>2:original.rx(.251,2)
    initial=[(i+1)%n for i in range(n)]
    compiled=QuantumCircuit(n)
    compiled.compose(original,qubits=initial,inplace=True)
    compiled.swap(0,1)
    compiled._layout=TranspileLayout(
        initial_layout=Layout({q:initial[i] for i,q in enumerate(original.qubits)}),
        input_qubit_mapping={q:i for i,q in enumerate(original.qubits)},
        final_layout=Layout({q:(1 if i==0 else 0 if i==1 else i) for i,q in enumerate(compiled.qubits)}),
        _input_qubit_count=n,_output_qubit_list=compiled.qubits,
    )
    assert np.max(np.abs(Operator(original).data-Operator(compiled).data))>.1
    assert np.max(np.abs(Operator.from_circuit(original).data-Operator.from_circuit(compiled).data))<1e-12
    state=random_statevector(2**n,seed=2578)
    assert np.max(np.abs(logical_evolve(state,original)-logical_evolve(state,compiled)))<1e-12
    with TemporaryDirectory() as directory:
        path=Path(directory)/'reference.qpy'
        with path.open('wb') as stream:qpy.dump(original,stream)
        case=dict(origin='synthetic',reference=path.name,measured=False)
        result=validate(case,None,compiled,Path(directory),1)
        assert result['passed'],result
    measured_original=original.copy();measured_original.add_register(ClassicalRegister(n,'results'))
    measured_compiled=compiled.copy();measured_compiled.add_register(ClassicalRegister(n,'results'))
    final=compiled.layout.final_index_layout()
    for q in range(n):
        c=(q+1)%n
        measured_original.measure(q,c)
        measured_compiled.measure(final[q],c)
    assert np.max(np.abs(measurement_probabilities(measured_original)-measurement_probabilities(measured_compiled)))<1e-12
    with TemporaryDirectory() as directory:
        path=Path(directory)/'reference.qpy'
        with path.open('wb') as stream:qpy.dump(measured_original,stream)
        case=dict(origin='synthetic',reference=path.name,measured=True)
        result=validate(case,None,measured_compiled,Path(directory),1)
        assert result['passed'],result

barrier=QuantumCircuit(2);barrier.barrier()
assert counts(barrier)['native_2q']==0 and counts(barrier)['two_qubit_depth']==0
nested=QuantumCircuit(2,1);nested.x(0)
with nested.if_test((nested.clbits[0],1)):
    nested.cx(0,1);nested.cz(0,1);nested.cx(1,0)
metrics=counts(nested)
assert metrics['native_1q']==1 and metrics['native_2q']==3,metrics
assert metrics['depth'] is None and metrics['two_qubit_depth'] is None
print('PASS: nonidentity initial/final layouts at 2/3/5 qubits, full-phase matrices/states, classical measurement maps, nested counts, barrier exclusion')
from evaluate import distribution_check
ideal={'00':.5,'11':.5}
assert distribution_check({'00':256,'11':256},ideal)['passed']
assert not distribution_check({'00':512},ideal)['passed']
assert not distribution_check({'00':256,'10':256},ideal)['passed']
# Correct sparse observations must remain acceptable for broad uniform support.
uniform={format(i,'08b'):1/256 for i in range(256)}
draw=np.random.default_rng(2578).multinomial(512,[1/256]*256)
samples={format(i,'08b'):int(count) for i,count in enumerate(draw) if count}
assert distribution_check(samples,uniform)['passed']
print('PASS: DKW distribution check accepts ideal/sparse sampling, rejects collapsed GHZ and impossible outcomes')
