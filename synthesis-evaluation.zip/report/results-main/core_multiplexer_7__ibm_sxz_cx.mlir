module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 0>, input_count = 7 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant 4.3906384259880475 : f64
    %cst_0 = arith.constant -1.3734007669450157 : f64
    %cst_1 = arith.constant 5.4977871437821371 : f64
    %cst_2 = arith.constant 5.1050880620834134 : f64
    %cst_3 = arith.constant 3.5342917352885181 : f64
    %cst_4 = arith.constant 3.338988213439674 : f64
    %cst_5 = arith.constant 4.9087385212340511 : f64
    %cst_6 = arith.constant 3.1415926535897927 : f64
    %cst_7 = arith.constant 3.3379421944391554 : f64
    %cst_8 = arith.constant 4.8105637508093704 : f64
    %cst_9 = arith.constant 3.2397674240144743 : f64
    %cst_10 = arith.constant 4.76147636559703 : f64
    %cst_11 = arith.constant 3.1906800388021344 : f64
    %cst_12 = arith.constant -4.7123889803846897 : f64
    %cst_13 = arith.constant 3.9269908169872432 : f64
    %cst_14 = arith.constant 3.1415926535897936 : f64
    %cst_15 = arith.constant 4.736932672990859 : f64
    %cst_16 = arith.constant -1.5707963267948966 : f64
    %cst_17 = arith.constant 3.1415926535897962 : f64
    %cst_18 = arith.constant 3.1661363461959651 : f64
    %cst_19 = arith.constant -4.7123889803846932 : f64
    %cst_20 = arith.constant 3.1415926535897931 : f64
    %cst_21 = arith.constant -6.2831853071795862 : f64
    %cst_22 = arith.constant 4.7123889803846897 : f64
    %cst_23 = arith.constant 2.819842099193151 : f64
    %cst_24 = arith.constant 1.2490457723982544 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %cst_25 = arith.constant 1.5707963267948966 : f64
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %8 = qco.rz(%cst_25) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.sx %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_25) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_25) %2 : !qco.qubit -> !qco.qubit
    %12 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_25) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_25) %3 : !qco.qubit -> !qco.qubit
    %15 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_25) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_25) %4 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_25) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_25) %5 : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_25) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_25) %6 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_25) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_24) %0 : !qco.qubit -> !qco.qubit
    %27 = qco.x %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_23) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.sx %25 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_16) %29 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%30) targets (%arg0 = %28) {
      %145 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.rz(%cst_21) %targets_out : !qco.qubit -> !qco.qubit
    %32 = qco.sx %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_20) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_12) %controls_out : !qco.qubit -> !qco.qubit
    %35 = qco.sx %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_13) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.sx %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_20) %37 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%38) targets (%arg0 = %33) {
      %145 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.rz(%cst_16) %targets_out_27 : !qco.qubit -> !qco.qubit
    %40 = qco.sx %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_1) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.sx %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_0) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.sx %controls_out_26 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_20) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.x %43 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_4) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %22 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_22) %48 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%49) targets (%arg0 = %47) {
      %145 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qco.rz(%cst_21) %targets_out_29 : !qco.qubit -> !qco.qubit
    %51 = qco.sx %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_20) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_12) %controls_out_28 : !qco.qubit -> !qco.qubit
    %54 = qco.sx %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_3) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.sx %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_20) %56 : !qco.qubit -> !qco.qubit
    %controls_out_30, %targets_out_31 = qco.ctrl(%57) targets (%arg0 = %52) {
      %145 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = qco.rz(%cst_22) %targets_out_31 : !qco.qubit -> !qco.qubit
    %59 = qco.sx %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_2) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.sx %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.sx %controls_out_30 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_20) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.x %62 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_23) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.sx %19 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_22) %67 : !qco.qubit -> !qco.qubit
    %controls_out_32, %targets_out_33 = qco.ctrl(%68) targets (%arg0 = %66) {
      %145 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qco.rz(%cst_21) %targets_out_33 : !qco.qubit -> !qco.qubit
    %70 = qco.sx %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_20) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_12) %controls_out_32 : !qco.qubit -> !qco.qubit
    %73 = qco.sx %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_7) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.sx %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_6) %75 : !qco.qubit -> !qco.qubit
    %controls_out_34, %targets_out_35 = qco.ctrl(%76) targets (%arg0 = %71) {
      %145 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qco.rz(%cst_16) %targets_out_35 : !qco.qubit -> !qco.qubit
    %78 = qco.sx %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_5) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.sx %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_21) %controls_out_34 : !qco.qubit -> !qco.qubit
    %83 = qco.sx %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_20) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.x %81 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_23) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.sx %16 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_22) %87 : !qco.qubit -> !qco.qubit
    %controls_out_36, %targets_out_37 = qco.ctrl(%88) targets (%arg0 = %86) {
      %145 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %89 = qco.rz(%cst_21) %targets_out_37 : !qco.qubit -> !qco.qubit
    %90 = qco.sx %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_20) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_12) %controls_out_36 : !qco.qubit -> !qco.qubit
    %93 = qco.sx %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_9) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.sx %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_20) %95 : !qco.qubit -> !qco.qubit
    %controls_out_38, %targets_out_39 = qco.ctrl(%96) targets (%arg0 = %91) {
      %145 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %97 = qco.rz(%cst_16) %targets_out_39 : !qco.qubit -> !qco.qubit
    %98 = qco.sx %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_8) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.sx %99 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_21) %controls_out_38 : !qco.qubit -> !qco.qubit
    %103 = qco.sx %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_20) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.x %101 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_23) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_22) %107 : !qco.qubit -> !qco.qubit
    %controls_out_40, %targets_out_41 = qco.ctrl(%108) targets (%arg0 = %106) {
      %145 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %109 = qco.rz(%cst_21) %targets_out_41 : !qco.qubit -> !qco.qubit
    %110 = qco.sx %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_20) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rz(%cst_12) %controls_out_40 : !qco.qubit -> !qco.qubit
    %113 = qco.sx %112 : !qco.qubit -> !qco.qubit
    %114 = qco.rz(%cst_11) %113 : !qco.qubit -> !qco.qubit
    %115 = qco.sx %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst_20) %115 : !qco.qubit -> !qco.qubit
    %controls_out_42, %targets_out_43 = qco.ctrl(%116) targets (%arg0 = %111) {
      %145 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %117 = qco.rz(%cst_16) %targets_out_43 : !qco.qubit -> !qco.qubit
    %118 = qco.sx %117 : !qco.qubit -> !qco.qubit
    %119 = qco.rz(%cst_10) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.sx %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rz(%cst) %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rz(%cst_21) %controls_out_42 : !qco.qubit -> !qco.qubit
    %123 = qco.sx %122 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_20) %123 : !qco.qubit -> !qco.qubit
    %125 = qco.x %121 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst_23) %125 : !qco.qubit -> !qco.qubit
    %127 = qco.sx %10 : !qco.qubit -> !qco.qubit
    %128 = qco.rz(%cst_22) %127 : !qco.qubit -> !qco.qubit
    %controls_out_44, %targets_out_45 = qco.ctrl(%128) targets (%arg0 = %126) {
      %145 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %129 = qco.rz(%cst_21) %targets_out_45 : !qco.qubit -> !qco.qubit
    %130 = qco.sx %129 : !qco.qubit -> !qco.qubit
    %131 = qco.rz(%cst_20) %130 : !qco.qubit -> !qco.qubit
    %132 = qco.rz(%cst_19) %controls_out_44 : !qco.qubit -> !qco.qubit
    %133 = qco.sx %132 : !qco.qubit -> !qco.qubit
    %134 = qco.rz(%cst_18) %133 : !qco.qubit -> !qco.qubit
    %135 = qco.sx %134 : !qco.qubit -> !qco.qubit
    %136 = qco.rz(%cst_17) %135 : !qco.qubit -> !qco.qubit
    %controls_out_46, %targets_out_47 = qco.ctrl(%136) targets (%arg0 = %131) {
      %145 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %145 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %137 = qco.rz(%cst_16) %targets_out_47 : !qco.qubit -> !qco.qubit
    %138 = qco.sx %137 : !qco.qubit -> !qco.qubit
    %139 = qco.rz(%cst_15) %138 : !qco.qubit -> !qco.qubit
    %140 = qco.sx %139 : !qco.qubit -> !qco.qubit
    %141 = qco.rz(%cst_14) %140 : !qco.qubit -> !qco.qubit
    %142 = qco.rz(%cst_21) %controls_out_46 : !qco.qubit -> !qco.qubit
    %143 = qco.sx %142 : !qco.qubit -> !qco.qubit
    %144 = qco.rz(%cst_20) %143 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %141 : !qco.qubit
    cbit.store %result, %7[%c0] : !cbit.reg<7>
    %qubit_out_48, %result_49 = qco.measure %144 : !qco.qubit
    cbit.store %result_49, %7[%c1] : !cbit.reg<7>
    %qubit_out_50, %result_51 = qco.measure %124 : !qco.qubit
    cbit.store %result_51, %7[%c2] : !cbit.reg<7>
    %qubit_out_52, %result_53 = qco.measure %104 : !qco.qubit
    cbit.store %result_53, %7[%c3] : !cbit.reg<7>
    %qubit_out_54, %result_55 = qco.measure %84 : !qco.qubit
    cbit.store %result_55, %7[%c4] : !cbit.reg<7>
    %qubit_out_56, %result_57 = qco.measure %64 : !qco.qubit
    cbit.store %result_57, %7[%c5] : !cbit.reg<7>
    qco.sink %qubit_out_48 : !qco.qubit
    qco.sink %qubit_out_50 : !qco.qubit
    qco.sink %qubit_out_52 : !qco.qubit
    qco.sink %qubit_out_54 : !qco.qubit
    qco.sink %qubit_out_56 : !qco.qubit
    %qubit_out_58, %result_59 = qco.measure %45 : !qco.qubit
    qco.sink %qubit_out_58 : !qco.qubit
    cbit.store %result_59, %7[%c6] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    %cst_60 = arith.constant 1.0658141036401503E-14 : f64
    qco.gphase(%cst_60)
    return %7 : !cbit.reg<7>
  }
}
