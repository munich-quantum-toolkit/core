module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant 1.5707963267948966 : f64
    %cst_0 = arith.constant 3.1415926535897931 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %9 = qco.rx(%cst_0) %0 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst) %1 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst) %3 : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst) %5 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst) %7 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst) %20 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%12) targets (%arg0 = %9) {
      %34 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %34 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_1, %targets_out_2 = qco.ctrl(%15) targets (%arg0 = %targets_out) {
      %34 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %34 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_3, %targets_out_4 = qco.ctrl(%18) targets (%arg0 = %targets_out_2) {
      %34 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %34 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_5, %targets_out_6 = qco.ctrl(%21) targets (%arg0 = %targets_out_4) {
      %34 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %34 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.rz(%cst) %controls_out : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst) %controls_out_1 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst) %controls_out_3 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst) %controls_out_5 : !qco.qubit -> !qco.qubit
    %32 = qco.rx(%cst) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst) %32 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %24 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<7>
    %qubit_out_7, %result_8 = qco.measure %2 : !qco.qubit
    cbit.store %result_8, %8[%c1] : !cbit.reg<7>
    %qubit_out_9, %result_10 = qco.measure %27 : !qco.qubit
    cbit.store %result_10, %8[%c2] : !cbit.reg<7>
    %qubit_out_11, %result_12 = qco.measure %4 : !qco.qubit
    cbit.store %result_12, %8[%c3] : !cbit.reg<7>
    %qubit_out_13, %result_14 = qco.measure %30 : !qco.qubit
    cbit.store %result_14, %8[%c4] : !cbit.reg<7>
    %qubit_out_15, %result_16 = qco.measure %6 : !qco.qubit
    cbit.store %result_16, %8[%c5] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_7 : !qco.qubit
    qco.sink %qubit_out_9 : !qco.qubit
    qco.sink %qubit_out_11 : !qco.qubit
    qco.sink %qubit_out_13 : !qco.qubit
    qco.sink %qubit_out_15 : !qco.qubit
    %qubit_out_17, %result_18 = qco.measure %33 : !qco.qubit
    qco.sink %qubit_out_17 : !qco.qubit
    cbit.store %result_18, %8[%c6] : !cbit.reg<7>
    qco.sink %targets_out_6 : !qco.qubit
    qco.gphase(%cst)
    return %8 : !cbit.reg<7>
  }
}
