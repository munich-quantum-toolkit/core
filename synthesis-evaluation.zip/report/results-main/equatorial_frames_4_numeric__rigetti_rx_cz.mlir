module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 1.81970260401633 : f64
    %cst_0 = arith.constant 3.6131455869984368 : f64
    %cst_1 = arith.constant -1.1473440729019779 : f64
    %cst_2 = arith.constant 2.4244515486851945 : f64
    %cst_3 = arith.constant 1.7707963267948967 : f64
    %cst_4 = arith.constant 2.7327068257094416 : f64
    %cst_5 = arith.constant 2.8568303848144141 : f64
    %cst_6 = arith.constant 1.1417467156517203 : f64
    %cst_7 = arith.constant 0.88294689162089335 : f64
    %cst_8 = arith.constant -1.5700924846043793 : f64
    %cst_9 = arith.constant 0.69974275681698139 : f64
    %cst_10 = arith.constant 1.7707963267948965 : f64
    %cst_11 = arith.constant 2.1254744129589218 : f64
    %cst_12 = arith.constant 1.7707963267948963 : f64
    %cst_13 = arith.constant 3.4415926535897929 : f64
    %cst_14 = arith.constant 1.5707963267948966 : f64
    %cst_15 = arith.constant 3.5232374407119882 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.rz(%cst_15) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.rx(%cst_14) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_13) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rx(%cst_14) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_12) %7 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%8) targets (%arg0 = %1) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %9 = qco.rz(%cst_11) %targets_out : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_14) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_13) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_14) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_10) %12 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%13) targets (%arg0 = %2) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.rz(%cst_9) %targets_out_17 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_14) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_13) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_14) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_10) %17 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%18) targets (%arg0 = %3) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.rz(%cst_8) %targets_out_19 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_14) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_13) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst_14) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_10) %22 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%23) targets (%arg0 = %controls_out) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.rz(%cst_7) %targets_out_21 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_14) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_13) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_14) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_10) %27 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%28) targets (%arg0 = %controls_out_16) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.rz(%cst_6) %targets_out_23 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_14) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_13) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rx(%cst_14) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_10) %32 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%33) targets (%arg0 = %controls_out_18) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.rz(%cst_5) %targets_out_25 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_14) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_13) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rx(%cst_14) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_12) %37 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%38) targets (%arg0 = %controls_out_20) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.rz(%cst_4) %targets_out_27 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_14) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_13) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rx(%cst_14) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_3) %42 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%43) targets (%arg0 = %controls_out_22) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = qco.rz(%cst_2) %targets_out_29 : !qco.qubit -> !qco.qubit
    %45 = qco.rx(%cst_14) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_13) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rx(%cst_14) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_10) %47 : !qco.qubit -> !qco.qubit
    %controls_out_30, %targets_out_31 = qco.ctrl(%48) targets (%arg0 = %controls_out_24) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qco.rz(%cst_1) %targets_out_31 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_14) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_13) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rx(%cst_14) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_10) %52 : !qco.qubit -> !qco.qubit
    %controls_out_32, %targets_out_33 = qco.ctrl(%53) targets (%arg0 = %controls_out_26) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %54 = qco.rz(%cst_0) %targets_out_33 : !qco.qubit -> !qco.qubit
    %55 = qco.rx(%cst_14) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_13) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rx(%cst_14) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_3) %57 : !qco.qubit -> !qco.qubit
    %controls_out_34, %targets_out_35 = qco.ctrl(%58) targets (%arg0 = %controls_out_28) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qco.rz(%cst) %targets_out_35 : !qco.qubit -> !qco.qubit
    %60 = qco.rx(%cst_14) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_13) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rx(%cst_14) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_10) %62 : !qco.qubit -> !qco.qubit
    qco.sink %controls_out_32 : !qco.qubit
    qco.sink %controls_out_34 : !qco.qubit
    %controls_out_36, %targets_out_37 = qco.ctrl(%63) targets (%arg0 = %controls_out_30) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    qco.sink %targets_out_37 : !qco.qubit
    qco.sink %controls_out_36 : !qco.qubit
    return %c0_i64 : i64
  }
}
