module attributes {mqt.layout = {initial = array<i64: 1, 0, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 4.7123889803846897 : f64
    %cst_0 = arith.constant 5.497787143782138 : f64
    %cst_1 = arith.constant 3.9269908169872414 : f64
    %cst_2 = arith.constant 0.78539816339744839 : f64
    %cst_3 = arith.constant -4.7123889803846897 : f64
    %cst_4 = arith.constant 5.4977871437821371 : f64
    %cst_5 = arith.constant 1.5707963267948961 : f64
    %cst_6 = arith.constant -3.1415926535897931 : f64
    %cst_7 = arith.constant 2.748893571891069 : f64
    %cst_8 = arith.constant 0.39269908169872397 : f64
    %cst_9 = arith.constant -0.78539816339744828 : f64
    %cst_10 = arith.constant 5.4977871437821388 : f64
    %cst_11 = arith.constant -1.5707963267948966 : f64
    %cst_12 = arith.constant 0.78539816339744828 : f64
    %cst_13 = arith.constant 3.1415926535897931 : f64
    %cst_14 = arith.constant 2.3561944901923448 : f64
    %cst_15 = arith.constant 6.2831853071795862 : f64
    %cst_16 = arith.constant 1.5707963267948966 : f64
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.rx(%cst_13) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.rx(%cst_13) %2 : !qco.qubit -> !qco.qubit
    %6 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %7 = qco.rz(%cst_16) %3 : !qco.qubit -> !qco.qubit
    %8 = qco.rx(%cst_16) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_16) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_16) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_15) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_12) %5 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_13) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_9) %13 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %14, %11 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %15 = qco.rz(%cst_14) %qubit1_out : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_13) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_12) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_11) %qubit0_out : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_16) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_4) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_16) %20 : !qco.qubit -> !qco.qubit
    %qubit0_out_17, %qubit1_out_18 = qco.iswap %21, %17 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %22 = qco.rz(%cst_3) %qubit1_out_18 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_16) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_1) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_0) %qubit0_out_17 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_16) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_16) %24 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_13) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_12) %4 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_13) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_9) %31 : !qco.qubit -> !qco.qubit
    %qubit0_out_19, %qubit1_out_20 = qco.iswap %32, %29 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %33 = qco.rz(%cst_14) %qubit1_out_20 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_13) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_12) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_6) %qubit0_out_19 : !qco.qubit -> !qco.qubit
    %37 = qco.rx(%cst_16) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_11) %37 : !qco.qubit -> !qco.qubit
    %qubit0_out_21, %qubit1_out_22 = qco.iswap %38, %35 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %39 = qco.rz(%cst_11) %qubit1_out_22 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_16) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_16) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_5) %qubit0_out_21 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_16) %41 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_15) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_12) %1 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst_13) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_9) %46 : !qco.qubit -> !qco.qubit
    %qubit0_out_23, %qubit1_out_24 = qco.iswap %47, %44 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %48 = qco.rz(%cst_14) %qubit1_out_24 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_13) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_12) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_11) %qubit0_out_23 : !qco.qubit -> !qco.qubit
    %52 = qco.rx(%cst_16) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_4) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rx(%cst_16) %53 : !qco.qubit -> !qco.qubit
    %qubit0_out_25, %qubit1_out_26 = qco.iswap %54, %50 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %55 = qco.rz(%cst_3) %qubit1_out_26 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_16) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_2) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst) %qubit0_out_25 : !qco.qubit -> !qco.qubit
    %59 = qco.rx(%cst_16) %27 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_13) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rx(%cst_13) %58 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_9) %61 : !qco.qubit -> !qco.qubit
    %qubit0_out_27, %qubit1_out_28 = qco.iswap %62, %60 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %63 = qco.rz(%cst_14) %qubit1_out_28 : !qco.qubit -> !qco.qubit
    %64 = qco.rx(%cst_13) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_12) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_6) %qubit0_out_27 : !qco.qubit -> !qco.qubit
    %67 = qco.rx(%cst_16) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_11) %67 : !qco.qubit -> !qco.qubit
    %qubit0_out_29, %qubit1_out_30 = qco.iswap %68, %65 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %69 = qco.rz(%cst_11) %qubit1_out_30 : !qco.qubit -> !qco.qubit
    %70 = qco.rx(%cst_16) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_13) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_5) %qubit0_out_29 : !qco.qubit -> !qco.qubit
    %73 = qco.rx(%cst_16) %71 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_15) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rx(%cst_16) %57 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_15) %75 : !qco.qubit -> !qco.qubit
    %qubit0_out_31, %qubit1_out_32 = qco.iswap %74, %76 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %77 = qco.rz(%cst_14) %qubit1_out_32 : !qco.qubit -> !qco.qubit
    %78 = qco.rx(%cst_13) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_12) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_11) %qubit0_out_31 : !qco.qubit -> !qco.qubit
    %81 = qco.rx(%cst_16) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_10) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rx(%cst_16) %82 : !qco.qubit -> !qco.qubit
    %qubit0_out_33, %qubit1_out_34 = qco.iswap %83, %79 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %84 = qco.rz(%cst_16) %qubit1_out_34 : !qco.qubit -> !qco.qubit
    %85 = qco.rx(%cst_16) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_12) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_8) %qubit0_out_33 : !qco.qubit -> !qco.qubit
    %88 = qco.rx(%cst_13) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_7) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rx(%cst_16) %86 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_16) %90 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %89 : !qco.qubit
    cbit.store %result, %6[%c0] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    %qubit_out_35, %result_36 = qco.measure %91 : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    cbit.store %result_36, %6[%c1] : !cbit.reg<4>
    %qubit_out_37, %result_38 = qco.measure %72 : !qco.qubit
    cbit.store %result_38, %6[%c2] : !cbit.reg<4>
    qco.sink %qubit_out_37 : !qco.qubit
    %qubit_out_39, %result_40 = qco.measure %42 : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    cbit.store %result_40, %6[%c3] : !cbit.reg<4>
    %cst_41 = arith.constant -1.1780972450961702 : f64
    qco.gphase(%cst_41)
    return %6 : !cbit.reg<4>
  }
}
