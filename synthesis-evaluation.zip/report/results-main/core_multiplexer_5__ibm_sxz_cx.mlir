module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 0>, input_count = 5 : i64, sites = array<i64: 0, 1, 2, 3, 4>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<5> attributes {mqt.entry_point} {
    %cst = arith.constant 4.3906384259880475 : f64
    %cst_0 = arith.constant -1.3734007669450157 : f64
    %cst_1 = arith.constant 5.4977871437821371 : f64
    %cst_2 = arith.constant 5.1050880620834134 : f64
    %cst_3 = arith.constant 3.5342917352885181 : f64
    %cst_4 = arith.constant 3.338988213439674 : f64
    %cst_5 = arith.constant 4.9087385212340511 : f64
    %cst_6 = arith.constant 3.1415926535897927 : f64
    %cst_7 = arith.constant 3.3379421944391554 : f64
    %cst_8 = arith.constant 3.9269908169872432 : f64
    %cst_9 = arith.constant 4.8105637508093704 : f64
    %cst_10 = arith.constant -1.5707963267948966 : f64
    %cst_11 = arith.constant 3.2397674240144743 : f64
    %cst_12 = arith.constant -4.7123889803846897 : f64
    %cst_13 = arith.constant 3.1415926535897931 : f64
    %cst_14 = arith.constant -6.2831853071795862 : f64
    %cst_15 = arith.constant 4.7123889803846897 : f64
    %cst_16 = arith.constant 2.819842099193151 : f64
    %cst_17 = arith.constant 1.2490457723982544 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %cst_18 = arith.constant 1.5707963267948966 : f64
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<5>
    %6 = qco.rz(%cst_18) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.sx %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_18) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_18) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_18) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_18) %3 : !qco.qubit -> !qco.qubit
    %13 = qco.sx %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_18) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_18) %4 : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_18) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_17) %0 : !qco.qubit -> !qco.qubit
    %19 = qco.x %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_16) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_10) %21 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%22) targets (%arg0 = %20) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qco.rz(%cst_14) %targets_out : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_13) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_12) %controls_out : !qco.qubit -> !qco.qubit
    %27 = qco.sx %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_8) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.sx %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_13) %29 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%30) targets (%arg0 = %25) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.rz(%cst_10) %targets_out_20 : !qco.qubit -> !qco.qubit
    %32 = qco.sx %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_1) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_0) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.sx %controls_out_19 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_13) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.x %35 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_4) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_15) %40 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%41) targets (%arg0 = %39) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qco.rz(%cst_14) %targets_out_22 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_13) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_12) %controls_out_21 : !qco.qubit -> !qco.qubit
    %46 = qco.sx %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_3) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_13) %48 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%49) targets (%arg0 = %44) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qco.rz(%cst_15) %targets_out_24 : !qco.qubit -> !qco.qubit
    %51 = qco.sx %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_2) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.sx %controls_out_23 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_13) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.x %54 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_16) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_15) %59 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%60) targets (%arg0 = %58) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qco.rz(%cst_14) %targets_out_26 : !qco.qubit -> !qco.qubit
    %62 = qco.sx %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_13) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_12) %controls_out_25 : !qco.qubit -> !qco.qubit
    %65 = qco.sx %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_7) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.sx %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_6) %67 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%68) targets (%arg0 = %63) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qco.rz(%cst_10) %targets_out_28 : !qco.qubit -> !qco.qubit
    %70 = qco.sx %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_5) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.sx %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_14) %controls_out_27 : !qco.qubit -> !qco.qubit
    %75 = qco.sx %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_13) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.x %73 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_16) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.sx %8 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_15) %79 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%80) targets (%arg0 = %78) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %81 = qco.rz(%cst_14) %targets_out_30 : !qco.qubit -> !qco.qubit
    %82 = qco.sx %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_13) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_12) %controls_out_29 : !qco.qubit -> !qco.qubit
    %85 = qco.sx %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_11) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.sx %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_13) %87 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%88) targets (%arg0 = %83) {
      %97 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %97 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %89 = qco.rz(%cst_10) %targets_out_32 : !qco.qubit -> !qco.qubit
    %90 = qco.sx %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_9) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.sx %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_13) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_14) %controls_out_31 : !qco.qubit -> !qco.qubit
    %95 = qco.sx %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_13) %95 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %93 : !qco.qubit
    cbit.store %result, %5[%c0] : !cbit.reg<5>
    %qubit_out_33, %result_34 = qco.measure %96 : !qco.qubit
    cbit.store %result_34, %5[%c1] : !cbit.reg<5>
    %qubit_out_35, %result_36 = qco.measure %76 : !qco.qubit
    cbit.store %result_36, %5[%c2] : !cbit.reg<5>
    %qubit_out_37, %result_38 = qco.measure %56 : !qco.qubit
    cbit.store %result_38, %5[%c3] : !cbit.reg<5>
    qco.sink %qubit_out_33 : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    qco.sink %qubit_out_37 : !qco.qubit
    %qubit_out_39, %result_40 = qco.measure %37 : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    cbit.store %result_40, %5[%c4] : !cbit.reg<5>
    qco.sink %qubit_out : !qco.qubit
    %cst_41 = arith.constant -3.141592653589786 : f64
    qco.gphase(%cst_41)
    return %5 : !cbit.reg<5>
  }
}
