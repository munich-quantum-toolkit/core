module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 1.8174757264522772 : f64
    %cst_0 = arith.constant 0.58500904908161133 : f64
    %cst_1 = arith.constant 2.0482881731359797 : f64
    %cst_2 = arith.constant 2.0525313692890954 : f64
    %cst_3 = arith.constant 0.61667469758984617 : f64
    %cst_4 = arith.constant 0.47246062519127829 : f64
    %cst_5 = arith.constant -0.23781688082189967 : f64
    %cst_6 = arith.constant 3.4847438678090641 : f64
    %cst_7 = arith.constant -0.43943625132064162 : f64
    %cst_8 = arith.constant 1.2710576463886041 : f64
    %cst_9 = arith.constant -0.52432722189691694 : f64
    %cst_10 = arith.constant 4.1814131910883896 : f64
    %cst_11 = arith.constant -1.0036798758222003 : f64
    %cst_12 = arith.constant 1.7707963267948967 : f64
    %cst_13 = arith.constant -0.34313213530239806 : f64
    %cst_14 = arith.constant -0.84027703535214893 : f64
    %cst_15 = arith.constant 0.42101291091352239 : f64
    %cst_16 = arith.constant -0.46716916510451767 : f64
    %cst_17 = arith.constant 1.7707963267948963 : f64
    %cst_18 = arith.constant 3.8773406952756617 : f64
    %cst_19 = arith.constant 2.1768941290452251 : f64
    %cst_20 = arith.constant 1.6047451880023955 : f64
    %cst_21 = arith.constant -0.90796022616893945 : f64
    %cst_22 = arith.constant 0.78396102861348749 : f64
    %cst_23 = arith.constant 2.0737320352231876 : f64
    %cst_24 = arith.constant 1.7707963267948965 : f64
    %cst_25 = arith.constant 3.4415926535897929 : f64
    %cst_26 = arith.constant 1.5707963267948966 : f64
    %cst_27 = arith.constant 1.9515722152379686 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.rz(%cst_27) %0 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_26) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_25) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_26) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_24) %11 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%12) targets (%arg0 = %1) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %13 = qco.rz(%cst_23) %targets_out : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_26) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_25) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_26) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_24) %16 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%17) targets (%arg0 = %2) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qco.rz(%cst_22) %targets_out_29 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_26) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_25) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_26) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_24) %21 : !qco.qubit -> !qco.qubit
    %controls_out_30, %targets_out_31 = qco.ctrl(%22) targets (%arg0 = %3) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qco.rz(%cst_21) %targets_out_31 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_26) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_25) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_26) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_24) %26 : !qco.qubit -> !qco.qubit
    %controls_out_32, %targets_out_33 = qco.ctrl(%27) targets (%arg0 = %4) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qco.rz(%cst_20) %targets_out_33 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_26) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_25) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_26) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_24) %31 : !qco.qubit -> !qco.qubit
    %controls_out_34, %targets_out_35 = qco.ctrl(%32) targets (%arg0 = %5) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %33 = qco.rz(%cst_19) %targets_out_35 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_26) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_25) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_26) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_24) %36 : !qco.qubit -> !qco.qubit
    %controls_out_36, %targets_out_37 = qco.ctrl(%37) targets (%arg0 = %6) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qco.rz(%cst_18) %targets_out_37 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_26) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_25) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_26) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_17) %41 : !qco.qubit -> !qco.qubit
    %controls_out_38, %targets_out_39 = qco.ctrl(%42) targets (%arg0 = %7) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qco.rz(%cst_16) %targets_out_39 : !qco.qubit -> !qco.qubit
    %44 = qco.rx(%cst_26) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_25) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst_26) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_17) %46 : !qco.qubit -> !qco.qubit
    %controls_out_40, %targets_out_41 = qco.ctrl(%47) targets (%arg0 = %controls_out) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %48 = qco.rz(%cst_15) %targets_out_41 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_26) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_25) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rx(%cst_26) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_24) %51 : !qco.qubit -> !qco.qubit
    %controls_out_42, %targets_out_43 = qco.ctrl(%52) targets (%arg0 = %controls_out_28) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qco.rz(%cst_14) %targets_out_43 : !qco.qubit -> !qco.qubit
    %54 = qco.rx(%cst_26) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_25) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_26) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_24) %56 : !qco.qubit -> !qco.qubit
    %controls_out_44, %targets_out_45 = qco.ctrl(%57) targets (%arg0 = %controls_out_30) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = qco.rz(%cst_13) %targets_out_45 : !qco.qubit -> !qco.qubit
    %59 = qco.rx(%cst_26) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_25) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rx(%cst_26) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_12) %61 : !qco.qubit -> !qco.qubit
    %controls_out_46, %targets_out_47 = qco.ctrl(%62) targets (%arg0 = %controls_out_32) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %63 = qco.rz(%cst_11) %targets_out_47 : !qco.qubit -> !qco.qubit
    %64 = qco.rx(%cst_26) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_25) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rx(%cst_26) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_24) %66 : !qco.qubit -> !qco.qubit
    %controls_out_48, %targets_out_49 = qco.ctrl(%67) targets (%arg0 = %controls_out_34) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %68 = qco.rz(%cst_10) %targets_out_49 : !qco.qubit -> !qco.qubit
    %69 = qco.rx(%cst_26) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_25) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_26) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_12) %71 : !qco.qubit -> !qco.qubit
    %controls_out_50, %targets_out_51 = qco.ctrl(%72) targets (%arg0 = %controls_out_36) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %73 = qco.rz(%cst_9) %targets_out_51 : !qco.qubit -> !qco.qubit
    %74 = qco.rx(%cst_26) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_25) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rx(%cst_26) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_12) %76 : !qco.qubit -> !qco.qubit
    %controls_out_52, %targets_out_53 = qco.ctrl(%77) targets (%arg0 = %controls_out_38) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %78 = qco.rz(%cst_8) %targets_out_53 : !qco.qubit -> !qco.qubit
    %79 = qco.rx(%cst_26) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_25) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rx(%cst_26) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_24) %81 : !qco.qubit -> !qco.qubit
    %controls_out_54, %targets_out_55 = qco.ctrl(%82) targets (%arg0 = %controls_out_40) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qco.rz(%cst_7) %targets_out_55 : !qco.qubit -> !qco.qubit
    %84 = qco.rx(%cst_26) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_25) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rx(%cst_26) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_24) %86 : !qco.qubit -> !qco.qubit
    %controls_out_56, %targets_out_57 = qco.ctrl(%87) targets (%arg0 = %controls_out_42) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %88 = qco.rz(%cst_6) %targets_out_57 : !qco.qubit -> !qco.qubit
    %89 = qco.rx(%cst_26) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_25) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rx(%cst_26) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_17) %91 : !qco.qubit -> !qco.qubit
    %controls_out_58, %targets_out_59 = qco.ctrl(%92) targets (%arg0 = %controls_out_44) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %93 = qco.rz(%cst_5) %targets_out_59 : !qco.qubit -> !qco.qubit
    %94 = qco.rx(%cst_26) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_25) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rx(%cst_26) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_24) %96 : !qco.qubit -> !qco.qubit
    %controls_out_60, %targets_out_61 = qco.ctrl(%97) targets (%arg0 = %controls_out_46) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %98 = qco.rz(%cst_4) %targets_out_61 : !qco.qubit -> !qco.qubit
    %99 = qco.rx(%cst_26) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_25) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.rx(%cst_26) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_12) %101 : !qco.qubit -> !qco.qubit
    %controls_out_62, %targets_out_63 = qco.ctrl(%102) targets (%arg0 = %controls_out_48) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %103 = qco.rz(%cst_3) %targets_out_63 : !qco.qubit -> !qco.qubit
    %104 = qco.rx(%cst_26) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst_25) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rx(%cst_26) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rz(%cst_12) %106 : !qco.qubit -> !qco.qubit
    %controls_out_64, %targets_out_65 = qco.ctrl(%107) targets (%arg0 = %controls_out_50) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %108 = qco.rz(%cst_2) %targets_out_65 : !qco.qubit -> !qco.qubit
    %109 = qco.rx(%cst_26) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst_25) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rx(%cst_26) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rz(%cst_24) %111 : !qco.qubit -> !qco.qubit
    %controls_out_66, %targets_out_67 = qco.ctrl(%112) targets (%arg0 = %controls_out_52) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %113 = qco.rz(%cst_1) %targets_out_67 : !qco.qubit -> !qco.qubit
    %114 = qco.rx(%cst_26) %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_25) %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rx(%cst_26) %115 : !qco.qubit -> !qco.qubit
    %117 = qco.rz(%cst_24) %116 : !qco.qubit -> !qco.qubit
    %controls_out_68, %targets_out_69 = qco.ctrl(%117) targets (%arg0 = %controls_out_54) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %118 = qco.rz(%cst_0) %targets_out_69 : !qco.qubit -> !qco.qubit
    %119 = qco.rx(%cst_26) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.rz(%cst_25) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rx(%cst_26) %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rz(%cst_24) %121 : !qco.qubit -> !qco.qubit
    %controls_out_70, %targets_out_71 = qco.ctrl(%122) targets (%arg0 = %controls_out_56) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %123 = qco.rz(%cst) %targets_out_71 : !qco.qubit -> !qco.qubit
    %124 = qco.rx(%cst_26) %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rz(%cst_25) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rx(%cst_26) %125 : !qco.qubit -> !qco.qubit
    %127 = qco.rz(%cst_24) %126 : !qco.qubit -> !qco.qubit
    qco.sink %controls_out_60 : !qco.qubit
    qco.sink %controls_out_62 : !qco.qubit
    qco.sink %controls_out_64 : !qco.qubit
    qco.sink %controls_out_66 : !qco.qubit
    qco.sink %controls_out_68 : !qco.qubit
    qco.sink %controls_out_70 : !qco.qubit
    %controls_out_72, %targets_out_73 = qco.ctrl(%127) targets (%arg0 = %controls_out_58) {
      %128 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %128 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    qco.sink %targets_out_73 : !qco.qubit
    qco.sink %controls_out_72 : !qco.qubit
    return %c0_i64 : i64
  }
}
