module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<16> attributes {mqt.entry_point} {
    %cst = arith.constant 1.5707963267948963 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant 4.7123889803846897 : f64
    %cst_2 = arith.constant -4.7123889803846897 : f64
    %cst_3 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %c15 = arith.constant 15 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<16>
    %17 = qco.rz(%cst_3) %0 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_3) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_2) %1 : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_1) %21 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%19) targets (%arg0 = %22) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qco.rz(%cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_2) %2 : !qco.qubit -> !qco.qubit
    %27 = qco.sx %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_1) %27 : !qco.qubit -> !qco.qubit
    %controls_out_4, %targets_out_5 = qco.ctrl(%25) targets (%arg0 = %28) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.rz(%cst_0) %targets_out_5 : !qco.qubit -> !qco.qubit
    %30 = qco.sx %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_2) %3 : !qco.qubit -> !qco.qubit
    %33 = qco.sx %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_1) %33 : !qco.qubit -> !qco.qubit
    %controls_out_6, %targets_out_7 = qco.ctrl(%31) targets (%arg0 = %34) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.rz(%cst_0) %targets_out_7 : !qco.qubit -> !qco.qubit
    %36 = qco.sx %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_2) %4 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_1) %39 : !qco.qubit -> !qco.qubit
    %controls_out_8, %targets_out_9 = qco.ctrl(%37) targets (%arg0 = %40) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.rz(%cst_0) %targets_out_9 : !qco.qubit -> !qco.qubit
    %42 = qco.sx %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_2) %5 : !qco.qubit -> !qco.qubit
    %45 = qco.sx %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_1) %45 : !qco.qubit -> !qco.qubit
    %controls_out_10, %targets_out_11 = qco.ctrl(%43) targets (%arg0 = %46) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.rz(%cst_0) %targets_out_11 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_2) %6 : !qco.qubit -> !qco.qubit
    %51 = qco.sx %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_1) %51 : !qco.qubit -> !qco.qubit
    %controls_out_12, %targets_out_13 = qco.ctrl(%49) targets (%arg0 = %52) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qco.rz(%cst_0) %targets_out_13 : !qco.qubit -> !qco.qubit
    %54 = qco.sx %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_2) %7 : !qco.qubit -> !qco.qubit
    %57 = qco.sx %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_1) %57 : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%55) targets (%arg0 = %58) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qco.rz(%cst_0) %targets_out_15 : !qco.qubit -> !qco.qubit
    %60 = qco.sx %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_2) %8 : !qco.qubit -> !qco.qubit
    %63 = qco.sx %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_1) %63 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%61) targets (%arg0 = %64) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qco.rz(%cst_0) %targets_out_17 : !qco.qubit -> !qco.qubit
    %66 = qco.sx %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_2) %9 : !qco.qubit -> !qco.qubit
    %69 = qco.sx %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_1) %69 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%67) targets (%arg0 = %70) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qco.rz(%cst_0) %targets_out_19 : !qco.qubit -> !qco.qubit
    %72 = qco.sx %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_2) %10 : !qco.qubit -> !qco.qubit
    %75 = qco.sx %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_1) %75 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%73) targets (%arg0 = %76) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qco.rz(%cst_0) %targets_out_21 : !qco.qubit -> !qco.qubit
    %78 = qco.sx %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_2) %11 : !qco.qubit -> !qco.qubit
    %81 = qco.sx %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_1) %81 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%79) targets (%arg0 = %82) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qco.rz(%cst_0) %targets_out_23 : !qco.qubit -> !qco.qubit
    %84 = qco.sx %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_2) %12 : !qco.qubit -> !qco.qubit
    %87 = qco.sx %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_1) %87 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%85) targets (%arg0 = %88) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %89 = qco.rz(%cst_0) %targets_out_25 : !qco.qubit -> !qco.qubit
    %90 = qco.sx %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_2) %13 : !qco.qubit -> !qco.qubit
    %93 = qco.sx %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_1) %93 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%91) targets (%arg0 = %94) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %95 = qco.rz(%cst_0) %targets_out_27 : !qco.qubit -> !qco.qubit
    %96 = qco.sx %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_2) %14 : !qco.qubit -> !qco.qubit
    %99 = qco.sx %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_1) %99 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%97) targets (%arg0 = %100) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %101 = qco.rz(%cst_0) %targets_out_29 : !qco.qubit -> !qco.qubit
    %102 = qco.sx %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_2) %15 : !qco.qubit -> !qco.qubit
    %105 = qco.sx %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_1) %105 : !qco.qubit -> !qco.qubit
    %controls_out_30, %targets_out_31 = qco.ctrl(%103) targets (%arg0 = %106) {
      %110 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %110 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %107 = qco.rz(%cst_0) %targets_out_31 : !qco.qubit -> !qco.qubit
    %108 = qco.sx %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rz(%cst) %108 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %controls_out : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<16>
    %qubit_out_32, %result_33 = qco.measure %controls_out_4 : !qco.qubit
    cbit.store %result_33, %16[%c1] : !cbit.reg<16>
    %qubit_out_34, %result_35 = qco.measure %controls_out_6 : !qco.qubit
    cbit.store %result_35, %16[%c2] : !cbit.reg<16>
    %qubit_out_36, %result_37 = qco.measure %controls_out_8 : !qco.qubit
    cbit.store %result_37, %16[%c3] : !cbit.reg<16>
    %qubit_out_38, %result_39 = qco.measure %controls_out_10 : !qco.qubit
    cbit.store %result_39, %16[%c4] : !cbit.reg<16>
    %qubit_out_40, %result_41 = qco.measure %controls_out_12 : !qco.qubit
    cbit.store %result_41, %16[%c5] : !cbit.reg<16>
    %qubit_out_42, %result_43 = qco.measure %controls_out_14 : !qco.qubit
    cbit.store %result_43, %16[%c6] : !cbit.reg<16>
    %qubit_out_44, %result_45 = qco.measure %controls_out_16 : !qco.qubit
    cbit.store %result_45, %16[%c7] : !cbit.reg<16>
    %qubit_out_46, %result_47 = qco.measure %controls_out_18 : !qco.qubit
    cbit.store %result_47, %16[%c8] : !cbit.reg<16>
    %qubit_out_48, %result_49 = qco.measure %controls_out_20 : !qco.qubit
    cbit.store %result_49, %16[%c9] : !cbit.reg<16>
    %qubit_out_50, %result_51 = qco.measure %controls_out_22 : !qco.qubit
    cbit.store %result_51, %16[%c10] : !cbit.reg<16>
    %qubit_out_52, %result_53 = qco.measure %controls_out_24 : !qco.qubit
    cbit.store %result_53, %16[%c11] : !cbit.reg<16>
    %qubit_out_54, %result_55 = qco.measure %controls_out_26 : !qco.qubit
    cbit.store %result_55, %16[%c12] : !cbit.reg<16>
    %qubit_out_56, %result_57 = qco.measure %controls_out_28 : !qco.qubit
    cbit.store %result_57, %16[%c13] : !cbit.reg<16>
    %qubit_out_58, %result_59 = qco.measure %controls_out_30 : !qco.qubit
    cbit.store %result_59, %16[%c14] : !cbit.reg<16>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_32 : !qco.qubit
    qco.sink %qubit_out_34 : !qco.qubit
    qco.sink %qubit_out_36 : !qco.qubit
    qco.sink %qubit_out_38 : !qco.qubit
    qco.sink %qubit_out_40 : !qco.qubit
    qco.sink %qubit_out_42 : !qco.qubit
    qco.sink %qubit_out_44 : !qco.qubit
    qco.sink %qubit_out_46 : !qco.qubit
    qco.sink %qubit_out_48 : !qco.qubit
    qco.sink %qubit_out_50 : !qco.qubit
    qco.sink %qubit_out_52 : !qco.qubit
    qco.sink %qubit_out_54 : !qco.qubit
    qco.sink %qubit_out_56 : !qco.qubit
    qco.sink %qubit_out_58 : !qco.qubit
    %qubit_out_60, %result_61 = qco.measure %109 : !qco.qubit
    qco.sink %qubit_out_60 : !qco.qubit
    cbit.store %result_61, %16[%c15] : !cbit.reg<16>
    %cst_62 = arith.constant 2.3561944901923448 : f64
    qco.gphase(%cst_62)
    return %16 : !cbit.reg<16>
  }
}
