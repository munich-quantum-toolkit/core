module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant -3.1415926535897931 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %cst_2 = arith.constant 1.5707963267948968 : f64
    %cst_3 = arith.constant -1.5707963267948963 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %5 = qco.x %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_1) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.sx %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_1) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_1) %3 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_1) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_3) %5 : !qco.qubit -> !qco.qubit
    %13 = qco.sx %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_2) %13 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%8) targets (%arg0 = %14) {
      %29 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %29 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qco.rz(%cst_1) %targets_out : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_2) %18 : !qco.qubit -> !qco.qubit
    %controls_out_4, %targets_out_5 = qco.ctrl(%11) targets (%arg0 = %19) {
      %29 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %29 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.rz(%cst_1) %targets_out_5 : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_0) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_1) %controls_out : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_1) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_1) %controls_out_4 : !qco.qubit -> !qco.qubit
    %27 = qco.sx %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_1) %27 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %25 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<3>
    %qubit_out_6, %result_7 = qco.measure %2 : !qco.qubit
    cbit.store %result_7, %4[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_6 : !qco.qubit
    %qubit_out_8, %result_9 = qco.measure %28 : !qco.qubit
    qco.sink %qubit_out_8 : !qco.qubit
    cbit.store %result_9, %4[%c2] : !cbit.reg<3>
    qco.sink %22 : !qco.qubit
    return %4 : !cbit.reg<3>
  }
}
