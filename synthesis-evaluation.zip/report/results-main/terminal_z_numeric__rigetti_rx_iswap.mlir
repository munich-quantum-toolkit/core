module attributes {mqt.layout = {initial = array<i64: 0, 1>, input_count = 2 : i64, sites = array<i64: 0, 1>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<2> attributes {mqt.entry_point} {
    %cst = arith.constant 1.9407963267948967 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant -4.7123889803846897 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "meas"} : !cbit.reg<2>
    %3 = qco.rz(%cst_1) %0 : !qco.qubit -> !qco.qubit
    %4 = qco.rx(%cst_0) %3 : !qco.qubit -> !qco.qubit
    %5 = qco.rz(%cst) %4 : !qco.qubit -> !qco.qubit
    %6:2 = qco.barrier %5, %1 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %qubit_out, %result = qco.measure %6#0 : !qco.qubit
    cbit.store %result, %2[%c0] : !cbit.reg<2>
    qco.sink %qubit_out : !qco.qubit
    %qubit_out_2, %result_3 = qco.measure %6#1 : !qco.qubit
    qco.sink %qubit_out_2 : !qco.qubit
    cbit.store %result_3, %2[%c1] : !cbit.reg<2>
    %cst_4 = arith.constant -1.5707963267948966 : f64
    qco.gphase(%cst_4)
    return %2 : !cbit.reg<2>
  }
}
