module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main(%arg0: f64 {mqt.input_id = 1448859521991596184831488526587787482 : i128, mqt.input_name = "theta[0]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 0 : i64, name = "theta", size = 48 : i64}}, %arg1: f64 {mqt.input_id = 1448859521991596184831488526587787483 : i128, mqt.input_name = "theta[1]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 1 : i64, name = "theta", size = 48 : i64}}, %arg2: f64 {mqt.input_id = 1448859521991596184831488526587787484 : i128, mqt.input_name = "theta[2]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 2 : i64, name = "theta", size = 48 : i64}}, %arg3: f64 {mqt.input_id = 1448859521991596184831488526587787485 : i128, mqt.input_name = "theta[3]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 3 : i64, name = "theta", size = 48 : i64}}, %arg4: f64 {mqt.input_id = 1448859521991596184831488526587787486 : i128, mqt.input_name = "theta[4]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 4 : i64, name = "theta", size = 48 : i64}}, %arg5: f64 {mqt.input_id = 1448859521991596184831488526587787487 : i128, mqt.input_name = "theta[5]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 5 : i64, name = "theta", size = 48 : i64}}, %arg6: f64 {mqt.input_id = 1448859521991596184831488526587787488 : i128, mqt.input_name = "theta[6]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 6 : i64, name = "theta", size = 48 : i64}}, %arg7: f64 {mqt.input_id = 1448859521991596184831488526587787489 : i128, mqt.input_name = "theta[7]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 7 : i64, name = "theta", size = 48 : i64}}, %arg8: f64 {mqt.input_id = 1448859521991596184831488526587787490 : i128, mqt.input_name = "theta[8]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 8 : i64, name = "theta", size = 48 : i64}}, %arg9: f64 {mqt.input_id = 1448859521991596184831488526587787491 : i128, mqt.input_name = "theta[9]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 9 : i64, name = "theta", size = 48 : i64}}, %arg10: f64 {mqt.input_id = 1448859521991596184831488526587787492 : i128, mqt.input_name = "theta[10]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 10 : i64, name = "theta", size = 48 : i64}}, %arg11: f64 {mqt.input_id = 1448859521991596184831488526587787493 : i128, mqt.input_name = "theta[11]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 11 : i64, name = "theta", size = 48 : i64}}, %arg12: f64 {mqt.input_id = 1448859521991596184831488526587787494 : i128, mqt.input_name = "theta[12]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 12 : i64, name = "theta", size = 48 : i64}}, %arg13: f64 {mqt.input_id = 1448859521991596184831488526587787495 : i128, mqt.input_name = "theta[13]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 13 : i64, name = "theta", size = 48 : i64}}, %arg14: f64 {mqt.input_id = 1448859521991596184831488526587787496 : i128, mqt.input_name = "theta[14]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 14 : i64, name = "theta", size = 48 : i64}}, %arg15: f64 {mqt.input_id = 1448859521991596184831488526587787497 : i128, mqt.input_name = "theta[15]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 15 : i64, name = "theta", size = 48 : i64}}, %arg16: f64 {mqt.input_id = 1448859521991596184831488526587787498 : i128, mqt.input_name = "theta[16]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 16 : i64, name = "theta", size = 48 : i64}}, %arg17: f64 {mqt.input_id = 1448859521991596184831488526587787499 : i128, mqt.input_name = "theta[17]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 17 : i64, name = "theta", size = 48 : i64}}, %arg18: f64 {mqt.input_id = 1448859521991596184831488526587787500 : i128, mqt.input_name = "theta[18]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 18 : i64, name = "theta", size = 48 : i64}}, %arg19: f64 {mqt.input_id = 1448859521991596184831488526587787501 : i128, mqt.input_name = "theta[19]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 19 : i64, name = "theta", size = 48 : i64}}, %arg20: f64 {mqt.input_id = 1448859521991596184831488526587787502 : i128, mqt.input_name = "theta[20]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 20 : i64, name = "theta", size = 48 : i64}}, %arg21: f64 {mqt.input_id = 1448859521991596184831488526587787503 : i128, mqt.input_name = "theta[21]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 21 : i64, name = "theta", size = 48 : i64}}, %arg22: f64 {mqt.input_id = 1448859521991596184831488526587787504 : i128, mqt.input_name = "theta[22]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 22 : i64, name = "theta", size = 48 : i64}}, %arg23: f64 {mqt.input_id = 1448859521991596184831488526587787505 : i128, mqt.input_name = "theta[23]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 23 : i64, name = "theta", size = 48 : i64}}, %arg24: f64 {mqt.input_id = 1448859521991596184831488526587787506 : i128, mqt.input_name = "theta[24]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 24 : i64, name = "theta", size = 48 : i64}}, %arg25: f64 {mqt.input_id = 1448859521991596184831488526587787507 : i128, mqt.input_name = "theta[25]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 25 : i64, name = "theta", size = 48 : i64}}, %arg26: f64 {mqt.input_id = 1448859521991596184831488526587787508 : i128, mqt.input_name = "theta[26]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 26 : i64, name = "theta", size = 48 : i64}}, %arg27: f64 {mqt.input_id = 1448859521991596184831488526587787509 : i128, mqt.input_name = "theta[27]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 27 : i64, name = "theta", size = 48 : i64}}, %arg28: f64 {mqt.input_id = 1448859521991596184831488526587787510 : i128, mqt.input_name = "theta[28]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 28 : i64, name = "theta", size = 48 : i64}}, %arg29: f64 {mqt.input_id = 1448859521991596184831488526587787511 : i128, mqt.input_name = "theta[29]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 29 : i64, name = "theta", size = 48 : i64}}, %arg30: f64 {mqt.input_id = 1448859521991596184831488526587787512 : i128, mqt.input_name = "theta[30]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 30 : i64, name = "theta", size = 48 : i64}}, %arg31: f64 {mqt.input_id = 1448859521991596184831488526587787513 : i128, mqt.input_name = "theta[31]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 31 : i64, name = "theta", size = 48 : i64}}, %arg32: f64 {mqt.input_id = 1448859521991596184831488526587787514 : i128, mqt.input_name = "theta[32]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 32 : i64, name = "theta", size = 48 : i64}}, %arg33: f64 {mqt.input_id = 1448859521991596184831488526587787515 : i128, mqt.input_name = "theta[33]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 33 : i64, name = "theta", size = 48 : i64}}, %arg34: f64 {mqt.input_id = 1448859521991596184831488526587787516 : i128, mqt.input_name = "theta[34]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 34 : i64, name = "theta", size = 48 : i64}}, %arg35: f64 {mqt.input_id = 1448859521991596184831488526587787517 : i128, mqt.input_name = "theta[35]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 35 : i64, name = "theta", size = 48 : i64}}, %arg36: f64 {mqt.input_id = 1448859521991596184831488526587787518 : i128, mqt.input_name = "theta[36]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 36 : i64, name = "theta", size = 48 : i64}}, %arg37: f64 {mqt.input_id = 1448859521991596184831488526587787519 : i128, mqt.input_name = "theta[37]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 37 : i64, name = "theta", size = 48 : i64}}, %arg38: f64 {mqt.input_id = 1448859521991596184831488526587787520 : i128, mqt.input_name = "theta[38]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 38 : i64, name = "theta", size = 48 : i64}}, %arg39: f64 {mqt.input_id = 1448859521991596184831488526587787521 : i128, mqt.input_name = "theta[39]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 39 : i64, name = "theta", size = 48 : i64}}, %arg40: f64 {mqt.input_id = 1448859521991596184831488526587787522 : i128, mqt.input_name = "theta[40]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 40 : i64, name = "theta", size = 48 : i64}}, %arg41: f64 {mqt.input_id = 1448859521991596184831488526587787523 : i128, mqt.input_name = "theta[41]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 41 : i64, name = "theta", size = 48 : i64}}, %arg42: f64 {mqt.input_id = 1448859521991596184831488526587787524 : i128, mqt.input_name = "theta[42]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 42 : i64, name = "theta", size = 48 : i64}}, %arg43: f64 {mqt.input_id = 1448859521991596184831488526587787525 : i128, mqt.input_name = "theta[43]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 43 : i64, name = "theta", size = 48 : i64}}, %arg44: f64 {mqt.input_id = 1448859521991596184831488526587787526 : i128, mqt.input_name = "theta[44]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 44 : i64, name = "theta", size = 48 : i64}}, %arg45: f64 {mqt.input_id = 1448859521991596184831488526587787527 : i128, mqt.input_name = "theta[45]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 45 : i64, name = "theta", size = 48 : i64}}, %arg46: f64 {mqt.input_id = 1448859521991596184831488526587787528 : i128, mqt.input_name = "theta[46]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 46 : i64, name = "theta", size = 48 : i64}}, %arg47: f64 {mqt.input_id = 1448859521991596184831488526587787529 : i128, mqt.input_name = "theta[47]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 47 : i64, name = "theta", size = 48 : i64}}) -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 1.7707963267948965 : f64
    %cst_0 = arith.constant 3.4415926535897929 : f64
    %cst_1 = arith.constant 1.3707963267948966 : f64
    %cst_2 = arith.constant 4.000000e+00 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = arith.divf %arg0, %cst_2 : f64
    %17 = math.tan %16 : f64
    %18 = math.atan %17 : f64
    %19 = arith.mulf %18, %cst_2 : f64
    %20 = arith.addf %19, %cst_1 : f64
    %21 = qco.rz(%20) %0 : !qco.qubit -> !qco.qubit
    %22 = qco.sx %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_0) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst) %24 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%25) targets (%arg48 = %1) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = arith.divf %arg1, %cst_2 : f64
    %27 = math.tan %26 : f64
    %28 = math.atan %27 : f64
    %29 = arith.mulf %28, %cst_2 : f64
    %30 = arith.addf %29, %cst_1 : f64
    %31 = qco.rz(%30) %targets_out : !qco.qubit -> !qco.qubit
    %32 = qco.sx %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_0) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst) %34 : !qco.qubit -> !qco.qubit
    %controls_out_3, %targets_out_4 = qco.ctrl(%35) targets (%arg48 = %2) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = arith.divf %arg2, %cst_2 : f64
    %37 = math.tan %36 : f64
    %38 = math.atan %37 : f64
    %39 = arith.mulf %38, %cst_2 : f64
    %40 = arith.addf %39, %cst_1 : f64
    %41 = qco.rz(%40) %targets_out_4 : !qco.qubit -> !qco.qubit
    %42 = qco.sx %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_0) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.sx %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst) %44 : !qco.qubit -> !qco.qubit
    %controls_out_5, %targets_out_6 = qco.ctrl(%45) targets (%arg48 = %3) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = arith.divf %arg3, %cst_2 : f64
    %47 = math.tan %46 : f64
    %48 = math.atan %47 : f64
    %49 = arith.mulf %48, %cst_2 : f64
    %50 = arith.addf %49, %cst_1 : f64
    %51 = qco.rz(%50) %targets_out_6 : !qco.qubit -> !qco.qubit
    %52 = qco.sx %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_0) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.sx %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst) %54 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%55) targets (%arg48 = %4) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = arith.divf %arg4, %cst_2 : f64
    %57 = math.tan %56 : f64
    %58 = math.atan %57 : f64
    %59 = arith.mulf %58, %cst_2 : f64
    %60 = arith.addf %59, %cst_1 : f64
    %61 = qco.rz(%60) %targets_out_8 : !qco.qubit -> !qco.qubit
    %62 = qco.sx %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_0) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.sx %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst) %64 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%65) targets (%arg48 = %5) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = arith.divf %arg5, %cst_2 : f64
    %67 = math.tan %66 : f64
    %68 = math.atan %67 : f64
    %69 = arith.mulf %68, %cst_2 : f64
    %70 = arith.addf %69, %cst_1 : f64
    %71 = qco.rz(%70) %targets_out_10 : !qco.qubit -> !qco.qubit
    %72 = qco.sx %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_0) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.sx %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst) %74 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%75) targets (%arg48 = %6) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %76 = arith.divf %arg6, %cst_2 : f64
    %77 = math.tan %76 : f64
    %78 = math.atan %77 : f64
    %79 = arith.mulf %78, %cst_2 : f64
    %80 = arith.addf %79, %cst_1 : f64
    %81 = qco.rz(%80) %targets_out_12 : !qco.qubit -> !qco.qubit
    %82 = qco.sx %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_0) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.sx %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst) %84 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%85) targets (%arg48 = %7) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %86 = arith.divf %arg7, %cst_2 : f64
    %87 = math.tan %86 : f64
    %88 = math.atan %87 : f64
    %89 = arith.mulf %88, %cst_2 : f64
    %90 = arith.addf %89, %cst_1 : f64
    %91 = qco.rz(%90) %targets_out_14 : !qco.qubit -> !qco.qubit
    %92 = qco.sx %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_0) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.sx %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst) %94 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%95) targets (%arg48 = %8) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %96 = arith.divf %arg8, %cst_2 : f64
    %97 = math.tan %96 : f64
    %98 = math.atan %97 : f64
    %99 = arith.mulf %98, %cst_2 : f64
    %100 = arith.addf %99, %cst_1 : f64
    %101 = qco.rz(%100) %targets_out_16 : !qco.qubit -> !qco.qubit
    %102 = qco.sx %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst_0) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.sx %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst) %104 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%105) targets (%arg48 = %9) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %106 = arith.divf %arg9, %cst_2 : f64
    %107 = math.tan %106 : f64
    %108 = math.atan %107 : f64
    %109 = arith.mulf %108, %cst_2 : f64
    %110 = arith.addf %109, %cst_1 : f64
    %111 = qco.rz(%110) %targets_out_18 : !qco.qubit -> !qco.qubit
    %112 = qco.sx %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_0) %112 : !qco.qubit -> !qco.qubit
    %114 = qco.sx %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst) %114 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%115) targets (%arg48 = %10) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %116 = arith.divf %arg10, %cst_2 : f64
    %117 = math.tan %116 : f64
    %118 = math.atan %117 : f64
    %119 = arith.mulf %118, %cst_2 : f64
    %120 = arith.addf %119, %cst_1 : f64
    %121 = qco.rz(%120) %targets_out_20 : !qco.qubit -> !qco.qubit
    %122 = qco.sx %121 : !qco.qubit -> !qco.qubit
    %123 = qco.rz(%cst_0) %122 : !qco.qubit -> !qco.qubit
    %124 = qco.sx %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rz(%cst) %124 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%125) targets (%arg48 = %11) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %126 = arith.divf %arg11, %cst_2 : f64
    %127 = math.tan %126 : f64
    %128 = math.atan %127 : f64
    %129 = arith.mulf %128, %cst_2 : f64
    %130 = arith.addf %129, %cst_1 : f64
    %131 = qco.rz(%130) %targets_out_22 : !qco.qubit -> !qco.qubit
    %132 = qco.sx %131 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst_0) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.sx %133 : !qco.qubit -> !qco.qubit
    %135 = qco.rz(%cst) %134 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%135) targets (%arg48 = %12) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %136 = arith.divf %arg12, %cst_2 : f64
    %137 = math.tan %136 : f64
    %138 = math.atan %137 : f64
    %139 = arith.mulf %138, %cst_2 : f64
    %140 = arith.addf %139, %cst_1 : f64
    %141 = qco.rz(%140) %targets_out_24 : !qco.qubit -> !qco.qubit
    %142 = qco.sx %141 : !qco.qubit -> !qco.qubit
    %143 = qco.rz(%cst_0) %142 : !qco.qubit -> !qco.qubit
    %144 = qco.sx %143 : !qco.qubit -> !qco.qubit
    %145 = qco.rz(%cst) %144 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%145) targets (%arg48 = %13) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %146 = arith.divf %arg13, %cst_2 : f64
    %147 = math.tan %146 : f64
    %148 = math.atan %147 : f64
    %149 = arith.mulf %148, %cst_2 : f64
    %150 = arith.addf %149, %cst_1 : f64
    %151 = qco.rz(%150) %targets_out_26 : !qco.qubit -> !qco.qubit
    %152 = qco.sx %151 : !qco.qubit -> !qco.qubit
    %153 = qco.rz(%cst_0) %152 : !qco.qubit -> !qco.qubit
    %154 = qco.sx %153 : !qco.qubit -> !qco.qubit
    %155 = qco.rz(%cst) %154 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%155) targets (%arg48 = %14) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %156 = arith.divf %arg14, %cst_2 : f64
    %157 = math.tan %156 : f64
    %158 = math.atan %157 : f64
    %159 = arith.mulf %158, %cst_2 : f64
    %160 = arith.addf %159, %cst_1 : f64
    %161 = qco.rz(%160) %targets_out_28 : !qco.qubit -> !qco.qubit
    %162 = qco.sx %161 : !qco.qubit -> !qco.qubit
    %163 = qco.rz(%cst_0) %162 : !qco.qubit -> !qco.qubit
    %164 = qco.sx %163 : !qco.qubit -> !qco.qubit
    %165 = qco.rz(%cst) %164 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%165) targets (%arg48 = %15) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %166 = arith.divf %arg15, %cst_2 : f64
    %167 = math.tan %166 : f64
    %168 = math.atan %167 : f64
    %169 = arith.mulf %168, %cst_2 : f64
    %170 = arith.addf %169, %cst_1 : f64
    %171 = qco.rz(%170) %targets_out_30 : !qco.qubit -> !qco.qubit
    %172 = qco.sx %171 : !qco.qubit -> !qco.qubit
    %173 = qco.rz(%cst_0) %172 : !qco.qubit -> !qco.qubit
    %174 = qco.sx %173 : !qco.qubit -> !qco.qubit
    %175 = qco.rz(%cst) %174 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%175) targets (%arg48 = %controls_out) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %176 = arith.divf %arg16, %cst_2 : f64
    %177 = math.tan %176 : f64
    %178 = math.atan %177 : f64
    %179 = arith.mulf %178, %cst_2 : f64
    %180 = arith.addf %179, %cst_1 : f64
    %181 = qco.rz(%180) %targets_out_32 : !qco.qubit -> !qco.qubit
    %182 = qco.sx %181 : !qco.qubit -> !qco.qubit
    %183 = qco.rz(%cst_0) %182 : !qco.qubit -> !qco.qubit
    %184 = qco.sx %183 : !qco.qubit -> !qco.qubit
    %185 = qco.rz(%cst) %184 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%185) targets (%arg48 = %controls_out_3) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %186 = arith.divf %arg17, %cst_2 : f64
    %187 = math.tan %186 : f64
    %188 = math.atan %187 : f64
    %189 = arith.mulf %188, %cst_2 : f64
    %190 = arith.addf %189, %cst_1 : f64
    %191 = qco.rz(%190) %targets_out_34 : !qco.qubit -> !qco.qubit
    %192 = qco.sx %191 : !qco.qubit -> !qco.qubit
    %193 = qco.rz(%cst_0) %192 : !qco.qubit -> !qco.qubit
    %194 = qco.sx %193 : !qco.qubit -> !qco.qubit
    %195 = qco.rz(%cst) %194 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%195) targets (%arg48 = %controls_out_5) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %196 = arith.divf %arg18, %cst_2 : f64
    %197 = math.tan %196 : f64
    %198 = math.atan %197 : f64
    %199 = arith.mulf %198, %cst_2 : f64
    %200 = arith.addf %199, %cst_1 : f64
    %201 = qco.rz(%200) %targets_out_36 : !qco.qubit -> !qco.qubit
    %202 = qco.sx %201 : !qco.qubit -> !qco.qubit
    %203 = qco.rz(%cst_0) %202 : !qco.qubit -> !qco.qubit
    %204 = qco.sx %203 : !qco.qubit -> !qco.qubit
    %205 = qco.rz(%cst) %204 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%205) targets (%arg48 = %controls_out_7) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %206 = arith.divf %arg19, %cst_2 : f64
    %207 = math.tan %206 : f64
    %208 = math.atan %207 : f64
    %209 = arith.mulf %208, %cst_2 : f64
    %210 = arith.addf %209, %cst_1 : f64
    %211 = qco.rz(%210) %targets_out_38 : !qco.qubit -> !qco.qubit
    %212 = qco.sx %211 : !qco.qubit -> !qco.qubit
    %213 = qco.rz(%cst_0) %212 : !qco.qubit -> !qco.qubit
    %214 = qco.sx %213 : !qco.qubit -> !qco.qubit
    %215 = qco.rz(%cst) %214 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%215) targets (%arg48 = %controls_out_9) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %216 = arith.divf %arg20, %cst_2 : f64
    %217 = math.tan %216 : f64
    %218 = math.atan %217 : f64
    %219 = arith.mulf %218, %cst_2 : f64
    %220 = arith.addf %219, %cst_1 : f64
    %221 = qco.rz(%220) %targets_out_40 : !qco.qubit -> !qco.qubit
    %222 = qco.sx %221 : !qco.qubit -> !qco.qubit
    %223 = qco.rz(%cst_0) %222 : !qco.qubit -> !qco.qubit
    %224 = qco.sx %223 : !qco.qubit -> !qco.qubit
    %225 = qco.rz(%cst) %224 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%225) targets (%arg48 = %controls_out_11) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %226 = arith.divf %arg21, %cst_2 : f64
    %227 = math.tan %226 : f64
    %228 = math.atan %227 : f64
    %229 = arith.mulf %228, %cst_2 : f64
    %230 = arith.addf %229, %cst_1 : f64
    %231 = qco.rz(%230) %targets_out_42 : !qco.qubit -> !qco.qubit
    %232 = qco.sx %231 : !qco.qubit -> !qco.qubit
    %233 = qco.rz(%cst_0) %232 : !qco.qubit -> !qco.qubit
    %234 = qco.sx %233 : !qco.qubit -> !qco.qubit
    %235 = qco.rz(%cst) %234 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%235) targets (%arg48 = %controls_out_13) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %236 = arith.divf %arg22, %cst_2 : f64
    %237 = math.tan %236 : f64
    %238 = math.atan %237 : f64
    %239 = arith.mulf %238, %cst_2 : f64
    %240 = arith.addf %239, %cst_1 : f64
    %241 = qco.rz(%240) %targets_out_44 : !qco.qubit -> !qco.qubit
    %242 = qco.sx %241 : !qco.qubit -> !qco.qubit
    %243 = qco.rz(%cst_0) %242 : !qco.qubit -> !qco.qubit
    %244 = qco.sx %243 : !qco.qubit -> !qco.qubit
    %245 = qco.rz(%cst) %244 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%245) targets (%arg48 = %controls_out_15) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %246 = arith.divf %arg23, %cst_2 : f64
    %247 = math.tan %246 : f64
    %248 = math.atan %247 : f64
    %249 = arith.mulf %248, %cst_2 : f64
    %250 = arith.addf %249, %cst_1 : f64
    %251 = qco.rz(%250) %targets_out_46 : !qco.qubit -> !qco.qubit
    %252 = qco.sx %251 : !qco.qubit -> !qco.qubit
    %253 = qco.rz(%cst_0) %252 : !qco.qubit -> !qco.qubit
    %254 = qco.sx %253 : !qco.qubit -> !qco.qubit
    %255 = qco.rz(%cst) %254 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%255) targets (%arg48 = %controls_out_17) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %256 = arith.divf %arg24, %cst_2 : f64
    %257 = math.tan %256 : f64
    %258 = math.atan %257 : f64
    %259 = arith.mulf %258, %cst_2 : f64
    %260 = arith.addf %259, %cst_1 : f64
    %261 = qco.rz(%260) %targets_out_48 : !qco.qubit -> !qco.qubit
    %262 = qco.sx %261 : !qco.qubit -> !qco.qubit
    %263 = qco.rz(%cst_0) %262 : !qco.qubit -> !qco.qubit
    %264 = qco.sx %263 : !qco.qubit -> !qco.qubit
    %265 = qco.rz(%cst) %264 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%265) targets (%arg48 = %controls_out_19) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %266 = arith.divf %arg25, %cst_2 : f64
    %267 = math.tan %266 : f64
    %268 = math.atan %267 : f64
    %269 = arith.mulf %268, %cst_2 : f64
    %270 = arith.addf %269, %cst_1 : f64
    %271 = qco.rz(%270) %targets_out_50 : !qco.qubit -> !qco.qubit
    %272 = qco.sx %271 : !qco.qubit -> !qco.qubit
    %273 = qco.rz(%cst_0) %272 : !qco.qubit -> !qco.qubit
    %274 = qco.sx %273 : !qco.qubit -> !qco.qubit
    %275 = qco.rz(%cst) %274 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%275) targets (%arg48 = %controls_out_21) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %276 = arith.divf %arg26, %cst_2 : f64
    %277 = math.tan %276 : f64
    %278 = math.atan %277 : f64
    %279 = arith.mulf %278, %cst_2 : f64
    %280 = arith.addf %279, %cst_1 : f64
    %281 = qco.rz(%280) %targets_out_52 : !qco.qubit -> !qco.qubit
    %282 = qco.sx %281 : !qco.qubit -> !qco.qubit
    %283 = qco.rz(%cst_0) %282 : !qco.qubit -> !qco.qubit
    %284 = qco.sx %283 : !qco.qubit -> !qco.qubit
    %285 = qco.rz(%cst) %284 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%285) targets (%arg48 = %controls_out_23) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %286 = arith.divf %arg27, %cst_2 : f64
    %287 = math.tan %286 : f64
    %288 = math.atan %287 : f64
    %289 = arith.mulf %288, %cst_2 : f64
    %290 = arith.addf %289, %cst_1 : f64
    %291 = qco.rz(%290) %targets_out_54 : !qco.qubit -> !qco.qubit
    %292 = qco.sx %291 : !qco.qubit -> !qco.qubit
    %293 = qco.rz(%cst_0) %292 : !qco.qubit -> !qco.qubit
    %294 = qco.sx %293 : !qco.qubit -> !qco.qubit
    %295 = qco.rz(%cst) %294 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%295) targets (%arg48 = %controls_out_25) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %296 = arith.divf %arg28, %cst_2 : f64
    %297 = math.tan %296 : f64
    %298 = math.atan %297 : f64
    %299 = arith.mulf %298, %cst_2 : f64
    %300 = arith.addf %299, %cst_1 : f64
    %301 = qco.rz(%300) %targets_out_56 : !qco.qubit -> !qco.qubit
    %302 = qco.sx %301 : !qco.qubit -> !qco.qubit
    %303 = qco.rz(%cst_0) %302 : !qco.qubit -> !qco.qubit
    %304 = qco.sx %303 : !qco.qubit -> !qco.qubit
    %305 = qco.rz(%cst) %304 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%305) targets (%arg48 = %controls_out_27) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %306 = arith.divf %arg29, %cst_2 : f64
    %307 = math.tan %306 : f64
    %308 = math.atan %307 : f64
    %309 = arith.mulf %308, %cst_2 : f64
    %310 = arith.addf %309, %cst_1 : f64
    %311 = qco.rz(%310) %targets_out_58 : !qco.qubit -> !qco.qubit
    %312 = qco.sx %311 : !qco.qubit -> !qco.qubit
    %313 = qco.rz(%cst_0) %312 : !qco.qubit -> !qco.qubit
    %314 = qco.sx %313 : !qco.qubit -> !qco.qubit
    %315 = qco.rz(%cst) %314 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%315) targets (%arg48 = %controls_out_29) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %316 = arith.divf %arg30, %cst_2 : f64
    %317 = math.tan %316 : f64
    %318 = math.atan %317 : f64
    %319 = arith.mulf %318, %cst_2 : f64
    %320 = arith.addf %319, %cst_1 : f64
    %321 = qco.rz(%320) %targets_out_60 : !qco.qubit -> !qco.qubit
    %322 = qco.sx %321 : !qco.qubit -> !qco.qubit
    %323 = qco.rz(%cst_0) %322 : !qco.qubit -> !qco.qubit
    %324 = qco.sx %323 : !qco.qubit -> !qco.qubit
    %325 = qco.rz(%cst) %324 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%325) targets (%arg48 = %controls_out_31) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %326 = arith.divf %arg31, %cst_2 : f64
    %327 = math.tan %326 : f64
    %328 = math.atan %327 : f64
    %329 = arith.mulf %328, %cst_2 : f64
    %330 = arith.addf %329, %cst_1 : f64
    %331 = qco.rz(%330) %targets_out_62 : !qco.qubit -> !qco.qubit
    %332 = qco.sx %331 : !qco.qubit -> !qco.qubit
    %333 = qco.rz(%cst_0) %332 : !qco.qubit -> !qco.qubit
    %334 = qco.sx %333 : !qco.qubit -> !qco.qubit
    %335 = qco.rz(%cst) %334 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%335) targets (%arg48 = %controls_out_33) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %336 = arith.divf %arg32, %cst_2 : f64
    %337 = math.tan %336 : f64
    %338 = math.atan %337 : f64
    %339 = arith.mulf %338, %cst_2 : f64
    %340 = arith.addf %339, %cst_1 : f64
    %341 = qco.rz(%340) %targets_out_64 : !qco.qubit -> !qco.qubit
    %342 = qco.sx %341 : !qco.qubit -> !qco.qubit
    %343 = qco.rz(%cst_0) %342 : !qco.qubit -> !qco.qubit
    %344 = qco.sx %343 : !qco.qubit -> !qco.qubit
    %345 = qco.rz(%cst) %344 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%345) targets (%arg48 = %controls_out_35) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %346 = arith.divf %arg33, %cst_2 : f64
    %347 = math.tan %346 : f64
    %348 = math.atan %347 : f64
    %349 = arith.mulf %348, %cst_2 : f64
    %350 = arith.addf %349, %cst_1 : f64
    %351 = qco.rz(%350) %targets_out_66 : !qco.qubit -> !qco.qubit
    %352 = qco.sx %351 : !qco.qubit -> !qco.qubit
    %353 = qco.rz(%cst_0) %352 : !qco.qubit -> !qco.qubit
    %354 = qco.sx %353 : !qco.qubit -> !qco.qubit
    %355 = qco.rz(%cst) %354 : !qco.qubit -> !qco.qubit
    %controls_out_67, %targets_out_68 = qco.ctrl(%355) targets (%arg48 = %controls_out_37) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %356 = arith.divf %arg34, %cst_2 : f64
    %357 = math.tan %356 : f64
    %358 = math.atan %357 : f64
    %359 = arith.mulf %358, %cst_2 : f64
    %360 = arith.addf %359, %cst_1 : f64
    %361 = qco.rz(%360) %targets_out_68 : !qco.qubit -> !qco.qubit
    %362 = qco.sx %361 : !qco.qubit -> !qco.qubit
    %363 = qco.rz(%cst_0) %362 : !qco.qubit -> !qco.qubit
    %364 = qco.sx %363 : !qco.qubit -> !qco.qubit
    %365 = qco.rz(%cst) %364 : !qco.qubit -> !qco.qubit
    %controls_out_69, %targets_out_70 = qco.ctrl(%365) targets (%arg48 = %controls_out_39) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %366 = arith.divf %arg35, %cst_2 : f64
    %367 = math.tan %366 : f64
    %368 = math.atan %367 : f64
    %369 = arith.mulf %368, %cst_2 : f64
    %370 = arith.addf %369, %cst_1 : f64
    %371 = qco.rz(%370) %targets_out_70 : !qco.qubit -> !qco.qubit
    %372 = qco.sx %371 : !qco.qubit -> !qco.qubit
    %373 = qco.rz(%cst_0) %372 : !qco.qubit -> !qco.qubit
    %374 = qco.sx %373 : !qco.qubit -> !qco.qubit
    %375 = qco.rz(%cst) %374 : !qco.qubit -> !qco.qubit
    %controls_out_71, %targets_out_72 = qco.ctrl(%375) targets (%arg48 = %controls_out_41) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %376 = arith.divf %arg36, %cst_2 : f64
    %377 = math.tan %376 : f64
    %378 = math.atan %377 : f64
    %379 = arith.mulf %378, %cst_2 : f64
    %380 = arith.addf %379, %cst_1 : f64
    %381 = qco.rz(%380) %targets_out_72 : !qco.qubit -> !qco.qubit
    %382 = qco.sx %381 : !qco.qubit -> !qco.qubit
    %383 = qco.rz(%cst_0) %382 : !qco.qubit -> !qco.qubit
    %384 = qco.sx %383 : !qco.qubit -> !qco.qubit
    %385 = qco.rz(%cst) %384 : !qco.qubit -> !qco.qubit
    %controls_out_73, %targets_out_74 = qco.ctrl(%385) targets (%arg48 = %controls_out_43) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %386 = arith.divf %arg37, %cst_2 : f64
    %387 = math.tan %386 : f64
    %388 = math.atan %387 : f64
    %389 = arith.mulf %388, %cst_2 : f64
    %390 = arith.addf %389, %cst_1 : f64
    %391 = qco.rz(%390) %targets_out_74 : !qco.qubit -> !qco.qubit
    %392 = qco.sx %391 : !qco.qubit -> !qco.qubit
    %393 = qco.rz(%cst_0) %392 : !qco.qubit -> !qco.qubit
    %394 = qco.sx %393 : !qco.qubit -> !qco.qubit
    %395 = qco.rz(%cst) %394 : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%395) targets (%arg48 = %controls_out_45) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %396 = arith.divf %arg38, %cst_2 : f64
    %397 = math.tan %396 : f64
    %398 = math.atan %397 : f64
    %399 = arith.mulf %398, %cst_2 : f64
    %400 = arith.addf %399, %cst_1 : f64
    %401 = qco.rz(%400) %targets_out_76 : !qco.qubit -> !qco.qubit
    %402 = qco.sx %401 : !qco.qubit -> !qco.qubit
    %403 = qco.rz(%cst_0) %402 : !qco.qubit -> !qco.qubit
    %404 = qco.sx %403 : !qco.qubit -> !qco.qubit
    %405 = qco.rz(%cst) %404 : !qco.qubit -> !qco.qubit
    %controls_out_77, %targets_out_78 = qco.ctrl(%405) targets (%arg48 = %controls_out_47) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %406 = arith.divf %arg39, %cst_2 : f64
    %407 = math.tan %406 : f64
    %408 = math.atan %407 : f64
    %409 = arith.mulf %408, %cst_2 : f64
    %410 = arith.addf %409, %cst_1 : f64
    %411 = qco.rz(%410) %targets_out_78 : !qco.qubit -> !qco.qubit
    %412 = qco.sx %411 : !qco.qubit -> !qco.qubit
    %413 = qco.rz(%cst_0) %412 : !qco.qubit -> !qco.qubit
    %414 = qco.sx %413 : !qco.qubit -> !qco.qubit
    %415 = qco.rz(%cst) %414 : !qco.qubit -> !qco.qubit
    %controls_out_79, %targets_out_80 = qco.ctrl(%415) targets (%arg48 = %controls_out_49) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %416 = arith.divf %arg40, %cst_2 : f64
    %417 = math.tan %416 : f64
    %418 = math.atan %417 : f64
    %419 = arith.mulf %418, %cst_2 : f64
    %420 = arith.addf %419, %cst_1 : f64
    %421 = qco.rz(%420) %targets_out_80 : !qco.qubit -> !qco.qubit
    %422 = qco.sx %421 : !qco.qubit -> !qco.qubit
    %423 = qco.rz(%cst_0) %422 : !qco.qubit -> !qco.qubit
    %424 = qco.sx %423 : !qco.qubit -> !qco.qubit
    %425 = qco.rz(%cst) %424 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%425) targets (%arg48 = %controls_out_51) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %426 = arith.divf %arg41, %cst_2 : f64
    %427 = math.tan %426 : f64
    %428 = math.atan %427 : f64
    %429 = arith.mulf %428, %cst_2 : f64
    %430 = arith.addf %429, %cst_1 : f64
    %431 = qco.rz(%430) %targets_out_82 : !qco.qubit -> !qco.qubit
    %432 = qco.sx %431 : !qco.qubit -> !qco.qubit
    %433 = qco.rz(%cst_0) %432 : !qco.qubit -> !qco.qubit
    %434 = qco.sx %433 : !qco.qubit -> !qco.qubit
    %435 = qco.rz(%cst) %434 : !qco.qubit -> !qco.qubit
    %controls_out_83, %targets_out_84 = qco.ctrl(%435) targets (%arg48 = %controls_out_53) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %436 = arith.divf %arg42, %cst_2 : f64
    %437 = math.tan %436 : f64
    %438 = math.atan %437 : f64
    %439 = arith.mulf %438, %cst_2 : f64
    %440 = arith.addf %439, %cst_1 : f64
    %441 = qco.rz(%440) %targets_out_84 : !qco.qubit -> !qco.qubit
    %442 = qco.sx %441 : !qco.qubit -> !qco.qubit
    %443 = qco.rz(%cst_0) %442 : !qco.qubit -> !qco.qubit
    %444 = qco.sx %443 : !qco.qubit -> !qco.qubit
    %445 = qco.rz(%cst) %444 : !qco.qubit -> !qco.qubit
    %controls_out_85, %targets_out_86 = qco.ctrl(%445) targets (%arg48 = %controls_out_55) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %446 = arith.divf %arg43, %cst_2 : f64
    %447 = math.tan %446 : f64
    %448 = math.atan %447 : f64
    %449 = arith.mulf %448, %cst_2 : f64
    %450 = arith.addf %449, %cst_1 : f64
    %451 = qco.rz(%450) %targets_out_86 : !qco.qubit -> !qco.qubit
    %452 = qco.sx %451 : !qco.qubit -> !qco.qubit
    %453 = qco.rz(%cst_0) %452 : !qco.qubit -> !qco.qubit
    %454 = qco.sx %453 : !qco.qubit -> !qco.qubit
    %455 = qco.rz(%cst) %454 : !qco.qubit -> !qco.qubit
    %controls_out_87, %targets_out_88 = qco.ctrl(%455) targets (%arg48 = %controls_out_57) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %456 = arith.divf %arg44, %cst_2 : f64
    %457 = math.tan %456 : f64
    %458 = math.atan %457 : f64
    %459 = arith.mulf %458, %cst_2 : f64
    %460 = arith.addf %459, %cst_1 : f64
    %461 = qco.rz(%460) %targets_out_88 : !qco.qubit -> !qco.qubit
    %462 = qco.sx %461 : !qco.qubit -> !qco.qubit
    %463 = qco.rz(%cst_0) %462 : !qco.qubit -> !qco.qubit
    %464 = qco.sx %463 : !qco.qubit -> !qco.qubit
    %465 = qco.rz(%cst) %464 : !qco.qubit -> !qco.qubit
    %controls_out_89, %targets_out_90 = qco.ctrl(%465) targets (%arg48 = %controls_out_59) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %466 = arith.divf %arg45, %cst_2 : f64
    %467 = math.tan %466 : f64
    %468 = math.atan %467 : f64
    %469 = arith.mulf %468, %cst_2 : f64
    %470 = arith.addf %469, %cst_1 : f64
    %471 = qco.rz(%470) %targets_out_90 : !qco.qubit -> !qco.qubit
    %472 = qco.sx %471 : !qco.qubit -> !qco.qubit
    %473 = qco.rz(%cst_0) %472 : !qco.qubit -> !qco.qubit
    %474 = qco.sx %473 : !qco.qubit -> !qco.qubit
    %475 = qco.rz(%cst) %474 : !qco.qubit -> !qco.qubit
    %controls_out_91, %targets_out_92 = qco.ctrl(%475) targets (%arg48 = %controls_out_61) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %476 = arith.divf %arg46, %cst_2 : f64
    %477 = math.tan %476 : f64
    %478 = math.atan %477 : f64
    %479 = arith.mulf %478, %cst_2 : f64
    %480 = arith.addf %479, %cst_1 : f64
    %481 = qco.rz(%480) %targets_out_92 : !qco.qubit -> !qco.qubit
    %482 = qco.sx %481 : !qco.qubit -> !qco.qubit
    %483 = qco.rz(%cst_0) %482 : !qco.qubit -> !qco.qubit
    %484 = qco.sx %483 : !qco.qubit -> !qco.qubit
    %485 = qco.rz(%cst) %484 : !qco.qubit -> !qco.qubit
    %controls_out_93, %targets_out_94 = qco.ctrl(%485) targets (%arg48 = %controls_out_63) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %486 = arith.divf %arg47, %cst_2 : f64
    %487 = math.tan %486 : f64
    %488 = math.atan %487 : f64
    %489 = arith.mulf %488, %cst_2 : f64
    %490 = arith.addf %489, %cst_1 : f64
    %491 = qco.rz(%490) %targets_out_94 : !qco.qubit -> !qco.qubit
    %492 = qco.sx %491 : !qco.qubit -> !qco.qubit
    %493 = qco.rz(%cst_0) %492 : !qco.qubit -> !qco.qubit
    %494 = qco.sx %493 : !qco.qubit -> !qco.qubit
    %495 = qco.rz(%cst) %494 : !qco.qubit -> !qco.qubit
    qco.sink %controls_out_67 : !qco.qubit
    qco.sink %controls_out_69 : !qco.qubit
    qco.sink %controls_out_71 : !qco.qubit
    qco.sink %controls_out_73 : !qco.qubit
    qco.sink %controls_out_75 : !qco.qubit
    qco.sink %controls_out_77 : !qco.qubit
    qco.sink %controls_out_79 : !qco.qubit
    qco.sink %controls_out_81 : !qco.qubit
    qco.sink %controls_out_83 : !qco.qubit
    qco.sink %controls_out_85 : !qco.qubit
    qco.sink %controls_out_87 : !qco.qubit
    qco.sink %controls_out_89 : !qco.qubit
    qco.sink %controls_out_91 : !qco.qubit
    qco.sink %controls_out_93 : !qco.qubit
    %controls_out_95, %targets_out_96 = qco.ctrl(%495) targets (%arg48 = %controls_out_65) {
      %496 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %496 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    qco.sink %targets_out_96 : !qco.qubit
    qco.sink %controls_out_95 : !qco.qubit
    return %c0_i64 : i64
  }
}
