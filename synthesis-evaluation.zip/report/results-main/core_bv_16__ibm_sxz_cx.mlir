module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<15> attributes {mqt.entry_point} {
    %cst = arith.constant -3.1415926535897931 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %cst_2 = arith.constant 1.5707963267948968 : f64
    %cst_3 = arith.constant -1.5707963267948963 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<15>
    %17 = qco.x %0 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_1) %1 : !qco.qubit -> !qco.qubit
    %19 = qco.sx %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_1) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_1) %3 : !qco.qubit -> !qco.qubit
    %22 = qco.sx %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_1) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_1) %5 : !qco.qubit -> !qco.qubit
    %25 = qco.sx %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_1) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_1) %7 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_1) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_1) %9 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_1) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_1) %11 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_1) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_1) %13 : !qco.qubit -> !qco.qubit
    %37 = qco.sx %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_1) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_1) %15 : !qco.qubit -> !qco.qubit
    %40 = qco.sx %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_1) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_3) %17 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_2) %43 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%20) targets (%arg0 = %44) {
      %107 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %107 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.rz(%cst_1) %targets_out : !qco.qubit -> !qco.qubit
    %46 = qco.sx %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_2) %48 : !qco.qubit -> !qco.qubit
    %controls_out_4, %targets_out_5 = qco.ctrl(%23) targets (%arg0 = %49) {
      %107 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %107 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qco.rz(%cst_1) %targets_out_5 : !qco.qubit -> !qco.qubit
    %51 = qco.sx %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_2) %53 : !qco.qubit -> !qco.qubit
    %controls_out_6, %targets_out_7 = qco.ctrl(%26) targets (%arg0 = %54) {
      %107 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %107 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.rz(%cst_1) %targets_out_7 : !qco.qubit -> !qco.qubit
    %56 = qco.sx %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.sx %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_2) %58 : !qco.qubit -> !qco.qubit
    %controls_out_8, %targets_out_9 = qco.ctrl(%29) targets (%arg0 = %59) {
      %107 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %107 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qco.rz(%cst_1) %targets_out_9 : !qco.qubit -> !qco.qubit
    %61 = qco.sx %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.sx %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_2) %63 : !qco.qubit -> !qco.qubit
    %controls_out_10, %targets_out_11 = qco.ctrl(%32) targets (%arg0 = %64) {
      %107 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %107 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qco.rz(%cst_1) %targets_out_11 : !qco.qubit -> !qco.qubit
    %66 = qco.sx %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.sx %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_2) %68 : !qco.qubit -> !qco.qubit
    %controls_out_12, %targets_out_13 = qco.ctrl(%35) targets (%arg0 = %69) {
      %107 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %107 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %70 = qco.rz(%cst_1) %targets_out_13 : !qco.qubit -> !qco.qubit
    %71 = qco.sx %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.sx %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_2) %73 : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%38) targets (%arg0 = %74) {
      %107 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %107 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %75 = qco.rz(%cst_1) %targets_out_15 : !qco.qubit -> !qco.qubit
    %76 = qco.sx %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.sx %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_2) %78 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%41) targets (%arg0 = %79) {
      %107 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %107 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %80 = qco.rz(%cst_1) %targets_out_17 : !qco.qubit -> !qco.qubit
    %81 = qco.sx %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_0) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_1) %controls_out : !qco.qubit -> !qco.qubit
    %84 = qco.sx %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_1) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_1) %controls_out_4 : !qco.qubit -> !qco.qubit
    %87 = qco.sx %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_1) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_1) %controls_out_6 : !qco.qubit -> !qco.qubit
    %90 = qco.sx %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_1) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_1) %controls_out_8 : !qco.qubit -> !qco.qubit
    %93 = qco.sx %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_1) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_1) %controls_out_10 : !qco.qubit -> !qco.qubit
    %96 = qco.sx %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_1) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_1) %controls_out_12 : !qco.qubit -> !qco.qubit
    %99 = qco.sx %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_1) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst_1) %controls_out_14 : !qco.qubit -> !qco.qubit
    %102 = qco.sx %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst_1) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_1) %controls_out_16 : !qco.qubit -> !qco.qubit
    %105 = qco.sx %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_1) %105 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %85 : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<15>
    %qubit_out_18, %result_19 = qco.measure %2 : !qco.qubit
    cbit.store %result_19, %16[%c1] : !cbit.reg<15>
    %qubit_out_20, %result_21 = qco.measure %88 : !qco.qubit
    cbit.store %result_21, %16[%c2] : !cbit.reg<15>
    %qubit_out_22, %result_23 = qco.measure %4 : !qco.qubit
    cbit.store %result_23, %16[%c3] : !cbit.reg<15>
    %qubit_out_24, %result_25 = qco.measure %91 : !qco.qubit
    cbit.store %result_25, %16[%c4] : !cbit.reg<15>
    %qubit_out_26, %result_27 = qco.measure %6 : !qco.qubit
    cbit.store %result_27, %16[%c5] : !cbit.reg<15>
    %qubit_out_28, %result_29 = qco.measure %94 : !qco.qubit
    cbit.store %result_29, %16[%c6] : !cbit.reg<15>
    %qubit_out_30, %result_31 = qco.measure %8 : !qco.qubit
    cbit.store %result_31, %16[%c7] : !cbit.reg<15>
    %qubit_out_32, %result_33 = qco.measure %97 : !qco.qubit
    cbit.store %result_33, %16[%c8] : !cbit.reg<15>
    %qubit_out_34, %result_35 = qco.measure %10 : !qco.qubit
    cbit.store %result_35, %16[%c9] : !cbit.reg<15>
    %qubit_out_36, %result_37 = qco.measure %100 : !qco.qubit
    cbit.store %result_37, %16[%c10] : !cbit.reg<15>
    %qubit_out_38, %result_39 = qco.measure %12 : !qco.qubit
    cbit.store %result_39, %16[%c11] : !cbit.reg<15>
    %qubit_out_40, %result_41 = qco.measure %103 : !qco.qubit
    cbit.store %result_41, %16[%c12] : !cbit.reg<15>
    %qubit_out_42, %result_43 = qco.measure %14 : !qco.qubit
    cbit.store %result_43, %16[%c13] : !cbit.reg<15>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_18 : !qco.qubit
    qco.sink %qubit_out_20 : !qco.qubit
    qco.sink %qubit_out_22 : !qco.qubit
    qco.sink %qubit_out_24 : !qco.qubit
    qco.sink %qubit_out_26 : !qco.qubit
    qco.sink %qubit_out_28 : !qco.qubit
    qco.sink %qubit_out_30 : !qco.qubit
    qco.sink %qubit_out_32 : !qco.qubit
    qco.sink %qubit_out_34 : !qco.qubit
    qco.sink %qubit_out_36 : !qco.qubit
    qco.sink %qubit_out_38 : !qco.qubit
    qco.sink %qubit_out_40 : !qco.qubit
    qco.sink %qubit_out_42 : !qco.qubit
    %qubit_out_44, %result_45 = qco.measure %106 : !qco.qubit
    qco.sink %qubit_out_44 : !qco.qubit
    cbit.store %result_45, %16[%c14] : !cbit.reg<15>
    qco.sink %82 : !qco.qubit
    return %16 : !cbit.reg<15>
  }
}
