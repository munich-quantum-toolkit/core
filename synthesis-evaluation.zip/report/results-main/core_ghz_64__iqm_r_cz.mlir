module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63>, input_count = 64 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>, <id = 16>, <id = 17>, <id = 18>, <id = 19>, <id = 20>, <id = 21>, <id = 22>, <id = 23>, <id = 24>, <id = 25>, <id = 26>, <id = 27>, <id = 28>, <id = 29>, <id = 30>, <id = 31>, <id = 32>, <id = 33>, <id = 34>, <id = 35>, <id = 36>, <id = 37>, <id = 38>, <id = 39>, <id = 40>, <id = 41>, <id = 42>, <id = 43>, <id = 44>, <id = 45>, <id = 46>, <id = 47>, <id = 48>, <id = 49>, <id = 50>, <id = 51>, <id = 52>, <id = 53>, <id = 54>, <id = 55>, <id = 56>, <id = 57>, <id = 58>, <id = 59>, <id = 60>, <id = 61>, <id = 62>, <id = 63>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<64> attributes {mqt.entry_point} {
    %cst = arith.constant 6.2831853071795862 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant 0.000000e+00 : f64
    %cst_2 = arith.constant 3.1415926535897931 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %c15 = arith.constant 15 : index
    %c16 = arith.constant 16 : index
    %c17 = arith.constant 17 : index
    %c18 = arith.constant 18 : index
    %c19 = arith.constant 19 : index
    %c20 = arith.constant 20 : index
    %c21 = arith.constant 21 : index
    %c22 = arith.constant 22 : index
    %c23 = arith.constant 23 : index
    %c24 = arith.constant 24 : index
    %c25 = arith.constant 25 : index
    %c26 = arith.constant 26 : index
    %c27 = arith.constant 27 : index
    %c28 = arith.constant 28 : index
    %c29 = arith.constant 29 : index
    %c30 = arith.constant 30 : index
    %c31 = arith.constant 31 : index
    %c32 = arith.constant 32 : index
    %c33 = arith.constant 33 : index
    %c34 = arith.constant 34 : index
    %c35 = arith.constant 35 : index
    %c36 = arith.constant 36 : index
    %c37 = arith.constant 37 : index
    %c38 = arith.constant 38 : index
    %c39 = arith.constant 39 : index
    %c40 = arith.constant 40 : index
    %c41 = arith.constant 41 : index
    %c42 = arith.constant 42 : index
    %c43 = arith.constant 43 : index
    %c44 = arith.constant 44 : index
    %c45 = arith.constant 45 : index
    %c46 = arith.constant 46 : index
    %c47 = arith.constant 47 : index
    %c48 = arith.constant 48 : index
    %c49 = arith.constant 49 : index
    %c50 = arith.constant 50 : index
    %c51 = arith.constant 51 : index
    %c52 = arith.constant 52 : index
    %c53 = arith.constant 53 : index
    %c54 = arith.constant 54 : index
    %c55 = arith.constant 55 : index
    %c56 = arith.constant 56 : index
    %c57 = arith.constant 57 : index
    %c58 = arith.constant 58 : index
    %c59 = arith.constant 59 : index
    %c60 = arith.constant 60 : index
    %c61 = arith.constant 61 : index
    %c62 = arith.constant 62 : index
    %c63 = arith.constant 63 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = qco.static 16 : !qco.qubit
    %17 = qco.static 17 : !qco.qubit
    %18 = qco.static 18 : !qco.qubit
    %19 = qco.static 19 : !qco.qubit
    %20 = qco.static 20 : !qco.qubit
    %21 = qco.static 21 : !qco.qubit
    %22 = qco.static 22 : !qco.qubit
    %23 = qco.static 23 : !qco.qubit
    %24 = qco.static 24 : !qco.qubit
    %25 = qco.static 25 : !qco.qubit
    %26 = qco.static 26 : !qco.qubit
    %27 = qco.static 27 : !qco.qubit
    %28 = qco.static 28 : !qco.qubit
    %29 = qco.static 29 : !qco.qubit
    %30 = qco.static 30 : !qco.qubit
    %31 = qco.static 31 : !qco.qubit
    %32 = qco.static 32 : !qco.qubit
    %33 = qco.static 33 : !qco.qubit
    %34 = qco.static 34 : !qco.qubit
    %35 = qco.static 35 : !qco.qubit
    %36 = qco.static 36 : !qco.qubit
    %37 = qco.static 37 : !qco.qubit
    %38 = qco.static 38 : !qco.qubit
    %39 = qco.static 39 : !qco.qubit
    %40 = qco.static 40 : !qco.qubit
    %41 = qco.static 41 : !qco.qubit
    %42 = qco.static 42 : !qco.qubit
    %43 = qco.static 43 : !qco.qubit
    %44 = qco.static 44 : !qco.qubit
    %45 = qco.static 45 : !qco.qubit
    %46 = qco.static 46 : !qco.qubit
    %47 = qco.static 47 : !qco.qubit
    %48 = qco.static 48 : !qco.qubit
    %49 = qco.static 49 : !qco.qubit
    %50 = qco.static 50 : !qco.qubit
    %51 = qco.static 51 : !qco.qubit
    %52 = qco.static 52 : !qco.qubit
    %53 = qco.static 53 : !qco.qubit
    %54 = qco.static 54 : !qco.qubit
    %55 = qco.static 55 : !qco.qubit
    %56 = qco.static 56 : !qco.qubit
    %57 = qco.static 57 : !qco.qubit
    %58 = qco.static 58 : !qco.qubit
    %59 = qco.static 59 : !qco.qubit
    %60 = qco.static 60 : !qco.qubit
    %61 = qco.static 61 : !qco.qubit
    %62 = qco.static 62 : !qco.qubit
    %63 = qco.static 63 : !qco.qubit
    %64 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<64>
    %65 = qco.r(%cst_0, %cst_0) %0 : !qco.qubit -> !qco.qubit
    %66 = qco.r(%cst_2, %cst_1) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.r(%cst_2, %cst_1) %1 : !qco.qubit -> !qco.qubit
    %68 = qco.r(%cst_0, %cst_0) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.r(%cst_2, %cst_1) %68 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%66) targets (%arg0 = %69) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %70 = qco.r(%cst_0, %cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %71 = qco.r(%cst, %cst_1) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%cst_2, %cst_1) %2 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%cst_0, %cst_0) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.r(%cst_2, %cst_1) %73 : !qco.qubit -> !qco.qubit
    %controls_out_3, %targets_out_4 = qco.ctrl(%71) targets (%arg0 = %74) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %75 = qco.r(%cst_0, %cst_0) %targets_out_4 : !qco.qubit -> !qco.qubit
    %76 = qco.r(%cst, %cst_1) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.r(%cst_2, %cst_1) %3 : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst_0, %cst_0) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.r(%cst_2, %cst_1) %78 : !qco.qubit -> !qco.qubit
    %controls_out_5, %targets_out_6 = qco.ctrl(%76) targets (%arg0 = %79) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %80 = qco.r(%cst_0, %cst_0) %targets_out_6 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%cst, %cst_1) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.r(%cst_2, %cst_1) %4 : !qco.qubit -> !qco.qubit
    %83 = qco.r(%cst_0, %cst_0) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.r(%cst_2, %cst_1) %83 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%81) targets (%arg0 = %84) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %85 = qco.r(%cst_0, %cst_0) %targets_out_8 : !qco.qubit -> !qco.qubit
    %86 = qco.r(%cst, %cst_1) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.r(%cst_2, %cst_1) %5 : !qco.qubit -> !qco.qubit
    %88 = qco.r(%cst_0, %cst_0) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%cst_2, %cst_1) %88 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%86) targets (%arg0 = %89) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %90 = qco.r(%cst_0, %cst_0) %targets_out_10 : !qco.qubit -> !qco.qubit
    %91 = qco.r(%cst, %cst_1) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.r(%cst_2, %cst_1) %6 : !qco.qubit -> !qco.qubit
    %93 = qco.r(%cst_0, %cst_0) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.r(%cst_2, %cst_1) %93 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%91) targets (%arg0 = %94) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %95 = qco.r(%cst_0, %cst_0) %targets_out_12 : !qco.qubit -> !qco.qubit
    %96 = qco.r(%cst, %cst_1) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.r(%cst_2, %cst_1) %7 : !qco.qubit -> !qco.qubit
    %98 = qco.r(%cst_0, %cst_0) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.r(%cst_2, %cst_1) %98 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%96) targets (%arg0 = %99) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %100 = qco.r(%cst_0, %cst_0) %targets_out_14 : !qco.qubit -> !qco.qubit
    %101 = qco.r(%cst, %cst_1) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.r(%cst_2, %cst_1) %8 : !qco.qubit -> !qco.qubit
    %103 = qco.r(%cst_0, %cst_0) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.r(%cst_2, %cst_1) %103 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%101) targets (%arg0 = %104) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %105 = qco.r(%cst_0, %cst_0) %targets_out_16 : !qco.qubit -> !qco.qubit
    %106 = qco.r(%cst, %cst_1) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.r(%cst_2, %cst_1) %9 : !qco.qubit -> !qco.qubit
    %108 = qco.r(%cst_0, %cst_0) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.r(%cst_2, %cst_1) %108 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%106) targets (%arg0 = %109) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %110 = qco.r(%cst_0, %cst_0) %targets_out_18 : !qco.qubit -> !qco.qubit
    %111 = qco.r(%cst, %cst_1) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.r(%cst_2, %cst_1) %10 : !qco.qubit -> !qco.qubit
    %113 = qco.r(%cst_0, %cst_0) %112 : !qco.qubit -> !qco.qubit
    %114 = qco.r(%cst_2, %cst_1) %113 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%111) targets (%arg0 = %114) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %115 = qco.r(%cst_0, %cst_0) %targets_out_20 : !qco.qubit -> !qco.qubit
    %116 = qco.r(%cst, %cst_1) %115 : !qco.qubit -> !qco.qubit
    %117 = qco.r(%cst_2, %cst_1) %11 : !qco.qubit -> !qco.qubit
    %118 = qco.r(%cst_0, %cst_0) %117 : !qco.qubit -> !qco.qubit
    %119 = qco.r(%cst_2, %cst_1) %118 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%116) targets (%arg0 = %119) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %120 = qco.r(%cst_0, %cst_0) %targets_out_22 : !qco.qubit -> !qco.qubit
    %121 = qco.r(%cst, %cst_1) %120 : !qco.qubit -> !qco.qubit
    %122 = qco.r(%cst_2, %cst_1) %12 : !qco.qubit -> !qco.qubit
    %123 = qco.r(%cst_0, %cst_0) %122 : !qco.qubit -> !qco.qubit
    %124 = qco.r(%cst_2, %cst_1) %123 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%121) targets (%arg0 = %124) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %125 = qco.r(%cst_0, %cst_0) %targets_out_24 : !qco.qubit -> !qco.qubit
    %126 = qco.r(%cst, %cst_1) %125 : !qco.qubit -> !qco.qubit
    %127 = qco.r(%cst_2, %cst_1) %13 : !qco.qubit -> !qco.qubit
    %128 = qco.r(%cst_0, %cst_0) %127 : !qco.qubit -> !qco.qubit
    %129 = qco.r(%cst_2, %cst_1) %128 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%126) targets (%arg0 = %129) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %130 = qco.r(%cst_0, %cst_0) %targets_out_26 : !qco.qubit -> !qco.qubit
    %131 = qco.r(%cst, %cst_1) %130 : !qco.qubit -> !qco.qubit
    %132 = qco.r(%cst_2, %cst_1) %14 : !qco.qubit -> !qco.qubit
    %133 = qco.r(%cst_0, %cst_0) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.r(%cst_2, %cst_1) %133 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%131) targets (%arg0 = %134) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %135 = qco.r(%cst_0, %cst_0) %targets_out_28 : !qco.qubit -> !qco.qubit
    %136 = qco.r(%cst, %cst_1) %135 : !qco.qubit -> !qco.qubit
    %137 = qco.r(%cst_2, %cst_1) %15 : !qco.qubit -> !qco.qubit
    %138 = qco.r(%cst_0, %cst_0) %137 : !qco.qubit -> !qco.qubit
    %139 = qco.r(%cst_2, %cst_1) %138 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%136) targets (%arg0 = %139) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %140 = qco.r(%cst_0, %cst_0) %targets_out_30 : !qco.qubit -> !qco.qubit
    %141 = qco.r(%cst, %cst_1) %140 : !qco.qubit -> !qco.qubit
    %142 = qco.r(%cst_2, %cst_1) %16 : !qco.qubit -> !qco.qubit
    %143 = qco.r(%cst_0, %cst_0) %142 : !qco.qubit -> !qco.qubit
    %144 = qco.r(%cst_2, %cst_1) %143 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%141) targets (%arg0 = %144) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %145 = qco.r(%cst_0, %cst_0) %targets_out_32 : !qco.qubit -> !qco.qubit
    %146 = qco.r(%cst, %cst_1) %145 : !qco.qubit -> !qco.qubit
    %147 = qco.r(%cst_2, %cst_1) %17 : !qco.qubit -> !qco.qubit
    %148 = qco.r(%cst_0, %cst_0) %147 : !qco.qubit -> !qco.qubit
    %149 = qco.r(%cst_2, %cst_1) %148 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%146) targets (%arg0 = %149) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %150 = qco.r(%cst_0, %cst_0) %targets_out_34 : !qco.qubit -> !qco.qubit
    %151 = qco.r(%cst, %cst_1) %150 : !qco.qubit -> !qco.qubit
    %152 = qco.r(%cst_2, %cst_1) %18 : !qco.qubit -> !qco.qubit
    %153 = qco.r(%cst_0, %cst_0) %152 : !qco.qubit -> !qco.qubit
    %154 = qco.r(%cst_2, %cst_1) %153 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%151) targets (%arg0 = %154) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %155 = qco.r(%cst_0, %cst_0) %targets_out_36 : !qco.qubit -> !qco.qubit
    %156 = qco.r(%cst, %cst_1) %155 : !qco.qubit -> !qco.qubit
    %157 = qco.r(%cst_2, %cst_1) %19 : !qco.qubit -> !qco.qubit
    %158 = qco.r(%cst_0, %cst_0) %157 : !qco.qubit -> !qco.qubit
    %159 = qco.r(%cst_2, %cst_1) %158 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%156) targets (%arg0 = %159) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %160 = qco.r(%cst_0, %cst_0) %targets_out_38 : !qco.qubit -> !qco.qubit
    %161 = qco.r(%cst, %cst_1) %160 : !qco.qubit -> !qco.qubit
    %162 = qco.r(%cst_2, %cst_1) %20 : !qco.qubit -> !qco.qubit
    %163 = qco.r(%cst_0, %cst_0) %162 : !qco.qubit -> !qco.qubit
    %164 = qco.r(%cst_2, %cst_1) %163 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%161) targets (%arg0 = %164) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %165 = qco.r(%cst_0, %cst_0) %targets_out_40 : !qco.qubit -> !qco.qubit
    %166 = qco.r(%cst, %cst_1) %165 : !qco.qubit -> !qco.qubit
    %167 = qco.r(%cst_2, %cst_1) %21 : !qco.qubit -> !qco.qubit
    %168 = qco.r(%cst_0, %cst_0) %167 : !qco.qubit -> !qco.qubit
    %169 = qco.r(%cst_2, %cst_1) %168 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%166) targets (%arg0 = %169) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %170 = qco.r(%cst_0, %cst_0) %targets_out_42 : !qco.qubit -> !qco.qubit
    %171 = qco.r(%cst, %cst_1) %170 : !qco.qubit -> !qco.qubit
    %172 = qco.r(%cst_2, %cst_1) %22 : !qco.qubit -> !qco.qubit
    %173 = qco.r(%cst_0, %cst_0) %172 : !qco.qubit -> !qco.qubit
    %174 = qco.r(%cst_2, %cst_1) %173 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%171) targets (%arg0 = %174) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %175 = qco.r(%cst_0, %cst_0) %targets_out_44 : !qco.qubit -> !qco.qubit
    %176 = qco.r(%cst, %cst_1) %175 : !qco.qubit -> !qco.qubit
    %177 = qco.r(%cst_2, %cst_1) %23 : !qco.qubit -> !qco.qubit
    %178 = qco.r(%cst_0, %cst_0) %177 : !qco.qubit -> !qco.qubit
    %179 = qco.r(%cst_2, %cst_1) %178 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%176) targets (%arg0 = %179) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %180 = qco.r(%cst_0, %cst_0) %targets_out_46 : !qco.qubit -> !qco.qubit
    %181 = qco.r(%cst, %cst_1) %180 : !qco.qubit -> !qco.qubit
    %182 = qco.r(%cst_2, %cst_1) %24 : !qco.qubit -> !qco.qubit
    %183 = qco.r(%cst_0, %cst_0) %182 : !qco.qubit -> !qco.qubit
    %184 = qco.r(%cst_2, %cst_1) %183 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%181) targets (%arg0 = %184) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %185 = qco.r(%cst_0, %cst_0) %targets_out_48 : !qco.qubit -> !qco.qubit
    %186 = qco.r(%cst, %cst_1) %185 : !qco.qubit -> !qco.qubit
    %187 = qco.r(%cst_2, %cst_1) %25 : !qco.qubit -> !qco.qubit
    %188 = qco.r(%cst_0, %cst_0) %187 : !qco.qubit -> !qco.qubit
    %189 = qco.r(%cst_2, %cst_1) %188 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%186) targets (%arg0 = %189) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %190 = qco.r(%cst_0, %cst_0) %targets_out_50 : !qco.qubit -> !qco.qubit
    %191 = qco.r(%cst, %cst_1) %190 : !qco.qubit -> !qco.qubit
    %192 = qco.r(%cst_2, %cst_1) %26 : !qco.qubit -> !qco.qubit
    %193 = qco.r(%cst_0, %cst_0) %192 : !qco.qubit -> !qco.qubit
    %194 = qco.r(%cst_2, %cst_1) %193 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%191) targets (%arg0 = %194) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %195 = qco.r(%cst_0, %cst_0) %targets_out_52 : !qco.qubit -> !qco.qubit
    %196 = qco.r(%cst, %cst_1) %195 : !qco.qubit -> !qco.qubit
    %197 = qco.r(%cst_2, %cst_1) %27 : !qco.qubit -> !qco.qubit
    %198 = qco.r(%cst_0, %cst_0) %197 : !qco.qubit -> !qco.qubit
    %199 = qco.r(%cst_2, %cst_1) %198 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%196) targets (%arg0 = %199) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %200 = qco.r(%cst_0, %cst_0) %targets_out_54 : !qco.qubit -> !qco.qubit
    %201 = qco.r(%cst, %cst_1) %200 : !qco.qubit -> !qco.qubit
    %202 = qco.r(%cst_2, %cst_1) %28 : !qco.qubit -> !qco.qubit
    %203 = qco.r(%cst_0, %cst_0) %202 : !qco.qubit -> !qco.qubit
    %204 = qco.r(%cst_2, %cst_1) %203 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%201) targets (%arg0 = %204) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %205 = qco.r(%cst_0, %cst_0) %targets_out_56 : !qco.qubit -> !qco.qubit
    %206 = qco.r(%cst, %cst_1) %205 : !qco.qubit -> !qco.qubit
    %207 = qco.r(%cst_2, %cst_1) %29 : !qco.qubit -> !qco.qubit
    %208 = qco.r(%cst_0, %cst_0) %207 : !qco.qubit -> !qco.qubit
    %209 = qco.r(%cst_2, %cst_1) %208 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%206) targets (%arg0 = %209) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %210 = qco.r(%cst_0, %cst_0) %targets_out_58 : !qco.qubit -> !qco.qubit
    %211 = qco.r(%cst, %cst_1) %210 : !qco.qubit -> !qco.qubit
    %212 = qco.r(%cst_2, %cst_1) %30 : !qco.qubit -> !qco.qubit
    %213 = qco.r(%cst_0, %cst_0) %212 : !qco.qubit -> !qco.qubit
    %214 = qco.r(%cst_2, %cst_1) %213 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%211) targets (%arg0 = %214) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %215 = qco.r(%cst_0, %cst_0) %targets_out_60 : !qco.qubit -> !qco.qubit
    %216 = qco.r(%cst, %cst_1) %215 : !qco.qubit -> !qco.qubit
    %217 = qco.r(%cst_2, %cst_1) %31 : !qco.qubit -> !qco.qubit
    %218 = qco.r(%cst_0, %cst_0) %217 : !qco.qubit -> !qco.qubit
    %219 = qco.r(%cst_2, %cst_1) %218 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%216) targets (%arg0 = %219) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %220 = qco.r(%cst_0, %cst_0) %targets_out_62 : !qco.qubit -> !qco.qubit
    %221 = qco.r(%cst, %cst_1) %220 : !qco.qubit -> !qco.qubit
    %222 = qco.r(%cst_2, %cst_1) %32 : !qco.qubit -> !qco.qubit
    %223 = qco.r(%cst_0, %cst_0) %222 : !qco.qubit -> !qco.qubit
    %224 = qco.r(%cst_2, %cst_1) %223 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%221) targets (%arg0 = %224) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %225 = qco.r(%cst_0, %cst_0) %targets_out_64 : !qco.qubit -> !qco.qubit
    %226 = qco.r(%cst, %cst_1) %225 : !qco.qubit -> !qco.qubit
    %227 = qco.r(%cst_2, %cst_1) %33 : !qco.qubit -> !qco.qubit
    %228 = qco.r(%cst_0, %cst_0) %227 : !qco.qubit -> !qco.qubit
    %229 = qco.r(%cst_2, %cst_1) %228 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%226) targets (%arg0 = %229) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %230 = qco.r(%cst_0, %cst_0) %targets_out_66 : !qco.qubit -> !qco.qubit
    %231 = qco.r(%cst, %cst_1) %230 : !qco.qubit -> !qco.qubit
    %232 = qco.r(%cst_2, %cst_1) %34 : !qco.qubit -> !qco.qubit
    %233 = qco.r(%cst_0, %cst_0) %232 : !qco.qubit -> !qco.qubit
    %234 = qco.r(%cst_2, %cst_1) %233 : !qco.qubit -> !qco.qubit
    %controls_out_67, %targets_out_68 = qco.ctrl(%231) targets (%arg0 = %234) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %235 = qco.r(%cst_0, %cst_0) %targets_out_68 : !qco.qubit -> !qco.qubit
    %236 = qco.r(%cst, %cst_1) %235 : !qco.qubit -> !qco.qubit
    %237 = qco.r(%cst_2, %cst_1) %35 : !qco.qubit -> !qco.qubit
    %238 = qco.r(%cst_0, %cst_0) %237 : !qco.qubit -> !qco.qubit
    %239 = qco.r(%cst_2, %cst_1) %238 : !qco.qubit -> !qco.qubit
    %controls_out_69, %targets_out_70 = qco.ctrl(%236) targets (%arg0 = %239) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %240 = qco.r(%cst_0, %cst_0) %targets_out_70 : !qco.qubit -> !qco.qubit
    %241 = qco.r(%cst, %cst_1) %240 : !qco.qubit -> !qco.qubit
    %242 = qco.r(%cst_2, %cst_1) %36 : !qco.qubit -> !qco.qubit
    %243 = qco.r(%cst_0, %cst_0) %242 : !qco.qubit -> !qco.qubit
    %244 = qco.r(%cst_2, %cst_1) %243 : !qco.qubit -> !qco.qubit
    %controls_out_71, %targets_out_72 = qco.ctrl(%241) targets (%arg0 = %244) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %245 = qco.r(%cst_0, %cst_0) %targets_out_72 : !qco.qubit -> !qco.qubit
    %246 = qco.r(%cst, %cst_1) %245 : !qco.qubit -> !qco.qubit
    %247 = qco.r(%cst_2, %cst_1) %37 : !qco.qubit -> !qco.qubit
    %248 = qco.r(%cst_0, %cst_0) %247 : !qco.qubit -> !qco.qubit
    %249 = qco.r(%cst_2, %cst_1) %248 : !qco.qubit -> !qco.qubit
    %controls_out_73, %targets_out_74 = qco.ctrl(%246) targets (%arg0 = %249) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %250 = qco.r(%cst_0, %cst_0) %targets_out_74 : !qco.qubit -> !qco.qubit
    %251 = qco.r(%cst, %cst_1) %250 : !qco.qubit -> !qco.qubit
    %252 = qco.r(%cst_2, %cst_1) %38 : !qco.qubit -> !qco.qubit
    %253 = qco.r(%cst_0, %cst_0) %252 : !qco.qubit -> !qco.qubit
    %254 = qco.r(%cst_2, %cst_1) %253 : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%251) targets (%arg0 = %254) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %255 = qco.r(%cst_0, %cst_0) %targets_out_76 : !qco.qubit -> !qco.qubit
    %256 = qco.r(%cst, %cst_1) %255 : !qco.qubit -> !qco.qubit
    %257 = qco.r(%cst_2, %cst_1) %39 : !qco.qubit -> !qco.qubit
    %258 = qco.r(%cst_0, %cst_0) %257 : !qco.qubit -> !qco.qubit
    %259 = qco.r(%cst_2, %cst_1) %258 : !qco.qubit -> !qco.qubit
    %controls_out_77, %targets_out_78 = qco.ctrl(%256) targets (%arg0 = %259) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %260 = qco.r(%cst_0, %cst_0) %targets_out_78 : !qco.qubit -> !qco.qubit
    %261 = qco.r(%cst, %cst_1) %260 : !qco.qubit -> !qco.qubit
    %262 = qco.r(%cst_2, %cst_1) %40 : !qco.qubit -> !qco.qubit
    %263 = qco.r(%cst_0, %cst_0) %262 : !qco.qubit -> !qco.qubit
    %264 = qco.r(%cst_2, %cst_1) %263 : !qco.qubit -> !qco.qubit
    %controls_out_79, %targets_out_80 = qco.ctrl(%261) targets (%arg0 = %264) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %265 = qco.r(%cst_0, %cst_0) %targets_out_80 : !qco.qubit -> !qco.qubit
    %266 = qco.r(%cst, %cst_1) %265 : !qco.qubit -> !qco.qubit
    %267 = qco.r(%cst_2, %cst_1) %41 : !qco.qubit -> !qco.qubit
    %268 = qco.r(%cst_0, %cst_0) %267 : !qco.qubit -> !qco.qubit
    %269 = qco.r(%cst_2, %cst_1) %268 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%266) targets (%arg0 = %269) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %270 = qco.r(%cst_0, %cst_0) %targets_out_82 : !qco.qubit -> !qco.qubit
    %271 = qco.r(%cst, %cst_1) %270 : !qco.qubit -> !qco.qubit
    %272 = qco.r(%cst_2, %cst_1) %42 : !qco.qubit -> !qco.qubit
    %273 = qco.r(%cst_0, %cst_0) %272 : !qco.qubit -> !qco.qubit
    %274 = qco.r(%cst_2, %cst_1) %273 : !qco.qubit -> !qco.qubit
    %controls_out_83, %targets_out_84 = qco.ctrl(%271) targets (%arg0 = %274) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %275 = qco.r(%cst_0, %cst_0) %targets_out_84 : !qco.qubit -> !qco.qubit
    %276 = qco.r(%cst, %cst_1) %275 : !qco.qubit -> !qco.qubit
    %277 = qco.r(%cst_2, %cst_1) %43 : !qco.qubit -> !qco.qubit
    %278 = qco.r(%cst_0, %cst_0) %277 : !qco.qubit -> !qco.qubit
    %279 = qco.r(%cst_2, %cst_1) %278 : !qco.qubit -> !qco.qubit
    %controls_out_85, %targets_out_86 = qco.ctrl(%276) targets (%arg0 = %279) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %280 = qco.r(%cst_0, %cst_0) %targets_out_86 : !qco.qubit -> !qco.qubit
    %281 = qco.r(%cst, %cst_1) %280 : !qco.qubit -> !qco.qubit
    %282 = qco.r(%cst_2, %cst_1) %44 : !qco.qubit -> !qco.qubit
    %283 = qco.r(%cst_0, %cst_0) %282 : !qco.qubit -> !qco.qubit
    %284 = qco.r(%cst_2, %cst_1) %283 : !qco.qubit -> !qco.qubit
    %controls_out_87, %targets_out_88 = qco.ctrl(%281) targets (%arg0 = %284) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %285 = qco.r(%cst_0, %cst_0) %targets_out_88 : !qco.qubit -> !qco.qubit
    %286 = qco.r(%cst, %cst_1) %285 : !qco.qubit -> !qco.qubit
    %287 = qco.r(%cst_2, %cst_1) %45 : !qco.qubit -> !qco.qubit
    %288 = qco.r(%cst_0, %cst_0) %287 : !qco.qubit -> !qco.qubit
    %289 = qco.r(%cst_2, %cst_1) %288 : !qco.qubit -> !qco.qubit
    %controls_out_89, %targets_out_90 = qco.ctrl(%286) targets (%arg0 = %289) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %290 = qco.r(%cst_0, %cst_0) %targets_out_90 : !qco.qubit -> !qco.qubit
    %291 = qco.r(%cst, %cst_1) %290 : !qco.qubit -> !qco.qubit
    %292 = qco.r(%cst_2, %cst_1) %46 : !qco.qubit -> !qco.qubit
    %293 = qco.r(%cst_0, %cst_0) %292 : !qco.qubit -> !qco.qubit
    %294 = qco.r(%cst_2, %cst_1) %293 : !qco.qubit -> !qco.qubit
    %controls_out_91, %targets_out_92 = qco.ctrl(%291) targets (%arg0 = %294) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %295 = qco.r(%cst_0, %cst_0) %targets_out_92 : !qco.qubit -> !qco.qubit
    %296 = qco.r(%cst, %cst_1) %295 : !qco.qubit -> !qco.qubit
    %297 = qco.r(%cst_2, %cst_1) %47 : !qco.qubit -> !qco.qubit
    %298 = qco.r(%cst_0, %cst_0) %297 : !qco.qubit -> !qco.qubit
    %299 = qco.r(%cst_2, %cst_1) %298 : !qco.qubit -> !qco.qubit
    %controls_out_93, %targets_out_94 = qco.ctrl(%296) targets (%arg0 = %299) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %300 = qco.r(%cst_0, %cst_0) %targets_out_94 : !qco.qubit -> !qco.qubit
    %301 = qco.r(%cst, %cst_1) %300 : !qco.qubit -> !qco.qubit
    %302 = qco.r(%cst_2, %cst_1) %48 : !qco.qubit -> !qco.qubit
    %303 = qco.r(%cst_0, %cst_0) %302 : !qco.qubit -> !qco.qubit
    %304 = qco.r(%cst_2, %cst_1) %303 : !qco.qubit -> !qco.qubit
    %controls_out_95, %targets_out_96 = qco.ctrl(%301) targets (%arg0 = %304) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %305 = qco.r(%cst_0, %cst_0) %targets_out_96 : !qco.qubit -> !qco.qubit
    %306 = qco.r(%cst, %cst_1) %305 : !qco.qubit -> !qco.qubit
    %307 = qco.r(%cst_2, %cst_1) %49 : !qco.qubit -> !qco.qubit
    %308 = qco.r(%cst_0, %cst_0) %307 : !qco.qubit -> !qco.qubit
    %309 = qco.r(%cst_2, %cst_1) %308 : !qco.qubit -> !qco.qubit
    %controls_out_97, %targets_out_98 = qco.ctrl(%306) targets (%arg0 = %309) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %310 = qco.r(%cst_0, %cst_0) %targets_out_98 : !qco.qubit -> !qco.qubit
    %311 = qco.r(%cst, %cst_1) %310 : !qco.qubit -> !qco.qubit
    %312 = qco.r(%cst_2, %cst_1) %50 : !qco.qubit -> !qco.qubit
    %313 = qco.r(%cst_0, %cst_0) %312 : !qco.qubit -> !qco.qubit
    %314 = qco.r(%cst_2, %cst_1) %313 : !qco.qubit -> !qco.qubit
    %controls_out_99, %targets_out_100 = qco.ctrl(%311) targets (%arg0 = %314) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %315 = qco.r(%cst_0, %cst_0) %targets_out_100 : !qco.qubit -> !qco.qubit
    %316 = qco.r(%cst, %cst_1) %315 : !qco.qubit -> !qco.qubit
    %317 = qco.r(%cst_2, %cst_1) %51 : !qco.qubit -> !qco.qubit
    %318 = qco.r(%cst_0, %cst_0) %317 : !qco.qubit -> !qco.qubit
    %319 = qco.r(%cst_2, %cst_1) %318 : !qco.qubit -> !qco.qubit
    %controls_out_101, %targets_out_102 = qco.ctrl(%316) targets (%arg0 = %319) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %320 = qco.r(%cst_0, %cst_0) %targets_out_102 : !qco.qubit -> !qco.qubit
    %321 = qco.r(%cst, %cst_1) %320 : !qco.qubit -> !qco.qubit
    %322 = qco.r(%cst_2, %cst_1) %52 : !qco.qubit -> !qco.qubit
    %323 = qco.r(%cst_0, %cst_0) %322 : !qco.qubit -> !qco.qubit
    %324 = qco.r(%cst_2, %cst_1) %323 : !qco.qubit -> !qco.qubit
    %controls_out_103, %targets_out_104 = qco.ctrl(%321) targets (%arg0 = %324) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %325 = qco.r(%cst_0, %cst_0) %targets_out_104 : !qco.qubit -> !qco.qubit
    %326 = qco.r(%cst, %cst_1) %325 : !qco.qubit -> !qco.qubit
    %327 = qco.r(%cst_2, %cst_1) %53 : !qco.qubit -> !qco.qubit
    %328 = qco.r(%cst_0, %cst_0) %327 : !qco.qubit -> !qco.qubit
    %329 = qco.r(%cst_2, %cst_1) %328 : !qco.qubit -> !qco.qubit
    %controls_out_105, %targets_out_106 = qco.ctrl(%326) targets (%arg0 = %329) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %330 = qco.r(%cst_0, %cst_0) %targets_out_106 : !qco.qubit -> !qco.qubit
    %331 = qco.r(%cst, %cst_1) %330 : !qco.qubit -> !qco.qubit
    %332 = qco.r(%cst_2, %cst_1) %54 : !qco.qubit -> !qco.qubit
    %333 = qco.r(%cst_0, %cst_0) %332 : !qco.qubit -> !qco.qubit
    %334 = qco.r(%cst_2, %cst_1) %333 : !qco.qubit -> !qco.qubit
    %controls_out_107, %targets_out_108 = qco.ctrl(%331) targets (%arg0 = %334) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %335 = qco.r(%cst_0, %cst_0) %targets_out_108 : !qco.qubit -> !qco.qubit
    %336 = qco.r(%cst, %cst_1) %335 : !qco.qubit -> !qco.qubit
    %337 = qco.r(%cst_2, %cst_1) %55 : !qco.qubit -> !qco.qubit
    %338 = qco.r(%cst_0, %cst_0) %337 : !qco.qubit -> !qco.qubit
    %339 = qco.r(%cst_2, %cst_1) %338 : !qco.qubit -> !qco.qubit
    %controls_out_109, %targets_out_110 = qco.ctrl(%336) targets (%arg0 = %339) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %340 = qco.r(%cst_0, %cst_0) %targets_out_110 : !qco.qubit -> !qco.qubit
    %341 = qco.r(%cst, %cst_1) %340 : !qco.qubit -> !qco.qubit
    %342 = qco.r(%cst_2, %cst_1) %56 : !qco.qubit -> !qco.qubit
    %343 = qco.r(%cst_0, %cst_0) %342 : !qco.qubit -> !qco.qubit
    %344 = qco.r(%cst_2, %cst_1) %343 : !qco.qubit -> !qco.qubit
    %controls_out_111, %targets_out_112 = qco.ctrl(%341) targets (%arg0 = %344) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %345 = qco.r(%cst_0, %cst_0) %targets_out_112 : !qco.qubit -> !qco.qubit
    %346 = qco.r(%cst, %cst_1) %345 : !qco.qubit -> !qco.qubit
    %347 = qco.r(%cst_2, %cst_1) %57 : !qco.qubit -> !qco.qubit
    %348 = qco.r(%cst_0, %cst_0) %347 : !qco.qubit -> !qco.qubit
    %349 = qco.r(%cst_2, %cst_1) %348 : !qco.qubit -> !qco.qubit
    %controls_out_113, %targets_out_114 = qco.ctrl(%346) targets (%arg0 = %349) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %350 = qco.r(%cst_0, %cst_0) %targets_out_114 : !qco.qubit -> !qco.qubit
    %351 = qco.r(%cst, %cst_1) %350 : !qco.qubit -> !qco.qubit
    %352 = qco.r(%cst_2, %cst_1) %58 : !qco.qubit -> !qco.qubit
    %353 = qco.r(%cst_0, %cst_0) %352 : !qco.qubit -> !qco.qubit
    %354 = qco.r(%cst_2, %cst_1) %353 : !qco.qubit -> !qco.qubit
    %controls_out_115, %targets_out_116 = qco.ctrl(%351) targets (%arg0 = %354) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %355 = qco.r(%cst_0, %cst_0) %targets_out_116 : !qco.qubit -> !qco.qubit
    %356 = qco.r(%cst, %cst_1) %355 : !qco.qubit -> !qco.qubit
    %357 = qco.r(%cst_2, %cst_1) %59 : !qco.qubit -> !qco.qubit
    %358 = qco.r(%cst_0, %cst_0) %357 : !qco.qubit -> !qco.qubit
    %359 = qco.r(%cst_2, %cst_1) %358 : !qco.qubit -> !qco.qubit
    %controls_out_117, %targets_out_118 = qco.ctrl(%356) targets (%arg0 = %359) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %360 = qco.r(%cst_0, %cst_0) %targets_out_118 : !qco.qubit -> !qco.qubit
    %361 = qco.r(%cst, %cst_1) %360 : !qco.qubit -> !qco.qubit
    %362 = qco.r(%cst_2, %cst_1) %60 : !qco.qubit -> !qco.qubit
    %363 = qco.r(%cst_0, %cst_0) %362 : !qco.qubit -> !qco.qubit
    %364 = qco.r(%cst_2, %cst_1) %363 : !qco.qubit -> !qco.qubit
    %controls_out_119, %targets_out_120 = qco.ctrl(%361) targets (%arg0 = %364) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %365 = qco.r(%cst_0, %cst_0) %targets_out_120 : !qco.qubit -> !qco.qubit
    %366 = qco.r(%cst, %cst_1) %365 : !qco.qubit -> !qco.qubit
    %367 = qco.r(%cst_2, %cst_1) %61 : !qco.qubit -> !qco.qubit
    %368 = qco.r(%cst_0, %cst_0) %367 : !qco.qubit -> !qco.qubit
    %369 = qco.r(%cst_2, %cst_1) %368 : !qco.qubit -> !qco.qubit
    %controls_out_121, %targets_out_122 = qco.ctrl(%366) targets (%arg0 = %369) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %370 = qco.r(%cst_0, %cst_0) %targets_out_122 : !qco.qubit -> !qco.qubit
    %371 = qco.r(%cst, %cst_1) %370 : !qco.qubit -> !qco.qubit
    %372 = qco.r(%cst_2, %cst_1) %62 : !qco.qubit -> !qco.qubit
    %373 = qco.r(%cst_0, %cst_0) %372 : !qco.qubit -> !qco.qubit
    %374 = qco.r(%cst_2, %cst_1) %373 : !qco.qubit -> !qco.qubit
    %controls_out_123, %targets_out_124 = qco.ctrl(%371) targets (%arg0 = %374) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %375 = qco.r(%cst_0, %cst_0) %targets_out_124 : !qco.qubit -> !qco.qubit
    %376 = qco.r(%cst, %cst_1) %375 : !qco.qubit -> !qco.qubit
    %377 = qco.r(%cst_2, %cst_1) %63 : !qco.qubit -> !qco.qubit
    %378 = qco.r(%cst_0, %cst_0) %377 : !qco.qubit -> !qco.qubit
    %379 = qco.r(%cst_2, %cst_1) %378 : !qco.qubit -> !qco.qubit
    %controls_out_125, %targets_out_126 = qco.ctrl(%376) targets (%arg0 = %379) {
      %382 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %382 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %380 = qco.r(%cst_0, %cst_0) %targets_out_126 : !qco.qubit -> !qco.qubit
    %381 = qco.r(%cst, %cst_1) %380 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %controls_out : !qco.qubit
    cbit.store %result, %64[%c0] : !cbit.reg<64>
    %qubit_out_127, %result_128 = qco.measure %controls_out_3 : !qco.qubit
    cbit.store %result_128, %64[%c1] : !cbit.reg<64>
    %qubit_out_129, %result_130 = qco.measure %controls_out_5 : !qco.qubit
    cbit.store %result_130, %64[%c2] : !cbit.reg<64>
    %qubit_out_131, %result_132 = qco.measure %controls_out_7 : !qco.qubit
    cbit.store %result_132, %64[%c3] : !cbit.reg<64>
    %qubit_out_133, %result_134 = qco.measure %controls_out_9 : !qco.qubit
    cbit.store %result_134, %64[%c4] : !cbit.reg<64>
    %qubit_out_135, %result_136 = qco.measure %controls_out_11 : !qco.qubit
    cbit.store %result_136, %64[%c5] : !cbit.reg<64>
    %qubit_out_137, %result_138 = qco.measure %controls_out_13 : !qco.qubit
    cbit.store %result_138, %64[%c6] : !cbit.reg<64>
    %qubit_out_139, %result_140 = qco.measure %controls_out_15 : !qco.qubit
    cbit.store %result_140, %64[%c7] : !cbit.reg<64>
    %qubit_out_141, %result_142 = qco.measure %controls_out_17 : !qco.qubit
    cbit.store %result_142, %64[%c8] : !cbit.reg<64>
    %qubit_out_143, %result_144 = qco.measure %controls_out_19 : !qco.qubit
    cbit.store %result_144, %64[%c9] : !cbit.reg<64>
    %qubit_out_145, %result_146 = qco.measure %controls_out_21 : !qco.qubit
    cbit.store %result_146, %64[%c10] : !cbit.reg<64>
    %qubit_out_147, %result_148 = qco.measure %controls_out_23 : !qco.qubit
    cbit.store %result_148, %64[%c11] : !cbit.reg<64>
    %qubit_out_149, %result_150 = qco.measure %controls_out_25 : !qco.qubit
    cbit.store %result_150, %64[%c12] : !cbit.reg<64>
    %qubit_out_151, %result_152 = qco.measure %controls_out_27 : !qco.qubit
    cbit.store %result_152, %64[%c13] : !cbit.reg<64>
    %qubit_out_153, %result_154 = qco.measure %controls_out_29 : !qco.qubit
    cbit.store %result_154, %64[%c14] : !cbit.reg<64>
    %qubit_out_155, %result_156 = qco.measure %controls_out_31 : !qco.qubit
    cbit.store %result_156, %64[%c15] : !cbit.reg<64>
    %qubit_out_157, %result_158 = qco.measure %controls_out_33 : !qco.qubit
    cbit.store %result_158, %64[%c16] : !cbit.reg<64>
    %qubit_out_159, %result_160 = qco.measure %controls_out_35 : !qco.qubit
    cbit.store %result_160, %64[%c17] : !cbit.reg<64>
    %qubit_out_161, %result_162 = qco.measure %controls_out_37 : !qco.qubit
    cbit.store %result_162, %64[%c18] : !cbit.reg<64>
    %qubit_out_163, %result_164 = qco.measure %controls_out_39 : !qco.qubit
    cbit.store %result_164, %64[%c19] : !cbit.reg<64>
    %qubit_out_165, %result_166 = qco.measure %controls_out_41 : !qco.qubit
    cbit.store %result_166, %64[%c20] : !cbit.reg<64>
    %qubit_out_167, %result_168 = qco.measure %controls_out_43 : !qco.qubit
    cbit.store %result_168, %64[%c21] : !cbit.reg<64>
    %qubit_out_169, %result_170 = qco.measure %controls_out_45 : !qco.qubit
    cbit.store %result_170, %64[%c22] : !cbit.reg<64>
    %qubit_out_171, %result_172 = qco.measure %controls_out_47 : !qco.qubit
    cbit.store %result_172, %64[%c23] : !cbit.reg<64>
    %qubit_out_173, %result_174 = qco.measure %controls_out_49 : !qco.qubit
    cbit.store %result_174, %64[%c24] : !cbit.reg<64>
    %qubit_out_175, %result_176 = qco.measure %controls_out_51 : !qco.qubit
    cbit.store %result_176, %64[%c25] : !cbit.reg<64>
    %qubit_out_177, %result_178 = qco.measure %controls_out_53 : !qco.qubit
    cbit.store %result_178, %64[%c26] : !cbit.reg<64>
    %qubit_out_179, %result_180 = qco.measure %controls_out_55 : !qco.qubit
    cbit.store %result_180, %64[%c27] : !cbit.reg<64>
    %qubit_out_181, %result_182 = qco.measure %controls_out_57 : !qco.qubit
    cbit.store %result_182, %64[%c28] : !cbit.reg<64>
    %qubit_out_183, %result_184 = qco.measure %controls_out_59 : !qco.qubit
    cbit.store %result_184, %64[%c29] : !cbit.reg<64>
    %qubit_out_185, %result_186 = qco.measure %controls_out_61 : !qco.qubit
    cbit.store %result_186, %64[%c30] : !cbit.reg<64>
    %qubit_out_187, %result_188 = qco.measure %controls_out_63 : !qco.qubit
    cbit.store %result_188, %64[%c31] : !cbit.reg<64>
    %qubit_out_189, %result_190 = qco.measure %controls_out_65 : !qco.qubit
    cbit.store %result_190, %64[%c32] : !cbit.reg<64>
    %qubit_out_191, %result_192 = qco.measure %controls_out_67 : !qco.qubit
    cbit.store %result_192, %64[%c33] : !cbit.reg<64>
    %qubit_out_193, %result_194 = qco.measure %controls_out_69 : !qco.qubit
    cbit.store %result_194, %64[%c34] : !cbit.reg<64>
    %qubit_out_195, %result_196 = qco.measure %controls_out_71 : !qco.qubit
    cbit.store %result_196, %64[%c35] : !cbit.reg<64>
    %qubit_out_197, %result_198 = qco.measure %controls_out_73 : !qco.qubit
    cbit.store %result_198, %64[%c36] : !cbit.reg<64>
    %qubit_out_199, %result_200 = qco.measure %controls_out_75 : !qco.qubit
    cbit.store %result_200, %64[%c37] : !cbit.reg<64>
    %qubit_out_201, %result_202 = qco.measure %controls_out_77 : !qco.qubit
    cbit.store %result_202, %64[%c38] : !cbit.reg<64>
    %qubit_out_203, %result_204 = qco.measure %controls_out_79 : !qco.qubit
    cbit.store %result_204, %64[%c39] : !cbit.reg<64>
    %qubit_out_205, %result_206 = qco.measure %controls_out_81 : !qco.qubit
    cbit.store %result_206, %64[%c40] : !cbit.reg<64>
    %qubit_out_207, %result_208 = qco.measure %controls_out_83 : !qco.qubit
    cbit.store %result_208, %64[%c41] : !cbit.reg<64>
    %qubit_out_209, %result_210 = qco.measure %controls_out_85 : !qco.qubit
    cbit.store %result_210, %64[%c42] : !cbit.reg<64>
    %qubit_out_211, %result_212 = qco.measure %controls_out_87 : !qco.qubit
    cbit.store %result_212, %64[%c43] : !cbit.reg<64>
    %qubit_out_213, %result_214 = qco.measure %controls_out_89 : !qco.qubit
    cbit.store %result_214, %64[%c44] : !cbit.reg<64>
    %qubit_out_215, %result_216 = qco.measure %controls_out_91 : !qco.qubit
    cbit.store %result_216, %64[%c45] : !cbit.reg<64>
    %qubit_out_217, %result_218 = qco.measure %controls_out_93 : !qco.qubit
    cbit.store %result_218, %64[%c46] : !cbit.reg<64>
    %qubit_out_219, %result_220 = qco.measure %controls_out_95 : !qco.qubit
    cbit.store %result_220, %64[%c47] : !cbit.reg<64>
    %qubit_out_221, %result_222 = qco.measure %controls_out_97 : !qco.qubit
    cbit.store %result_222, %64[%c48] : !cbit.reg<64>
    %qubit_out_223, %result_224 = qco.measure %controls_out_99 : !qco.qubit
    cbit.store %result_224, %64[%c49] : !cbit.reg<64>
    %qubit_out_225, %result_226 = qco.measure %controls_out_101 : !qco.qubit
    cbit.store %result_226, %64[%c50] : !cbit.reg<64>
    %qubit_out_227, %result_228 = qco.measure %controls_out_103 : !qco.qubit
    cbit.store %result_228, %64[%c51] : !cbit.reg<64>
    %qubit_out_229, %result_230 = qco.measure %controls_out_105 : !qco.qubit
    cbit.store %result_230, %64[%c52] : !cbit.reg<64>
    %qubit_out_231, %result_232 = qco.measure %controls_out_107 : !qco.qubit
    cbit.store %result_232, %64[%c53] : !cbit.reg<64>
    %qubit_out_233, %result_234 = qco.measure %controls_out_109 : !qco.qubit
    cbit.store %result_234, %64[%c54] : !cbit.reg<64>
    %qubit_out_235, %result_236 = qco.measure %controls_out_111 : !qco.qubit
    cbit.store %result_236, %64[%c55] : !cbit.reg<64>
    %qubit_out_237, %result_238 = qco.measure %controls_out_113 : !qco.qubit
    cbit.store %result_238, %64[%c56] : !cbit.reg<64>
    %qubit_out_239, %result_240 = qco.measure %controls_out_115 : !qco.qubit
    cbit.store %result_240, %64[%c57] : !cbit.reg<64>
    %qubit_out_241, %result_242 = qco.measure %controls_out_117 : !qco.qubit
    cbit.store %result_242, %64[%c58] : !cbit.reg<64>
    %qubit_out_243, %result_244 = qco.measure %controls_out_119 : !qco.qubit
    cbit.store %result_244, %64[%c59] : !cbit.reg<64>
    %qubit_out_245, %result_246 = qco.measure %controls_out_121 : !qco.qubit
    cbit.store %result_246, %64[%c60] : !cbit.reg<64>
    %qubit_out_247, %result_248 = qco.measure %controls_out_123 : !qco.qubit
    cbit.store %result_248, %64[%c61] : !cbit.reg<64>
    %qubit_out_249, %result_250 = qco.measure %controls_out_125 : !qco.qubit
    cbit.store %result_250, %64[%c62] : !cbit.reg<64>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_127 : !qco.qubit
    qco.sink %qubit_out_129 : !qco.qubit
    qco.sink %qubit_out_131 : !qco.qubit
    qco.sink %qubit_out_133 : !qco.qubit
    qco.sink %qubit_out_135 : !qco.qubit
    qco.sink %qubit_out_137 : !qco.qubit
    qco.sink %qubit_out_139 : !qco.qubit
    qco.sink %qubit_out_141 : !qco.qubit
    qco.sink %qubit_out_143 : !qco.qubit
    qco.sink %qubit_out_145 : !qco.qubit
    qco.sink %qubit_out_147 : !qco.qubit
    qco.sink %qubit_out_149 : !qco.qubit
    qco.sink %qubit_out_151 : !qco.qubit
    qco.sink %qubit_out_153 : !qco.qubit
    qco.sink %qubit_out_155 : !qco.qubit
    qco.sink %qubit_out_157 : !qco.qubit
    qco.sink %qubit_out_159 : !qco.qubit
    qco.sink %qubit_out_161 : !qco.qubit
    qco.sink %qubit_out_163 : !qco.qubit
    qco.sink %qubit_out_165 : !qco.qubit
    qco.sink %qubit_out_167 : !qco.qubit
    qco.sink %qubit_out_169 : !qco.qubit
    qco.sink %qubit_out_171 : !qco.qubit
    qco.sink %qubit_out_173 : !qco.qubit
    qco.sink %qubit_out_175 : !qco.qubit
    qco.sink %qubit_out_177 : !qco.qubit
    qco.sink %qubit_out_179 : !qco.qubit
    qco.sink %qubit_out_181 : !qco.qubit
    qco.sink %qubit_out_183 : !qco.qubit
    qco.sink %qubit_out_185 : !qco.qubit
    qco.sink %qubit_out_187 : !qco.qubit
    qco.sink %qubit_out_189 : !qco.qubit
    qco.sink %qubit_out_191 : !qco.qubit
    qco.sink %qubit_out_193 : !qco.qubit
    qco.sink %qubit_out_195 : !qco.qubit
    qco.sink %qubit_out_197 : !qco.qubit
    qco.sink %qubit_out_199 : !qco.qubit
    qco.sink %qubit_out_201 : !qco.qubit
    qco.sink %qubit_out_203 : !qco.qubit
    qco.sink %qubit_out_205 : !qco.qubit
    qco.sink %qubit_out_207 : !qco.qubit
    qco.sink %qubit_out_209 : !qco.qubit
    qco.sink %qubit_out_211 : !qco.qubit
    qco.sink %qubit_out_213 : !qco.qubit
    qco.sink %qubit_out_215 : !qco.qubit
    qco.sink %qubit_out_217 : !qco.qubit
    qco.sink %qubit_out_219 : !qco.qubit
    qco.sink %qubit_out_221 : !qco.qubit
    qco.sink %qubit_out_223 : !qco.qubit
    qco.sink %qubit_out_225 : !qco.qubit
    qco.sink %qubit_out_227 : !qco.qubit
    qco.sink %qubit_out_229 : !qco.qubit
    qco.sink %qubit_out_231 : !qco.qubit
    qco.sink %qubit_out_233 : !qco.qubit
    qco.sink %qubit_out_235 : !qco.qubit
    qco.sink %qubit_out_237 : !qco.qubit
    qco.sink %qubit_out_239 : !qco.qubit
    qco.sink %qubit_out_241 : !qco.qubit
    qco.sink %qubit_out_243 : !qco.qubit
    qco.sink %qubit_out_245 : !qco.qubit
    qco.sink %qubit_out_247 : !qco.qubit
    qco.sink %qubit_out_249 : !qco.qubit
    %qubit_out_251, %result_252 = qco.measure %381 : !qco.qubit
    qco.sink %qubit_out_251 : !qco.qubit
    cbit.store %result_252, %64[%c63] : !cbit.reg<64>
    qco.gphase(%cst_0)
    return %64 : !cbit.reg<64>
  }
}
