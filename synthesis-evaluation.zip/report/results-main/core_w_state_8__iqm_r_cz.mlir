module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant 1.5707963267948948 : f64
    %cst_0 = arith.constant 5.9218181832728796 : f64
    %cst_1 = arith.constant 3.1415926535897918 : f64
    %cst_2 = arith.constant 3.0653948796912953 : f64
    %cst_3 = arith.constant 2.7802255296830851 : f64
    %cst_4 = arith.constant 1.5707963267948981 : f64
    %cst_5 = arith.constant 4.7123889803846923 : f64
    %cst_6 = arith.constant -1.5707963267948966 : f64
    %cst_7 = arith.constant 4.7123889803846861 : f64
    %cst_8 = arith.constant 5.8955886205244061 : f64
    %cst_9 = arith.constant 2.7539959669346126 : f64
    %cst_10 = arith.constant 1.5707963267948939 : f64
    %cst_11 = arith.constant 1.5707963267948972 : f64
    %cst_12 = arith.constant 1.5707963267948979 : f64
    %cst_13 = arith.constant 4.7123889803846888 : f64
    %cst_14 = arith.constant 5.8626509718956221 : f64
    %cst_15 = arith.constant 2.7210583183058281 : f64
    %cst_16 = arith.constant 7.8539816339744836 : f64
    %cst_17 = arith.constant 6.2831853071795862 : f64
    %cst_18 = arith.constant 4.7123889803846915 : f64
    %cst_19 = arith.constant 5.819537698178781 : f64
    %cst_20 = arith.constant 2.6779450445889865 : f64
    %cst_21 = arith.constant 1.5707963267948959 : f64
    %cst_22 = arith.constant 7.8539816339744846 : f64
    %cst_23 = arith.constant 5.759586531581288 : f64
    %cst_24 = arith.constant 2.6179938779914944 : f64
    %cst_25 = arith.constant 1.5707963267948961 : f64
    %cst_26 = arith.constant 5.6677055985091993 : f64
    %cst_27 = arith.constant 0.61547970867038737 : f64
    %cst_28 = arith.constant 3.1415926535897931 : f64
    %cst_29 = arith.constant 1.5707963267948954 : f64
    %cst_30 = arith.constant 7.8539816339744828 : f64
    %cst_31 = arith.constant 1.570796326794897 : f64
    %cst_32 = arith.constant 7.8539816339744819 : f64
    %cst_33 = arith.constant 1.5707963267948968 : f64
    %cst_34 = arith.constant 4.7123889803846897 : f64
    %cst_35 = arith.constant 1.5707963267948963 : f64
    %cst_36 = arith.constant 5.4977871437821388 : f64
    %cst_37 = arith.constant 3.9269908169872423 : f64
    %cst_38 = arith.constant 1.5707963267948966 : f64
    %cst_39 = arith.constant 1.5707963267948974 : f64
    %cst_40 = arith.constant 0.000000e+00 : f64
    %cst_41 = arith.constant -1.5707963267948957 : f64
    %cst_42 = arith.constant 9.4247779607693793 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %9 = qco.r(%cst_42, %cst_40) %0 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_30, %cst_40) %1 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_4, %cst_38) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_3, %cst_40) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_2, %cst_40) %9 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_1, %cst_38) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_2, %cst_40) %14 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%15) targets (%arg0 = %12) {
      %106 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %106 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.r(%cst_0, %cst_40) %targets_out : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_38, %cst_38) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_34, %cst_40) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst_38, %cst_38) %controls_out : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_33, %cst_40) %19 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%20) targets (%arg0 = %18) {
      %106 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %106 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.r(%cst_7, %cst_40) %targets_out_44 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_38, %cst_38) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_13, %cst_40) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst, %cst_40) %controls_out_43 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_31, %cst_38) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_22, %cst_40) %2 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst_10, %cst_38) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_9, %cst_40) %27 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%23) targets (%arg0 = %28) {
      %106 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %106 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.r(%cst_8, %cst_40) %targets_out_46 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_38, %cst_38) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%cst_34, %cst_40) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_38, %cst_38) %controls_out_45 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_33, %cst_40) %32 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%33) targets (%arg0 = %31) {
      %106 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %106 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.r(%cst_7, %cst_40) %targets_out_48 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst_35, %cst_38) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_6, %cst_40) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%cst_5, %cst_40) %controls_out_47 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst_21, %cst_38) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst_16, %cst_40) %3 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_21, %cst_38) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst_15, %cst_40) %40 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%36) targets (%arg0 = %41) {
      %106 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %106 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qco.r(%cst_14, %cst_40) %targets_out_50 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%cst_35, %cst_38) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_34, %cst_40) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst_38, %cst_38) %controls_out_49 : !qco.qubit -> !qco.qubit
    %46 = qco.r(%cst_33, %cst_40) %45 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%46) targets (%arg0 = %44) {
      %106 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %106 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.r(%cst_13, %cst_40) %targets_out_52 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst_12, %cst_38) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.r(%cst_34, %cst_40) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.r(%cst_11, %cst_40) %controls_out_51 : !qco.qubit -> !qco.qubit
    %51 = qco.r(%cst_35, %cst_38) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.r(%cst_22, %cst_40) %4 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst_21, %cst_38) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.r(%cst_20, %cst_40) %53 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%49) targets (%arg0 = %54) {
      %106 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %106 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.r(%cst_19, %cst_40) %targets_out_54 : !qco.qubit -> !qco.qubit
    %56 = qco.r(%cst_35, %cst_38) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.r(%cst_34, %cst_40) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.r(%cst_38, %cst_38) %controls_out_53 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%cst_33, %cst_40) %58 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%59) targets (%arg0 = %57) {
      %106 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %106 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qco.r(%cst_34, %cst_40) %targets_out_56 : !qco.qubit -> !qco.qubit
    %61 = qco.r(%cst_38, %cst_38) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.r(%cst_34, %cst_40) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%cst_18, %cst_40) %controls_out_55 : !qco.qubit -> !qco.qubit
    %64 = qco.r(%cst_38, %cst_38) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%cst_17, %cst_40) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.r(%cst_30, %cst_40) %5 : !qco.qubit -> !qco.qubit
    %67 = qco.r(%cst_25, %cst_38) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.r(%cst_24, %cst_40) %67 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%62) targets (%arg0 = %68) {
      %106 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %106 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qco.r(%cst_23, %cst_40) %targets_out_58 : !qco.qubit -> !qco.qubit
    %70 = qco.r(%cst_35, %cst_38) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.r(%cst_34, %cst_40) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%cst_38, %cst_38) %controls_out_57 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%cst_33, %cst_40) %72 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%73) targets (%arg0 = %71) {
      %106 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %106 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %74 = qco.r(%cst_41, %cst_40) %targets_out_60 : !qco.qubit -> !qco.qubit
    %75 = qco.r(%cst_38, %cst_38) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.r(%cst_33, %cst_40) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.r(%cst_39, %cst_40) %controls_out_59 : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst_31, %cst_38) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.r(%cst_34, %cst_40) %6 : !qco.qubit -> !qco.qubit
    %80 = qco.r(%cst_38, %cst_38) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%cst_27, %cst_40) %80 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%76) targets (%arg0 = %81) {
      %106 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %106 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %82 = qco.r(%cst_26, %cst_40) %targets_out_62 : !qco.qubit -> !qco.qubit
    %83 = qco.r(%cst_25, %cst_38) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.r(%cst_34, %cst_40) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.r(%cst_38, %cst_38) %controls_out_61 : !qco.qubit -> !qco.qubit
    %86 = qco.r(%cst_33, %cst_40) %85 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%86) targets (%arg0 = %84) {
      %106 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %106 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %87 = qco.r(%cst_34, %cst_40) %targets_out_64 : !qco.qubit -> !qco.qubit
    %88 = qco.r(%cst_31, %cst_38) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%cst_34, %cst_40) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.r(%cst_34, %cst_40) %controls_out_63 : !qco.qubit -> !qco.qubit
    %91 = qco.r(%cst_31, %cst_38) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.r(%cst_41, %cst_40) %7 : !qco.qubit -> !qco.qubit
    %93 = qco.r(%cst_39, %cst_38) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.r(%cst_37, %cst_40) %93 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%89) targets (%arg0 = %94) {
      %106 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %106 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %95 = qco.r(%cst_36, %cst_40) %targets_out_66 : !qco.qubit -> !qco.qubit
    %96 = qco.r(%cst_35, %cst_38) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.r(%cst_34, %cst_40) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.r(%cst_38, %cst_38) %controls_out_65 : !qco.qubit -> !qco.qubit
    %99 = qco.r(%cst_33, %cst_40) %98 : !qco.qubit -> !qco.qubit
    %controls_out_67, %targets_out_68 = qco.ctrl(%99) targets (%arg0 = %97) {
      %106 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %106 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %100 = qco.r(%cst_32, %cst_40) %targets_out_68 : !qco.qubit -> !qco.qubit
    %101 = qco.r(%cst_31, %cst_38) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.r(%cst_34, %cst_40) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.r(%cst_30, %cst_40) %controls_out_67 : !qco.qubit -> !qco.qubit
    %104 = qco.r(%cst_29, %cst_38) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.r(%cst_28, %cst_40) %104 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %25 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<8>
    %qubit_out_69, %result_70 = qco.measure %38 : !qco.qubit
    cbit.store %result_70, %8[%c1] : !cbit.reg<8>
    %qubit_out_71, %result_72 = qco.measure %51 : !qco.qubit
    cbit.store %result_72, %8[%c2] : !cbit.reg<8>
    %qubit_out_73, %result_74 = qco.measure %65 : !qco.qubit
    cbit.store %result_74, %8[%c3] : !cbit.reg<8>
    %qubit_out_75, %result_76 = qco.measure %78 : !qco.qubit
    cbit.store %result_76, %8[%c4] : !cbit.reg<8>
    %qubit_out_77, %result_78 = qco.measure %91 : !qco.qubit
    cbit.store %result_78, %8[%c5] : !cbit.reg<8>
    %qubit_out_79, %result_80 = qco.measure %105 : !qco.qubit
    cbit.store %result_80, %8[%c6] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_69 : !qco.qubit
    qco.sink %qubit_out_71 : !qco.qubit
    qco.sink %qubit_out_73 : !qco.qubit
    qco.sink %qubit_out_75 : !qco.qubit
    qco.sink %qubit_out_77 : !qco.qubit
    qco.sink %qubit_out_79 : !qco.qubit
    %qubit_out_81, %result_82 = qco.measure %102 : !qco.qubit
    qco.sink %qubit_out_81 : !qco.qubit
    cbit.store %result_82, %8[%c7] : !cbit.reg<8>
    %cst_83 = arith.constant -2.3561944901923351 : f64
    qco.gphase(%cst_83)
    return %8 : !cbit.reg<8>
  }
}
