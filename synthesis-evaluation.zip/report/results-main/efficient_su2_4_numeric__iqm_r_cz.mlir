module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 6.2831853071795862 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant 0.000000e+00 : f64
    %cst_2 = arith.constant 3.1415926535897931 : f64
    %cst_3 = arith.constant 4.8087119912568941 : f64
    %cst_4 = arith.constant 1.44977267393813 : f64
    %cst_5 = arith.constant 1.5591318305710284 : f64
    %cst_6 = arith.constant 3.2302093688311735 : f64
    %cst_7 = arith.constant 1.6986720977538898 : f64
    %cst_8 = arith.constant 3.7501055426015197 : f64
    %cst_9 = arith.constant 5.8696518849336154 : f64
    %cst_10 = arith.constant 1.820051767593734 : f64
    %cst_11 = arith.constant 2.0829014617262271 : f64
    %cst_12 = arith.constant 0.11689127612371708 : f64
    %cst_13 = arith.constant 1.5771647970103775 : f64
    %cst_14 = arith.constant 4.6582087928325873 : f64
    %cst_15 = arith.constant 3.1108692464859335 : f64
    %cst_16 = arith.constant 1.3190883764492403 : f64
    %cst_17 = arith.constant 3.2643690464264026 : f64
    %cst_18 = arith.constant 3.6981620060338289 : f64
    %cst_19 = arith.constant 0.82457240684687938 : f64
    %cst_20 = arith.constant 5.5413323013658093 : f64
    %cst_21 = arith.constant -0.39771768401357388 : f64
    %cst_22 = arith.constant 2.4591916893430978 : f64
    %cst_23 = arith.constant 5.7870223457434378 : f64
    %cst_24 = arith.constant 5.0428554890852313 : f64
    %cst_25 = arith.constant 1.9175993291233908 : f64
    %cst_26 = arith.constant 1.6868711564979066 : f64
    %cst_27 = arith.constant 5.8491310163752033 : f64
    %cst_28 = arith.constant 0.49876066505598649 : f64
    %cst_29 = arith.constant 0.48567145721551075 : f64
    %cst_30 = arith.constant -0.60953117461851081 : f64
    %cst_31 = arith.constant 1.2689866040915032 : f64
    %cst_32 = arith.constant 4.3099063828921533 : f64
    %cst_33 = arith.constant 2.5307375220496198 : f64
    %cst_34 = arith.constant 2.3482048081167379 : f64
    %cst_35 = arith.constant 2.3570807723466052 : f64
    %cst_36 = arith.constant 0.42084654974763058 : f64
    %cst_37 = arith.constant 1.2607961702853132 : f64
    %cst_38 = arith.constant 5.3106323675362255 : f64
    %cst_39 = arith.constant 4.5073480698507602 : f64
    %cst_40 = arith.constant 1.7754289208606948 : f64
    %cst_41 = arith.constant 4.6701543820830596 : f64
    %cst_42 = arith.constant 2.2436021026750419 : f64
    %cst_43 = arith.constant 1.5044441014569709 : f64
    %cst_44 = arith.constant 4.6596053172534662 : f64
    %cst_45 = arith.constant 6.0462707169637477 : f64
    %cst_46 = arith.constant 0.78205640869975579 : f64
    %cst_47 = arith.constant 0.32802983354499116 : f64
    %cst_48 = arith.constant 6.5821465004517883 : f64
    %cst_49 = arith.constant 2.0775114041394653 : f64
    %cst_50 = arith.constant 0.56579915028612504 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.r(%cst_50, %cst_1) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.r(%cst_49, %cst_0) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.r(%cst_48, %cst_1) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.r(%cst_47, %cst_1) %1 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_46, %cst_0) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_45, %cst_1) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_44, %cst_1) %2 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_43, %cst_0) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_42, %cst_1) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_41, %cst_1) %3 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_40, %cst_0) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_39, %cst_1) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_2, %cst_1) %6 : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_0, %cst_0) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_2, %cst_1) %17 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%15) targets (%arg0 = %18) {
      %112 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %112 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.r(%cst_0, %cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst, %cst_1) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_2, %cst_1) %9 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_0, %cst_0) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_2, %cst_1) %22 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%20) targets (%arg0 = %23) {
      %112 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %112 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.r(%cst_0, %cst_0) %targets_out_52 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst, %cst_1) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_2, %cst_1) %12 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst_0, %cst_0) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_2, %cst_1) %27 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%25) targets (%arg0 = %28) {
      %112 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %112 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.r(%cst_0, %cst_0) %targets_out_54 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst, %cst_1) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%cst_2, %cst_1) %controls_out : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_0, %cst_0) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_2, %cst_1) %32 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%30) targets (%arg0 = %33) {
      %112 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %112 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.r(%cst_0, %cst_0) %targets_out_56 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst, %cst_1) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_38, %cst_1) %controls_out_51 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%cst_37, %cst_0) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst_36, %cst_1) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst_35, %cst_1) %controls_out_53 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_34, %cst_0) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst_33, %cst_1) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst_32, %cst_1) %controls_out_55 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%cst_31, %cst_0) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_30, %cst_1) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst_29, %cst_1) %35 : !qco.qubit -> !qco.qubit
    %46 = qco.r(%cst_28, %cst_0) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%cst_27, %cst_1) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst_2, %cst_1) %38 : !qco.qubit -> !qco.qubit
    %49 = qco.r(%cst_0, %cst_0) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.r(%cst_2, %cst_1) %49 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%47) targets (%arg0 = %50) {
      %112 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %112 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %51 = qco.r(%cst_0, %cst_0) %targets_out_58 : !qco.qubit -> !qco.qubit
    %52 = qco.r(%cst, %cst_1) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst_2, %cst_1) %41 : !qco.qubit -> !qco.qubit
    %54 = qco.r(%cst_0, %cst_0) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.r(%cst_2, %cst_1) %54 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%52) targets (%arg0 = %55) {
      %112 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %112 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qco.r(%cst_0, %cst_0) %targets_out_60 : !qco.qubit -> !qco.qubit
    %57 = qco.r(%cst, %cst_1) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.r(%cst_2, %cst_1) %44 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%cst_0, %cst_0) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.r(%cst_2, %cst_1) %59 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%57) targets (%arg0 = %60) {
      %112 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %112 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qco.r(%cst_0, %cst_0) %targets_out_62 : !qco.qubit -> !qco.qubit
    %62 = qco.r(%cst, %cst_1) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%cst_2, %cst_1) %controls_out_57 : !qco.qubit -> !qco.qubit
    %64 = qco.r(%cst_0, %cst_0) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%cst_2, %cst_1) %64 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%62) targets (%arg0 = %65) {
      %112 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %112 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = qco.r(%cst_0, %cst_0) %targets_out_64 : !qco.qubit -> !qco.qubit
    %67 = qco.r(%cst, %cst_1) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.r(%cst_26, %cst_1) %controls_out_59 : !qco.qubit -> !qco.qubit
    %69 = qco.r(%cst_25, %cst_0) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.r(%cst_24, %cst_1) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.r(%cst_23, %cst_1) %controls_out_61 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%cst_22, %cst_0) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%cst_21, %cst_1) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.r(%cst_20, %cst_1) %controls_out_63 : !qco.qubit -> !qco.qubit
    %75 = qco.r(%cst_19, %cst_0) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.r(%cst_18, %cst_1) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.r(%cst_17, %cst_1) %67 : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst_16, %cst_0) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.r(%cst_15, %cst_1) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.r(%cst_2, %cst_1) %70 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%cst_0, %cst_0) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.r(%cst_2, %cst_1) %81 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%79) targets (%arg0 = %82) {
      %112 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %112 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qco.r(%cst_0, %cst_0) %targets_out_66 : !qco.qubit -> !qco.qubit
    %84 = qco.r(%cst, %cst_1) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.r(%cst_2, %cst_1) %73 : !qco.qubit -> !qco.qubit
    %86 = qco.r(%cst_0, %cst_0) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.r(%cst_2, %cst_1) %86 : !qco.qubit -> !qco.qubit
    %controls_out_67, %targets_out_68 = qco.ctrl(%84) targets (%arg0 = %87) {
      %112 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %112 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %88 = qco.r(%cst_0, %cst_0) %targets_out_68 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%cst, %cst_1) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.r(%cst_2, %cst_1) %76 : !qco.qubit -> !qco.qubit
    %91 = qco.r(%cst_0, %cst_0) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.r(%cst_2, %cst_1) %91 : !qco.qubit -> !qco.qubit
    %controls_out_69, %targets_out_70 = qco.ctrl(%89) targets (%arg0 = %92) {
      %112 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %112 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %93 = qco.r(%cst_0, %cst_0) %targets_out_70 : !qco.qubit -> !qco.qubit
    %94 = qco.r(%cst, %cst_1) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.r(%cst_2, %cst_1) %controls_out_65 : !qco.qubit -> !qco.qubit
    %96 = qco.r(%cst_0, %cst_0) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.r(%cst_2, %cst_1) %96 : !qco.qubit -> !qco.qubit
    %controls_out_71, %targets_out_72 = qco.ctrl(%94) targets (%arg0 = %97) {
      %112 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %112 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %98 = qco.r(%cst_0, %cst_0) %targets_out_72 : !qco.qubit -> !qco.qubit
    %99 = qco.r(%cst, %cst_1) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.r(%cst_14, %cst_1) %controls_out_67 : !qco.qubit -> !qco.qubit
    %101 = qco.r(%cst_13, %cst_0) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.r(%cst_12, %cst_1) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.r(%cst_11, %cst_1) %controls_out_69 : !qco.qubit -> !qco.qubit
    %104 = qco.r(%cst_10, %cst_0) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.r(%cst_9, %cst_1) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.r(%cst_8, %cst_1) %controls_out_71 : !qco.qubit -> !qco.qubit
    %107 = qco.r(%cst_7, %cst_0) %106 : !qco.qubit -> !qco.qubit
    %108 = qco.r(%cst_6, %cst_1) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.r(%cst_5, %cst_1) %99 : !qco.qubit -> !qco.qubit
    %110 = qco.r(%cst_4, %cst_0) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.r(%cst_3, %cst_1) %110 : !qco.qubit -> !qco.qubit
    qco.sink %102 : !qco.qubit
    qco.sink %105 : !qco.qubit
    qco.sink %108 : !qco.qubit
    qco.sink %111 : !qco.qubit
    return %c0_i64 : i64
  }
}
