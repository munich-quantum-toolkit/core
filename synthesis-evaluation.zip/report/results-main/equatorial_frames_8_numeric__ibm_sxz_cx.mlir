module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 0.24667939965738062 : f64
    %cst_0 = arith.constant -0.98578727771328523 : f64
    %cst_1 = arith.constant 0.4774918463410831 : f64
    %cst_2 = arith.constant 0.48173504249419885 : f64
    %cst_3 = arith.constant -0.95412162920505039 : f64
    %cst_4 = arith.constant -1.0983357016036184 : f64
    %cst_5 = arith.constant -1.8086132076167962 : f64
    %cst_6 = arith.constant 1.9139475410141675 : f64
    %cst_7 = arith.constant -2.0102325781155383 : f64
    %cst_8 = arith.constant -0.29973868040629248 : f64
    %cst_9 = arith.constant -2.0951235486918134 : f64
    %cst_10 = arith.constant 2.610616864293493 : f64
    %cst_11 = arith.constant -2.5744762026170971 : f64
    %cst_12 = arith.constant -1.9139284620972945 : f64
    %cst_13 = arith.constant -2.4110733621470457 : f64
    %cst_14 = arith.constant -1.1497834158813742 : f64
    %cst_15 = arith.constant -2.0379654918994143 : f64
    %cst_16 = arith.constant 2.3065443684807652 : f64
    %cst_17 = arith.constant 0.6060978022503285 : f64
    %cst_18 = arith.constant 0.033948861207498959 : f64
    %cst_19 = arith.constant -2.4787565529638362 : f64
    %cst_20 = arith.constant -0.78683529818140907 : f64
    %cst_21 = arith.constant 0.50293570842829105 : f64
    %cst_22 = arith.constant -1.5707963267948966 : f64
    %cst_23 = arith.constant 1.5707963267948966 : f64
    %cst_24 = arith.constant 1.5707963267948968 : f64
    %cst_25 = arith.constant -1.5707963267948963 : f64
    %cst_26 = arith.constant 1.7707963267948967 : f64
    %cst_27 = arith.constant 1.7707963267948963 : f64
    %cst_28 = arith.constant 1.7707963267948965 : f64
    %cst_29 = arith.constant 3.4415926535897929 : f64
    %cst_30 = arith.constant 1.9515722152379686 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.rz(%cst_30) %0 : !qco.qubit -> !qco.qubit
    %9 = qco.sx %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_29) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.sx %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_28) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_25) %1 : !qco.qubit -> !qco.qubit
    %14 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_24) %14 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%12) targets (%arg0 = %15) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.rz(%cst_23) %targets_out : !qco.qubit -> !qco.qubit
    %17 = qco.sx %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_21) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.sx %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_29) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_28) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_25) %2 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_24) %24 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%22) targets (%arg0 = %25) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.rz(%cst_23) %targets_out_32 : !qco.qubit -> !qco.qubit
    %27 = qco.sx %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_20) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.sx %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_29) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_28) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_25) %3 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_24) %34 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%32) targets (%arg0 = %35) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qco.rz(%cst_23) %targets_out_34 : !qco.qubit -> !qco.qubit
    %37 = qco.sx %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_19) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_29) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.sx %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_28) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_25) %4 : !qco.qubit -> !qco.qubit
    %44 = qco.sx %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_24) %44 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%42) targets (%arg0 = %45) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qco.rz(%cst_23) %targets_out_36 : !qco.qubit -> !qco.qubit
    %47 = qco.sx %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_18) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.sx %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_29) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.sx %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_28) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_25) %5 : !qco.qubit -> !qco.qubit
    %54 = qco.sx %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_24) %54 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%52) targets (%arg0 = %55) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qco.rz(%cst_23) %targets_out_38 : !qco.qubit -> !qco.qubit
    %57 = qco.sx %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_17) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.sx %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_29) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.sx %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_28) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_25) %6 : !qco.qubit -> !qco.qubit
    %64 = qco.sx %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_24) %64 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%62) targets (%arg0 = %65) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = qco.rz(%cst_23) %targets_out_40 : !qco.qubit -> !qco.qubit
    %67 = qco.sx %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_16) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.sx %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_29) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.sx %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_27) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_25) %7 : !qco.qubit -> !qco.qubit
    %74 = qco.sx %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_24) %74 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%72) targets (%arg0 = %75) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %76 = qco.rz(%cst_23) %targets_out_42 : !qco.qubit -> !qco.qubit
    %77 = qco.sx %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_15) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.sx %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_29) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.sx %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_27) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_25) %controls_out : !qco.qubit -> !qco.qubit
    %84 = qco.sx %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_24) %84 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%82) targets (%arg0 = %85) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %86 = qco.rz(%cst_23) %targets_out_44 : !qco.qubit -> !qco.qubit
    %87 = qco.sx %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_14) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.sx %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_29) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.sx %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_28) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_25) %controls_out_31 : !qco.qubit -> !qco.qubit
    %94 = qco.sx %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_24) %94 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%92) targets (%arg0 = %95) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %96 = qco.rz(%cst_23) %targets_out_46 : !qco.qubit -> !qco.qubit
    %97 = qco.sx %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_13) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.sx %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_29) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.sx %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_28) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst_25) %controls_out_33 : !qco.qubit -> !qco.qubit
    %104 = qco.sx %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst_24) %104 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%102) targets (%arg0 = %105) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %106 = qco.rz(%cst_23) %targets_out_48 : !qco.qubit -> !qco.qubit
    %107 = qco.sx %106 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_12) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.sx %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst_29) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.sx %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rz(%cst_26) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_25) %controls_out_35 : !qco.qubit -> !qco.qubit
    %114 = qco.sx %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_24) %114 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%112) targets (%arg0 = %115) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %116 = qco.rz(%cst_23) %targets_out_50 : !qco.qubit -> !qco.qubit
    %117 = qco.sx %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_11) %117 : !qco.qubit -> !qco.qubit
    %119 = qco.sx %118 : !qco.qubit -> !qco.qubit
    %120 = qco.rz(%cst_29) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.sx %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rz(%cst_28) %121 : !qco.qubit -> !qco.qubit
    %123 = qco.rz(%cst_25) %controls_out_37 : !qco.qubit -> !qco.qubit
    %124 = qco.sx %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rz(%cst_24) %124 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%122) targets (%arg0 = %125) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %126 = qco.rz(%cst_23) %targets_out_52 : !qco.qubit -> !qco.qubit
    %127 = qco.sx %126 : !qco.qubit -> !qco.qubit
    %128 = qco.rz(%cst_10) %127 : !qco.qubit -> !qco.qubit
    %129 = qco.sx %128 : !qco.qubit -> !qco.qubit
    %130 = qco.rz(%cst_29) %129 : !qco.qubit -> !qco.qubit
    %131 = qco.sx %130 : !qco.qubit -> !qco.qubit
    %132 = qco.rz(%cst_26) %131 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst_25) %controls_out_39 : !qco.qubit -> !qco.qubit
    %134 = qco.sx %133 : !qco.qubit -> !qco.qubit
    %135 = qco.rz(%cst_24) %134 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%132) targets (%arg0 = %135) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %136 = qco.rz(%cst_23) %targets_out_54 : !qco.qubit -> !qco.qubit
    %137 = qco.sx %136 : !qco.qubit -> !qco.qubit
    %138 = qco.rz(%cst_9) %137 : !qco.qubit -> !qco.qubit
    %139 = qco.sx %138 : !qco.qubit -> !qco.qubit
    %140 = qco.rz(%cst_29) %139 : !qco.qubit -> !qco.qubit
    %141 = qco.sx %140 : !qco.qubit -> !qco.qubit
    %142 = qco.rz(%cst_26) %141 : !qco.qubit -> !qco.qubit
    %143 = qco.rz(%cst_25) %controls_out_41 : !qco.qubit -> !qco.qubit
    %144 = qco.sx %143 : !qco.qubit -> !qco.qubit
    %145 = qco.rz(%cst_24) %144 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%142) targets (%arg0 = %145) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %146 = qco.rz(%cst_23) %targets_out_56 : !qco.qubit -> !qco.qubit
    %147 = qco.sx %146 : !qco.qubit -> !qco.qubit
    %148 = qco.rz(%cst_8) %147 : !qco.qubit -> !qco.qubit
    %149 = qco.sx %148 : !qco.qubit -> !qco.qubit
    %150 = qco.rz(%cst_29) %149 : !qco.qubit -> !qco.qubit
    %151 = qco.sx %150 : !qco.qubit -> !qco.qubit
    %152 = qco.rz(%cst_28) %151 : !qco.qubit -> !qco.qubit
    %153 = qco.rz(%cst_25) %controls_out_43 : !qco.qubit -> !qco.qubit
    %154 = qco.sx %153 : !qco.qubit -> !qco.qubit
    %155 = qco.rz(%cst_24) %154 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%152) targets (%arg0 = %155) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %156 = qco.rz(%cst_23) %targets_out_58 : !qco.qubit -> !qco.qubit
    %157 = qco.sx %156 : !qco.qubit -> !qco.qubit
    %158 = qco.rz(%cst_7) %157 : !qco.qubit -> !qco.qubit
    %159 = qco.sx %158 : !qco.qubit -> !qco.qubit
    %160 = qco.rz(%cst_29) %159 : !qco.qubit -> !qco.qubit
    %161 = qco.sx %160 : !qco.qubit -> !qco.qubit
    %162 = qco.rz(%cst_28) %161 : !qco.qubit -> !qco.qubit
    %163 = qco.rz(%cst_25) %controls_out_45 : !qco.qubit -> !qco.qubit
    %164 = qco.sx %163 : !qco.qubit -> !qco.qubit
    %165 = qco.rz(%cst_24) %164 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%162) targets (%arg0 = %165) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %166 = qco.rz(%cst_23) %targets_out_60 : !qco.qubit -> !qco.qubit
    %167 = qco.sx %166 : !qco.qubit -> !qco.qubit
    %168 = qco.rz(%cst_6) %167 : !qco.qubit -> !qco.qubit
    %169 = qco.sx %168 : !qco.qubit -> !qco.qubit
    %170 = qco.rz(%cst_29) %169 : !qco.qubit -> !qco.qubit
    %171 = qco.sx %170 : !qco.qubit -> !qco.qubit
    %172 = qco.rz(%cst_27) %171 : !qco.qubit -> !qco.qubit
    %173 = qco.rz(%cst_25) %controls_out_47 : !qco.qubit -> !qco.qubit
    %174 = qco.sx %173 : !qco.qubit -> !qco.qubit
    %175 = qco.rz(%cst_24) %174 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%172) targets (%arg0 = %175) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %176 = qco.rz(%cst_23) %targets_out_62 : !qco.qubit -> !qco.qubit
    %177 = qco.sx %176 : !qco.qubit -> !qco.qubit
    %178 = qco.rz(%cst_5) %177 : !qco.qubit -> !qco.qubit
    %179 = qco.sx %178 : !qco.qubit -> !qco.qubit
    %180 = qco.rz(%cst_29) %179 : !qco.qubit -> !qco.qubit
    %181 = qco.sx %180 : !qco.qubit -> !qco.qubit
    %182 = qco.rz(%cst_28) %181 : !qco.qubit -> !qco.qubit
    %183 = qco.rz(%cst_25) %controls_out_49 : !qco.qubit -> !qco.qubit
    %184 = qco.sx %183 : !qco.qubit -> !qco.qubit
    %185 = qco.rz(%cst_24) %184 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%182) targets (%arg0 = %185) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %186 = qco.rz(%cst_23) %targets_out_64 : !qco.qubit -> !qco.qubit
    %187 = qco.sx %186 : !qco.qubit -> !qco.qubit
    %188 = qco.rz(%cst_4) %187 : !qco.qubit -> !qco.qubit
    %189 = qco.sx %188 : !qco.qubit -> !qco.qubit
    %190 = qco.rz(%cst_29) %189 : !qco.qubit -> !qco.qubit
    %191 = qco.sx %190 : !qco.qubit -> !qco.qubit
    %192 = qco.rz(%cst_26) %191 : !qco.qubit -> !qco.qubit
    %193 = qco.rz(%cst_25) %controls_out_51 : !qco.qubit -> !qco.qubit
    %194 = qco.sx %193 : !qco.qubit -> !qco.qubit
    %195 = qco.rz(%cst_24) %194 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%192) targets (%arg0 = %195) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %196 = qco.rz(%cst_23) %targets_out_66 : !qco.qubit -> !qco.qubit
    %197 = qco.sx %196 : !qco.qubit -> !qco.qubit
    %198 = qco.rz(%cst_3) %197 : !qco.qubit -> !qco.qubit
    %199 = qco.sx %198 : !qco.qubit -> !qco.qubit
    %200 = qco.rz(%cst_29) %199 : !qco.qubit -> !qco.qubit
    %201 = qco.sx %200 : !qco.qubit -> !qco.qubit
    %202 = qco.rz(%cst_26) %201 : !qco.qubit -> !qco.qubit
    %203 = qco.rz(%cst_25) %controls_out_53 : !qco.qubit -> !qco.qubit
    %204 = qco.sx %203 : !qco.qubit -> !qco.qubit
    %205 = qco.rz(%cst_24) %204 : !qco.qubit -> !qco.qubit
    %controls_out_67, %targets_out_68 = qco.ctrl(%202) targets (%arg0 = %205) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %206 = qco.rz(%cst_23) %targets_out_68 : !qco.qubit -> !qco.qubit
    %207 = qco.sx %206 : !qco.qubit -> !qco.qubit
    %208 = qco.rz(%cst_2) %207 : !qco.qubit -> !qco.qubit
    %209 = qco.sx %208 : !qco.qubit -> !qco.qubit
    %210 = qco.rz(%cst_29) %209 : !qco.qubit -> !qco.qubit
    %211 = qco.sx %210 : !qco.qubit -> !qco.qubit
    %212 = qco.rz(%cst_28) %211 : !qco.qubit -> !qco.qubit
    %213 = qco.rz(%cst_25) %controls_out_55 : !qco.qubit -> !qco.qubit
    %214 = qco.sx %213 : !qco.qubit -> !qco.qubit
    %215 = qco.rz(%cst_24) %214 : !qco.qubit -> !qco.qubit
    %controls_out_69, %targets_out_70 = qco.ctrl(%212) targets (%arg0 = %215) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %216 = qco.rz(%cst_23) %targets_out_70 : !qco.qubit -> !qco.qubit
    %217 = qco.sx %216 : !qco.qubit -> !qco.qubit
    %218 = qco.rz(%cst_1) %217 : !qco.qubit -> !qco.qubit
    %219 = qco.sx %218 : !qco.qubit -> !qco.qubit
    %220 = qco.rz(%cst_29) %219 : !qco.qubit -> !qco.qubit
    %221 = qco.sx %220 : !qco.qubit -> !qco.qubit
    %222 = qco.rz(%cst_28) %221 : !qco.qubit -> !qco.qubit
    %223 = qco.rz(%cst_25) %controls_out_57 : !qco.qubit -> !qco.qubit
    %224 = qco.sx %223 : !qco.qubit -> !qco.qubit
    %225 = qco.rz(%cst_24) %224 : !qco.qubit -> !qco.qubit
    %controls_out_71, %targets_out_72 = qco.ctrl(%222) targets (%arg0 = %225) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %226 = qco.rz(%cst_23) %targets_out_72 : !qco.qubit -> !qco.qubit
    %227 = qco.sx %226 : !qco.qubit -> !qco.qubit
    %228 = qco.rz(%cst_0) %227 : !qco.qubit -> !qco.qubit
    %229 = qco.sx %228 : !qco.qubit -> !qco.qubit
    %230 = qco.rz(%cst_29) %229 : !qco.qubit -> !qco.qubit
    %231 = qco.sx %230 : !qco.qubit -> !qco.qubit
    %232 = qco.rz(%cst_28) %231 : !qco.qubit -> !qco.qubit
    %233 = qco.rz(%cst_25) %controls_out_59 : !qco.qubit -> !qco.qubit
    %234 = qco.sx %233 : !qco.qubit -> !qco.qubit
    %235 = qco.rz(%cst_24) %234 : !qco.qubit -> !qco.qubit
    %controls_out_73, %targets_out_74 = qco.ctrl(%232) targets (%arg0 = %235) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %236 = qco.rz(%cst_23) %targets_out_74 : !qco.qubit -> !qco.qubit
    %237 = qco.sx %236 : !qco.qubit -> !qco.qubit
    %238 = qco.rz(%cst) %237 : !qco.qubit -> !qco.qubit
    %239 = qco.sx %238 : !qco.qubit -> !qco.qubit
    %240 = qco.rz(%cst_29) %239 : !qco.qubit -> !qco.qubit
    %241 = qco.sx %240 : !qco.qubit -> !qco.qubit
    %242 = qco.rz(%cst_28) %241 : !qco.qubit -> !qco.qubit
    qco.sink %controls_out_63 : !qco.qubit
    qco.sink %controls_out_65 : !qco.qubit
    qco.sink %controls_out_67 : !qco.qubit
    qco.sink %controls_out_69 : !qco.qubit
    qco.sink %controls_out_71 : !qco.qubit
    qco.sink %controls_out_73 : !qco.qubit
    %243 = qco.rz(%cst_25) %controls_out_61 : !qco.qubit -> !qco.qubit
    %244 = qco.sx %243 : !qco.qubit -> !qco.qubit
    %245 = qco.rz(%cst_24) %244 : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%242) targets (%arg0 = %245) {
      %249 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %249 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %246 = qco.rz(%cst_23) %targets_out_76 : !qco.qubit -> !qco.qubit
    %247 = qco.sx %246 : !qco.qubit -> !qco.qubit
    %248 = qco.rz(%cst_22) %247 : !qco.qubit -> !qco.qubit
    qco.sink %248 : !qco.qubit
    qco.sink %controls_out_75 : !qco.qubit
    return %c0_i64 : i64
  }
}
