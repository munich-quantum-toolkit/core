module attributes {mqt.layout = {initial = array<i64: 1, 2, 0>, input_count = 3 : i64, sites = array<i64: 0, 1, 2>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant -1.3734007669450157 : f64
    %cst_0 = arith.constant 5.4977871437821371 : f64
    %cst_1 = arith.constant 3.9269908169872432 : f64
    %cst_2 = arith.constant -1.5707963267948966 : f64
    %cst_3 = arith.constant 2.819842099193151 : f64
    %cst_4 = arith.constant 1.2490457723982544 : f64
    %cst_5 = arith.constant 3.1415926535897936 : f64
    %cst_6 = arith.constant 5.1050880620834134 : f64
    %cst_7 = arith.constant 3.5342917352885181 : f64
    %cst_8 = arith.constant -4.7123889803846897 : f64
    %cst_9 = arith.constant 3.1415926535897931 : f64
    %cst_10 = arith.constant -6.2831853071795862 : f64
    %cst_11 = arith.constant 4.7123889803846897 : f64
    %cst_12 = arith.constant 3.338988213439674 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %cst_13 = arith.constant 1.5707963267948966 : f64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %4 = qco.rz(%cst_13) %1 : !qco.qubit -> !qco.qubit
    %5 = qco.sx %4 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_13) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_13) %2 : !qco.qubit -> !qco.qubit
    %8 = qco.sx %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_13) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_4) %0 : !qco.qubit -> !qco.qubit
    %11 = qco.x %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_3) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_2) %13 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%14) targets (%arg0 = %12) {
      %49 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %49 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qco.rz(%cst_10) %targets_out : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_9) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_8) %controls_out : !qco.qubit -> !qco.qubit
    %19 = qco.sx %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_1) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_9) %21 : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%22) targets (%arg0 = %17) {
      %49 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %49 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qco.rz(%cst_2) %targets_out_15 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_0) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.sx %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %controls_out_14 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_9) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.x %27 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_12) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.sx %6 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_11) %32 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%33) targets (%arg0 = %31) {
      %49 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %49 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.rz(%cst_10) %targets_out_17 : !qco.qubit -> !qco.qubit
    %35 = qco.sx %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_9) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_8) %controls_out_16 : !qco.qubit -> !qco.qubit
    %38 = qco.sx %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_7) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.sx %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_9) %40 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%41) targets (%arg0 = %36) {
      %49 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %49 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qco.rz(%cst_11) %targets_out_19 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_6) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.sx %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_5) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.sx %controls_out_18 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_9) %47 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %46 : !qco.qubit
    cbit.store %result, %3[%c0] : !cbit.reg<3>
    %qubit_out_20, %result_21 = qco.measure %48 : !qco.qubit
    cbit.store %result_21, %3[%c1] : !cbit.reg<3>
    qco.sink %qubit_out_20 : !qco.qubit
    %qubit_out_22, %result_23 = qco.measure %29 : !qco.qubit
    qco.sink %qubit_out_22 : !qco.qubit
    cbit.store %result_23, %3[%c2] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    %cst_24 = arith.constant 3.4416913763379853E-15 : f64
    qco.gphase(%cst_24)
    return %3 : !cbit.reg<3>
  }
}
