module attributes {mqt.layout = {initial = array<i64: 1, 0, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 9.0320788790706548 : f64
    %cst_0 = arith.constant 4.7123889803846897 : f64
    %cst_1 = arith.constant -3.1415926535897931 : f64
    %cst_2 = arith.constant 3.5342917352885173 : f64
    %cst_3 = arith.constant -0.39269908169872414 : f64
    %cst_4 = arith.constant 3.9269908169872423 : f64
    %cst_5 = arith.constant -1.5707963267948966 : f64
    %cst_6 = arith.constant -0.78539816339744828 : f64
    %cst_7 = arith.constant -3.1415926535897927 : f64
    %cst_8 = arith.constant -1.1780972450961724 : f64
    %cst_9 = arith.constant 3.9269908169872405 : f64
    %cst_10 = arith.constant 3.9269908169872414 : f64
    %cst_11 = arith.constant 5.497787143782138 : f64
    %cst_12 = arith.constant 1.5707963267948961 : f64
    %cst_13 = arith.constant 1.5707963267948966 : f64
    %cst_14 = arith.constant 3.1415926535897931 : f64
    %cst_15 = arith.constant -4.7123889803846897 : f64
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.rx(%cst_14) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.rx(%cst_14) %2 : !qco.qubit -> !qco.qubit
    %6 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %7 = qco.rz(%cst_13) %3 : !qco.qubit -> !qco.qubit
    %8 = qco.rx(%cst_13) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_1) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_13) %5 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_5) %10 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%11) targets (%arg0 = %9) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qco.rz(%cst_11) %targets_out : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_14) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_10) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_15) %controls_out : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_13) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_4) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_13) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_14) %18 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%19) targets (%arg0 = %14) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.rz(%cst_3) %targets_out_17 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_14) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_2) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_13) %controls_out_16 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_11) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_13) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_13) %25 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%4) targets (%arg0 = %22) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %27 = qco.rz(%cst_15) %targets_out_19 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_13) %1 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_5) %28 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%29) targets (%arg0 = %27) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.rz(%cst_11) %targets_out_21 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_14) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_10) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_15) %controls_out_20 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_13) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_4) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_13) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_14) %36 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%37) targets (%arg0 = %32) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qco.rz(%cst_3) %targets_out_23 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_14) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_8) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_13) %controls_out_22 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_10) %41 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%42) targets (%arg0 = %26) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qco.rz(%cst_13) %targets_out_25 : !qco.qubit -> !qco.qubit
    %44 = qco.rx(%cst_13) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_0) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst_13) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_12) %46 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%47) targets (%arg0 = %40) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %48 = qco.rz(%cst_11) %targets_out_27 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_14) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_10) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_15) %controls_out_26 : !qco.qubit -> !qco.qubit
    %52 = qco.rx(%cst_13) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_9) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rx(%cst_13) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_14) %54 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%55) targets (%arg0 = %50) {
      %64 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %64 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qco.rz(%cst_8) %targets_out_29 : !qco.qubit -> !qco.qubit
    %57 = qco.rx(%cst_14) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_7) %controls_out_28 : !qco.qubit -> !qco.qubit
    %60 = qco.rx(%cst_13) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_6) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rx(%cst_13) %58 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_13) %62 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %61 : !qco.qubit
    cbit.store %result, %6[%c0] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    %qubit_out_30, %result_31 = qco.measure %63 : !qco.qubit
    qco.sink %qubit_out_30 : !qco.qubit
    cbit.store %result_31, %6[%c1] : !cbit.reg<4>
    %qubit_out_32, %result_33 = qco.measure %controls_out_24 : !qco.qubit
    cbit.store %result_33, %6[%c2] : !cbit.reg<4>
    qco.sink %qubit_out_32 : !qco.qubit
    %qubit_out_34, %result_35 = qco.measure %controls_out_18 : !qco.qubit
    qco.sink %qubit_out_34 : !qco.qubit
    cbit.store %result_35, %6[%c3] : !cbit.reg<4>
    %cst_36 = arith.constant 1.9634954084936265 : f64
    qco.gphase(%cst_36)
    return %6 : !cbit.reg<4>
  }
}
