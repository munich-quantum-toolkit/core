module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 1.7411520270540846 : f64
    %cst_0 = arith.constant 0.44384283218038334 : f64
    %cst_1 = arith.constant 4.8495419250235905 : f64
    %cst_2 = arith.constant 1.910960526894758 : f64
    %cst_3 = arith.constant 2.2322918083789127 : f64
    %cst_4 = arith.constant 4.786862445561848 : f64
    %cst_5 = arith.constant 4.9237825979843564 : f64
    %cst_6 = arith.constant 2.5244128431174029 : f64
    %cst_7 = arith.constant 1.4691751824920685 : f64
    %cst_8 = arith.constant 1.8310987593942736 : f64
    %cst_9 = arith.constant 1.0459444997562506 : f64
    %cst_10 = arith.constant 4.7802836587919346 : f64
    %cst_11 = arith.constant 1.8521788333097933 : f64
    %cst_12 = arith.constant 1.3535803372618576 : f64
    %cst_13 = arith.constant 4.7725488961611404 : f64
    %cst_14 = arith.constant 1.8596550387136206 : f64
    %cst_15 = arith.constant 1.4774842349682589 : f64
    %cst_16 = arith.constant 4.7713905410581789 : f64
    %cst_17 = arith.constant 5.2444335096046011 : f64
    %cst_18 = arith.constant 0.24477744749475647 : f64
    %cst_19 = arith.constant 1.3260957499492732 : f64
    %cst_20 = arith.constant 5.1146839302040155 : f64
    %cst_21 = arith.constant 0.49973517879145463 : f64
    %cst_22 = arith.constant 1.4479675821478473 : f64
    %cst_23 = arith.constant 4.7134324825532641 : f64
    %cst_24 = arith.constant 2.9409201411066732 : f64
    %cst_25 = arith.constant 1.2718189586879804 : f64
    %cst_26 = arith.constant 5.0792615977139812 : f64
    %cst_27 = arith.constant 0.68189643290593727 : f64
    %cst_28 = arith.constant 1.4775087358429129 : f64
    %cst_29 = arith.constant 1.8017106278390007 : f64
    %cst_30 = arith.constant 0.74783133753600417 : f64
    %cst_31 = arith.constant 4.7988296062936246 : f64
    %cst_32 = arith.constant 1.9030160508695089 : f64
    %cst_33 = arith.constant 1.5707963267948966 : f64
    %cst_34 = arith.constant 2.142617179036725 : f64
    %cst_35 = arith.constant 0.000000e+00 : f64
    %cst_36 = arith.constant 4.7822634209487038 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.r(%cst_36, %cst_35) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.r(%cst_34, %cst_33) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.r(%cst_32, %cst_35) %5 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%6) targets (%arg0 = %1) {
      %40 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %7 = qco.r(%cst_31, %cst_35) %targets_out : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_30, %cst_33) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_29, %cst_35) %8 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%9) targets (%arg0 = %2) {
      %40 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %10 = qco.r(%cst_28, %cst_35) %targets_out_38 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_27, %cst_33) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_26, %cst_35) %11 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%12) targets (%arg0 = %3) {
      %40 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %13 = qco.r(%cst_25, %cst_35) %targets_out_40 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_24, %cst_33) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_23, %cst_35) %14 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%15) targets (%arg0 = %controls_out) {
      %40 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.r(%cst_22, %cst_35) %targets_out_42 : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_21, %cst_33) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_20, %cst_35) %17 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%18) targets (%arg0 = %controls_out_37) {
      %40 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.r(%cst_19, %cst_35) %targets_out_44 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_18, %cst_33) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_17, %cst_35) %20 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%21) targets (%arg0 = %controls_out_39) {
      %40 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.r(%cst_16, %cst_35) %targets_out_46 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_15, %cst_33) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_14, %cst_35) %23 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%24) targets (%arg0 = %controls_out_41) {
      %40 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %25 = qco.r(%cst_13, %cst_35) %targets_out_48 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_12, %cst_33) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst_11, %cst_35) %26 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%27) targets (%arg0 = %controls_out_43) {
      %40 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qco.r(%cst_10, %cst_35) %targets_out_50 : !qco.qubit -> !qco.qubit
    %29 = qco.r(%cst_9, %cst_33) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_8, %cst_35) %29 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%30) targets (%arg0 = %controls_out_45) {
      %40 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.r(%cst_7, %cst_35) %targets_out_52 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_6, %cst_33) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_5, %cst_35) %32 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%33) targets (%arg0 = %controls_out_47) {
      %40 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.r(%cst_4, %cst_35) %targets_out_54 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst_3, %cst_33) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_2, %cst_35) %35 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%36) targets (%arg0 = %controls_out_49) {
      %40 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.r(%cst_1, %cst_35) %targets_out_56 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst_0, %cst_33) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst, %cst_35) %38 : !qco.qubit -> !qco.qubit
    qco.sink %controls_out_53 : !qco.qubit
    qco.sink %controls_out_55 : !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%39) targets (%arg0 = %controls_out_51) {
      %40 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %40 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    qco.sink %targets_out_58 : !qco.qubit
    qco.sink %controls_out_57 : !qco.qubit
    return %c0_i64 : i64
  }
}
