module attributes {mqt.layout = {initial = array<i64: 1, 0, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 8.6393797973719302 : f64
    %cst_0 = arith.constant 4.7123889803846897 : f64
    %cst_1 = arith.constant 6.2831853071795862 : f64
    %cst_2 = arith.constant -3.9269908169872418 : f64
    %cst_3 = arith.constant 5.497787143782138 : f64
    %cst_4 = arith.constant 0.78539816339744806 : f64
    %cst_5 = arith.constant 3.9269908169872414 : f64
    %cst_6 = arith.constant 3.9269908169872432 : f64
    %cst_7 = arith.constant 1.5707963267948968 : f64
    %cst_8 = arith.constant -0.78539816339744783 : f64
    %cst_9 = arith.constant -3.1415926535897922 : f64
    %cst_10 = arith.constant -1.5707963267948966 : f64
    %cst_11 = arith.constant 3.926990816987241 : f64
    %cst_12 = arith.constant -4.7123889803846897 : f64
    %cst_13 = arith.constant 1.5707963267948961 : f64
    %cst_14 = arith.constant 3.1415926535897931 : f64
    %cst_15 = arith.constant 1.5707963267948966 : f64
    %cst_16 = arith.constant -6.2831853071795862 : f64
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.x %0 : !qco.qubit -> !qco.qubit
    %5 = qco.x %2 : !qco.qubit -> !qco.qubit
    %6 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %7 = qco.rz(%cst_15) %3 : !qco.qubit -> !qco.qubit
    %8 = qco.sx %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_12) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_15) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_10) %12 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%13) targets (%arg0 = %11) {
      %77 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %77 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.rz(%cst_16) %targets_out : !qco.qubit -> !qco.qubit
    %15 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_14) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_12) %controls_out : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_6) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.sx %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_14) %20 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%21) targets (%arg0 = %16) {
      %77 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %77 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.rz(%cst_10) %targets_out_18 : !qco.qubit -> !qco.qubit
    %23 = qco.sx %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_4) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.sx %controls_out_17 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_3) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.sx %26 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %24 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_7) %28 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%4) targets (%arg0 = %29) {
      %77 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %77 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.rz(%cst_12) %targets_out_20 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_10) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.sx %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_15) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.sx %1 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_10) %35 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%36) targets (%arg0 = %34) {
      %77 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %77 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.rz(%cst_16) %targets_out_22 : !qco.qubit -> !qco.qubit
    %38 = qco.sx %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_14) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_12) %controls_out_21 : !qco.qubit -> !qco.qubit
    %41 = qco.sx %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_6) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_14) %43 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%44) targets (%arg0 = %39) {
      %77 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %77 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.rz(%cst_10) %targets_out_24 : !qco.qubit -> !qco.qubit
    %46 = qco.sx %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_2) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %controls_out_23 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_5) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_7) %50 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%49) targets (%arg0 = %51) {
      %77 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %77 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qco.rz(%cst_12) %targets_out_26 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_1) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.sx %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_0) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_15) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.sx %56 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_13) %59 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%60) targets (%arg0 = %58) {
      %77 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %77 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qco.rz(%cst_16) %targets_out_28 : !qco.qubit -> !qco.qubit
    %62 = qco.sx %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_14) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_12) %controls_out_27 : !qco.qubit -> !qco.qubit
    %65 = qco.sx %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_11) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.sx %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_14) %67 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%68) targets (%arg0 = %63) {
      %77 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %77 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qco.rz(%cst_10) %targets_out_30 : !qco.qubit -> !qco.qubit
    %70 = qco.sx %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_9) %controls_out_29 : !qco.qubit -> !qco.qubit
    %73 = qco.sx %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_8) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.sx %71 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_15) %75 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %74 : !qco.qubit
    cbit.store %result, %6[%c0] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    %qubit_out_31, %result_32 = qco.measure %76 : !qco.qubit
    qco.sink %qubit_out_31 : !qco.qubit
    cbit.store %result_32, %6[%c1] : !cbit.reg<4>
    %qubit_out_33, %result_34 = qco.measure %controls_out_25 : !qco.qubit
    cbit.store %result_34, %6[%c2] : !cbit.reg<4>
    qco.sink %qubit_out_33 : !qco.qubit
    %qubit_out_35, %result_36 = qco.measure %controls_out_19 : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    cbit.store %result_36, %6[%c3] : !cbit.reg<4>
    %cst_37 = arith.constant 1.1780972450961782 : f64
    qco.gphase(%cst_37)
    return %6 : !cbit.reg<4>
  }
}
