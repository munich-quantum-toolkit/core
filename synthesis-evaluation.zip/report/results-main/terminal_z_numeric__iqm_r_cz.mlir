module attributes {mqt.layout = {initial = array<i64: 0, 1>, input_count = 2 : i64, sites = array<i64: 0, 1>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<2> attributes {mqt.entry_point} {
    %cst = arith.constant -3.1415926535897931 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant 1.5707963267948968 : f64
    %cst_2 = arith.constant 0.000000e+00 : f64
    %cst_3 = arith.constant 0.37000000000000011 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "meas"} : !cbit.reg<2>
    %3 = qco.r(%cst_3, %cst_2) %0 : !qco.qubit -> !qco.qubit
    %4 = qco.r(%cst_1, %cst_0) %3 : !qco.qubit -> !qco.qubit
    %5 = qco.r(%cst, %cst_2) %4 : !qco.qubit -> !qco.qubit
    %6:2 = qco.barrier %5, %1 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %qubit_out, %result = qco.measure %6#0 : !qco.qubit
    cbit.store %result, %2[%c0] : !cbit.reg<2>
    qco.sink %qubit_out : !qco.qubit
    %qubit_out_4, %result_5 = qco.measure %6#1 : !qco.qubit
    qco.sink %qubit_out_4 : !qco.qubit
    cbit.store %result_5, %2[%c1] : !cbit.reg<2>
    %cst_6 = arith.constant -1.5707963267948966 : f64
    qco.gphase(%cst_6)
    return %2 : !cbit.reg<2>
  }
}
