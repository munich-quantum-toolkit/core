module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 3.1415926535897927 : f64
    %cst_0 = arith.constant 4.7123889803846897 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %cst_2 = arith.constant -3.1415926535897931 : f64
    %cst_3 = arith.constant 2.3561944901923448 : f64
    %cst_4 = arith.constant -0.78539816339744828 : f64
    %cst_5 = arith.constant 0.78539816339744828 : f64
    %cst_6 = arith.constant 1.5707963267948966 : f64
    %cst_7 = arith.constant 3.1415926535897931 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %5 = qco.rx(%cst_7) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_6) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.rx(%cst_6) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_3) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_6) %3 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_6) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_3) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_7) %5 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_6) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_7) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_7) %8 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_4) %15 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %16, %14 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %17 = qco.rz(%cst_3) %qubit1_out : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_7) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_5) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_2) %qubit0_out : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_6) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_1) %21 : !qco.qubit -> !qco.qubit
    %qubit0_out_8, %qubit1_out_9 = qco.iswap %22, %19 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %23 = qco.rz(%cst_1) %qubit1_out_9 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_6) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_0) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst) %qubit0_out_8 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_6) %25 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_7) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_7) %11 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_4) %29 : !qco.qubit -> !qco.qubit
    %qubit0_out_10, %qubit1_out_11 = qco.iswap %30, %28 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %31 = qco.rz(%cst_3) %qubit1_out_11 : !qco.qubit -> !qco.qubit
    %32 = qco.rx(%cst_7) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_5) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_2) %qubit0_out_10 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_6) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_1) %35 : !qco.qubit -> !qco.qubit
    %qubit0_out_12, %qubit1_out_13 = qco.iswap %36, %33 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %37 = qco.rz(%cst_1) %qubit1_out_13 : !qco.qubit -> !qco.qubit
    %38 = qco.rx(%cst_6) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_6) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst) %qubit0_out_12 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_6) %26 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_6) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_6) %40 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_6) %43 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %42 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<3>
    %qubit_out_14, %result_15 = qco.measure %2 : !qco.qubit
    cbit.store %result_15, %4[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_14 : !qco.qubit
    %qubit_out_16, %result_17 = qco.measure %44 : !qco.qubit
    qco.sink %qubit_out_16 : !qco.qubit
    cbit.store %result_17, %4[%c2] : !cbit.reg<3>
    qco.sink %39 : !qco.qubit
    %cst_18 = arith.constant -1.7763568394002505E-15 : f64
    qco.gphase(%cst_18)
    return %4 : !cbit.reg<3>
  }
}
