module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 1.7404396926187879 : f64
    %cst_0 = arith.constant 0.44163696459159696 : f64
    %cst_1 = arith.constant 4.8501855774508655 : f64
    %cst_2 = arith.constant 5.0643396495252277 : f64
    %cst_3 = arith.constant 0.79619125699809568 : f64
    %cst_4 = arith.constant 1.4885558674970811 : f64
    %cst_5 = arith.constant 1.7910031736098688 : f64
    %cst_6 = arith.constant 0.67096006368026528 : f64
    %cst_7 = arith.constant 4.8069599852081977 : f64
    %cst_8 = arith.constant 1.7916442260953038 : f64
    %cst_9 = arith.constant 0.67518439956500753 : f64
    %cst_10 = arith.constant 4.8064587386338973 : f64
    %cst_11 = arith.constant 5.0680965906856628 : f64
    %cst_12 = arith.constant 0.76463608779652392 : f64
    %cst_13 = arith.constant 1.4858857665055942 : f64
    %cst_14 = arith.constant 5.0526388303579122 : f64
    %cst_15 = arith.constant 0.90839567120654963 : f64
    %cst_16 = arith.constant 1.496270216519678 : f64
    %cst_17 = arith.constant 5.0040179112550165 : f64
    %cst_18 = arith.constant 1.6172444221121702 : f64
    %cst_19 = arith.constant 1.5119882450039366 : f64
    %cst_20 = arith.constant 1.8998956796037296 : f64
    %cst_21 = arith.constant 2.1042153151496632 : f64
    %cst_22 = arith.constant 4.7806251759062892 : f64
    %cst_23 = arith.constant 4.9918771466767309 : f64
    %cst_24 = arith.constant 1.8185070799474428 : f64
    %cst_25 = arith.constant 1.510199950904717 : f64
    %cst_26 = arith.constant 5.5012944969399591 : f64
    %cst_27 = arith.constant 0.1232835416800302 : f64
    %cst_28 = arith.constant 1.0730639561216697 : f64
    %cst_29 = arith.constant 4.9864449326104987 : f64
    %cst_30 = arith.constant 1.9032384356134255 : f64
    %cst_31 = arith.constant 1.508644800426638 : f64
    %cst_32 = arith.constant 2.0297934905336494 : f64
    %cst_33 = arith.constant 2.7970573012277402 : f64
    %cst_34 = arith.constant 4.8871007935292319 : f64
    %cst_35 = arith.constant 4.944861603490768 : f64
    %cst_36 = arith.constant 2.3813687808492299 : f64
    %cst_37 = arith.constant 1.485491642297184 : f64
    %cst_38 = arith.constant 4.9977678231010341 : f64
    %cst_39 = arith.constant 1.7223760426460784 : f64
    %cst_40 = arith.constant 1.5113695534704215 : f64
    %cst_41 = arith.constant 4.9622424308783355 : f64
    %cst_42 = arith.constant 2.2184769663678501 : f64
    %cst_43 = arith.constant 1.4971097450823048 : f64
    %cst_44 = arith.constant 5.0479637790895042 : f64
    %cst_45 = arith.constant 0.95970596385894413 : f64
    %cst_46 = arith.constant 1.4990508355502377 : f64
    %cst_47 = arith.constant 4.9901321202054048 : f64
    %cst_48 = arith.constant 1.8461887203811271 : f64
    %cst_49 = arith.constant 1.5097486792103718 : f64
    %cst_50 = arith.constant 1.943238778035759 : f64
    %cst_51 = arith.constant 2.4955376276385111 : f64
    %cst_52 = arith.constant 4.810063793932458 : f64
    %cst_53 = arith.constant 1.8079018480780829 : f64
    %cst_54 = arith.constant 0.79906898523659486 : f64
    %cst_55 = arith.constant 4.7943982985842348 : f64
    %cst_56 = arith.constant 1.6143169407338116 : f64
    %cst_57 = arith.constant 0.23264610776635553 : f64
    %cst_58 = arith.constant 4.9698767189253212 : f64
    %cst_59 = arith.constant 4.9556474859154394 : f64
    %cst_60 = arith.constant 2.285966281979888 : f64
    %cst_61 = arith.constant 1.4929532095365874 : f64
    %cst_62 = arith.constant 5.0931785298774024 : f64
    %cst_63 = arith.constant 0.59808769823152697 : f64
    %cst_64 = arith.constant 1.4663360855801213 : f64
    %cst_65 = arith.constant 1.7947488753832832 : f64
    %cst_66 = arith.constant 0.6962937304898249 : f64
    %cst_67 = arith.constant 4.8040557568195084 : f64
    %cst_68 = arith.constant 1.7742282538709413 : f64
    %cst_69 = arith.constant 1.5707963267948966 : f64
    %cst_70 = arith.constant 0.5747378080031621 : f64
    %cst_71 = arith.constant 0.000000e+00 : f64
    %cst_72 = arith.constant 4.8206007998253888 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.r(%cst_72, %cst_71) %0 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_70, %cst_69) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_68, %cst_71) %9 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%10) targets (%arg0 = %1) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qco.r(%cst_67, %cst_71) %targets_out : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_66, %cst_69) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_65, %cst_71) %12 : !qco.qubit -> !qco.qubit
    %controls_out_73, %targets_out_74 = qco.ctrl(%13) targets (%arg0 = %2) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.r(%cst_64, %cst_71) %targets_out_74 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_63, %cst_69) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_62, %cst_71) %15 : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%16) targets (%arg0 = %3) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.r(%cst_61, %cst_71) %targets_out_76 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_60, %cst_69) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst_59, %cst_71) %18 : !qco.qubit -> !qco.qubit
    %controls_out_77, %targets_out_78 = qco.ctrl(%19) targets (%arg0 = %4) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.r(%cst_58, %cst_71) %targets_out_78 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_57, %cst_69) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_56, %cst_71) %21 : !qco.qubit -> !qco.qubit
    %controls_out_79, %targets_out_80 = qco.ctrl(%22) targets (%arg0 = %5) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qco.r(%cst_55, %cst_71) %targets_out_80 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_54, %cst_69) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_53, %cst_71) %24 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%25) targets (%arg0 = %6) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.r(%cst_52, %cst_71) %targets_out_82 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst_51, %cst_69) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_50, %cst_71) %27 : !qco.qubit -> !qco.qubit
    %controls_out_83, %targets_out_84 = qco.ctrl(%28) targets (%arg0 = %7) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.r(%cst_49, %cst_71) %targets_out_84 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_48, %cst_69) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%cst_47, %cst_71) %30 : !qco.qubit -> !qco.qubit
    %controls_out_85, %targets_out_86 = qco.ctrl(%31) targets (%arg0 = %controls_out) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qco.r(%cst_46, %cst_71) %targets_out_86 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_45, %cst_69) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.r(%cst_44, %cst_71) %33 : !qco.qubit -> !qco.qubit
    %controls_out_87, %targets_out_88 = qco.ctrl(%34) targets (%arg0 = %controls_out_73) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.r(%cst_43, %cst_71) %targets_out_88 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_42, %cst_69) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%cst_41, %cst_71) %36 : !qco.qubit -> !qco.qubit
    %controls_out_89, %targets_out_90 = qco.ctrl(%37) targets (%arg0 = %controls_out_75) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qco.r(%cst_40, %cst_71) %targets_out_90 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst_39, %cst_69) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_38, %cst_71) %39 : !qco.qubit -> !qco.qubit
    %controls_out_91, %targets_out_92 = qco.ctrl(%40) targets (%arg0 = %controls_out_77) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.r(%cst_37, %cst_71) %targets_out_92 : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst_36, %cst_69) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%cst_35, %cst_71) %42 : !qco.qubit -> !qco.qubit
    %controls_out_93, %targets_out_94 = qco.ctrl(%43) targets (%arg0 = %controls_out_79) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = qco.r(%cst_34, %cst_71) %targets_out_94 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst_33, %cst_69) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.r(%cst_32, %cst_71) %45 : !qco.qubit -> !qco.qubit
    %controls_out_95, %targets_out_96 = qco.ctrl(%46) targets (%arg0 = %controls_out_81) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.r(%cst_31, %cst_71) %targets_out_96 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst_30, %cst_69) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.r(%cst_29, %cst_71) %48 : !qco.qubit -> !qco.qubit
    %controls_out_97, %targets_out_98 = qco.ctrl(%49) targets (%arg0 = %controls_out_83) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qco.r(%cst_28, %cst_71) %targets_out_98 : !qco.qubit -> !qco.qubit
    %51 = qco.r(%cst_27, %cst_69) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.r(%cst_26, %cst_71) %51 : !qco.qubit -> !qco.qubit
    %controls_out_99, %targets_out_100 = qco.ctrl(%52) targets (%arg0 = %controls_out_85) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qco.r(%cst_25, %cst_71) %targets_out_100 : !qco.qubit -> !qco.qubit
    %54 = qco.r(%cst_24, %cst_69) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.r(%cst_23, %cst_71) %54 : !qco.qubit -> !qco.qubit
    %controls_out_101, %targets_out_102 = qco.ctrl(%55) targets (%arg0 = %controls_out_87) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qco.r(%cst_22, %cst_71) %targets_out_102 : !qco.qubit -> !qco.qubit
    %57 = qco.r(%cst_21, %cst_69) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.r(%cst_20, %cst_71) %57 : !qco.qubit -> !qco.qubit
    %controls_out_103, %targets_out_104 = qco.ctrl(%58) targets (%arg0 = %controls_out_89) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qco.r(%cst_19, %cst_71) %targets_out_104 : !qco.qubit -> !qco.qubit
    %60 = qco.r(%cst_18, %cst_69) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.r(%cst_17, %cst_71) %60 : !qco.qubit -> !qco.qubit
    %controls_out_105, %targets_out_106 = qco.ctrl(%61) targets (%arg0 = %controls_out_91) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %62 = qco.r(%cst_16, %cst_71) %targets_out_106 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%cst_15, %cst_69) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.r(%cst_14, %cst_71) %63 : !qco.qubit -> !qco.qubit
    %controls_out_107, %targets_out_108 = qco.ctrl(%64) targets (%arg0 = %controls_out_93) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qco.r(%cst_13, %cst_71) %targets_out_108 : !qco.qubit -> !qco.qubit
    %66 = qco.r(%cst_12, %cst_69) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.r(%cst_11, %cst_71) %66 : !qco.qubit -> !qco.qubit
    %controls_out_109, %targets_out_110 = qco.ctrl(%67) targets (%arg0 = %controls_out_95) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %68 = qco.r(%cst_10, %cst_71) %targets_out_110 : !qco.qubit -> !qco.qubit
    %69 = qco.r(%cst_9, %cst_69) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.r(%cst_8, %cst_71) %69 : !qco.qubit -> !qco.qubit
    %controls_out_111, %targets_out_112 = qco.ctrl(%70) targets (%arg0 = %controls_out_97) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qco.r(%cst_7, %cst_71) %targets_out_112 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%cst_6, %cst_69) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%cst_5, %cst_71) %72 : !qco.qubit -> !qco.qubit
    %controls_out_113, %targets_out_114 = qco.ctrl(%73) targets (%arg0 = %controls_out_99) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %74 = qco.r(%cst_4, %cst_71) %targets_out_114 : !qco.qubit -> !qco.qubit
    %75 = qco.r(%cst_3, %cst_69) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.r(%cst_2, %cst_71) %75 : !qco.qubit -> !qco.qubit
    %controls_out_115, %targets_out_116 = qco.ctrl(%76) targets (%arg0 = %controls_out_101) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qco.r(%cst_1, %cst_71) %targets_out_116 : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst_0, %cst_69) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.r(%cst, %cst_71) %78 : !qco.qubit -> !qco.qubit
    qco.sink %controls_out_105 : !qco.qubit
    qco.sink %controls_out_107 : !qco.qubit
    qco.sink %controls_out_109 : !qco.qubit
    qco.sink %controls_out_111 : !qco.qubit
    qco.sink %controls_out_113 : !qco.qubit
    qco.sink %controls_out_115 : !qco.qubit
    %controls_out_117, %targets_out_118 = qco.ctrl(%79) targets (%arg0 = %controls_out_103) {
      %80 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %80 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    qco.sink %targets_out_118 : !qco.qubit
    qco.sink %controls_out_117 : !qco.qubit
    return %c0_i64 : i64
  }
}
