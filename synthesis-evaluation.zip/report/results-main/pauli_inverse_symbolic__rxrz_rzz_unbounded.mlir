module attributes {mqt.layout = {initial = array<i64: 0, 1>, input_count = 2 : i64, sites = array<i64: 0, 1>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main(%arg0: f64 {mqt.input_id = -3033000624479524390794154133784343657 : i128, mqt.input_name = "theta[0]", mqt.parameter_group = {identity = "fdb7dd86-1c01-4fc1-b8da-f3c16e084b97", index = 0 : i64, name = "theta", size = 2 : i64}}) -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant -1.000000e+00 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%arg0) %0, %1 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %2 = arith.mulf %arg0, %cst : f64
    %qubit0_out_0, %qubit1_out_1 = qco.rzz(%2) %qubit0_out, %qubit1_out : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    qco.sink %qubit1_out_1 : !qco.qubit
    qco.sink %qubit0_out_0 : !qco.qubit
    return %c0_i64 : i64
  }
}
