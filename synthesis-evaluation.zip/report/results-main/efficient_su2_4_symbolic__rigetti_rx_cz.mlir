module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main(%arg0: f64 {mqt.input_id = -120262898746132594670008414538420507071 : i128, mqt.input_name = "\CE\B8[0]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 0 : i64, name = "\CE\B8", size = 32 : i64}}, %arg1: f64 {mqt.input_id = -120262898746132594670008414538420507070 : i128, mqt.input_name = "\CE\B8[1]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 1 : i64, name = "\CE\B8", size = 32 : i64}}, %arg2: f64 {mqt.input_id = -120262898746132594670008414538420507069 : i128, mqt.input_name = "\CE\B8[2]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 2 : i64, name = "\CE\B8", size = 32 : i64}}, %arg3: f64 {mqt.input_id = -120262898746132594670008414538420507068 : i128, mqt.input_name = "\CE\B8[3]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 3 : i64, name = "\CE\B8", size = 32 : i64}}, %arg4: f64 {mqt.input_id = -120262898746132594670008414538420507067 : i128, mqt.input_name = "\CE\B8[4]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 4 : i64, name = "\CE\B8", size = 32 : i64}}, %arg5: f64 {mqt.input_id = -120262898746132594670008414538420507066 : i128, mqt.input_name = "\CE\B8[5]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 5 : i64, name = "\CE\B8", size = 32 : i64}}, %arg6: f64 {mqt.input_id = -120262898746132594670008414538420507065 : i128, mqt.input_name = "\CE\B8[6]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 6 : i64, name = "\CE\B8", size = 32 : i64}}, %arg7: f64 {mqt.input_id = -120262898746132594670008414538420507064 : i128, mqt.input_name = "\CE\B8[7]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 7 : i64, name = "\CE\B8", size = 32 : i64}}, %arg8: f64 {mqt.input_id = -120262898746132594670008414538420507063 : i128, mqt.input_name = "\CE\B8[8]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 8 : i64, name = "\CE\B8", size = 32 : i64}}, %arg9: f64 {mqt.input_id = -120262898746132594670008414538420507062 : i128, mqt.input_name = "\CE\B8[9]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 9 : i64, name = "\CE\B8", size = 32 : i64}}, %arg10: f64 {mqt.input_id = -120262898746132594670008414538420507061 : i128, mqt.input_name = "\CE\B8[10]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 10 : i64, name = "\CE\B8", size = 32 : i64}}, %arg11: f64 {mqt.input_id = -120262898746132594670008414538420507060 : i128, mqt.input_name = "\CE\B8[11]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 11 : i64, name = "\CE\B8", size = 32 : i64}}, %arg12: f64 {mqt.input_id = -120262898746132594670008414538420507059 : i128, mqt.input_name = "\CE\B8[12]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 12 : i64, name = "\CE\B8", size = 32 : i64}}, %arg13: f64 {mqt.input_id = -120262898746132594670008414538420507058 : i128, mqt.input_name = "\CE\B8[13]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 13 : i64, name = "\CE\B8", size = 32 : i64}}, %arg14: f64 {mqt.input_id = -120262898746132594670008414538420507057 : i128, mqt.input_name = "\CE\B8[14]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 14 : i64, name = "\CE\B8", size = 32 : i64}}, %arg15: f64 {mqt.input_id = -120262898746132594670008414538420507056 : i128, mqt.input_name = "\CE\B8[15]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 15 : i64, name = "\CE\B8", size = 32 : i64}}, %arg16: f64 {mqt.input_id = -120262898746132594670008414538420507055 : i128, mqt.input_name = "\CE\B8[16]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 16 : i64, name = "\CE\B8", size = 32 : i64}}, %arg17: f64 {mqt.input_id = -120262898746132594670008414538420507054 : i128, mqt.input_name = "\CE\B8[17]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 17 : i64, name = "\CE\B8", size = 32 : i64}}, %arg18: f64 {mqt.input_id = -120262898746132594670008414538420507053 : i128, mqt.input_name = "\CE\B8[18]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 18 : i64, name = "\CE\B8", size = 32 : i64}}, %arg19: f64 {mqt.input_id = -120262898746132594670008414538420507052 : i128, mqt.input_name = "\CE\B8[19]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 19 : i64, name = "\CE\B8", size = 32 : i64}}, %arg20: f64 {mqt.input_id = -120262898746132594670008414538420507051 : i128, mqt.input_name = "\CE\B8[20]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 20 : i64, name = "\CE\B8", size = 32 : i64}}, %arg21: f64 {mqt.input_id = -120262898746132594670008414538420507050 : i128, mqt.input_name = "\CE\B8[21]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 21 : i64, name = "\CE\B8", size = 32 : i64}}, %arg22: f64 {mqt.input_id = -120262898746132594670008414538420507049 : i128, mqt.input_name = "\CE\B8[22]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 22 : i64, name = "\CE\B8", size = 32 : i64}}, %arg23: f64 {mqt.input_id = -120262898746132594670008414538420507048 : i128, mqt.input_name = "\CE\B8[23]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 23 : i64, name = "\CE\B8", size = 32 : i64}}, %arg24: f64 {mqt.input_id = -120262898746132594670008414538420507047 : i128, mqt.input_name = "\CE\B8[24]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 24 : i64, name = "\CE\B8", size = 32 : i64}}, %arg25: f64 {mqt.input_id = -120262898746132594670008414538420507046 : i128, mqt.input_name = "\CE\B8[25]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 25 : i64, name = "\CE\B8", size = 32 : i64}}, %arg26: f64 {mqt.input_id = -120262898746132594670008414538420507045 : i128, mqt.input_name = "\CE\B8[26]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 26 : i64, name = "\CE\B8", size = 32 : i64}}, %arg27: f64 {mqt.input_id = -120262898746132594670008414538420507044 : i128, mqt.input_name = "\CE\B8[27]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 27 : i64, name = "\CE\B8", size = 32 : i64}}, %arg28: f64 {mqt.input_id = -120262898746132594670008414538420507043 : i128, mqt.input_name = "\CE\B8[28]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 28 : i64, name = "\CE\B8", size = 32 : i64}}, %arg29: f64 {mqt.input_id = -120262898746132594670008414538420507042 : i128, mqt.input_name = "\CE\B8[29]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 29 : i64, name = "\CE\B8", size = 32 : i64}}, %arg30: f64 {mqt.input_id = -120262898746132594670008414538420507041 : i128, mqt.input_name = "\CE\B8[30]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 30 : i64, name = "\CE\B8", size = 32 : i64}}, %arg31: f64 {mqt.input_id = -120262898746132594670008414538420507040 : i128, mqt.input_name = "\CE\B8[31]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 31 : i64, name = "\CE\B8", size = 32 : i64}}) -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 1.5707963267948963 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant 4.7123889803846897 : f64
    %cst_2 = arith.constant -4.7123889803846897 : f64
    %cst_3 = arith.constant 4.000000e+00 : f64
    %cst_4 = arith.constant 1.5707963267948966 : f64
    %cst_5 = arith.constant 3.1415926535897931 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = arith.divf %arg0, %cst_3 : f64
    %5 = math.tan %4 : f64
    %6 = math.atan %5 : f64
    %7 = arith.mulf %6, %cst_3 : f64
    %8 = qco.rx(%cst_4) %0 : !qco.qubit -> !qco.qubit
    %9 = arith.addf %7, %cst_5 : f64
    %10 = qco.rz(%9) %8 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_4) %10 : !qco.qubit -> !qco.qubit
    %12 = arith.divf %arg1, %cst_3 : f64
    %13 = math.tan %12 : f64
    %14 = math.atan %13 : f64
    %15 = arith.mulf %14, %cst_3 : f64
    %16 = qco.rx(%cst_4) %1 : !qco.qubit -> !qco.qubit
    %17 = arith.addf %15, %cst_5 : f64
    %18 = qco.rz(%17) %16 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_4) %18 : !qco.qubit -> !qco.qubit
    %20 = arith.divf %arg2, %cst_3 : f64
    %21 = math.tan %20 : f64
    %22 = math.atan %21 : f64
    %23 = arith.mulf %22, %cst_3 : f64
    %24 = qco.rx(%cst_4) %2 : !qco.qubit -> !qco.qubit
    %25 = arith.addf %23, %cst_5 : f64
    %26 = qco.rz(%25) %24 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_4) %26 : !qco.qubit -> !qco.qubit
    %28 = arith.divf %arg3, %cst_3 : f64
    %29 = math.tan %28 : f64
    %30 = math.atan %29 : f64
    %31 = arith.mulf %30, %cst_3 : f64
    %32 = qco.rx(%cst_4) %3 : !qco.qubit -> !qco.qubit
    %33 = arith.addf %31, %cst_5 : f64
    %34 = qco.rz(%33) %32 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_4) %34 : !qco.qubit -> !qco.qubit
    %36 = arith.divf %arg7, %cst_3 : f64
    %37 = math.tan %36 : f64
    %38 = math.atan %37 : f64
    %39 = arith.mulf %38, %cst_3 : f64
    %40 = arith.addf %39, %cst_5 : f64
    %41 = qco.rz(%40) %35 : !qco.qubit -> !qco.qubit
    %42 = arith.divf %arg4, %cst_3 : f64
    %43 = math.tan %42 : f64
    %44 = math.atan %43 : f64
    %45 = arith.mulf %44, %cst_3 : f64
    %46 = arith.addf %45, %cst_2 : f64
    %47 = arith.divf %46, %cst_3 : f64
    %48 = math.tan %47 : f64
    %49 = math.atan %48 : f64
    %50 = arith.mulf %49, %cst_3 : f64
    %51 = arith.addf %50, %cst_5 : f64
    %52 = qco.rz(%51) %11 : !qco.qubit -> !qco.qubit
    %53 = qco.rx(%cst_4) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_1) %53 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%41) targets (%arg32 = %54) {
      %336 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %336 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.rz(%cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_4) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst) %56 : !qco.qubit -> !qco.qubit
    %58 = arith.divf %arg5, %cst_3 : f64
    %59 = math.tan %58 : f64
    %60 = math.atan %59 : f64
    %61 = arith.mulf %60, %cst_3 : f64
    %62 = arith.addf %61, %cst_2 : f64
    %63 = arith.divf %62, %cst_3 : f64
    %64 = math.tan %63 : f64
    %65 = math.atan %64 : f64
    %66 = arith.mulf %65, %cst_3 : f64
    %67 = arith.addf %66, %cst_5 : f64
    %68 = qco.rz(%67) %19 : !qco.qubit -> !qco.qubit
    %69 = qco.rx(%cst_4) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_1) %69 : !qco.qubit -> !qco.qubit
    %controls_out_6, %targets_out_7 = qco.ctrl(%57) targets (%arg32 = %70) {
      %336 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %336 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qco.rz(%cst_0) %targets_out_7 : !qco.qubit -> !qco.qubit
    %72 = qco.rx(%cst_4) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst) %72 : !qco.qubit -> !qco.qubit
    %74 = arith.divf %arg6, %cst_3 : f64
    %75 = math.tan %74 : f64
    %76 = math.atan %75 : f64
    %77 = arith.mulf %76, %cst_3 : f64
    %78 = arith.addf %77, %cst_2 : f64
    %79 = arith.divf %78, %cst_3 : f64
    %80 = math.tan %79 : f64
    %81 = math.atan %80 : f64
    %82 = arith.mulf %81, %cst_3 : f64
    %83 = arith.addf %82, %cst_5 : f64
    %84 = qco.rz(%83) %27 : !qco.qubit -> !qco.qubit
    %85 = qco.rx(%cst_4) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_1) %85 : !qco.qubit -> !qco.qubit
    %controls_out_8, %targets_out_9 = qco.ctrl(%73) targets (%arg32 = %86) {
      %336 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %336 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %87 = qco.rz(%cst_0) %targets_out_9 : !qco.qubit -> !qco.qubit
    %88 = qco.rx(%cst_4) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_2) %controls_out : !qco.qubit -> !qco.qubit
    %91 = qco.rx(%cst_4) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_1) %91 : !qco.qubit -> !qco.qubit
    %controls_out_10, %targets_out_11 = qco.ctrl(%89) targets (%arg32 = %92) {
      %336 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %336 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %93 = qco.rz(%cst_0) %targets_out_11 : !qco.qubit -> !qco.qubit
    %94 = qco.rx(%cst_4) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst) %94 : !qco.qubit -> !qco.qubit
    %96 = arith.divf %arg8, %cst_3 : f64
    %97 = math.tan %96 : f64
    %98 = math.atan %97 : f64
    %99 = arith.mulf %98, %cst_3 : f64
    %100 = qco.rx(%cst_4) %controls_out_6 : !qco.qubit -> !qco.qubit
    %101 = arith.addf %99, %cst_5 : f64
    %102 = qco.rz(%101) %100 : !qco.qubit -> !qco.qubit
    %103 = qco.rx(%cst_4) %102 : !qco.qubit -> !qco.qubit
    %104 = arith.divf %arg9, %cst_3 : f64
    %105 = math.tan %104 : f64
    %106 = math.atan %105 : f64
    %107 = arith.mulf %106, %cst_3 : f64
    %108 = qco.rx(%cst_4) %controls_out_8 : !qco.qubit -> !qco.qubit
    %109 = arith.addf %107, %cst_5 : f64
    %110 = qco.rz(%109) %108 : !qco.qubit -> !qco.qubit
    %111 = qco.rx(%cst_4) %110 : !qco.qubit -> !qco.qubit
    %112 = arith.divf %arg10, %cst_3 : f64
    %113 = math.tan %112 : f64
    %114 = math.atan %113 : f64
    %115 = arith.mulf %114, %cst_3 : f64
    %116 = qco.rx(%cst_4) %controls_out_10 : !qco.qubit -> !qco.qubit
    %117 = arith.addf %115, %cst_5 : f64
    %118 = qco.rz(%117) %116 : !qco.qubit -> !qco.qubit
    %119 = qco.rx(%cst_4) %118 : !qco.qubit -> !qco.qubit
    %120 = arith.divf %arg11, %cst_3 : f64
    %121 = math.tan %120 : f64
    %122 = math.atan %121 : f64
    %123 = arith.mulf %122, %cst_3 : f64
    %124 = qco.rx(%cst_4) %95 : !qco.qubit -> !qco.qubit
    %125 = arith.addf %123, %cst_5 : f64
    %126 = qco.rz(%125) %124 : !qco.qubit -> !qco.qubit
    %127 = qco.rx(%cst_4) %126 : !qco.qubit -> !qco.qubit
    %128 = arith.divf %arg15, %cst_3 : f64
    %129 = math.tan %128 : f64
    %130 = math.atan %129 : f64
    %131 = arith.mulf %130, %cst_3 : f64
    %132 = arith.addf %131, %cst_5 : f64
    %133 = qco.rz(%132) %127 : !qco.qubit -> !qco.qubit
    %134 = arith.divf %arg12, %cst_3 : f64
    %135 = math.tan %134 : f64
    %136 = math.atan %135 : f64
    %137 = arith.mulf %136, %cst_3 : f64
    %138 = arith.addf %137, %cst_2 : f64
    %139 = arith.divf %138, %cst_3 : f64
    %140 = math.tan %139 : f64
    %141 = math.atan %140 : f64
    %142 = arith.mulf %141, %cst_3 : f64
    %143 = arith.addf %142, %cst_5 : f64
    %144 = qco.rz(%143) %103 : !qco.qubit -> !qco.qubit
    %145 = qco.rx(%cst_4) %144 : !qco.qubit -> !qco.qubit
    %146 = qco.rz(%cst_1) %145 : !qco.qubit -> !qco.qubit
    %controls_out_12, %targets_out_13 = qco.ctrl(%133) targets (%arg32 = %146) {
      %336 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %336 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %147 = qco.rz(%cst_0) %targets_out_13 : !qco.qubit -> !qco.qubit
    %148 = qco.rx(%cst_4) %147 : !qco.qubit -> !qco.qubit
    %149 = qco.rz(%cst) %148 : !qco.qubit -> !qco.qubit
    %150 = arith.divf %arg13, %cst_3 : f64
    %151 = math.tan %150 : f64
    %152 = math.atan %151 : f64
    %153 = arith.mulf %152, %cst_3 : f64
    %154 = arith.addf %153, %cst_2 : f64
    %155 = arith.divf %154, %cst_3 : f64
    %156 = math.tan %155 : f64
    %157 = math.atan %156 : f64
    %158 = arith.mulf %157, %cst_3 : f64
    %159 = arith.addf %158, %cst_5 : f64
    %160 = qco.rz(%159) %111 : !qco.qubit -> !qco.qubit
    %161 = qco.rx(%cst_4) %160 : !qco.qubit -> !qco.qubit
    %162 = qco.rz(%cst_1) %161 : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%149) targets (%arg32 = %162) {
      %336 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %336 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %163 = qco.rz(%cst_0) %targets_out_15 : !qco.qubit -> !qco.qubit
    %164 = qco.rx(%cst_4) %163 : !qco.qubit -> !qco.qubit
    %165 = qco.rz(%cst) %164 : !qco.qubit -> !qco.qubit
    %166 = arith.divf %arg14, %cst_3 : f64
    %167 = math.tan %166 : f64
    %168 = math.atan %167 : f64
    %169 = arith.mulf %168, %cst_3 : f64
    %170 = arith.addf %169, %cst_2 : f64
    %171 = arith.divf %170, %cst_3 : f64
    %172 = math.tan %171 : f64
    %173 = math.atan %172 : f64
    %174 = arith.mulf %173, %cst_3 : f64
    %175 = arith.addf %174, %cst_5 : f64
    %176 = qco.rz(%175) %119 : !qco.qubit -> !qco.qubit
    %177 = qco.rx(%cst_4) %176 : !qco.qubit -> !qco.qubit
    %178 = qco.rz(%cst_1) %177 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%165) targets (%arg32 = %178) {
      %336 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %336 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %179 = qco.rz(%cst_0) %targets_out_17 : !qco.qubit -> !qco.qubit
    %180 = qco.rx(%cst_4) %179 : !qco.qubit -> !qco.qubit
    %181 = qco.rz(%cst) %180 : !qco.qubit -> !qco.qubit
    %182 = qco.rz(%cst_2) %controls_out_12 : !qco.qubit -> !qco.qubit
    %183 = qco.rx(%cst_4) %182 : !qco.qubit -> !qco.qubit
    %184 = qco.rz(%cst_1) %183 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%181) targets (%arg32 = %184) {
      %336 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %336 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %185 = qco.rz(%cst_0) %targets_out_19 : !qco.qubit -> !qco.qubit
    %186 = qco.rx(%cst_4) %185 : !qco.qubit -> !qco.qubit
    %187 = qco.rz(%cst) %186 : !qco.qubit -> !qco.qubit
    %188 = arith.divf %arg16, %cst_3 : f64
    %189 = math.tan %188 : f64
    %190 = math.atan %189 : f64
    %191 = arith.mulf %190, %cst_3 : f64
    %192 = qco.rx(%cst_4) %controls_out_14 : !qco.qubit -> !qco.qubit
    %193 = arith.addf %191, %cst_5 : f64
    %194 = qco.rz(%193) %192 : !qco.qubit -> !qco.qubit
    %195 = qco.rx(%cst_4) %194 : !qco.qubit -> !qco.qubit
    %196 = arith.divf %arg17, %cst_3 : f64
    %197 = math.tan %196 : f64
    %198 = math.atan %197 : f64
    %199 = arith.mulf %198, %cst_3 : f64
    %200 = qco.rx(%cst_4) %controls_out_16 : !qco.qubit -> !qco.qubit
    %201 = arith.addf %199, %cst_5 : f64
    %202 = qco.rz(%201) %200 : !qco.qubit -> !qco.qubit
    %203 = qco.rx(%cst_4) %202 : !qco.qubit -> !qco.qubit
    %204 = arith.divf %arg18, %cst_3 : f64
    %205 = math.tan %204 : f64
    %206 = math.atan %205 : f64
    %207 = arith.mulf %206, %cst_3 : f64
    %208 = qco.rx(%cst_4) %controls_out_18 : !qco.qubit -> !qco.qubit
    %209 = arith.addf %207, %cst_5 : f64
    %210 = qco.rz(%209) %208 : !qco.qubit -> !qco.qubit
    %211 = qco.rx(%cst_4) %210 : !qco.qubit -> !qco.qubit
    %212 = arith.divf %arg19, %cst_3 : f64
    %213 = math.tan %212 : f64
    %214 = math.atan %213 : f64
    %215 = arith.mulf %214, %cst_3 : f64
    %216 = qco.rx(%cst_4) %187 : !qco.qubit -> !qco.qubit
    %217 = arith.addf %215, %cst_5 : f64
    %218 = qco.rz(%217) %216 : !qco.qubit -> !qco.qubit
    %219 = qco.rx(%cst_4) %218 : !qco.qubit -> !qco.qubit
    %220 = arith.divf %arg23, %cst_3 : f64
    %221 = math.tan %220 : f64
    %222 = math.atan %221 : f64
    %223 = arith.mulf %222, %cst_3 : f64
    %224 = arith.addf %223, %cst_5 : f64
    %225 = qco.rz(%224) %219 : !qco.qubit -> !qco.qubit
    %226 = arith.divf %arg20, %cst_3 : f64
    %227 = math.tan %226 : f64
    %228 = math.atan %227 : f64
    %229 = arith.mulf %228, %cst_3 : f64
    %230 = arith.addf %229, %cst_2 : f64
    %231 = arith.divf %230, %cst_3 : f64
    %232 = math.tan %231 : f64
    %233 = math.atan %232 : f64
    %234 = arith.mulf %233, %cst_3 : f64
    %235 = arith.addf %234, %cst_5 : f64
    %236 = qco.rz(%235) %195 : !qco.qubit -> !qco.qubit
    %237 = qco.rx(%cst_4) %236 : !qco.qubit -> !qco.qubit
    %238 = qco.rz(%cst_1) %237 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%225) targets (%arg32 = %238) {
      %336 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %336 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %239 = qco.rz(%cst_0) %targets_out_21 : !qco.qubit -> !qco.qubit
    %240 = qco.rx(%cst_4) %239 : !qco.qubit -> !qco.qubit
    %241 = qco.rz(%cst) %240 : !qco.qubit -> !qco.qubit
    %242 = arith.divf %arg21, %cst_3 : f64
    %243 = math.tan %242 : f64
    %244 = math.atan %243 : f64
    %245 = arith.mulf %244, %cst_3 : f64
    %246 = arith.addf %245, %cst_2 : f64
    %247 = arith.divf %246, %cst_3 : f64
    %248 = math.tan %247 : f64
    %249 = math.atan %248 : f64
    %250 = arith.mulf %249, %cst_3 : f64
    %251 = arith.addf %250, %cst_5 : f64
    %252 = qco.rz(%251) %203 : !qco.qubit -> !qco.qubit
    %253 = qco.rx(%cst_4) %252 : !qco.qubit -> !qco.qubit
    %254 = qco.rz(%cst_1) %253 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%241) targets (%arg32 = %254) {
      %336 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %336 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %255 = qco.rz(%cst_0) %targets_out_23 : !qco.qubit -> !qco.qubit
    %256 = qco.rx(%cst_4) %255 : !qco.qubit -> !qco.qubit
    %257 = qco.rz(%cst) %256 : !qco.qubit -> !qco.qubit
    %258 = arith.divf %arg22, %cst_3 : f64
    %259 = math.tan %258 : f64
    %260 = math.atan %259 : f64
    %261 = arith.mulf %260, %cst_3 : f64
    %262 = arith.addf %261, %cst_2 : f64
    %263 = arith.divf %262, %cst_3 : f64
    %264 = math.tan %263 : f64
    %265 = math.atan %264 : f64
    %266 = arith.mulf %265, %cst_3 : f64
    %267 = arith.addf %266, %cst_5 : f64
    %268 = qco.rz(%267) %211 : !qco.qubit -> !qco.qubit
    %269 = qco.rx(%cst_4) %268 : !qco.qubit -> !qco.qubit
    %270 = qco.rz(%cst_1) %269 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%257) targets (%arg32 = %270) {
      %336 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %336 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %271 = qco.rz(%cst_0) %targets_out_25 : !qco.qubit -> !qco.qubit
    %272 = qco.rx(%cst_4) %271 : !qco.qubit -> !qco.qubit
    %273 = qco.rz(%cst) %272 : !qco.qubit -> !qco.qubit
    %274 = qco.rz(%cst_2) %controls_out_20 : !qco.qubit -> !qco.qubit
    %275 = qco.rx(%cst_4) %274 : !qco.qubit -> !qco.qubit
    %276 = qco.rz(%cst_1) %275 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%273) targets (%arg32 = %276) {
      %336 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %336 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %277 = qco.rz(%cst_0) %targets_out_27 : !qco.qubit -> !qco.qubit
    %278 = qco.rx(%cst_4) %277 : !qco.qubit -> !qco.qubit
    %279 = qco.rz(%cst) %278 : !qco.qubit -> !qco.qubit
    %280 = arith.divf %arg24, %cst_3 : f64
    %281 = math.tan %280 : f64
    %282 = math.atan %281 : f64
    %283 = arith.mulf %282, %cst_3 : f64
    %284 = qco.rx(%cst_4) %controls_out_22 : !qco.qubit -> !qco.qubit
    %285 = arith.addf %283, %cst_5 : f64
    %286 = qco.rz(%285) %284 : !qco.qubit -> !qco.qubit
    %287 = qco.rx(%cst_4) %286 : !qco.qubit -> !qco.qubit
    %288 = arith.divf %arg25, %cst_3 : f64
    %289 = math.tan %288 : f64
    %290 = math.atan %289 : f64
    %291 = arith.mulf %290, %cst_3 : f64
    %292 = qco.rx(%cst_4) %controls_out_24 : !qco.qubit -> !qco.qubit
    %293 = arith.addf %291, %cst_5 : f64
    %294 = qco.rz(%293) %292 : !qco.qubit -> !qco.qubit
    %295 = qco.rx(%cst_4) %294 : !qco.qubit -> !qco.qubit
    %296 = arith.divf %arg26, %cst_3 : f64
    %297 = math.tan %296 : f64
    %298 = math.atan %297 : f64
    %299 = arith.mulf %298, %cst_3 : f64
    %300 = qco.rx(%cst_4) %controls_out_26 : !qco.qubit -> !qco.qubit
    %301 = arith.addf %299, %cst_5 : f64
    %302 = qco.rz(%301) %300 : !qco.qubit -> !qco.qubit
    %303 = qco.rx(%cst_4) %302 : !qco.qubit -> !qco.qubit
    %304 = arith.divf %arg27, %cst_3 : f64
    %305 = math.tan %304 : f64
    %306 = math.atan %305 : f64
    %307 = arith.mulf %306, %cst_3 : f64
    %308 = qco.rx(%cst_4) %279 : !qco.qubit -> !qco.qubit
    %309 = arith.addf %307, %cst_5 : f64
    %310 = qco.rz(%309) %308 : !qco.qubit -> !qco.qubit
    %311 = qco.rx(%cst_4) %310 : !qco.qubit -> !qco.qubit
    %312 = arith.divf %arg28, %cst_3 : f64
    %313 = math.tan %312 : f64
    %314 = math.atan %313 : f64
    %315 = arith.mulf %314, %cst_3 : f64
    %316 = arith.addf %315, %cst_5 : f64
    %317 = qco.rz(%316) %287 : !qco.qubit -> !qco.qubit
    %318 = arith.divf %arg29, %cst_3 : f64
    %319 = math.tan %318 : f64
    %320 = math.atan %319 : f64
    %321 = arith.mulf %320, %cst_3 : f64
    %322 = arith.addf %321, %cst_5 : f64
    %323 = qco.rz(%322) %295 : !qco.qubit -> !qco.qubit
    %324 = arith.divf %arg30, %cst_3 : f64
    %325 = math.tan %324 : f64
    %326 = math.atan %325 : f64
    %327 = arith.mulf %326, %cst_3 : f64
    %328 = arith.addf %327, %cst_5 : f64
    %329 = qco.rz(%328) %303 : !qco.qubit -> !qco.qubit
    qco.sink %317 : !qco.qubit
    qco.sink %323 : !qco.qubit
    qco.sink %329 : !qco.qubit
    %330 = arith.divf %arg31, %cst_3 : f64
    %331 = math.tan %330 : f64
    %332 = math.atan %331 : f64
    %333 = arith.mulf %332, %cst_3 : f64
    %334 = arith.addf %333, %cst_5 : f64
    %335 = qco.rz(%334) %311 : !qco.qubit -> !qco.qubit
    qco.sink %335 : !qco.qubit
    return %c0_i64 : i64
  }
}
