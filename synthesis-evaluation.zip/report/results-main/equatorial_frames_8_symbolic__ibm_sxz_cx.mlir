module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main(%arg0: f64 {mqt.input_id = 16309916367715198394276235805800677067 : i128, mqt.input_name = "theta[0]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 0 : i64, name = "theta", size = 24 : i64}}, %arg1: f64 {mqt.input_id = 16309916367715198394276235805800677068 : i128, mqt.input_name = "theta[1]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 1 : i64, name = "theta", size = 24 : i64}}, %arg2: f64 {mqt.input_id = 16309916367715198394276235805800677069 : i128, mqt.input_name = "theta[2]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 2 : i64, name = "theta", size = 24 : i64}}, %arg3: f64 {mqt.input_id = 16309916367715198394276235805800677070 : i128, mqt.input_name = "theta[3]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 3 : i64, name = "theta", size = 24 : i64}}, %arg4: f64 {mqt.input_id = 16309916367715198394276235805800677071 : i128, mqt.input_name = "theta[4]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 4 : i64, name = "theta", size = 24 : i64}}, %arg5: f64 {mqt.input_id = 16309916367715198394276235805800677072 : i128, mqt.input_name = "theta[5]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 5 : i64, name = "theta", size = 24 : i64}}, %arg6: f64 {mqt.input_id = 16309916367715198394276235805800677073 : i128, mqt.input_name = "theta[6]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 6 : i64, name = "theta", size = 24 : i64}}, %arg7: f64 {mqt.input_id = 16309916367715198394276235805800677074 : i128, mqt.input_name = "theta[7]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 7 : i64, name = "theta", size = 24 : i64}}, %arg8: f64 {mqt.input_id = 16309916367715198394276235805800677075 : i128, mqt.input_name = "theta[8]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 8 : i64, name = "theta", size = 24 : i64}}, %arg9: f64 {mqt.input_id = 16309916367715198394276235805800677076 : i128, mqt.input_name = "theta[9]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 9 : i64, name = "theta", size = 24 : i64}}, %arg10: f64 {mqt.input_id = 16309916367715198394276235805800677077 : i128, mqt.input_name = "theta[10]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 10 : i64, name = "theta", size = 24 : i64}}, %arg11: f64 {mqt.input_id = 16309916367715198394276235805800677078 : i128, mqt.input_name = "theta[11]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 11 : i64, name = "theta", size = 24 : i64}}, %arg12: f64 {mqt.input_id = 16309916367715198394276235805800677079 : i128, mqt.input_name = "theta[12]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 12 : i64, name = "theta", size = 24 : i64}}, %arg13: f64 {mqt.input_id = 16309916367715198394276235805800677080 : i128, mqt.input_name = "theta[13]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 13 : i64, name = "theta", size = 24 : i64}}, %arg14: f64 {mqt.input_id = 16309916367715198394276235805800677081 : i128, mqt.input_name = "theta[14]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 14 : i64, name = "theta", size = 24 : i64}}, %arg15: f64 {mqt.input_id = 16309916367715198394276235805800677082 : i128, mqt.input_name = "theta[15]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 15 : i64, name = "theta", size = 24 : i64}}, %arg16: f64 {mqt.input_id = 16309916367715198394276235805800677083 : i128, mqt.input_name = "theta[16]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 16 : i64, name = "theta", size = 24 : i64}}, %arg17: f64 {mqt.input_id = 16309916367715198394276235805800677084 : i128, mqt.input_name = "theta[17]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 17 : i64, name = "theta", size = 24 : i64}}, %arg18: f64 {mqt.input_id = 16309916367715198394276235805800677085 : i128, mqt.input_name = "theta[18]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 18 : i64, name = "theta", size = 24 : i64}}, %arg19: f64 {mqt.input_id = 16309916367715198394276235805800677086 : i128, mqt.input_name = "theta[19]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 19 : i64, name = "theta", size = 24 : i64}}, %arg20: f64 {mqt.input_id = 16309916367715198394276235805800677087 : i128, mqt.input_name = "theta[20]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 20 : i64, name = "theta", size = 24 : i64}}, %arg21: f64 {mqt.input_id = 16309916367715198394276235805800677088 : i128, mqt.input_name = "theta[21]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 21 : i64, name = "theta", size = 24 : i64}}, %arg22: f64 {mqt.input_id = 16309916367715198394276235805800677089 : i128, mqt.input_name = "theta[22]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 22 : i64, name = "theta", size = 24 : i64}}, %arg23: f64 {mqt.input_id = 16309916367715198394276235805800677090 : i128, mqt.input_name = "theta[23]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 23 : i64, name = "theta", size = 24 : i64}}) -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948966 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant 1.5707963267948968 : f64
    %cst_2 = arith.constant -1.5707963267948963 : f64
    %cst_3 = arith.constant 1.7707963267948965 : f64
    %cst_4 = arith.constant 3.4415926535897929 : f64
    %cst_5 = arith.constant 1.3707963267948966 : f64
    %cst_6 = arith.constant 4.000000e+00 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = arith.divf %arg0, %cst_6 : f64
    %9 = math.tan %8 : f64
    %10 = math.atan %9 : f64
    %11 = arith.mulf %10, %cst_6 : f64
    %12 = arith.addf %11, %cst_5 : f64
    %13 = qco.rz(%12) %0 : !qco.qubit -> !qco.qubit
    %14 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_4) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_3) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_2) %1 : !qco.qubit -> !qco.qubit
    %19 = qco.sx %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_1) %19 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%17) targets (%arg24 = %20) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.rz(%cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %22 = qco.sx %21 : !qco.qubit -> !qco.qubit
    %23 = arith.divf %arg1, %cst_6 : f64
    %24 = math.tan %23 : f64
    %25 = math.atan %24 : f64
    %26 = arith.mulf %25, %cst_6 : f64
    %27 = arith.addf %26, %cst_5 : f64
    %28 = arith.divf %27, %cst_6 : f64
    %29 = math.tan %28 : f64
    %30 = math.atan %29 : f64
    %31 = arith.mulf %30, %cst_6 : f64
    %32 = arith.addf %31, %cst : f64
    %33 = qco.rz(%32) %22 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_4) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.sx %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_3) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_2) %2 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_1) %39 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%37) targets (%arg24 = %40) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.rz(%cst_0) %targets_out_8 : !qco.qubit -> !qco.qubit
    %42 = qco.sx %41 : !qco.qubit -> !qco.qubit
    %43 = arith.divf %arg2, %cst_6 : f64
    %44 = math.tan %43 : f64
    %45 = math.atan %44 : f64
    %46 = arith.mulf %45, %cst_6 : f64
    %47 = arith.addf %46, %cst_5 : f64
    %48 = arith.divf %47, %cst_6 : f64
    %49 = math.tan %48 : f64
    %50 = math.atan %49 : f64
    %51 = arith.mulf %50, %cst_6 : f64
    %52 = arith.addf %51, %cst : f64
    %53 = qco.rz(%52) %42 : !qco.qubit -> !qco.qubit
    %54 = qco.sx %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_4) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.sx %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_3) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_2) %3 : !qco.qubit -> !qco.qubit
    %59 = qco.sx %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_1) %59 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%57) targets (%arg24 = %60) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qco.rz(%cst_0) %targets_out_10 : !qco.qubit -> !qco.qubit
    %62 = qco.sx %61 : !qco.qubit -> !qco.qubit
    %63 = arith.divf %arg3, %cst_6 : f64
    %64 = math.tan %63 : f64
    %65 = math.atan %64 : f64
    %66 = arith.mulf %65, %cst_6 : f64
    %67 = arith.addf %66, %cst_5 : f64
    %68 = arith.divf %67, %cst_6 : f64
    %69 = math.tan %68 : f64
    %70 = math.atan %69 : f64
    %71 = arith.mulf %70, %cst_6 : f64
    %72 = arith.addf %71, %cst : f64
    %73 = qco.rz(%72) %62 : !qco.qubit -> !qco.qubit
    %74 = qco.sx %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_4) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.sx %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_3) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_2) %4 : !qco.qubit -> !qco.qubit
    %79 = qco.sx %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_1) %79 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%77) targets (%arg24 = %80) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %81 = qco.rz(%cst_0) %targets_out_12 : !qco.qubit -> !qco.qubit
    %82 = qco.sx %81 : !qco.qubit -> !qco.qubit
    %83 = arith.divf %arg4, %cst_6 : f64
    %84 = math.tan %83 : f64
    %85 = math.atan %84 : f64
    %86 = arith.mulf %85, %cst_6 : f64
    %87 = arith.addf %86, %cst_5 : f64
    %88 = arith.divf %87, %cst_6 : f64
    %89 = math.tan %88 : f64
    %90 = math.atan %89 : f64
    %91 = arith.mulf %90, %cst_6 : f64
    %92 = arith.addf %91, %cst : f64
    %93 = qco.rz(%92) %82 : !qco.qubit -> !qco.qubit
    %94 = qco.sx %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_4) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.sx %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_3) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_2) %5 : !qco.qubit -> !qco.qubit
    %99 = qco.sx %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_1) %99 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%97) targets (%arg24 = %100) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %101 = qco.rz(%cst_0) %targets_out_14 : !qco.qubit -> !qco.qubit
    %102 = qco.sx %101 : !qco.qubit -> !qco.qubit
    %103 = arith.divf %arg5, %cst_6 : f64
    %104 = math.tan %103 : f64
    %105 = math.atan %104 : f64
    %106 = arith.mulf %105, %cst_6 : f64
    %107 = arith.addf %106, %cst_5 : f64
    %108 = arith.divf %107, %cst_6 : f64
    %109 = math.tan %108 : f64
    %110 = math.atan %109 : f64
    %111 = arith.mulf %110, %cst_6 : f64
    %112 = arith.addf %111, %cst : f64
    %113 = qco.rz(%112) %102 : !qco.qubit -> !qco.qubit
    %114 = qco.sx %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_4) %114 : !qco.qubit -> !qco.qubit
    %116 = qco.sx %115 : !qco.qubit -> !qco.qubit
    %117 = qco.rz(%cst_3) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_2) %6 : !qco.qubit -> !qco.qubit
    %119 = qco.sx %118 : !qco.qubit -> !qco.qubit
    %120 = qco.rz(%cst_1) %119 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%117) targets (%arg24 = %120) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %121 = qco.rz(%cst_0) %targets_out_16 : !qco.qubit -> !qco.qubit
    %122 = qco.sx %121 : !qco.qubit -> !qco.qubit
    %123 = arith.divf %arg6, %cst_6 : f64
    %124 = math.tan %123 : f64
    %125 = math.atan %124 : f64
    %126 = arith.mulf %125, %cst_6 : f64
    %127 = arith.addf %126, %cst_5 : f64
    %128 = arith.divf %127, %cst_6 : f64
    %129 = math.tan %128 : f64
    %130 = math.atan %129 : f64
    %131 = arith.mulf %130, %cst_6 : f64
    %132 = arith.addf %131, %cst : f64
    %133 = qco.rz(%132) %122 : !qco.qubit -> !qco.qubit
    %134 = qco.sx %133 : !qco.qubit -> !qco.qubit
    %135 = qco.rz(%cst_4) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.sx %135 : !qco.qubit -> !qco.qubit
    %137 = qco.rz(%cst_3) %136 : !qco.qubit -> !qco.qubit
    %138 = qco.rz(%cst_2) %7 : !qco.qubit -> !qco.qubit
    %139 = qco.sx %138 : !qco.qubit -> !qco.qubit
    %140 = qco.rz(%cst_1) %139 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%137) targets (%arg24 = %140) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %141 = qco.rz(%cst_0) %targets_out_18 : !qco.qubit -> !qco.qubit
    %142 = qco.sx %141 : !qco.qubit -> !qco.qubit
    %143 = arith.divf %arg7, %cst_6 : f64
    %144 = math.tan %143 : f64
    %145 = math.atan %144 : f64
    %146 = arith.mulf %145, %cst_6 : f64
    %147 = arith.addf %146, %cst_5 : f64
    %148 = arith.divf %147, %cst_6 : f64
    %149 = math.tan %148 : f64
    %150 = math.atan %149 : f64
    %151 = arith.mulf %150, %cst_6 : f64
    %152 = arith.addf %151, %cst : f64
    %153 = qco.rz(%152) %142 : !qco.qubit -> !qco.qubit
    %154 = qco.sx %153 : !qco.qubit -> !qco.qubit
    %155 = qco.rz(%cst_4) %154 : !qco.qubit -> !qco.qubit
    %156 = qco.sx %155 : !qco.qubit -> !qco.qubit
    %157 = qco.rz(%cst_3) %156 : !qco.qubit -> !qco.qubit
    %158 = qco.rz(%cst_2) %controls_out : !qco.qubit -> !qco.qubit
    %159 = qco.sx %158 : !qco.qubit -> !qco.qubit
    %160 = qco.rz(%cst_1) %159 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%157) targets (%arg24 = %160) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %161 = qco.rz(%cst_0) %targets_out_20 : !qco.qubit -> !qco.qubit
    %162 = qco.sx %161 : !qco.qubit -> !qco.qubit
    %163 = arith.divf %arg8, %cst_6 : f64
    %164 = math.tan %163 : f64
    %165 = math.atan %164 : f64
    %166 = arith.mulf %165, %cst_6 : f64
    %167 = arith.addf %166, %cst_5 : f64
    %168 = arith.divf %167, %cst_6 : f64
    %169 = math.tan %168 : f64
    %170 = math.atan %169 : f64
    %171 = arith.mulf %170, %cst_6 : f64
    %172 = arith.addf %171, %cst : f64
    %173 = qco.rz(%172) %162 : !qco.qubit -> !qco.qubit
    %174 = qco.sx %173 : !qco.qubit -> !qco.qubit
    %175 = qco.rz(%cst_4) %174 : !qco.qubit -> !qco.qubit
    %176 = qco.sx %175 : !qco.qubit -> !qco.qubit
    %177 = qco.rz(%cst_3) %176 : !qco.qubit -> !qco.qubit
    %178 = qco.rz(%cst_2) %controls_out_7 : !qco.qubit -> !qco.qubit
    %179 = qco.sx %178 : !qco.qubit -> !qco.qubit
    %180 = qco.rz(%cst_1) %179 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%177) targets (%arg24 = %180) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %181 = qco.rz(%cst_0) %targets_out_22 : !qco.qubit -> !qco.qubit
    %182 = qco.sx %181 : !qco.qubit -> !qco.qubit
    %183 = arith.divf %arg9, %cst_6 : f64
    %184 = math.tan %183 : f64
    %185 = math.atan %184 : f64
    %186 = arith.mulf %185, %cst_6 : f64
    %187 = arith.addf %186, %cst_5 : f64
    %188 = arith.divf %187, %cst_6 : f64
    %189 = math.tan %188 : f64
    %190 = math.atan %189 : f64
    %191 = arith.mulf %190, %cst_6 : f64
    %192 = arith.addf %191, %cst : f64
    %193 = qco.rz(%192) %182 : !qco.qubit -> !qco.qubit
    %194 = qco.sx %193 : !qco.qubit -> !qco.qubit
    %195 = qco.rz(%cst_4) %194 : !qco.qubit -> !qco.qubit
    %196 = qco.sx %195 : !qco.qubit -> !qco.qubit
    %197 = qco.rz(%cst_3) %196 : !qco.qubit -> !qco.qubit
    %198 = qco.rz(%cst_2) %controls_out_9 : !qco.qubit -> !qco.qubit
    %199 = qco.sx %198 : !qco.qubit -> !qco.qubit
    %200 = qco.rz(%cst_1) %199 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%197) targets (%arg24 = %200) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %201 = qco.rz(%cst_0) %targets_out_24 : !qco.qubit -> !qco.qubit
    %202 = qco.sx %201 : !qco.qubit -> !qco.qubit
    %203 = arith.divf %arg10, %cst_6 : f64
    %204 = math.tan %203 : f64
    %205 = math.atan %204 : f64
    %206 = arith.mulf %205, %cst_6 : f64
    %207 = arith.addf %206, %cst_5 : f64
    %208 = arith.divf %207, %cst_6 : f64
    %209 = math.tan %208 : f64
    %210 = math.atan %209 : f64
    %211 = arith.mulf %210, %cst_6 : f64
    %212 = arith.addf %211, %cst : f64
    %213 = qco.rz(%212) %202 : !qco.qubit -> !qco.qubit
    %214 = qco.sx %213 : !qco.qubit -> !qco.qubit
    %215 = qco.rz(%cst_4) %214 : !qco.qubit -> !qco.qubit
    %216 = qco.sx %215 : !qco.qubit -> !qco.qubit
    %217 = qco.rz(%cst_3) %216 : !qco.qubit -> !qco.qubit
    %218 = qco.rz(%cst_2) %controls_out_11 : !qco.qubit -> !qco.qubit
    %219 = qco.sx %218 : !qco.qubit -> !qco.qubit
    %220 = qco.rz(%cst_1) %219 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%217) targets (%arg24 = %220) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %221 = qco.rz(%cst_0) %targets_out_26 : !qco.qubit -> !qco.qubit
    %222 = qco.sx %221 : !qco.qubit -> !qco.qubit
    %223 = arith.divf %arg11, %cst_6 : f64
    %224 = math.tan %223 : f64
    %225 = math.atan %224 : f64
    %226 = arith.mulf %225, %cst_6 : f64
    %227 = arith.addf %226, %cst_5 : f64
    %228 = arith.divf %227, %cst_6 : f64
    %229 = math.tan %228 : f64
    %230 = math.atan %229 : f64
    %231 = arith.mulf %230, %cst_6 : f64
    %232 = arith.addf %231, %cst : f64
    %233 = qco.rz(%232) %222 : !qco.qubit -> !qco.qubit
    %234 = qco.sx %233 : !qco.qubit -> !qco.qubit
    %235 = qco.rz(%cst_4) %234 : !qco.qubit -> !qco.qubit
    %236 = qco.sx %235 : !qco.qubit -> !qco.qubit
    %237 = qco.rz(%cst_3) %236 : !qco.qubit -> !qco.qubit
    %238 = qco.rz(%cst_2) %controls_out_13 : !qco.qubit -> !qco.qubit
    %239 = qco.sx %238 : !qco.qubit -> !qco.qubit
    %240 = qco.rz(%cst_1) %239 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%237) targets (%arg24 = %240) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %241 = qco.rz(%cst_0) %targets_out_28 : !qco.qubit -> !qco.qubit
    %242 = qco.sx %241 : !qco.qubit -> !qco.qubit
    %243 = arith.divf %arg12, %cst_6 : f64
    %244 = math.tan %243 : f64
    %245 = math.atan %244 : f64
    %246 = arith.mulf %245, %cst_6 : f64
    %247 = arith.addf %246, %cst_5 : f64
    %248 = arith.divf %247, %cst_6 : f64
    %249 = math.tan %248 : f64
    %250 = math.atan %249 : f64
    %251 = arith.mulf %250, %cst_6 : f64
    %252 = arith.addf %251, %cst : f64
    %253 = qco.rz(%252) %242 : !qco.qubit -> !qco.qubit
    %254 = qco.sx %253 : !qco.qubit -> !qco.qubit
    %255 = qco.rz(%cst_4) %254 : !qco.qubit -> !qco.qubit
    %256 = qco.sx %255 : !qco.qubit -> !qco.qubit
    %257 = qco.rz(%cst_3) %256 : !qco.qubit -> !qco.qubit
    %258 = qco.rz(%cst_2) %controls_out_15 : !qco.qubit -> !qco.qubit
    %259 = qco.sx %258 : !qco.qubit -> !qco.qubit
    %260 = qco.rz(%cst_1) %259 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%257) targets (%arg24 = %260) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %261 = qco.rz(%cst_0) %targets_out_30 : !qco.qubit -> !qco.qubit
    %262 = qco.sx %261 : !qco.qubit -> !qco.qubit
    %263 = arith.divf %arg13, %cst_6 : f64
    %264 = math.tan %263 : f64
    %265 = math.atan %264 : f64
    %266 = arith.mulf %265, %cst_6 : f64
    %267 = arith.addf %266, %cst_5 : f64
    %268 = arith.divf %267, %cst_6 : f64
    %269 = math.tan %268 : f64
    %270 = math.atan %269 : f64
    %271 = arith.mulf %270, %cst_6 : f64
    %272 = arith.addf %271, %cst : f64
    %273 = qco.rz(%272) %262 : !qco.qubit -> !qco.qubit
    %274 = qco.sx %273 : !qco.qubit -> !qco.qubit
    %275 = qco.rz(%cst_4) %274 : !qco.qubit -> !qco.qubit
    %276 = qco.sx %275 : !qco.qubit -> !qco.qubit
    %277 = qco.rz(%cst_3) %276 : !qco.qubit -> !qco.qubit
    %278 = qco.rz(%cst_2) %controls_out_17 : !qco.qubit -> !qco.qubit
    %279 = qco.sx %278 : !qco.qubit -> !qco.qubit
    %280 = qco.rz(%cst_1) %279 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%277) targets (%arg24 = %280) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %281 = qco.rz(%cst_0) %targets_out_32 : !qco.qubit -> !qco.qubit
    %282 = qco.sx %281 : !qco.qubit -> !qco.qubit
    %283 = arith.divf %arg14, %cst_6 : f64
    %284 = math.tan %283 : f64
    %285 = math.atan %284 : f64
    %286 = arith.mulf %285, %cst_6 : f64
    %287 = arith.addf %286, %cst_5 : f64
    %288 = arith.divf %287, %cst_6 : f64
    %289 = math.tan %288 : f64
    %290 = math.atan %289 : f64
    %291 = arith.mulf %290, %cst_6 : f64
    %292 = arith.addf %291, %cst : f64
    %293 = qco.rz(%292) %282 : !qco.qubit -> !qco.qubit
    %294 = qco.sx %293 : !qco.qubit -> !qco.qubit
    %295 = qco.rz(%cst_4) %294 : !qco.qubit -> !qco.qubit
    %296 = qco.sx %295 : !qco.qubit -> !qco.qubit
    %297 = qco.rz(%cst_3) %296 : !qco.qubit -> !qco.qubit
    %298 = qco.rz(%cst_2) %controls_out_19 : !qco.qubit -> !qco.qubit
    %299 = qco.sx %298 : !qco.qubit -> !qco.qubit
    %300 = qco.rz(%cst_1) %299 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%297) targets (%arg24 = %300) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %301 = qco.rz(%cst_0) %targets_out_34 : !qco.qubit -> !qco.qubit
    %302 = qco.sx %301 : !qco.qubit -> !qco.qubit
    %303 = arith.divf %arg15, %cst_6 : f64
    %304 = math.tan %303 : f64
    %305 = math.atan %304 : f64
    %306 = arith.mulf %305, %cst_6 : f64
    %307 = arith.addf %306, %cst_5 : f64
    %308 = arith.divf %307, %cst_6 : f64
    %309 = math.tan %308 : f64
    %310 = math.atan %309 : f64
    %311 = arith.mulf %310, %cst_6 : f64
    %312 = arith.addf %311, %cst : f64
    %313 = qco.rz(%312) %302 : !qco.qubit -> !qco.qubit
    %314 = qco.sx %313 : !qco.qubit -> !qco.qubit
    %315 = qco.rz(%cst_4) %314 : !qco.qubit -> !qco.qubit
    %316 = qco.sx %315 : !qco.qubit -> !qco.qubit
    %317 = qco.rz(%cst_3) %316 : !qco.qubit -> !qco.qubit
    %318 = qco.rz(%cst_2) %controls_out_21 : !qco.qubit -> !qco.qubit
    %319 = qco.sx %318 : !qco.qubit -> !qco.qubit
    %320 = qco.rz(%cst_1) %319 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%317) targets (%arg24 = %320) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %321 = qco.rz(%cst_0) %targets_out_36 : !qco.qubit -> !qco.qubit
    %322 = qco.sx %321 : !qco.qubit -> !qco.qubit
    %323 = arith.divf %arg16, %cst_6 : f64
    %324 = math.tan %323 : f64
    %325 = math.atan %324 : f64
    %326 = arith.mulf %325, %cst_6 : f64
    %327 = arith.addf %326, %cst_5 : f64
    %328 = arith.divf %327, %cst_6 : f64
    %329 = math.tan %328 : f64
    %330 = math.atan %329 : f64
    %331 = arith.mulf %330, %cst_6 : f64
    %332 = arith.addf %331, %cst : f64
    %333 = qco.rz(%332) %322 : !qco.qubit -> !qco.qubit
    %334 = qco.sx %333 : !qco.qubit -> !qco.qubit
    %335 = qco.rz(%cst_4) %334 : !qco.qubit -> !qco.qubit
    %336 = qco.sx %335 : !qco.qubit -> !qco.qubit
    %337 = qco.rz(%cst_3) %336 : !qco.qubit -> !qco.qubit
    %338 = qco.rz(%cst_2) %controls_out_23 : !qco.qubit -> !qco.qubit
    %339 = qco.sx %338 : !qco.qubit -> !qco.qubit
    %340 = qco.rz(%cst_1) %339 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%337) targets (%arg24 = %340) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %341 = qco.rz(%cst_0) %targets_out_38 : !qco.qubit -> !qco.qubit
    %342 = qco.sx %341 : !qco.qubit -> !qco.qubit
    %343 = arith.divf %arg17, %cst_6 : f64
    %344 = math.tan %343 : f64
    %345 = math.atan %344 : f64
    %346 = arith.mulf %345, %cst_6 : f64
    %347 = arith.addf %346, %cst_5 : f64
    %348 = arith.divf %347, %cst_6 : f64
    %349 = math.tan %348 : f64
    %350 = math.atan %349 : f64
    %351 = arith.mulf %350, %cst_6 : f64
    %352 = arith.addf %351, %cst : f64
    %353 = qco.rz(%352) %342 : !qco.qubit -> !qco.qubit
    %354 = qco.sx %353 : !qco.qubit -> !qco.qubit
    %355 = qco.rz(%cst_4) %354 : !qco.qubit -> !qco.qubit
    %356 = qco.sx %355 : !qco.qubit -> !qco.qubit
    %357 = qco.rz(%cst_3) %356 : !qco.qubit -> !qco.qubit
    %358 = qco.rz(%cst_2) %controls_out_25 : !qco.qubit -> !qco.qubit
    %359 = qco.sx %358 : !qco.qubit -> !qco.qubit
    %360 = qco.rz(%cst_1) %359 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%357) targets (%arg24 = %360) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %361 = qco.rz(%cst_0) %targets_out_40 : !qco.qubit -> !qco.qubit
    %362 = qco.sx %361 : !qco.qubit -> !qco.qubit
    %363 = arith.divf %arg18, %cst_6 : f64
    %364 = math.tan %363 : f64
    %365 = math.atan %364 : f64
    %366 = arith.mulf %365, %cst_6 : f64
    %367 = arith.addf %366, %cst_5 : f64
    %368 = arith.divf %367, %cst_6 : f64
    %369 = math.tan %368 : f64
    %370 = math.atan %369 : f64
    %371 = arith.mulf %370, %cst_6 : f64
    %372 = arith.addf %371, %cst : f64
    %373 = qco.rz(%372) %362 : !qco.qubit -> !qco.qubit
    %374 = qco.sx %373 : !qco.qubit -> !qco.qubit
    %375 = qco.rz(%cst_4) %374 : !qco.qubit -> !qco.qubit
    %376 = qco.sx %375 : !qco.qubit -> !qco.qubit
    %377 = qco.rz(%cst_3) %376 : !qco.qubit -> !qco.qubit
    %378 = qco.rz(%cst_2) %controls_out_27 : !qco.qubit -> !qco.qubit
    %379 = qco.sx %378 : !qco.qubit -> !qco.qubit
    %380 = qco.rz(%cst_1) %379 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%377) targets (%arg24 = %380) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %381 = qco.rz(%cst_0) %targets_out_42 : !qco.qubit -> !qco.qubit
    %382 = qco.sx %381 : !qco.qubit -> !qco.qubit
    %383 = arith.divf %arg19, %cst_6 : f64
    %384 = math.tan %383 : f64
    %385 = math.atan %384 : f64
    %386 = arith.mulf %385, %cst_6 : f64
    %387 = arith.addf %386, %cst_5 : f64
    %388 = arith.divf %387, %cst_6 : f64
    %389 = math.tan %388 : f64
    %390 = math.atan %389 : f64
    %391 = arith.mulf %390, %cst_6 : f64
    %392 = arith.addf %391, %cst : f64
    %393 = qco.rz(%392) %382 : !qco.qubit -> !qco.qubit
    %394 = qco.sx %393 : !qco.qubit -> !qco.qubit
    %395 = qco.rz(%cst_4) %394 : !qco.qubit -> !qco.qubit
    %396 = qco.sx %395 : !qco.qubit -> !qco.qubit
    %397 = qco.rz(%cst_3) %396 : !qco.qubit -> !qco.qubit
    %398 = qco.rz(%cst_2) %controls_out_29 : !qco.qubit -> !qco.qubit
    %399 = qco.sx %398 : !qco.qubit -> !qco.qubit
    %400 = qco.rz(%cst_1) %399 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%397) targets (%arg24 = %400) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %401 = qco.rz(%cst_0) %targets_out_44 : !qco.qubit -> !qco.qubit
    %402 = qco.sx %401 : !qco.qubit -> !qco.qubit
    %403 = arith.divf %arg20, %cst_6 : f64
    %404 = math.tan %403 : f64
    %405 = math.atan %404 : f64
    %406 = arith.mulf %405, %cst_6 : f64
    %407 = arith.addf %406, %cst_5 : f64
    %408 = arith.divf %407, %cst_6 : f64
    %409 = math.tan %408 : f64
    %410 = math.atan %409 : f64
    %411 = arith.mulf %410, %cst_6 : f64
    %412 = arith.addf %411, %cst : f64
    %413 = qco.rz(%412) %402 : !qco.qubit -> !qco.qubit
    %414 = qco.sx %413 : !qco.qubit -> !qco.qubit
    %415 = qco.rz(%cst_4) %414 : !qco.qubit -> !qco.qubit
    %416 = qco.sx %415 : !qco.qubit -> !qco.qubit
    %417 = qco.rz(%cst_3) %416 : !qco.qubit -> !qco.qubit
    %418 = qco.rz(%cst_2) %controls_out_31 : !qco.qubit -> !qco.qubit
    %419 = qco.sx %418 : !qco.qubit -> !qco.qubit
    %420 = qco.rz(%cst_1) %419 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%417) targets (%arg24 = %420) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %421 = qco.rz(%cst_0) %targets_out_46 : !qco.qubit -> !qco.qubit
    %422 = qco.sx %421 : !qco.qubit -> !qco.qubit
    %423 = arith.divf %arg21, %cst_6 : f64
    %424 = math.tan %423 : f64
    %425 = math.atan %424 : f64
    %426 = arith.mulf %425, %cst_6 : f64
    %427 = arith.addf %426, %cst_5 : f64
    %428 = arith.divf %427, %cst_6 : f64
    %429 = math.tan %428 : f64
    %430 = math.atan %429 : f64
    %431 = arith.mulf %430, %cst_6 : f64
    %432 = arith.addf %431, %cst : f64
    %433 = qco.rz(%432) %422 : !qco.qubit -> !qco.qubit
    %434 = qco.sx %433 : !qco.qubit -> !qco.qubit
    %435 = qco.rz(%cst_4) %434 : !qco.qubit -> !qco.qubit
    %436 = qco.sx %435 : !qco.qubit -> !qco.qubit
    %437 = qco.rz(%cst_3) %436 : !qco.qubit -> !qco.qubit
    %438 = qco.rz(%cst_2) %controls_out_33 : !qco.qubit -> !qco.qubit
    %439 = qco.sx %438 : !qco.qubit -> !qco.qubit
    %440 = qco.rz(%cst_1) %439 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%437) targets (%arg24 = %440) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %441 = qco.rz(%cst_0) %targets_out_48 : !qco.qubit -> !qco.qubit
    %442 = qco.sx %441 : !qco.qubit -> !qco.qubit
    %443 = arith.divf %arg22, %cst_6 : f64
    %444 = math.tan %443 : f64
    %445 = math.atan %444 : f64
    %446 = arith.mulf %445, %cst_6 : f64
    %447 = arith.addf %446, %cst_5 : f64
    %448 = arith.divf %447, %cst_6 : f64
    %449 = math.tan %448 : f64
    %450 = math.atan %449 : f64
    %451 = arith.mulf %450, %cst_6 : f64
    %452 = arith.addf %451, %cst : f64
    %453 = qco.rz(%452) %442 : !qco.qubit -> !qco.qubit
    %454 = qco.sx %453 : !qco.qubit -> !qco.qubit
    %455 = qco.rz(%cst_4) %454 : !qco.qubit -> !qco.qubit
    %456 = qco.sx %455 : !qco.qubit -> !qco.qubit
    %457 = qco.rz(%cst_3) %456 : !qco.qubit -> !qco.qubit
    %458 = qco.rz(%cst_2) %controls_out_35 : !qco.qubit -> !qco.qubit
    %459 = qco.sx %458 : !qco.qubit -> !qco.qubit
    %460 = qco.rz(%cst_1) %459 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%457) targets (%arg24 = %460) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %461 = qco.rz(%cst_0) %targets_out_50 : !qco.qubit -> !qco.qubit
    %462 = qco.sx %461 : !qco.qubit -> !qco.qubit
    %463 = arith.divf %arg23, %cst_6 : f64
    %464 = math.tan %463 : f64
    %465 = math.atan %464 : f64
    %466 = arith.mulf %465, %cst_6 : f64
    %467 = arith.addf %466, %cst_5 : f64
    %468 = arith.divf %467, %cst_6 : f64
    %469 = math.tan %468 : f64
    %470 = math.atan %469 : f64
    %471 = arith.mulf %470, %cst_6 : f64
    %472 = arith.addf %471, %cst : f64
    %473 = qco.rz(%472) %462 : !qco.qubit -> !qco.qubit
    %474 = qco.sx %473 : !qco.qubit -> !qco.qubit
    %475 = qco.rz(%cst_4) %474 : !qco.qubit -> !qco.qubit
    %476 = qco.sx %475 : !qco.qubit -> !qco.qubit
    %477 = qco.rz(%cst_3) %476 : !qco.qubit -> !qco.qubit
    qco.sink %controls_out_39 : !qco.qubit
    qco.sink %controls_out_41 : !qco.qubit
    qco.sink %controls_out_43 : !qco.qubit
    qco.sink %controls_out_45 : !qco.qubit
    qco.sink %controls_out_47 : !qco.qubit
    qco.sink %controls_out_49 : !qco.qubit
    %478 = qco.rz(%cst_2) %controls_out_37 : !qco.qubit -> !qco.qubit
    %479 = qco.sx %478 : !qco.qubit -> !qco.qubit
    %480 = qco.rz(%cst_1) %479 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%477) targets (%arg24 = %480) {
      %484 = qco.x %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %484 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %481 = qco.rz(%cst_0) %targets_out_52 : !qco.qubit -> !qco.qubit
    %482 = qco.sx %481 : !qco.qubit -> !qco.qubit
    %483 = qco.rz(%cst) %482 : !qco.qubit -> !qco.qubit
    qco.sink %483 : !qco.qubit
    qco.sink %controls_out_51 : !qco.qubit
    return %c0_i64 : i64
  }
}
