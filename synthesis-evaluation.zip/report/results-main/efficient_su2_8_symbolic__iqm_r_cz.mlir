module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main(%arg0: f64 {mqt.input_id = 44246249981895013191645689038461798644 : i128, mqt.input_name = "\CE\B8[0]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 0 : i64, name = "\CE\B8", size = 64 : i64}}, %arg1: f64 {mqt.input_id = 44246249981895013191645689038461798645 : i128, mqt.input_name = "\CE\B8[1]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 1 : i64, name = "\CE\B8", size = 64 : i64}}, %arg2: f64 {mqt.input_id = 44246249981895013191645689038461798646 : i128, mqt.input_name = "\CE\B8[2]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 2 : i64, name = "\CE\B8", size = 64 : i64}}, %arg3: f64 {mqt.input_id = 44246249981895013191645689038461798647 : i128, mqt.input_name = "\CE\B8[3]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 3 : i64, name = "\CE\B8", size = 64 : i64}}, %arg4: f64 {mqt.input_id = 44246249981895013191645689038461798648 : i128, mqt.input_name = "\CE\B8[4]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 4 : i64, name = "\CE\B8", size = 64 : i64}}, %arg5: f64 {mqt.input_id = 44246249981895013191645689038461798649 : i128, mqt.input_name = "\CE\B8[5]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 5 : i64, name = "\CE\B8", size = 64 : i64}}, %arg6: f64 {mqt.input_id = 44246249981895013191645689038461798650 : i128, mqt.input_name = "\CE\B8[6]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 6 : i64, name = "\CE\B8", size = 64 : i64}}, %arg7: f64 {mqt.input_id = 44246249981895013191645689038461798651 : i128, mqt.input_name = "\CE\B8[7]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 7 : i64, name = "\CE\B8", size = 64 : i64}}, %arg8: f64 {mqt.input_id = 44246249981895013191645689038461798652 : i128, mqt.input_name = "\CE\B8[8]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 8 : i64, name = "\CE\B8", size = 64 : i64}}, %arg9: f64 {mqt.input_id = 44246249981895013191645689038461798653 : i128, mqt.input_name = "\CE\B8[9]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 9 : i64, name = "\CE\B8", size = 64 : i64}}, %arg10: f64 {mqt.input_id = 44246249981895013191645689038461798654 : i128, mqt.input_name = "\CE\B8[10]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 10 : i64, name = "\CE\B8", size = 64 : i64}}, %arg11: f64 {mqt.input_id = 44246249981895013191645689038461798655 : i128, mqt.input_name = "\CE\B8[11]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 11 : i64, name = "\CE\B8", size = 64 : i64}}, %arg12: f64 {mqt.input_id = 44246249981895013191645689038461798656 : i128, mqt.input_name = "\CE\B8[12]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 12 : i64, name = "\CE\B8", size = 64 : i64}}, %arg13: f64 {mqt.input_id = 44246249981895013191645689038461798657 : i128, mqt.input_name = "\CE\B8[13]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 13 : i64, name = "\CE\B8", size = 64 : i64}}, %arg14: f64 {mqt.input_id = 44246249981895013191645689038461798658 : i128, mqt.input_name = "\CE\B8[14]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 14 : i64, name = "\CE\B8", size = 64 : i64}}, %arg15: f64 {mqt.input_id = 44246249981895013191645689038461798659 : i128, mqt.input_name = "\CE\B8[15]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 15 : i64, name = "\CE\B8", size = 64 : i64}}, %arg16: f64 {mqt.input_id = 44246249981895013191645689038461798660 : i128, mqt.input_name = "\CE\B8[16]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 16 : i64, name = "\CE\B8", size = 64 : i64}}, %arg17: f64 {mqt.input_id = 44246249981895013191645689038461798661 : i128, mqt.input_name = "\CE\B8[17]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 17 : i64, name = "\CE\B8", size = 64 : i64}}, %arg18: f64 {mqt.input_id = 44246249981895013191645689038461798662 : i128, mqt.input_name = "\CE\B8[18]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 18 : i64, name = "\CE\B8", size = 64 : i64}}, %arg19: f64 {mqt.input_id = 44246249981895013191645689038461798663 : i128, mqt.input_name = "\CE\B8[19]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 19 : i64, name = "\CE\B8", size = 64 : i64}}, %arg20: f64 {mqt.input_id = 44246249981895013191645689038461798664 : i128, mqt.input_name = "\CE\B8[20]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 20 : i64, name = "\CE\B8", size = 64 : i64}}, %arg21: f64 {mqt.input_id = 44246249981895013191645689038461798665 : i128, mqt.input_name = "\CE\B8[21]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 21 : i64, name = "\CE\B8", size = 64 : i64}}, %arg22: f64 {mqt.input_id = 44246249981895013191645689038461798666 : i128, mqt.input_name = "\CE\B8[22]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 22 : i64, name = "\CE\B8", size = 64 : i64}}, %arg23: f64 {mqt.input_id = 44246249981895013191645689038461798667 : i128, mqt.input_name = "\CE\B8[23]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 23 : i64, name = "\CE\B8", size = 64 : i64}}, %arg24: f64 {mqt.input_id = 44246249981895013191645689038461798668 : i128, mqt.input_name = "\CE\B8[24]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 24 : i64, name = "\CE\B8", size = 64 : i64}}, %arg25: f64 {mqt.input_id = 44246249981895013191645689038461798669 : i128, mqt.input_name = "\CE\B8[25]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 25 : i64, name = "\CE\B8", size = 64 : i64}}, %arg26: f64 {mqt.input_id = 44246249981895013191645689038461798670 : i128, mqt.input_name = "\CE\B8[26]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 26 : i64, name = "\CE\B8", size = 64 : i64}}, %arg27: f64 {mqt.input_id = 44246249981895013191645689038461798671 : i128, mqt.input_name = "\CE\B8[27]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 27 : i64, name = "\CE\B8", size = 64 : i64}}, %arg28: f64 {mqt.input_id = 44246249981895013191645689038461798672 : i128, mqt.input_name = "\CE\B8[28]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 28 : i64, name = "\CE\B8", size = 64 : i64}}, %arg29: f64 {mqt.input_id = 44246249981895013191645689038461798673 : i128, mqt.input_name = "\CE\B8[29]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 29 : i64, name = "\CE\B8", size = 64 : i64}}, %arg30: f64 {mqt.input_id = 44246249981895013191645689038461798674 : i128, mqt.input_name = "\CE\B8[30]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 30 : i64, name = "\CE\B8", size = 64 : i64}}, %arg31: f64 {mqt.input_id = 44246249981895013191645689038461798675 : i128, mqt.input_name = "\CE\B8[31]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 31 : i64, name = "\CE\B8", size = 64 : i64}}, %arg32: f64 {mqt.input_id = 44246249981895013191645689038461798676 : i128, mqt.input_name = "\CE\B8[32]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 32 : i64, name = "\CE\B8", size = 64 : i64}}, %arg33: f64 {mqt.input_id = 44246249981895013191645689038461798677 : i128, mqt.input_name = "\CE\B8[33]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 33 : i64, name = "\CE\B8", size = 64 : i64}}, %arg34: f64 {mqt.input_id = 44246249981895013191645689038461798678 : i128, mqt.input_name = "\CE\B8[34]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 34 : i64, name = "\CE\B8", size = 64 : i64}}, %arg35: f64 {mqt.input_id = 44246249981895013191645689038461798679 : i128, mqt.input_name = "\CE\B8[35]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 35 : i64, name = "\CE\B8", size = 64 : i64}}, %arg36: f64 {mqt.input_id = 44246249981895013191645689038461798680 : i128, mqt.input_name = "\CE\B8[36]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 36 : i64, name = "\CE\B8", size = 64 : i64}}, %arg37: f64 {mqt.input_id = 44246249981895013191645689038461798681 : i128, mqt.input_name = "\CE\B8[37]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 37 : i64, name = "\CE\B8", size = 64 : i64}}, %arg38: f64 {mqt.input_id = 44246249981895013191645689038461798682 : i128, mqt.input_name = "\CE\B8[38]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 38 : i64, name = "\CE\B8", size = 64 : i64}}, %arg39: f64 {mqt.input_id = 44246249981895013191645689038461798683 : i128, mqt.input_name = "\CE\B8[39]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 39 : i64, name = "\CE\B8", size = 64 : i64}}, %arg40: f64 {mqt.input_id = 44246249981895013191645689038461798684 : i128, mqt.input_name = "\CE\B8[40]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 40 : i64, name = "\CE\B8", size = 64 : i64}}, %arg41: f64 {mqt.input_id = 44246249981895013191645689038461798685 : i128, mqt.input_name = "\CE\B8[41]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 41 : i64, name = "\CE\B8", size = 64 : i64}}, %arg42: f64 {mqt.input_id = 44246249981895013191645689038461798686 : i128, mqt.input_name = "\CE\B8[42]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 42 : i64, name = "\CE\B8", size = 64 : i64}}, %arg43: f64 {mqt.input_id = 44246249981895013191645689038461798687 : i128, mqt.input_name = "\CE\B8[43]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 43 : i64, name = "\CE\B8", size = 64 : i64}}, %arg44: f64 {mqt.input_id = 44246249981895013191645689038461798688 : i128, mqt.input_name = "\CE\B8[44]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 44 : i64, name = "\CE\B8", size = 64 : i64}}, %arg45: f64 {mqt.input_id = 44246249981895013191645689038461798689 : i128, mqt.input_name = "\CE\B8[45]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 45 : i64, name = "\CE\B8", size = 64 : i64}}, %arg46: f64 {mqt.input_id = 44246249981895013191645689038461798690 : i128, mqt.input_name = "\CE\B8[46]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 46 : i64, name = "\CE\B8", size = 64 : i64}}, %arg47: f64 {mqt.input_id = 44246249981895013191645689038461798691 : i128, mqt.input_name = "\CE\B8[47]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 47 : i64, name = "\CE\B8", size = 64 : i64}}, %arg48: f64 {mqt.input_id = 44246249981895013191645689038461798692 : i128, mqt.input_name = "\CE\B8[48]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 48 : i64, name = "\CE\B8", size = 64 : i64}}, %arg49: f64 {mqt.input_id = 44246249981895013191645689038461798693 : i128, mqt.input_name = "\CE\B8[49]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 49 : i64, name = "\CE\B8", size = 64 : i64}}, %arg50: f64 {mqt.input_id = 44246249981895013191645689038461798694 : i128, mqt.input_name = "\CE\B8[50]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 50 : i64, name = "\CE\B8", size = 64 : i64}}, %arg51: f64 {mqt.input_id = 44246249981895013191645689038461798695 : i128, mqt.input_name = "\CE\B8[51]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 51 : i64, name = "\CE\B8", size = 64 : i64}}, %arg52: f64 {mqt.input_id = 44246249981895013191645689038461798696 : i128, mqt.input_name = "\CE\B8[52]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 52 : i64, name = "\CE\B8", size = 64 : i64}}, %arg53: f64 {mqt.input_id = 44246249981895013191645689038461798697 : i128, mqt.input_name = "\CE\B8[53]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 53 : i64, name = "\CE\B8", size = 64 : i64}}, %arg54: f64 {mqt.input_id = 44246249981895013191645689038461798698 : i128, mqt.input_name = "\CE\B8[54]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 54 : i64, name = "\CE\B8", size = 64 : i64}}, %arg55: f64 {mqt.input_id = 44246249981895013191645689038461798699 : i128, mqt.input_name = "\CE\B8[55]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 55 : i64, name = "\CE\B8", size = 64 : i64}}, %arg56: f64 {mqt.input_id = 44246249981895013191645689038461798700 : i128, mqt.input_name = "\CE\B8[56]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 56 : i64, name = "\CE\B8", size = 64 : i64}}, %arg57: f64 {mqt.input_id = 44246249981895013191645689038461798701 : i128, mqt.input_name = "\CE\B8[57]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 57 : i64, name = "\CE\B8", size = 64 : i64}}, %arg58: f64 {mqt.input_id = 44246249981895013191645689038461798702 : i128, mqt.input_name = "\CE\B8[58]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 58 : i64, name = "\CE\B8", size = 64 : i64}}, %arg59: f64 {mqt.input_id = 44246249981895013191645689038461798703 : i128, mqt.input_name = "\CE\B8[59]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 59 : i64, name = "\CE\B8", size = 64 : i64}}, %arg60: f64 {mqt.input_id = 44246249981895013191645689038461798704 : i128, mqt.input_name = "\CE\B8[60]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 60 : i64, name = "\CE\B8", size = 64 : i64}}, %arg61: f64 {mqt.input_id = 44246249981895013191645689038461798705 : i128, mqt.input_name = "\CE\B8[61]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 61 : i64, name = "\CE\B8", size = 64 : i64}}, %arg62: f64 {mqt.input_id = 44246249981895013191645689038461798706 : i128, mqt.input_name = "\CE\B8[62]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 62 : i64, name = "\CE\B8", size = 64 : i64}}, %arg63: f64 {mqt.input_id = 44246249981895013191645689038461798707 : i128, mqt.input_name = "\CE\B8[63]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 63 : i64, name = "\CE\B8", size = 64 : i64}}) -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 6.2831853071795862 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant 4.000000e+00 : f64
    %cst_2 = arith.constant 3.1415926535897931 : f64
    %cst_3 = arith.constant 2.000000e+00 : f64
    %cst_4 = arith.constant 0.000000e+00 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.r(%arg0, %cst_0) %0 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%arg1, %cst_0) %1 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%arg2, %cst_0) %2 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%arg3, %cst_0) %3 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%arg4, %cst_0) %4 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%arg5, %cst_0) %5 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%arg6, %cst_0) %6 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%arg7, %cst_0) %7 : !qco.qubit -> !qco.qubit
    %16 = arith.divf %arg8, %cst_1 : f64
    %17 = math.tan %16 : f64
    %18 = math.atan %17 : f64
    %19 = arith.mulf %18, %cst_1 : f64
    %20 = arith.divf %cst_2, %cst_3 : f64
    %21 = arith.negf %20 : f64
    %22 = qco.r(%21, %cst_4) %8 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%19, %20) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%20, %cst_4) %23 : !qco.qubit -> !qco.qubit
    %25 = arith.divf %arg9, %cst_1 : f64
    %26 = math.tan %25 : f64
    %27 = math.atan %26 : f64
    %28 = arith.mulf %27, %cst_1 : f64
    %29 = qco.r(%21, %cst_4) %9 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%28, %20) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%20, %cst_4) %30 : !qco.qubit -> !qco.qubit
    %32 = arith.divf %arg10, %cst_1 : f64
    %33 = math.tan %32 : f64
    %34 = math.atan %33 : f64
    %35 = arith.mulf %34, %cst_1 : f64
    %36 = qco.r(%21, %cst_4) %10 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%35, %20) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%20, %cst_4) %37 : !qco.qubit -> !qco.qubit
    %39 = arith.divf %arg11, %cst_1 : f64
    %40 = math.tan %39 : f64
    %41 = math.atan %40 : f64
    %42 = arith.mulf %41, %cst_1 : f64
    %43 = qco.r(%21, %cst_4) %11 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%42, %20) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%20, %cst_4) %44 : !qco.qubit -> !qco.qubit
    %46 = arith.divf %arg12, %cst_1 : f64
    %47 = math.tan %46 : f64
    %48 = math.atan %47 : f64
    %49 = arith.mulf %48, %cst_1 : f64
    %50 = qco.r(%21, %cst_4) %12 : !qco.qubit -> !qco.qubit
    %51 = qco.r(%49, %20) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.r(%20, %cst_4) %51 : !qco.qubit -> !qco.qubit
    %53 = arith.divf %arg13, %cst_1 : f64
    %54 = math.tan %53 : f64
    %55 = math.atan %54 : f64
    %56 = arith.mulf %55, %cst_1 : f64
    %57 = qco.r(%21, %cst_4) %13 : !qco.qubit -> !qco.qubit
    %58 = qco.r(%56, %20) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%20, %cst_4) %58 : !qco.qubit -> !qco.qubit
    %60 = arith.divf %arg14, %cst_1 : f64
    %61 = math.tan %60 : f64
    %62 = math.atan %61 : f64
    %63 = arith.mulf %62, %cst_1 : f64
    %64 = qco.r(%21, %cst_4) %14 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%63, %20) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.r(%20, %cst_4) %65 : !qco.qubit -> !qco.qubit
    %67 = arith.divf %arg15, %cst_1 : f64
    %68 = math.tan %67 : f64
    %69 = math.atan %68 : f64
    %70 = arith.mulf %69, %cst_1 : f64
    %71 = qco.r(%21, %cst_4) %15 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%70, %20) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%20, %cst_4) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.r(%cst_2, %cst_4) %24 : !qco.qubit -> !qco.qubit
    %75 = qco.r(%cst_0, %cst_0) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.r(%cst_2, %cst_4) %75 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%73) targets (%arg64 = %76) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qco.r(%cst_0, %cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst, %cst_4) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.r(%cst_2, %cst_4) %31 : !qco.qubit -> !qco.qubit
    %80 = qco.r(%cst_0, %cst_0) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%cst_2, %cst_4) %80 : !qco.qubit -> !qco.qubit
    %controls_out_5, %targets_out_6 = qco.ctrl(%78) targets (%arg64 = %81) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %82 = qco.r(%cst_0, %cst_0) %targets_out_6 : !qco.qubit -> !qco.qubit
    %83 = qco.r(%cst, %cst_4) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.r(%cst_2, %cst_4) %38 : !qco.qubit -> !qco.qubit
    %85 = qco.r(%cst_0, %cst_0) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.r(%cst_2, %cst_4) %85 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%83) targets (%arg64 = %86) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %87 = qco.r(%cst_0, %cst_0) %targets_out_8 : !qco.qubit -> !qco.qubit
    %88 = qco.r(%cst, %cst_4) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%cst_2, %cst_4) %45 : !qco.qubit -> !qco.qubit
    %90 = qco.r(%cst_0, %cst_0) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.r(%cst_2, %cst_4) %90 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%88) targets (%arg64 = %91) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %92 = qco.r(%cst_0, %cst_0) %targets_out_10 : !qco.qubit -> !qco.qubit
    %93 = qco.r(%cst, %cst_4) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.r(%cst_2, %cst_4) %52 : !qco.qubit -> !qco.qubit
    %95 = qco.r(%cst_0, %cst_0) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.r(%cst_2, %cst_4) %95 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%93) targets (%arg64 = %96) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %97 = qco.r(%cst_0, %cst_0) %targets_out_12 : !qco.qubit -> !qco.qubit
    %98 = qco.r(%cst, %cst_4) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.r(%cst_2, %cst_4) %59 : !qco.qubit -> !qco.qubit
    %100 = qco.r(%cst_0, %cst_0) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.r(%cst_2, %cst_4) %100 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%98) targets (%arg64 = %101) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %102 = qco.r(%cst_0, %cst_0) %targets_out_14 : !qco.qubit -> !qco.qubit
    %103 = qco.r(%cst, %cst_4) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.r(%cst_2, %cst_4) %66 : !qco.qubit -> !qco.qubit
    %105 = qco.r(%cst_0, %cst_0) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.r(%cst_2, %cst_4) %105 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%103) targets (%arg64 = %106) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %107 = qco.r(%cst_0, %cst_0) %targets_out_16 : !qco.qubit -> !qco.qubit
    %108 = qco.r(%cst, %cst_4) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.r(%cst_2, %cst_4) %controls_out : !qco.qubit -> !qco.qubit
    %110 = qco.r(%cst_0, %cst_0) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.r(%cst_2, %cst_4) %110 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%108) targets (%arg64 = %111) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %112 = qco.r(%cst_0, %cst_0) %targets_out_18 : !qco.qubit -> !qco.qubit
    %113 = qco.r(%cst, %cst_4) %112 : !qco.qubit -> !qco.qubit
    %114 = qco.r(%arg16, %cst_0) %controls_out_5 : !qco.qubit -> !qco.qubit
    %115 = qco.r(%arg17, %cst_0) %controls_out_7 : !qco.qubit -> !qco.qubit
    %116 = qco.r(%arg18, %cst_0) %controls_out_9 : !qco.qubit -> !qco.qubit
    %117 = qco.r(%arg19, %cst_0) %controls_out_11 : !qco.qubit -> !qco.qubit
    %118 = qco.r(%arg20, %cst_0) %controls_out_13 : !qco.qubit -> !qco.qubit
    %119 = qco.r(%arg21, %cst_0) %controls_out_15 : !qco.qubit -> !qco.qubit
    %120 = qco.r(%arg22, %cst_0) %controls_out_17 : !qco.qubit -> !qco.qubit
    %121 = qco.r(%arg23, %cst_0) %113 : !qco.qubit -> !qco.qubit
    %122 = arith.divf %arg24, %cst_1 : f64
    %123 = math.tan %122 : f64
    %124 = math.atan %123 : f64
    %125 = arith.mulf %124, %cst_1 : f64
    %126 = qco.r(%21, %cst_4) %114 : !qco.qubit -> !qco.qubit
    %127 = qco.r(%125, %20) %126 : !qco.qubit -> !qco.qubit
    %128 = qco.r(%20, %cst_4) %127 : !qco.qubit -> !qco.qubit
    %129 = arith.divf %arg25, %cst_1 : f64
    %130 = math.tan %129 : f64
    %131 = math.atan %130 : f64
    %132 = arith.mulf %131, %cst_1 : f64
    %133 = qco.r(%21, %cst_4) %115 : !qco.qubit -> !qco.qubit
    %134 = qco.r(%132, %20) %133 : !qco.qubit -> !qco.qubit
    %135 = qco.r(%20, %cst_4) %134 : !qco.qubit -> !qco.qubit
    %136 = arith.divf %arg26, %cst_1 : f64
    %137 = math.tan %136 : f64
    %138 = math.atan %137 : f64
    %139 = arith.mulf %138, %cst_1 : f64
    %140 = qco.r(%21, %cst_4) %116 : !qco.qubit -> !qco.qubit
    %141 = qco.r(%139, %20) %140 : !qco.qubit -> !qco.qubit
    %142 = qco.r(%20, %cst_4) %141 : !qco.qubit -> !qco.qubit
    %143 = arith.divf %arg27, %cst_1 : f64
    %144 = math.tan %143 : f64
    %145 = math.atan %144 : f64
    %146 = arith.mulf %145, %cst_1 : f64
    %147 = qco.r(%21, %cst_4) %117 : !qco.qubit -> !qco.qubit
    %148 = qco.r(%146, %20) %147 : !qco.qubit -> !qco.qubit
    %149 = qco.r(%20, %cst_4) %148 : !qco.qubit -> !qco.qubit
    %150 = arith.divf %arg28, %cst_1 : f64
    %151 = math.tan %150 : f64
    %152 = math.atan %151 : f64
    %153 = arith.mulf %152, %cst_1 : f64
    %154 = qco.r(%21, %cst_4) %118 : !qco.qubit -> !qco.qubit
    %155 = qco.r(%153, %20) %154 : !qco.qubit -> !qco.qubit
    %156 = qco.r(%20, %cst_4) %155 : !qco.qubit -> !qco.qubit
    %157 = arith.divf %arg29, %cst_1 : f64
    %158 = math.tan %157 : f64
    %159 = math.atan %158 : f64
    %160 = arith.mulf %159, %cst_1 : f64
    %161 = qco.r(%21, %cst_4) %119 : !qco.qubit -> !qco.qubit
    %162 = qco.r(%160, %20) %161 : !qco.qubit -> !qco.qubit
    %163 = qco.r(%20, %cst_4) %162 : !qco.qubit -> !qco.qubit
    %164 = arith.divf %arg30, %cst_1 : f64
    %165 = math.tan %164 : f64
    %166 = math.atan %165 : f64
    %167 = arith.mulf %166, %cst_1 : f64
    %168 = qco.r(%21, %cst_4) %120 : !qco.qubit -> !qco.qubit
    %169 = qco.r(%167, %20) %168 : !qco.qubit -> !qco.qubit
    %170 = qco.r(%20, %cst_4) %169 : !qco.qubit -> !qco.qubit
    %171 = arith.divf %arg31, %cst_1 : f64
    %172 = math.tan %171 : f64
    %173 = math.atan %172 : f64
    %174 = arith.mulf %173, %cst_1 : f64
    %175 = qco.r(%21, %cst_4) %121 : !qco.qubit -> !qco.qubit
    %176 = qco.r(%174, %20) %175 : !qco.qubit -> !qco.qubit
    %177 = qco.r(%20, %cst_4) %176 : !qco.qubit -> !qco.qubit
    %178 = qco.r(%cst_2, %cst_4) %128 : !qco.qubit -> !qco.qubit
    %179 = qco.r(%cst_0, %cst_0) %178 : !qco.qubit -> !qco.qubit
    %180 = qco.r(%cst_2, %cst_4) %179 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%177) targets (%arg64 = %180) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %181 = qco.r(%cst_0, %cst_0) %targets_out_20 : !qco.qubit -> !qco.qubit
    %182 = qco.r(%cst, %cst_4) %181 : !qco.qubit -> !qco.qubit
    %183 = qco.r(%cst_2, %cst_4) %135 : !qco.qubit -> !qco.qubit
    %184 = qco.r(%cst_0, %cst_0) %183 : !qco.qubit -> !qco.qubit
    %185 = qco.r(%cst_2, %cst_4) %184 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%182) targets (%arg64 = %185) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %186 = qco.r(%cst_0, %cst_0) %targets_out_22 : !qco.qubit -> !qco.qubit
    %187 = qco.r(%cst, %cst_4) %186 : !qco.qubit -> !qco.qubit
    %188 = qco.r(%cst_2, %cst_4) %142 : !qco.qubit -> !qco.qubit
    %189 = qco.r(%cst_0, %cst_0) %188 : !qco.qubit -> !qco.qubit
    %190 = qco.r(%cst_2, %cst_4) %189 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%187) targets (%arg64 = %190) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %191 = qco.r(%cst_0, %cst_0) %targets_out_24 : !qco.qubit -> !qco.qubit
    %192 = qco.r(%cst, %cst_4) %191 : !qco.qubit -> !qco.qubit
    %193 = qco.r(%cst_2, %cst_4) %149 : !qco.qubit -> !qco.qubit
    %194 = qco.r(%cst_0, %cst_0) %193 : !qco.qubit -> !qco.qubit
    %195 = qco.r(%cst_2, %cst_4) %194 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%192) targets (%arg64 = %195) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %196 = qco.r(%cst_0, %cst_0) %targets_out_26 : !qco.qubit -> !qco.qubit
    %197 = qco.r(%cst, %cst_4) %196 : !qco.qubit -> !qco.qubit
    %198 = qco.r(%cst_2, %cst_4) %156 : !qco.qubit -> !qco.qubit
    %199 = qco.r(%cst_0, %cst_0) %198 : !qco.qubit -> !qco.qubit
    %200 = qco.r(%cst_2, %cst_4) %199 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%197) targets (%arg64 = %200) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %201 = qco.r(%cst_0, %cst_0) %targets_out_28 : !qco.qubit -> !qco.qubit
    %202 = qco.r(%cst, %cst_4) %201 : !qco.qubit -> !qco.qubit
    %203 = qco.r(%cst_2, %cst_4) %163 : !qco.qubit -> !qco.qubit
    %204 = qco.r(%cst_0, %cst_0) %203 : !qco.qubit -> !qco.qubit
    %205 = qco.r(%cst_2, %cst_4) %204 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%202) targets (%arg64 = %205) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %206 = qco.r(%cst_0, %cst_0) %targets_out_30 : !qco.qubit -> !qco.qubit
    %207 = qco.r(%cst, %cst_4) %206 : !qco.qubit -> !qco.qubit
    %208 = qco.r(%cst_2, %cst_4) %170 : !qco.qubit -> !qco.qubit
    %209 = qco.r(%cst_0, %cst_0) %208 : !qco.qubit -> !qco.qubit
    %210 = qco.r(%cst_2, %cst_4) %209 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%207) targets (%arg64 = %210) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %211 = qco.r(%cst_0, %cst_0) %targets_out_32 : !qco.qubit -> !qco.qubit
    %212 = qco.r(%cst, %cst_4) %211 : !qco.qubit -> !qco.qubit
    %213 = qco.r(%cst_2, %cst_4) %controls_out_19 : !qco.qubit -> !qco.qubit
    %214 = qco.r(%cst_0, %cst_0) %213 : !qco.qubit -> !qco.qubit
    %215 = qco.r(%cst_2, %cst_4) %214 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%212) targets (%arg64 = %215) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %216 = qco.r(%cst_0, %cst_0) %targets_out_34 : !qco.qubit -> !qco.qubit
    %217 = qco.r(%cst, %cst_4) %216 : !qco.qubit -> !qco.qubit
    %218 = qco.r(%arg32, %cst_0) %controls_out_21 : !qco.qubit -> !qco.qubit
    %219 = qco.r(%arg33, %cst_0) %controls_out_23 : !qco.qubit -> !qco.qubit
    %220 = qco.r(%arg34, %cst_0) %controls_out_25 : !qco.qubit -> !qco.qubit
    %221 = qco.r(%arg35, %cst_0) %controls_out_27 : !qco.qubit -> !qco.qubit
    %222 = qco.r(%arg36, %cst_0) %controls_out_29 : !qco.qubit -> !qco.qubit
    %223 = qco.r(%arg37, %cst_0) %controls_out_31 : !qco.qubit -> !qco.qubit
    %224 = qco.r(%arg38, %cst_0) %controls_out_33 : !qco.qubit -> !qco.qubit
    %225 = qco.r(%arg39, %cst_0) %217 : !qco.qubit -> !qco.qubit
    %226 = arith.divf %arg40, %cst_1 : f64
    %227 = math.tan %226 : f64
    %228 = math.atan %227 : f64
    %229 = arith.mulf %228, %cst_1 : f64
    %230 = qco.r(%21, %cst_4) %218 : !qco.qubit -> !qco.qubit
    %231 = qco.r(%229, %20) %230 : !qco.qubit -> !qco.qubit
    %232 = qco.r(%20, %cst_4) %231 : !qco.qubit -> !qco.qubit
    %233 = arith.divf %arg41, %cst_1 : f64
    %234 = math.tan %233 : f64
    %235 = math.atan %234 : f64
    %236 = arith.mulf %235, %cst_1 : f64
    %237 = qco.r(%21, %cst_4) %219 : !qco.qubit -> !qco.qubit
    %238 = qco.r(%236, %20) %237 : !qco.qubit -> !qco.qubit
    %239 = qco.r(%20, %cst_4) %238 : !qco.qubit -> !qco.qubit
    %240 = arith.divf %arg42, %cst_1 : f64
    %241 = math.tan %240 : f64
    %242 = math.atan %241 : f64
    %243 = arith.mulf %242, %cst_1 : f64
    %244 = qco.r(%21, %cst_4) %220 : !qco.qubit -> !qco.qubit
    %245 = qco.r(%243, %20) %244 : !qco.qubit -> !qco.qubit
    %246 = qco.r(%20, %cst_4) %245 : !qco.qubit -> !qco.qubit
    %247 = arith.divf %arg43, %cst_1 : f64
    %248 = math.tan %247 : f64
    %249 = math.atan %248 : f64
    %250 = arith.mulf %249, %cst_1 : f64
    %251 = qco.r(%21, %cst_4) %221 : !qco.qubit -> !qco.qubit
    %252 = qco.r(%250, %20) %251 : !qco.qubit -> !qco.qubit
    %253 = qco.r(%20, %cst_4) %252 : !qco.qubit -> !qco.qubit
    %254 = arith.divf %arg44, %cst_1 : f64
    %255 = math.tan %254 : f64
    %256 = math.atan %255 : f64
    %257 = arith.mulf %256, %cst_1 : f64
    %258 = qco.r(%21, %cst_4) %222 : !qco.qubit -> !qco.qubit
    %259 = qco.r(%257, %20) %258 : !qco.qubit -> !qco.qubit
    %260 = qco.r(%20, %cst_4) %259 : !qco.qubit -> !qco.qubit
    %261 = arith.divf %arg45, %cst_1 : f64
    %262 = math.tan %261 : f64
    %263 = math.atan %262 : f64
    %264 = arith.mulf %263, %cst_1 : f64
    %265 = qco.r(%21, %cst_4) %223 : !qco.qubit -> !qco.qubit
    %266 = qco.r(%264, %20) %265 : !qco.qubit -> !qco.qubit
    %267 = qco.r(%20, %cst_4) %266 : !qco.qubit -> !qco.qubit
    %268 = arith.divf %arg46, %cst_1 : f64
    %269 = math.tan %268 : f64
    %270 = math.atan %269 : f64
    %271 = arith.mulf %270, %cst_1 : f64
    %272 = qco.r(%21, %cst_4) %224 : !qco.qubit -> !qco.qubit
    %273 = qco.r(%271, %20) %272 : !qco.qubit -> !qco.qubit
    %274 = qco.r(%20, %cst_4) %273 : !qco.qubit -> !qco.qubit
    %275 = arith.divf %arg47, %cst_1 : f64
    %276 = math.tan %275 : f64
    %277 = math.atan %276 : f64
    %278 = arith.mulf %277, %cst_1 : f64
    %279 = qco.r(%21, %cst_4) %225 : !qco.qubit -> !qco.qubit
    %280 = qco.r(%278, %20) %279 : !qco.qubit -> !qco.qubit
    %281 = qco.r(%20, %cst_4) %280 : !qco.qubit -> !qco.qubit
    %282 = qco.r(%cst_2, %cst_4) %232 : !qco.qubit -> !qco.qubit
    %283 = qco.r(%cst_0, %cst_0) %282 : !qco.qubit -> !qco.qubit
    %284 = qco.r(%cst_2, %cst_4) %283 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%281) targets (%arg64 = %284) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %285 = qco.r(%cst_0, %cst_0) %targets_out_36 : !qco.qubit -> !qco.qubit
    %286 = qco.r(%cst, %cst_4) %285 : !qco.qubit -> !qco.qubit
    %287 = qco.r(%cst_2, %cst_4) %239 : !qco.qubit -> !qco.qubit
    %288 = qco.r(%cst_0, %cst_0) %287 : !qco.qubit -> !qco.qubit
    %289 = qco.r(%cst_2, %cst_4) %288 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%286) targets (%arg64 = %289) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %290 = qco.r(%cst_0, %cst_0) %targets_out_38 : !qco.qubit -> !qco.qubit
    %291 = qco.r(%cst, %cst_4) %290 : !qco.qubit -> !qco.qubit
    %292 = qco.r(%cst_2, %cst_4) %246 : !qco.qubit -> !qco.qubit
    %293 = qco.r(%cst_0, %cst_0) %292 : !qco.qubit -> !qco.qubit
    %294 = qco.r(%cst_2, %cst_4) %293 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%291) targets (%arg64 = %294) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %295 = qco.r(%cst_0, %cst_0) %targets_out_40 : !qco.qubit -> !qco.qubit
    %296 = qco.r(%cst, %cst_4) %295 : !qco.qubit -> !qco.qubit
    %297 = qco.r(%cst_2, %cst_4) %253 : !qco.qubit -> !qco.qubit
    %298 = qco.r(%cst_0, %cst_0) %297 : !qco.qubit -> !qco.qubit
    %299 = qco.r(%cst_2, %cst_4) %298 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%296) targets (%arg64 = %299) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %300 = qco.r(%cst_0, %cst_0) %targets_out_42 : !qco.qubit -> !qco.qubit
    %301 = qco.r(%cst, %cst_4) %300 : !qco.qubit -> !qco.qubit
    %302 = qco.r(%cst_2, %cst_4) %260 : !qco.qubit -> !qco.qubit
    %303 = qco.r(%cst_0, %cst_0) %302 : !qco.qubit -> !qco.qubit
    %304 = qco.r(%cst_2, %cst_4) %303 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%301) targets (%arg64 = %304) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %305 = qco.r(%cst_0, %cst_0) %targets_out_44 : !qco.qubit -> !qco.qubit
    %306 = qco.r(%cst, %cst_4) %305 : !qco.qubit -> !qco.qubit
    %307 = qco.r(%cst_2, %cst_4) %267 : !qco.qubit -> !qco.qubit
    %308 = qco.r(%cst_0, %cst_0) %307 : !qco.qubit -> !qco.qubit
    %309 = qco.r(%cst_2, %cst_4) %308 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%306) targets (%arg64 = %309) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %310 = qco.r(%cst_0, %cst_0) %targets_out_46 : !qco.qubit -> !qco.qubit
    %311 = qco.r(%cst, %cst_4) %310 : !qco.qubit -> !qco.qubit
    %312 = qco.r(%cst_2, %cst_4) %274 : !qco.qubit -> !qco.qubit
    %313 = qco.r(%cst_0, %cst_0) %312 : !qco.qubit -> !qco.qubit
    %314 = qco.r(%cst_2, %cst_4) %313 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%311) targets (%arg64 = %314) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %315 = qco.r(%cst_0, %cst_0) %targets_out_48 : !qco.qubit -> !qco.qubit
    %316 = qco.r(%cst, %cst_4) %315 : !qco.qubit -> !qco.qubit
    %317 = qco.r(%cst_2, %cst_4) %controls_out_35 : !qco.qubit -> !qco.qubit
    %318 = qco.r(%cst_0, %cst_0) %317 : !qco.qubit -> !qco.qubit
    %319 = qco.r(%cst_2, %cst_4) %318 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%316) targets (%arg64 = %319) {
      %386 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %386 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %320 = qco.r(%cst_0, %cst_0) %targets_out_50 : !qco.qubit -> !qco.qubit
    %321 = qco.r(%cst, %cst_4) %320 : !qco.qubit -> !qco.qubit
    %322 = qco.r(%arg48, %cst_0) %controls_out_37 : !qco.qubit -> !qco.qubit
    %323 = qco.r(%arg49, %cst_0) %controls_out_39 : !qco.qubit -> !qco.qubit
    %324 = qco.r(%arg50, %cst_0) %controls_out_41 : !qco.qubit -> !qco.qubit
    %325 = qco.r(%arg51, %cst_0) %controls_out_43 : !qco.qubit -> !qco.qubit
    %326 = qco.r(%arg52, %cst_0) %controls_out_45 : !qco.qubit -> !qco.qubit
    %327 = qco.r(%arg53, %cst_0) %controls_out_47 : !qco.qubit -> !qco.qubit
    %328 = qco.r(%arg54, %cst_0) %controls_out_49 : !qco.qubit -> !qco.qubit
    %329 = qco.r(%arg55, %cst_0) %321 : !qco.qubit -> !qco.qubit
    %330 = arith.divf %arg56, %cst_1 : f64
    %331 = math.tan %330 : f64
    %332 = math.atan %331 : f64
    %333 = arith.mulf %332, %cst_1 : f64
    %334 = qco.r(%21, %cst_4) %322 : !qco.qubit -> !qco.qubit
    %335 = qco.r(%333, %20) %334 : !qco.qubit -> !qco.qubit
    %336 = qco.r(%20, %cst_4) %335 : !qco.qubit -> !qco.qubit
    %337 = arith.divf %arg57, %cst_1 : f64
    %338 = math.tan %337 : f64
    %339 = math.atan %338 : f64
    %340 = arith.mulf %339, %cst_1 : f64
    %341 = qco.r(%21, %cst_4) %323 : !qco.qubit -> !qco.qubit
    %342 = qco.r(%340, %20) %341 : !qco.qubit -> !qco.qubit
    %343 = qco.r(%20, %cst_4) %342 : !qco.qubit -> !qco.qubit
    %344 = arith.divf %arg58, %cst_1 : f64
    %345 = math.tan %344 : f64
    %346 = math.atan %345 : f64
    %347 = arith.mulf %346, %cst_1 : f64
    %348 = qco.r(%21, %cst_4) %324 : !qco.qubit -> !qco.qubit
    %349 = qco.r(%347, %20) %348 : !qco.qubit -> !qco.qubit
    %350 = qco.r(%20, %cst_4) %349 : !qco.qubit -> !qco.qubit
    %351 = arith.divf %arg59, %cst_1 : f64
    %352 = math.tan %351 : f64
    %353 = math.atan %352 : f64
    %354 = arith.mulf %353, %cst_1 : f64
    %355 = qco.r(%21, %cst_4) %325 : !qco.qubit -> !qco.qubit
    %356 = qco.r(%354, %20) %355 : !qco.qubit -> !qco.qubit
    %357 = qco.r(%20, %cst_4) %356 : !qco.qubit -> !qco.qubit
    %358 = arith.divf %arg60, %cst_1 : f64
    %359 = math.tan %358 : f64
    %360 = math.atan %359 : f64
    %361 = arith.mulf %360, %cst_1 : f64
    %362 = qco.r(%21, %cst_4) %326 : !qco.qubit -> !qco.qubit
    %363 = qco.r(%361, %20) %362 : !qco.qubit -> !qco.qubit
    %364 = qco.r(%20, %cst_4) %363 : !qco.qubit -> !qco.qubit
    %365 = arith.divf %arg61, %cst_1 : f64
    %366 = math.tan %365 : f64
    %367 = math.atan %366 : f64
    %368 = arith.mulf %367, %cst_1 : f64
    %369 = qco.r(%21, %cst_4) %327 : !qco.qubit -> !qco.qubit
    %370 = qco.r(%368, %20) %369 : !qco.qubit -> !qco.qubit
    %371 = qco.r(%20, %cst_4) %370 : !qco.qubit -> !qco.qubit
    %372 = arith.divf %arg62, %cst_1 : f64
    %373 = math.tan %372 : f64
    %374 = math.atan %373 : f64
    %375 = arith.mulf %374, %cst_1 : f64
    %376 = qco.r(%21, %cst_4) %328 : !qco.qubit -> !qco.qubit
    %377 = qco.r(%375, %20) %376 : !qco.qubit -> !qco.qubit
    %378 = qco.r(%20, %cst_4) %377 : !qco.qubit -> !qco.qubit
    qco.sink %336 : !qco.qubit
    qco.sink %343 : !qco.qubit
    qco.sink %350 : !qco.qubit
    qco.sink %357 : !qco.qubit
    qco.sink %364 : !qco.qubit
    qco.sink %371 : !qco.qubit
    qco.sink %378 : !qco.qubit
    %379 = arith.divf %arg63, %cst_1 : f64
    %380 = math.tan %379 : f64
    %381 = math.atan %380 : f64
    %382 = arith.mulf %381, %cst_1 : f64
    %383 = qco.r(%21, %cst_4) %329 : !qco.qubit -> !qco.qubit
    %384 = qco.r(%382, %20) %383 : !qco.qubit -> !qco.qubit
    %385 = qco.r(%20, %cst_4) %384 : !qco.qubit -> !qco.qubit
    qco.sink %385 : !qco.qubit
    return %c0_i64 : i64
  }
}
