module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main(%arg0: f64 {mqt.input_id = 12927349219598359841868690406665925546 : i128, mqt.input_name = "theta[0]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 0 : i64, name = "theta", size = 12 : i64}}, %arg1: f64 {mqt.input_id = 12927349219598359841868690406665925547 : i128, mqt.input_name = "theta[1]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 1 : i64, name = "theta", size = 12 : i64}}, %arg2: f64 {mqt.input_id = 12927349219598359841868690406665925548 : i128, mqt.input_name = "theta[2]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 2 : i64, name = "theta", size = 12 : i64}}, %arg3: f64 {mqt.input_id = 12927349219598359841868690406665925549 : i128, mqt.input_name = "theta[3]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 3 : i64, name = "theta", size = 12 : i64}}, %arg4: f64 {mqt.input_id = 12927349219598359841868690406665925550 : i128, mqt.input_name = "theta[4]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 4 : i64, name = "theta", size = 12 : i64}}, %arg5: f64 {mqt.input_id = 12927349219598359841868690406665925551 : i128, mqt.input_name = "theta[5]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 5 : i64, name = "theta", size = 12 : i64}}, %arg6: f64 {mqt.input_id = 12927349219598359841868690406665925552 : i128, mqt.input_name = "theta[6]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 6 : i64, name = "theta", size = 12 : i64}}, %arg7: f64 {mqt.input_id = 12927349219598359841868690406665925553 : i128, mqt.input_name = "theta[7]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 7 : i64, name = "theta", size = 12 : i64}}, %arg8: f64 {mqt.input_id = 12927349219598359841868690406665925554 : i128, mqt.input_name = "theta[8]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 8 : i64, name = "theta", size = 12 : i64}}, %arg9: f64 {mqt.input_id = 12927349219598359841868690406665925555 : i128, mqt.input_name = "theta[9]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 9 : i64, name = "theta", size = 12 : i64}}, %arg10: f64 {mqt.input_id = 12927349219598359841868690406665925556 : i128, mqt.input_name = "theta[10]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 10 : i64, name = "theta", size = 12 : i64}}, %arg11: f64 {mqt.input_id = 12927349219598359841868690406665925557 : i128, mqt.input_name = "theta[11]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 11 : i64, name = "theta", size = 12 : i64}}) -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948966 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant 1.5707963267948968 : f64
    %cst_2 = arith.constant -1.5707963267948963 : f64
    %cst_3 = arith.constant 1.7707963267948965 : f64
    %cst_4 = arith.constant 3.4415926535897929 : f64
    %cst_5 = arith.constant 1.3707963267948966 : f64
    %cst_6 = arith.constant 4.000000e+00 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = arith.divf %arg0, %cst_6 : f64
    %5 = math.tan %4 : f64
    %6 = math.atan %5 : f64
    %7 = arith.mulf %6, %cst_6 : f64
    %8 = arith.addf %7, %cst_5 : f64
    %9 = qco.rz(%8) %0 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_4) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_3) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_2) %1 : !qco.qubit -> !qco.qubit
    %15 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_1) %15 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%13) targets (%arg12 = %16) {
      %240 = qco.x %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %240 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.rz(%cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = arith.divf %arg1, %cst_6 : f64
    %20 = math.tan %19 : f64
    %21 = math.atan %20 : f64
    %22 = arith.mulf %21, %cst_6 : f64
    %23 = arith.addf %22, %cst_5 : f64
    %24 = arith.divf %23, %cst_6 : f64
    %25 = math.tan %24 : f64
    %26 = math.atan %25 : f64
    %27 = arith.mulf %26, %cst_6 : f64
    %28 = arith.addf %27, %cst : f64
    %29 = qco.rz(%28) %18 : !qco.qubit -> !qco.qubit
    %30 = qco.sx %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_4) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.sx %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_3) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_2) %2 : !qco.qubit -> !qco.qubit
    %35 = qco.sx %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_1) %35 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%33) targets (%arg12 = %36) {
      %240 = qco.x %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %240 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.rz(%cst_0) %targets_out_8 : !qco.qubit -> !qco.qubit
    %38 = qco.sx %37 : !qco.qubit -> !qco.qubit
    %39 = arith.divf %arg2, %cst_6 : f64
    %40 = math.tan %39 : f64
    %41 = math.atan %40 : f64
    %42 = arith.mulf %41, %cst_6 : f64
    %43 = arith.addf %42, %cst_5 : f64
    %44 = arith.divf %43, %cst_6 : f64
    %45 = math.tan %44 : f64
    %46 = math.atan %45 : f64
    %47 = arith.mulf %46, %cst_6 : f64
    %48 = arith.addf %47, %cst : f64
    %49 = qco.rz(%48) %38 : !qco.qubit -> !qco.qubit
    %50 = qco.sx %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_4) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.sx %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_3) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_2) %3 : !qco.qubit -> !qco.qubit
    %55 = qco.sx %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_1) %55 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%53) targets (%arg12 = %56) {
      %240 = qco.x %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %240 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %57 = qco.rz(%cst_0) %targets_out_10 : !qco.qubit -> !qco.qubit
    %58 = qco.sx %57 : !qco.qubit -> !qco.qubit
    %59 = arith.divf %arg3, %cst_6 : f64
    %60 = math.tan %59 : f64
    %61 = math.atan %60 : f64
    %62 = arith.mulf %61, %cst_6 : f64
    %63 = arith.addf %62, %cst_5 : f64
    %64 = arith.divf %63, %cst_6 : f64
    %65 = math.tan %64 : f64
    %66 = math.atan %65 : f64
    %67 = arith.mulf %66, %cst_6 : f64
    %68 = arith.addf %67, %cst : f64
    %69 = qco.rz(%68) %58 : !qco.qubit -> !qco.qubit
    %70 = qco.sx %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_4) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.sx %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_3) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_2) %controls_out : !qco.qubit -> !qco.qubit
    %75 = qco.sx %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_1) %75 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%73) targets (%arg12 = %76) {
      %240 = qco.x %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %240 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qco.rz(%cst_0) %targets_out_12 : !qco.qubit -> !qco.qubit
    %78 = qco.sx %77 : !qco.qubit -> !qco.qubit
    %79 = arith.divf %arg4, %cst_6 : f64
    %80 = math.tan %79 : f64
    %81 = math.atan %80 : f64
    %82 = arith.mulf %81, %cst_6 : f64
    %83 = arith.addf %82, %cst_5 : f64
    %84 = arith.divf %83, %cst_6 : f64
    %85 = math.tan %84 : f64
    %86 = math.atan %85 : f64
    %87 = arith.mulf %86, %cst_6 : f64
    %88 = arith.addf %87, %cst : f64
    %89 = qco.rz(%88) %78 : !qco.qubit -> !qco.qubit
    %90 = qco.sx %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_4) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.sx %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_3) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_2) %controls_out_7 : !qco.qubit -> !qco.qubit
    %95 = qco.sx %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_1) %95 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%93) targets (%arg12 = %96) {
      %240 = qco.x %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %240 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %97 = qco.rz(%cst_0) %targets_out_14 : !qco.qubit -> !qco.qubit
    %98 = qco.sx %97 : !qco.qubit -> !qco.qubit
    %99 = arith.divf %arg5, %cst_6 : f64
    %100 = math.tan %99 : f64
    %101 = math.atan %100 : f64
    %102 = arith.mulf %101, %cst_6 : f64
    %103 = arith.addf %102, %cst_5 : f64
    %104 = arith.divf %103, %cst_6 : f64
    %105 = math.tan %104 : f64
    %106 = math.atan %105 : f64
    %107 = arith.mulf %106, %cst_6 : f64
    %108 = arith.addf %107, %cst : f64
    %109 = qco.rz(%108) %98 : !qco.qubit -> !qco.qubit
    %110 = qco.sx %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_4) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.sx %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_3) %112 : !qco.qubit -> !qco.qubit
    %114 = qco.rz(%cst_2) %controls_out_9 : !qco.qubit -> !qco.qubit
    %115 = qco.sx %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst_1) %115 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%113) targets (%arg12 = %116) {
      %240 = qco.x %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %240 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %117 = qco.rz(%cst_0) %targets_out_16 : !qco.qubit -> !qco.qubit
    %118 = qco.sx %117 : !qco.qubit -> !qco.qubit
    %119 = arith.divf %arg6, %cst_6 : f64
    %120 = math.tan %119 : f64
    %121 = math.atan %120 : f64
    %122 = arith.mulf %121, %cst_6 : f64
    %123 = arith.addf %122, %cst_5 : f64
    %124 = arith.divf %123, %cst_6 : f64
    %125 = math.tan %124 : f64
    %126 = math.atan %125 : f64
    %127 = arith.mulf %126, %cst_6 : f64
    %128 = arith.addf %127, %cst : f64
    %129 = qco.rz(%128) %118 : !qco.qubit -> !qco.qubit
    %130 = qco.sx %129 : !qco.qubit -> !qco.qubit
    %131 = qco.rz(%cst_4) %130 : !qco.qubit -> !qco.qubit
    %132 = qco.sx %131 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst_3) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.rz(%cst_2) %controls_out_11 : !qco.qubit -> !qco.qubit
    %135 = qco.sx %134 : !qco.qubit -> !qco.qubit
    %136 = qco.rz(%cst_1) %135 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%133) targets (%arg12 = %136) {
      %240 = qco.x %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %240 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %137 = qco.rz(%cst_0) %targets_out_18 : !qco.qubit -> !qco.qubit
    %138 = qco.sx %137 : !qco.qubit -> !qco.qubit
    %139 = arith.divf %arg7, %cst_6 : f64
    %140 = math.tan %139 : f64
    %141 = math.atan %140 : f64
    %142 = arith.mulf %141, %cst_6 : f64
    %143 = arith.addf %142, %cst_5 : f64
    %144 = arith.divf %143, %cst_6 : f64
    %145 = math.tan %144 : f64
    %146 = math.atan %145 : f64
    %147 = arith.mulf %146, %cst_6 : f64
    %148 = arith.addf %147, %cst : f64
    %149 = qco.rz(%148) %138 : !qco.qubit -> !qco.qubit
    %150 = qco.sx %149 : !qco.qubit -> !qco.qubit
    %151 = qco.rz(%cst_4) %150 : !qco.qubit -> !qco.qubit
    %152 = qco.sx %151 : !qco.qubit -> !qco.qubit
    %153 = qco.rz(%cst_3) %152 : !qco.qubit -> !qco.qubit
    %154 = qco.rz(%cst_2) %controls_out_13 : !qco.qubit -> !qco.qubit
    %155 = qco.sx %154 : !qco.qubit -> !qco.qubit
    %156 = qco.rz(%cst_1) %155 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%153) targets (%arg12 = %156) {
      %240 = qco.x %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %240 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %157 = qco.rz(%cst_0) %targets_out_20 : !qco.qubit -> !qco.qubit
    %158 = qco.sx %157 : !qco.qubit -> !qco.qubit
    %159 = arith.divf %arg8, %cst_6 : f64
    %160 = math.tan %159 : f64
    %161 = math.atan %160 : f64
    %162 = arith.mulf %161, %cst_6 : f64
    %163 = arith.addf %162, %cst_5 : f64
    %164 = arith.divf %163, %cst_6 : f64
    %165 = math.tan %164 : f64
    %166 = math.atan %165 : f64
    %167 = arith.mulf %166, %cst_6 : f64
    %168 = arith.addf %167, %cst : f64
    %169 = qco.rz(%168) %158 : !qco.qubit -> !qco.qubit
    %170 = qco.sx %169 : !qco.qubit -> !qco.qubit
    %171 = qco.rz(%cst_4) %170 : !qco.qubit -> !qco.qubit
    %172 = qco.sx %171 : !qco.qubit -> !qco.qubit
    %173 = qco.rz(%cst_3) %172 : !qco.qubit -> !qco.qubit
    %174 = qco.rz(%cst_2) %controls_out_15 : !qco.qubit -> !qco.qubit
    %175 = qco.sx %174 : !qco.qubit -> !qco.qubit
    %176 = qco.rz(%cst_1) %175 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%173) targets (%arg12 = %176) {
      %240 = qco.x %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %240 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %177 = qco.rz(%cst_0) %targets_out_22 : !qco.qubit -> !qco.qubit
    %178 = qco.sx %177 : !qco.qubit -> !qco.qubit
    %179 = arith.divf %arg9, %cst_6 : f64
    %180 = math.tan %179 : f64
    %181 = math.atan %180 : f64
    %182 = arith.mulf %181, %cst_6 : f64
    %183 = arith.addf %182, %cst_5 : f64
    %184 = arith.divf %183, %cst_6 : f64
    %185 = math.tan %184 : f64
    %186 = math.atan %185 : f64
    %187 = arith.mulf %186, %cst_6 : f64
    %188 = arith.addf %187, %cst : f64
    %189 = qco.rz(%188) %178 : !qco.qubit -> !qco.qubit
    %190 = qco.sx %189 : !qco.qubit -> !qco.qubit
    %191 = qco.rz(%cst_4) %190 : !qco.qubit -> !qco.qubit
    %192 = qco.sx %191 : !qco.qubit -> !qco.qubit
    %193 = qco.rz(%cst_3) %192 : !qco.qubit -> !qco.qubit
    %194 = qco.rz(%cst_2) %controls_out_17 : !qco.qubit -> !qco.qubit
    %195 = qco.sx %194 : !qco.qubit -> !qco.qubit
    %196 = qco.rz(%cst_1) %195 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%193) targets (%arg12 = %196) {
      %240 = qco.x %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %240 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %197 = qco.rz(%cst_0) %targets_out_24 : !qco.qubit -> !qco.qubit
    %198 = qco.sx %197 : !qco.qubit -> !qco.qubit
    %199 = arith.divf %arg10, %cst_6 : f64
    %200 = math.tan %199 : f64
    %201 = math.atan %200 : f64
    %202 = arith.mulf %201, %cst_6 : f64
    %203 = arith.addf %202, %cst_5 : f64
    %204 = arith.divf %203, %cst_6 : f64
    %205 = math.tan %204 : f64
    %206 = math.atan %205 : f64
    %207 = arith.mulf %206, %cst_6 : f64
    %208 = arith.addf %207, %cst : f64
    %209 = qco.rz(%208) %198 : !qco.qubit -> !qco.qubit
    %210 = qco.sx %209 : !qco.qubit -> !qco.qubit
    %211 = qco.rz(%cst_4) %210 : !qco.qubit -> !qco.qubit
    %212 = qco.sx %211 : !qco.qubit -> !qco.qubit
    %213 = qco.rz(%cst_3) %212 : !qco.qubit -> !qco.qubit
    %214 = qco.rz(%cst_2) %controls_out_19 : !qco.qubit -> !qco.qubit
    %215 = qco.sx %214 : !qco.qubit -> !qco.qubit
    %216 = qco.rz(%cst_1) %215 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%213) targets (%arg12 = %216) {
      %240 = qco.x %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %240 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %217 = qco.rz(%cst_0) %targets_out_26 : !qco.qubit -> !qco.qubit
    %218 = qco.sx %217 : !qco.qubit -> !qco.qubit
    %219 = arith.divf %arg11, %cst_6 : f64
    %220 = math.tan %219 : f64
    %221 = math.atan %220 : f64
    %222 = arith.mulf %221, %cst_6 : f64
    %223 = arith.addf %222, %cst_5 : f64
    %224 = arith.divf %223, %cst_6 : f64
    %225 = math.tan %224 : f64
    %226 = math.atan %225 : f64
    %227 = arith.mulf %226, %cst_6 : f64
    %228 = arith.addf %227, %cst : f64
    %229 = qco.rz(%228) %218 : !qco.qubit -> !qco.qubit
    %230 = qco.sx %229 : !qco.qubit -> !qco.qubit
    %231 = qco.rz(%cst_4) %230 : !qco.qubit -> !qco.qubit
    %232 = qco.sx %231 : !qco.qubit -> !qco.qubit
    %233 = qco.rz(%cst_3) %232 : !qco.qubit -> !qco.qubit
    qco.sink %controls_out_23 : !qco.qubit
    qco.sink %controls_out_25 : !qco.qubit
    %234 = qco.rz(%cst_2) %controls_out_21 : !qco.qubit -> !qco.qubit
    %235 = qco.sx %234 : !qco.qubit -> !qco.qubit
    %236 = qco.rz(%cst_1) %235 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%233) targets (%arg12 = %236) {
      %240 = qco.x %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %240 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %237 = qco.rz(%cst_0) %targets_out_28 : !qco.qubit -> !qco.qubit
    %238 = qco.sx %237 : !qco.qubit -> !qco.qubit
    %239 = qco.rz(%cst) %238 : !qco.qubit -> !qco.qubit
    qco.sink %239 : !qco.qubit
    qco.sink %controls_out_27 : !qco.qubit
    return %c0_i64 : i64
  }
}
