module attributes {mqt.layout = {initial = array<i64: 3, 1, 2, 0, 5, 7, 4, 6>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948983 : f64
    %cst_0 = arith.constant 3.1415926535897918 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %cst_2 = arith.constant -0.78539816339744739 : f64
    %cst_3 = arith.constant 3.1415926535897931 : f64
    %cst_4 = arith.constant 2.3561944901923453 : f64
    %cst_5 = arith.constant 3.1415926535897927 : f64
    %cst_6 = arith.constant 1.5707963267948968 : f64
    %cst_7 = arith.constant 2.3561944901923448 : f64
    %cst_8 = arith.constant -0.78539816339744916 : f64
    %cst_9 = arith.constant 7.8539816339744819 : f64
    %cst_10 = arith.constant 2.7488935718910694 : f64
    %cst_11 = arith.constant 3.1415926535897922 : f64
    %cst_12 = arith.constant 2.748893571891069 : f64
    %cst_13 = arith.constant -1.178097245096172 : f64
    %cst_14 = arith.constant 7.853981633974481 : f64
    %cst_15 = arith.constant 3.1415926535897913 : f64
    %cst_16 = arith.constant 1.5707963267948961 : f64
    %cst_17 = arith.constant 2.9452431127404313 : f64
    %cst_18 = arith.constant -1.3744467859455352 : f64
    %cst_19 = arith.constant 1.570796326794897 : f64
    %cst_20 = arith.constant 6.2831853071795862 : f64
    %cst_21 = arith.constant 7.8539816339744828 : f64
    %cst_22 = arith.constant 1.5707963267948966 : f64
    %cst_23 = arith.constant 0.000000e+00 : f64
    %cst_24 = arith.constant 4.7123889803846897 : f64
    %cst_25 = arith.constant 9.4247779607693793 : f64
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.r(%cst_25, %cst_23) %0 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_25, %cst_23) %1 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_25, %cst_23) %4 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_25, %cst_23) %5 : !qco.qubit -> !qco.qubit
    %12 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %13 = qco.r(%cst_22, %cst_22) %6 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_3, %cst_23) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_24, %cst_23) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_22, %cst_22) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_21, %cst_23) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_3, %cst_23) %10 : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst_6, %cst_22) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_24, %cst_23) %19 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%20) targets (%arg0 = %17) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.r(%cst_24, %cst_23) %targets_out : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_22, %cst_22) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_24, %cst_23) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_2, %cst_23) %controls_out : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_19, %cst_22) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_6, %cst_23) %25 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%26) targets (%arg0 = %23) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %27 = qco.r(%cst_1, %cst_23) %targets_out_27 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_7, %cst_22) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.r(%cst_24, %cst_23) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_5, %cst_23) %controls_out_26 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%cst_7, %cst_22) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_1, %cst_23) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_24, %cst_23) %29 : !qco.qubit -> !qco.qubit
    %34 = qco.r(%cst_22, %cst_22) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst_6, %cst_23) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_3, %cst_23) %7 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%cst_6, %cst_22) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst_24, %cst_23) %37 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%38) targets (%arg0 = %35) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.r(%cst_24, %cst_23) %targets_out_29 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_22, %cst_22) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst_24, %cst_23) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst_13, %cst_23) %controls_out_28 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%cst_19, %cst_22) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_22, %cst_23) %43 : !qco.qubit -> !qco.qubit
    %controls_out_30, %targets_out_31 = qco.ctrl(%44) targets (%arg0 = %41) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.r(%cst_1, %cst_23) %targets_out_31 : !qco.qubit -> !qco.qubit
    %46 = qco.r(%cst_12, %cst_22) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%cst_24, %cst_23) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst_0, %cst_23) %controls_out_30 : !qco.qubit -> !qco.qubit
    %49 = qco.r(%cst_10, %cst_22) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.r(%cst, %cst_23) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.r(%cst_24, %cst_23) %47 : !qco.qubit -> !qco.qubit
    %52 = qco.r(%cst_22, %cst_22) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst_6, %cst_23) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.r(%cst_3, %cst_23) %11 : !qco.qubit -> !qco.qubit
    %55 = qco.r(%cst_6, %cst_22) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.r(%cst_24, %cst_23) %55 : !qco.qubit -> !qco.qubit
    %controls_out_32, %targets_out_33 = qco.ctrl(%56) targets (%arg0 = %53) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %57 = qco.r(%cst_24, %cst_23) %targets_out_33 : !qco.qubit -> !qco.qubit
    %58 = qco.r(%cst_22, %cst_22) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%cst_24, %cst_23) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.r(%cst_18, %cst_23) %controls_out_32 : !qco.qubit -> !qco.qubit
    %61 = qco.r(%cst_19, %cst_22) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.r(%cst_22, %cst_23) %61 : !qco.qubit -> !qco.qubit
    %controls_out_34, %targets_out_35 = qco.ctrl(%62) targets (%arg0 = %59) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %63 = qco.r(%cst_1, %cst_23) %targets_out_35 : !qco.qubit -> !qco.qubit
    %64 = qco.r(%cst_17, %cst_22) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%cst_24, %cst_23) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.r(%cst_15, %cst_23) %controls_out_34 : !qco.qubit -> !qco.qubit
    %67 = qco.r(%cst_17, %cst_22) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.r(%cst, %cst_23) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.r(%cst_22, %cst_22) %32 : !qco.qubit -> !qco.qubit
    %70 = qco.r(%cst_3, %cst_23) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.r(%cst_24, %cst_23) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%cst_22, %cst_22) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%cst_21, %cst_23) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.r(%cst_3, %cst_23) %50 : !qco.qubit -> !qco.qubit
    %75 = qco.r(%cst_6, %cst_22) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.r(%cst_24, %cst_23) %75 : !qco.qubit -> !qco.qubit
    %controls_out_36, %targets_out_37 = qco.ctrl(%76) targets (%arg0 = %73) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qco.r(%cst_24, %cst_23) %targets_out_37 : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst_22, %cst_22) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.r(%cst_24, %cst_23) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.r(%cst_2, %cst_23) %controls_out_36 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%cst_19, %cst_22) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.r(%cst_6, %cst_23) %81 : !qco.qubit -> !qco.qubit
    %controls_out_38, %targets_out_39 = qco.ctrl(%82) targets (%arg0 = %79) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qco.r(%cst_1, %cst_23) %targets_out_39 : !qco.qubit -> !qco.qubit
    %84 = qco.r(%cst_7, %cst_22) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.r(%cst_24, %cst_23) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.r(%cst_5, %cst_23) %controls_out_38 : !qco.qubit -> !qco.qubit
    %87 = qco.r(%cst_7, %cst_22) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.r(%cst_1, %cst_23) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%cst_24, %cst_23) %85 : !qco.qubit -> !qco.qubit
    %90 = qco.r(%cst_22, %cst_22) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.r(%cst_6, %cst_23) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.r(%cst_3, %cst_23) %68 : !qco.qubit -> !qco.qubit
    %93 = qco.r(%cst_6, %cst_22) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.r(%cst_24, %cst_23) %93 : !qco.qubit -> !qco.qubit
    %controls_out_40, %targets_out_41 = qco.ctrl(%94) targets (%arg0 = %91) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %95 = qco.r(%cst_24, %cst_23) %targets_out_41 : !qco.qubit -> !qco.qubit
    %96 = qco.r(%cst_22, %cst_22) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.r(%cst_24, %cst_23) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.r(%cst_13, %cst_23) %controls_out_40 : !qco.qubit -> !qco.qubit
    %99 = qco.r(%cst_19, %cst_22) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.r(%cst_22, %cst_23) %99 : !qco.qubit -> !qco.qubit
    %controls_out_42, %targets_out_43 = qco.ctrl(%100) targets (%arg0 = %97) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %101 = qco.r(%cst_1, %cst_23) %targets_out_43 : !qco.qubit -> !qco.qubit
    %102 = qco.r(%cst_12, %cst_22) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.r(%cst_24, %cst_23) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.r(%cst_0, %cst_23) %controls_out_42 : !qco.qubit -> !qco.qubit
    %105 = qco.r(%cst_10, %cst_22) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.r(%cst, %cst_23) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.r(%cst_22, %cst_22) %88 : !qco.qubit -> !qco.qubit
    %108 = qco.r(%cst_3, %cst_23) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.r(%cst_24, %cst_23) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.r(%cst_22, %cst_22) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.r(%cst_21, %cst_23) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.r(%cst_3, %cst_23) %106 : !qco.qubit -> !qco.qubit
    %113 = qco.r(%cst_6, %cst_22) %112 : !qco.qubit -> !qco.qubit
    %114 = qco.r(%cst_24, %cst_23) %113 : !qco.qubit -> !qco.qubit
    %controls_out_44, %targets_out_45 = qco.ctrl(%114) targets (%arg0 = %111) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %115 = qco.r(%cst_24, %cst_23) %targets_out_45 : !qco.qubit -> !qco.qubit
    %116 = qco.r(%cst_22, %cst_22) %115 : !qco.qubit -> !qco.qubit
    %117 = qco.r(%cst_24, %cst_23) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.r(%cst_2, %cst_23) %controls_out_44 : !qco.qubit -> !qco.qubit
    %119 = qco.r(%cst_19, %cst_22) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.r(%cst_6, %cst_23) %119 : !qco.qubit -> !qco.qubit
    %controls_out_46, %targets_out_47 = qco.ctrl(%120) targets (%arg0 = %117) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %121 = qco.r(%cst_1, %cst_23) %targets_out_47 : !qco.qubit -> !qco.qubit
    %122 = qco.r(%cst_7, %cst_22) %121 : !qco.qubit -> !qco.qubit
    %123 = qco.r(%cst_24, %cst_23) %122 : !qco.qubit -> !qco.qubit
    %124 = qco.r(%cst_5, %cst_23) %controls_out_46 : !qco.qubit -> !qco.qubit
    %125 = qco.r(%cst_7, %cst_22) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.r(%cst_1, %cst_23) %125 : !qco.qubit -> !qco.qubit
    %127 = qco.r(%cst_22, %cst_22) %126 : !qco.qubit -> !qco.qubit
    %128 = qco.r(%cst_3, %cst_23) %127 : !qco.qubit -> !qco.qubit
    %controls_out_48, %targets_out_49 = qco.ctrl(%8) targets (%arg0 = %65) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %129 = qco.r(%cst_24, %cst_23) %targets_out_49 : !qco.qubit -> !qco.qubit
    %130 = qco.r(%cst_22, %cst_22) %129 : !qco.qubit -> !qco.qubit
    %131 = qco.r(%cst_21, %cst_23) %130 : !qco.qubit -> !qco.qubit
    %132 = qco.r(%cst_3, %cst_23) %2 : !qco.qubit -> !qco.qubit
    %133 = qco.r(%cst_6, %cst_22) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.r(%cst_24, %cst_23) %133 : !qco.qubit -> !qco.qubit
    %controls_out_50, %targets_out_51 = qco.ctrl(%134) targets (%arg0 = %131) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %135 = qco.r(%cst_24, %cst_23) %targets_out_51 : !qco.qubit -> !qco.qubit
    %136 = qco.r(%cst_22, %cst_22) %135 : !qco.qubit -> !qco.qubit
    %137 = qco.r(%cst_24, %cst_23) %136 : !qco.qubit -> !qco.qubit
    %138 = qco.r(%cst_2, %cst_23) %controls_out_50 : !qco.qubit -> !qco.qubit
    %139 = qco.r(%cst_19, %cst_22) %138 : !qco.qubit -> !qco.qubit
    %140 = qco.r(%cst_6, %cst_23) %139 : !qco.qubit -> !qco.qubit
    %controls_out_52, %targets_out_53 = qco.ctrl(%140) targets (%arg0 = %137) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %141 = qco.r(%cst_1, %cst_23) %targets_out_53 : !qco.qubit -> !qco.qubit
    %142 = qco.r(%cst_7, %cst_22) %141 : !qco.qubit -> !qco.qubit
    %143 = qco.r(%cst_24, %cst_23) %142 : !qco.qubit -> !qco.qubit
    %144 = qco.r(%cst_5, %cst_23) %controls_out_52 : !qco.qubit -> !qco.qubit
    %145 = qco.r(%cst_7, %cst_22) %144 : !qco.qubit -> !qco.qubit
    %146 = qco.r(%cst_1, %cst_23) %145 : !qco.qubit -> !qco.qubit
    %147 = qco.r(%cst_24, %cst_23) %143 : !qco.qubit -> !qco.qubit
    %148 = qco.r(%cst_22, %cst_22) %147 : !qco.qubit -> !qco.qubit
    %149 = qco.r(%cst_6, %cst_23) %148 : !qco.qubit -> !qco.qubit
    %150 = qco.r(%cst_3, %cst_23) %9 : !qco.qubit -> !qco.qubit
    %151 = qco.r(%cst_6, %cst_22) %150 : !qco.qubit -> !qco.qubit
    %152 = qco.r(%cst_24, %cst_23) %151 : !qco.qubit -> !qco.qubit
    %controls_out_54, %targets_out_55 = qco.ctrl(%152) targets (%arg0 = %149) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %153 = qco.r(%cst_24, %cst_23) %targets_out_55 : !qco.qubit -> !qco.qubit
    %154 = qco.r(%cst_22, %cst_22) %153 : !qco.qubit -> !qco.qubit
    %155 = qco.r(%cst_24, %cst_23) %154 : !qco.qubit -> !qco.qubit
    %156 = qco.r(%cst_13, %cst_23) %controls_out_54 : !qco.qubit -> !qco.qubit
    %157 = qco.r(%cst_19, %cst_22) %156 : !qco.qubit -> !qco.qubit
    %158 = qco.r(%cst_22, %cst_23) %157 : !qco.qubit -> !qco.qubit
    %controls_out_56, %targets_out_57 = qco.ctrl(%158) targets (%arg0 = %155) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %159 = qco.r(%cst_1, %cst_23) %targets_out_57 : !qco.qubit -> !qco.qubit
    %160 = qco.r(%cst_12, %cst_22) %159 : !qco.qubit -> !qco.qubit
    %161 = qco.r(%cst_24, %cst_23) %160 : !qco.qubit -> !qco.qubit
    %162 = qco.r(%cst_0, %cst_23) %controls_out_56 : !qco.qubit -> !qco.qubit
    %163 = qco.r(%cst_10, %cst_22) %162 : !qco.qubit -> !qco.qubit
    %164 = qco.r(%cst, %cst_23) %163 : !qco.qubit -> !qco.qubit
    %165 = qco.r(%cst_24, %cst_23) %161 : !qco.qubit -> !qco.qubit
    %166 = qco.r(%cst_22, %cst_22) %165 : !qco.qubit -> !qco.qubit
    %167 = qco.r(%cst_6, %cst_23) %166 : !qco.qubit -> !qco.qubit
    %168 = qco.r(%cst_3, %cst_23) %3 : !qco.qubit -> !qco.qubit
    %169 = qco.r(%cst_6, %cst_22) %168 : !qco.qubit -> !qco.qubit
    %170 = qco.r(%cst_24, %cst_23) %169 : !qco.qubit -> !qco.qubit
    %controls_out_58, %targets_out_59 = qco.ctrl(%170) targets (%arg0 = %167) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %171 = qco.r(%cst_24, %cst_23) %targets_out_59 : !qco.qubit -> !qco.qubit
    %172 = qco.r(%cst_22, %cst_22) %171 : !qco.qubit -> !qco.qubit
    %173 = qco.r(%cst_24, %cst_23) %172 : !qco.qubit -> !qco.qubit
    %174 = qco.r(%cst_18, %cst_23) %controls_out_58 : !qco.qubit -> !qco.qubit
    %175 = qco.r(%cst_19, %cst_22) %174 : !qco.qubit -> !qco.qubit
    %176 = qco.r(%cst_22, %cst_23) %175 : !qco.qubit -> !qco.qubit
    %controls_out_60, %targets_out_61 = qco.ctrl(%176) targets (%arg0 = %173) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %177 = qco.r(%cst_1, %cst_23) %targets_out_61 : !qco.qubit -> !qco.qubit
    %178 = qco.r(%cst_17, %cst_22) %177 : !qco.qubit -> !qco.qubit
    %179 = qco.r(%cst_24, %cst_23) %178 : !qco.qubit -> !qco.qubit
    %180 = qco.r(%cst_15, %cst_23) %controls_out_60 : !qco.qubit -> !qco.qubit
    %181 = qco.r(%cst_17, %cst_22) %180 : !qco.qubit -> !qco.qubit
    %182 = qco.r(%cst, %cst_23) %181 : !qco.qubit -> !qco.qubit
    %controls_out_62, %targets_out_63 = qco.ctrl(%146) targets (%arg0 = %103) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %183 = qco.r(%cst_24, %cst_23) %targets_out_63 : !qco.qubit -> !qco.qubit
    %184 = qco.r(%cst_22, %cst_22) %183 : !qco.qubit -> !qco.qubit
    %185 = qco.r(%cst_21, %cst_23) %184 : !qco.qubit -> !qco.qubit
    %186 = qco.r(%cst_3, %cst_23) %164 : !qco.qubit -> !qco.qubit
    %187 = qco.r(%cst_6, %cst_22) %186 : !qco.qubit -> !qco.qubit
    %188 = qco.r(%cst_24, %cst_23) %187 : !qco.qubit -> !qco.qubit
    %controls_out_64, %targets_out_65 = qco.ctrl(%188) targets (%arg0 = %185) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %189 = qco.r(%cst_24, %cst_23) %targets_out_65 : !qco.qubit -> !qco.qubit
    %190 = qco.r(%cst_22, %cst_22) %189 : !qco.qubit -> !qco.qubit
    %191 = qco.r(%cst_24, %cst_23) %190 : !qco.qubit -> !qco.qubit
    %192 = qco.r(%cst_2, %cst_23) %controls_out_64 : !qco.qubit -> !qco.qubit
    %193 = qco.r(%cst_19, %cst_22) %192 : !qco.qubit -> !qco.qubit
    %194 = qco.r(%cst_6, %cst_23) %193 : !qco.qubit -> !qco.qubit
    %controls_out_66, %targets_out_67 = qco.ctrl(%194) targets (%arg0 = %191) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %195 = qco.r(%cst_1, %cst_23) %targets_out_67 : !qco.qubit -> !qco.qubit
    %196 = qco.r(%cst_7, %cst_22) %195 : !qco.qubit -> !qco.qubit
    %197 = qco.r(%cst_24, %cst_23) %196 : !qco.qubit -> !qco.qubit
    %198 = qco.r(%cst_5, %cst_23) %controls_out_66 : !qco.qubit -> !qco.qubit
    %199 = qco.r(%cst_7, %cst_22) %198 : !qco.qubit -> !qco.qubit
    %200 = qco.r(%cst_1, %cst_23) %199 : !qco.qubit -> !qco.qubit
    %201 = qco.r(%cst_24, %cst_23) %197 : !qco.qubit -> !qco.qubit
    %202 = qco.r(%cst_22, %cst_22) %201 : !qco.qubit -> !qco.qubit
    %203 = qco.r(%cst_6, %cst_23) %202 : !qco.qubit -> !qco.qubit
    %204 = qco.r(%cst_3, %cst_23) %182 : !qco.qubit -> !qco.qubit
    %205 = qco.r(%cst_6, %cst_22) %204 : !qco.qubit -> !qco.qubit
    %206 = qco.r(%cst_24, %cst_23) %205 : !qco.qubit -> !qco.qubit
    %controls_out_68, %targets_out_69 = qco.ctrl(%206) targets (%arg0 = %203) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %207 = qco.r(%cst_24, %cst_23) %targets_out_69 : !qco.qubit -> !qco.qubit
    %208 = qco.r(%cst_22, %cst_22) %207 : !qco.qubit -> !qco.qubit
    %209 = qco.r(%cst_24, %cst_23) %208 : !qco.qubit -> !qco.qubit
    %210 = qco.r(%cst_13, %cst_23) %controls_out_68 : !qco.qubit -> !qco.qubit
    %211 = qco.r(%cst_19, %cst_22) %210 : !qco.qubit -> !qco.qubit
    %212 = qco.r(%cst_22, %cst_23) %211 : !qco.qubit -> !qco.qubit
    %controls_out_70, %targets_out_71 = qco.ctrl(%212) targets (%arg0 = %209) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %213 = qco.r(%cst_1, %cst_23) %targets_out_71 : !qco.qubit -> !qco.qubit
    %214 = qco.r(%cst_12, %cst_22) %213 : !qco.qubit -> !qco.qubit
    %215 = qco.r(%cst_24, %cst_23) %214 : !qco.qubit -> !qco.qubit
    %216 = qco.r(%cst_0, %cst_23) %controls_out_70 : !qco.qubit -> !qco.qubit
    %217 = qco.r(%cst_10, %cst_22) %216 : !qco.qubit -> !qco.qubit
    %218 = qco.r(%cst, %cst_23) %217 : !qco.qubit -> !qco.qubit
    %controls_out_72, %targets_out_73 = qco.ctrl(%200) targets (%arg0 = %123) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %219 = qco.r(%cst_24, %cst_23) %targets_out_73 : !qco.qubit -> !qco.qubit
    %220 = qco.r(%cst_22, %cst_22) %219 : !qco.qubit -> !qco.qubit
    %221 = qco.r(%cst_21, %cst_23) %220 : !qco.qubit -> !qco.qubit
    %222 = qco.r(%cst_3, %cst_23) %218 : !qco.qubit -> !qco.qubit
    %223 = qco.r(%cst_6, %cst_22) %222 : !qco.qubit -> !qco.qubit
    %224 = qco.r(%cst_24, %cst_23) %223 : !qco.qubit -> !qco.qubit
    %controls_out_74, %targets_out_75 = qco.ctrl(%224) targets (%arg0 = %221) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %225 = qco.r(%cst_24, %cst_23) %targets_out_75 : !qco.qubit -> !qco.qubit
    %226 = qco.r(%cst_22, %cst_22) %225 : !qco.qubit -> !qco.qubit
    %227 = qco.r(%cst_24, %cst_23) %226 : !qco.qubit -> !qco.qubit
    %228 = qco.r(%cst_2, %cst_23) %controls_out_74 : !qco.qubit -> !qco.qubit
    %229 = qco.r(%cst_19, %cst_22) %228 : !qco.qubit -> !qco.qubit
    %230 = qco.r(%cst_6, %cst_23) %229 : !qco.qubit -> !qco.qubit
    %controls_out_76, %targets_out_77 = qco.ctrl(%230) targets (%arg0 = %227) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %231 = qco.r(%cst_1, %cst_23) %targets_out_77 : !qco.qubit -> !qco.qubit
    %232 = qco.r(%cst_7, %cst_22) %231 : !qco.qubit -> !qco.qubit
    %233 = qco.r(%cst_24, %cst_23) %232 : !qco.qubit -> !qco.qubit
    %234 = qco.r(%cst_5, %cst_23) %controls_out_76 : !qco.qubit -> !qco.qubit
    %235 = qco.r(%cst_7, %cst_22) %234 : !qco.qubit -> !qco.qubit
    %236 = qco.r(%cst_1, %cst_23) %235 : !qco.qubit -> !qco.qubit
    %controls_out_78, %targets_out_79 = qco.ctrl(%236) targets (%arg0 = %128) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %237 = qco.r(%cst_22, %cst_22) %targets_out_79 : !qco.qubit -> !qco.qubit
    %238 = qco.r(%cst_3, %cst_23) %237 : !qco.qubit -> !qco.qubit
    %239 = qco.r(%cst_24, %cst_23) %233 : !qco.qubit -> !qco.qubit
    %240 = qco.r(%cst_22, %cst_22) %239 : !qco.qubit -> !qco.qubit
    %241 = qco.r(%cst_21, %cst_23) %240 : !qco.qubit -> !qco.qubit
    %242 = qco.r(%cst_20, %cst_23) %238 : !qco.qubit -> !qco.qubit
    %243 = qco.r(%cst_19, %cst_22) %242 : !qco.qubit -> !qco.qubit
    %244 = qco.r(%cst_24, %cst_23) %243 : !qco.qubit -> !qco.qubit
    %controls_out_80, %targets_out_81 = qco.ctrl(%244) targets (%arg0 = %241) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %245 = qco.r(%cst_24, %cst_23) %targets_out_81 : !qco.qubit -> !qco.qubit
    %246 = qco.r(%cst_22, %cst_22) %245 : !qco.qubit -> !qco.qubit
    %247 = qco.r(%cst_24, %cst_23) %246 : !qco.qubit -> !qco.qubit
    %248 = qco.r(%cst_8, %cst_23) %controls_out_80 : !qco.qubit -> !qco.qubit
    %249 = qco.r(%cst_19, %cst_22) %248 : !qco.qubit -> !qco.qubit
    %250 = qco.r(%cst_22, %cst_23) %249 : !qco.qubit -> !qco.qubit
    %controls_out_82, %targets_out_83 = qco.ctrl(%250) targets (%arg0 = %247) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %251 = qco.r(%cst_19, %cst_23) %targets_out_83 : !qco.qubit -> !qco.qubit
    %252 = qco.r(%cst_7, %cst_22) %251 : !qco.qubit -> !qco.qubit
    %253 = qco.r(%cst_6, %cst_23) %252 : !qco.qubit -> !qco.qubit
    %254 = qco.r(%cst_5, %cst_23) %controls_out_82 : !qco.qubit -> !qco.qubit
    %255 = qco.r(%cst_4, %cst_22) %254 : !qco.qubit -> !qco.qubit
    %256 = qco.r(%cst_21, %cst_23) %255 : !qco.qubit -> !qco.qubit
    %257 = qco.r(%cst_22, %cst_22) %253 : !qco.qubit -> !qco.qubit
    %258 = qco.r(%cst_3, %cst_23) %257 : !qco.qubit -> !qco.qubit
    %259 = qco.r(%cst_24, %cst_23) %215 : !qco.qubit -> !qco.qubit
    %260 = qco.r(%cst_22, %cst_22) %259 : !qco.qubit -> !qco.qubit
    %261 = qco.r(%cst_21, %cst_23) %260 : !qco.qubit -> !qco.qubit
    %262 = qco.r(%cst_20, %cst_23) %258 : !qco.qubit -> !qco.qubit
    %263 = qco.r(%cst_19, %cst_22) %262 : !qco.qubit -> !qco.qubit
    %264 = qco.r(%cst_24, %cst_23) %263 : !qco.qubit -> !qco.qubit
    %controls_out_84, %targets_out_85 = qco.ctrl(%264) targets (%arg0 = %261) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %265 = qco.r(%cst_24, %cst_23) %targets_out_85 : !qco.qubit -> !qco.qubit
    %266 = qco.r(%cst_22, %cst_22) %265 : !qco.qubit -> !qco.qubit
    %267 = qco.r(%cst_24, %cst_23) %266 : !qco.qubit -> !qco.qubit
    %268 = qco.r(%cst_8, %cst_23) %controls_out_84 : !qco.qubit -> !qco.qubit
    %269 = qco.r(%cst_19, %cst_22) %268 : !qco.qubit -> !qco.qubit
    %270 = qco.r(%cst_22, %cst_23) %269 : !qco.qubit -> !qco.qubit
    %controls_out_86, %targets_out_87 = qco.ctrl(%270) targets (%arg0 = %267) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %271 = qco.r(%cst_19, %cst_23) %targets_out_87 : !qco.qubit -> !qco.qubit
    %272 = qco.r(%cst_7, %cst_22) %271 : !qco.qubit -> !qco.qubit
    %273 = qco.r(%cst_6, %cst_23) %272 : !qco.qubit -> !qco.qubit
    %274 = qco.r(%cst_5, %cst_23) %controls_out_86 : !qco.qubit -> !qco.qubit
    %275 = qco.r(%cst_4, %cst_22) %274 : !qco.qubit -> !qco.qubit
    %276 = qco.r(%cst_21, %cst_23) %275 : !qco.qubit -> !qco.qubit
    %277 = qco.r(%cst_24, %cst_23) %273 : !qco.qubit -> !qco.qubit
    %278 = qco.r(%cst_22, %cst_22) %277 : !qco.qubit -> !qco.qubit
    %279 = qco.r(%cst_21, %cst_23) %278 : !qco.qubit -> !qco.qubit
    %280 = qco.r(%cst_20, %cst_23) %256 : !qco.qubit -> !qco.qubit
    %281 = qco.r(%cst_19, %cst_22) %280 : !qco.qubit -> !qco.qubit
    %282 = qco.r(%cst_24, %cst_23) %281 : !qco.qubit -> !qco.qubit
    %controls_out_88, %targets_out_89 = qco.ctrl(%282) targets (%arg0 = %279) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %283 = qco.r(%cst_24, %cst_23) %targets_out_89 : !qco.qubit -> !qco.qubit
    %284 = qco.r(%cst_22, %cst_22) %283 : !qco.qubit -> !qco.qubit
    %285 = qco.r(%cst_24, %cst_23) %284 : !qco.qubit -> !qco.qubit
    %286 = qco.r(%cst_13, %cst_23) %controls_out_88 : !qco.qubit -> !qco.qubit
    %287 = qco.r(%cst_19, %cst_22) %286 : !qco.qubit -> !qco.qubit
    %288 = qco.r(%cst_22, %cst_23) %287 : !qco.qubit -> !qco.qubit
    %controls_out_90, %targets_out_91 = qco.ctrl(%288) targets (%arg0 = %285) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %289 = qco.r(%cst_19, %cst_23) %targets_out_91 : !qco.qubit -> !qco.qubit
    %290 = qco.r(%cst_12, %cst_22) %289 : !qco.qubit -> !qco.qubit
    %291 = qco.r(%cst_22, %cst_23) %290 : !qco.qubit -> !qco.qubit
    %292 = qco.r(%cst_11, %cst_23) %controls_out_90 : !qco.qubit -> !qco.qubit
    %293 = qco.r(%cst_10, %cst_22) %292 : !qco.qubit -> !qco.qubit
    %294 = qco.r(%cst_9, %cst_23) %293 : !qco.qubit -> !qco.qubit
    %295 = qco.r(%cst_22, %cst_22) %291 : !qco.qubit -> !qco.qubit
    %296 = qco.r(%cst_3, %cst_23) %295 : !qco.qubit -> !qco.qubit
    %297 = qco.r(%cst_24, %cst_23) %179 : !qco.qubit -> !qco.qubit
    %298 = qco.r(%cst_22, %cst_22) %297 : !qco.qubit -> !qco.qubit
    %299 = qco.r(%cst_21, %cst_23) %298 : !qco.qubit -> !qco.qubit
    %300 = qco.r(%cst_20, %cst_23) %296 : !qco.qubit -> !qco.qubit
    %301 = qco.r(%cst_19, %cst_22) %300 : !qco.qubit -> !qco.qubit
    %302 = qco.r(%cst_24, %cst_23) %301 : !qco.qubit -> !qco.qubit
    %controls_out_92, %targets_out_93 = qco.ctrl(%302) targets (%arg0 = %299) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %303 = qco.r(%cst_24, %cst_23) %targets_out_93 : !qco.qubit -> !qco.qubit
    %304 = qco.r(%cst_22, %cst_22) %303 : !qco.qubit -> !qco.qubit
    %305 = qco.r(%cst_24, %cst_23) %304 : !qco.qubit -> !qco.qubit
    %306 = qco.r(%cst_8, %cst_23) %controls_out_92 : !qco.qubit -> !qco.qubit
    %307 = qco.r(%cst_19, %cst_22) %306 : !qco.qubit -> !qco.qubit
    %308 = qco.r(%cst_22, %cst_23) %307 : !qco.qubit -> !qco.qubit
    %controls_out_94, %targets_out_95 = qco.ctrl(%308) targets (%arg0 = %305) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %309 = qco.r(%cst_19, %cst_23) %targets_out_95 : !qco.qubit -> !qco.qubit
    %310 = qco.r(%cst_7, %cst_22) %309 : !qco.qubit -> !qco.qubit
    %311 = qco.r(%cst_6, %cst_23) %310 : !qco.qubit -> !qco.qubit
    %312 = qco.r(%cst_5, %cst_23) %controls_out_94 : !qco.qubit -> !qco.qubit
    %313 = qco.r(%cst_4, %cst_22) %312 : !qco.qubit -> !qco.qubit
    %314 = qco.r(%cst_21, %cst_23) %313 : !qco.qubit -> !qco.qubit
    %315 = qco.r(%cst_24, %cst_23) %311 : !qco.qubit -> !qco.qubit
    %316 = qco.r(%cst_22, %cst_22) %315 : !qco.qubit -> !qco.qubit
    %317 = qco.r(%cst_21, %cst_23) %316 : !qco.qubit -> !qco.qubit
    %318 = qco.r(%cst_20, %cst_23) %276 : !qco.qubit -> !qco.qubit
    %319 = qco.r(%cst_19, %cst_22) %318 : !qco.qubit -> !qco.qubit
    %320 = qco.r(%cst_24, %cst_23) %319 : !qco.qubit -> !qco.qubit
    %controls_out_96, %targets_out_97 = qco.ctrl(%320) targets (%arg0 = %317) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %321 = qco.r(%cst_24, %cst_23) %targets_out_97 : !qco.qubit -> !qco.qubit
    %322 = qco.r(%cst_22, %cst_22) %321 : !qco.qubit -> !qco.qubit
    %323 = qco.r(%cst_24, %cst_23) %322 : !qco.qubit -> !qco.qubit
    %324 = qco.r(%cst_13, %cst_23) %controls_out_96 : !qco.qubit -> !qco.qubit
    %325 = qco.r(%cst_19, %cst_22) %324 : !qco.qubit -> !qco.qubit
    %326 = qco.r(%cst_22, %cst_23) %325 : !qco.qubit -> !qco.qubit
    %controls_out_98, %targets_out_99 = qco.ctrl(%326) targets (%arg0 = %323) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %327 = qco.r(%cst_19, %cst_23) %targets_out_99 : !qco.qubit -> !qco.qubit
    %328 = qco.r(%cst_12, %cst_22) %327 : !qco.qubit -> !qco.qubit
    %329 = qco.r(%cst_22, %cst_23) %328 : !qco.qubit -> !qco.qubit
    %330 = qco.r(%cst_11, %cst_23) %controls_out_98 : !qco.qubit -> !qco.qubit
    %331 = qco.r(%cst_10, %cst_22) %330 : !qco.qubit -> !qco.qubit
    %332 = qco.r(%cst_9, %cst_23) %331 : !qco.qubit -> !qco.qubit
    %333 = qco.r(%cst_24, %cst_23) %329 : !qco.qubit -> !qco.qubit
    %334 = qco.r(%cst_22, %cst_22) %333 : !qco.qubit -> !qco.qubit
    %335 = qco.r(%cst_21, %cst_23) %334 : !qco.qubit -> !qco.qubit
    %336 = qco.r(%cst_20, %cst_23) %294 : !qco.qubit -> !qco.qubit
    %337 = qco.r(%cst_19, %cst_22) %336 : !qco.qubit -> !qco.qubit
    %338 = qco.r(%cst_24, %cst_23) %337 : !qco.qubit -> !qco.qubit
    %controls_out_100, %targets_out_101 = qco.ctrl(%338) targets (%arg0 = %335) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %339 = qco.r(%cst_24, %cst_23) %targets_out_101 : !qco.qubit -> !qco.qubit
    %340 = qco.r(%cst_22, %cst_22) %339 : !qco.qubit -> !qco.qubit
    %341 = qco.r(%cst_24, %cst_23) %340 : !qco.qubit -> !qco.qubit
    %342 = qco.r(%cst_18, %cst_23) %controls_out_100 : !qco.qubit -> !qco.qubit
    %343 = qco.r(%cst_19, %cst_22) %342 : !qco.qubit -> !qco.qubit
    %344 = qco.r(%cst_22, %cst_23) %343 : !qco.qubit -> !qco.qubit
    %controls_out_102, %targets_out_103 = qco.ctrl(%344) targets (%arg0 = %341) {
      %353 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %353 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %345 = qco.r(%cst_22, %cst_23) %targets_out_103 : !qco.qubit -> !qco.qubit
    %346 = qco.r(%cst_17, %cst_22) %345 : !qco.qubit -> !qco.qubit
    %347 = qco.r(%cst_16, %cst_23) %346 : !qco.qubit -> !qco.qubit
    %348 = qco.r(%cst_15, %cst_23) %controls_out_102 : !qco.qubit -> !qco.qubit
    %349 = qco.r(%cst_17, %cst_22) %348 : !qco.qubit -> !qco.qubit
    %350 = qco.r(%cst_14, %cst_23) %349 : !qco.qubit -> !qco.qubit
    %351 = qco.r(%cst_22, %cst_22) %347 : !qco.qubit -> !qco.qubit
    %352 = qco.r(%cst_3, %cst_23) %351 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %350 : !qco.qubit
    cbit.store %result, %12[%c0] : !cbit.reg<8>
    %qubit_out_104, %result_105 = qco.measure %332 : !qco.qubit
    cbit.store %result_105, %12[%c1] : !cbit.reg<8>
    %qubit_out_106, %result_107 = qco.measure %314 : !qco.qubit
    cbit.store %result_107, %12[%c2] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_104 : !qco.qubit
    qco.sink %qubit_out_106 : !qco.qubit
    %qubit_out_108, %result_109 = qco.measure %352 : !qco.qubit
    qco.sink %qubit_out_108 : !qco.qubit
    cbit.store %result_109, %12[%c3] : !cbit.reg<8>
    %qubit_out_110, %result_111 = qco.measure %controls_out_78 : !qco.qubit
    cbit.store %result_111, %12[%c4] : !cbit.reg<8>
    %qubit_out_112, %result_113 = qco.measure %controls_out_72 : !qco.qubit
    cbit.store %result_113, %12[%c5] : !cbit.reg<8>
    %qubit_out_114, %result_115 = qco.measure %controls_out_62 : !qco.qubit
    cbit.store %result_115, %12[%c6] : !cbit.reg<8>
    qco.sink %qubit_out_110 : !qco.qubit
    qco.sink %qubit_out_112 : !qco.qubit
    qco.sink %qubit_out_114 : !qco.qubit
    %qubit_out_116, %result_117 = qco.measure %controls_out_48 : !qco.qubit
    qco.sink %qubit_out_116 : !qco.qubit
    cbit.store %result_117, %12[%c7] : !cbit.reg<8>
    %cst_118 = arith.constant -1.4726215563701786 : f64
    qco.gphase(%cst_118)
    return %12 : !cbit.reg<8>
  }
}
