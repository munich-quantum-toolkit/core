module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant 5.0737561042913972 : f64
    %cst_0 = arith.constant -1.570796326794897 : f64
    %cst_1 = arith.constant 3.4633432079864357 : f64
    %cst_2 = arith.constant 1.8925468811915382 : f64
    %cst_3 = arith.constant 5.0999856670398698 : f64
    %cst_4 = arith.constant 5.0999856670398707 : f64
    %cst_5 = arith.constant 6.2831853071795853 : f64
    %cst_6 = arith.constant 3.2081608173656164 : f64
    %cst_7 = arith.constant 4.7789571441605139 : f64
    %cst_8 = arith.constant 5.1329233156686547 : f64
    %cst_9 = arith.constant 3.141592653589794 : f64
    %cst_10 = arith.constant 3.6355340225093742 : f64
    %cst_11 = arith.constant 5.2063303493042721 : f64
    %cst_12 = arith.constant -3.1415926535897931 : f64
    %cst_13 = arith.constant 5.1760365893854958 : f64
    %cst_14 = arith.constant -3.1415926535897936 : f64
    %cst_15 = arith.constant 6.2831853071795862 : f64
    %cst_16 = arith.constant -1.5707963267948961 : f64
    %cst_17 = arith.constant 0.78539816339744828 : f64
    %cst_18 = arith.constant -2.3561944901923448 : f64
    %cst_19 = arith.constant 5.2359877559829879 : f64
    %cst_20 = arith.constant -1.5707963267948957 : f64
    %cst_21 = arith.constant -1.9614033704925831 : f64
    %cst_22 = arith.constant 6.2831853071795845 : f64
    %cst_23 = arith.constant -0.39060704369768695 : f64
    %cst_24 = arith.constant 3.1415926535897931 : f64
    %cst_25 = arith.constant 5.3278686890550766 : f64
    %cst_26 = arith.constant 4.7123889803846906 : f64
    %cst_27 = arith.constant 4.0969092717143027 : f64
    %cst_28 = arith.constant 3.1415926535897927 : f64
    %cst_29 = arith.constant -6.2831853071795862 : f64
    %cst_30 = arith.constant 3.1415926535897936 : f64
    %cst_31 = arith.constant 5.4977871437821371 : f64
    %cst_32 = arith.constant 4.7123889803846897 : f64
    %cst_33 = arith.constant 3.1415926535897944 : f64
    %cst_34 = arith.constant -1.5707963267948966 : f64
    %cst_35 = arith.constant 1.5707963267948979 : f64
    %cst_36 = arith.constant 5.4977871437821388 : f64
    %cst_37 = arith.constant 1.5707963267948966 : f64
    %cst_38 = arith.constant -3.1415926535897918 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %9 = qco.rx(%cst_24) %0 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_30) %1 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_37) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_37) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_32) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_24) %9 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%15) targets (%arg0 = %14) {
      %147 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %147 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.rz(%cst_32) %targets_out : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_37) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_37) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_24) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_29) %controls_out : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst_37) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_37) %22 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%23) targets (%arg0 = %20) {
      %147 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %147 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.rz(%cst_37) %targets_out_40 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_24) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_15) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_16) %controls_out_39 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_37) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_12) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_30) %2 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_37) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_4) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_37) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_32) %33 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%26) targets (%arg0 = %34) {
      %147 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %147 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.rz(%cst_32) %targets_out_42 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_37) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_3) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rx(%cst_37) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_24) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_29) %controls_out_41 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_37) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_37) %41 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%42) targets (%arg0 = %39) {
      %147 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %147 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qco.rz(%cst_2) %targets_out_44 : !qco.qubit -> !qco.qubit
    %44 = qco.rx(%cst_24) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_1) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_0) %controls_out_43 : !qco.qubit -> !qco.qubit
    %47 = qco.rx(%cst_37) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_15) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_9) %3 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_37) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_8) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rx(%cst_37) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_32) %52 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%45) targets (%arg0 = %53) {
      %147 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %147 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %54 = qco.rz(%cst_32) %targets_out_46 : !qco.qubit -> !qco.qubit
    %55 = qco.rx(%cst_37) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_8) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rx(%cst_37) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_30) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_29) %controls_out_45 : !qco.qubit -> !qco.qubit
    %60 = qco.rx(%cst_37) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_37) %60 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%61) targets (%arg0 = %58) {
      %147 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %147 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %62 = qco.rz(%cst_7) %targets_out_48 : !qco.qubit -> !qco.qubit
    %63 = qco.rx(%cst_37) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_22) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rx(%cst_37) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_6) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_20) %controls_out_47 : !qco.qubit -> !qco.qubit
    %68 = qco.rx(%cst_37) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_5) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_14) %4 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_37) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_13) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rx(%cst_37) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_32) %73 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%66) targets (%arg0 = %74) {
      %147 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %147 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %75 = qco.rz(%cst_32) %targets_out_50 : !qco.qubit -> !qco.qubit
    %76 = qco.rx(%cst_37) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_13) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rx(%cst_37) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_30) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_29) %controls_out_49 : !qco.qubit -> !qco.qubit
    %81 = qco.rx(%cst_37) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_37) %81 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%82) targets (%arg0 = %79) {
      %147 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %147 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qco.rz(%cst_11) %targets_out_52 : !qco.qubit -> !qco.qubit
    %84 = qco.rx(%cst_24) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_10) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_34) %controls_out_51 : !qco.qubit -> !qco.qubit
    %87 = qco.rx(%cst_37) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_30) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_30) %5 : !qco.qubit -> !qco.qubit
    %90 = qco.rx(%cst_37) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_19) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rx(%cst_37) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_32) %92 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%85) targets (%arg0 = %93) {
      %147 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %147 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %94 = qco.rz(%cst_32) %targets_out_54 : !qco.qubit -> !qco.qubit
    %95 = qco.rx(%cst_37) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_19) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rx(%cst_37) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_30) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_29) %controls_out_53 : !qco.qubit -> !qco.qubit
    %100 = qco.rx(%cst_37) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst_37) %100 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%101) targets (%arg0 = %98) {
      %147 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %147 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %102 = qco.rz(%cst_18) %targets_out_56 : !qco.qubit -> !qco.qubit
    %103 = qco.rx(%cst_37) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_33) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rx(%cst_37) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_17) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rz(%cst_16) %controls_out_55 : !qco.qubit -> !qco.qubit
    %108 = qco.rx(%cst_37) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rz(%cst_15) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rx(%cst_37) %6 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_27) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rx(%cst_37) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_26) %112 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%106) targets (%arg0 = %113) {
      %147 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %147 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %114 = qco.rz(%cst_32) %targets_out_58 : !qco.qubit -> !qco.qubit
    %115 = qco.rx(%cst_37) %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst_25) %115 : !qco.qubit -> !qco.qubit
    %117 = qco.rx(%cst_37) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_24) %117 : !qco.qubit -> !qco.qubit
    %119 = qco.rz(%cst_29) %controls_out_57 : !qco.qubit -> !qco.qubit
    %120 = qco.rx(%cst_37) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rz(%cst_37) %120 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%121) targets (%arg0 = %118) {
      %147 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %147 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %122 = qco.rz(%cst_23) %targets_out_60 : !qco.qubit -> !qco.qubit
    %123 = qco.rx(%cst_37) %122 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_22) %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rx(%cst_37) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst_21) %125 : !qco.qubit -> !qco.qubit
    %127 = qco.rz(%cst_20) %controls_out_59 : !qco.qubit -> !qco.qubit
    %128 = qco.rx(%cst_37) %127 : !qco.qubit -> !qco.qubit
    %129 = qco.rz(%cst_30) %128 : !qco.qubit -> !qco.qubit
    %130 = qco.rz(%cst_38) %7 : !qco.qubit -> !qco.qubit
    %131 = qco.rx(%cst_37) %130 : !qco.qubit -> !qco.qubit
    %132 = qco.rz(%cst_36) %131 : !qco.qubit -> !qco.qubit
    %133 = qco.rx(%cst_37) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.rz(%cst_35) %133 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%126) targets (%arg0 = %134) {
      %147 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %147 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %135 = qco.rz(%cst_32) %targets_out_62 : !qco.qubit -> !qco.qubit
    %136 = qco.rx(%cst_37) %135 : !qco.qubit -> !qco.qubit
    %137 = qco.rz(%cst_31) %136 : !qco.qubit -> !qco.qubit
    %138 = qco.rx(%cst_37) %137 : !qco.qubit -> !qco.qubit
    %139 = qco.rz(%cst_30) %138 : !qco.qubit -> !qco.qubit
    %140 = qco.rz(%cst_29) %controls_out_61 : !qco.qubit -> !qco.qubit
    %141 = qco.rx(%cst_37) %140 : !qco.qubit -> !qco.qubit
    %142 = qco.rz(%cst_37) %141 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%142) targets (%arg0 = %139) {
      %147 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %147 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %143 = qco.rz(%cst_32) %targets_out_64 : !qco.qubit -> !qco.qubit
    %144 = qco.rz(%cst_35) %controls_out_63 : !qco.qubit -> !qco.qubit
    %145 = qco.rx(%cst_37) %144 : !qco.qubit -> !qco.qubit
    %146 = qco.rz(%cst_28) %145 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %29 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<8>
    %qubit_out_65, %result_66 = qco.measure %48 : !qco.qubit
    cbit.store %result_66, %8[%c1] : !cbit.reg<8>
    %qubit_out_67, %result_68 = qco.measure %69 : !qco.qubit
    cbit.store %result_68, %8[%c2] : !cbit.reg<8>
    %qubit_out_69, %result_70 = qco.measure %88 : !qco.qubit
    cbit.store %result_70, %8[%c3] : !cbit.reg<8>
    %qubit_out_71, %result_72 = qco.measure %109 : !qco.qubit
    cbit.store %result_72, %8[%c4] : !cbit.reg<8>
    %qubit_out_73, %result_74 = qco.measure %129 : !qco.qubit
    cbit.store %result_74, %8[%c5] : !cbit.reg<8>
    %qubit_out_75, %result_76 = qco.measure %146 : !qco.qubit
    cbit.store %result_76, %8[%c6] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_65 : !qco.qubit
    qco.sink %qubit_out_67 : !qco.qubit
    qco.sink %qubit_out_69 : !qco.qubit
    qco.sink %qubit_out_71 : !qco.qubit
    qco.sink %qubit_out_73 : !qco.qubit
    qco.sink %qubit_out_75 : !qco.qubit
    %qubit_out_77, %result_78 = qco.measure %143 : !qco.qubit
    qco.sink %qubit_out_77 : !qco.qubit
    cbit.store %result_78, %8[%c7] : !cbit.reg<8>
    %cst_79 = arith.constant -2.3561944901923351 : f64
    qco.gphase(%cst_79)
    return %8 : !cbit.reg<8>
  }
}
