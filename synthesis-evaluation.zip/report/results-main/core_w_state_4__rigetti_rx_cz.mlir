module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 6.2831853071795862 : f64
    %cst_0 = arith.constant -1.5707963267948961 : f64
    %cst_1 = arith.constant 0.78539816339744828 : f64
    %cst_2 = arith.constant -2.3561944901923448 : f64
    %cst_3 = arith.constant -3.0243399873051935 : f64
    %cst_4 = arith.constant 0.11725266628459963 : f64
    %cst_5 = arith.constant 5.2359877559829879 : f64
    %cst_6 = arith.constant -1.5707963267948957 : f64
    %cst_7 = arith.constant -1.9614033704925831 : f64
    %cst_8 = arith.constant 6.2831853071795845 : f64
    %cst_9 = arith.constant -0.39060704369768695 : f64
    %cst_10 = arith.constant 3.1415926535897931 : f64
    %cst_11 = arith.constant 5.3278686890550766 : f64
    %cst_12 = arith.constant 4.7123889803846906 : f64
    %cst_13 = arith.constant 4.0969092717143027 : f64
    %cst_14 = arith.constant 3.1415926535897927 : f64
    %cst_15 = arith.constant -6.2831853071795862 : f64
    %cst_16 = arith.constant 3.1415926535897936 : f64
    %cst_17 = arith.constant 5.4977871437821371 : f64
    %cst_18 = arith.constant 4.7123889803846897 : f64
    %cst_19 = arith.constant 3.1415926535897944 : f64
    %cst_20 = arith.constant 1.5707963267948979 : f64
    %cst_21 = arith.constant 5.4977871437821388 : f64
    %cst_22 = arith.constant 1.5707963267948966 : f64
    %cst_23 = arith.constant -3.1415926535897918 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.rx(%cst_10) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_16) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.rx(%cst_22) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_5) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_22) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_18) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_4) %5 : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_10) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_3) %12 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%13) targets (%arg0 = %10) {
      %67 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %67 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.rz(%cst_18) %targets_out : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_22) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_5) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_22) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_16) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_15) %controls_out : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_22) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_22) %20 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%21) targets (%arg0 = %18) {
      %67 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %67 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.rz(%cst_2) %targets_out_25 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_22) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_19) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_22) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_1) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_0) %controls_out_24 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_22) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_22) %2 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_13) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rx(%cst_22) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_12) %32 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%26) targets (%arg0 = %33) {
      %67 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %67 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.rz(%cst_18) %targets_out_27 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_22) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_11) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rx(%cst_22) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_10) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_15) %controls_out_26 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_22) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_22) %40 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%41) targets (%arg0 = %38) {
      %67 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %67 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qco.rz(%cst_9) %targets_out_29 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_22) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_8) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rx(%cst_22) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_7) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_6) %controls_out_28 : !qco.qubit -> !qco.qubit
    %48 = qco.rx(%cst_22) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_16) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_23) %3 : !qco.qubit -> !qco.qubit
    %51 = qco.rx(%cst_22) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_21) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rx(%cst_22) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_20) %53 : !qco.qubit -> !qco.qubit
    %controls_out_30, %targets_out_31 = qco.ctrl(%46) targets (%arg0 = %54) {
      %67 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %67 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.rz(%cst_18) %targets_out_31 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_22) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_17) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_22) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_16) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_15) %controls_out_30 : !qco.qubit -> !qco.qubit
    %61 = qco.rx(%cst_22) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_22) %61 : !qco.qubit -> !qco.qubit
    %controls_out_32, %targets_out_33 = qco.ctrl(%62) targets (%arg0 = %59) {
      %67 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %67 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %63 = qco.rz(%cst_18) %targets_out_33 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_20) %controls_out_32 : !qco.qubit -> !qco.qubit
    %65 = qco.rx(%cst_22) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_14) %65 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %29 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<4>
    %qubit_out_34, %result_35 = qco.measure %49 : !qco.qubit
    cbit.store %result_35, %4[%c1] : !cbit.reg<4>
    %qubit_out_36, %result_37 = qco.measure %66 : !qco.qubit
    cbit.store %result_37, %4[%c2] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_34 : !qco.qubit
    qco.sink %qubit_out_36 : !qco.qubit
    %qubit_out_38, %result_39 = qco.measure %63 : !qco.qubit
    qco.sink %qubit_out_38 : !qco.qubit
    cbit.store %result_39, %4[%c3] : !cbit.reg<4>
    %cst_40 = arith.constant 0.78539816339745094 : f64
    qco.gphase(%cst_40)
    return %4 : !cbit.reg<4>
  }
}
