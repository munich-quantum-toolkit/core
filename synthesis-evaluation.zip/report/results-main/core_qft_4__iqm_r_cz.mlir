module attributes {mqt.layout = {initial = array<i64: 3, 2, 0, 1>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 3.1415926535897913 : f64
    %cst_0 = arith.constant 2.9452431127404313 : f64
    %cst_1 = arith.constant -1.3744467859455352 : f64
    %cst_2 = arith.constant -1.5707963267948983 : f64
    %cst_3 = arith.constant 2.7488935718910694 : f64
    %cst_4 = arith.constant 3.1415926535897918 : f64
    %cst_5 = arith.constant 2.748893571891069 : f64
    %cst_6 = arith.constant -1.178097245096172 : f64
    %cst_7 = arith.constant 3.1415926535897927 : f64
    %cst_8 = arith.constant 2.3561944901923448 : f64
    %cst_9 = arith.constant -1.5707963267948966 : f64
    %cst_10 = arith.constant 1.570796326794897 : f64
    %cst_11 = arith.constant -0.78539816339744739 : f64
    %cst_12 = arith.constant 1.5707963267948968 : f64
    %cst_13 = arith.constant 3.1415926535897931 : f64
    %cst_14 = arith.constant 7.8539816339744828 : f64
    %cst_15 = arith.constant 1.5707963267948966 : f64
    %cst_16 = arith.constant 0.000000e+00 : f64
    %cst_17 = arith.constant 4.7123889803846897 : f64
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.r(%cst_15, %cst_15) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.r(%cst_13, %cst_16) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.r(%cst_17, %cst_16) %1 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_15, %cst_15) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_14, %cst_16) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_13, %cst_16) %6 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_12, %cst_15) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_17, %cst_16) %11 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%12) targets (%arg0 = %9) {
      %121 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %121 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %13 = qco.r(%cst_17, %cst_16) %targets_out : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_15, %cst_15) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_17, %cst_16) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_11, %cst_16) %controls_out : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_10, %cst_15) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_12, %cst_16) %17 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%18) targets (%arg0 = %15) {
      %121 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %121 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.r(%cst_9, %cst_16) %targets_out_19 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_8, %cst_15) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_17, %cst_16) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_7, %cst_16) %controls_out_18 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_8, %cst_15) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_9, %cst_16) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_17, %cst_16) %21 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_15, %cst_15) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst_12, %cst_16) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_13, %cst_16) %2 : !qco.qubit -> !qco.qubit
    %29 = qco.r(%cst_12, %cst_15) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_17, %cst_16) %29 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%30) targets (%arg0 = %27) {
      %121 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %121 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.r(%cst_17, %cst_16) %targets_out_21 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_15, %cst_15) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_17, %cst_16) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.r(%cst_6, %cst_16) %controls_out_20 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst_10, %cst_15) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_15, %cst_16) %35 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%36) targets (%arg0 = %33) {
      %121 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %121 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.r(%cst_9, %cst_16) %targets_out_23 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst_5, %cst_15) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst_17, %cst_16) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_4, %cst_16) %controls_out_22 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst_3, %cst_15) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst_2, %cst_16) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%cst_17, %cst_16) %39 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_15, %cst_15) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst_12, %cst_16) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.r(%cst_13, %cst_16) %3 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%cst_12, %cst_15) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst_17, %cst_16) %47 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%48) targets (%arg0 = %45) {
      %121 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %121 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qco.r(%cst_17, %cst_16) %targets_out_25 : !qco.qubit -> !qco.qubit
    %50 = qco.r(%cst_15, %cst_15) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.r(%cst_17, %cst_16) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.r(%cst_1, %cst_16) %controls_out_24 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst_10, %cst_15) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.r(%cst_15, %cst_16) %53 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%54) targets (%arg0 = %51) {
      %121 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %121 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.r(%cst_9, %cst_16) %targets_out_27 : !qco.qubit -> !qco.qubit
    %56 = qco.r(%cst_0, %cst_15) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.r(%cst_17, %cst_16) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.r(%cst, %cst_16) %controls_out_26 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%cst_0, %cst_15) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.r(%cst_2, %cst_16) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.r(%cst_15, %cst_15) %24 : !qco.qubit -> !qco.qubit
    %62 = qco.r(%cst_13, %cst_16) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%cst_17, %cst_16) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.r(%cst_15, %cst_15) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%cst_14, %cst_16) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.r(%cst_13, %cst_16) %42 : !qco.qubit -> !qco.qubit
    %67 = qco.r(%cst_12, %cst_15) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.r(%cst_17, %cst_16) %67 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%68) targets (%arg0 = %65) {
      %121 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %121 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %69 = qco.r(%cst_17, %cst_16) %targets_out_29 : !qco.qubit -> !qco.qubit
    %70 = qco.r(%cst_15, %cst_15) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.r(%cst_17, %cst_16) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%cst_11, %cst_16) %controls_out_28 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%cst_10, %cst_15) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.r(%cst_12, %cst_16) %73 : !qco.qubit -> !qco.qubit
    %controls_out_30, %targets_out_31 = qco.ctrl(%74) targets (%arg0 = %71) {
      %121 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %121 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %75 = qco.r(%cst_9, %cst_16) %targets_out_31 : !qco.qubit -> !qco.qubit
    %76 = qco.r(%cst_8, %cst_15) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.r(%cst_17, %cst_16) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst_7, %cst_16) %controls_out_30 : !qco.qubit -> !qco.qubit
    %79 = qco.r(%cst_8, %cst_15) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.r(%cst_9, %cst_16) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%cst_17, %cst_16) %77 : !qco.qubit -> !qco.qubit
    %82 = qco.r(%cst_15, %cst_15) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.r(%cst_12, %cst_16) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.r(%cst_13, %cst_16) %60 : !qco.qubit -> !qco.qubit
    %85 = qco.r(%cst_12, %cst_15) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.r(%cst_17, %cst_16) %85 : !qco.qubit -> !qco.qubit
    %controls_out_32, %targets_out_33 = qco.ctrl(%86) targets (%arg0 = %83) {
      %121 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %121 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %87 = qco.r(%cst_17, %cst_16) %targets_out_33 : !qco.qubit -> !qco.qubit
    %88 = qco.r(%cst_15, %cst_15) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%cst_17, %cst_16) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.r(%cst_6, %cst_16) %controls_out_32 : !qco.qubit -> !qco.qubit
    %91 = qco.r(%cst_10, %cst_15) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.r(%cst_15, %cst_16) %91 : !qco.qubit -> !qco.qubit
    %controls_out_34, %targets_out_35 = qco.ctrl(%92) targets (%arg0 = %89) {
      %121 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %121 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %93 = qco.r(%cst_9, %cst_16) %targets_out_35 : !qco.qubit -> !qco.qubit
    %94 = qco.r(%cst_5, %cst_15) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.r(%cst_17, %cst_16) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.r(%cst_4, %cst_16) %controls_out_34 : !qco.qubit -> !qco.qubit
    %97 = qco.r(%cst_3, %cst_15) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.r(%cst_2, %cst_16) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.r(%cst_15, %cst_15) %80 : !qco.qubit -> !qco.qubit
    %100 = qco.r(%cst_13, %cst_16) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.r(%cst_17, %cst_16) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.r(%cst_15, %cst_15) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.r(%cst_14, %cst_16) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.r(%cst_13, %cst_16) %98 : !qco.qubit -> !qco.qubit
    %105 = qco.r(%cst_12, %cst_15) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.r(%cst_17, %cst_16) %105 : !qco.qubit -> !qco.qubit
    %controls_out_36, %targets_out_37 = qco.ctrl(%106) targets (%arg0 = %103) {
      %121 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %121 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %107 = qco.r(%cst_17, %cst_16) %targets_out_37 : !qco.qubit -> !qco.qubit
    %108 = qco.r(%cst_15, %cst_15) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.r(%cst_17, %cst_16) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.r(%cst_11, %cst_16) %controls_out_36 : !qco.qubit -> !qco.qubit
    %111 = qco.r(%cst_10, %cst_15) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.r(%cst_12, %cst_16) %111 : !qco.qubit -> !qco.qubit
    %controls_out_38, %targets_out_39 = qco.ctrl(%112) targets (%arg0 = %109) {
      %121 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %121 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %113 = qco.r(%cst_9, %cst_16) %targets_out_39 : !qco.qubit -> !qco.qubit
    %114 = qco.r(%cst_8, %cst_15) %113 : !qco.qubit -> !qco.qubit
    %115 = qco.r(%cst_17, %cst_16) %114 : !qco.qubit -> !qco.qubit
    %116 = qco.r(%cst_7, %cst_16) %controls_out_38 : !qco.qubit -> !qco.qubit
    %117 = qco.r(%cst_8, %cst_15) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.r(%cst_9, %cst_16) %117 : !qco.qubit -> !qco.qubit
    %119 = qco.r(%cst_15, %cst_15) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.r(%cst_13, %cst_16) %119 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %120 : !qco.qubit
    cbit.store %result, %4[%c3] : !cbit.reg<4>
    %qubit_out_40, %result_41 = qco.measure %115 : !qco.qubit
    cbit.store %result_41, %4[%c2] : !cbit.reg<4>
    %qubit_out_42, %result_43 = qco.measure %95 : !qco.qubit
    cbit.store %result_43, %4[%c1] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_40 : !qco.qubit
    qco.sink %qubit_out_42 : !qco.qubit
    %qubit_out_44, %result_45 = qco.measure %57 : !qco.qubit
    qco.sink %qubit_out_44 : !qco.qubit
    cbit.store %result_45, %4[%c0] : !cbit.reg<4>
    %cst_46 = arith.constant 1.6689710972195932 : f64
    qco.gphase(%cst_46)
    return %4 : !cbit.reg<4>
  }
}
