module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 3.1415926535897931 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant 0.000000e+00 : f64
    %cst_2 = arith.constant 9.4247779607693793 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %5 = qco.r(%cst_2, %cst_1) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.r(%cst_0, %cst_0) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.r(%cst, %cst_1) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_0, %cst_0) %3 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst, %cst_1) %8 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%7) targets (%arg0 = %5) {
      %14 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %14 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_3, %targets_out_4 = qco.ctrl(%9) targets (%arg0 = %targets_out) {
      %14 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %14 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %10 = qco.r(%cst_0, %cst_0) %controls_out : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst, %cst_1) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_0, %cst_0) %controls_out_3 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst, %cst_1) %12 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %11 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<3>
    %qubit_out_5, %result_6 = qco.measure %2 : !qco.qubit
    cbit.store %result_6, %4[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_5 : !qco.qubit
    %qubit_out_7, %result_8 = qco.measure %13 : !qco.qubit
    qco.sink %qubit_out_7 : !qco.qubit
    cbit.store %result_8, %4[%c2] : !cbit.reg<3>
    qco.sink %targets_out_4 : !qco.qubit
    %cst_9 = arith.constant -1.5707963267948966 : f64
    qco.gphase(%cst_9)
    return %4 : !cbit.reg<3>
  }
}
