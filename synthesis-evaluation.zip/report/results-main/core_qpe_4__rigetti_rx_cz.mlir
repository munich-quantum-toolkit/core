module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 0>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 7.6576320931251214 : f64
    %cst_0 = arith.constant 2.7488935718910685 : f64
    %cst_1 = arith.constant 2.3561944901923448 : f64
    %cst_2 = arith.constant 9.0320788790706548 : f64
    %cst_3 = arith.constant -5.497787143782138 : f64
    %cst_4 = arith.constant -0.39269908169872458 : f64
    %cst_5 = arith.constant -0.98174770424681057 : f64
    %cst_6 = arith.constant 4.7123889803846897 : f64
    %cst_7 = arith.constant -0.5890486225480861 : f64
    %cst_8 = arith.constant 4.3196898986859651 : f64
    %cst_9 = arith.constant -1.5707963267948966 : f64
    %cst_10 = arith.constant 5.4268386164800555 : f64
    %cst_11 = arith.constant 3.0706441262877116 : f64
    %cst_12 = arith.constant 3.9269908169872423 : f64
    %cst_13 = arith.constant -0.78539816339744828 : f64
    %cst_14 = arith.constant -3.1415926535897927 : f64
    %cst_15 = arith.constant -1.1780972450961724 : f64
    %cst_16 = arith.constant 3.9269908169872405 : f64
    %cst_17 = arith.constant -0.39269908169872392 : f64
    %cst_18 = arith.constant -3.1415926535897931 : f64
    %cst_19 = arith.constant -2.9452431127404313 : f64
    %cst_20 = arith.constant 3.5342917352885177 : f64
    %cst_21 = arith.constant 3.9269908169872414 : f64
    %cst_22 = arith.constant 5.497787143782138 : f64
    %cst_23 = arith.constant 1.5707963267948961 : f64
    %cst_24 = arith.constant 1.5707963267948966 : f64
    %cst_25 = arith.constant 3.1415926535897931 : f64
    %cst_26 = arith.constant -4.7123889803846897 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %5 = qco.rz(%cst_24) %1 : !qco.qubit -> !qco.qubit
    %6 = qco.rx(%cst_24) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_24) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_24) %2 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_24) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_6) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_24) %3 : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_24) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_24) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_25) %0 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_24) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_24) %13 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_9) %16 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%17) targets (%arg0 = %15) {
      %102 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qco.rz(%cst_22) %targets_out : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_25) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_21) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_26) %controls_out : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst_24) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_8) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_24) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_25) %24 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%25) targets (%arg0 = %20) {
      %102 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.rz(%cst_7) %targets_out_28 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_25) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_5) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_24) %controls_out_27 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_4) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_24) %10 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_23) %31 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%32) targets (%arg0 = %28) {
      %102 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %33 = qco.rz(%cst_22) %targets_out_30 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_25) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_21) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_26) %controls_out_29 : !qco.qubit -> !qco.qubit
    %37 = qco.rx(%cst_24) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_12) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_24) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_25) %39 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%40) targets (%arg0 = %35) {
      %102 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.rz(%cst_11) %targets_out_32 : !qco.qubit -> !qco.qubit
    %42 = qco.rx(%cst_25) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_10) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_14) %controls_out_31 : !qco.qubit -> !qco.qubit
    %45 = qco.rx(%cst_24) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_3) %45 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%7) targets (%arg0 = %43) {
      %102 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.rz(%cst_24) %controls_out_33 : !qco.qubit -> !qco.qubit
    %48 = qco.rx(%cst_24) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_6) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_24) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_23) %50 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%51) targets (%arg0 = %46) {
      %102 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qco.rz(%cst_22) %targets_out_36 : !qco.qubit -> !qco.qubit
    %53 = qco.rx(%cst_25) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_21) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_26) %controls_out_35 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_24) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_16) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_24) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_25) %58 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%59) targets (%arg0 = %54) {
      %102 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qco.rz(%cst_15) %targets_out_38 : !qco.qubit -> !qco.qubit
    %61 = qco.rx(%cst_25) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_2) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_14) %controls_out_37 : !qco.qubit -> !qco.qubit
    %64 = qco.rx(%cst_24) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_1) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rx(%cst_24) %62 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_6) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rx(%cst_24) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_23) %68 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%69) targets (%arg0 = %30) {
      %102 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %70 = qco.rz(%cst_22) %targets_out_40 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_25) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_21) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_26) %controls_out_39 : !qco.qubit -> !qco.qubit
    %74 = qco.rx(%cst_24) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_16) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rx(%cst_24) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_25) %76 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%77) targets (%arg0 = %72) {
      %102 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %78 = qco.rz(%cst_15) %targets_out_42 : !qco.qubit -> !qco.qubit
    %79 = qco.rx(%cst_25) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_0) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_14) %controls_out_41 : !qco.qubit -> !qco.qubit
    %82 = qco.rx(%cst_24) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_13) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rx(%cst_24) %65 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_23) %84 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%85) targets (%arg0 = %80) {
      %102 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %86 = qco.rz(%cst_22) %targets_out_44 : !qco.qubit -> !qco.qubit
    %87 = qco.rx(%cst_25) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_21) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_26) %controls_out_43 : !qco.qubit -> !qco.qubit
    %90 = qco.rx(%cst_24) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_20) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rx(%cst_24) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_25) %92 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%93) targets (%arg0 = %88) {
      %102 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %94 = qco.rz(%cst_19) %targets_out_46 : !qco.qubit -> !qco.qubit
    %95 = qco.rx(%cst_25) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_18) %controls_out_45 : !qco.qubit -> !qco.qubit
    %98 = qco.rx(%cst_24) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_17) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rx(%cst_24) %96 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst_24) %100 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %99 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<3>
    %qubit_out_47, %result_48 = qco.measure %83 : !qco.qubit
    cbit.store %result_48, %4[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_47 : !qco.qubit
    %qubit_out_49, %result_50 = qco.measure %101 : !qco.qubit
    qco.sink %qubit_out_49 : !qco.qubit
    cbit.store %result_50, %4[%c2] : !cbit.reg<3>
    qco.sink %targets_out_34 : !qco.qubit
    %cst_51 = arith.constant 2.3561944901923528 : f64
    qco.gphase(%cst_51)
    return %4 : !cbit.reg<3>
  }
}
