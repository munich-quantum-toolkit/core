module attributes {mqt.layout = {initial = array<i64: 3, 1, 2, 0, 5, 7, 4, 6>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant 9.2284284199200179 : f64
    %cst_0 = arith.constant 1.178097245096172 : f64
    %cst_1 = arith.constant 2.7488935718910694 : f64
    %cst_2 = arith.constant 9.0320788790706548 : f64
    %cst_3 = arith.constant 2.3561944901923453 : f64
    %cst_4 = arith.constant 8.6393797973719302 : f64
    %cst_5 = arith.constant 4.7123889803846897 : f64
    %cst_6 = arith.constant 6.2831853071795862 : f64
    %cst_7 = arith.constant -3.9269908169872418 : f64
    %cst_8 = arith.constant -4.319689898685966 : f64
    %cst_9 = arith.constant -4.5160394395353283 : f64
    %cst_10 = arith.constant 0.78539816339744806 : f64
    %cst_11 = arith.constant 0.39269908169872392 : f64
    %cst_12 = arith.constant 0.19634954084936185 : f64
    %cst_13 = arith.constant 5.497787143782138 : f64
    %cst_14 = arith.constant 3.337942194439155 : f64
    %cst_15 = arith.constant 3.5342917352885168 : f64
    %cst_16 = arith.constant 1.9634954084936203 : f64
    %cst_17 = arith.constant 3.9269908169872414 : f64
    %cst_18 = arith.constant 2.3561944901923444 : f64
    %cst_19 = arith.constant 3.9269908169872432 : f64
    %cst_20 = arith.constant 1.5707963267948968 : f64
    %cst_21 = arith.constant -1.5707963267948963 : f64
    %cst_22 = arith.constant -0.78539816339744783 : f64
    %cst_23 = arith.constant -3.1415926535897922 : f64
    %cst_24 = arith.constant -1.5707963267948966 : f64
    %cst_25 = arith.constant 3.926990816987241 : f64
    %cst_26 = arith.constant -0.39269908169872392 : f64
    %cst_27 = arith.constant -3.1415926535897931 : f64
    %cst_28 = arith.constant 3.5342917352885181 : f64
    %cst_29 = arith.constant -0.19634954084936185 : f64
    %cst_30 = arith.constant -3.1415926535897927 : f64
    %cst_31 = arith.constant -1.5707963267948961 : f64
    %cst_32 = arith.constant 3.1415926535897927 : f64
    %cst_33 = arith.constant 3.3379421944391554 : f64
    %cst_34 = arith.constant -4.7123889803846897 : f64
    %cst_35 = arith.constant 1.5707963267948961 : f64
    %cst_36 = arith.constant 3.1415926535897931 : f64
    %cst_37 = arith.constant 1.5707963267948966 : f64
    %cst_38 = arith.constant -6.2831853071795862 : f64
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %cst_39 = arith.constant 0.78539816339744828 : f64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.x %0 : !qco.qubit -> !qco.qubit
    %9 = qco.x %1 : !qco.qubit -> !qco.qubit
    %10 = qco.x %4 : !qco.qubit -> !qco.qubit
    %11 = qco.x %5 : !qco.qubit -> !qco.qubit
    %12 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %13 = qco.rz(%cst_37) %6 : !qco.qubit -> !qco.qubit
    %14 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_34) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_37) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %10 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_24) %18 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%19) targets (%arg0 = %17) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.rz(%cst_38) %targets_out : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_36) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_34) %controls_out : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_19) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.sx %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_36) %26 : !qco.qubit -> !qco.qubit
    %controls_out_40, %targets_out_41 = qco.ctrl(%27) targets (%arg0 = %22) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qco.rz(%cst_24) %targets_out_41 : !qco.qubit -> !qco.qubit
    %29 = qco.sx %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_18) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %controls_out_40 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_13) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_37) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.sx %7 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_24) %35 : !qco.qubit -> !qco.qubit
    %controls_out_42, %targets_out_43 = qco.ctrl(%36) targets (%arg0 = %34) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.rz(%cst_38) %targets_out_43 : !qco.qubit -> !qco.qubit
    %38 = qco.sx %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_36) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_34) %controls_out_42 : !qco.qubit -> !qco.qubit
    %41 = qco.sx %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_28) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_36) %43 : !qco.qubit -> !qco.qubit
    %controls_out_44, %targets_out_45 = qco.ctrl(%44) targets (%arg0 = %39) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.rz(%cst_21) %targets_out_45 : !qco.qubit -> !qco.qubit
    %46 = qco.sx %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_16) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %controls_out_44 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_15) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_37) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_24) %52 : !qco.qubit -> !qco.qubit
    %controls_out_46, %targets_out_47 = qco.ctrl(%53) targets (%arg0 = %51) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %54 = qco.rz(%cst_38) %targets_out_47 : !qco.qubit -> !qco.qubit
    %55 = qco.sx %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_36) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_34) %controls_out_46 : !qco.qubit -> !qco.qubit
    %58 = qco.sx %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_33) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.sx %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_32) %60 : !qco.qubit -> !qco.qubit
    %controls_out_48, %targets_out_49 = qco.ctrl(%61) targets (%arg0 = %56) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %62 = qco.rz(%cst_21) %targets_out_49 : !qco.qubit -> !qco.qubit
    %63 = qco.sx %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_12) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.sx %controls_out_48 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_14) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.sx %32 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_34) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.sx %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_37) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.sx %49 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_24) %71 : !qco.qubit -> !qco.qubit
    %controls_out_50, %targets_out_51 = qco.ctrl(%72) targets (%arg0 = %70) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %73 = qco.rz(%cst_38) %targets_out_51 : !qco.qubit -> !qco.qubit
    %74 = qco.sx %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_36) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_34) %controls_out_50 : !qco.qubit -> !qco.qubit
    %77 = qco.sx %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_19) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.sx %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_36) %79 : !qco.qubit -> !qco.qubit
    %controls_out_52, %targets_out_53 = qco.ctrl(%80) targets (%arg0 = %75) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %81 = qco.rz(%cst_24) %targets_out_53 : !qco.qubit -> !qco.qubit
    %82 = qco.sx %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_18) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.sx %controls_out_52 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_13) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.sx %83 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_37) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.sx %66 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_24) %88 : !qco.qubit -> !qco.qubit
    %controls_out_54, %targets_out_55 = qco.ctrl(%89) targets (%arg0 = %87) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %90 = qco.rz(%cst_38) %targets_out_55 : !qco.qubit -> !qco.qubit
    %91 = qco.sx %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_36) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_34) %controls_out_54 : !qco.qubit -> !qco.qubit
    %94 = qco.sx %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_28) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.sx %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_36) %96 : !qco.qubit -> !qco.qubit
    %controls_out_56, %targets_out_57 = qco.ctrl(%97) targets (%arg0 = %92) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %98 = qco.rz(%cst_21) %targets_out_57 : !qco.qubit -> !qco.qubit
    %99 = qco.sx %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_11) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.sx %controls_out_56 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_15) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.sx %85 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_34) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.sx %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_37) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.sx %102 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_24) %107 : !qco.qubit -> !qco.qubit
    %controls_out_58, %targets_out_59 = qco.ctrl(%108) targets (%arg0 = %106) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %109 = qco.rz(%cst_38) %targets_out_59 : !qco.qubit -> !qco.qubit
    %110 = qco.sx %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_36) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rz(%cst_34) %controls_out_58 : !qco.qubit -> !qco.qubit
    %113 = qco.sx %112 : !qco.qubit -> !qco.qubit
    %114 = qco.rz(%cst_19) %113 : !qco.qubit -> !qco.qubit
    %115 = qco.sx %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst_36) %115 : !qco.qubit -> !qco.qubit
    %controls_out_60, %targets_out_61 = qco.ctrl(%116) targets (%arg0 = %111) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %117 = qco.rz(%cst_24) %targets_out_61 : !qco.qubit -> !qco.qubit
    %118 = qco.sx %117 : !qco.qubit -> !qco.qubit
    %119 = qco.rz(%cst_10) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.sx %controls_out_60 : !qco.qubit -> !qco.qubit
    %121 = qco.rz(%cst_13) %120 : !qco.qubit -> !qco.qubit
    %122 = qco.sx %121 : !qco.qubit -> !qco.qubit
    %123 = qco.sx %64 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_20) %123 : !qco.qubit -> !qco.qubit
    %controls_out_62, %targets_out_63 = qco.ctrl(%8) targets (%arg0 = %124) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %125 = qco.rz(%cst_34) %targets_out_63 : !qco.qubit -> !qco.qubit
    %126 = qco.sx %125 : !qco.qubit -> !qco.qubit
    %127 = qco.rz(%cst_24) %126 : !qco.qubit -> !qco.qubit
    %128 = qco.sx %127 : !qco.qubit -> !qco.qubit
    %129 = qco.rz(%cst_37) %128 : !qco.qubit -> !qco.qubit
    %130 = qco.sx %2 : !qco.qubit -> !qco.qubit
    %131 = qco.rz(%cst_24) %130 : !qco.qubit -> !qco.qubit
    %controls_out_64, %targets_out_65 = qco.ctrl(%131) targets (%arg0 = %129) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %132 = qco.rz(%cst_38) %targets_out_65 : !qco.qubit -> !qco.qubit
    %133 = qco.sx %132 : !qco.qubit -> !qco.qubit
    %134 = qco.rz(%cst_36) %133 : !qco.qubit -> !qco.qubit
    %135 = qco.rz(%cst_34) %controls_out_64 : !qco.qubit -> !qco.qubit
    %136 = qco.sx %135 : !qco.qubit -> !qco.qubit
    %137 = qco.rz(%cst_19) %136 : !qco.qubit -> !qco.qubit
    %138 = qco.sx %137 : !qco.qubit -> !qco.qubit
    %139 = qco.rz(%cst_36) %138 : !qco.qubit -> !qco.qubit
    %controls_out_66, %targets_out_67 = qco.ctrl(%139) targets (%arg0 = %134) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %140 = qco.rz(%cst_24) %targets_out_67 : !qco.qubit -> !qco.qubit
    %141 = qco.sx %140 : !qco.qubit -> !qco.qubit
    %142 = qco.rz(%cst_18) %141 : !qco.qubit -> !qco.qubit
    %143 = qco.sx %controls_out_66 : !qco.qubit -> !qco.qubit
    %144 = qco.rz(%cst_17) %143 : !qco.qubit -> !qco.qubit
    %145 = qco.sx %142 : !qco.qubit -> !qco.qubit
    %146 = qco.rz(%cst_37) %145 : !qco.qubit -> !qco.qubit
    %147 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %148 = qco.rz(%cst_24) %147 : !qco.qubit -> !qco.qubit
    %controls_out_68, %targets_out_69 = qco.ctrl(%148) targets (%arg0 = %146) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %149 = qco.rz(%cst_38) %targets_out_69 : !qco.qubit -> !qco.qubit
    %150 = qco.sx %149 : !qco.qubit -> !qco.qubit
    %151 = qco.rz(%cst_36) %150 : !qco.qubit -> !qco.qubit
    %152 = qco.rz(%cst_34) %controls_out_68 : !qco.qubit -> !qco.qubit
    %153 = qco.sx %152 : !qco.qubit -> !qco.qubit
    %154 = qco.rz(%cst_28) %153 : !qco.qubit -> !qco.qubit
    %155 = qco.sx %154 : !qco.qubit -> !qco.qubit
    %156 = qco.rz(%cst_36) %155 : !qco.qubit -> !qco.qubit
    %controls_out_70, %targets_out_71 = qco.ctrl(%156) targets (%arg0 = %151) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %157 = qco.rz(%cst_21) %targets_out_71 : !qco.qubit -> !qco.qubit
    %158 = qco.sx %157 : !qco.qubit -> !qco.qubit
    %159 = qco.rz(%cst_16) %158 : !qco.qubit -> !qco.qubit
    %160 = qco.sx %controls_out_70 : !qco.qubit -> !qco.qubit
    %161 = qco.rz(%cst_15) %160 : !qco.qubit -> !qco.qubit
    %162 = qco.sx %159 : !qco.qubit -> !qco.qubit
    %163 = qco.rz(%cst_37) %162 : !qco.qubit -> !qco.qubit
    %164 = qco.sx %3 : !qco.qubit -> !qco.qubit
    %165 = qco.rz(%cst_24) %164 : !qco.qubit -> !qco.qubit
    %controls_out_72, %targets_out_73 = qco.ctrl(%165) targets (%arg0 = %163) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %166 = qco.rz(%cst_38) %targets_out_73 : !qco.qubit -> !qco.qubit
    %167 = qco.sx %166 : !qco.qubit -> !qco.qubit
    %168 = qco.rz(%cst_36) %167 : !qco.qubit -> !qco.qubit
    %169 = qco.rz(%cst_34) %controls_out_72 : !qco.qubit -> !qco.qubit
    %170 = qco.sx %169 : !qco.qubit -> !qco.qubit
    %171 = qco.rz(%cst_33) %170 : !qco.qubit -> !qco.qubit
    %172 = qco.sx %171 : !qco.qubit -> !qco.qubit
    %173 = qco.rz(%cst_32) %172 : !qco.qubit -> !qco.qubit
    %controls_out_74, %targets_out_75 = qco.ctrl(%173) targets (%arg0 = %168) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %174 = qco.rz(%cst_21) %targets_out_75 : !qco.qubit -> !qco.qubit
    %175 = qco.sx %174 : !qco.qubit -> !qco.qubit
    %176 = qco.rz(%cst_9) %175 : !qco.qubit -> !qco.qubit
    %177 = qco.sx %controls_out_74 : !qco.qubit -> !qco.qubit
    %178 = qco.rz(%cst_14) %177 : !qco.qubit -> !qco.qubit
    %179 = qco.sx %100 : !qco.qubit -> !qco.qubit
    %180 = qco.rz(%cst_20) %179 : !qco.qubit -> !qco.qubit
    %controls_out_76, %targets_out_77 = qco.ctrl(%144) targets (%arg0 = %180) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %181 = qco.rz(%cst_34) %targets_out_77 : !qco.qubit -> !qco.qubit
    %182 = qco.sx %181 : !qco.qubit -> !qco.qubit
    %183 = qco.rz(%cst_24) %182 : !qco.qubit -> !qco.qubit
    %184 = qco.sx %183 : !qco.qubit -> !qco.qubit
    %185 = qco.rz(%cst_37) %184 : !qco.qubit -> !qco.qubit
    %186 = qco.sx %161 : !qco.qubit -> !qco.qubit
    %187 = qco.rz(%cst_24) %186 : !qco.qubit -> !qco.qubit
    %controls_out_78, %targets_out_79 = qco.ctrl(%187) targets (%arg0 = %185) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %188 = qco.rz(%cst_38) %targets_out_79 : !qco.qubit -> !qco.qubit
    %189 = qco.sx %188 : !qco.qubit -> !qco.qubit
    %190 = qco.rz(%cst_36) %189 : !qco.qubit -> !qco.qubit
    %191 = qco.rz(%cst_34) %controls_out_78 : !qco.qubit -> !qco.qubit
    %192 = qco.sx %191 : !qco.qubit -> !qco.qubit
    %193 = qco.rz(%cst_19) %192 : !qco.qubit -> !qco.qubit
    %194 = qco.sx %193 : !qco.qubit -> !qco.qubit
    %195 = qco.rz(%cst_36) %194 : !qco.qubit -> !qco.qubit
    %controls_out_80, %targets_out_81 = qco.ctrl(%195) targets (%arg0 = %190) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %196 = qco.rz(%cst_24) %targets_out_81 : !qco.qubit -> !qco.qubit
    %197 = qco.sx %196 : !qco.qubit -> !qco.qubit
    %198 = qco.rz(%cst_18) %197 : !qco.qubit -> !qco.qubit
    %199 = qco.sx %controls_out_80 : !qco.qubit -> !qco.qubit
    %200 = qco.rz(%cst_17) %199 : !qco.qubit -> !qco.qubit
    %201 = qco.sx %198 : !qco.qubit -> !qco.qubit
    %202 = qco.rz(%cst_37) %201 : !qco.qubit -> !qco.qubit
    %203 = qco.sx %178 : !qco.qubit -> !qco.qubit
    %204 = qco.rz(%cst_24) %203 : !qco.qubit -> !qco.qubit
    %controls_out_82, %targets_out_83 = qco.ctrl(%204) targets (%arg0 = %202) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %205 = qco.rz(%cst_38) %targets_out_83 : !qco.qubit -> !qco.qubit
    %206 = qco.sx %205 : !qco.qubit -> !qco.qubit
    %207 = qco.rz(%cst_36) %206 : !qco.qubit -> !qco.qubit
    %208 = qco.rz(%cst_34) %controls_out_82 : !qco.qubit -> !qco.qubit
    %209 = qco.sx %208 : !qco.qubit -> !qco.qubit
    %210 = qco.rz(%cst_28) %209 : !qco.qubit -> !qco.qubit
    %211 = qco.sx %210 : !qco.qubit -> !qco.qubit
    %212 = qco.rz(%cst_36) %211 : !qco.qubit -> !qco.qubit
    %controls_out_84, %targets_out_85 = qco.ctrl(%212) targets (%arg0 = %207) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %213 = qco.rz(%cst_21) %targets_out_85 : !qco.qubit -> !qco.qubit
    %214 = qco.sx %213 : !qco.qubit -> !qco.qubit
    %215 = qco.rz(%cst_8) %214 : !qco.qubit -> !qco.qubit
    %216 = qco.sx %controls_out_84 : !qco.qubit -> !qco.qubit
    %217 = qco.rz(%cst_15) %216 : !qco.qubit -> !qco.qubit
    %218 = qco.sx %119 : !qco.qubit -> !qco.qubit
    %219 = qco.rz(%cst_20) %218 : !qco.qubit -> !qco.qubit
    %controls_out_86, %targets_out_87 = qco.ctrl(%200) targets (%arg0 = %219) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %220 = qco.rz(%cst_34) %targets_out_87 : !qco.qubit -> !qco.qubit
    %221 = qco.sx %220 : !qco.qubit -> !qco.qubit
    %222 = qco.rz(%cst_24) %221 : !qco.qubit -> !qco.qubit
    %223 = qco.sx %222 : !qco.qubit -> !qco.qubit
    %224 = qco.rz(%cst_37) %223 : !qco.qubit -> !qco.qubit
    %225 = qco.sx %217 : !qco.qubit -> !qco.qubit
    %226 = qco.rz(%cst_24) %225 : !qco.qubit -> !qco.qubit
    %controls_out_88, %targets_out_89 = qco.ctrl(%226) targets (%arg0 = %224) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %227 = qco.rz(%cst_38) %targets_out_89 : !qco.qubit -> !qco.qubit
    %228 = qco.sx %227 : !qco.qubit -> !qco.qubit
    %229 = qco.rz(%cst_36) %228 : !qco.qubit -> !qco.qubit
    %230 = qco.rz(%cst_34) %controls_out_88 : !qco.qubit -> !qco.qubit
    %231 = qco.sx %230 : !qco.qubit -> !qco.qubit
    %232 = qco.rz(%cst_19) %231 : !qco.qubit -> !qco.qubit
    %233 = qco.sx %232 : !qco.qubit -> !qco.qubit
    %234 = qco.rz(%cst_36) %233 : !qco.qubit -> !qco.qubit
    %controls_out_90, %targets_out_91 = qco.ctrl(%234) targets (%arg0 = %229) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %235 = qco.rz(%cst_24) %targets_out_91 : !qco.qubit -> !qco.qubit
    %236 = qco.sx %235 : !qco.qubit -> !qco.qubit
    %237 = qco.rz(%cst_7) %236 : !qco.qubit -> !qco.qubit
    %238 = qco.sx %controls_out_90 : !qco.qubit -> !qco.qubit
    %239 = qco.rz(%cst_17) %238 : !qco.qubit -> !qco.qubit
    %240 = qco.sx %122 : !qco.qubit -> !qco.qubit
    %241 = qco.rz(%cst_20) %240 : !qco.qubit -> !qco.qubit
    %controls_out_92, %targets_out_93 = qco.ctrl(%239) targets (%arg0 = %241) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %242 = qco.rz(%cst_34) %targets_out_93 : !qco.qubit -> !qco.qubit
    %243 = qco.sx %242 : !qco.qubit -> !qco.qubit
    %244 = qco.rz(%cst_6) %243 : !qco.qubit -> !qco.qubit
    %245 = qco.sx %244 : !qco.qubit -> !qco.qubit
    %246 = qco.rz(%cst_5) %245 : !qco.qubit -> !qco.qubit
    %247 = qco.sx %237 : !qco.qubit -> !qco.qubit
    %248 = qco.rz(%cst_37) %247 : !qco.qubit -> !qco.qubit
    %249 = qco.sx %246 : !qco.qubit -> !qco.qubit
    %250 = qco.rz(%cst_35) %249 : !qco.qubit -> !qco.qubit
    %controls_out_94, %targets_out_95 = qco.ctrl(%250) targets (%arg0 = %248) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %251 = qco.rz(%cst_38) %targets_out_95 : !qco.qubit -> !qco.qubit
    %252 = qco.sx %251 : !qco.qubit -> !qco.qubit
    %253 = qco.rz(%cst_36) %252 : !qco.qubit -> !qco.qubit
    %254 = qco.rz(%cst_34) %controls_out_94 : !qco.qubit -> !qco.qubit
    %255 = qco.sx %254 : !qco.qubit -> !qco.qubit
    %256 = qco.rz(%cst_25) %255 : !qco.qubit -> !qco.qubit
    %257 = qco.sx %256 : !qco.qubit -> !qco.qubit
    %258 = qco.rz(%cst_36) %257 : !qco.qubit -> !qco.qubit
    %controls_out_96, %targets_out_97 = qco.ctrl(%258) targets (%arg0 = %253) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %259 = qco.rz(%cst_24) %targets_out_97 : !qco.qubit -> !qco.qubit
    %260 = qco.sx %259 : !qco.qubit -> !qco.qubit
    %261 = qco.rz(%cst_4) %260 : !qco.qubit -> !qco.qubit
    %262 = qco.rz(%cst_23) %controls_out_96 : !qco.qubit -> !qco.qubit
    %263 = qco.sx %262 : !qco.qubit -> !qco.qubit
    %264 = qco.rz(%cst_3) %263 : !qco.qubit -> !qco.qubit
    %265 = qco.sx %261 : !qco.qubit -> !qco.qubit
    %266 = qco.rz(%cst_5) %265 : !qco.qubit -> !qco.qubit
    %267 = qco.sx %215 : !qco.qubit -> !qco.qubit
    %268 = qco.rz(%cst_37) %267 : !qco.qubit -> !qco.qubit
    %269 = qco.sx %266 : !qco.qubit -> !qco.qubit
    %270 = qco.rz(%cst_35) %269 : !qco.qubit -> !qco.qubit
    %controls_out_98, %targets_out_99 = qco.ctrl(%270) targets (%arg0 = %268) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %271 = qco.rz(%cst_38) %targets_out_99 : !qco.qubit -> !qco.qubit
    %272 = qco.sx %271 : !qco.qubit -> !qco.qubit
    %273 = qco.rz(%cst_36) %272 : !qco.qubit -> !qco.qubit
    %274 = qco.rz(%cst_34) %controls_out_98 : !qco.qubit -> !qco.qubit
    %275 = qco.sx %274 : !qco.qubit -> !qco.qubit
    %276 = qco.rz(%cst_25) %275 : !qco.qubit -> !qco.qubit
    %277 = qco.sx %276 : !qco.qubit -> !qco.qubit
    %278 = qco.rz(%cst_36) %277 : !qco.qubit -> !qco.qubit
    %controls_out_100, %targets_out_101 = qco.ctrl(%278) targets (%arg0 = %273) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %279 = qco.rz(%cst_24) %targets_out_101 : !qco.qubit -> !qco.qubit
    %280 = qco.sx %279 : !qco.qubit -> !qco.qubit
    %281 = qco.rz(%cst_39) %280 : !qco.qubit -> !qco.qubit
    %282 = qco.rz(%cst_23) %controls_out_100 : !qco.qubit -> !qco.qubit
    %283 = qco.sx %282 : !qco.qubit -> !qco.qubit
    %284 = qco.rz(%cst_3) %283 : !qco.qubit -> !qco.qubit
    %285 = qco.sx %281 : !qco.qubit -> !qco.qubit
    %286 = qco.rz(%cst_37) %285 : !qco.qubit -> !qco.qubit
    %287 = qco.sx %264 : !qco.qubit -> !qco.qubit
    %288 = qco.rz(%cst_35) %287 : !qco.qubit -> !qco.qubit
    %controls_out_102, %targets_out_103 = qco.ctrl(%288) targets (%arg0 = %286) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %289 = qco.rz(%cst_38) %targets_out_103 : !qco.qubit -> !qco.qubit
    %290 = qco.sx %289 : !qco.qubit -> !qco.qubit
    %291 = qco.rz(%cst_36) %290 : !qco.qubit -> !qco.qubit
    %292 = qco.rz(%cst_34) %controls_out_102 : !qco.qubit -> !qco.qubit
    %293 = qco.sx %292 : !qco.qubit -> !qco.qubit
    %294 = qco.rz(%cst_28) %293 : !qco.qubit -> !qco.qubit
    %295 = qco.sx %294 : !qco.qubit -> !qco.qubit
    %296 = qco.rz(%cst_36) %295 : !qco.qubit -> !qco.qubit
    %controls_out_104, %targets_out_105 = qco.ctrl(%296) targets (%arg0 = %291) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %297 = qco.rz(%cst_31) %targets_out_105 : !qco.qubit -> !qco.qubit
    %298 = qco.sx %297 : !qco.qubit -> !qco.qubit
    %299 = qco.rz(%cst_2) %298 : !qco.qubit -> !qco.qubit
    %300 = qco.rz(%cst_27) %controls_out_104 : !qco.qubit -> !qco.qubit
    %301 = qco.sx %300 : !qco.qubit -> !qco.qubit
    %302 = qco.rz(%cst_1) %301 : !qco.qubit -> !qco.qubit
    %303 = qco.sx %299 : !qco.qubit -> !qco.qubit
    %304 = qco.rz(%cst_5) %303 : !qco.qubit -> !qco.qubit
    %305 = qco.sx %176 : !qco.qubit -> !qco.qubit
    %306 = qco.rz(%cst_37) %305 : !qco.qubit -> !qco.qubit
    %307 = qco.sx %304 : !qco.qubit -> !qco.qubit
    %308 = qco.rz(%cst_35) %307 : !qco.qubit -> !qco.qubit
    %controls_out_106, %targets_out_107 = qco.ctrl(%308) targets (%arg0 = %306) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %309 = qco.rz(%cst_38) %targets_out_107 : !qco.qubit -> !qco.qubit
    %310 = qco.sx %309 : !qco.qubit -> !qco.qubit
    %311 = qco.rz(%cst_36) %310 : !qco.qubit -> !qco.qubit
    %312 = qco.rz(%cst_34) %controls_out_106 : !qco.qubit -> !qco.qubit
    %313 = qco.sx %312 : !qco.qubit -> !qco.qubit
    %314 = qco.rz(%cst_25) %313 : !qco.qubit -> !qco.qubit
    %315 = qco.sx %314 : !qco.qubit -> !qco.qubit
    %316 = qco.rz(%cst_36) %315 : !qco.qubit -> !qco.qubit
    %controls_out_108, %targets_out_109 = qco.ctrl(%316) targets (%arg0 = %311) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %317 = qco.rz(%cst_24) %targets_out_109 : !qco.qubit -> !qco.qubit
    %318 = qco.sx %317 : !qco.qubit -> !qco.qubit
    %319 = qco.rz(%cst_39) %318 : !qco.qubit -> !qco.qubit
    %320 = qco.rz(%cst_23) %controls_out_108 : !qco.qubit -> !qco.qubit
    %321 = qco.sx %320 : !qco.qubit -> !qco.qubit
    %322 = qco.rz(%cst_22) %321 : !qco.qubit -> !qco.qubit
    %323 = qco.sx %319 : !qco.qubit -> !qco.qubit
    %324 = qco.rz(%cst_37) %323 : !qco.qubit -> !qco.qubit
    %325 = qco.sx %284 : !qco.qubit -> !qco.qubit
    %326 = qco.rz(%cst_35) %325 : !qco.qubit -> !qco.qubit
    %controls_out_110, %targets_out_111 = qco.ctrl(%326) targets (%arg0 = %324) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %327 = qco.rz(%cst_38) %targets_out_111 : !qco.qubit -> !qco.qubit
    %328 = qco.sx %327 : !qco.qubit -> !qco.qubit
    %329 = qco.rz(%cst_36) %328 : !qco.qubit -> !qco.qubit
    %330 = qco.rz(%cst_34) %controls_out_110 : !qco.qubit -> !qco.qubit
    %331 = qco.sx %330 : !qco.qubit -> !qco.qubit
    %332 = qco.rz(%cst_28) %331 : !qco.qubit -> !qco.qubit
    %333 = qco.sx %332 : !qco.qubit -> !qco.qubit
    %334 = qco.rz(%cst_36) %333 : !qco.qubit -> !qco.qubit
    %controls_out_112, %targets_out_113 = qco.ctrl(%334) targets (%arg0 = %329) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %335 = qco.rz(%cst_31) %targets_out_113 : !qco.qubit -> !qco.qubit
    %336 = qco.sx %335 : !qco.qubit -> !qco.qubit
    %337 = qco.rz(%cst_0) %336 : !qco.qubit -> !qco.qubit
    %338 = qco.rz(%cst_27) %controls_out_112 : !qco.qubit -> !qco.qubit
    %339 = qco.sx %338 : !qco.qubit -> !qco.qubit
    %340 = qco.rz(%cst_26) %339 : !qco.qubit -> !qco.qubit
    %341 = qco.sx %337 : !qco.qubit -> !qco.qubit
    %342 = qco.rz(%cst_37) %341 : !qco.qubit -> !qco.qubit
    %343 = qco.sx %302 : !qco.qubit -> !qco.qubit
    %344 = qco.rz(%cst_35) %343 : !qco.qubit -> !qco.qubit
    %controls_out_114, %targets_out_115 = qco.ctrl(%344) targets (%arg0 = %342) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %345 = qco.rz(%cst_38) %targets_out_115 : !qco.qubit -> !qco.qubit
    %346 = qco.sx %345 : !qco.qubit -> !qco.qubit
    %347 = qco.rz(%cst_36) %346 : !qco.qubit -> !qco.qubit
    %348 = qco.rz(%cst_34) %controls_out_114 : !qco.qubit -> !qco.qubit
    %349 = qco.sx %348 : !qco.qubit -> !qco.qubit
    %350 = qco.rz(%cst_33) %349 : !qco.qubit -> !qco.qubit
    %351 = qco.sx %350 : !qco.qubit -> !qco.qubit
    %352 = qco.rz(%cst_32) %351 : !qco.qubit -> !qco.qubit
    %controls_out_116, %targets_out_117 = qco.ctrl(%352) targets (%arg0 = %347) {
      %361 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %361 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %353 = qco.rz(%cst_31) %targets_out_117 : !qco.qubit -> !qco.qubit
    %354 = qco.sx %353 : !qco.qubit -> !qco.qubit
    %355 = qco.rz(%cst) %354 : !qco.qubit -> !qco.qubit
    %356 = qco.rz(%cst_30) %controls_out_116 : !qco.qubit -> !qco.qubit
    %357 = qco.sx %356 : !qco.qubit -> !qco.qubit
    %358 = qco.rz(%cst_29) %357 : !qco.qubit -> !qco.qubit
    %359 = qco.sx %355 : !qco.qubit -> !qco.qubit
    %360 = qco.rz(%cst_37) %359 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %358 : !qco.qubit
    cbit.store %result, %12[%c0] : !cbit.reg<8>
    %qubit_out_118, %result_119 = qco.measure %340 : !qco.qubit
    cbit.store %result_119, %12[%c1] : !cbit.reg<8>
    %qubit_out_120, %result_121 = qco.measure %322 : !qco.qubit
    cbit.store %result_121, %12[%c2] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_118 : !qco.qubit
    qco.sink %qubit_out_120 : !qco.qubit
    %qubit_out_122, %result_123 = qco.measure %360 : !qco.qubit
    qco.sink %qubit_out_122 : !qco.qubit
    cbit.store %result_123, %12[%c3] : !cbit.reg<8>
    %qubit_out_124, %result_125 = qco.measure %controls_out_92 : !qco.qubit
    cbit.store %result_125, %12[%c4] : !cbit.reg<8>
    %qubit_out_126, %result_127 = qco.measure %controls_out_86 : !qco.qubit
    cbit.store %result_127, %12[%c5] : !cbit.reg<8>
    %qubit_out_128, %result_129 = qco.measure %controls_out_76 : !qco.qubit
    cbit.store %result_129, %12[%c6] : !cbit.reg<8>
    qco.sink %qubit_out_124 : !qco.qubit
    qco.sink %qubit_out_126 : !qco.qubit
    qco.sink %qubit_out_128 : !qco.qubit
    %qubit_out_130, %result_131 = qco.measure %controls_out_62 : !qco.qubit
    qco.sink %qubit_out_130 : !qco.qubit
    cbit.store %result_131, %12[%c7] : !cbit.reg<8>
    %cst_132 = arith.constant 0.098174770424712676 : f64
    qco.gphase(%cst_132)
    return %12 : !cbit.reg<8>
  }
}
