module attributes {mqt.layout = {initial = array<i64: 3, 2, 0, 1>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 4.1233403578366037 : f64
    %cst_0 = arith.constant 4.3196898986859651 : f64
    %cst_1 = arith.constant 5.497787143782138 : f64
    %cst_2 = arith.constant 0.19634954084936185 : f64
    %cst_3 = arith.constant 6.0868357663302248 : f64
    %cst_4 = arith.constant 0.39269908169872392 : f64
    %cst_5 = arith.constant 5.8904862254808616 : f64
    %cst_6 = arith.constant -1.570796326794897 : f64
    %cst_7 = arith.constant 0.78539816339744839 : f64
    %cst_8 = arith.constant -4.7123889803846897 : f64
    %cst_9 = arith.constant 5.4977871437821371 : f64
    %cst_10 = arith.constant -1.5707963267948966 : f64
    %cst_11 = arith.constant 2.3561944901923448 : f64
    %cst_12 = arith.constant -0.78539816339744828 : f64
    %cst_13 = arith.constant 3.1415926535897931 : f64
    %cst_14 = arith.constant 0.78539816339744828 : f64
    %cst_15 = arith.constant 6.2831853071795862 : f64
    %cst_16 = arith.constant 1.5707963267948966 : f64
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.rz(%cst_16) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rx(%cst_16) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_11) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rx(%cst_16) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_15) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_13) %7 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_12) %10 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %11, %9 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %12 = qco.rz(%cst_11) %qubit1_out : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_13) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_14) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_10) %qubit0_out : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_16) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_9) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_16) %17 : !qco.qubit -> !qco.qubit
    %qubit0_out_17, %qubit1_out_18 = qco.iswap %18, %14 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %19 = qco.rz(%cst_8) %qubit1_out_18 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_16) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_7) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_1) %qubit0_out_17 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_16) %21 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_14) %2 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_13) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_12) %25 : !qco.qubit -> !qco.qubit
    %qubit0_out_19, %qubit1_out_20 = qco.iswap %26, %23 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %27 = qco.rz(%cst_11) %qubit1_out_20 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_13) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_14) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_6) %qubit0_out_19 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_16) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_5) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_16) %32 : !qco.qubit -> !qco.qubit
    %qubit0_out_21, %qubit1_out_22 = qco.iswap %33, %29 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %34 = qco.rz(%cst_8) %qubit1_out_22 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_16) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_4) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_0) %qubit0_out_21 : !qco.qubit -> !qco.qubit
    %38 = qco.rx(%cst_16) %36 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_14) %3 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_13) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_12) %40 : !qco.qubit -> !qco.qubit
    %qubit0_out_23, %qubit1_out_24 = qco.iswap %41, %38 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %42 = qco.rz(%cst_11) %qubit1_out_24 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_13) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_14) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_10) %qubit0_out_23 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst_16) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_3) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rx(%cst_16) %47 : !qco.qubit -> !qco.qubit
    %qubit0_out_25, %qubit1_out_26 = qco.iswap %48, %44 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %49 = qco.rz(%cst_8) %qubit1_out_26 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_16) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_2) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst) %qubit0_out_25 : !qco.qubit -> !qco.qubit
    %53 = qco.rx(%cst_16) %22 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_16) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rx(%cst_16) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_15) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rx(%cst_13) %37 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_12) %57 : !qco.qubit -> !qco.qubit
    %qubit0_out_27, %qubit1_out_28 = qco.iswap %58, %56 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %59 = qco.rz(%cst_11) %qubit1_out_28 : !qco.qubit -> !qco.qubit
    %60 = qco.rx(%cst_13) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_14) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_10) %qubit0_out_27 : !qco.qubit -> !qco.qubit
    %63 = qco.rx(%cst_16) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_9) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rx(%cst_16) %64 : !qco.qubit -> !qco.qubit
    %qubit0_out_29, %qubit1_out_30 = qco.iswap %65, %61 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %66 = qco.rz(%cst_8) %qubit1_out_30 : !qco.qubit -> !qco.qubit
    %67 = qco.rx(%cst_16) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_7) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_1) %qubit0_out_29 : !qco.qubit -> !qco.qubit
    %70 = qco.rx(%cst_16) %68 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_13) %52 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_12) %71 : !qco.qubit -> !qco.qubit
    %qubit0_out_31, %qubit1_out_32 = qco.iswap %72, %70 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %73 = qco.rz(%cst_11) %qubit1_out_32 : !qco.qubit -> !qco.qubit
    %74 = qco.rx(%cst_13) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_14) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_6) %qubit0_out_31 : !qco.qubit -> !qco.qubit
    %77 = qco.rx(%cst_16) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_5) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rx(%cst_16) %78 : !qco.qubit -> !qco.qubit
    %qubit0_out_33, %qubit1_out_34 = qco.iswap %79, %75 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %80 = qco.rz(%cst_8) %qubit1_out_34 : !qco.qubit -> !qco.qubit
    %81 = qco.rx(%cst_16) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_4) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_0) %qubit0_out_33 : !qco.qubit -> !qco.qubit
    %84 = qco.rx(%cst_16) %69 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_16) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rx(%cst_16) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_15) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rx(%cst_13) %83 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_12) %88 : !qco.qubit -> !qco.qubit
    %qubit0_out_35, %qubit1_out_36 = qco.iswap %89, %87 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %90 = qco.rz(%cst_11) %qubit1_out_36 : !qco.qubit -> !qco.qubit
    %91 = qco.rx(%cst_13) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_14) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_10) %qubit0_out_35 : !qco.qubit -> !qco.qubit
    %94 = qco.rx(%cst_16) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_9) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rx(%cst_16) %95 : !qco.qubit -> !qco.qubit
    %qubit0_out_37, %qubit1_out_38 = qco.iswap %96, %92 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %97 = qco.rz(%cst_8) %qubit1_out_38 : !qco.qubit -> !qco.qubit
    %98 = qco.rx(%cst_16) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_7) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_1) %qubit0_out_37 : !qco.qubit -> !qco.qubit
    %101 = qco.rx(%cst_16) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_16) %101 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %102 : !qco.qubit
    cbit.store %result, %4[%c3] : !cbit.reg<4>
    %qubit_out_39, %result_40 = qco.measure %99 : !qco.qubit
    cbit.store %result_40, %4[%c2] : !cbit.reg<4>
    %qubit_out_41, %result_42 = qco.measure %82 : !qco.qubit
    cbit.store %result_42, %4[%c1] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    qco.sink %qubit_out_41 : !qco.qubit
    %qubit_out_43, %result_44 = qco.measure %51 : !qco.qubit
    qco.sink %qubit_out_43 : !qco.qubit
    cbit.store %result_44, %4[%c0] : !cbit.reg<4>
    %cst_45 = arith.constant -1.4726215563702105 : f64
    qco.gphase(%cst_45)
    return %4 : !cbit.reg<4>
  }
}
