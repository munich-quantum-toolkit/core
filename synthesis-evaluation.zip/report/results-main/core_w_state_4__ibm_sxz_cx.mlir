module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 6.2831853071795862 : f64
    %cst_0 = arith.constant -1.5707963267948961 : f64
    %cst_1 = arith.constant -4.7123889803846915 : f64
    %cst_2 = arith.constant -1.0471975511965979 : f64
    %cst_3 = arith.constant -3.0243399873051935 : f64
    %cst_4 = arith.constant 0.11725266628459963 : f64
    %cst_5 = arith.constant -2.6179938779914949 : f64
    %cst_6 = arith.constant -1.5707963267948957 : f64
    %cst_7 = arith.constant 4.7123889803846897 : f64
    %cst_8 = arith.constant 4.7123889803846879 : f64
    %cst_9 = arith.constant -0.95531661812450918 : f64
    %cst_10 = arith.constant 2.5261129449194057 : f64
    %cst_11 = arith.constant 3.1415926535897931 : f64
    %cst_12 = arith.constant 3.1415926535897936 : f64
    %cst_13 = arith.constant 1.570796326794897 : f64
    %cst_14 = arith.constant -6.2831853071795862 : f64
    %cst_15 = arith.constant -3.1415926535897931 : f64
    %cst_16 = arith.constant -0.78539816339744872 : f64
    %cst_17 = arith.constant 1.5707963267948966 : f64
    %cst_18 = arith.constant 7.0685834705770345 : f64
    %cst_19 = arith.constant 4.7123889803846906 : f64
    %cst_20 = arith.constant 1.5707963267948974 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.x %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_15) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.sx %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_5) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_4) %5 : !qco.qubit -> !qco.qubit
    %10 = qco.x %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_3) %10 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%11) targets (%arg0 = %8) {
      %55 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %55 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qco.rz(%cst_2) %targets_out : !qco.qubit -> !qco.qubit
    %13 = qco.sx %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_15) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_14) %controls_out : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_17) %16 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%17) targets (%arg0 = %14) {
      %55 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %55 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qco.rz(%cst_1) %targets_out_22 : !qco.qubit -> !qco.qubit
    %19 = qco.sx %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_0) %controls_out_21 : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.sx %2 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_10) %23 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%19) targets (%arg0 = %24) {
      %55 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %55 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %25 = qco.rz(%cst_9) %targets_out_24 : !qco.qubit -> !qco.qubit
    %26 = qco.sx %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_15) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_14) %controls_out_23 : !qco.qubit -> !qco.qubit
    %29 = qco.sx %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_17) %29 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%30) targets (%arg0 = %27) {
      %55 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %55 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.sx %targets_out_26 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_8) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.sx %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_7) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_6) %controls_out_25 : !qco.qubit -> !qco.qubit
    %36 = qco.sx %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_11) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_20) %3 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_19) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.sx %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_18) %41 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%34) targets (%arg0 = %42) {
      %55 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %55 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qco.rz(%cst_16) %targets_out_28 : !qco.qubit -> !qco.qubit
    %44 = qco.sx %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_15) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_14) %controls_out_27 : !qco.qubit -> !qco.qubit
    %47 = qco.sx %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_17) %47 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%48) targets (%arg0 = %45) {
      %55 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %55 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qco.rz(%cst_13) %targets_out_30 : !qco.qubit -> !qco.qubit
    %50 = qco.sx %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_12) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_20) %controls_out_29 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_11) %53 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %22 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<4>
    %qubit_out_31, %result_32 = qco.measure %37 : !qco.qubit
    cbit.store %result_32, %4[%c1] : !cbit.reg<4>
    %qubit_out_33, %result_34 = qco.measure %54 : !qco.qubit
    cbit.store %result_34, %4[%c2] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_31 : !qco.qubit
    qco.sink %qubit_out_33 : !qco.qubit
    %qubit_out_35, %result_36 = qco.measure %51 : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    cbit.store %result_36, %4[%c3] : !cbit.reg<4>
    %cst_37 = arith.constant 4.4408920985006262E-15 : f64
    qco.gphase(%cst_37)
    return %4 : !cbit.reg<4>
  }
}
