module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant 3.1415926535897927 : f64
    %cst_0 = arith.constant 4.7123889803846897 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %cst_2 = arith.constant -3.1415926535897931 : f64
    %cst_3 = arith.constant 2.3561944901923448 : f64
    %cst_4 = arith.constant -0.78539816339744828 : f64
    %cst_5 = arith.constant 0.78539816339744828 : f64
    %cst_6 = arith.constant 1.5707963267948966 : f64
    %cst_7 = arith.constant 3.1415926535897931 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %9 = qco.rx(%cst_7) %0 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_6) %1 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_6) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_3) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_6) %3 : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_6) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_3) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_6) %5 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_6) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_3) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_6) %7 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_6) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_3) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_7) %9 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_6) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_7) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_7) %12 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_4) %25 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %26, %24 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %27 = qco.rz(%cst_3) %qubit1_out : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_7) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_5) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_2) %qubit0_out : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_6) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_1) %31 : !qco.qubit -> !qco.qubit
    %qubit0_out_8, %qubit1_out_9 = qco.iswap %32, %29 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %33 = qco.rz(%cst_1) %qubit1_out_9 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_6) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_0) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst) %qubit0_out_8 : !qco.qubit -> !qco.qubit
    %37 = qco.rx(%cst_6) %35 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_7) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_7) %15 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_4) %39 : !qco.qubit -> !qco.qubit
    %qubit0_out_10, %qubit1_out_11 = qco.iswap %40, %38 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %41 = qco.rz(%cst_3) %qubit1_out_11 : !qco.qubit -> !qco.qubit
    %42 = qco.rx(%cst_7) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_5) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_2) %qubit0_out_10 : !qco.qubit -> !qco.qubit
    %45 = qco.rx(%cst_6) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_1) %45 : !qco.qubit -> !qco.qubit
    %qubit0_out_12, %qubit1_out_13 = qco.iswap %46, %43 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %47 = qco.rz(%cst_1) %qubit1_out_13 : !qco.qubit -> !qco.qubit
    %48 = qco.rx(%cst_6) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_0) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst) %qubit0_out_12 : !qco.qubit -> !qco.qubit
    %51 = qco.rx(%cst_6) %49 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_7) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rx(%cst_7) %18 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_4) %53 : !qco.qubit -> !qco.qubit
    %qubit0_out_14, %qubit1_out_15 = qco.iswap %54, %52 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %55 = qco.rz(%cst_3) %qubit1_out_15 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_7) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_5) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_2) %qubit0_out_14 : !qco.qubit -> !qco.qubit
    %59 = qco.rx(%cst_6) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_1) %59 : !qco.qubit -> !qco.qubit
    %qubit0_out_16, %qubit1_out_17 = qco.iswap %60, %57 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %61 = qco.rz(%cst_1) %qubit1_out_17 : !qco.qubit -> !qco.qubit
    %62 = qco.rx(%cst_6) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_0) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst) %qubit0_out_16 : !qco.qubit -> !qco.qubit
    %65 = qco.rx(%cst_6) %63 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_7) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rx(%cst_7) %21 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_4) %67 : !qco.qubit -> !qco.qubit
    %qubit0_out_18, %qubit1_out_19 = qco.iswap %68, %66 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %69 = qco.rz(%cst_3) %qubit1_out_19 : !qco.qubit -> !qco.qubit
    %70 = qco.rx(%cst_7) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_5) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_2) %qubit0_out_18 : !qco.qubit -> !qco.qubit
    %73 = qco.rx(%cst_6) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_1) %73 : !qco.qubit -> !qco.qubit
    %qubit0_out_20, %qubit1_out_21 = qco.iswap %74, %71 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %75 = qco.rz(%cst_1) %qubit1_out_21 : !qco.qubit -> !qco.qubit
    %76 = qco.rx(%cst_6) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_6) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst) %qubit0_out_20 : !qco.qubit -> !qco.qubit
    %79 = qco.rx(%cst_6) %36 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_6) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rx(%cst_6) %50 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_6) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rx(%cst_6) %64 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_6) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rx(%cst_6) %78 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_6) %85 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %80 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<7>
    %qubit_out_22, %result_23 = qco.measure %2 : !qco.qubit
    cbit.store %result_23, %8[%c1] : !cbit.reg<7>
    %qubit_out_24, %result_25 = qco.measure %82 : !qco.qubit
    cbit.store %result_25, %8[%c2] : !cbit.reg<7>
    %qubit_out_26, %result_27 = qco.measure %4 : !qco.qubit
    cbit.store %result_27, %8[%c3] : !cbit.reg<7>
    %qubit_out_28, %result_29 = qco.measure %84 : !qco.qubit
    cbit.store %result_29, %8[%c4] : !cbit.reg<7>
    %qubit_out_30, %result_31 = qco.measure %6 : !qco.qubit
    cbit.store %result_31, %8[%c5] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_22 : !qco.qubit
    qco.sink %qubit_out_24 : !qco.qubit
    qco.sink %qubit_out_26 : !qco.qubit
    qco.sink %qubit_out_28 : !qco.qubit
    qco.sink %qubit_out_30 : !qco.qubit
    %qubit_out_32, %result_33 = qco.measure %86 : !qco.qubit
    qco.sink %qubit_out_32 : !qco.qubit
    cbit.store %result_33, %8[%c6] : !cbit.reg<7>
    qco.sink %77 : !qco.qubit
    %cst_34 = arith.constant -1.5707963267949001 : f64
    qco.gphase(%cst_34)
    return %8 : !cbit.reg<7>
  }
}
