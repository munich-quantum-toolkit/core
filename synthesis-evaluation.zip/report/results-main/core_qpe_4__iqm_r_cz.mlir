module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 0>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948974 : f64
    %cst_0 = arith.constant 1.9634954084936209 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %cst_2 = arith.constant -0.39269908169872458 : f64
    %cst_3 = arith.constant 3.1415926535897931 : f64
    %cst_4 = arith.constant -0.78539816339744739 : f64
    %cst_5 = arith.constant 2.3561944901923453 : f64
    %cst_6 = arith.constant 3.1415926535897927 : f64
    %cst_7 = arith.constant 1.5707963267948968 : f64
    %cst_8 = arith.constant 2.3561944901923448 : f64
    %cst_9 = arith.constant -0.78539816339744916 : f64
    %cst_10 = arith.constant 7.8539816339744819 : f64
    %cst_11 = arith.constant 2.7488935718910694 : f64
    %cst_12 = arith.constant 3.1415926535897922 : f64
    %cst_13 = arith.constant 2.748893571891069 : f64
    %cst_14 = arith.constant -1.178097245096172 : f64
    %cst_15 = arith.constant 1.570796326794897 : f64
    %cst_16 = arith.constant 6.2831853071795862 : f64
    %cst_17 = arith.constant 7.8539816339744828 : f64
    %cst_18 = arith.constant 1.5707963267948966 : f64
    %cst_19 = arith.constant 0.000000e+00 : f64
    %cst_20 = arith.constant 4.7123889803846897 : f64
    %cst_21 = arith.constant 9.4247779607693793 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %5 = qco.r(%cst_18, %cst_18) %1 : !qco.qubit -> !qco.qubit
    %6 = qco.r(%cst_3, %cst_19) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.r(%cst_18, %cst_18) %2 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_3, %cst_19) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_18, %cst_18) %3 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_3, %cst_19) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_21, %cst_19) %0 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_20, %cst_19) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_18, %cst_18) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_7, %cst_19) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_3, %cst_19) %10 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_7, %cst_18) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_20, %cst_19) %16 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%17) targets (%arg0 = %14) {
      %108 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %108 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qco.r(%cst_20, %cst_19) %targets_out : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst_18, %cst_18) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_20, %cst_19) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_2, %cst_19) %controls_out : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_18, %cst_18) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_18, %cst_19) %22 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%23) targets (%arg0 = %20) {
      %108 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %108 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.r(%cst_1, %cst_19) %targets_out_23 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_0, %cst_18) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_20, %cst_19) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst_3, %cst_19) %controls_out_22 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_0, %cst_18) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.r(%cst, %cst_19) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_20, %cst_19) %26 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%cst_18, %cst_18) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_17, %cst_19) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_16, %cst_19) %8 : !qco.qubit -> !qco.qubit
    %34 = qco.r(%cst_15, %cst_18) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst_20, %cst_19) %34 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%35) targets (%arg0 = %32) {
      %108 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %108 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qco.r(%cst_20, %cst_19) %targets_out_25 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%cst_18, %cst_18) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst_20, %cst_19) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst_4, %cst_19) %controls_out_24 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_15, %cst_18) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst_7, %cst_19) %40 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%41) targets (%arg0 = %38) {
      %108 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %108 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qco.r(%cst_7, %cst_19) %targets_out_27 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%cst_8, %cst_18) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_17, %cst_19) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst_6, %cst_19) %controls_out_26 : !qco.qubit -> !qco.qubit
    %46 = qco.r(%cst_8, %cst_18) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%cst_17, %cst_19) %46 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%6) targets (%arg0 = %44) {
      %108 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %108 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %48 = qco.r(%cst_18, %cst_18) %controls_out_28 : !qco.qubit -> !qco.qubit
    %49 = qco.r(%cst_3, %cst_19) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.r(%cst_20, %cst_19) %47 : !qco.qubit -> !qco.qubit
    %51 = qco.r(%cst_18, %cst_18) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.r(%cst_17, %cst_19) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst_16, %cst_19) %49 : !qco.qubit -> !qco.qubit
    %54 = qco.r(%cst_15, %cst_18) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.r(%cst_20, %cst_19) %54 : !qco.qubit -> !qco.qubit
    %controls_out_30, %targets_out_31 = qco.ctrl(%55) targets (%arg0 = %52) {
      %108 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %108 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qco.r(%cst_20, %cst_19) %targets_out_31 : !qco.qubit -> !qco.qubit
    %57 = qco.r(%cst_18, %cst_18) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.r(%cst_20, %cst_19) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%cst_9, %cst_19) %controls_out_30 : !qco.qubit -> !qco.qubit
    %60 = qco.r(%cst_15, %cst_18) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.r(%cst_18, %cst_19) %60 : !qco.qubit -> !qco.qubit
    %controls_out_32, %targets_out_33 = qco.ctrl(%61) targets (%arg0 = %58) {
      %108 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %108 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %62 = qco.r(%cst_15, %cst_19) %targets_out_33 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%cst_8, %cst_18) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.r(%cst_7, %cst_19) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%cst_6, %cst_19) %controls_out_32 : !qco.qubit -> !qco.qubit
    %66 = qco.r(%cst_5, %cst_18) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.r(%cst_17, %cst_19) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.r(%cst_18, %cst_18) %64 : !qco.qubit -> !qco.qubit
    %69 = qco.r(%cst_3, %cst_19) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.r(%cst_20, %cst_19) %29 : !qco.qubit -> !qco.qubit
    %71 = qco.r(%cst_18, %cst_18) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%cst_17, %cst_19) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%cst_16, %cst_19) %69 : !qco.qubit -> !qco.qubit
    %74 = qco.r(%cst_15, %cst_18) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.r(%cst_20, %cst_19) %74 : !qco.qubit -> !qco.qubit
    %controls_out_34, %targets_out_35 = qco.ctrl(%75) targets (%arg0 = %72) {
      %108 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %108 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %76 = qco.r(%cst_20, %cst_19) %targets_out_35 : !qco.qubit -> !qco.qubit
    %77 = qco.r(%cst_18, %cst_18) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst_20, %cst_19) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.r(%cst_9, %cst_19) %controls_out_34 : !qco.qubit -> !qco.qubit
    %80 = qco.r(%cst_15, %cst_18) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%cst_18, %cst_19) %80 : !qco.qubit -> !qco.qubit
    %controls_out_36, %targets_out_37 = qco.ctrl(%81) targets (%arg0 = %78) {
      %108 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %108 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %82 = qco.r(%cst_15, %cst_19) %targets_out_37 : !qco.qubit -> !qco.qubit
    %83 = qco.r(%cst_8, %cst_18) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.r(%cst_7, %cst_19) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.r(%cst_6, %cst_19) %controls_out_36 : !qco.qubit -> !qco.qubit
    %86 = qco.r(%cst_5, %cst_18) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.r(%cst_17, %cst_19) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.r(%cst_20, %cst_19) %84 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%cst_18, %cst_18) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.r(%cst_17, %cst_19) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.r(%cst_16, %cst_19) %67 : !qco.qubit -> !qco.qubit
    %92 = qco.r(%cst_15, %cst_18) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.r(%cst_20, %cst_19) %92 : !qco.qubit -> !qco.qubit
    %controls_out_38, %targets_out_39 = qco.ctrl(%93) targets (%arg0 = %90) {
      %108 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %108 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %94 = qco.r(%cst_20, %cst_19) %targets_out_39 : !qco.qubit -> !qco.qubit
    %95 = qco.r(%cst_18, %cst_18) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.r(%cst_20, %cst_19) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.r(%cst_14, %cst_19) %controls_out_38 : !qco.qubit -> !qco.qubit
    %98 = qco.r(%cst_15, %cst_18) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.r(%cst_18, %cst_19) %98 : !qco.qubit -> !qco.qubit
    %controls_out_40, %targets_out_41 = qco.ctrl(%99) targets (%arg0 = %96) {
      %108 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %108 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %100 = qco.r(%cst_15, %cst_19) %targets_out_41 : !qco.qubit -> !qco.qubit
    %101 = qco.r(%cst_13, %cst_18) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.r(%cst_18, %cst_19) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.r(%cst_12, %cst_19) %controls_out_40 : !qco.qubit -> !qco.qubit
    %104 = qco.r(%cst_11, %cst_18) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.r(%cst_10, %cst_19) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.r(%cst_18, %cst_18) %102 : !qco.qubit -> !qco.qubit
    %107 = qco.r(%cst_3, %cst_19) %106 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %105 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<3>
    %qubit_out_42, %result_43 = qco.measure %87 : !qco.qubit
    cbit.store %result_43, %4[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_42 : !qco.qubit
    %qubit_out_44, %result_45 = qco.measure %107 : !qco.qubit
    qco.sink %qubit_out_44 : !qco.qubit
    cbit.store %result_45, %4[%c2] : !cbit.reg<3>
    qco.sink %targets_out_29 : !qco.qubit
    %cst_46 = arith.constant 2.3561944901923493 : f64
    qco.gphase(%cst_46)
    return %4 : !cbit.reg<3>
  }
}
