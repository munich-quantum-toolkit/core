module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 6.8828228713297559 : f64
    %cst_0 = arith.constant 3.1415926535897887 : f64
    %cst_1 = arith.constant 3.3931520156444699 : f64
    %cst_2 = arith.constant -4.7123889803846843 : f64
    %cst_3 = arith.constant 4.2178132105483392 : f64
    %cst_4 = arith.constant 5.2940337675068836 : f64
    %cst_5 = arith.constant 0.59963756415017011 : f64
    %cst_6 = arith.constant -4.7123889803846915 : f64
    %cst_7 = arith.constant 4.9360735037106629 : f64
    %cst_8 = arith.constant 3.8962707397538185 : f64
    %cst_9 = arith.constant 5.9058462640975726 : f64
    %cst_10 = arith.constant 0.20232162837830359 : f64
    %cst_11 = arith.constant -0.20232162837830359 : f64
    %cst_12 = arith.constant 4.7123889803847074 : f64
    %cst_13 = arith.constant -4.7123889803846764 : f64
    %cst_14 = arith.constant 3.1415926535897949 : f64
    %cst_15 = arith.constant 5.3028890367131627 : f64
    %cst_16 = arith.constant -1.5707963267948954 : f64
    %cst_17 = arith.constant 3.8126462235677074 : f64
    %cst_18 = arith.constant 5.9476585221906282 : f64
    %cst_19 = arith.constant 4.7123889803846888 : f64
    %cst_20 = arith.constant 6.2831853071795809 : f64
    %cst_21 = arith.constant 6.1205688287882527 : f64
    %cst_22 = arith.constant 1.5707963267948899 : f64
    %cst_23 = arith.constant 4.6120370592894311 : f64
    %cst_24 = arith.constant 6.0824814649890691 : f64
    %cst_25 = arith.constant 7.8539816339744828 : f64
    %cst_26 = arith.constant 4.7123889803846879 : f64
    %cst_27 = arith.constant -1.5099033134902129E-14 : f64
    %cst_28 = arith.constant 4.7887388507657684 : f64
    %cst_29 = arith.constant 1.5707963267948672 : f64
    %cst_30 = arith.constant 3.6294420887637955 : f64
    %cst_31 = arith.constant 3.141592653589794 : f64
    %cst_32 = arith.constant 6.0392605895925842 : f64
    %cst_33 = arith.constant 3.1415926535897629 : f64
    %cst_34 = arith.constant 4.7123889803846701 : f64
    %cst_35 = arith.constant -1.5707963267948828 : f64
    %cst_36 = arith.constant 1.6431300764452317E-14 : f64
    %cst_37 = arith.constant 5.2077336663912188 : f64
    %cst_38 = arith.constant 1.570796326794881 : f64
    %cst_39 = arith.constant 3.1415926535897927 : f64
    %cst_40 = arith.constant 3.3706422647329704 : f64
    %cst_41 = arith.constant 3.1415926535897953 : f64
    %cst_42 = arith.constant 6.1686605016079969 : f64
    %cst_43 = arith.constant 4.7123889803846915 : f64
    %cst_44 = arith.constant 3.1415926535897647 : f64
    %cst_45 = arith.constant -3.9269908169872414 : f64
    %cst_46 = arith.constant 5.1663591466895369 : f64
    %cst_47 = arith.constant 4.7123889803846906 : f64
    %cst_48 = arith.constant 4.6276267116093095 : f64
    %cst_49 = arith.constant 5.5401682781698272 : f64
    %cst_50 = arith.constant 3.9269908169872414 : f64
    %cst_51 = arith.constant 3.1415926535897944 : f64
    %cst_52 = arith.constant 0.78539816339744861 : f64
    %cst_53 = arith.constant 6.2831853071795862 : f64
    %cst_54 = arith.constant 4.3611705730879251 : f64
    %cst_55 = arith.constant -1.5707963267948957 : f64
    %cst_56 = arith.constant 4.5035031525043383 : f64
    %cst_57 = arith.constant 5.6022300577223128 : f64
    %cst_58 = arith.constant -3.1415926535897922 : f64
    %cst_59 = arith.constant 5.443805173947295 : f64
    %cst_60 = arith.constant 1.5707963267948974 : f64
    %cst_61 = arith.constant 4.1952478754800904 : f64
    %cst_62 = arith.constant 5.7563576962344367 : f64
    %cst_63 = arith.constant 4.957367643511553 : f64
    %cst_64 = arith.constant -2.8966139904629284 : f64
    %cst_65 = arith.constant 3.9649392269835104 : f64
    %cst_66 = arith.constant 1.570796326794895 : f64
    %cst_67 = arith.constant 4.4006628534382308 : f64
    %cst_68 = arith.constant 5.6597330532866668 : f64
    %cst_69 = arith.constant 3.1415926535897918 : f64
    %cst_70 = arith.constant 3.2912280793302724 : f64
    %cst_71 = arith.constant 1.5707963267948972 : f64
    %cst_72 = arith.constant 4.2627672836915629 : f64
    %cst_73 = arith.constant 5.3839419137933326 : f64
    %cst_74 = arith.constant -1.5707963267948966 : f64
    %cst_75 = arith.constant -6.2831853071795862 : f64
    %cst_76 = arith.constant 3.5904989308112256 : f64
    %cst_77 = arith.constant 3.1415926535897936 : f64
    %cst_78 = arith.constant 6.0587321685688691 : f64
    %cst_79 = arith.constant 4.7123889803846897 : f64
    %cst_80 = arith.constant 1.5707963267948966 : f64
    %cst_81 = arith.constant -4.7123889803846897 : f64
    %cst_82 = arith.constant 3.1415926535897931 : f64
    %cst_83 = arith.constant 3.8590730248954901 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.rx(%cst_80) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.rz(%cst_83) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.rx(%cst_80) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_74) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_80) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_25) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_82) %7 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_5) %11 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%12) targets (%arg0 = %10) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %13 = qco.rz(%cst_79) %targets_out : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_80) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_4) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_80) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_82) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_81) %controls_out : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_80) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_3) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_80) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_82) %21 : !qco.qubit -> !qco.qubit
    %controls_out_84, %targets_out_85 = qco.ctrl(%22) targets (%arg0 = %17) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qco.rz(%cst_2) %targets_out_85 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_80) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_1) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_80) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_0) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_80) %controls_out_84 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_79) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_11) %2 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_80) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_41) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_80) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_10) %33 : !qco.qubit -> !qco.qubit
    %controls_out_86, %targets_out_87 = qco.ctrl(%27) targets (%arg0 = %34) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.rz(%cst_47) %targets_out_87 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_80) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_9) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rx(%cst_80) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_31) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_81) %controls_out_86 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_80) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_8) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_80) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_82) %43 : !qco.qubit -> !qco.qubit
    %controls_out_88, %targets_out_89 = qco.ctrl(%44) targets (%arg0 = %39) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.rz(%cst_74) %targets_out_89 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst_80) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_7) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rx(%cst_80) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_51) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_6) %controls_out_88 : !qco.qubit -> !qco.qubit
    %51 = qco.rx(%cst_80) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_19) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rx(%cst_80) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_77) %53 : !qco.qubit -> !qco.qubit
    %controls_out_90, %targets_out_91 = qco.ctrl(%49) targets (%arg0 = %3) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.rz(%cst_47) %targets_out_91 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_80) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_18) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_80) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_31) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_81) %controls_out_90 : !qco.qubit -> !qco.qubit
    %61 = qco.rx(%cst_80) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_17) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rx(%cst_80) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_82) %63 : !qco.qubit -> !qco.qubit
    %controls_out_92, %targets_out_93 = qco.ctrl(%64) targets (%arg0 = %59) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qco.rz(%cst_16) %targets_out_93 : !qco.qubit -> !qco.qubit
    %66 = qco.rx(%cst_80) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_15) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rx(%cst_80) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_14) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_13) %controls_out_92 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_80) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_12) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rx(%cst_80) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_44) %73 : !qco.qubit -> !qco.qubit
    %controls_out_94, %targets_out_95 = qco.ctrl(%69) targets (%arg0 = %29) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %75 = qco.rz(%cst_43) %targets_out_95 : !qco.qubit -> !qco.qubit
    %76 = qco.rx(%cst_80) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_24) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rx(%cst_80) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_51) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_81) %controls_out_94 : !qco.qubit -> !qco.qubit
    %81 = qco.rx(%cst_80) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_23) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rx(%cst_80) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_82) %83 : !qco.qubit -> !qco.qubit
    %controls_out_96, %targets_out_97 = qco.ctrl(%84) targets (%arg0 = %79) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %85 = qco.rz(%cst_22) %targets_out_97 : !qco.qubit -> !qco.qubit
    %86 = qco.rx(%cst_80) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_21) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rx(%cst_80) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_20) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_47) %controls_out_96 : !qco.qubit -> !qco.qubit
    %controls_out_98, %targets_out_99 = qco.ctrl(%89) targets (%arg0 = %54) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %91 = qco.rz(%cst_47) %targets_out_99 : !qco.qubit -> !qco.qubit
    %92 = qco.rx(%cst_80) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_32) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rx(%cst_80) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_31) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_81) %controls_out_98 : !qco.qubit -> !qco.qubit
    %97 = qco.rx(%cst_80) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_30) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rx(%cst_80) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_39) %99 : !qco.qubit -> !qco.qubit
    %controls_out_100, %targets_out_101 = qco.ctrl(%100) targets (%arg0 = %95) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %101 = qco.rz(%cst_29) %targets_out_101 : !qco.qubit -> !qco.qubit
    %102 = qco.rx(%cst_80) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst_28) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rx(%cst_80) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst_27) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_81) %controls_out_100 : !qco.qubit -> !qco.qubit
    %107 = qco.rx(%cst_80) %106 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_26) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rx(%cst_80) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst_77) %109 : !qco.qubit -> !qco.qubit
    %controls_out_102, %targets_out_103 = qco.ctrl(%105) targets (%arg0 = %74) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %111 = qco.rz(%cst_43) %targets_out_103 : !qco.qubit -> !qco.qubit
    %112 = qco.rx(%cst_80) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_42) %112 : !qco.qubit -> !qco.qubit
    %114 = qco.rx(%cst_80) %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_41) %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst_81) %controls_out_102 : !qco.qubit -> !qco.qubit
    %117 = qco.rx(%cst_80) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_40) %117 : !qco.qubit -> !qco.qubit
    %119 = qco.rx(%cst_80) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.rz(%cst_39) %119 : !qco.qubit -> !qco.qubit
    %controls_out_104, %targets_out_105 = qco.ctrl(%120) targets (%arg0 = %115) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %121 = qco.rz(%cst_38) %targets_out_105 : !qco.qubit -> !qco.qubit
    %122 = qco.rx(%cst_80) %121 : !qco.qubit -> !qco.qubit
    %123 = qco.rz(%cst_37) %122 : !qco.qubit -> !qco.qubit
    %124 = qco.rx(%cst_80) %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rz(%cst_36) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst_35) %controls_out_104 : !qco.qubit -> !qco.qubit
    %127 = qco.rx(%cst_80) %126 : !qco.qubit -> !qco.qubit
    %128 = qco.rz(%cst_34) %127 : !qco.qubit -> !qco.qubit
    %129 = qco.rx(%cst_80) %128 : !qco.qubit -> !qco.qubit
    %130 = qco.rz(%cst_33) %129 : !qco.qubit -> !qco.qubit
    %controls_out_106, %targets_out_107 = qco.ctrl(%125) targets (%arg0 = %90) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %131 = qco.rz(%cst_79) %targets_out_107 : !qco.qubit -> !qco.qubit
    %132 = qco.rx(%cst_80) %131 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst_49) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.rx(%cst_80) %133 : !qco.qubit -> !qco.qubit
    %135 = qco.rz(%cst_77) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.rz(%cst_81) %controls_out_106 : !qco.qubit -> !qco.qubit
    %137 = qco.rx(%cst_80) %136 : !qco.qubit -> !qco.qubit
    %138 = qco.rz(%cst_48) %137 : !qco.qubit -> !qco.qubit
    %139 = qco.rx(%cst_80) %138 : !qco.qubit -> !qco.qubit
    %140 = qco.rz(%cst_82) %139 : !qco.qubit -> !qco.qubit
    %controls_out_108, %targets_out_109 = qco.ctrl(%140) targets (%arg0 = %135) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %141 = qco.rz(%cst_47) %targets_out_109 : !qco.qubit -> !qco.qubit
    %142 = qco.rx(%cst_80) %141 : !qco.qubit -> !qco.qubit
    %143 = qco.rz(%cst_46) %142 : !qco.qubit -> !qco.qubit
    %144 = qco.rx(%cst_80) %143 : !qco.qubit -> !qco.qubit
    %145 = qco.rz(%cst_82) %144 : !qco.qubit -> !qco.qubit
    %146 = qco.rz(%cst_45) %controls_out_108 : !qco.qubit -> !qco.qubit
    %147 = qco.rx(%cst_82) %146 : !qco.qubit -> !qco.qubit
    %148 = qco.rz(%cst_50) %147 : !qco.qubit -> !qco.qubit
    %controls_out_110, %targets_out_111 = qco.ctrl(%145) targets (%arg0 = %110) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %149 = qco.rz(%cst_79) %targets_out_111 : !qco.qubit -> !qco.qubit
    %150 = qco.rx(%cst_80) %149 : !qco.qubit -> !qco.qubit
    %151 = qco.rz(%cst_57) %150 : !qco.qubit -> !qco.qubit
    %152 = qco.rx(%cst_80) %151 : !qco.qubit -> !qco.qubit
    %153 = qco.rz(%cst_77) %152 : !qco.qubit -> !qco.qubit
    %154 = qco.rz(%cst_81) %controls_out_110 : !qco.qubit -> !qco.qubit
    %155 = qco.rx(%cst_80) %154 : !qco.qubit -> !qco.qubit
    %156 = qco.rz(%cst_56) %155 : !qco.qubit -> !qco.qubit
    %157 = qco.rx(%cst_80) %156 : !qco.qubit -> !qco.qubit
    %158 = qco.rz(%cst_82) %157 : !qco.qubit -> !qco.qubit
    %controls_out_112, %targets_out_113 = qco.ctrl(%158) targets (%arg0 = %153) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %159 = qco.rz(%cst_55) %targets_out_113 : !qco.qubit -> !qco.qubit
    %160 = qco.rx(%cst_80) %159 : !qco.qubit -> !qco.qubit
    %161 = qco.rz(%cst_54) %160 : !qco.qubit -> !qco.qubit
    %162 = qco.rx(%cst_80) %161 : !qco.qubit -> !qco.qubit
    %163 = qco.rz(%cst_53) %162 : !qco.qubit -> !qco.qubit
    %164 = qco.rz(%cst_52) %controls_out_112 : !qco.qubit -> !qco.qubit
    %165 = qco.rx(%cst_80) %164 : !qco.qubit -> !qco.qubit
    %166 = qco.rz(%cst_51) %165 : !qco.qubit -> !qco.qubit
    %167 = qco.rx(%cst_80) %166 : !qco.qubit -> !qco.qubit
    %168 = qco.rz(%cst_50) %167 : !qco.qubit -> !qco.qubit
    %controls_out_114, %targets_out_115 = qco.ctrl(%163) targets (%arg0 = %130) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %169 = qco.rz(%cst_79) %targets_out_115 : !qco.qubit -> !qco.qubit
    %170 = qco.rx(%cst_80) %169 : !qco.qubit -> !qco.qubit
    %171 = qco.rz(%cst_62) %170 : !qco.qubit -> !qco.qubit
    %172 = qco.rx(%cst_80) %171 : !qco.qubit -> !qco.qubit
    %173 = qco.rz(%cst_77) %172 : !qco.qubit -> !qco.qubit
    %174 = qco.rz(%cst_81) %controls_out_114 : !qco.qubit -> !qco.qubit
    %175 = qco.rx(%cst_80) %174 : !qco.qubit -> !qco.qubit
    %176 = qco.rz(%cst_61) %175 : !qco.qubit -> !qco.qubit
    %177 = qco.rx(%cst_80) %176 : !qco.qubit -> !qco.qubit
    %178 = qco.rz(%cst_82) %177 : !qco.qubit -> !qco.qubit
    %controls_out_116, %targets_out_117 = qco.ctrl(%178) targets (%arg0 = %173) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %179 = qco.rz(%cst_60) %targets_out_117 : !qco.qubit -> !qco.qubit
    %180 = qco.rx(%cst_80) %179 : !qco.qubit -> !qco.qubit
    %181 = qco.rz(%cst_59) %180 : !qco.qubit -> !qco.qubit
    %182 = qco.rx(%cst_80) %181 : !qco.qubit -> !qco.qubit
    %183 = qco.rz(%cst_58) %controls_out_116 : !qco.qubit -> !qco.qubit
    %184 = qco.rx(%cst_80) %183 : !qco.qubit -> !qco.qubit
    %185 = qco.rz(%cst_80) %184 : !qco.qubit -> !qco.qubit
    %controls_out_118, %targets_out_119 = qco.ctrl(%182) targets (%arg0 = %148) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %186 = qco.rz(%cst_79) %targets_out_119 : !qco.qubit -> !qco.qubit
    %187 = qco.rx(%cst_80) %186 : !qco.qubit -> !qco.qubit
    %188 = qco.rz(%cst_68) %187 : !qco.qubit -> !qco.qubit
    %189 = qco.rx(%cst_80) %188 : !qco.qubit -> !qco.qubit
    %190 = qco.rz(%cst_77) %189 : !qco.qubit -> !qco.qubit
    %191 = qco.rz(%cst_81) %controls_out_118 : !qco.qubit -> !qco.qubit
    %192 = qco.rx(%cst_80) %191 : !qco.qubit -> !qco.qubit
    %193 = qco.rz(%cst_67) %192 : !qco.qubit -> !qco.qubit
    %194 = qco.rx(%cst_80) %193 : !qco.qubit -> !qco.qubit
    %195 = qco.rz(%cst_82) %194 : !qco.qubit -> !qco.qubit
    %controls_out_120, %targets_out_121 = qco.ctrl(%195) targets (%arg0 = %190) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %196 = qco.rz(%cst_66) %targets_out_121 : !qco.qubit -> !qco.qubit
    %197 = qco.rx(%cst_80) %196 : !qco.qubit -> !qco.qubit
    %198 = qco.rz(%cst_65) %197 : !qco.qubit -> !qco.qubit
    %199 = qco.rx(%cst_80) %198 : !qco.qubit -> !qco.qubit
    %200 = qco.rz(%cst_64) %controls_out_120 : !qco.qubit -> !qco.qubit
    %201 = qco.rx(%cst_82) %200 : !qco.qubit -> !qco.qubit
    %202 = qco.rz(%cst_63) %201 : !qco.qubit -> !qco.qubit
    %controls_out_122, %targets_out_123 = qco.ctrl(%199) targets (%arg0 = %168) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %203 = qco.rz(%cst_79) %targets_out_123 : !qco.qubit -> !qco.qubit
    %204 = qco.rx(%cst_80) %203 : !qco.qubit -> !qco.qubit
    %205 = qco.rz(%cst_73) %204 : !qco.qubit -> !qco.qubit
    %206 = qco.rx(%cst_80) %205 : !qco.qubit -> !qco.qubit
    %207 = qco.rz(%cst_77) %206 : !qco.qubit -> !qco.qubit
    %208 = qco.rz(%cst_81) %controls_out_122 : !qco.qubit -> !qco.qubit
    %209 = qco.rx(%cst_80) %208 : !qco.qubit -> !qco.qubit
    %210 = qco.rz(%cst_72) %209 : !qco.qubit -> !qco.qubit
    %211 = qco.rx(%cst_80) %210 : !qco.qubit -> !qco.qubit
    %212 = qco.rz(%cst_82) %211 : !qco.qubit -> !qco.qubit
    %controls_out_124, %targets_out_125 = qco.ctrl(%212) targets (%arg0 = %207) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %213 = qco.rz(%cst_71) %targets_out_125 : !qco.qubit -> !qco.qubit
    %214 = qco.rx(%cst_80) %213 : !qco.qubit -> !qco.qubit
    %215 = qco.rz(%cst_70) %214 : !qco.qubit -> !qco.qubit
    %216 = qco.rx(%cst_80) %215 : !qco.qubit -> !qco.qubit
    %217 = qco.rz(%cst_69) %216 : !qco.qubit -> !qco.qubit
    %218 = qco.rz(%cst_79) %controls_out_124 : !qco.qubit -> !qco.qubit
    qco.sink %202 : !qco.qubit
    qco.sink %218 : !qco.qubit
    %controls_out_126, %targets_out_127 = qco.ctrl(%217) targets (%arg0 = %185) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %219 = qco.rz(%cst_79) %targets_out_127 : !qco.qubit -> !qco.qubit
    %220 = qco.rx(%cst_80) %219 : !qco.qubit -> !qco.qubit
    %221 = qco.rz(%cst_78) %220 : !qco.qubit -> !qco.qubit
    %222 = qco.rx(%cst_80) %221 : !qco.qubit -> !qco.qubit
    %223 = qco.rz(%cst_77) %222 : !qco.qubit -> !qco.qubit
    %224 = qco.rz(%cst_81) %controls_out_126 : !qco.qubit -> !qco.qubit
    %225 = qco.rx(%cst_80) %224 : !qco.qubit -> !qco.qubit
    %226 = qco.rz(%cst_76) %225 : !qco.qubit -> !qco.qubit
    %227 = qco.rx(%cst_80) %226 : !qco.qubit -> !qco.qubit
    %228 = qco.rz(%cst_82) %227 : !qco.qubit -> !qco.qubit
    %controls_out_128, %targets_out_129 = qco.ctrl(%228) targets (%arg0 = %223) {
      %233 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %233 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %229 = qco.rz(%cst_81) %targets_out_129 : !qco.qubit -> !qco.qubit
    %230 = qco.rz(%cst_75) %controls_out_128 : !qco.qubit -> !qco.qubit
    %231 = qco.rx(%cst_80) %230 : !qco.qubit -> !qco.qubit
    %232 = qco.rz(%cst_80) %231 : !qco.qubit -> !qco.qubit
    qco.sink %229 : !qco.qubit
    qco.sink %232 : !qco.qubit
    %cst_130 = arith.constant 2.1316282072803006E-14 : f64
    qco.gphase(%cst_130)
    return %c0_i64 : i64
  }
}
