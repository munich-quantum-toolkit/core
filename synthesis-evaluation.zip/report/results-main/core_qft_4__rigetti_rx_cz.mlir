module attributes {mqt.layout = {initial = array<i64: 3, 2, 0, 1>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant -3.1415926535897931 : f64
    %cst_0 = arith.constant 4.9087385212340511 : f64
    %cst_1 = arith.constant 5.1050880620834143 : f64
    %cst_2 = arith.constant 3.2397674240144743 : f64
    %cst_3 = arith.constant -0.098174770424680716 : f64
    %cst_4 = arith.constant 3.3379421944391545 : f64
    %cst_5 = arith.constant 3.5342917352885168 : f64
    %cst_6 = arith.constant 3.337942194439155 : f64
    %cst_7 = arith.constant -0.1963495408493619 : f64
    %cst_8 = arith.constant 3.5342917352885177 : f64
    %cst_9 = arith.constant 3.5342917352885173 : f64
    %cst_10 = arith.constant -0.39269908169872414 : f64
    %cst_11 = arith.constant 3.9269908169872423 : f64
    %cst_12 = arith.constant 3.9269908169872414 : f64
    %cst_13 = arith.constant 3.1415926535897931 : f64
    %cst_14 = arith.constant 5.497787143782138 : f64
    %cst_15 = arith.constant -1.5707963267948966 : f64
    %cst_16 = arith.constant 1.5707963267948966 : f64
    %cst_17 = arith.constant -4.7123889803846897 : f64
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.rz(%cst_16) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rx(%cst_16) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_16) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_17) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_16) %7 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_15) %9 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%10) targets (%arg0 = %8) {
      %105 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %105 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qco.rz(%cst_14) %targets_out : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_13) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_12) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_17) %controls_out : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_16) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_11) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_16) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_13) %17 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%18) targets (%arg0 = %13) {
      %105 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %105 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.rz(%cst_10) %targets_out_19 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_13) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_1) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst_16) %controls_out_18 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_14) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_16) %2 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_15) %24 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%25) targets (%arg0 = %21) {
      %105 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %105 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.rz(%cst_14) %targets_out_21 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_13) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_12) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_17) %controls_out_20 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_16) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_8) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rx(%cst_16) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_13) %32 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%33) targets (%arg0 = %28) {
      %105 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %105 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.rz(%cst_7) %targets_out_23 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_13) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_0) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rx(%cst_16) %controls_out_22 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_5) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_16) %3 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_15) %39 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%40) targets (%arg0 = %36) {
      %105 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %105 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.rz(%cst_14) %targets_out_25 : !qco.qubit -> !qco.qubit
    %42 = qco.rx(%cst_13) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_12) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_17) %controls_out_24 : !qco.qubit -> !qco.qubit
    %45 = qco.rx(%cst_16) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_4) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rx(%cst_16) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_13) %47 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%48) targets (%arg0 = %43) {
      %105 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %105 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qco.rz(%cst_3) %targets_out_27 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_13) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_2) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rx(%cst_16) %controls_out_26 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_6) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rx(%cst_16) %23 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_16) %38 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_15) %56 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%57) targets (%arg0 = %55) {
      %105 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %105 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = qco.rz(%cst_14) %targets_out_29 : !qco.qubit -> !qco.qubit
    %59 = qco.rx(%cst_13) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_12) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_17) %controls_out_28 : !qco.qubit -> !qco.qubit
    %62 = qco.rx(%cst_16) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_11) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rx(%cst_16) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_13) %64 : !qco.qubit -> !qco.qubit
    %controls_out_30, %targets_out_31 = qco.ctrl(%65) targets (%arg0 = %60) {
      %105 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %105 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = qco.rz(%cst_10) %targets_out_31 : !qco.qubit -> !qco.qubit
    %67 = qco.rx(%cst_13) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_1) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rx(%cst_16) %controls_out_30 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_14) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_16) %53 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_15) %71 : !qco.qubit -> !qco.qubit
    %controls_out_32, %targets_out_33 = qco.ctrl(%72) targets (%arg0 = %68) {
      %105 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %105 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %73 = qco.rz(%cst_14) %targets_out_33 : !qco.qubit -> !qco.qubit
    %74 = qco.rx(%cst_13) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_12) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_17) %controls_out_32 : !qco.qubit -> !qco.qubit
    %77 = qco.rx(%cst_16) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_8) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rx(%cst_16) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_13) %79 : !qco.qubit -> !qco.qubit
    %controls_out_34, %targets_out_35 = qco.ctrl(%80) targets (%arg0 = %75) {
      %105 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %105 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %81 = qco.rz(%cst_7) %targets_out_35 : !qco.qubit -> !qco.qubit
    %82 = qco.rx(%cst_13) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_6) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rx(%cst_16) %controls_out_34 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_5) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rx(%cst_16) %70 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rx(%cst_16) %85 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_15) %88 : !qco.qubit -> !qco.qubit
    %controls_out_36, %targets_out_37 = qco.ctrl(%89) targets (%arg0 = %87) {
      %105 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %105 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %90 = qco.rz(%cst_14) %targets_out_37 : !qco.qubit -> !qco.qubit
    %91 = qco.rx(%cst_13) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_12) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_17) %controls_out_36 : !qco.qubit -> !qco.qubit
    %94 = qco.rx(%cst_16) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_11) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rx(%cst_16) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_13) %96 : !qco.qubit -> !qco.qubit
    %controls_out_38, %targets_out_39 = qco.ctrl(%97) targets (%arg0 = %92) {
      %105 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %105 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %98 = qco.rz(%cst_10) %targets_out_39 : !qco.qubit -> !qco.qubit
    %99 = qco.rx(%cst_13) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_9) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.rx(%cst_16) %controls_out_38 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_14) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rx(%cst_16) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_16) %103 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %104 : !qco.qubit
    cbit.store %result, %4[%c3] : !cbit.reg<4>
    %qubit_out_40, %result_41 = qco.measure %100 : !qco.qubit
    cbit.store %result_41, %4[%c2] : !cbit.reg<4>
    %qubit_out_42, %result_43 = qco.measure %83 : !qco.qubit
    cbit.store %result_43, %4[%c1] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_40 : !qco.qubit
    qco.sink %qubit_out_42 : !qco.qubit
    %qubit_out_44, %result_45 = qco.measure %51 : !qco.qubit
    qco.sink %qubit_out_44 : !qco.qubit
    cbit.store %result_45, %4[%c0] : !cbit.reg<4>
    %cst_46 = arith.constant 1.6689710972195879 : f64
    qco.gphase(%cst_46)
    return %4 : !cbit.reg<4>
  }
}
