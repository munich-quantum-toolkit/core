module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 0>, input_count = 5 : i64, sites = array<i64: 0, 1, 2, 3, 4>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<5> attributes {mqt.entry_point} {
    %cst = arith.constant 7.4273541408476067 : f64
    %cst_0 = arith.constant 2.3561944901923448 : f64
    %cst_1 = arith.constant -0.78539816339744739 : f64
    %cst_2 = arith.constant 1.5707963267948968 : f64
    %cst_3 = arith.constant 2.4805494847391065 : f64
    %cst_4 = arith.constant 7.1929384651237962 : f64
    %cst_5 = arith.constant 2.748893571891069 : f64
    %cst_6 = arith.constant -1.178097245096172 : f64
    %cst_7 = arith.constant 3.1415926535897931 : f64
    %cst_8 = arith.constant 2.9452431127404313 : f64
    %cst_9 = arith.constant -1.3744467859455352 : f64
    %cst_10 = arith.constant 2.714965160462917 : f64
    %cst_11 = arith.constant 1.1441688336680205 : f64
    %cst_12 = arith.constant 3.1415926535897949 : f64
    %cst_13 = arith.constant 3.0434178831651124 : f64
    %cst_14 = arith.constant -1.5707963267948948 : f64
    %cst_15 = arith.constant -1.4726215563702159 : f64
    %cst_16 = arith.constant 4.7123889803846897 : f64
    %cst_17 = arith.constant -1.5707963267948966 : f64
    %cst_18 = arith.constant 3.1415926535897927 : f64
    %cst_19 = arith.constant 1.5707963267948966 : f64
    %cst_20 = arith.constant 1.570796326794897 : f64
    %cst_21 = arith.constant 0.000000e+00 : f64
    %cst_22 = arith.constant 6.2831853071795862 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<5>
    %6 = qco.r(%cst_19, %cst_19) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.r(%cst_7, %cst_21) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_19, %cst_19) %2 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_7, %cst_21) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_19, %cst_19) %3 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_7, %cst_21) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_19, %cst_19) %4 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_7, %cst_21) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_22, %cst_21) %0 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_20, %cst_19) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_20, %cst_21) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_7, %cst_21) %13 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_2, %cst_19) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst_16, %cst_21) %18 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%19) targets (%arg0 = %16) {
      %85 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %85 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.r(%cst_16, %cst_21) %targets_out : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_19, %cst_19) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_16, %cst_21) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_1, %cst_21) %controls_out : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_20, %cst_19) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_2, %cst_21) %24 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%25) targets (%arg0 = %22) {
      %85 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %85 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.r(%cst_17, %cst_21) %targets_out_24 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst_0, %cst_19) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_7, %cst_21) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.r(%cst, %cst_21) %controls_out_23 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_18, %cst_19) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%cst_10, %cst_21) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_20, %cst_19) %28 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_20, %cst_21) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.r(%cst_18, %cst_21) %11 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst_20, %cst_19) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_17, %cst_21) %35 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%36) targets (%arg0 = %33) {
      %85 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %85 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.r(%cst_16, %cst_21) %targets_out_26 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst_19, %cst_19) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst_16, %cst_21) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_6, %cst_21) %controls_out_25 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst_20, %cst_19) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst_19, %cst_21) %41 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%42) targets (%arg0 = %39) {
      %85 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %85 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qco.r(%cst_16, %cst_21) %targets_out_28 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_5, %cst_19) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst_18, %cst_21) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.r(%cst_4, %cst_21) %controls_out_27 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%cst_18, %cst_19) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst_3, %cst_21) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.r(%cst_22, %cst_21) %45 : !qco.qubit -> !qco.qubit
    %50 = qco.r(%cst_20, %cst_19) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.r(%cst_20, %cst_21) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.r(%cst_18, %cst_21) %9 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst_20, %cst_19) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.r(%cst_17, %cst_21) %53 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%54) targets (%arg0 = %51) {
      %85 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %85 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.r(%cst_16, %cst_21) %targets_out_30 : !qco.qubit -> !qco.qubit
    %56 = qco.r(%cst_19, %cst_19) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.r(%cst_16, %cst_21) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.r(%cst_9, %cst_21) %controls_out_29 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%cst_20, %cst_19) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.r(%cst_19, %cst_21) %59 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%60) targets (%arg0 = %57) {
      %85 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %85 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qco.r(%cst_17, %cst_21) %targets_out_32 : !qco.qubit -> !qco.qubit
    %62 = qco.r(%cst_8, %cst_19) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%cst_7, %cst_21) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.r(%cst_11, %cst_21) %controls_out_31 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%cst_18, %cst_19) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.r(%cst_10, %cst_21) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.r(%cst_22, %cst_21) %63 : !qco.qubit -> !qco.qubit
    %68 = qco.r(%cst_20, %cst_19) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.r(%cst_20, %cst_21) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.r(%cst_18, %cst_21) %7 : !qco.qubit -> !qco.qubit
    %71 = qco.r(%cst_20, %cst_19) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%cst_17, %cst_21) %71 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%72) targets (%arg0 = %69) {
      %85 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %85 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %73 = qco.r(%cst_16, %cst_21) %targets_out_34 : !qco.qubit -> !qco.qubit
    %74 = qco.r(%cst_19, %cst_19) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.r(%cst_16, %cst_21) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.r(%cst_15, %cst_21) %controls_out_33 : !qco.qubit -> !qco.qubit
    %77 = qco.r(%cst_20, %cst_19) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst_19, %cst_21) %77 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%78) targets (%arg0 = %75) {
      %85 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %85 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %79 = qco.r(%cst_14, %cst_21) %targets_out_36 : !qco.qubit -> !qco.qubit
    %80 = qco.r(%cst_13, %cst_19) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%cst_12, %cst_21) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.r(%cst_11, %cst_21) %controls_out_35 : !qco.qubit -> !qco.qubit
    %83 = qco.r(%cst_18, %cst_19) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.r(%cst_10, %cst_21) %83 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %81 : !qco.qubit
    cbit.store %result, %5[%c0] : !cbit.reg<5>
    %qubit_out_37, %result_38 = qco.measure %84 : !qco.qubit
    cbit.store %result_38, %5[%c1] : !cbit.reg<5>
    %qubit_out_39, %result_40 = qco.measure %66 : !qco.qubit
    cbit.store %result_40, %5[%c2] : !cbit.reg<5>
    %qubit_out_41, %result_42 = qco.measure %48 : !qco.qubit
    cbit.store %result_42, %5[%c3] : !cbit.reg<5>
    qco.sink %qubit_out_37 : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    qco.sink %qubit_out_41 : !qco.qubit
    %qubit_out_43, %result_44 = qco.measure %31 : !qco.qubit
    qco.sink %qubit_out_43 : !qco.qubit
    cbit.store %result_44, %5[%c4] : !cbit.reg<5>
    qco.sink %qubit_out : !qco.qubit
    %cst_45 = arith.constant -3.141592653589786 : f64
    qco.gphase(%cst_45)
    return %5 : !cbit.reg<5>
  }
}
