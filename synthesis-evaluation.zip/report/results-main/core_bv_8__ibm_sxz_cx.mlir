module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant -3.1415926535897931 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %cst_2 = arith.constant 1.5707963267948968 : f64
    %cst_3 = arith.constant -1.5707963267948963 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %9 = qco.x %0 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_1) %1 : !qco.qubit -> !qco.qubit
    %11 = qco.sx %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_1) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_1) %3 : !qco.qubit -> !qco.qubit
    %14 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_1) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_1) %5 : !qco.qubit -> !qco.qubit
    %17 = qco.sx %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_1) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_1) %7 : !qco.qubit -> !qco.qubit
    %20 = qco.sx %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_1) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_3) %9 : !qco.qubit -> !qco.qubit
    %23 = qco.sx %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_2) %23 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%12) targets (%arg0 = %24) {
      %55 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %55 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %25 = qco.rz(%cst_1) %targets_out : !qco.qubit -> !qco.qubit
    %26 = qco.sx %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_2) %28 : !qco.qubit -> !qco.qubit
    %controls_out_4, %targets_out_5 = qco.ctrl(%15) targets (%arg0 = %29) {
      %55 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %55 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.rz(%cst_1) %targets_out_5 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.sx %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_2) %33 : !qco.qubit -> !qco.qubit
    %controls_out_6, %targets_out_7 = qco.ctrl(%18) targets (%arg0 = %34) {
      %55 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %55 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.rz(%cst_1) %targets_out_7 : !qco.qubit -> !qco.qubit
    %36 = qco.sx %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.sx %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_2) %38 : !qco.qubit -> !qco.qubit
    %controls_out_8, %targets_out_9 = qco.ctrl(%21) targets (%arg0 = %39) {
      %55 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %55 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %40 = qco.rz(%cst_1) %targets_out_9 : !qco.qubit -> !qco.qubit
    %41 = qco.sx %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_0) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_1) %controls_out : !qco.qubit -> !qco.qubit
    %44 = qco.sx %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_1) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_1) %controls_out_4 : !qco.qubit -> !qco.qubit
    %47 = qco.sx %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_1) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_1) %controls_out_6 : !qco.qubit -> !qco.qubit
    %50 = qco.sx %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_1) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_1) %controls_out_8 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_1) %53 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %45 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<7>
    %qubit_out_10, %result_11 = qco.measure %2 : !qco.qubit
    cbit.store %result_11, %8[%c1] : !cbit.reg<7>
    %qubit_out_12, %result_13 = qco.measure %48 : !qco.qubit
    cbit.store %result_13, %8[%c2] : !cbit.reg<7>
    %qubit_out_14, %result_15 = qco.measure %4 : !qco.qubit
    cbit.store %result_15, %8[%c3] : !cbit.reg<7>
    %qubit_out_16, %result_17 = qco.measure %51 : !qco.qubit
    cbit.store %result_17, %8[%c4] : !cbit.reg<7>
    %qubit_out_18, %result_19 = qco.measure %6 : !qco.qubit
    cbit.store %result_19, %8[%c5] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_10 : !qco.qubit
    qco.sink %qubit_out_12 : !qco.qubit
    qco.sink %qubit_out_14 : !qco.qubit
    qco.sink %qubit_out_16 : !qco.qubit
    qco.sink %qubit_out_18 : !qco.qubit
    %qubit_out_20, %result_21 = qco.measure %54 : !qco.qubit
    qco.sink %qubit_out_20 : !qco.qubit
    cbit.store %result_21, %8[%c6] : !cbit.reg<7>
    qco.sink %42 : !qco.qubit
    return %8 : !cbit.reg<7>
  }
}
