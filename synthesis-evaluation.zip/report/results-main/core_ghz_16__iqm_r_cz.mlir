module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<16> attributes {mqt.entry_point} {
    %cst = arith.constant 6.2831853071795862 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant 0.000000e+00 : f64
    %cst_2 = arith.constant 3.1415926535897931 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %c15 = arith.constant 15 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<16>
    %17 = qco.r(%cst_0, %cst_0) %0 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_2, %cst_1) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst_2, %cst_1) %1 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_0, %cst_0) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_2, %cst_1) %20 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%18) targets (%arg0 = %21) {
      %94 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %94 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.r(%cst_0, %cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst, %cst_1) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_2, %cst_1) %2 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_0, %cst_0) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_2, %cst_1) %25 : !qco.qubit -> !qco.qubit
    %controls_out_3, %targets_out_4 = qco.ctrl(%23) targets (%arg0 = %26) {
      %94 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %94 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %27 = qco.r(%cst_0, %cst_0) %targets_out_4 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst, %cst_1) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.r(%cst_2, %cst_1) %3 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_0, %cst_0) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%cst_2, %cst_1) %30 : !qco.qubit -> !qco.qubit
    %controls_out_5, %targets_out_6 = qco.ctrl(%28) targets (%arg0 = %31) {
      %94 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %94 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qco.r(%cst_0, %cst_0) %targets_out_6 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst, %cst_1) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.r(%cst_2, %cst_1) %4 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst_0, %cst_0) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_2, %cst_1) %35 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%33) targets (%arg0 = %36) {
      %94 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %94 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.r(%cst_0, %cst_0) %targets_out_8 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst, %cst_1) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst_2, %cst_1) %5 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_0, %cst_0) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst_2, %cst_1) %40 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%38) targets (%arg0 = %41) {
      %94 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %94 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qco.r(%cst_0, %cst_0) %targets_out_10 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%cst, %cst_1) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_2, %cst_1) %6 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst_0, %cst_0) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.r(%cst_2, %cst_1) %45 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%43) targets (%arg0 = %46) {
      %94 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %94 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.r(%cst_0, %cst_0) %targets_out_12 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst, %cst_1) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.r(%cst_2, %cst_1) %7 : !qco.qubit -> !qco.qubit
    %50 = qco.r(%cst_0, %cst_0) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.r(%cst_2, %cst_1) %50 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%48) targets (%arg0 = %51) {
      %94 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %94 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qco.r(%cst_0, %cst_0) %targets_out_14 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst, %cst_1) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.r(%cst_2, %cst_1) %8 : !qco.qubit -> !qco.qubit
    %55 = qco.r(%cst_0, %cst_0) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.r(%cst_2, %cst_1) %55 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%53) targets (%arg0 = %56) {
      %94 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %94 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %57 = qco.r(%cst_0, %cst_0) %targets_out_16 : !qco.qubit -> !qco.qubit
    %58 = qco.r(%cst, %cst_1) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%cst_2, %cst_1) %9 : !qco.qubit -> !qco.qubit
    %60 = qco.r(%cst_0, %cst_0) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.r(%cst_2, %cst_1) %60 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%58) targets (%arg0 = %61) {
      %94 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %94 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %62 = qco.r(%cst_0, %cst_0) %targets_out_18 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%cst, %cst_1) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.r(%cst_2, %cst_1) %10 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%cst_0, %cst_0) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.r(%cst_2, %cst_1) %65 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%63) targets (%arg0 = %66) {
      %94 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %94 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %67 = qco.r(%cst_0, %cst_0) %targets_out_20 : !qco.qubit -> !qco.qubit
    %68 = qco.r(%cst, %cst_1) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.r(%cst_2, %cst_1) %11 : !qco.qubit -> !qco.qubit
    %70 = qco.r(%cst_0, %cst_0) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.r(%cst_2, %cst_1) %70 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%68) targets (%arg0 = %71) {
      %94 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %94 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %72 = qco.r(%cst_0, %cst_0) %targets_out_22 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%cst, %cst_1) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.r(%cst_2, %cst_1) %12 : !qco.qubit -> !qco.qubit
    %75 = qco.r(%cst_0, %cst_0) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.r(%cst_2, %cst_1) %75 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%73) targets (%arg0 = %76) {
      %94 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %94 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %77 = qco.r(%cst_0, %cst_0) %targets_out_24 : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst, %cst_1) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.r(%cst_2, %cst_1) %13 : !qco.qubit -> !qco.qubit
    %80 = qco.r(%cst_0, %cst_0) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%cst_2, %cst_1) %80 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%78) targets (%arg0 = %81) {
      %94 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %94 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %82 = qco.r(%cst_0, %cst_0) %targets_out_26 : !qco.qubit -> !qco.qubit
    %83 = qco.r(%cst, %cst_1) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.r(%cst_2, %cst_1) %14 : !qco.qubit -> !qco.qubit
    %85 = qco.r(%cst_0, %cst_0) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.r(%cst_2, %cst_1) %85 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%83) targets (%arg0 = %86) {
      %94 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %94 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %87 = qco.r(%cst_0, %cst_0) %targets_out_28 : !qco.qubit -> !qco.qubit
    %88 = qco.r(%cst, %cst_1) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%cst_2, %cst_1) %15 : !qco.qubit -> !qco.qubit
    %90 = qco.r(%cst_0, %cst_0) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.r(%cst_2, %cst_1) %90 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%88) targets (%arg0 = %91) {
      %94 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %94 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %92 = qco.r(%cst_0, %cst_0) %targets_out_30 : !qco.qubit -> !qco.qubit
    %93 = qco.r(%cst, %cst_1) %92 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %controls_out : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<16>
    %qubit_out_31, %result_32 = qco.measure %controls_out_3 : !qco.qubit
    cbit.store %result_32, %16[%c1] : !cbit.reg<16>
    %qubit_out_33, %result_34 = qco.measure %controls_out_5 : !qco.qubit
    cbit.store %result_34, %16[%c2] : !cbit.reg<16>
    %qubit_out_35, %result_36 = qco.measure %controls_out_7 : !qco.qubit
    cbit.store %result_36, %16[%c3] : !cbit.reg<16>
    %qubit_out_37, %result_38 = qco.measure %controls_out_9 : !qco.qubit
    cbit.store %result_38, %16[%c4] : !cbit.reg<16>
    %qubit_out_39, %result_40 = qco.measure %controls_out_11 : !qco.qubit
    cbit.store %result_40, %16[%c5] : !cbit.reg<16>
    %qubit_out_41, %result_42 = qco.measure %controls_out_13 : !qco.qubit
    cbit.store %result_42, %16[%c6] : !cbit.reg<16>
    %qubit_out_43, %result_44 = qco.measure %controls_out_15 : !qco.qubit
    cbit.store %result_44, %16[%c7] : !cbit.reg<16>
    %qubit_out_45, %result_46 = qco.measure %controls_out_17 : !qco.qubit
    cbit.store %result_46, %16[%c8] : !cbit.reg<16>
    %qubit_out_47, %result_48 = qco.measure %controls_out_19 : !qco.qubit
    cbit.store %result_48, %16[%c9] : !cbit.reg<16>
    %qubit_out_49, %result_50 = qco.measure %controls_out_21 : !qco.qubit
    cbit.store %result_50, %16[%c10] : !cbit.reg<16>
    %qubit_out_51, %result_52 = qco.measure %controls_out_23 : !qco.qubit
    cbit.store %result_52, %16[%c11] : !cbit.reg<16>
    %qubit_out_53, %result_54 = qco.measure %controls_out_25 : !qco.qubit
    cbit.store %result_54, %16[%c12] : !cbit.reg<16>
    %qubit_out_55, %result_56 = qco.measure %controls_out_27 : !qco.qubit
    cbit.store %result_56, %16[%c13] : !cbit.reg<16>
    %qubit_out_57, %result_58 = qco.measure %controls_out_29 : !qco.qubit
    cbit.store %result_58, %16[%c14] : !cbit.reg<16>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_31 : !qco.qubit
    qco.sink %qubit_out_33 : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    qco.sink %qubit_out_37 : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    qco.sink %qubit_out_41 : !qco.qubit
    qco.sink %qubit_out_43 : !qco.qubit
    qco.sink %qubit_out_45 : !qco.qubit
    qco.sink %qubit_out_47 : !qco.qubit
    qco.sink %qubit_out_49 : !qco.qubit
    qco.sink %qubit_out_51 : !qco.qubit
    qco.sink %qubit_out_53 : !qco.qubit
    qco.sink %qubit_out_55 : !qco.qubit
    qco.sink %qubit_out_57 : !qco.qubit
    %qubit_out_59, %result_60 = qco.measure %93 : !qco.qubit
    qco.sink %qubit_out_59 : !qco.qubit
    cbit.store %result_60, %16[%c15] : !cbit.reg<16>
    qco.gphase(%cst_0)
    return %16 : !cbit.reg<16>
  }
}
