module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 7, 0>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant 7.8417097876713981 : f64
    %cst_0 = arith.constant 1.5462526341887264 : f64
    %cst_1 = arith.constant 3.0925052683774528 : f64
    %cst_2 = arith.constant 7.8294379413683126 : f64
    %cst_3 = arith.constant -7.9521564043991635 : f64
    %cst_4 = arith.constant 6.1850105367549055 : f64
    %cst_5 = arith.constant -1.6689710972195777 : f64
    %cst_6 = arith.constant 8.8629555813438934 : f64
    %cst_7 = arith.constant 7.7558068635498021 : f64
    %cst_8 = arith.constant 1.3744467859455352 : f64
    %cst_9 = arith.constant 2.7488935718910694 : f64
    %cst_10 = arith.constant 7.6576320931251214 : f64
    %cst_11 = arith.constant 2.7488935718910685 : f64
    %cst_12 = arith.constant 2.3561944901923448 : f64
    %cst_13 = arith.constant 9.0320788790706548 : f64
    %cst_14 = arith.constant -5.497787143782138 : f64
    %cst_15 = arith.constant -0.39269908169872458 : f64
    %cst_16 = arith.constant -0.98174770424681057 : f64
    %cst_17 = arith.constant 4.7123889803846897 : f64
    %cst_18 = arith.constant -0.5890486225480861 : f64
    %cst_19 = arith.constant 4.3196898986859651 : f64
    %cst_20 = arith.constant 1.5707963267948966 : f64
    %cst_21 = arith.constant 5.4268386164800555 : f64
    %cst_22 = arith.constant 3.0706441262877116 : f64
    %cst_23 = arith.constant 3.9269908169872423 : f64
    %cst_24 = arith.constant -0.78539816339744828 : f64
    %cst_25 = arith.constant -1.1780972450961724 : f64
    %cst_26 = arith.constant 3.9269908169872405 : f64
    %cst_27 = arith.constant -0.39269908169872392 : f64
    %cst_28 = arith.constant -3.1415926535897931 : f64
    %cst_29 = arith.constant -2.9452431127404313 : f64
    %cst_30 = arith.constant 3.5342917352885177 : f64
    %cst_31 = arith.constant -0.19634954084936185 : f64
    %cst_32 = arith.constant -3.0434178831651124 : f64
    %cst_33 = arith.constant 3.3379421944391545 : f64
    %cst_34 = arith.constant 3.043417883165112 : f64
    %cst_35 = arith.constant 3.2397674240144738 : f64
    %cst_36 = arith.constant -1.5707963267948966 : f64
    %cst_37 = arith.constant 4.2487413713838835 : f64
    %cst_38 = arith.constant -0.049087385212340573 : f64
    %cst_39 = arith.constant -3.1170489609836229 : f64
    %cst_40 = arith.constant 3.1906800388021339 : f64
    %cst_41 = arith.constant -0.024543692606170175 : f64
    %cst_42 = arith.constant -3.1415926535897927 : f64
    %cst_43 = arith.constant -3.129320807286708 : f64
    %cst_44 = arith.constant 3.1661363461959646 : f64
    %cst_45 = arith.constant 3.9269908169872414 : f64
    %cst_46 = arith.constant 5.497787143782138 : f64
    %cst_47 = arith.constant 1.5707963267948961 : f64
    %cst_48 = arith.constant 3.1415926535897931 : f64
    %cst_49 = arith.constant -4.7123889803846897 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %9 = qco.rz(%cst_20) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_28) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_20) %3 : !qco.qubit -> !qco.qubit
    %13 = qco.sx %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_28) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_20) %4 : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_28) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_20) %5 : !qco.qubit -> !qco.qubit
    %19 = qco.sx %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_20) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_20) %6 : !qco.qubit -> !qco.qubit
    %22 = qco.sx %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_17) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_20) %7 : !qco.qubit -> !qco.qubit
    %25 = qco.sx %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_20) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.x %0 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_20) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.sx %26 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_36) %29 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%30) targets (%arg0 = %28) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.rz(%cst_46) %targets_out : !qco.qubit -> !qco.qubit
    %32 = qco.x %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_45) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_49) %controls_out : !qco.qubit -> !qco.qubit
    %35 = qco.sx %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_19) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.sx %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_48) %37 : !qco.qubit -> !qco.qubit
    %controls_out_50, %targets_out_51 = qco.ctrl(%38) targets (%arg0 = %33) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.rz(%cst_18) %targets_out_51 : !qco.qubit -> !qco.qubit
    %40 = qco.x %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_16) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.sx %controls_out_50 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_15) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_47) %44 : !qco.qubit -> !qco.qubit
    %controls_out_52, %targets_out_53 = qco.ctrl(%45) targets (%arg0 = %41) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qco.rz(%cst_46) %targets_out_53 : !qco.qubit -> !qco.qubit
    %47 = qco.x %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_45) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_49) %controls_out_52 : !qco.qubit -> !qco.qubit
    %50 = qco.sx %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_23) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.sx %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_48) %52 : !qco.qubit -> !qco.qubit
    %controls_out_54, %targets_out_55 = qco.ctrl(%53) targets (%arg0 = %48) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %54 = qco.rz(%cst_22) %targets_out_55 : !qco.qubit -> !qco.qubit
    %55 = qco.x %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_21) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_42) %controls_out_54 : !qco.qubit -> !qco.qubit
    %58 = qco.sx %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_14) %58 : !qco.qubit -> !qco.qubit
    %controls_out_56, %targets_out_57 = qco.ctrl(%20) targets (%arg0 = %56) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qco.rz(%cst_48) %1 : !qco.qubit -> !qco.qubit
    %61 = qco.sx %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_47) %61 : !qco.qubit -> !qco.qubit
    %controls_out_58, %targets_out_59 = qco.ctrl(%62) targets (%arg0 = %11) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %63 = qco.rz(%cst_46) %targets_out_59 : !qco.qubit -> !qco.qubit
    %64 = qco.x %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_45) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_49) %controls_out_58 : !qco.qubit -> !qco.qubit
    %67 = qco.sx %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_26) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.sx %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_48) %69 : !qco.qubit -> !qco.qubit
    %controls_out_60, %targets_out_61 = qco.ctrl(%70) targets (%arg0 = %65) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qco.rz(%cst_25) %targets_out_61 : !qco.qubit -> !qco.qubit
    %72 = qco.x %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_13) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_42) %controls_out_60 : !qco.qubit -> !qco.qubit
    %75 = qco.sx %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_12) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.sx %73 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_17) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.sx %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_47) %79 : !qco.qubit -> !qco.qubit
    %controls_out_62, %targets_out_63 = qco.ctrl(%80) targets (%arg0 = %14) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %81 = qco.rz(%cst_46) %targets_out_63 : !qco.qubit -> !qco.qubit
    %82 = qco.x %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_45) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_49) %controls_out_62 : !qco.qubit -> !qco.qubit
    %85 = qco.sx %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_26) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.sx %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_48) %87 : !qco.qubit -> !qco.qubit
    %controls_out_64, %targets_out_65 = qco.ctrl(%88) targets (%arg0 = %83) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %89 = qco.rz(%cst_25) %targets_out_65 : !qco.qubit -> !qco.qubit
    %90 = qco.x %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_11) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_42) %controls_out_64 : !qco.qubit -> !qco.qubit
    %93 = qco.sx %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_12) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.sx %76 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_47) %95 : !qco.qubit -> !qco.qubit
    %controls_out_66, %targets_out_67 = qco.ctrl(%96) targets (%arg0 = %91) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %97 = qco.rz(%cst_46) %targets_out_67 : !qco.qubit -> !qco.qubit
    %98 = qco.x %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_45) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_49) %controls_out_66 : !qco.qubit -> !qco.qubit
    %101 = qco.sx %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_30) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.sx %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_48) %103 : !qco.qubit -> !qco.qubit
    %controls_out_68, %targets_out_69 = qco.ctrl(%104) targets (%arg0 = %99) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %105 = qco.rz(%cst_29) %targets_out_69 : !qco.qubit -> !qco.qubit
    %106 = qco.x %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rz(%cst_10) %106 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_28) %controls_out_68 : !qco.qubit -> !qco.qubit
    %109 = qco.sx %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst_9) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.sx %107 : !qco.qubit -> !qco.qubit
    %112 = qco.rz(%cst_17) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.sx %112 : !qco.qubit -> !qco.qubit
    %114 = qco.rz(%cst_47) %113 : !qco.qubit -> !qco.qubit
    %controls_out_70, %targets_out_71 = qco.ctrl(%114) targets (%arg0 = %17) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %115 = qco.rz(%cst_46) %targets_out_71 : !qco.qubit -> !qco.qubit
    %116 = qco.x %115 : !qco.qubit -> !qco.qubit
    %117 = qco.rz(%cst_45) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_49) %controls_out_70 : !qco.qubit -> !qco.qubit
    %119 = qco.sx %118 : !qco.qubit -> !qco.qubit
    %120 = qco.rz(%cst_26) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.sx %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rz(%cst_48) %121 : !qco.qubit -> !qco.qubit
    %controls_out_72, %targets_out_73 = qco.ctrl(%122) targets (%arg0 = %117) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %123 = qco.rz(%cst_25) %targets_out_73 : !qco.qubit -> !qco.qubit
    %124 = qco.x %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rz(%cst_11) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst_42) %controls_out_72 : !qco.qubit -> !qco.qubit
    %127 = qco.sx %126 : !qco.qubit -> !qco.qubit
    %128 = qco.rz(%cst_12) %127 : !qco.qubit -> !qco.qubit
    %129 = qco.sx %94 : !qco.qubit -> !qco.qubit
    %130 = qco.rz(%cst_47) %129 : !qco.qubit -> !qco.qubit
    %controls_out_74, %targets_out_75 = qco.ctrl(%130) targets (%arg0 = %125) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %131 = qco.rz(%cst_46) %targets_out_75 : !qco.qubit -> !qco.qubit
    %132 = qco.x %131 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst_45) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.rz(%cst_49) %controls_out_74 : !qco.qubit -> !qco.qubit
    %135 = qco.sx %134 : !qco.qubit -> !qco.qubit
    %136 = qco.rz(%cst_30) %135 : !qco.qubit -> !qco.qubit
    %137 = qco.sx %136 : !qco.qubit -> !qco.qubit
    %138 = qco.rz(%cst_48) %137 : !qco.qubit -> !qco.qubit
    %controls_out_76, %targets_out_77 = qco.ctrl(%138) targets (%arg0 = %133) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %139 = qco.rz(%cst_29) %targets_out_77 : !qco.qubit -> !qco.qubit
    %140 = qco.x %139 : !qco.qubit -> !qco.qubit
    %141 = qco.rz(%cst_8) %140 : !qco.qubit -> !qco.qubit
    %142 = qco.rz(%cst_28) %controls_out_76 : !qco.qubit -> !qco.qubit
    %143 = qco.sx %142 : !qco.qubit -> !qco.qubit
    %144 = qco.rz(%cst_9) %143 : !qco.qubit -> !qco.qubit
    %145 = qco.sx %110 : !qco.qubit -> !qco.qubit
    %146 = qco.rz(%cst_47) %145 : !qco.qubit -> !qco.qubit
    %controls_out_78, %targets_out_79 = qco.ctrl(%146) targets (%arg0 = %141) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %147 = qco.rz(%cst_46) %targets_out_79 : !qco.qubit -> !qco.qubit
    %148 = qco.x %147 : !qco.qubit -> !qco.qubit
    %149 = qco.rz(%cst_45) %148 : !qco.qubit -> !qco.qubit
    %150 = qco.rz(%cst_49) %controls_out_78 : !qco.qubit -> !qco.qubit
    %151 = qco.sx %150 : !qco.qubit -> !qco.qubit
    %152 = qco.rz(%cst_33) %151 : !qco.qubit -> !qco.qubit
    %153 = qco.sx %152 : !qco.qubit -> !qco.qubit
    %154 = qco.rz(%cst_48) %153 : !qco.qubit -> !qco.qubit
    %controls_out_80, %targets_out_81 = qco.ctrl(%154) targets (%arg0 = %149) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %155 = qco.rz(%cst_32) %targets_out_81 : !qco.qubit -> !qco.qubit
    %156 = qco.x %155 : !qco.qubit -> !qco.qubit
    %157 = qco.rz(%cst_7) %156 : !qco.qubit -> !qco.qubit
    %158 = qco.rz(%cst_42) %controls_out_80 : !qco.qubit -> !qco.qubit
    %159 = qco.sx %158 : !qco.qubit -> !qco.qubit
    %160 = qco.rz(%cst_31) %159 : !qco.qubit -> !qco.qubit
    %161 = qco.sx %157 : !qco.qubit -> !qco.qubit
    %162 = qco.rz(%cst_17) %161 : !qco.qubit -> !qco.qubit
    %163 = qco.rz(%cst_49) %controls_out_56 : !qco.qubit -> !qco.qubit
    %164 = qco.sx %162 : !qco.qubit -> !qco.qubit
    %165 = qco.rz(%cst_47) %164 : !qco.qubit -> !qco.qubit
    %controls_out_82, %targets_out_83 = qco.ctrl(%165) targets (%arg0 = %163) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %166 = qco.rz(%cst_46) %targets_out_83 : !qco.qubit -> !qco.qubit
    %167 = qco.x %166 : !qco.qubit -> !qco.qubit
    %168 = qco.rz(%cst_45) %167 : !qco.qubit -> !qco.qubit
    %169 = qco.rz(%cst_49) %controls_out_82 : !qco.qubit -> !qco.qubit
    %170 = qco.sx %169 : !qco.qubit -> !qco.qubit
    %171 = qco.rz(%cst_26) %170 : !qco.qubit -> !qco.qubit
    %172 = qco.sx %171 : !qco.qubit -> !qco.qubit
    %173 = qco.rz(%cst_48) %172 : !qco.qubit -> !qco.qubit
    %controls_out_84, %targets_out_85 = qco.ctrl(%173) targets (%arg0 = %168) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %174 = qco.rz(%cst_25) %targets_out_85 : !qco.qubit -> !qco.qubit
    %175 = qco.x %174 : !qco.qubit -> !qco.qubit
    %176 = qco.rz(%cst_11) %175 : !qco.qubit -> !qco.qubit
    %177 = qco.rz(%cst_42) %controls_out_84 : !qco.qubit -> !qco.qubit
    %178 = qco.sx %177 : !qco.qubit -> !qco.qubit
    %179 = qco.rz(%cst_12) %178 : !qco.qubit -> !qco.qubit
    %180 = qco.sx %128 : !qco.qubit -> !qco.qubit
    %181 = qco.rz(%cst_47) %180 : !qco.qubit -> !qco.qubit
    %controls_out_86, %targets_out_87 = qco.ctrl(%181) targets (%arg0 = %176) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %182 = qco.rz(%cst_46) %targets_out_87 : !qco.qubit -> !qco.qubit
    %183 = qco.x %182 : !qco.qubit -> !qco.qubit
    %184 = qco.rz(%cst_45) %183 : !qco.qubit -> !qco.qubit
    %185 = qco.rz(%cst_49) %controls_out_86 : !qco.qubit -> !qco.qubit
    %186 = qco.sx %185 : !qco.qubit -> !qco.qubit
    %187 = qco.rz(%cst_30) %186 : !qco.qubit -> !qco.qubit
    %188 = qco.sx %187 : !qco.qubit -> !qco.qubit
    %189 = qco.rz(%cst_48) %188 : !qco.qubit -> !qco.qubit
    %controls_out_88, %targets_out_89 = qco.ctrl(%189) targets (%arg0 = %184) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %190 = qco.rz(%cst_29) %targets_out_89 : !qco.qubit -> !qco.qubit
    %191 = qco.x %190 : !qco.qubit -> !qco.qubit
    %192 = qco.rz(%cst_8) %191 : !qco.qubit -> !qco.qubit
    %193 = qco.rz(%cst_28) %controls_out_88 : !qco.qubit -> !qco.qubit
    %194 = qco.sx %193 : !qco.qubit -> !qco.qubit
    %195 = qco.rz(%cst_9) %194 : !qco.qubit -> !qco.qubit
    %196 = qco.sx %144 : !qco.qubit -> !qco.qubit
    %197 = qco.rz(%cst_47) %196 : !qco.qubit -> !qco.qubit
    %controls_out_90, %targets_out_91 = qco.ctrl(%197) targets (%arg0 = %192) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %198 = qco.rz(%cst_46) %targets_out_91 : !qco.qubit -> !qco.qubit
    %199 = qco.x %198 : !qco.qubit -> !qco.qubit
    %200 = qco.rz(%cst_45) %199 : !qco.qubit -> !qco.qubit
    %201 = qco.rz(%cst_49) %controls_out_90 : !qco.qubit -> !qco.qubit
    %202 = qco.sx %201 : !qco.qubit -> !qco.qubit
    %203 = qco.rz(%cst_33) %202 : !qco.qubit -> !qco.qubit
    %204 = qco.sx %203 : !qco.qubit -> !qco.qubit
    %205 = qco.rz(%cst_48) %204 : !qco.qubit -> !qco.qubit
    %controls_out_92, %targets_out_93 = qco.ctrl(%205) targets (%arg0 = %200) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %206 = qco.rz(%cst_32) %targets_out_93 : !qco.qubit -> !qco.qubit
    %207 = qco.x %206 : !qco.qubit -> !qco.qubit
    %208 = qco.rz(%cst_6) %207 : !qco.qubit -> !qco.qubit
    %209 = qco.rz(%cst_42) %controls_out_92 : !qco.qubit -> !qco.qubit
    %210 = qco.sx %209 : !qco.qubit -> !qco.qubit
    %211 = qco.rz(%cst_31) %210 : !qco.qubit -> !qco.qubit
    %212 = qco.x %208 : !qco.qubit -> !qco.qubit
    %213 = qco.rz(%cst_37) %212 : !qco.qubit -> !qco.qubit
    %214 = qco.sx %160 : !qco.qubit -> !qco.qubit
    %215 = qco.rz(%cst_36) %214 : !qco.qubit -> !qco.qubit
    %controls_out_94, %targets_out_95 = qco.ctrl(%215) targets (%arg0 = %213) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %216 = qco.rz(%cst_46) %targets_out_95 : !qco.qubit -> !qco.qubit
    %217 = qco.x %216 : !qco.qubit -> !qco.qubit
    %218 = qco.rz(%cst_45) %217 : !qco.qubit -> !qco.qubit
    %219 = qco.rz(%cst_49) %controls_out_94 : !qco.qubit -> !qco.qubit
    %220 = qco.sx %219 : !qco.qubit -> !qco.qubit
    %221 = qco.rz(%cst_35) %220 : !qco.qubit -> !qco.qubit
    %222 = qco.sx %221 : !qco.qubit -> !qco.qubit
    %223 = qco.rz(%cst_48) %222 : !qco.qubit -> !qco.qubit
    %controls_out_96, %targets_out_97 = qco.ctrl(%223) targets (%arg0 = %218) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %224 = qco.rz(%cst_5) %targets_out_97 : !qco.qubit -> !qco.qubit
    %225 = qco.sx %controls_out_96 : !qco.qubit -> !qco.qubit
    %226 = qco.rz(%cst_4) %225 : !qco.qubit -> !qco.qubit
    %227 = qco.sx %224 : !qco.qubit -> !qco.qubit
    %228 = qco.rz(%cst_17) %227 : !qco.qubit -> !qco.qubit
    %229 = qco.sx %228 : !qco.qubit -> !qco.qubit
    %230 = qco.rz(%cst_47) %229 : !qco.qubit -> !qco.qubit
    %controls_out_98, %targets_out_99 = qco.ctrl(%230) targets (%arg0 = %59) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %231 = qco.rz(%cst_46) %targets_out_99 : !qco.qubit -> !qco.qubit
    %232 = qco.x %231 : !qco.qubit -> !qco.qubit
    %233 = qco.rz(%cst_45) %232 : !qco.qubit -> !qco.qubit
    %234 = qco.rz(%cst_49) %controls_out_98 : !qco.qubit -> !qco.qubit
    %235 = qco.sx %234 : !qco.qubit -> !qco.qubit
    %236 = qco.rz(%cst_26) %235 : !qco.qubit -> !qco.qubit
    %237 = qco.sx %236 : !qco.qubit -> !qco.qubit
    %238 = qco.rz(%cst_48) %237 : !qco.qubit -> !qco.qubit
    %controls_out_100, %targets_out_101 = qco.ctrl(%238) targets (%arg0 = %233) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %239 = qco.rz(%cst_25) %targets_out_101 : !qco.qubit -> !qco.qubit
    %240 = qco.x %239 : !qco.qubit -> !qco.qubit
    %241 = qco.rz(%cst_11) %240 : !qco.qubit -> !qco.qubit
    %242 = qco.rz(%cst_42) %controls_out_100 : !qco.qubit -> !qco.qubit
    %243 = qco.sx %242 : !qco.qubit -> !qco.qubit
    %244 = qco.rz(%cst_12) %243 : !qco.qubit -> !qco.qubit
    %245 = qco.sx %179 : !qco.qubit -> !qco.qubit
    %246 = qco.rz(%cst_47) %245 : !qco.qubit -> !qco.qubit
    %controls_out_102, %targets_out_103 = qco.ctrl(%246) targets (%arg0 = %241) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %247 = qco.rz(%cst_46) %targets_out_103 : !qco.qubit -> !qco.qubit
    %248 = qco.x %247 : !qco.qubit -> !qco.qubit
    %249 = qco.rz(%cst_45) %248 : !qco.qubit -> !qco.qubit
    %250 = qco.rz(%cst_49) %controls_out_102 : !qco.qubit -> !qco.qubit
    %251 = qco.sx %250 : !qco.qubit -> !qco.qubit
    %252 = qco.rz(%cst_30) %251 : !qco.qubit -> !qco.qubit
    %253 = qco.sx %252 : !qco.qubit -> !qco.qubit
    %254 = qco.rz(%cst_48) %253 : !qco.qubit -> !qco.qubit
    %controls_out_104, %targets_out_105 = qco.ctrl(%254) targets (%arg0 = %249) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %255 = qco.rz(%cst_29) %targets_out_105 : !qco.qubit -> !qco.qubit
    %256 = qco.x %255 : !qco.qubit -> !qco.qubit
    %257 = qco.rz(%cst_8) %256 : !qco.qubit -> !qco.qubit
    %258 = qco.rz(%cst_28) %controls_out_104 : !qco.qubit -> !qco.qubit
    %259 = qco.sx %258 : !qco.qubit -> !qco.qubit
    %260 = qco.rz(%cst_9) %259 : !qco.qubit -> !qco.qubit
    %261 = qco.sx %195 : !qco.qubit -> !qco.qubit
    %262 = qco.rz(%cst_47) %261 : !qco.qubit -> !qco.qubit
    %controls_out_106, %targets_out_107 = qco.ctrl(%262) targets (%arg0 = %257) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %263 = qco.rz(%cst_46) %targets_out_107 : !qco.qubit -> !qco.qubit
    %264 = qco.x %263 : !qco.qubit -> !qco.qubit
    %265 = qco.rz(%cst_45) %264 : !qco.qubit -> !qco.qubit
    %266 = qco.rz(%cst_49) %controls_out_106 : !qco.qubit -> !qco.qubit
    %267 = qco.sx %266 : !qco.qubit -> !qco.qubit
    %268 = qco.rz(%cst_33) %267 : !qco.qubit -> !qco.qubit
    %269 = qco.sx %268 : !qco.qubit -> !qco.qubit
    %270 = qco.rz(%cst_48) %269 : !qco.qubit -> !qco.qubit
    %controls_out_108, %targets_out_109 = qco.ctrl(%270) targets (%arg0 = %265) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %271 = qco.rz(%cst_32) %targets_out_109 : !qco.qubit -> !qco.qubit
    %272 = qco.x %271 : !qco.qubit -> !qco.qubit
    %273 = qco.rz(%cst_6) %272 : !qco.qubit -> !qco.qubit
    %274 = qco.rz(%cst_42) %controls_out_108 : !qco.qubit -> !qco.qubit
    %275 = qco.sx %274 : !qco.qubit -> !qco.qubit
    %276 = qco.rz(%cst_31) %275 : !qco.qubit -> !qco.qubit
    %277 = qco.x %273 : !qco.qubit -> !qco.qubit
    %278 = qco.rz(%cst_37) %277 : !qco.qubit -> !qco.qubit
    %279 = qco.sx %211 : !qco.qubit -> !qco.qubit
    %280 = qco.rz(%cst_36) %279 : !qco.qubit -> !qco.qubit
    %controls_out_110, %targets_out_111 = qco.ctrl(%280) targets (%arg0 = %278) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %281 = qco.rz(%cst_46) %targets_out_111 : !qco.qubit -> !qco.qubit
    %282 = qco.x %281 : !qco.qubit -> !qco.qubit
    %283 = qco.rz(%cst_45) %282 : !qco.qubit -> !qco.qubit
    %284 = qco.rz(%cst_49) %controls_out_110 : !qco.qubit -> !qco.qubit
    %285 = qco.sx %284 : !qco.qubit -> !qco.qubit
    %286 = qco.rz(%cst_35) %285 : !qco.qubit -> !qco.qubit
    %287 = qco.sx %286 : !qco.qubit -> !qco.qubit
    %288 = qco.rz(%cst_48) %287 : !qco.qubit -> !qco.qubit
    %controls_out_112, %targets_out_113 = qco.ctrl(%288) targets (%arg0 = %283) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %289 = qco.rz(%cst_3) %targets_out_113 : !qco.qubit -> !qco.qubit
    %290 = qco.sx %controls_out_112 : !qco.qubit -> !qco.qubit
    %291 = qco.rz(%cst_4) %290 : !qco.qubit -> !qco.qubit
    %292 = qco.sx %226 : !qco.qubit -> !qco.qubit
    %293 = qco.rz(%cst_47) %292 : !qco.qubit -> !qco.qubit
    %controls_out_114, %targets_out_115 = qco.ctrl(%293) targets (%arg0 = %289) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %294 = qco.rz(%cst_46) %targets_out_115 : !qco.qubit -> !qco.qubit
    %295 = qco.x %294 : !qco.qubit -> !qco.qubit
    %296 = qco.rz(%cst_45) %295 : !qco.qubit -> !qco.qubit
    %297 = qco.rz(%cst_49) %controls_out_114 : !qco.qubit -> !qco.qubit
    %298 = qco.sx %297 : !qco.qubit -> !qco.qubit
    %299 = qco.rz(%cst_40) %298 : !qco.qubit -> !qco.qubit
    %300 = qco.sx %299 : !qco.qubit -> !qco.qubit
    %301 = qco.rz(%cst_48) %300 : !qco.qubit -> !qco.qubit
    %controls_out_116, %targets_out_117 = qco.ctrl(%301) targets (%arg0 = %296) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %302 = qco.rz(%cst_39) %targets_out_117 : !qco.qubit -> !qco.qubit
    %303 = qco.x %302 : !qco.qubit -> !qco.qubit
    %304 = qco.rz(%cst_2) %303 : !qco.qubit -> !qco.qubit
    %305 = qco.rz(%cst_42) %controls_out_116 : !qco.qubit -> !qco.qubit
    %306 = qco.sx %305 : !qco.qubit -> !qco.qubit
    %307 = qco.rz(%cst_1) %306 : !qco.qubit -> !qco.qubit
    %308 = qco.sx %304 : !qco.qubit -> !qco.qubit
    %309 = qco.rz(%cst_17) %308 : !qco.qubit -> !qco.qubit
    %310 = qco.sx %309 : !qco.qubit -> !qco.qubit
    %311 = qco.rz(%cst_47) %310 : !qco.qubit -> !qco.qubit
    %controls_out_118, %targets_out_119 = qco.ctrl(%311) targets (%arg0 = %43) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %312 = qco.rz(%cst_46) %targets_out_119 : !qco.qubit -> !qco.qubit
    %313 = qco.x %312 : !qco.qubit -> !qco.qubit
    %314 = qco.rz(%cst_45) %313 : !qco.qubit -> !qco.qubit
    %315 = qco.rz(%cst_49) %controls_out_118 : !qco.qubit -> !qco.qubit
    %316 = qco.sx %315 : !qco.qubit -> !qco.qubit
    %317 = qco.rz(%cst_26) %316 : !qco.qubit -> !qco.qubit
    %318 = qco.sx %317 : !qco.qubit -> !qco.qubit
    %319 = qco.rz(%cst_48) %318 : !qco.qubit -> !qco.qubit
    %controls_out_120, %targets_out_121 = qco.ctrl(%319) targets (%arg0 = %314) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %320 = qco.rz(%cst_25) %targets_out_121 : !qco.qubit -> !qco.qubit
    %321 = qco.x %320 : !qco.qubit -> !qco.qubit
    %322 = qco.rz(%cst_11) %321 : !qco.qubit -> !qco.qubit
    %323 = qco.rz(%cst_42) %controls_out_120 : !qco.qubit -> !qco.qubit
    %324 = qco.sx %323 : !qco.qubit -> !qco.qubit
    %325 = qco.rz(%cst_24) %324 : !qco.qubit -> !qco.qubit
    %326 = qco.sx %244 : !qco.qubit -> !qco.qubit
    %327 = qco.rz(%cst_47) %326 : !qco.qubit -> !qco.qubit
    %controls_out_122, %targets_out_123 = qco.ctrl(%327) targets (%arg0 = %322) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %328 = qco.rz(%cst_46) %targets_out_123 : !qco.qubit -> !qco.qubit
    %329 = qco.x %328 : !qco.qubit -> !qco.qubit
    %330 = qco.rz(%cst_45) %329 : !qco.qubit -> !qco.qubit
    %331 = qco.rz(%cst_49) %controls_out_122 : !qco.qubit -> !qco.qubit
    %332 = qco.sx %331 : !qco.qubit -> !qco.qubit
    %333 = qco.rz(%cst_30) %332 : !qco.qubit -> !qco.qubit
    %334 = qco.sx %333 : !qco.qubit -> !qco.qubit
    %335 = qco.rz(%cst_48) %334 : !qco.qubit -> !qco.qubit
    %controls_out_124, %targets_out_125 = qco.ctrl(%335) targets (%arg0 = %330) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %336 = qco.rz(%cst_29) %targets_out_125 : !qco.qubit -> !qco.qubit
    %337 = qco.x %336 : !qco.qubit -> !qco.qubit
    %338 = qco.rz(%cst_8) %337 : !qco.qubit -> !qco.qubit
    %339 = qco.rz(%cst_28) %controls_out_124 : !qco.qubit -> !qco.qubit
    %340 = qco.sx %339 : !qco.qubit -> !qco.qubit
    %341 = qco.rz(%cst_27) %340 : !qco.qubit -> !qco.qubit
    %342 = qco.sx %260 : !qco.qubit -> !qco.qubit
    %343 = qco.rz(%cst_47) %342 : !qco.qubit -> !qco.qubit
    %controls_out_126, %targets_out_127 = qco.ctrl(%343) targets (%arg0 = %338) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %344 = qco.rz(%cst_46) %targets_out_127 : !qco.qubit -> !qco.qubit
    %345 = qco.x %344 : !qco.qubit -> !qco.qubit
    %346 = qco.rz(%cst_45) %345 : !qco.qubit -> !qco.qubit
    %347 = qco.rz(%cst_49) %controls_out_126 : !qco.qubit -> !qco.qubit
    %348 = qco.sx %347 : !qco.qubit -> !qco.qubit
    %349 = qco.rz(%cst_33) %348 : !qco.qubit -> !qco.qubit
    %350 = qco.sx %349 : !qco.qubit -> !qco.qubit
    %351 = qco.rz(%cst_48) %350 : !qco.qubit -> !qco.qubit
    %controls_out_128, %targets_out_129 = qco.ctrl(%351) targets (%arg0 = %346) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %352 = qco.rz(%cst_32) %targets_out_129 : !qco.qubit -> !qco.qubit
    %353 = qco.x %352 : !qco.qubit -> !qco.qubit
    %354 = qco.rz(%cst_6) %353 : !qco.qubit -> !qco.qubit
    %355 = qco.rz(%cst_42) %controls_out_128 : !qco.qubit -> !qco.qubit
    %356 = qco.sx %355 : !qco.qubit -> !qco.qubit
    %357 = qco.rz(%cst_31) %356 : !qco.qubit -> !qco.qubit
    %358 = qco.x %354 : !qco.qubit -> !qco.qubit
    %359 = qco.rz(%cst_37) %358 : !qco.qubit -> !qco.qubit
    %360 = qco.sx %276 : !qco.qubit -> !qco.qubit
    %361 = qco.rz(%cst_36) %360 : !qco.qubit -> !qco.qubit
    %controls_out_130, %targets_out_131 = qco.ctrl(%361) targets (%arg0 = %359) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %362 = qco.rz(%cst_46) %targets_out_131 : !qco.qubit -> !qco.qubit
    %363 = qco.x %362 : !qco.qubit -> !qco.qubit
    %364 = qco.rz(%cst_45) %363 : !qco.qubit -> !qco.qubit
    %365 = qco.rz(%cst_49) %controls_out_130 : !qco.qubit -> !qco.qubit
    %366 = qco.sx %365 : !qco.qubit -> !qco.qubit
    %367 = qco.rz(%cst_35) %366 : !qco.qubit -> !qco.qubit
    %368 = qco.sx %367 : !qco.qubit -> !qco.qubit
    %369 = qco.rz(%cst_48) %368 : !qco.qubit -> !qco.qubit
    %controls_out_132, %targets_out_133 = qco.ctrl(%369) targets (%arg0 = %364) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %370 = qco.rz(%cst_3) %targets_out_133 : !qco.qubit -> !qco.qubit
    %371 = qco.sx %controls_out_132 : !qco.qubit -> !qco.qubit
    %372 = qco.rz(%cst_34) %371 : !qco.qubit -> !qco.qubit
    %373 = qco.sx %291 : !qco.qubit -> !qco.qubit
    %374 = qco.rz(%cst_47) %373 : !qco.qubit -> !qco.qubit
    %controls_out_134, %targets_out_135 = qco.ctrl(%374) targets (%arg0 = %370) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %375 = qco.rz(%cst_46) %targets_out_135 : !qco.qubit -> !qco.qubit
    %376 = qco.x %375 : !qco.qubit -> !qco.qubit
    %377 = qco.rz(%cst_45) %376 : !qco.qubit -> !qco.qubit
    %378 = qco.rz(%cst_49) %controls_out_134 : !qco.qubit -> !qco.qubit
    %379 = qco.sx %378 : !qco.qubit -> !qco.qubit
    %380 = qco.rz(%cst_40) %379 : !qco.qubit -> !qco.qubit
    %381 = qco.sx %380 : !qco.qubit -> !qco.qubit
    %382 = qco.rz(%cst_48) %381 : !qco.qubit -> !qco.qubit
    %controls_out_136, %targets_out_137 = qco.ctrl(%382) targets (%arg0 = %377) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %383 = qco.rz(%cst_39) %targets_out_137 : !qco.qubit -> !qco.qubit
    %384 = qco.x %383 : !qco.qubit -> !qco.qubit
    %385 = qco.rz(%cst_0) %384 : !qco.qubit -> !qco.qubit
    %386 = qco.rz(%cst_42) %controls_out_136 : !qco.qubit -> !qco.qubit
    %387 = qco.sx %386 : !qco.qubit -> !qco.qubit
    %388 = qco.rz(%cst_38) %387 : !qco.qubit -> !qco.qubit
    %389 = qco.sx %307 : !qco.qubit -> !qco.qubit
    %390 = qco.rz(%cst_47) %389 : !qco.qubit -> !qco.qubit
    %controls_out_138, %targets_out_139 = qco.ctrl(%390) targets (%arg0 = %385) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %391 = qco.rz(%cst_46) %targets_out_139 : !qco.qubit -> !qco.qubit
    %392 = qco.x %391 : !qco.qubit -> !qco.qubit
    %393 = qco.rz(%cst_45) %392 : !qco.qubit -> !qco.qubit
    %394 = qco.rz(%cst_49) %controls_out_138 : !qco.qubit -> !qco.qubit
    %395 = qco.sx %394 : !qco.qubit -> !qco.qubit
    %396 = qco.rz(%cst_44) %395 : !qco.qubit -> !qco.qubit
    %397 = qco.sx %396 : !qco.qubit -> !qco.qubit
    %398 = qco.rz(%cst_48) %397 : !qco.qubit -> !qco.qubit
    %controls_out_140, %targets_out_141 = qco.ctrl(%398) targets (%arg0 = %393) {
      %407 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %407 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %399 = qco.rz(%cst_43) %targets_out_141 : !qco.qubit -> !qco.qubit
    %400 = qco.x %399 : !qco.qubit -> !qco.qubit
    %401 = qco.rz(%cst) %400 : !qco.qubit -> !qco.qubit
    %402 = qco.rz(%cst_42) %controls_out_140 : !qco.qubit -> !qco.qubit
    %403 = qco.sx %402 : !qco.qubit -> !qco.qubit
    %404 = qco.rz(%cst_41) %403 : !qco.qubit -> !qco.qubit
    %405 = qco.sx %401 : !qco.qubit -> !qco.qubit
    %406 = qco.rz(%cst_20) %405 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %404 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<7>
    %qubit_out_142, %result_143 = qco.measure %388 : !qco.qubit
    cbit.store %result_143, %8[%c1] : !cbit.reg<7>
    %qubit_out_144, %result_145 = qco.measure %372 : !qco.qubit
    cbit.store %result_145, %8[%c2] : !cbit.reg<7>
    %qubit_out_146, %result_147 = qco.measure %357 : !qco.qubit
    cbit.store %result_147, %8[%c3] : !cbit.reg<7>
    %qubit_out_148, %result_149 = qco.measure %341 : !qco.qubit
    cbit.store %result_149, %8[%c4] : !cbit.reg<7>
    %qubit_out_150, %result_151 = qco.measure %325 : !qco.qubit
    cbit.store %result_151, %8[%c5] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_142 : !qco.qubit
    qco.sink %qubit_out_144 : !qco.qubit
    qco.sink %qubit_out_146 : !qco.qubit
    qco.sink %qubit_out_148 : !qco.qubit
    qco.sink %qubit_out_150 : !qco.qubit
    %qubit_out_152, %result_153 = qco.measure %406 : !qco.qubit
    qco.sink %qubit_out_152 : !qco.qubit
    cbit.store %result_153, %8[%c6] : !cbit.reg<7>
    qco.sink %targets_out_57 : !qco.qubit
    %cst_154 = arith.constant 0.96947585794377033 : f64
    qco.gphase(%cst_154)
    return %8 : !cbit.reg<7>
  }
}
