module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 7, 0>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948974 : f64
    %cst_0 = arith.constant 1.9634954084936209 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %cst_2 = arith.constant -0.39269908169872458 : f64
    %cst_3 = arith.constant -0.78539816339744739 : f64
    %cst_4 = arith.constant 2.3561944901923453 : f64
    %cst_5 = arith.constant 3.1415926535897927 : f64
    %cst_6 = arith.constant 2.3561944901923448 : f64
    %cst_7 = arith.constant -0.78539816339744916 : f64
    %cst_8 = arith.constant 2.7488935718910694 : f64
    %cst_9 = arith.constant 3.1415926535897922 : f64
    %cst_10 = arith.constant 2.748893571891069 : f64
    %cst_11 = arith.constant -1.178097245096172 : f64
    %cst_12 = arith.constant 7.853981633974481 : f64
    %cst_13 = arith.constant 3.1415926535897913 : f64
    %cst_14 = arith.constant 1.5707963267948961 : f64
    %cst_15 = arith.constant 2.9452431127404313 : f64
    %cst_16 = arith.constant -1.3744467859455352 : f64
    %cst_17 = arith.constant 1.5707963267949059 : f64
    %cst_18 = arith.constant 6.2831853071795951 : f64
    %cst_19 = arith.constant 7.8539816339744819 : f64
    %cst_20 = arith.constant 3.043417883165112 : f64
    %cst_21 = arith.constant 4.7123889803846888 : f64
    %cst_22 = arith.constant -1.4726215563702159 : f64
    %cst_23 = arith.constant 3.1415926535897931 : f64
    %cst_24 = arith.constant 7.8539816339744694 : f64
    %cst_25 = arith.constant 3.0925052683774532 : f64
    %cst_26 = arith.constant 3.1415926535897798 : f64
    %cst_27 = arith.constant 3.0925052683774528 : f64
    %cst_28 = arith.constant 1.5707963267948968 : f64
    %cst_29 = arith.constant -1.5217089415825562 : f64
    %cst_30 = arith.constant 7.8539816339744579 : f64
    %cst_31 = arith.constant 3.1415926535897678 : f64
    %cst_32 = arith.constant 3.1170489609836229 : f64
    %cst_33 = arith.constant -1.5462526341887255 : f64
    %cst_34 = arith.constant 1.570796326794897 : f64
    %cst_35 = arith.constant 6.2831853071795862 : f64
    %cst_36 = arith.constant 7.8539816339744828 : f64
    %cst_37 = arith.constant 1.5707963267948966 : f64
    %cst_38 = arith.constant 0.000000e+00 : f64
    %cst_39 = arith.constant 4.7123889803846897 : f64
    %cst_40 = arith.constant 9.4247779607693793 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %9 = qco.r(%cst_37, %cst_37) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_23, %cst_38) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_37, %cst_37) %3 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_23, %cst_38) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_37, %cst_37) %4 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_23, %cst_38) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_37, %cst_37) %5 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_23, %cst_38) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_37, %cst_37) %6 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_23, %cst_38) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst_37, %cst_37) %7 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_23, %cst_38) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_40, %cst_38) %0 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_39, %cst_38) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_37, %cst_37) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_28, %cst_38) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_23, %cst_38) %20 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_28, %cst_37) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst_39, %cst_38) %26 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%27) targets (%arg0 = %24) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qco.r(%cst_39, %cst_38) %targets_out : !qco.qubit -> !qco.qubit
    %29 = qco.r(%cst_37, %cst_37) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_39, %cst_38) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%cst_2, %cst_38) %controls_out : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_37, %cst_37) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_37, %cst_38) %32 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%33) targets (%arg0 = %30) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.r(%cst_1, %cst_38) %targets_out_42 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst_0, %cst_37) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_39, %cst_38) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%cst_23, %cst_38) %controls_out_41 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst_0, %cst_37) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst, %cst_38) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_39, %cst_38) %36 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst_37, %cst_37) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst_36, %cst_38) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%cst_35, %cst_38) %18 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_34, %cst_37) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst_39, %cst_38) %44 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%45) targets (%arg0 = %42) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qco.r(%cst_39, %cst_38) %targets_out_44 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%cst_37, %cst_37) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst_39, %cst_38) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.r(%cst_3, %cst_38) %controls_out_43 : !qco.qubit -> !qco.qubit
    %50 = qco.r(%cst_34, %cst_37) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.r(%cst_28, %cst_38) %50 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%51) targets (%arg0 = %48) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qco.r(%cst_28, %cst_38) %targets_out_46 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst_6, %cst_37) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.r(%cst_36, %cst_38) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.r(%cst_5, %cst_38) %controls_out_45 : !qco.qubit -> !qco.qubit
    %56 = qco.r(%cst_6, %cst_37) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.r(%cst_36, %cst_38) %56 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%16) targets (%arg0 = %54) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = qco.r(%cst_39, %cst_38) %10 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%cst_37, %cst_37) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.r(%cst_36, %cst_38) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.r(%cst_35, %cst_38) %1 : !qco.qubit -> !qco.qubit
    %62 = qco.r(%cst_34, %cst_37) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%cst_39, %cst_38) %62 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%63) targets (%arg0 = %60) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %64 = qco.r(%cst_39, %cst_38) %targets_out_50 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%cst_37, %cst_37) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.r(%cst_39, %cst_38) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.r(%cst_7, %cst_38) %controls_out_49 : !qco.qubit -> !qco.qubit
    %68 = qco.r(%cst_34, %cst_37) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.r(%cst_37, %cst_38) %68 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%69) targets (%arg0 = %66) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %70 = qco.r(%cst_34, %cst_38) %targets_out_52 : !qco.qubit -> !qco.qubit
    %71 = qco.r(%cst_6, %cst_37) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%cst_28, %cst_38) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%cst_5, %cst_38) %controls_out_51 : !qco.qubit -> !qco.qubit
    %74 = qco.r(%cst_4, %cst_37) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.r(%cst_36, %cst_38) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.r(%cst_37, %cst_37) %72 : !qco.qubit -> !qco.qubit
    %77 = qco.r(%cst_23, %cst_38) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst_39, %cst_38) %12 : !qco.qubit -> !qco.qubit
    %79 = qco.r(%cst_37, %cst_37) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.r(%cst_36, %cst_38) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%cst_35, %cst_38) %77 : !qco.qubit -> !qco.qubit
    %82 = qco.r(%cst_34, %cst_37) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.r(%cst_39, %cst_38) %82 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%83) targets (%arg0 = %80) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %84 = qco.r(%cst_39, %cst_38) %targets_out_54 : !qco.qubit -> !qco.qubit
    %85 = qco.r(%cst_37, %cst_37) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.r(%cst_39, %cst_38) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.r(%cst_7, %cst_38) %controls_out_53 : !qco.qubit -> !qco.qubit
    %88 = qco.r(%cst_34, %cst_37) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%cst_37, %cst_38) %88 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%89) targets (%arg0 = %86) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %90 = qco.r(%cst_34, %cst_38) %targets_out_56 : !qco.qubit -> !qco.qubit
    %91 = qco.r(%cst_6, %cst_37) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.r(%cst_28, %cst_38) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.r(%cst_5, %cst_38) %controls_out_55 : !qco.qubit -> !qco.qubit
    %94 = qco.r(%cst_4, %cst_37) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.r(%cst_36, %cst_38) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.r(%cst_39, %cst_38) %92 : !qco.qubit -> !qco.qubit
    %97 = qco.r(%cst_37, %cst_37) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.r(%cst_36, %cst_38) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.r(%cst_35, %cst_38) %75 : !qco.qubit -> !qco.qubit
    %100 = qco.r(%cst_34, %cst_37) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.r(%cst_39, %cst_38) %100 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%101) targets (%arg0 = %98) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %102 = qco.r(%cst_39, %cst_38) %targets_out_58 : !qco.qubit -> !qco.qubit
    %103 = qco.r(%cst_37, %cst_37) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.r(%cst_39, %cst_38) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.r(%cst_11, %cst_38) %controls_out_57 : !qco.qubit -> !qco.qubit
    %106 = qco.r(%cst_34, %cst_37) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.r(%cst_37, %cst_38) %106 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%107) targets (%arg0 = %104) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %108 = qco.r(%cst_34, %cst_38) %targets_out_60 : !qco.qubit -> !qco.qubit
    %109 = qco.r(%cst_10, %cst_37) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.r(%cst_37, %cst_38) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.r(%cst_9, %cst_38) %controls_out_59 : !qco.qubit -> !qco.qubit
    %112 = qco.r(%cst_8, %cst_37) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.r(%cst_19, %cst_38) %112 : !qco.qubit -> !qco.qubit
    %114 = qco.r(%cst_37, %cst_37) %110 : !qco.qubit -> !qco.qubit
    %115 = qco.r(%cst_23, %cst_38) %114 : !qco.qubit -> !qco.qubit
    %116 = qco.r(%cst_39, %cst_38) %14 : !qco.qubit -> !qco.qubit
    %117 = qco.r(%cst_37, %cst_37) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.r(%cst_36, %cst_38) %117 : !qco.qubit -> !qco.qubit
    %119 = qco.r(%cst_35, %cst_38) %115 : !qco.qubit -> !qco.qubit
    %120 = qco.r(%cst_34, %cst_37) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.r(%cst_39, %cst_38) %120 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%121) targets (%arg0 = %118) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %122 = qco.r(%cst_39, %cst_38) %targets_out_62 : !qco.qubit -> !qco.qubit
    %123 = qco.r(%cst_37, %cst_37) %122 : !qco.qubit -> !qco.qubit
    %124 = qco.r(%cst_39, %cst_38) %123 : !qco.qubit -> !qco.qubit
    %125 = qco.r(%cst_7, %cst_38) %controls_out_61 : !qco.qubit -> !qco.qubit
    %126 = qco.r(%cst_34, %cst_37) %125 : !qco.qubit -> !qco.qubit
    %127 = qco.r(%cst_37, %cst_38) %126 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%127) targets (%arg0 = %124) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %128 = qco.r(%cst_34, %cst_38) %targets_out_64 : !qco.qubit -> !qco.qubit
    %129 = qco.r(%cst_6, %cst_37) %128 : !qco.qubit -> !qco.qubit
    %130 = qco.r(%cst_28, %cst_38) %129 : !qco.qubit -> !qco.qubit
    %131 = qco.r(%cst_5, %cst_38) %controls_out_63 : !qco.qubit -> !qco.qubit
    %132 = qco.r(%cst_4, %cst_37) %131 : !qco.qubit -> !qco.qubit
    %133 = qco.r(%cst_36, %cst_38) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.r(%cst_39, %cst_38) %130 : !qco.qubit -> !qco.qubit
    %135 = qco.r(%cst_37, %cst_37) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.r(%cst_36, %cst_38) %135 : !qco.qubit -> !qco.qubit
    %137 = qco.r(%cst_35, %cst_38) %95 : !qco.qubit -> !qco.qubit
    %138 = qco.r(%cst_34, %cst_37) %137 : !qco.qubit -> !qco.qubit
    %139 = qco.r(%cst_39, %cst_38) %138 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%139) targets (%arg0 = %136) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %140 = qco.r(%cst_39, %cst_38) %targets_out_66 : !qco.qubit -> !qco.qubit
    %141 = qco.r(%cst_37, %cst_37) %140 : !qco.qubit -> !qco.qubit
    %142 = qco.r(%cst_39, %cst_38) %141 : !qco.qubit -> !qco.qubit
    %143 = qco.r(%cst_11, %cst_38) %controls_out_65 : !qco.qubit -> !qco.qubit
    %144 = qco.r(%cst_34, %cst_37) %143 : !qco.qubit -> !qco.qubit
    %145 = qco.r(%cst_37, %cst_38) %144 : !qco.qubit -> !qco.qubit
    %controls_out_67, %targets_out_68 = qco.ctrl(%145) targets (%arg0 = %142) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %146 = qco.r(%cst_34, %cst_38) %targets_out_68 : !qco.qubit -> !qco.qubit
    %147 = qco.r(%cst_10, %cst_37) %146 : !qco.qubit -> !qco.qubit
    %148 = qco.r(%cst_37, %cst_38) %147 : !qco.qubit -> !qco.qubit
    %149 = qco.r(%cst_9, %cst_38) %controls_out_67 : !qco.qubit -> !qco.qubit
    %150 = qco.r(%cst_8, %cst_37) %149 : !qco.qubit -> !qco.qubit
    %151 = qco.r(%cst_19, %cst_38) %150 : !qco.qubit -> !qco.qubit
    %152 = qco.r(%cst_39, %cst_38) %148 : !qco.qubit -> !qco.qubit
    %153 = qco.r(%cst_37, %cst_37) %152 : !qco.qubit -> !qco.qubit
    %154 = qco.r(%cst_36, %cst_38) %153 : !qco.qubit -> !qco.qubit
    %155 = qco.r(%cst_35, %cst_38) %113 : !qco.qubit -> !qco.qubit
    %156 = qco.r(%cst_34, %cst_37) %155 : !qco.qubit -> !qco.qubit
    %157 = qco.r(%cst_39, %cst_38) %156 : !qco.qubit -> !qco.qubit
    %controls_out_69, %targets_out_70 = qco.ctrl(%157) targets (%arg0 = %154) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %158 = qco.r(%cst_39, %cst_38) %targets_out_70 : !qco.qubit -> !qco.qubit
    %159 = qco.r(%cst_37, %cst_37) %158 : !qco.qubit -> !qco.qubit
    %160 = qco.r(%cst_39, %cst_38) %159 : !qco.qubit -> !qco.qubit
    %161 = qco.r(%cst_16, %cst_38) %controls_out_69 : !qco.qubit -> !qco.qubit
    %162 = qco.r(%cst_34, %cst_37) %161 : !qco.qubit -> !qco.qubit
    %163 = qco.r(%cst_37, %cst_38) %162 : !qco.qubit -> !qco.qubit
    %controls_out_71, %targets_out_72 = qco.ctrl(%163) targets (%arg0 = %160) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %164 = qco.r(%cst_37, %cst_38) %targets_out_72 : !qco.qubit -> !qco.qubit
    %165 = qco.r(%cst_15, %cst_37) %164 : !qco.qubit -> !qco.qubit
    %166 = qco.r(%cst_14, %cst_38) %165 : !qco.qubit -> !qco.qubit
    %167 = qco.r(%cst_13, %cst_38) %controls_out_71 : !qco.qubit -> !qco.qubit
    %168 = qco.r(%cst_15, %cst_37) %167 : !qco.qubit -> !qco.qubit
    %169 = qco.r(%cst_12, %cst_38) %168 : !qco.qubit -> !qco.qubit
    %170 = qco.r(%cst_37, %cst_37) %166 : !qco.qubit -> !qco.qubit
    %171 = qco.r(%cst_23, %cst_38) %170 : !qco.qubit -> !qco.qubit
    %172 = qco.r(%cst_39, %cst_38) %controls_out_47 : !qco.qubit -> !qco.qubit
    %173 = qco.r(%cst_37, %cst_37) %172 : !qco.qubit -> !qco.qubit
    %174 = qco.r(%cst_36, %cst_38) %173 : !qco.qubit -> !qco.qubit
    %175 = qco.r(%cst_35, %cst_38) %171 : !qco.qubit -> !qco.qubit
    %176 = qco.r(%cst_34, %cst_37) %175 : !qco.qubit -> !qco.qubit
    %177 = qco.r(%cst_39, %cst_38) %176 : !qco.qubit -> !qco.qubit
    %controls_out_73, %targets_out_74 = qco.ctrl(%177) targets (%arg0 = %174) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %178 = qco.r(%cst_39, %cst_38) %targets_out_74 : !qco.qubit -> !qco.qubit
    %179 = qco.r(%cst_37, %cst_37) %178 : !qco.qubit -> !qco.qubit
    %180 = qco.r(%cst_39, %cst_38) %179 : !qco.qubit -> !qco.qubit
    %181 = qco.r(%cst_7, %cst_38) %controls_out_73 : !qco.qubit -> !qco.qubit
    %182 = qco.r(%cst_34, %cst_37) %181 : !qco.qubit -> !qco.qubit
    %183 = qco.r(%cst_37, %cst_38) %182 : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%183) targets (%arg0 = %180) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %184 = qco.r(%cst_34, %cst_38) %targets_out_76 : !qco.qubit -> !qco.qubit
    %185 = qco.r(%cst_6, %cst_37) %184 : !qco.qubit -> !qco.qubit
    %186 = qco.r(%cst_28, %cst_38) %185 : !qco.qubit -> !qco.qubit
    %187 = qco.r(%cst_5, %cst_38) %controls_out_75 : !qco.qubit -> !qco.qubit
    %188 = qco.r(%cst_4, %cst_37) %187 : !qco.qubit -> !qco.qubit
    %189 = qco.r(%cst_36, %cst_38) %188 : !qco.qubit -> !qco.qubit
    %190 = qco.r(%cst_39, %cst_38) %186 : !qco.qubit -> !qco.qubit
    %191 = qco.r(%cst_37, %cst_37) %190 : !qco.qubit -> !qco.qubit
    %192 = qco.r(%cst_36, %cst_38) %191 : !qco.qubit -> !qco.qubit
    %193 = qco.r(%cst_35, %cst_38) %133 : !qco.qubit -> !qco.qubit
    %194 = qco.r(%cst_34, %cst_37) %193 : !qco.qubit -> !qco.qubit
    %195 = qco.r(%cst_39, %cst_38) %194 : !qco.qubit -> !qco.qubit
    %controls_out_77, %targets_out_78 = qco.ctrl(%195) targets (%arg0 = %192) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %196 = qco.r(%cst_39, %cst_38) %targets_out_78 : !qco.qubit -> !qco.qubit
    %197 = qco.r(%cst_37, %cst_37) %196 : !qco.qubit -> !qco.qubit
    %198 = qco.r(%cst_39, %cst_38) %197 : !qco.qubit -> !qco.qubit
    %199 = qco.r(%cst_11, %cst_38) %controls_out_77 : !qco.qubit -> !qco.qubit
    %200 = qco.r(%cst_34, %cst_37) %199 : !qco.qubit -> !qco.qubit
    %201 = qco.r(%cst_37, %cst_38) %200 : !qco.qubit -> !qco.qubit
    %controls_out_79, %targets_out_80 = qco.ctrl(%201) targets (%arg0 = %198) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %202 = qco.r(%cst_34, %cst_38) %targets_out_80 : !qco.qubit -> !qco.qubit
    %203 = qco.r(%cst_10, %cst_37) %202 : !qco.qubit -> !qco.qubit
    %204 = qco.r(%cst_37, %cst_38) %203 : !qco.qubit -> !qco.qubit
    %205 = qco.r(%cst_9, %cst_38) %controls_out_79 : !qco.qubit -> !qco.qubit
    %206 = qco.r(%cst_8, %cst_37) %205 : !qco.qubit -> !qco.qubit
    %207 = qco.r(%cst_19, %cst_38) %206 : !qco.qubit -> !qco.qubit
    %208 = qco.r(%cst_39, %cst_38) %204 : !qco.qubit -> !qco.qubit
    %209 = qco.r(%cst_37, %cst_37) %208 : !qco.qubit -> !qco.qubit
    %210 = qco.r(%cst_36, %cst_38) %209 : !qco.qubit -> !qco.qubit
    %211 = qco.r(%cst_35, %cst_38) %151 : !qco.qubit -> !qco.qubit
    %212 = qco.r(%cst_34, %cst_37) %211 : !qco.qubit -> !qco.qubit
    %213 = qco.r(%cst_39, %cst_38) %212 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%213) targets (%arg0 = %210) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %214 = qco.r(%cst_39, %cst_38) %targets_out_82 : !qco.qubit -> !qco.qubit
    %215 = qco.r(%cst_37, %cst_37) %214 : !qco.qubit -> !qco.qubit
    %216 = qco.r(%cst_39, %cst_38) %215 : !qco.qubit -> !qco.qubit
    %217 = qco.r(%cst_16, %cst_38) %controls_out_81 : !qco.qubit -> !qco.qubit
    %218 = qco.r(%cst_34, %cst_37) %217 : !qco.qubit -> !qco.qubit
    %219 = qco.r(%cst_37, %cst_38) %218 : !qco.qubit -> !qco.qubit
    %controls_out_83, %targets_out_84 = qco.ctrl(%219) targets (%arg0 = %216) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %220 = qco.r(%cst_37, %cst_38) %targets_out_84 : !qco.qubit -> !qco.qubit
    %221 = qco.r(%cst_15, %cst_37) %220 : !qco.qubit -> !qco.qubit
    %222 = qco.r(%cst_14, %cst_38) %221 : !qco.qubit -> !qco.qubit
    %223 = qco.r(%cst_13, %cst_38) %controls_out_83 : !qco.qubit -> !qco.qubit
    %224 = qco.r(%cst_15, %cst_37) %223 : !qco.qubit -> !qco.qubit
    %225 = qco.r(%cst_12, %cst_38) %224 : !qco.qubit -> !qco.qubit
    %226 = qco.r(%cst_36, %cst_38) %222 : !qco.qubit -> !qco.qubit
    %227 = qco.r(%cst_28, %cst_37) %226 : !qco.qubit -> !qco.qubit
    %228 = qco.r(%cst_37, %cst_38) %227 : !qco.qubit -> !qco.qubit
    %229 = qco.r(%cst_23, %cst_38) %169 : !qco.qubit -> !qco.qubit
    %230 = qco.r(%cst_28, %cst_37) %229 : !qco.qubit -> !qco.qubit
    %231 = qco.r(%cst_39, %cst_38) %230 : !qco.qubit -> !qco.qubit
    %controls_out_85, %targets_out_86 = qco.ctrl(%231) targets (%arg0 = %228) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %232 = qco.r(%cst_39, %cst_38) %targets_out_86 : !qco.qubit -> !qco.qubit
    %233 = qco.r(%cst_37, %cst_37) %232 : !qco.qubit -> !qco.qubit
    %234 = qco.r(%cst_39, %cst_38) %233 : !qco.qubit -> !qco.qubit
    %235 = qco.r(%cst_22, %cst_38) %controls_out_85 : !qco.qubit -> !qco.qubit
    %236 = qco.r(%cst_34, %cst_37) %235 : !qco.qubit -> !qco.qubit
    %237 = qco.r(%cst_37, %cst_38) %236 : !qco.qubit -> !qco.qubit
    %controls_out_87, %targets_out_88 = qco.ctrl(%237) targets (%arg0 = %234) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %238 = qco.r(%cst_21, %cst_38) %targets_out_88 : !qco.qubit -> !qco.qubit
    %239 = qco.r(%cst_20, %cst_37) %238 : !qco.qubit -> !qco.qubit
    %240 = qco.r(%cst_19, %cst_38) %239 : !qco.qubit -> !qco.qubit
    %241 = qco.r(%cst_18, %cst_38) %controls_out_87 : !qco.qubit -> !qco.qubit
    %242 = qco.r(%cst_20, %cst_37) %241 : !qco.qubit -> !qco.qubit
    %243 = qco.r(%cst_17, %cst_38) %242 : !qco.qubit -> !qco.qubit
    %244 = qco.r(%cst_37, %cst_37) %240 : !qco.qubit -> !qco.qubit
    %245 = qco.r(%cst_23, %cst_38) %244 : !qco.qubit -> !qco.qubit
    %246 = qco.r(%cst_39, %cst_38) %57 : !qco.qubit -> !qco.qubit
    %247 = qco.r(%cst_37, %cst_37) %246 : !qco.qubit -> !qco.qubit
    %248 = qco.r(%cst_36, %cst_38) %247 : !qco.qubit -> !qco.qubit
    %249 = qco.r(%cst_35, %cst_38) %245 : !qco.qubit -> !qco.qubit
    %250 = qco.r(%cst_34, %cst_37) %249 : !qco.qubit -> !qco.qubit
    %251 = qco.r(%cst_39, %cst_38) %250 : !qco.qubit -> !qco.qubit
    %controls_out_89, %targets_out_90 = qco.ctrl(%251) targets (%arg0 = %248) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %252 = qco.r(%cst_39, %cst_38) %targets_out_90 : !qco.qubit -> !qco.qubit
    %253 = qco.r(%cst_37, %cst_37) %252 : !qco.qubit -> !qco.qubit
    %254 = qco.r(%cst_39, %cst_38) %253 : !qco.qubit -> !qco.qubit
    %255 = qco.r(%cst_7, %cst_38) %controls_out_89 : !qco.qubit -> !qco.qubit
    %256 = qco.r(%cst_34, %cst_37) %255 : !qco.qubit -> !qco.qubit
    %257 = qco.r(%cst_37, %cst_38) %256 : !qco.qubit -> !qco.qubit
    %controls_out_91, %targets_out_92 = qco.ctrl(%257) targets (%arg0 = %254) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %258 = qco.r(%cst_34, %cst_38) %targets_out_92 : !qco.qubit -> !qco.qubit
    %259 = qco.r(%cst_6, %cst_37) %258 : !qco.qubit -> !qco.qubit
    %260 = qco.r(%cst_28, %cst_38) %259 : !qco.qubit -> !qco.qubit
    %261 = qco.r(%cst_5, %cst_38) %controls_out_91 : !qco.qubit -> !qco.qubit
    %262 = qco.r(%cst_4, %cst_37) %261 : !qco.qubit -> !qco.qubit
    %263 = qco.r(%cst_36, %cst_38) %262 : !qco.qubit -> !qco.qubit
    %264 = qco.r(%cst_39, %cst_38) %260 : !qco.qubit -> !qco.qubit
    %265 = qco.r(%cst_37, %cst_37) %264 : !qco.qubit -> !qco.qubit
    %266 = qco.r(%cst_36, %cst_38) %265 : !qco.qubit -> !qco.qubit
    %267 = qco.r(%cst_35, %cst_38) %189 : !qco.qubit -> !qco.qubit
    %268 = qco.r(%cst_34, %cst_37) %267 : !qco.qubit -> !qco.qubit
    %269 = qco.r(%cst_39, %cst_38) %268 : !qco.qubit -> !qco.qubit
    %controls_out_93, %targets_out_94 = qco.ctrl(%269) targets (%arg0 = %266) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %270 = qco.r(%cst_39, %cst_38) %targets_out_94 : !qco.qubit -> !qco.qubit
    %271 = qco.r(%cst_37, %cst_37) %270 : !qco.qubit -> !qco.qubit
    %272 = qco.r(%cst_39, %cst_38) %271 : !qco.qubit -> !qco.qubit
    %273 = qco.r(%cst_11, %cst_38) %controls_out_93 : !qco.qubit -> !qco.qubit
    %274 = qco.r(%cst_34, %cst_37) %273 : !qco.qubit -> !qco.qubit
    %275 = qco.r(%cst_37, %cst_38) %274 : !qco.qubit -> !qco.qubit
    %controls_out_95, %targets_out_96 = qco.ctrl(%275) targets (%arg0 = %272) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %276 = qco.r(%cst_34, %cst_38) %targets_out_96 : !qco.qubit -> !qco.qubit
    %277 = qco.r(%cst_10, %cst_37) %276 : !qco.qubit -> !qco.qubit
    %278 = qco.r(%cst_37, %cst_38) %277 : !qco.qubit -> !qco.qubit
    %279 = qco.r(%cst_9, %cst_38) %controls_out_95 : !qco.qubit -> !qco.qubit
    %280 = qco.r(%cst_8, %cst_37) %279 : !qco.qubit -> !qco.qubit
    %281 = qco.r(%cst_19, %cst_38) %280 : !qco.qubit -> !qco.qubit
    %282 = qco.r(%cst_39, %cst_38) %278 : !qco.qubit -> !qco.qubit
    %283 = qco.r(%cst_37, %cst_37) %282 : !qco.qubit -> !qco.qubit
    %284 = qco.r(%cst_36, %cst_38) %283 : !qco.qubit -> !qco.qubit
    %285 = qco.r(%cst_35, %cst_38) %207 : !qco.qubit -> !qco.qubit
    %286 = qco.r(%cst_34, %cst_37) %285 : !qco.qubit -> !qco.qubit
    %287 = qco.r(%cst_39, %cst_38) %286 : !qco.qubit -> !qco.qubit
    %controls_out_97, %targets_out_98 = qco.ctrl(%287) targets (%arg0 = %284) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %288 = qco.r(%cst_39, %cst_38) %targets_out_98 : !qco.qubit -> !qco.qubit
    %289 = qco.r(%cst_37, %cst_37) %288 : !qco.qubit -> !qco.qubit
    %290 = qco.r(%cst_39, %cst_38) %289 : !qco.qubit -> !qco.qubit
    %291 = qco.r(%cst_16, %cst_38) %controls_out_97 : !qco.qubit -> !qco.qubit
    %292 = qco.r(%cst_34, %cst_37) %291 : !qco.qubit -> !qco.qubit
    %293 = qco.r(%cst_37, %cst_38) %292 : !qco.qubit -> !qco.qubit
    %controls_out_99, %targets_out_100 = qco.ctrl(%293) targets (%arg0 = %290) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %294 = qco.r(%cst_37, %cst_38) %targets_out_100 : !qco.qubit -> !qco.qubit
    %295 = qco.r(%cst_15, %cst_37) %294 : !qco.qubit -> !qco.qubit
    %296 = qco.r(%cst_14, %cst_38) %295 : !qco.qubit -> !qco.qubit
    %297 = qco.r(%cst_13, %cst_38) %controls_out_99 : !qco.qubit -> !qco.qubit
    %298 = qco.r(%cst_15, %cst_37) %297 : !qco.qubit -> !qco.qubit
    %299 = qco.r(%cst_12, %cst_38) %298 : !qco.qubit -> !qco.qubit
    %300 = qco.r(%cst_36, %cst_38) %296 : !qco.qubit -> !qco.qubit
    %301 = qco.r(%cst_28, %cst_37) %300 : !qco.qubit -> !qco.qubit
    %302 = qco.r(%cst_37, %cst_38) %301 : !qco.qubit -> !qco.qubit
    %303 = qco.r(%cst_23, %cst_38) %225 : !qco.qubit -> !qco.qubit
    %304 = qco.r(%cst_28, %cst_37) %303 : !qco.qubit -> !qco.qubit
    %305 = qco.r(%cst_39, %cst_38) %304 : !qco.qubit -> !qco.qubit
    %controls_out_101, %targets_out_102 = qco.ctrl(%305) targets (%arg0 = %302) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %306 = qco.r(%cst_39, %cst_38) %targets_out_102 : !qco.qubit -> !qco.qubit
    %307 = qco.r(%cst_37, %cst_37) %306 : !qco.qubit -> !qco.qubit
    %308 = qco.r(%cst_39, %cst_38) %307 : !qco.qubit -> !qco.qubit
    %309 = qco.r(%cst_22, %cst_38) %controls_out_101 : !qco.qubit -> !qco.qubit
    %310 = qco.r(%cst_34, %cst_37) %309 : !qco.qubit -> !qco.qubit
    %311 = qco.r(%cst_37, %cst_38) %310 : !qco.qubit -> !qco.qubit
    %controls_out_103, %targets_out_104 = qco.ctrl(%311) targets (%arg0 = %308) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %312 = qco.r(%cst_21, %cst_38) %targets_out_104 : !qco.qubit -> !qco.qubit
    %313 = qco.r(%cst_20, %cst_37) %312 : !qco.qubit -> !qco.qubit
    %314 = qco.r(%cst_19, %cst_38) %313 : !qco.qubit -> !qco.qubit
    %315 = qco.r(%cst_18, %cst_38) %controls_out_103 : !qco.qubit -> !qco.qubit
    %316 = qco.r(%cst_20, %cst_37) %315 : !qco.qubit -> !qco.qubit
    %317 = qco.r(%cst_17, %cst_38) %316 : !qco.qubit -> !qco.qubit
    %318 = qco.r(%cst_39, %cst_38) %314 : !qco.qubit -> !qco.qubit
    %319 = qco.r(%cst_37, %cst_37) %318 : !qco.qubit -> !qco.qubit
    %320 = qco.r(%cst_36, %cst_38) %319 : !qco.qubit -> !qco.qubit
    %321 = qco.r(%cst_35, %cst_38) %243 : !qco.qubit -> !qco.qubit
    %322 = qco.r(%cst_34, %cst_37) %321 : !qco.qubit -> !qco.qubit
    %323 = qco.r(%cst_39, %cst_38) %322 : !qco.qubit -> !qco.qubit
    %controls_out_105, %targets_out_106 = qco.ctrl(%323) targets (%arg0 = %320) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %324 = qco.r(%cst_39, %cst_38) %targets_out_106 : !qco.qubit -> !qco.qubit
    %325 = qco.r(%cst_37, %cst_37) %324 : !qco.qubit -> !qco.qubit
    %326 = qco.r(%cst_39, %cst_38) %325 : !qco.qubit -> !qco.qubit
    %327 = qco.r(%cst_29, %cst_38) %controls_out_105 : !qco.qubit -> !qco.qubit
    %328 = qco.r(%cst_34, %cst_37) %327 : !qco.qubit -> !qco.qubit
    %329 = qco.r(%cst_37, %cst_38) %328 : !qco.qubit -> !qco.qubit
    %controls_out_107, %targets_out_108 = qco.ctrl(%329) targets (%arg0 = %326) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %330 = qco.r(%cst_28, %cst_38) %targets_out_108 : !qco.qubit -> !qco.qubit
    %331 = qco.r(%cst_27, %cst_37) %330 : !qco.qubit -> !qco.qubit
    %332 = qco.r(%cst_37, %cst_38) %331 : !qco.qubit -> !qco.qubit
    %333 = qco.r(%cst_26, %cst_38) %controls_out_107 : !qco.qubit -> !qco.qubit
    %334 = qco.r(%cst_25, %cst_37) %333 : !qco.qubit -> !qco.qubit
    %335 = qco.r(%cst_24, %cst_38) %334 : !qco.qubit -> !qco.qubit
    %336 = qco.r(%cst_37, %cst_37) %332 : !qco.qubit -> !qco.qubit
    %337 = qco.r(%cst_23, %cst_38) %336 : !qco.qubit -> !qco.qubit
    %338 = qco.r(%cst_39, %cst_38) %39 : !qco.qubit -> !qco.qubit
    %339 = qco.r(%cst_37, %cst_37) %338 : !qco.qubit -> !qco.qubit
    %340 = qco.r(%cst_36, %cst_38) %339 : !qco.qubit -> !qco.qubit
    %341 = qco.r(%cst_35, %cst_38) %337 : !qco.qubit -> !qco.qubit
    %342 = qco.r(%cst_34, %cst_37) %341 : !qco.qubit -> !qco.qubit
    %343 = qco.r(%cst_39, %cst_38) %342 : !qco.qubit -> !qco.qubit
    %controls_out_109, %targets_out_110 = qco.ctrl(%343) targets (%arg0 = %340) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %344 = qco.r(%cst_39, %cst_38) %targets_out_110 : !qco.qubit -> !qco.qubit
    %345 = qco.r(%cst_37, %cst_37) %344 : !qco.qubit -> !qco.qubit
    %346 = qco.r(%cst_39, %cst_38) %345 : !qco.qubit -> !qco.qubit
    %347 = qco.r(%cst_7, %cst_38) %controls_out_109 : !qco.qubit -> !qco.qubit
    %348 = qco.r(%cst_34, %cst_37) %347 : !qco.qubit -> !qco.qubit
    %349 = qco.r(%cst_37, %cst_38) %348 : !qco.qubit -> !qco.qubit
    %controls_out_111, %targets_out_112 = qco.ctrl(%349) targets (%arg0 = %346) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %350 = qco.r(%cst_34, %cst_38) %targets_out_112 : !qco.qubit -> !qco.qubit
    %351 = qco.r(%cst_6, %cst_37) %350 : !qco.qubit -> !qco.qubit
    %352 = qco.r(%cst_28, %cst_38) %351 : !qco.qubit -> !qco.qubit
    %353 = qco.r(%cst_5, %cst_38) %controls_out_111 : !qco.qubit -> !qco.qubit
    %354 = qco.r(%cst_4, %cst_37) %353 : !qco.qubit -> !qco.qubit
    %355 = qco.r(%cst_36, %cst_38) %354 : !qco.qubit -> !qco.qubit
    %356 = qco.r(%cst_39, %cst_38) %352 : !qco.qubit -> !qco.qubit
    %357 = qco.r(%cst_37, %cst_37) %356 : !qco.qubit -> !qco.qubit
    %358 = qco.r(%cst_36, %cst_38) %357 : !qco.qubit -> !qco.qubit
    %359 = qco.r(%cst_35, %cst_38) %263 : !qco.qubit -> !qco.qubit
    %360 = qco.r(%cst_34, %cst_37) %359 : !qco.qubit -> !qco.qubit
    %361 = qco.r(%cst_39, %cst_38) %360 : !qco.qubit -> !qco.qubit
    %controls_out_113, %targets_out_114 = qco.ctrl(%361) targets (%arg0 = %358) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %362 = qco.r(%cst_39, %cst_38) %targets_out_114 : !qco.qubit -> !qco.qubit
    %363 = qco.r(%cst_37, %cst_37) %362 : !qco.qubit -> !qco.qubit
    %364 = qco.r(%cst_39, %cst_38) %363 : !qco.qubit -> !qco.qubit
    %365 = qco.r(%cst_11, %cst_38) %controls_out_113 : !qco.qubit -> !qco.qubit
    %366 = qco.r(%cst_34, %cst_37) %365 : !qco.qubit -> !qco.qubit
    %367 = qco.r(%cst_37, %cst_38) %366 : !qco.qubit -> !qco.qubit
    %controls_out_115, %targets_out_116 = qco.ctrl(%367) targets (%arg0 = %364) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %368 = qco.r(%cst_34, %cst_38) %targets_out_116 : !qco.qubit -> !qco.qubit
    %369 = qco.r(%cst_10, %cst_37) %368 : !qco.qubit -> !qco.qubit
    %370 = qco.r(%cst_37, %cst_38) %369 : !qco.qubit -> !qco.qubit
    %371 = qco.r(%cst_9, %cst_38) %controls_out_115 : !qco.qubit -> !qco.qubit
    %372 = qco.r(%cst_8, %cst_37) %371 : !qco.qubit -> !qco.qubit
    %373 = qco.r(%cst_19, %cst_38) %372 : !qco.qubit -> !qco.qubit
    %374 = qco.r(%cst_39, %cst_38) %370 : !qco.qubit -> !qco.qubit
    %375 = qco.r(%cst_37, %cst_37) %374 : !qco.qubit -> !qco.qubit
    %376 = qco.r(%cst_36, %cst_38) %375 : !qco.qubit -> !qco.qubit
    %377 = qco.r(%cst_35, %cst_38) %281 : !qco.qubit -> !qco.qubit
    %378 = qco.r(%cst_34, %cst_37) %377 : !qco.qubit -> !qco.qubit
    %379 = qco.r(%cst_39, %cst_38) %378 : !qco.qubit -> !qco.qubit
    %controls_out_117, %targets_out_118 = qco.ctrl(%379) targets (%arg0 = %376) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %380 = qco.r(%cst_39, %cst_38) %targets_out_118 : !qco.qubit -> !qco.qubit
    %381 = qco.r(%cst_37, %cst_37) %380 : !qco.qubit -> !qco.qubit
    %382 = qco.r(%cst_39, %cst_38) %381 : !qco.qubit -> !qco.qubit
    %383 = qco.r(%cst_16, %cst_38) %controls_out_117 : !qco.qubit -> !qco.qubit
    %384 = qco.r(%cst_34, %cst_37) %383 : !qco.qubit -> !qco.qubit
    %385 = qco.r(%cst_37, %cst_38) %384 : !qco.qubit -> !qco.qubit
    %controls_out_119, %targets_out_120 = qco.ctrl(%385) targets (%arg0 = %382) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %386 = qco.r(%cst_37, %cst_38) %targets_out_120 : !qco.qubit -> !qco.qubit
    %387 = qco.r(%cst_15, %cst_37) %386 : !qco.qubit -> !qco.qubit
    %388 = qco.r(%cst_14, %cst_38) %387 : !qco.qubit -> !qco.qubit
    %389 = qco.r(%cst_13, %cst_38) %controls_out_119 : !qco.qubit -> !qco.qubit
    %390 = qco.r(%cst_15, %cst_37) %389 : !qco.qubit -> !qco.qubit
    %391 = qco.r(%cst_12, %cst_38) %390 : !qco.qubit -> !qco.qubit
    %392 = qco.r(%cst_36, %cst_38) %388 : !qco.qubit -> !qco.qubit
    %393 = qco.r(%cst_28, %cst_37) %392 : !qco.qubit -> !qco.qubit
    %394 = qco.r(%cst_37, %cst_38) %393 : !qco.qubit -> !qco.qubit
    %395 = qco.r(%cst_23, %cst_38) %299 : !qco.qubit -> !qco.qubit
    %396 = qco.r(%cst_28, %cst_37) %395 : !qco.qubit -> !qco.qubit
    %397 = qco.r(%cst_39, %cst_38) %396 : !qco.qubit -> !qco.qubit
    %controls_out_121, %targets_out_122 = qco.ctrl(%397) targets (%arg0 = %394) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %398 = qco.r(%cst_39, %cst_38) %targets_out_122 : !qco.qubit -> !qco.qubit
    %399 = qco.r(%cst_37, %cst_37) %398 : !qco.qubit -> !qco.qubit
    %400 = qco.r(%cst_39, %cst_38) %399 : !qco.qubit -> !qco.qubit
    %401 = qco.r(%cst_22, %cst_38) %controls_out_121 : !qco.qubit -> !qco.qubit
    %402 = qco.r(%cst_34, %cst_37) %401 : !qco.qubit -> !qco.qubit
    %403 = qco.r(%cst_37, %cst_38) %402 : !qco.qubit -> !qco.qubit
    %controls_out_123, %targets_out_124 = qco.ctrl(%403) targets (%arg0 = %400) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %404 = qco.r(%cst_21, %cst_38) %targets_out_124 : !qco.qubit -> !qco.qubit
    %405 = qco.r(%cst_20, %cst_37) %404 : !qco.qubit -> !qco.qubit
    %406 = qco.r(%cst_19, %cst_38) %405 : !qco.qubit -> !qco.qubit
    %407 = qco.r(%cst_18, %cst_38) %controls_out_123 : !qco.qubit -> !qco.qubit
    %408 = qco.r(%cst_20, %cst_37) %407 : !qco.qubit -> !qco.qubit
    %409 = qco.r(%cst_17, %cst_38) %408 : !qco.qubit -> !qco.qubit
    %410 = qco.r(%cst_39, %cst_38) %406 : !qco.qubit -> !qco.qubit
    %411 = qco.r(%cst_37, %cst_37) %410 : !qco.qubit -> !qco.qubit
    %412 = qco.r(%cst_36, %cst_38) %411 : !qco.qubit -> !qco.qubit
    %413 = qco.r(%cst_35, %cst_38) %317 : !qco.qubit -> !qco.qubit
    %414 = qco.r(%cst_34, %cst_37) %413 : !qco.qubit -> !qco.qubit
    %415 = qco.r(%cst_39, %cst_38) %414 : !qco.qubit -> !qco.qubit
    %controls_out_125, %targets_out_126 = qco.ctrl(%415) targets (%arg0 = %412) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %416 = qco.r(%cst_39, %cst_38) %targets_out_126 : !qco.qubit -> !qco.qubit
    %417 = qco.r(%cst_37, %cst_37) %416 : !qco.qubit -> !qco.qubit
    %418 = qco.r(%cst_39, %cst_38) %417 : !qco.qubit -> !qco.qubit
    %419 = qco.r(%cst_29, %cst_38) %controls_out_125 : !qco.qubit -> !qco.qubit
    %420 = qco.r(%cst_34, %cst_37) %419 : !qco.qubit -> !qco.qubit
    %421 = qco.r(%cst_37, %cst_38) %420 : !qco.qubit -> !qco.qubit
    %controls_out_127, %targets_out_128 = qco.ctrl(%421) targets (%arg0 = %418) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %422 = qco.r(%cst_28, %cst_38) %targets_out_128 : !qco.qubit -> !qco.qubit
    %423 = qco.r(%cst_27, %cst_37) %422 : !qco.qubit -> !qco.qubit
    %424 = qco.r(%cst_37, %cst_38) %423 : !qco.qubit -> !qco.qubit
    %425 = qco.r(%cst_26, %cst_38) %controls_out_127 : !qco.qubit -> !qco.qubit
    %426 = qco.r(%cst_25, %cst_37) %425 : !qco.qubit -> !qco.qubit
    %427 = qco.r(%cst_24, %cst_38) %426 : !qco.qubit -> !qco.qubit
    %428 = qco.r(%cst_39, %cst_38) %424 : !qco.qubit -> !qco.qubit
    %429 = qco.r(%cst_37, %cst_37) %428 : !qco.qubit -> !qco.qubit
    %430 = qco.r(%cst_36, %cst_38) %429 : !qco.qubit -> !qco.qubit
    %431 = qco.r(%cst_35, %cst_38) %335 : !qco.qubit -> !qco.qubit
    %432 = qco.r(%cst_34, %cst_37) %431 : !qco.qubit -> !qco.qubit
    %433 = qco.r(%cst_39, %cst_38) %432 : !qco.qubit -> !qco.qubit
    %controls_out_129, %targets_out_130 = qco.ctrl(%433) targets (%arg0 = %430) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %434 = qco.r(%cst_39, %cst_38) %targets_out_130 : !qco.qubit -> !qco.qubit
    %435 = qco.r(%cst_37, %cst_37) %434 : !qco.qubit -> !qco.qubit
    %436 = qco.r(%cst_39, %cst_38) %435 : !qco.qubit -> !qco.qubit
    %437 = qco.r(%cst_33, %cst_38) %controls_out_129 : !qco.qubit -> !qco.qubit
    %438 = qco.r(%cst_34, %cst_37) %437 : !qco.qubit -> !qco.qubit
    %439 = qco.r(%cst_37, %cst_38) %438 : !qco.qubit -> !qco.qubit
    %controls_out_131, %targets_out_132 = qco.ctrl(%439) targets (%arg0 = %436) {
      %448 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %448 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %440 = qco.r(%cst_37, %cst_38) %targets_out_132 : !qco.qubit -> !qco.qubit
    %441 = qco.r(%cst_32, %cst_37) %440 : !qco.qubit -> !qco.qubit
    %442 = qco.r(%cst_37, %cst_38) %441 : !qco.qubit -> !qco.qubit
    %443 = qco.r(%cst_31, %cst_38) %controls_out_131 : !qco.qubit -> !qco.qubit
    %444 = qco.r(%cst_32, %cst_37) %443 : !qco.qubit -> !qco.qubit
    %445 = qco.r(%cst_30, %cst_38) %444 : !qco.qubit -> !qco.qubit
    %446 = qco.r(%cst_37, %cst_37) %442 : !qco.qubit -> !qco.qubit
    %447 = qco.r(%cst_23, %cst_38) %446 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %445 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<7>
    %qubit_out_133, %result_134 = qco.measure %427 : !qco.qubit
    cbit.store %result_134, %8[%c1] : !cbit.reg<7>
    %qubit_out_135, %result_136 = qco.measure %409 : !qco.qubit
    cbit.store %result_136, %8[%c2] : !cbit.reg<7>
    %qubit_out_137, %result_138 = qco.measure %391 : !qco.qubit
    cbit.store %result_138, %8[%c3] : !cbit.reg<7>
    %qubit_out_139, %result_140 = qco.measure %373 : !qco.qubit
    cbit.store %result_140, %8[%c4] : !cbit.reg<7>
    %qubit_out_141, %result_142 = qco.measure %355 : !qco.qubit
    cbit.store %result_142, %8[%c5] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_133 : !qco.qubit
    qco.sink %qubit_out_135 : !qco.qubit
    qco.sink %qubit_out_137 : !qco.qubit
    qco.sink %qubit_out_139 : !qco.qubit
    qco.sink %qubit_out_141 : !qco.qubit
    %qubit_out_143, %result_144 = qco.measure %447 : !qco.qubit
    qco.sink %qubit_out_143 : !qco.qubit
    cbit.store %result_144, %8[%c6] : !cbit.reg<7>
    qco.sink %targets_out_48 : !qco.qubit
    %cst_145 = arith.constant -0.60132046885114043 : f64
    qco.gphase(%cst_145)
    return %8 : !cbit.reg<7>
  }
}
