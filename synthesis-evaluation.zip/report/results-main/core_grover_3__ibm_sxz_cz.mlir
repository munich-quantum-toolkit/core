module attributes {mqt.layout = {initial = array<i64: 0, 1, 2>, input_count = 3 : i64, sites = array<i64: 0, 1, 2>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 0.78539816339744795 : f64
    %cst_0 = arith.constant -2.3561944901923448 : f64
    %cst_1 = arith.constant -3.9269908169872414 : f64
    %cst_2 = arith.constant -3.1415926535897931 : f64
    %cst_3 = arith.constant -1.5707963267948966 : f64
    %cst_4 = arith.constant 4.7123889803846897 : f64
    %cst_5 = arith.constant -4.7123889803846897 : f64
    %cst_6 = arith.constant 0.78539816339744828 : f64
    %cst_7 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %4 = qco.rz(%cst_7) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.sx %4 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_7) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_3) %1 : !qco.qubit -> !qco.qubit
    %8 = qco.sx %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_7) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_7) %2 : !qco.qubit -> !qco.qubit
    %11 = qco.sx %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_2) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.sx %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_4) %13 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%9) targets (%arg0 = %14) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qco.rz(%cst_3) %targets_out : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_1) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_4) %18 : !qco.qubit -> !qco.qubit
    %controls_out_8, %targets_out_9 = qco.ctrl(%6) targets (%arg0 = %19) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.rz(%cst_3) %targets_out_9 : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_0) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.sx %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_4) %23 : !qco.qubit -> !qco.qubit
    %controls_out_10, %targets_out_11 = qco.ctrl(%controls_out) targets (%arg0 = %24) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %25 = qco.rz(%cst_3) %targets_out_11 : !qco.qubit -> !qco.qubit
    %26 = qco.sx %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_1) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_4) %28 : !qco.qubit -> !qco.qubit
    %controls_out_12, %targets_out_13 = qco.ctrl(%controls_out_8) targets (%arg0 = %29) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.rz(%cst_3) %targets_out_13 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_1) %controls_out_10 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %32 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_2) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.sx %33 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_4) %36 : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%controls_out_12) targets (%arg0 = %37) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qco.rz(%cst_3) %targets_out_15 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_1) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_6) %controls_out_14 : !qco.qubit -> !qco.qubit
    %42 = qco.sx %40 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_4) %42 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%41) targets (%arg0 = %43) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = qco.rz(%cst_3) %targets_out_17 : !qco.qubit -> !qco.qubit
    %45 = qco.sx %44 : !qco.qubit -> !qco.qubit
    %46 = qco.sx %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_3) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_3) %controls_out_16 : !qco.qubit -> !qco.qubit
    %49 = qco.sx %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_7) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.sx %35 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_4) %51 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%47) targets (%arg0 = %52) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qco.rz(%cst_3) %targets_out_19 : !qco.qubit -> !qco.qubit
    %54 = qco.sx %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_1) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.sx %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_4) %56 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%50) targets (%arg0 = %57) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = qco.rz(%cst_3) %targets_out_21 : !qco.qubit -> !qco.qubit
    %59 = qco.sx %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_0) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.sx %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_4) %61 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%controls_out_18) targets (%arg0 = %62) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %63 = qco.rz(%cst_3) %targets_out_23 : !qco.qubit -> !qco.qubit
    %64 = qco.sx %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_1) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.sx %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_4) %66 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%controls_out_20) targets (%arg0 = %67) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %68 = qco.rz(%cst_3) %targets_out_25 : !qco.qubit -> !qco.qubit
    %69 = qco.sx %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_0) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_1) %controls_out_22 : !qco.qubit -> !qco.qubit
    %72 = qco.sx %70 : !qco.qubit -> !qco.qubit
    %73 = qco.sx %71 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_4) %73 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%controls_out_24) targets (%arg0 = %74) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %75 = qco.rz(%cst_3) %targets_out_27 : !qco.qubit -> !qco.qubit
    %76 = qco.sx %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_1) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_6) %controls_out_26 : !qco.qubit -> !qco.qubit
    %79 = qco.sx %77 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_4) %79 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%78) targets (%arg0 = %80) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %81 = qco.rz(%cst_3) %targets_out_29 : !qco.qubit -> !qco.qubit
    %82 = qco.sx %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_5) %controls_out_28 : !qco.qubit -> !qco.qubit
    %84 = qco.sx %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_4) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.sx %82 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_3) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.sx %72 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_4) %88 : !qco.qubit -> !qco.qubit
    %controls_out_30, %targets_out_31 = qco.ctrl(%87) targets (%arg0 = %89) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %90 = qco.rz(%cst_3) %targets_out_31 : !qco.qubit -> !qco.qubit
    %91 = qco.sx %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_1) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.sx %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_4) %93 : !qco.qubit -> !qco.qubit
    %controls_out_32, %targets_out_33 = qco.ctrl(%85) targets (%arg0 = %94) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %95 = qco.rz(%cst_3) %targets_out_33 : !qco.qubit -> !qco.qubit
    %96 = qco.sx %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_0) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.sx %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_4) %98 : !qco.qubit -> !qco.qubit
    %controls_out_34, %targets_out_35 = qco.ctrl(%controls_out_30) targets (%arg0 = %99) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %100 = qco.rz(%cst_3) %targets_out_35 : !qco.qubit -> !qco.qubit
    %101 = qco.sx %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_1) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.sx %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_4) %103 : !qco.qubit -> !qco.qubit
    %controls_out_36, %targets_out_37 = qco.ctrl(%controls_out_32) targets (%arg0 = %104) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %105 = qco.rz(%cst_3) %targets_out_37 : !qco.qubit -> !qco.qubit
    %106 = qco.sx %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rz(%cst) %106 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_1) %controls_out_34 : !qco.qubit -> !qco.qubit
    %109 = qco.sx %107 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst_2) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.sx %108 : !qco.qubit -> !qco.qubit
    %112 = qco.rz(%cst_4) %111 : !qco.qubit -> !qco.qubit
    %controls_out_38, %targets_out_39 = qco.ctrl(%controls_out_36) targets (%arg0 = %112) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %113 = qco.rz(%cst_3) %targets_out_39 : !qco.qubit -> !qco.qubit
    %114 = qco.sx %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_1) %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst_6) %controls_out_38 : !qco.qubit -> !qco.qubit
    %117 = qco.sx %115 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_4) %117 : !qco.qubit -> !qco.qubit
    %controls_out_40, %targets_out_41 = qco.ctrl(%116) targets (%arg0 = %118) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %119 = qco.rz(%cst_3) %targets_out_41 : !qco.qubit -> !qco.qubit
    %120 = qco.sx %119 : !qco.qubit -> !qco.qubit
    %121 = qco.sx %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rz(%cst_3) %121 : !qco.qubit -> !qco.qubit
    %123 = qco.rz(%cst_3) %controls_out_40 : !qco.qubit -> !qco.qubit
    %124 = qco.sx %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rz(%cst_7) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.sx %110 : !qco.qubit -> !qco.qubit
    %127 = qco.rz(%cst_4) %126 : !qco.qubit -> !qco.qubit
    %controls_out_42, %targets_out_43 = qco.ctrl(%122) targets (%arg0 = %127) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %128 = qco.rz(%cst_3) %targets_out_43 : !qco.qubit -> !qco.qubit
    %129 = qco.sx %128 : !qco.qubit -> !qco.qubit
    %130 = qco.rz(%cst_1) %129 : !qco.qubit -> !qco.qubit
    %131 = qco.sx %130 : !qco.qubit -> !qco.qubit
    %132 = qco.rz(%cst_4) %131 : !qco.qubit -> !qco.qubit
    %controls_out_44, %targets_out_45 = qco.ctrl(%125) targets (%arg0 = %132) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %133 = qco.rz(%cst_3) %targets_out_45 : !qco.qubit -> !qco.qubit
    %134 = qco.sx %133 : !qco.qubit -> !qco.qubit
    %135 = qco.rz(%cst_0) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.sx %135 : !qco.qubit -> !qco.qubit
    %137 = qco.rz(%cst_4) %136 : !qco.qubit -> !qco.qubit
    %controls_out_46, %targets_out_47 = qco.ctrl(%controls_out_42) targets (%arg0 = %137) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %138 = qco.rz(%cst_3) %targets_out_47 : !qco.qubit -> !qco.qubit
    %139 = qco.sx %138 : !qco.qubit -> !qco.qubit
    %140 = qco.rz(%cst_1) %139 : !qco.qubit -> !qco.qubit
    %141 = qco.sx %140 : !qco.qubit -> !qco.qubit
    %142 = qco.rz(%cst_4) %141 : !qco.qubit -> !qco.qubit
    %controls_out_48, %targets_out_49 = qco.ctrl(%controls_out_44) targets (%arg0 = %142) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %143 = qco.rz(%cst_3) %targets_out_49 : !qco.qubit -> !qco.qubit
    %144 = qco.sx %143 : !qco.qubit -> !qco.qubit
    %145 = qco.rz(%cst_0) %144 : !qco.qubit -> !qco.qubit
    %146 = qco.rz(%cst_1) %controls_out_46 : !qco.qubit -> !qco.qubit
    %147 = qco.sx %145 : !qco.qubit -> !qco.qubit
    %148 = qco.rz(%cst_4) %147 : !qco.qubit -> !qco.qubit
    %149 = qco.sx %146 : !qco.qubit -> !qco.qubit
    %150 = qco.rz(%cst_4) %149 : !qco.qubit -> !qco.qubit
    %controls_out_50, %targets_out_51 = qco.ctrl(%controls_out_48) targets (%arg0 = %150) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %151 = qco.rz(%cst_3) %targets_out_51 : !qco.qubit -> !qco.qubit
    %152 = qco.sx %151 : !qco.qubit -> !qco.qubit
    %153 = qco.rz(%cst_1) %152 : !qco.qubit -> !qco.qubit
    %154 = qco.rz(%cst_6) %controls_out_50 : !qco.qubit -> !qco.qubit
    %155 = qco.sx %153 : !qco.qubit -> !qco.qubit
    %156 = qco.rz(%cst_4) %155 : !qco.qubit -> !qco.qubit
    %controls_out_52, %targets_out_53 = qco.ctrl(%154) targets (%arg0 = %156) {
      %165 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %165 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %157 = qco.rz(%cst_3) %targets_out_53 : !qco.qubit -> !qco.qubit
    %158 = qco.sx %157 : !qco.qubit -> !qco.qubit
    %159 = qco.rz(%cst_2) %158 : !qco.qubit -> !qco.qubit
    %160 = qco.rz(%cst_5) %controls_out_52 : !qco.qubit -> !qco.qubit
    %161 = qco.sx %160 : !qco.qubit -> !qco.qubit
    %162 = qco.rz(%cst_4) %161 : !qco.qubit -> !qco.qubit
    %163 = qco.sx %159 : !qco.qubit -> !qco.qubit
    %164 = qco.rz(%cst_4) %163 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %162 : !qco.qubit
    cbit.store %result, %3[%c0] : !cbit.reg<3>
    %qubit_out_54, %result_55 = qco.measure %164 : !qco.qubit
    cbit.store %result_55, %3[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_54 : !qco.qubit
    %qubit_out_56, %result_57 = qco.measure %148 : !qco.qubit
    qco.sink %qubit_out_56 : !qco.qubit
    cbit.store %result_57, %3[%c2] : !cbit.reg<3>
    qco.gphase(%cst_0)
    return %3 : !cbit.reg<3>
  }
}
