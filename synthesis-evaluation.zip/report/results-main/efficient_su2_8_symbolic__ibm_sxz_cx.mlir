module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main(%arg0: f64 {mqt.input_id = 44246249981895013191645689038461798644 : i128, mqt.input_name = "\CE\B8[0]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 0 : i64, name = "\CE\B8", size = 64 : i64}}, %arg1: f64 {mqt.input_id = 44246249981895013191645689038461798645 : i128, mqt.input_name = "\CE\B8[1]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 1 : i64, name = "\CE\B8", size = 64 : i64}}, %arg2: f64 {mqt.input_id = 44246249981895013191645689038461798646 : i128, mqt.input_name = "\CE\B8[2]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 2 : i64, name = "\CE\B8", size = 64 : i64}}, %arg3: f64 {mqt.input_id = 44246249981895013191645689038461798647 : i128, mqt.input_name = "\CE\B8[3]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 3 : i64, name = "\CE\B8", size = 64 : i64}}, %arg4: f64 {mqt.input_id = 44246249981895013191645689038461798648 : i128, mqt.input_name = "\CE\B8[4]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 4 : i64, name = "\CE\B8", size = 64 : i64}}, %arg5: f64 {mqt.input_id = 44246249981895013191645689038461798649 : i128, mqt.input_name = "\CE\B8[5]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 5 : i64, name = "\CE\B8", size = 64 : i64}}, %arg6: f64 {mqt.input_id = 44246249981895013191645689038461798650 : i128, mqt.input_name = "\CE\B8[6]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 6 : i64, name = "\CE\B8", size = 64 : i64}}, %arg7: f64 {mqt.input_id = 44246249981895013191645689038461798651 : i128, mqt.input_name = "\CE\B8[7]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 7 : i64, name = "\CE\B8", size = 64 : i64}}, %arg8: f64 {mqt.input_id = 44246249981895013191645689038461798652 : i128, mqt.input_name = "\CE\B8[8]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 8 : i64, name = "\CE\B8", size = 64 : i64}}, %arg9: f64 {mqt.input_id = 44246249981895013191645689038461798653 : i128, mqt.input_name = "\CE\B8[9]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 9 : i64, name = "\CE\B8", size = 64 : i64}}, %arg10: f64 {mqt.input_id = 44246249981895013191645689038461798654 : i128, mqt.input_name = "\CE\B8[10]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 10 : i64, name = "\CE\B8", size = 64 : i64}}, %arg11: f64 {mqt.input_id = 44246249981895013191645689038461798655 : i128, mqt.input_name = "\CE\B8[11]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 11 : i64, name = "\CE\B8", size = 64 : i64}}, %arg12: f64 {mqt.input_id = 44246249981895013191645689038461798656 : i128, mqt.input_name = "\CE\B8[12]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 12 : i64, name = "\CE\B8", size = 64 : i64}}, %arg13: f64 {mqt.input_id = 44246249981895013191645689038461798657 : i128, mqt.input_name = "\CE\B8[13]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 13 : i64, name = "\CE\B8", size = 64 : i64}}, %arg14: f64 {mqt.input_id = 44246249981895013191645689038461798658 : i128, mqt.input_name = "\CE\B8[14]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 14 : i64, name = "\CE\B8", size = 64 : i64}}, %arg15: f64 {mqt.input_id = 44246249981895013191645689038461798659 : i128, mqt.input_name = "\CE\B8[15]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 15 : i64, name = "\CE\B8", size = 64 : i64}}, %arg16: f64 {mqt.input_id = 44246249981895013191645689038461798660 : i128, mqt.input_name = "\CE\B8[16]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 16 : i64, name = "\CE\B8", size = 64 : i64}}, %arg17: f64 {mqt.input_id = 44246249981895013191645689038461798661 : i128, mqt.input_name = "\CE\B8[17]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 17 : i64, name = "\CE\B8", size = 64 : i64}}, %arg18: f64 {mqt.input_id = 44246249981895013191645689038461798662 : i128, mqt.input_name = "\CE\B8[18]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 18 : i64, name = "\CE\B8", size = 64 : i64}}, %arg19: f64 {mqt.input_id = 44246249981895013191645689038461798663 : i128, mqt.input_name = "\CE\B8[19]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 19 : i64, name = "\CE\B8", size = 64 : i64}}, %arg20: f64 {mqt.input_id = 44246249981895013191645689038461798664 : i128, mqt.input_name = "\CE\B8[20]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 20 : i64, name = "\CE\B8", size = 64 : i64}}, %arg21: f64 {mqt.input_id = 44246249981895013191645689038461798665 : i128, mqt.input_name = "\CE\B8[21]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 21 : i64, name = "\CE\B8", size = 64 : i64}}, %arg22: f64 {mqt.input_id = 44246249981895013191645689038461798666 : i128, mqt.input_name = "\CE\B8[22]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 22 : i64, name = "\CE\B8", size = 64 : i64}}, %arg23: f64 {mqt.input_id = 44246249981895013191645689038461798667 : i128, mqt.input_name = "\CE\B8[23]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 23 : i64, name = "\CE\B8", size = 64 : i64}}, %arg24: f64 {mqt.input_id = 44246249981895013191645689038461798668 : i128, mqt.input_name = "\CE\B8[24]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 24 : i64, name = "\CE\B8", size = 64 : i64}}, %arg25: f64 {mqt.input_id = 44246249981895013191645689038461798669 : i128, mqt.input_name = "\CE\B8[25]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 25 : i64, name = "\CE\B8", size = 64 : i64}}, %arg26: f64 {mqt.input_id = 44246249981895013191645689038461798670 : i128, mqt.input_name = "\CE\B8[26]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 26 : i64, name = "\CE\B8", size = 64 : i64}}, %arg27: f64 {mqt.input_id = 44246249981895013191645689038461798671 : i128, mqt.input_name = "\CE\B8[27]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 27 : i64, name = "\CE\B8", size = 64 : i64}}, %arg28: f64 {mqt.input_id = 44246249981895013191645689038461798672 : i128, mqt.input_name = "\CE\B8[28]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 28 : i64, name = "\CE\B8", size = 64 : i64}}, %arg29: f64 {mqt.input_id = 44246249981895013191645689038461798673 : i128, mqt.input_name = "\CE\B8[29]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 29 : i64, name = "\CE\B8", size = 64 : i64}}, %arg30: f64 {mqt.input_id = 44246249981895013191645689038461798674 : i128, mqt.input_name = "\CE\B8[30]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 30 : i64, name = "\CE\B8", size = 64 : i64}}, %arg31: f64 {mqt.input_id = 44246249981895013191645689038461798675 : i128, mqt.input_name = "\CE\B8[31]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 31 : i64, name = "\CE\B8", size = 64 : i64}}, %arg32: f64 {mqt.input_id = 44246249981895013191645689038461798676 : i128, mqt.input_name = "\CE\B8[32]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 32 : i64, name = "\CE\B8", size = 64 : i64}}, %arg33: f64 {mqt.input_id = 44246249981895013191645689038461798677 : i128, mqt.input_name = "\CE\B8[33]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 33 : i64, name = "\CE\B8", size = 64 : i64}}, %arg34: f64 {mqt.input_id = 44246249981895013191645689038461798678 : i128, mqt.input_name = "\CE\B8[34]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 34 : i64, name = "\CE\B8", size = 64 : i64}}, %arg35: f64 {mqt.input_id = 44246249981895013191645689038461798679 : i128, mqt.input_name = "\CE\B8[35]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 35 : i64, name = "\CE\B8", size = 64 : i64}}, %arg36: f64 {mqt.input_id = 44246249981895013191645689038461798680 : i128, mqt.input_name = "\CE\B8[36]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 36 : i64, name = "\CE\B8", size = 64 : i64}}, %arg37: f64 {mqt.input_id = 44246249981895013191645689038461798681 : i128, mqt.input_name = "\CE\B8[37]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 37 : i64, name = "\CE\B8", size = 64 : i64}}, %arg38: f64 {mqt.input_id = 44246249981895013191645689038461798682 : i128, mqt.input_name = "\CE\B8[38]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 38 : i64, name = "\CE\B8", size = 64 : i64}}, %arg39: f64 {mqt.input_id = 44246249981895013191645689038461798683 : i128, mqt.input_name = "\CE\B8[39]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 39 : i64, name = "\CE\B8", size = 64 : i64}}, %arg40: f64 {mqt.input_id = 44246249981895013191645689038461798684 : i128, mqt.input_name = "\CE\B8[40]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 40 : i64, name = "\CE\B8", size = 64 : i64}}, %arg41: f64 {mqt.input_id = 44246249981895013191645689038461798685 : i128, mqt.input_name = "\CE\B8[41]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 41 : i64, name = "\CE\B8", size = 64 : i64}}, %arg42: f64 {mqt.input_id = 44246249981895013191645689038461798686 : i128, mqt.input_name = "\CE\B8[42]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 42 : i64, name = "\CE\B8", size = 64 : i64}}, %arg43: f64 {mqt.input_id = 44246249981895013191645689038461798687 : i128, mqt.input_name = "\CE\B8[43]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 43 : i64, name = "\CE\B8", size = 64 : i64}}, %arg44: f64 {mqt.input_id = 44246249981895013191645689038461798688 : i128, mqt.input_name = "\CE\B8[44]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 44 : i64, name = "\CE\B8", size = 64 : i64}}, %arg45: f64 {mqt.input_id = 44246249981895013191645689038461798689 : i128, mqt.input_name = "\CE\B8[45]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 45 : i64, name = "\CE\B8", size = 64 : i64}}, %arg46: f64 {mqt.input_id = 44246249981895013191645689038461798690 : i128, mqt.input_name = "\CE\B8[46]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 46 : i64, name = "\CE\B8", size = 64 : i64}}, %arg47: f64 {mqt.input_id = 44246249981895013191645689038461798691 : i128, mqt.input_name = "\CE\B8[47]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 47 : i64, name = "\CE\B8", size = 64 : i64}}, %arg48: f64 {mqt.input_id = 44246249981895013191645689038461798692 : i128, mqt.input_name = "\CE\B8[48]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 48 : i64, name = "\CE\B8", size = 64 : i64}}, %arg49: f64 {mqt.input_id = 44246249981895013191645689038461798693 : i128, mqt.input_name = "\CE\B8[49]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 49 : i64, name = "\CE\B8", size = 64 : i64}}, %arg50: f64 {mqt.input_id = 44246249981895013191645689038461798694 : i128, mqt.input_name = "\CE\B8[50]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 50 : i64, name = "\CE\B8", size = 64 : i64}}, %arg51: f64 {mqt.input_id = 44246249981895013191645689038461798695 : i128, mqt.input_name = "\CE\B8[51]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 51 : i64, name = "\CE\B8", size = 64 : i64}}, %arg52: f64 {mqt.input_id = 44246249981895013191645689038461798696 : i128, mqt.input_name = "\CE\B8[52]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 52 : i64, name = "\CE\B8", size = 64 : i64}}, %arg53: f64 {mqt.input_id = 44246249981895013191645689038461798697 : i128, mqt.input_name = "\CE\B8[53]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 53 : i64, name = "\CE\B8", size = 64 : i64}}, %arg54: f64 {mqt.input_id = 44246249981895013191645689038461798698 : i128, mqt.input_name = "\CE\B8[54]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 54 : i64, name = "\CE\B8", size = 64 : i64}}, %arg55: f64 {mqt.input_id = 44246249981895013191645689038461798699 : i128, mqt.input_name = "\CE\B8[55]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 55 : i64, name = "\CE\B8", size = 64 : i64}}, %arg56: f64 {mqt.input_id = 44246249981895013191645689038461798700 : i128, mqt.input_name = "\CE\B8[56]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 56 : i64, name = "\CE\B8", size = 64 : i64}}, %arg57: f64 {mqt.input_id = 44246249981895013191645689038461798701 : i128, mqt.input_name = "\CE\B8[57]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 57 : i64, name = "\CE\B8", size = 64 : i64}}, %arg58: f64 {mqt.input_id = 44246249981895013191645689038461798702 : i128, mqt.input_name = "\CE\B8[58]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 58 : i64, name = "\CE\B8", size = 64 : i64}}, %arg59: f64 {mqt.input_id = 44246249981895013191645689038461798703 : i128, mqt.input_name = "\CE\B8[59]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 59 : i64, name = "\CE\B8", size = 64 : i64}}, %arg60: f64 {mqt.input_id = 44246249981895013191645689038461798704 : i128, mqt.input_name = "\CE\B8[60]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 60 : i64, name = "\CE\B8", size = 64 : i64}}, %arg61: f64 {mqt.input_id = 44246249981895013191645689038461798705 : i128, mqt.input_name = "\CE\B8[61]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 61 : i64, name = "\CE\B8", size = 64 : i64}}, %arg62: f64 {mqt.input_id = 44246249981895013191645689038461798706 : i128, mqt.input_name = "\CE\B8[62]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 62 : i64, name = "\CE\B8", size = 64 : i64}}, %arg63: f64 {mqt.input_id = 44246249981895013191645689038461798707 : i128, mqt.input_name = "\CE\B8[63]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 63 : i64, name = "\CE\B8", size = 64 : i64}}) -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 4.000000e+00 : f64
    %cst_0 = arith.constant 3.1415926535897931 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = arith.divf %arg0, %cst : f64
    %9 = math.tan %8 : f64
    %10 = math.atan %9 : f64
    %11 = arith.mulf %10, %cst : f64
    %12 = qco.sx %0 : !qco.qubit -> !qco.qubit
    %13 = arith.addf %11, %cst_0 : f64
    %14 = qco.rz(%13) %12 : !qco.qubit -> !qco.qubit
    %15 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %16 = arith.divf %arg1, %cst : f64
    %17 = math.tan %16 : f64
    %18 = math.atan %17 : f64
    %19 = arith.mulf %18, %cst : f64
    %20 = qco.sx %1 : !qco.qubit -> !qco.qubit
    %21 = arith.addf %19, %cst_0 : f64
    %22 = qco.rz(%21) %20 : !qco.qubit -> !qco.qubit
    %23 = qco.sx %22 : !qco.qubit -> !qco.qubit
    %24 = arith.divf %arg2, %cst : f64
    %25 = math.tan %24 : f64
    %26 = math.atan %25 : f64
    %27 = arith.mulf %26, %cst : f64
    %28 = qco.sx %2 : !qco.qubit -> !qco.qubit
    %29 = arith.addf %27, %cst_0 : f64
    %30 = qco.rz(%29) %28 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %32 = arith.divf %arg3, %cst : f64
    %33 = math.tan %32 : f64
    %34 = math.atan %33 : f64
    %35 = arith.mulf %34, %cst : f64
    %36 = qco.sx %3 : !qco.qubit -> !qco.qubit
    %37 = arith.addf %35, %cst_0 : f64
    %38 = qco.rz(%37) %36 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %38 : !qco.qubit -> !qco.qubit
    %40 = arith.divf %arg4, %cst : f64
    %41 = math.tan %40 : f64
    %42 = math.atan %41 : f64
    %43 = arith.mulf %42, %cst : f64
    %44 = qco.sx %4 : !qco.qubit -> !qco.qubit
    %45 = arith.addf %43, %cst_0 : f64
    %46 = qco.rz(%45) %44 : !qco.qubit -> !qco.qubit
    %47 = qco.sx %46 : !qco.qubit -> !qco.qubit
    %48 = arith.divf %arg5, %cst : f64
    %49 = math.tan %48 : f64
    %50 = math.atan %49 : f64
    %51 = arith.mulf %50, %cst : f64
    %52 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %53 = arith.addf %51, %cst_0 : f64
    %54 = qco.rz(%53) %52 : !qco.qubit -> !qco.qubit
    %55 = qco.sx %54 : !qco.qubit -> !qco.qubit
    %56 = arith.divf %arg6, %cst : f64
    %57 = math.tan %56 : f64
    %58 = math.atan %57 : f64
    %59 = arith.mulf %58, %cst : f64
    %60 = qco.sx %6 : !qco.qubit -> !qco.qubit
    %61 = arith.addf %59, %cst_0 : f64
    %62 = qco.rz(%61) %60 : !qco.qubit -> !qco.qubit
    %63 = qco.sx %62 : !qco.qubit -> !qco.qubit
    %64 = arith.divf %arg7, %cst : f64
    %65 = math.tan %64 : f64
    %66 = math.atan %65 : f64
    %67 = arith.mulf %66, %cst : f64
    %68 = qco.sx %7 : !qco.qubit -> !qco.qubit
    %69 = arith.addf %67, %cst_0 : f64
    %70 = qco.rz(%69) %68 : !qco.qubit -> !qco.qubit
    %71 = qco.sx %70 : !qco.qubit -> !qco.qubit
    %72 = arith.divf %arg8, %cst : f64
    %73 = math.tan %72 : f64
    %74 = math.atan %73 : f64
    %75 = arith.mulf %74, %cst : f64
    %76 = arith.addf %75, %cst_0 : f64
    %77 = qco.rz(%76) %15 : !qco.qubit -> !qco.qubit
    %78 = arith.divf %arg9, %cst : f64
    %79 = math.tan %78 : f64
    %80 = math.atan %79 : f64
    %81 = arith.mulf %80, %cst : f64
    %82 = arith.addf %81, %cst_0 : f64
    %83 = qco.rz(%82) %23 : !qco.qubit -> !qco.qubit
    %84 = arith.divf %arg10, %cst : f64
    %85 = math.tan %84 : f64
    %86 = math.atan %85 : f64
    %87 = arith.mulf %86, %cst : f64
    %88 = arith.addf %87, %cst_0 : f64
    %89 = qco.rz(%88) %31 : !qco.qubit -> !qco.qubit
    %90 = arith.divf %arg11, %cst : f64
    %91 = math.tan %90 : f64
    %92 = math.atan %91 : f64
    %93 = arith.mulf %92, %cst : f64
    %94 = arith.addf %93, %cst_0 : f64
    %95 = qco.rz(%94) %39 : !qco.qubit -> !qco.qubit
    %96 = arith.divf %arg12, %cst : f64
    %97 = math.tan %96 : f64
    %98 = math.atan %97 : f64
    %99 = arith.mulf %98, %cst : f64
    %100 = arith.addf %99, %cst_0 : f64
    %101 = qco.rz(%100) %47 : !qco.qubit -> !qco.qubit
    %102 = arith.divf %arg13, %cst : f64
    %103 = math.tan %102 : f64
    %104 = math.atan %103 : f64
    %105 = arith.mulf %104, %cst : f64
    %106 = arith.addf %105, %cst_0 : f64
    %107 = qco.rz(%106) %55 : !qco.qubit -> !qco.qubit
    %108 = arith.divf %arg14, %cst : f64
    %109 = math.tan %108 : f64
    %110 = math.atan %109 : f64
    %111 = arith.mulf %110, %cst : f64
    %112 = arith.addf %111, %cst_0 : f64
    %113 = qco.rz(%112) %63 : !qco.qubit -> !qco.qubit
    %114 = arith.divf %arg15, %cst : f64
    %115 = math.tan %114 : f64
    %116 = math.atan %115 : f64
    %117 = arith.mulf %116, %cst : f64
    %118 = arith.addf %117, %cst_0 : f64
    %119 = qco.rz(%118) %71 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%119) targets (%arg64 = %77) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_1, %targets_out_2 = qco.ctrl(%targets_out) targets (%arg64 = %83) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_3, %targets_out_4 = qco.ctrl(%targets_out_2) targets (%arg64 = %89) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_5, %targets_out_6 = qco.ctrl(%targets_out_4) targets (%arg64 = %95) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_7, %targets_out_8 = qco.ctrl(%targets_out_6) targets (%arg64 = %101) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_9, %targets_out_10 = qco.ctrl(%targets_out_8) targets (%arg64 = %107) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_11, %targets_out_12 = qco.ctrl(%targets_out_10) targets (%arg64 = %113) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_13, %targets_out_14 = qco.ctrl(%targets_out_12) targets (%arg64 = %controls_out) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %120 = arith.divf %arg16, %cst : f64
    %121 = math.tan %120 : f64
    %122 = math.atan %121 : f64
    %123 = arith.mulf %122, %cst : f64
    %124 = qco.sx %controls_out_1 : !qco.qubit -> !qco.qubit
    %125 = arith.addf %123, %cst_0 : f64
    %126 = qco.rz(%125) %124 : !qco.qubit -> !qco.qubit
    %127 = qco.sx %126 : !qco.qubit -> !qco.qubit
    %128 = arith.divf %arg17, %cst : f64
    %129 = math.tan %128 : f64
    %130 = math.atan %129 : f64
    %131 = arith.mulf %130, %cst : f64
    %132 = qco.sx %controls_out_3 : !qco.qubit -> !qco.qubit
    %133 = arith.addf %131, %cst_0 : f64
    %134 = qco.rz(%133) %132 : !qco.qubit -> !qco.qubit
    %135 = qco.sx %134 : !qco.qubit -> !qco.qubit
    %136 = arith.divf %arg18, %cst : f64
    %137 = math.tan %136 : f64
    %138 = math.atan %137 : f64
    %139 = arith.mulf %138, %cst : f64
    %140 = qco.sx %controls_out_5 : !qco.qubit -> !qco.qubit
    %141 = arith.addf %139, %cst_0 : f64
    %142 = qco.rz(%141) %140 : !qco.qubit -> !qco.qubit
    %143 = qco.sx %142 : !qco.qubit -> !qco.qubit
    %144 = arith.divf %arg19, %cst : f64
    %145 = math.tan %144 : f64
    %146 = math.atan %145 : f64
    %147 = arith.mulf %146, %cst : f64
    %148 = qco.sx %controls_out_7 : !qco.qubit -> !qco.qubit
    %149 = arith.addf %147, %cst_0 : f64
    %150 = qco.rz(%149) %148 : !qco.qubit -> !qco.qubit
    %151 = qco.sx %150 : !qco.qubit -> !qco.qubit
    %152 = arith.divf %arg20, %cst : f64
    %153 = math.tan %152 : f64
    %154 = math.atan %153 : f64
    %155 = arith.mulf %154, %cst : f64
    %156 = qco.sx %controls_out_9 : !qco.qubit -> !qco.qubit
    %157 = arith.addf %155, %cst_0 : f64
    %158 = qco.rz(%157) %156 : !qco.qubit -> !qco.qubit
    %159 = qco.sx %158 : !qco.qubit -> !qco.qubit
    %160 = arith.divf %arg21, %cst : f64
    %161 = math.tan %160 : f64
    %162 = math.atan %161 : f64
    %163 = arith.mulf %162, %cst : f64
    %164 = qco.sx %controls_out_11 : !qco.qubit -> !qco.qubit
    %165 = arith.addf %163, %cst_0 : f64
    %166 = qco.rz(%165) %164 : !qco.qubit -> !qco.qubit
    %167 = qco.sx %166 : !qco.qubit -> !qco.qubit
    %168 = arith.divf %arg22, %cst : f64
    %169 = math.tan %168 : f64
    %170 = math.atan %169 : f64
    %171 = arith.mulf %170, %cst : f64
    %172 = qco.sx %controls_out_13 : !qco.qubit -> !qco.qubit
    %173 = arith.addf %171, %cst_0 : f64
    %174 = qco.rz(%173) %172 : !qco.qubit -> !qco.qubit
    %175 = qco.sx %174 : !qco.qubit -> !qco.qubit
    %176 = arith.divf %arg23, %cst : f64
    %177 = math.tan %176 : f64
    %178 = math.atan %177 : f64
    %179 = arith.mulf %178, %cst : f64
    %180 = qco.sx %targets_out_14 : !qco.qubit -> !qco.qubit
    %181 = arith.addf %179, %cst_0 : f64
    %182 = qco.rz(%181) %180 : !qco.qubit -> !qco.qubit
    %183 = qco.sx %182 : !qco.qubit -> !qco.qubit
    %184 = arith.divf %arg24, %cst : f64
    %185 = math.tan %184 : f64
    %186 = math.atan %185 : f64
    %187 = arith.mulf %186, %cst : f64
    %188 = arith.addf %187, %cst_0 : f64
    %189 = qco.rz(%188) %127 : !qco.qubit -> !qco.qubit
    %190 = arith.divf %arg25, %cst : f64
    %191 = math.tan %190 : f64
    %192 = math.atan %191 : f64
    %193 = arith.mulf %192, %cst : f64
    %194 = arith.addf %193, %cst_0 : f64
    %195 = qco.rz(%194) %135 : !qco.qubit -> !qco.qubit
    %196 = arith.divf %arg26, %cst : f64
    %197 = math.tan %196 : f64
    %198 = math.atan %197 : f64
    %199 = arith.mulf %198, %cst : f64
    %200 = arith.addf %199, %cst_0 : f64
    %201 = qco.rz(%200) %143 : !qco.qubit -> !qco.qubit
    %202 = arith.divf %arg27, %cst : f64
    %203 = math.tan %202 : f64
    %204 = math.atan %203 : f64
    %205 = arith.mulf %204, %cst : f64
    %206 = arith.addf %205, %cst_0 : f64
    %207 = qco.rz(%206) %151 : !qco.qubit -> !qco.qubit
    %208 = arith.divf %arg28, %cst : f64
    %209 = math.tan %208 : f64
    %210 = math.atan %209 : f64
    %211 = arith.mulf %210, %cst : f64
    %212 = arith.addf %211, %cst_0 : f64
    %213 = qco.rz(%212) %159 : !qco.qubit -> !qco.qubit
    %214 = arith.divf %arg29, %cst : f64
    %215 = math.tan %214 : f64
    %216 = math.atan %215 : f64
    %217 = arith.mulf %216, %cst : f64
    %218 = arith.addf %217, %cst_0 : f64
    %219 = qco.rz(%218) %167 : !qco.qubit -> !qco.qubit
    %220 = arith.divf %arg30, %cst : f64
    %221 = math.tan %220 : f64
    %222 = math.atan %221 : f64
    %223 = arith.mulf %222, %cst : f64
    %224 = arith.addf %223, %cst_0 : f64
    %225 = qco.rz(%224) %175 : !qco.qubit -> !qco.qubit
    %226 = arith.divf %arg31, %cst : f64
    %227 = math.tan %226 : f64
    %228 = math.atan %227 : f64
    %229 = arith.mulf %228, %cst : f64
    %230 = arith.addf %229, %cst_0 : f64
    %231 = qco.rz(%230) %183 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%231) targets (%arg64 = %189) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_17, %targets_out_18 = qco.ctrl(%targets_out_16) targets (%arg64 = %195) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_19, %targets_out_20 = qco.ctrl(%targets_out_18) targets (%arg64 = %201) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_21, %targets_out_22 = qco.ctrl(%targets_out_20) targets (%arg64 = %207) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_23, %targets_out_24 = qco.ctrl(%targets_out_22) targets (%arg64 = %213) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_25, %targets_out_26 = qco.ctrl(%targets_out_24) targets (%arg64 = %219) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_27, %targets_out_28 = qco.ctrl(%targets_out_26) targets (%arg64 = %225) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_29, %targets_out_30 = qco.ctrl(%targets_out_28) targets (%arg64 = %controls_out_15) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %232 = arith.divf %arg32, %cst : f64
    %233 = math.tan %232 : f64
    %234 = math.atan %233 : f64
    %235 = arith.mulf %234, %cst : f64
    %236 = qco.sx %controls_out_17 : !qco.qubit -> !qco.qubit
    %237 = arith.addf %235, %cst_0 : f64
    %238 = qco.rz(%237) %236 : !qco.qubit -> !qco.qubit
    %239 = qco.sx %238 : !qco.qubit -> !qco.qubit
    %240 = arith.divf %arg33, %cst : f64
    %241 = math.tan %240 : f64
    %242 = math.atan %241 : f64
    %243 = arith.mulf %242, %cst : f64
    %244 = qco.sx %controls_out_19 : !qco.qubit -> !qco.qubit
    %245 = arith.addf %243, %cst_0 : f64
    %246 = qco.rz(%245) %244 : !qco.qubit -> !qco.qubit
    %247 = qco.sx %246 : !qco.qubit -> !qco.qubit
    %248 = arith.divf %arg34, %cst : f64
    %249 = math.tan %248 : f64
    %250 = math.atan %249 : f64
    %251 = arith.mulf %250, %cst : f64
    %252 = qco.sx %controls_out_21 : !qco.qubit -> !qco.qubit
    %253 = arith.addf %251, %cst_0 : f64
    %254 = qco.rz(%253) %252 : !qco.qubit -> !qco.qubit
    %255 = qco.sx %254 : !qco.qubit -> !qco.qubit
    %256 = arith.divf %arg35, %cst : f64
    %257 = math.tan %256 : f64
    %258 = math.atan %257 : f64
    %259 = arith.mulf %258, %cst : f64
    %260 = qco.sx %controls_out_23 : !qco.qubit -> !qco.qubit
    %261 = arith.addf %259, %cst_0 : f64
    %262 = qco.rz(%261) %260 : !qco.qubit -> !qco.qubit
    %263 = qco.sx %262 : !qco.qubit -> !qco.qubit
    %264 = arith.divf %arg36, %cst : f64
    %265 = math.tan %264 : f64
    %266 = math.atan %265 : f64
    %267 = arith.mulf %266, %cst : f64
    %268 = qco.sx %controls_out_25 : !qco.qubit -> !qco.qubit
    %269 = arith.addf %267, %cst_0 : f64
    %270 = qco.rz(%269) %268 : !qco.qubit -> !qco.qubit
    %271 = qco.sx %270 : !qco.qubit -> !qco.qubit
    %272 = arith.divf %arg37, %cst : f64
    %273 = math.tan %272 : f64
    %274 = math.atan %273 : f64
    %275 = arith.mulf %274, %cst : f64
    %276 = qco.sx %controls_out_27 : !qco.qubit -> !qco.qubit
    %277 = arith.addf %275, %cst_0 : f64
    %278 = qco.rz(%277) %276 : !qco.qubit -> !qco.qubit
    %279 = qco.sx %278 : !qco.qubit -> !qco.qubit
    %280 = arith.divf %arg38, %cst : f64
    %281 = math.tan %280 : f64
    %282 = math.atan %281 : f64
    %283 = arith.mulf %282, %cst : f64
    %284 = qco.sx %controls_out_29 : !qco.qubit -> !qco.qubit
    %285 = arith.addf %283, %cst_0 : f64
    %286 = qco.rz(%285) %284 : !qco.qubit -> !qco.qubit
    %287 = qco.sx %286 : !qco.qubit -> !qco.qubit
    %288 = arith.divf %arg39, %cst : f64
    %289 = math.tan %288 : f64
    %290 = math.atan %289 : f64
    %291 = arith.mulf %290, %cst : f64
    %292 = qco.sx %targets_out_30 : !qco.qubit -> !qco.qubit
    %293 = arith.addf %291, %cst_0 : f64
    %294 = qco.rz(%293) %292 : !qco.qubit -> !qco.qubit
    %295 = qco.sx %294 : !qco.qubit -> !qco.qubit
    %296 = arith.divf %arg40, %cst : f64
    %297 = math.tan %296 : f64
    %298 = math.atan %297 : f64
    %299 = arith.mulf %298, %cst : f64
    %300 = arith.addf %299, %cst_0 : f64
    %301 = qco.rz(%300) %239 : !qco.qubit -> !qco.qubit
    %302 = arith.divf %arg41, %cst : f64
    %303 = math.tan %302 : f64
    %304 = math.atan %303 : f64
    %305 = arith.mulf %304, %cst : f64
    %306 = arith.addf %305, %cst_0 : f64
    %307 = qco.rz(%306) %247 : !qco.qubit -> !qco.qubit
    %308 = arith.divf %arg42, %cst : f64
    %309 = math.tan %308 : f64
    %310 = math.atan %309 : f64
    %311 = arith.mulf %310, %cst : f64
    %312 = arith.addf %311, %cst_0 : f64
    %313 = qco.rz(%312) %255 : !qco.qubit -> !qco.qubit
    %314 = arith.divf %arg43, %cst : f64
    %315 = math.tan %314 : f64
    %316 = math.atan %315 : f64
    %317 = arith.mulf %316, %cst : f64
    %318 = arith.addf %317, %cst_0 : f64
    %319 = qco.rz(%318) %263 : !qco.qubit -> !qco.qubit
    %320 = arith.divf %arg44, %cst : f64
    %321 = math.tan %320 : f64
    %322 = math.atan %321 : f64
    %323 = arith.mulf %322, %cst : f64
    %324 = arith.addf %323, %cst_0 : f64
    %325 = qco.rz(%324) %271 : !qco.qubit -> !qco.qubit
    %326 = arith.divf %arg45, %cst : f64
    %327 = math.tan %326 : f64
    %328 = math.atan %327 : f64
    %329 = arith.mulf %328, %cst : f64
    %330 = arith.addf %329, %cst_0 : f64
    %331 = qco.rz(%330) %279 : !qco.qubit -> !qco.qubit
    %332 = arith.divf %arg46, %cst : f64
    %333 = math.tan %332 : f64
    %334 = math.atan %333 : f64
    %335 = arith.mulf %334, %cst : f64
    %336 = arith.addf %335, %cst_0 : f64
    %337 = qco.rz(%336) %287 : !qco.qubit -> !qco.qubit
    %338 = arith.divf %arg47, %cst : f64
    %339 = math.tan %338 : f64
    %340 = math.atan %339 : f64
    %341 = arith.mulf %340, %cst : f64
    %342 = arith.addf %341, %cst_0 : f64
    %343 = qco.rz(%342) %295 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%343) targets (%arg64 = %301) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_33, %targets_out_34 = qco.ctrl(%targets_out_32) targets (%arg64 = %307) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_35, %targets_out_36 = qco.ctrl(%targets_out_34) targets (%arg64 = %313) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_37, %targets_out_38 = qco.ctrl(%targets_out_36) targets (%arg64 = %319) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_39, %targets_out_40 = qco.ctrl(%targets_out_38) targets (%arg64 = %325) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_41, %targets_out_42 = qco.ctrl(%targets_out_40) targets (%arg64 = %331) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_43, %targets_out_44 = qco.ctrl(%targets_out_42) targets (%arg64 = %337) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_45, %targets_out_46 = qco.ctrl(%targets_out_44) targets (%arg64 = %controls_out_31) {
      %456 = qco.x %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %456 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %344 = arith.divf %arg48, %cst : f64
    %345 = math.tan %344 : f64
    %346 = math.atan %345 : f64
    %347 = arith.mulf %346, %cst : f64
    %348 = qco.sx %controls_out_33 : !qco.qubit -> !qco.qubit
    %349 = arith.addf %347, %cst_0 : f64
    %350 = qco.rz(%349) %348 : !qco.qubit -> !qco.qubit
    %351 = qco.sx %350 : !qco.qubit -> !qco.qubit
    %352 = arith.divf %arg49, %cst : f64
    %353 = math.tan %352 : f64
    %354 = math.atan %353 : f64
    %355 = arith.mulf %354, %cst : f64
    %356 = qco.sx %controls_out_35 : !qco.qubit -> !qco.qubit
    %357 = arith.addf %355, %cst_0 : f64
    %358 = qco.rz(%357) %356 : !qco.qubit -> !qco.qubit
    %359 = qco.sx %358 : !qco.qubit -> !qco.qubit
    %360 = arith.divf %arg50, %cst : f64
    %361 = math.tan %360 : f64
    %362 = math.atan %361 : f64
    %363 = arith.mulf %362, %cst : f64
    %364 = qco.sx %controls_out_37 : !qco.qubit -> !qco.qubit
    %365 = arith.addf %363, %cst_0 : f64
    %366 = qco.rz(%365) %364 : !qco.qubit -> !qco.qubit
    %367 = qco.sx %366 : !qco.qubit -> !qco.qubit
    %368 = arith.divf %arg51, %cst : f64
    %369 = math.tan %368 : f64
    %370 = math.atan %369 : f64
    %371 = arith.mulf %370, %cst : f64
    %372 = qco.sx %controls_out_39 : !qco.qubit -> !qco.qubit
    %373 = arith.addf %371, %cst_0 : f64
    %374 = qco.rz(%373) %372 : !qco.qubit -> !qco.qubit
    %375 = qco.sx %374 : !qco.qubit -> !qco.qubit
    %376 = arith.divf %arg52, %cst : f64
    %377 = math.tan %376 : f64
    %378 = math.atan %377 : f64
    %379 = arith.mulf %378, %cst : f64
    %380 = qco.sx %controls_out_41 : !qco.qubit -> !qco.qubit
    %381 = arith.addf %379, %cst_0 : f64
    %382 = qco.rz(%381) %380 : !qco.qubit -> !qco.qubit
    %383 = qco.sx %382 : !qco.qubit -> !qco.qubit
    %384 = arith.divf %arg53, %cst : f64
    %385 = math.tan %384 : f64
    %386 = math.atan %385 : f64
    %387 = arith.mulf %386, %cst : f64
    %388 = qco.sx %controls_out_43 : !qco.qubit -> !qco.qubit
    %389 = arith.addf %387, %cst_0 : f64
    %390 = qco.rz(%389) %388 : !qco.qubit -> !qco.qubit
    %391 = qco.sx %390 : !qco.qubit -> !qco.qubit
    %392 = arith.divf %arg54, %cst : f64
    %393 = math.tan %392 : f64
    %394 = math.atan %393 : f64
    %395 = arith.mulf %394, %cst : f64
    %396 = qco.sx %controls_out_45 : !qco.qubit -> !qco.qubit
    %397 = arith.addf %395, %cst_0 : f64
    %398 = qco.rz(%397) %396 : !qco.qubit -> !qco.qubit
    %399 = qco.sx %398 : !qco.qubit -> !qco.qubit
    %400 = arith.divf %arg55, %cst : f64
    %401 = math.tan %400 : f64
    %402 = math.atan %401 : f64
    %403 = arith.mulf %402, %cst : f64
    %404 = qco.sx %targets_out_46 : !qco.qubit -> !qco.qubit
    %405 = arith.addf %403, %cst_0 : f64
    %406 = qco.rz(%405) %404 : !qco.qubit -> !qco.qubit
    %407 = qco.sx %406 : !qco.qubit -> !qco.qubit
    %408 = arith.divf %arg56, %cst : f64
    %409 = math.tan %408 : f64
    %410 = math.atan %409 : f64
    %411 = arith.mulf %410, %cst : f64
    %412 = arith.addf %411, %cst_0 : f64
    %413 = qco.rz(%412) %351 : !qco.qubit -> !qco.qubit
    %414 = arith.divf %arg57, %cst : f64
    %415 = math.tan %414 : f64
    %416 = math.atan %415 : f64
    %417 = arith.mulf %416, %cst : f64
    %418 = arith.addf %417, %cst_0 : f64
    %419 = qco.rz(%418) %359 : !qco.qubit -> !qco.qubit
    %420 = arith.divf %arg58, %cst : f64
    %421 = math.tan %420 : f64
    %422 = math.atan %421 : f64
    %423 = arith.mulf %422, %cst : f64
    %424 = arith.addf %423, %cst_0 : f64
    %425 = qco.rz(%424) %367 : !qco.qubit -> !qco.qubit
    %426 = arith.divf %arg59, %cst : f64
    %427 = math.tan %426 : f64
    %428 = math.atan %427 : f64
    %429 = arith.mulf %428, %cst : f64
    %430 = arith.addf %429, %cst_0 : f64
    %431 = qco.rz(%430) %375 : !qco.qubit -> !qco.qubit
    %432 = arith.divf %arg60, %cst : f64
    %433 = math.tan %432 : f64
    %434 = math.atan %433 : f64
    %435 = arith.mulf %434, %cst : f64
    %436 = arith.addf %435, %cst_0 : f64
    %437 = qco.rz(%436) %383 : !qco.qubit -> !qco.qubit
    %438 = arith.divf %arg61, %cst : f64
    %439 = math.tan %438 : f64
    %440 = math.atan %439 : f64
    %441 = arith.mulf %440, %cst : f64
    %442 = arith.addf %441, %cst_0 : f64
    %443 = qco.rz(%442) %391 : !qco.qubit -> !qco.qubit
    %444 = arith.divf %arg62, %cst : f64
    %445 = math.tan %444 : f64
    %446 = math.atan %445 : f64
    %447 = arith.mulf %446, %cst : f64
    %448 = arith.addf %447, %cst_0 : f64
    %449 = qco.rz(%448) %399 : !qco.qubit -> !qco.qubit
    qco.sink %413 : !qco.qubit
    qco.sink %419 : !qco.qubit
    qco.sink %425 : !qco.qubit
    qco.sink %431 : !qco.qubit
    qco.sink %437 : !qco.qubit
    qco.sink %443 : !qco.qubit
    qco.sink %449 : !qco.qubit
    %450 = arith.divf %arg63, %cst : f64
    %451 = math.tan %450 : f64
    %452 = math.atan %451 : f64
    %453 = arith.mulf %452, %cst : f64
    %454 = arith.addf %453, %cst_0 : f64
    %455 = qco.rz(%454) %407 : !qco.qubit -> !qco.qubit
    qco.sink %455 : !qco.qubit
    return %c0_i64 : i64
  }
}
