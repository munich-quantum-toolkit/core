module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 1.5707963267948963 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant 4.7123889803846897 : f64
    %cst_2 = arith.constant -4.7123889803846897 : f64
    %cst_3 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.rz(%cst_3) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_3) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_2) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.sx %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_1) %9 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%7) targets (%arg0 = %10) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qco.rz(%cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %12 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_2) %2 : !qco.qubit -> !qco.qubit
    %15 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_1) %15 : !qco.qubit -> !qco.qubit
    %controls_out_4, %targets_out_5 = qco.ctrl(%13) targets (%arg0 = %16) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.rz(%cst_0) %targets_out_5 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_2) %3 : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_1) %21 : !qco.qubit -> !qco.qubit
    %controls_out_6, %targets_out_7 = qco.ctrl(%19) targets (%arg0 = %22) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %23 = qco.rz(%cst_0) %targets_out_7 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst) %24 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %controls_out : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<4>
    %qubit_out_8, %result_9 = qco.measure %controls_out_4 : !qco.qubit
    cbit.store %result_9, %4[%c1] : !cbit.reg<4>
    %qubit_out_10, %result_11 = qco.measure %controls_out_6 : !qco.qubit
    cbit.store %result_11, %4[%c2] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_8 : !qco.qubit
    qco.sink %qubit_out_10 : !qco.qubit
    %qubit_out_12, %result_13 = qco.measure %25 : !qco.qubit
    qco.sink %qubit_out_12 : !qco.qubit
    cbit.store %result_13, %4[%c3] : !cbit.reg<4>
    %cst_14 = arith.constant 2.3561944901923448 : f64
    qco.gphase(%cst_14)
    return %4 : !cbit.reg<4>
  }
}
