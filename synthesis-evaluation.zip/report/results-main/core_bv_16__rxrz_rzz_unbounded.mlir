module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<15> attributes {mqt.entry_point} {
    %cst = arith.constant 1.5707963267948963 : f64
    %cst_0 = arith.constant 3.1415926535897931 : f64
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %cst_2 = arith.constant -3.1415926535897931 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<15>
    %17 = qco.rx(%cst_0) %0 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_1) %1 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_1) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_1) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_1) %3 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_1) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_1) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_1) %5 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_1) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_1) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_1) %7 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_1) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_1) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_1) %9 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_1) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rx(%cst_1) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_1) %11 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_1) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_1) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_1) %13 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_1) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rx(%cst_1) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_1) %15 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_1) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_1) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rx(%cst_2) %20 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_1) %42, %17 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %43 = qco.rz(%cst_1) %qubit1_out : !qco.qubit -> !qco.qubit
    %44 = qco.rx(%cst_0) %qubit0_out : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst_2) %23 : !qco.qubit -> !qco.qubit
    %qubit0_out_3, %qubit1_out_4 = qco.rzz(%cst_1) %46, %43 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %47 = qco.rz(%cst_1) %qubit1_out_4 : !qco.qubit -> !qco.qubit
    %48 = qco.rx(%cst_0) %qubit0_out_3 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_2) %26 : !qco.qubit -> !qco.qubit
    %qubit0_out_5, %qubit1_out_6 = qco.rzz(%cst_1) %50, %47 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %51 = qco.rz(%cst_1) %qubit1_out_6 : !qco.qubit -> !qco.qubit
    %52 = qco.rx(%cst_0) %qubit0_out_5 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rx(%cst_2) %29 : !qco.qubit -> !qco.qubit
    %qubit0_out_7, %qubit1_out_8 = qco.rzz(%cst_1) %54, %51 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %55 = qco.rz(%cst_1) %qubit1_out_8 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_0) %qubit0_out_7 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_2) %32 : !qco.qubit -> !qco.qubit
    %qubit0_out_9, %qubit1_out_10 = qco.rzz(%cst_1) %58, %55 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %59 = qco.rz(%cst_1) %qubit1_out_10 : !qco.qubit -> !qco.qubit
    %60 = qco.rx(%cst_0) %qubit0_out_9 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rx(%cst_2) %35 : !qco.qubit -> !qco.qubit
    %qubit0_out_11, %qubit1_out_12 = qco.rzz(%cst_1) %62, %59 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %63 = qco.rz(%cst_1) %qubit1_out_12 : !qco.qubit -> !qco.qubit
    %64 = qco.rx(%cst_0) %qubit0_out_11 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rx(%cst_2) %38 : !qco.qubit -> !qco.qubit
    %qubit0_out_13, %qubit1_out_14 = qco.rzz(%cst_1) %66, %63 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %67 = qco.rz(%cst_1) %qubit1_out_14 : !qco.qubit -> !qco.qubit
    %68 = qco.rx(%cst_0) %qubit0_out_13 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rx(%cst_2) %41 : !qco.qubit -> !qco.qubit
    %qubit0_out_15, %qubit1_out_16 = qco.rzz(%cst_1) %70, %67 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %71 = qco.rz(%cst_1) %qubit1_out_16 : !qco.qubit -> !qco.qubit
    %72 = qco.rx(%cst_0) %qubit0_out_15 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rx(%cst_1) %45 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_1) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rx(%cst_1) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rx(%cst_1) %49 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_1) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rx(%cst_1) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rx(%cst_1) %53 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_1) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rx(%cst_1) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rx(%cst_1) %57 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_1) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rx(%cst_1) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rx(%cst_1) %61 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_1) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rx(%cst_1) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.rx(%cst_1) %65 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_1) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rx(%cst_1) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rx(%cst_1) %69 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_1) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rx(%cst_1) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rx(%cst_1) %73 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_1) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rx(%cst_1) %96 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %76 : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<15>
    %qubit_out_17, %result_18 = qco.measure %2 : !qco.qubit
    cbit.store %result_18, %16[%c1] : !cbit.reg<15>
    %qubit_out_19, %result_20 = qco.measure %79 : !qco.qubit
    cbit.store %result_20, %16[%c2] : !cbit.reg<15>
    %qubit_out_21, %result_22 = qco.measure %4 : !qco.qubit
    cbit.store %result_22, %16[%c3] : !cbit.reg<15>
    %qubit_out_23, %result_24 = qco.measure %82 : !qco.qubit
    cbit.store %result_24, %16[%c4] : !cbit.reg<15>
    %qubit_out_25, %result_26 = qco.measure %6 : !qco.qubit
    cbit.store %result_26, %16[%c5] : !cbit.reg<15>
    %qubit_out_27, %result_28 = qco.measure %85 : !qco.qubit
    cbit.store %result_28, %16[%c6] : !cbit.reg<15>
    %qubit_out_29, %result_30 = qco.measure %8 : !qco.qubit
    cbit.store %result_30, %16[%c7] : !cbit.reg<15>
    %qubit_out_31, %result_32 = qco.measure %88 : !qco.qubit
    cbit.store %result_32, %16[%c8] : !cbit.reg<15>
    %qubit_out_33, %result_34 = qco.measure %10 : !qco.qubit
    cbit.store %result_34, %16[%c9] : !cbit.reg<15>
    %qubit_out_35, %result_36 = qco.measure %91 : !qco.qubit
    cbit.store %result_36, %16[%c10] : !cbit.reg<15>
    %qubit_out_37, %result_38 = qco.measure %12 : !qco.qubit
    cbit.store %result_38, %16[%c11] : !cbit.reg<15>
    %qubit_out_39, %result_40 = qco.measure %94 : !qco.qubit
    cbit.store %result_40, %16[%c12] : !cbit.reg<15>
    %qubit_out_41, %result_42 = qco.measure %14 : !qco.qubit
    cbit.store %result_42, %16[%c13] : !cbit.reg<15>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_17 : !qco.qubit
    qco.sink %qubit_out_19 : !qco.qubit
    qco.sink %qubit_out_21 : !qco.qubit
    qco.sink %qubit_out_23 : !qco.qubit
    qco.sink %qubit_out_25 : !qco.qubit
    qco.sink %qubit_out_27 : !qco.qubit
    qco.sink %qubit_out_29 : !qco.qubit
    qco.sink %qubit_out_31 : !qco.qubit
    qco.sink %qubit_out_33 : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    qco.sink %qubit_out_37 : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    qco.sink %qubit_out_41 : !qco.qubit
    %qubit_out_43, %result_44 = qco.measure %97 : !qco.qubit
    qco.sink %qubit_out_43 : !qco.qubit
    cbit.store %result_44, %16[%c14] : !cbit.reg<15>
    qco.sink %71 : !qco.qubit
    %cst_45 = arith.constant 1.5707963267948895 : f64
    qco.gphase(%cst_45)
    return %16 : !cbit.reg<15>
  }
}
