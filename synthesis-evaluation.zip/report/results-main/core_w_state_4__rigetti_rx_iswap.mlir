module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 7.8539816339744819 : f64
    %cst_0 = arith.constant -1.5707963267948957 : f64
    %cst_1 = arith.constant 3.1415926535897936 : f64
    %cst_2 = arith.constant 5.2359877559829879 : f64
    %cst_3 = arith.constant 2.0943951023931953 : f64
    %cst_4 = arith.constant 3.1415926535897949 : f64
    %cst_5 = arith.constant 1.5707963267948968 : f64
    %cst_6 = arith.constant 0.88369178103153434 : f64
    %cst_7 = arith.constant -2.2579008725582588 : f64
    %cst_8 = arith.constant 5.3278686890550766 : f64
    %cst_9 = arith.constant 3.1415926535897927 : f64
    %cst_10 = arith.constant 0.95531661812450896 : f64
    %cst_11 = arith.constant 1.5707963267948961 : f64
    %cst_12 = arith.constant 4.7123889803846897 : f64
    %cst_13 = arith.constant -1.5707963267948963 : f64
    %cst_14 = arith.constant -1.5707963267948966 : f64
    %cst_15 = arith.constant -3.1415926535897931 : f64
    %cst_16 = arith.constant 5.497787143782138 : f64
    %cst_17 = arith.constant 3.1415926535897931 : f64
    %cst_18 = arith.constant 3.9269908169872414 : f64
    %cst_19 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.rx(%cst_17) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_4) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.rx(%cst_19) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_3) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_12) %5 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_19) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_19) %10 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %11, %8 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %12 = qco.rz(%cst_17) %qubit1_out : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_19) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_2) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_19) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_19) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_15) %qubit0_out : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_19) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_14) %18 : !qco.qubit -> !qco.qubit
    %qubit0_out_20, %qubit1_out_21 = qco.iswap %19, %16 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %20 = qco.rz(%cst_15) %qubit1_out_21 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_17) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_1) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_0) %qubit0_out_20 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_19) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_19) %2 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_10) %26 : !qco.qubit -> !qco.qubit
    %qubit0_out_22, %qubit1_out_23 = qco.iswap %22, %27 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %28 = qco.rz(%cst_9) %qubit1_out_23 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_19) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_8) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_19) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_11) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_15) %qubit0_out_22 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_19) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_14) %34 : !qco.qubit -> !qco.qubit
    %qubit0_out_24, %qubit1_out_25 = qco.iswap %35, %32 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %36 = qco.rz(%cst_7) %qubit1_out_25 : !qco.qubit -> !qco.qubit
    %37 = qco.rx(%cst_17) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_6) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_14) %qubit0_out_24 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_19) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_5) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rx(%cst_19) %3 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_18) %42 : !qco.qubit -> !qco.qubit
    %qubit0_out_26, %qubit1_out_27 = qco.iswap %38, %43 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %44 = qco.rz(%cst_17) %qubit1_out_27 : !qco.qubit -> !qco.qubit
    %45 = qco.rx(%cst_19) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_16) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rx(%cst_19) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_19) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_15) %qubit0_out_26 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_19) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_14) %50 : !qco.qubit -> !qco.qubit
    %qubit0_out_28, %qubit1_out_29 = qco.iswap %51, %48 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %52 = qco.rz(%cst_13) %qubit1_out_29 : !qco.qubit -> !qco.qubit
    %53 = qco.rx(%cst_19) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_12) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_19) %qubit0_out_28 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_19) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_11) %56 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %25 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<4>
    %qubit_out_30, %result_31 = qco.measure %41 : !qco.qubit
    cbit.store %result_31, %4[%c1] : !cbit.reg<4>
    %qubit_out_32, %result_33 = qco.measure %57 : !qco.qubit
    cbit.store %result_33, %4[%c2] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_30 : !qco.qubit
    qco.sink %qubit_out_32 : !qco.qubit
    %qubit_out_34, %result_35 = qco.measure %54 : !qco.qubit
    qco.sink %qubit_out_34 : !qco.qubit
    cbit.store %result_35, %4[%c3] : !cbit.reg<4>
    %cst_36 = arith.constant 0.7853981633974465 : f64
    qco.gphase(%cst_36)
    return %4 : !cbit.reg<4>
  }
}
