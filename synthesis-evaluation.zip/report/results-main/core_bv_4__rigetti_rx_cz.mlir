module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 1.5707963267948966 : f64
    %cst_0 = arith.constant 3.1415926535897931 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %5 = qco.rx(%cst_0) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.rx(%cst) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst) %3 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst) %10 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%8) targets (%arg0 = %5) {
      %18 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %18 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_1, %targets_out_2 = qco.ctrl(%11) targets (%arg0 = %targets_out) {
      %18 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %18 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qco.rz(%cst) %controls_out : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst) %controls_out_1 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst) %16 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %14 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<3>
    %qubit_out_3, %result_4 = qco.measure %2 : !qco.qubit
    cbit.store %result_4, %4[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_3 : !qco.qubit
    %qubit_out_5, %result_6 = qco.measure %17 : !qco.qubit
    qco.sink %qubit_out_5 : !qco.qubit
    cbit.store %result_6, %4[%c2] : !cbit.reg<3>
    qco.sink %targets_out_2 : !qco.qubit
    qco.gphase(%cst)
    return %4 : !cbit.reg<3>
  }
}
