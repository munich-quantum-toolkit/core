module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 0>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 9.0320788790706548 : f64
    %cst_0 = arith.constant 2.3561944901923453 : f64
    %cst_1 = arith.constant 8.6393797973719302 : f64
    %cst_2 = arith.constant -7.0685834705770345 : f64
    %cst_3 = arith.constant -0.78539816339744861 : f64
    %cst_4 = arith.constant -1.9634954084936211 : f64
    %cst_5 = arith.constant -3.5342917352885177 : f64
    %cst_6 = arith.constant 4.319689898685966 : f64
    %cst_7 = arith.constant -3.1415926535897927 : f64
    %cst_8 = arith.constant 3.9269908169872432 : f64
    %cst_9 = arith.constant 4.7123889803846897 : f64
    %cst_10 = arith.constant 1.5707963267948968 : f64
    %cst_11 = arith.constant -1.5707963267948963 : f64
    %cst_12 = arith.constant -0.78539816339744783 : f64
    %cst_13 = arith.constant -3.1415926535897922 : f64
    %cst_14 = arith.constant -1.5707963267948966 : f64
    %cst_15 = arith.constant 3.926990816987241 : f64
    %cst_16 = arith.constant -0.39269908169872392 : f64
    %cst_17 = arith.constant -3.1415926535897931 : f64
    %cst_18 = arith.constant -1.5707963267948961 : f64
    %cst_19 = arith.constant 3.5342917352885181 : f64
    %cst_20 = arith.constant -4.7123889803846897 : f64
    %cst_21 = arith.constant 1.5707963267948961 : f64
    %cst_22 = arith.constant 3.1415926535897931 : f64
    %cst_23 = arith.constant 1.5707963267948966 : f64
    %cst_24 = arith.constant -6.2831853071795862 : f64
    %cst_25 = arith.constant 0.78539816339744828 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %5 = qco.rz(%cst_23) %1 : !qco.qubit -> !qco.qubit
    %6 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_23) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_23) %2 : !qco.qubit -> !qco.qubit
    %9 = qco.sx %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_9) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_23) %3 : !qco.qubit -> !qco.qubit
    %12 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_23) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.x %0 : !qco.qubit -> !qco.qubit
    %15 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_23) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_14) %17 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%18) targets (%arg0 = %16) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %19 = qco.rz(%cst_24) %targets_out : !qco.qubit -> !qco.qubit
    %20 = qco.sx %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_22) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_20) %controls_out : !qco.qubit -> !qco.qubit
    %23 = qco.sx %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_6) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.sx %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_22) %25 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%26) targets (%arg0 = %21) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %27 = qco.rz(%cst_14) %targets_out_27 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_5) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.sx %controls_out_26 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_4) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.sx %29 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_23) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %10 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_21) %34 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%35) targets (%arg0 = %33) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %36 = qco.rz(%cst_24) %targets_out_29 : !qco.qubit -> !qco.qubit
    %37 = qco.sx %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_22) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_20) %controls_out_28 : !qco.qubit -> !qco.qubit
    %40 = qco.sx %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_8) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.sx %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_22) %42 : !qco.qubit -> !qco.qubit
    %controls_out_30, %targets_out_31 = qco.ctrl(%43) targets (%arg0 = %38) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = qco.rz(%cst_11) %targets_out_31 : !qco.qubit -> !qco.qubit
    %45 = qco.sx %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_3) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_7) %controls_out_30 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_2) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.sx %46 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_10) %50 : !qco.qubit -> !qco.qubit
    %controls_out_32, %targets_out_33 = qco.ctrl(%7) targets (%arg0 = %51) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qco.rz(%cst_20) %targets_out_33 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_9) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_23) %controls_out_32 : !qco.qubit -> !qco.qubit
    %56 = qco.sx %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_9) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.sx %49 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_23) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.sx %57 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_21) %60 : !qco.qubit -> !qco.qubit
    %controls_out_34, %targets_out_35 = qco.ctrl(%61) targets (%arg0 = %59) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %62 = qco.rz(%cst_24) %targets_out_35 : !qco.qubit -> !qco.qubit
    %63 = qco.sx %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_22) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_20) %controls_out_34 : !qco.qubit -> !qco.qubit
    %66 = qco.sx %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_15) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.sx %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_22) %68 : !qco.qubit -> !qco.qubit
    %controls_out_36, %targets_out_37 = qco.ctrl(%69) targets (%arg0 = %64) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %70 = qco.rz(%cst_14) %targets_out_37 : !qco.qubit -> !qco.qubit
    %71 = qco.sx %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_1) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_13) %controls_out_36 : !qco.qubit -> !qco.qubit
    %74 = qco.sx %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_0) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.sx %72 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_9) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.sx %31 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_23) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.sx %77 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_21) %80 : !qco.qubit -> !qco.qubit
    %controls_out_38, %targets_out_39 = qco.ctrl(%81) targets (%arg0 = %79) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %82 = qco.rz(%cst_24) %targets_out_39 : !qco.qubit -> !qco.qubit
    %83 = qco.sx %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_22) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_20) %controls_out_38 : !qco.qubit -> !qco.qubit
    %86 = qco.sx %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_15) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.sx %87 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_22) %88 : !qco.qubit -> !qco.qubit
    %controls_out_40, %targets_out_41 = qco.ctrl(%89) targets (%arg0 = %84) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %90 = qco.rz(%cst_14) %targets_out_41 : !qco.qubit -> !qco.qubit
    %91 = qco.sx %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_25) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_13) %controls_out_40 : !qco.qubit -> !qco.qubit
    %94 = qco.sx %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_12) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.sx %92 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_23) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.sx %75 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_21) %98 : !qco.qubit -> !qco.qubit
    %controls_out_42, %targets_out_43 = qco.ctrl(%99) targets (%arg0 = %97) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %100 = qco.rz(%cst_24) %targets_out_43 : !qco.qubit -> !qco.qubit
    %101 = qco.sx %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_22) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst_20) %controls_out_42 : !qco.qubit -> !qco.qubit
    %104 = qco.sx %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst_19) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.sx %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rz(%cst_22) %106 : !qco.qubit -> !qco.qubit
    %controls_out_44, %targets_out_45 = qco.ctrl(%107) targets (%arg0 = %102) {
      %116 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %116 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %108 = qco.rz(%cst_18) %targets_out_45 : !qco.qubit -> !qco.qubit
    %109 = qco.sx %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_17) %controls_out_44 : !qco.qubit -> !qco.qubit
    %112 = qco.sx %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_16) %112 : !qco.qubit -> !qco.qubit
    %114 = qco.sx %110 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_23) %114 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %113 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<3>
    %qubit_out_46, %result_47 = qco.measure %95 : !qco.qubit
    cbit.store %result_47, %4[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_46 : !qco.qubit
    %qubit_out_48, %result_49 = qco.measure %115 : !qco.qubit
    qco.sink %qubit_out_48 : !qco.qubit
    cbit.store %result_49, %4[%c2] : !cbit.reg<3>
    qco.sink %54 : !qco.qubit
    %cst_50 = arith.constant -1.5707963267948886 : f64
    qco.gphase(%cst_50)
    return %4 : !cbit.reg<3>
  }
}
