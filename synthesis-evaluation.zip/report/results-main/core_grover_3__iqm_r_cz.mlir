module attributes {mqt.layout = {initial = array<i64: 0, 1, 2>, input_count = 3 : i64, sites = array<i64: 0, 1, 2>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 6.2831853071795862 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant 0.000000e+00 : f64
    %cst_2 = arith.constant 3.1415926535897931 : f64
    %cst_3 = arith.constant 2.3561944901923448 : f64
    %cst_4 = arith.constant 0.78539816339744828 : f64
    %cst_5 = arith.constant 4.7123889803846897 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %4 = qco.r(%cst_0, %cst_0) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.r(%cst_2, %cst_1) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.r(%cst_0, %cst_0) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.r(%cst, %cst_1) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_0, %cst_0) %2 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_2, %cst_1) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_2, %cst_1) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_0, %cst_0) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_2, %cst_1) %11 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%7) targets (%arg0 = %12) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %13 = qco.r(%cst_0, %cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst, %cst_1) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_0, %cst_1) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_4, %cst_0) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_5, %cst_1) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_2, %cst_1) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst_0, %cst_0) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_2, %cst_1) %19 : !qco.qubit -> !qco.qubit
    %controls_out_6, %targets_out_7 = qco.ctrl(%5) targets (%arg0 = %20) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.r(%cst_0, %cst_0) %targets_out_7 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst, %cst_1) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_5, %cst_1) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_4, %cst_0) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_0, %cst_1) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_2, %cst_1) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst_0, %cst_0) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_2, %cst_1) %27 : !qco.qubit -> !qco.qubit
    %controls_out_8, %targets_out_9 = qco.ctrl(%controls_out) targets (%arg0 = %28) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.r(%cst_0, %cst_0) %targets_out_9 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst, %cst_1) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%cst_0, %cst_1) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_4, %cst_0) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_5, %cst_1) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.r(%cst_2, %cst_1) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst_0, %cst_0) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_2, %cst_1) %35 : !qco.qubit -> !qco.qubit
    %controls_out_10, %targets_out_11 = qco.ctrl(%controls_out_6) targets (%arg0 = %36) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.r(%cst_0, %cst_0) %targets_out_11 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst, %cst_1) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst_5, %cst_1) %controls_out_8 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_4, %cst_0) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst_0, %cst_1) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst_0, %cst_0) %38 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%cst_4, %cst_1) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_2, %cst_1) %41 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst_0, %cst_0) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.r(%cst_2, %cst_1) %45 : !qco.qubit -> !qco.qubit
    %controls_out_12, %targets_out_13 = qco.ctrl(%controls_out_10) targets (%arg0 = %46) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.r(%cst_0, %cst_0) %targets_out_13 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst, %cst_1) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.r(%cst_5, %cst_1) %controls_out_12 : !qco.qubit -> !qco.qubit
    %50 = qco.r(%cst_4, %cst_0) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.r(%cst_0, %cst_1) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.r(%cst_0, %cst_1) %48 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst_4, %cst_0) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.r(%cst_5, %cst_1) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.r(%cst_2, %cst_1) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.r(%cst_0, %cst_0) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.r(%cst_2, %cst_1) %56 : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%51) targets (%arg0 = %57) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = qco.r(%cst_0, %cst_0) %targets_out_15 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%cst, %cst_1) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.r(%cst_2, %cst_1) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.r(%cst_0, %cst_0) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.r(%cst_0, %cst_0) %controls_out_14 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%cst, %cst_1) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.r(%cst_2, %cst_1) %43 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%cst_0, %cst_0) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.r(%cst_2, %cst_1) %65 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%61) targets (%arg0 = %66) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %67 = qco.r(%cst_0, %cst_0) %targets_out_17 : !qco.qubit -> !qco.qubit
    %68 = qco.r(%cst, %cst_1) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.r(%cst_0, %cst_1) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.r(%cst_4, %cst_0) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.r(%cst_5, %cst_1) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%cst_2, %cst_1) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%cst_0, %cst_0) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.r(%cst_2, %cst_1) %73 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%63) targets (%arg0 = %74) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %75 = qco.r(%cst_0, %cst_0) %targets_out_19 : !qco.qubit -> !qco.qubit
    %76 = qco.r(%cst, %cst_1) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.r(%cst_5, %cst_1) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst_4, %cst_0) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.r(%cst_0, %cst_1) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.r(%cst_2, %cst_1) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%cst_0, %cst_0) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.r(%cst_2, %cst_1) %81 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%controls_out_16) targets (%arg0 = %82) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qco.r(%cst_0, %cst_0) %targets_out_21 : !qco.qubit -> !qco.qubit
    %84 = qco.r(%cst, %cst_1) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.r(%cst_0, %cst_1) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.r(%cst_4, %cst_0) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.r(%cst_5, %cst_1) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.r(%cst_2, %cst_1) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%cst_0, %cst_0) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.r(%cst_2, %cst_1) %89 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%controls_out_18) targets (%arg0 = %90) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %91 = qco.r(%cst_0, %cst_0) %targets_out_23 : !qco.qubit -> !qco.qubit
    %92 = qco.r(%cst, %cst_1) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.r(%cst_5, %cst_1) %controls_out_20 : !qco.qubit -> !qco.qubit
    %94 = qco.r(%cst_4, %cst_0) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.r(%cst_0, %cst_1) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.r(%cst_2, %cst_1) %92 : !qco.qubit -> !qco.qubit
    %97 = qco.r(%cst_0, %cst_0) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.r(%cst_3, %cst_1) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.r(%cst_2, %cst_1) %95 : !qco.qubit -> !qco.qubit
    %100 = qco.r(%cst_0, %cst_0) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.r(%cst_2, %cst_1) %100 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%controls_out_22) targets (%arg0 = %101) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %102 = qco.r(%cst_0, %cst_0) %targets_out_25 : !qco.qubit -> !qco.qubit
    %103 = qco.r(%cst, %cst_1) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.r(%cst_5, %cst_1) %controls_out_24 : !qco.qubit -> !qco.qubit
    %105 = qco.r(%cst_4, %cst_0) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.r(%cst_0, %cst_1) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.r(%cst_0, %cst_1) %103 : !qco.qubit -> !qco.qubit
    %108 = qco.r(%cst_4, %cst_0) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.r(%cst_5, %cst_1) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.r(%cst_2, %cst_1) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.r(%cst_0, %cst_0) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.r(%cst_2, %cst_1) %111 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%106) targets (%arg0 = %112) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %113 = qco.r(%cst_0, %cst_0) %targets_out_27 : !qco.qubit -> !qco.qubit
    %114 = qco.r(%cst, %cst_1) %113 : !qco.qubit -> !qco.qubit
    %115 = qco.r(%cst_2, %cst_1) %controls_out_26 : !qco.qubit -> !qco.qubit
    %116 = qco.r(%cst_0, %cst_0) %115 : !qco.qubit -> !qco.qubit
    %117 = qco.r(%cst_2, %cst_1) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.r(%cst_2, %cst_1) %114 : !qco.qubit -> !qco.qubit
    %119 = qco.r(%cst_0, %cst_0) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.r(%cst_2, %cst_1) %98 : !qco.qubit -> !qco.qubit
    %121 = qco.r(%cst_0, %cst_0) %120 : !qco.qubit -> !qco.qubit
    %122 = qco.r(%cst_2, %cst_1) %121 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%119) targets (%arg0 = %122) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %123 = qco.r(%cst_0, %cst_0) %targets_out_29 : !qco.qubit -> !qco.qubit
    %124 = qco.r(%cst, %cst_1) %123 : !qco.qubit -> !qco.qubit
    %125 = qco.r(%cst_0, %cst_1) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.r(%cst_4, %cst_0) %125 : !qco.qubit -> !qco.qubit
    %127 = qco.r(%cst_5, %cst_1) %126 : !qco.qubit -> !qco.qubit
    %128 = qco.r(%cst_2, %cst_1) %127 : !qco.qubit -> !qco.qubit
    %129 = qco.r(%cst_0, %cst_0) %128 : !qco.qubit -> !qco.qubit
    %130 = qco.r(%cst_2, %cst_1) %129 : !qco.qubit -> !qco.qubit
    %controls_out_30, %targets_out_31 = qco.ctrl(%117) targets (%arg0 = %130) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %131 = qco.r(%cst_0, %cst_0) %targets_out_31 : !qco.qubit -> !qco.qubit
    %132 = qco.r(%cst, %cst_1) %131 : !qco.qubit -> !qco.qubit
    %133 = qco.r(%cst_5, %cst_1) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.r(%cst_4, %cst_0) %133 : !qco.qubit -> !qco.qubit
    %135 = qco.r(%cst_0, %cst_1) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.r(%cst_2, %cst_1) %135 : !qco.qubit -> !qco.qubit
    %137 = qco.r(%cst_0, %cst_0) %136 : !qco.qubit -> !qco.qubit
    %138 = qco.r(%cst_2, %cst_1) %137 : !qco.qubit -> !qco.qubit
    %controls_out_32, %targets_out_33 = qco.ctrl(%controls_out_28) targets (%arg0 = %138) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %139 = qco.r(%cst_0, %cst_0) %targets_out_33 : !qco.qubit -> !qco.qubit
    %140 = qco.r(%cst, %cst_1) %139 : !qco.qubit -> !qco.qubit
    %141 = qco.r(%cst_0, %cst_1) %140 : !qco.qubit -> !qco.qubit
    %142 = qco.r(%cst_4, %cst_0) %141 : !qco.qubit -> !qco.qubit
    %143 = qco.r(%cst_5, %cst_1) %142 : !qco.qubit -> !qco.qubit
    %144 = qco.r(%cst_2, %cst_1) %143 : !qco.qubit -> !qco.qubit
    %145 = qco.r(%cst_0, %cst_0) %144 : !qco.qubit -> !qco.qubit
    %146 = qco.r(%cst_2, %cst_1) %145 : !qco.qubit -> !qco.qubit
    %controls_out_34, %targets_out_35 = qco.ctrl(%controls_out_30) targets (%arg0 = %146) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %147 = qco.r(%cst_0, %cst_0) %targets_out_35 : !qco.qubit -> !qco.qubit
    %148 = qco.r(%cst, %cst_1) %147 : !qco.qubit -> !qco.qubit
    %149 = qco.r(%cst_5, %cst_1) %controls_out_32 : !qco.qubit -> !qco.qubit
    %150 = qco.r(%cst_4, %cst_0) %149 : !qco.qubit -> !qco.qubit
    %151 = qco.r(%cst_0, %cst_1) %150 : !qco.qubit -> !qco.qubit
    %152 = qco.r(%cst_0, %cst_0) %148 : !qco.qubit -> !qco.qubit
    %153 = qco.r(%cst_4, %cst_1) %152 : !qco.qubit -> !qco.qubit
    %154 = qco.r(%cst_2, %cst_1) %151 : !qco.qubit -> !qco.qubit
    %155 = qco.r(%cst_0, %cst_0) %154 : !qco.qubit -> !qco.qubit
    %156 = qco.r(%cst_2, %cst_1) %155 : !qco.qubit -> !qco.qubit
    %controls_out_36, %targets_out_37 = qco.ctrl(%controls_out_34) targets (%arg0 = %156) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %157 = qco.r(%cst_0, %cst_0) %targets_out_37 : !qco.qubit -> !qco.qubit
    %158 = qco.r(%cst, %cst_1) %157 : !qco.qubit -> !qco.qubit
    %159 = qco.r(%cst_5, %cst_1) %controls_out_36 : !qco.qubit -> !qco.qubit
    %160 = qco.r(%cst_4, %cst_0) %159 : !qco.qubit -> !qco.qubit
    %161 = qco.r(%cst_0, %cst_1) %160 : !qco.qubit -> !qco.qubit
    %162 = qco.r(%cst_0, %cst_1) %158 : !qco.qubit -> !qco.qubit
    %163 = qco.r(%cst_4, %cst_0) %162 : !qco.qubit -> !qco.qubit
    %164 = qco.r(%cst_5, %cst_1) %163 : !qco.qubit -> !qco.qubit
    %165 = qco.r(%cst_2, %cst_1) %164 : !qco.qubit -> !qco.qubit
    %166 = qco.r(%cst_0, %cst_0) %165 : !qco.qubit -> !qco.qubit
    %167 = qco.r(%cst_2, %cst_1) %166 : !qco.qubit -> !qco.qubit
    %controls_out_38, %targets_out_39 = qco.ctrl(%161) targets (%arg0 = %167) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %168 = qco.r(%cst_0, %cst_0) %targets_out_39 : !qco.qubit -> !qco.qubit
    %169 = qco.r(%cst, %cst_1) %168 : !qco.qubit -> !qco.qubit
    %170 = qco.r(%cst_2, %cst_1) %169 : !qco.qubit -> !qco.qubit
    %171 = qco.r(%cst_0, %cst_0) %170 : !qco.qubit -> !qco.qubit
    %172 = qco.r(%cst_0, %cst_0) %controls_out_38 : !qco.qubit -> !qco.qubit
    %173 = qco.r(%cst, %cst_1) %172 : !qco.qubit -> !qco.qubit
    %174 = qco.r(%cst_2, %cst_1) %153 : !qco.qubit -> !qco.qubit
    %175 = qco.r(%cst_0, %cst_0) %174 : !qco.qubit -> !qco.qubit
    %176 = qco.r(%cst_2, %cst_1) %175 : !qco.qubit -> !qco.qubit
    %controls_out_40, %targets_out_41 = qco.ctrl(%171) targets (%arg0 = %176) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %177 = qco.r(%cst_0, %cst_0) %targets_out_41 : !qco.qubit -> !qco.qubit
    %178 = qco.r(%cst, %cst_1) %177 : !qco.qubit -> !qco.qubit
    %179 = qco.r(%cst_0, %cst_1) %178 : !qco.qubit -> !qco.qubit
    %180 = qco.r(%cst_4, %cst_0) %179 : !qco.qubit -> !qco.qubit
    %181 = qco.r(%cst_5, %cst_1) %180 : !qco.qubit -> !qco.qubit
    %182 = qco.r(%cst_2, %cst_1) %181 : !qco.qubit -> !qco.qubit
    %183 = qco.r(%cst_0, %cst_0) %182 : !qco.qubit -> !qco.qubit
    %184 = qco.r(%cst_2, %cst_1) %183 : !qco.qubit -> !qco.qubit
    %controls_out_42, %targets_out_43 = qco.ctrl(%173) targets (%arg0 = %184) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %185 = qco.r(%cst_0, %cst_0) %targets_out_43 : !qco.qubit -> !qco.qubit
    %186 = qco.r(%cst, %cst_1) %185 : !qco.qubit -> !qco.qubit
    %187 = qco.r(%cst_5, %cst_1) %186 : !qco.qubit -> !qco.qubit
    %188 = qco.r(%cst_4, %cst_0) %187 : !qco.qubit -> !qco.qubit
    %189 = qco.r(%cst_0, %cst_1) %188 : !qco.qubit -> !qco.qubit
    %190 = qco.r(%cst_2, %cst_1) %189 : !qco.qubit -> !qco.qubit
    %191 = qco.r(%cst_0, %cst_0) %190 : !qco.qubit -> !qco.qubit
    %192 = qco.r(%cst_2, %cst_1) %191 : !qco.qubit -> !qco.qubit
    %controls_out_44, %targets_out_45 = qco.ctrl(%controls_out_40) targets (%arg0 = %192) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %193 = qco.r(%cst_0, %cst_0) %targets_out_45 : !qco.qubit -> !qco.qubit
    %194 = qco.r(%cst, %cst_1) %193 : !qco.qubit -> !qco.qubit
    %195 = qco.r(%cst_0, %cst_1) %194 : !qco.qubit -> !qco.qubit
    %196 = qco.r(%cst_4, %cst_0) %195 : !qco.qubit -> !qco.qubit
    %197 = qco.r(%cst_5, %cst_1) %196 : !qco.qubit -> !qco.qubit
    %198 = qco.r(%cst_2, %cst_1) %197 : !qco.qubit -> !qco.qubit
    %199 = qco.r(%cst_0, %cst_0) %198 : !qco.qubit -> !qco.qubit
    %200 = qco.r(%cst_2, %cst_1) %199 : !qco.qubit -> !qco.qubit
    %controls_out_46, %targets_out_47 = qco.ctrl(%controls_out_42) targets (%arg0 = %200) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %201 = qco.r(%cst_0, %cst_0) %targets_out_47 : !qco.qubit -> !qco.qubit
    %202 = qco.r(%cst, %cst_1) %201 : !qco.qubit -> !qco.qubit
    %203 = qco.r(%cst_5, %cst_1) %controls_out_44 : !qco.qubit -> !qco.qubit
    %204 = qco.r(%cst_4, %cst_0) %203 : !qco.qubit -> !qco.qubit
    %205 = qco.r(%cst_0, %cst_1) %204 : !qco.qubit -> !qco.qubit
    %206 = qco.r(%cst_2, %cst_1) %202 : !qco.qubit -> !qco.qubit
    %207 = qco.r(%cst_0, %cst_0) %206 : !qco.qubit -> !qco.qubit
    %208 = qco.r(%cst_3, %cst_1) %207 : !qco.qubit -> !qco.qubit
    %209 = qco.r(%cst_2, %cst_1) %205 : !qco.qubit -> !qco.qubit
    %210 = qco.r(%cst_0, %cst_0) %209 : !qco.qubit -> !qco.qubit
    %211 = qco.r(%cst_2, %cst_1) %210 : !qco.qubit -> !qco.qubit
    %controls_out_48, %targets_out_49 = qco.ctrl(%controls_out_46) targets (%arg0 = %211) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %212 = qco.r(%cst_0, %cst_0) %targets_out_49 : !qco.qubit -> !qco.qubit
    %213 = qco.r(%cst, %cst_1) %212 : !qco.qubit -> !qco.qubit
    %214 = qco.r(%cst_5, %cst_1) %controls_out_48 : !qco.qubit -> !qco.qubit
    %215 = qco.r(%cst_4, %cst_0) %214 : !qco.qubit -> !qco.qubit
    %216 = qco.r(%cst_0, %cst_1) %215 : !qco.qubit -> !qco.qubit
    %217 = qco.r(%cst_0, %cst_1) %213 : !qco.qubit -> !qco.qubit
    %218 = qco.r(%cst_4, %cst_0) %217 : !qco.qubit -> !qco.qubit
    %219 = qco.r(%cst_5, %cst_1) %218 : !qco.qubit -> !qco.qubit
    %220 = qco.r(%cst_2, %cst_1) %219 : !qco.qubit -> !qco.qubit
    %221 = qco.r(%cst_0, %cst_0) %220 : !qco.qubit -> !qco.qubit
    %222 = qco.r(%cst_2, %cst_1) %221 : !qco.qubit -> !qco.qubit
    %controls_out_50, %targets_out_51 = qco.ctrl(%216) targets (%arg0 = %222) {
      %231 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %231 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %223 = qco.r(%cst_0, %cst_0) %targets_out_51 : !qco.qubit -> !qco.qubit
    %224 = qco.r(%cst, %cst_1) %223 : !qco.qubit -> !qco.qubit
    %225 = qco.r(%cst_2, %cst_1) %controls_out_50 : !qco.qubit -> !qco.qubit
    %226 = qco.r(%cst_0, %cst_0) %225 : !qco.qubit -> !qco.qubit
    %227 = qco.r(%cst_2, %cst_1) %226 : !qco.qubit -> !qco.qubit
    %228 = qco.r(%cst_2, %cst_1) %224 : !qco.qubit -> !qco.qubit
    %229 = qco.r(%cst_0, %cst_0) %228 : !qco.qubit -> !qco.qubit
    %230 = qco.r(%cst_2, %cst_1) %229 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %227 : !qco.qubit
    cbit.store %result, %3[%c0] : !cbit.reg<3>
    %qubit_out_52, %result_53 = qco.measure %230 : !qco.qubit
    cbit.store %result_53, %3[%c1] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_52 : !qco.qubit
    %qubit_out_54, %result_55 = qco.measure %208 : !qco.qubit
    qco.sink %qubit_out_54 : !qco.qubit
    cbit.store %result_55, %3[%c2] : !cbit.reg<3>
    %cst_56 = arith.constant -3.1415926535897918 : f64
    qco.gphase(%cst_56)
    return %3 : !cbit.reg<3>
  }
}
