module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<16> attributes {mqt.entry_point} {
    %cst = arith.constant 6.2831853071795862 : f64
    %cst_0 = arith.constant 1.5707963267948963 : f64
    %cst_1 = arith.constant -3.1415926535897931 : f64
    %cst_2 = arith.constant 1.5707963267948968 : f64
    %cst_3 = arith.constant 1.5707963267948966 : f64
    %cst_4 = arith.constant -1.5707963267948968 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %c15 = arith.constant 15 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<16>
    %17 = qco.rx(%cst_3) %0 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_3) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_3) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_4) %1 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_3) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst_2) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_1) %19 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_3) %23, %22 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %24 = qco.rx(%cst_3) %qubit1_out : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_2) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_1) %qubit0_out : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_0) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_4) %2 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_3) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_2) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rx(%cst_1) %25 : !qco.qubit -> !qco.qubit
    %qubit0_out_5, %qubit1_out_6 = qco.rzz(%cst_3) %32, %31 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %33 = qco.rx(%cst_3) %qubit1_out_6 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_2) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_1) %qubit0_out_5 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_0) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rx(%cst) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rx(%cst_4) %3 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_3) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_2) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_1) %34 : !qco.qubit -> !qco.qubit
    %qubit0_out_7, %qubit1_out_8 = qco.rzz(%cst_3) %41, %40 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %42 = qco.rx(%cst_3) %qubit1_out_8 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_2) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rx(%cst_1) %qubit0_out_7 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_0) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rx(%cst_4) %4 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_3) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_2) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_1) %43 : !qco.qubit -> !qco.qubit
    %qubit0_out_9, %qubit1_out_10 = qco.rzz(%cst_3) %50, %49 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %51 = qco.rx(%cst_3) %qubit1_out_10 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_2) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rx(%cst_1) %qubit0_out_9 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_0) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rx(%cst) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_4) %5 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_3) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_2) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rx(%cst_1) %52 : !qco.qubit -> !qco.qubit
    %qubit0_out_11, %qubit1_out_12 = qco.rzz(%cst_3) %59, %58 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %60 = qco.rx(%cst_3) %qubit1_out_12 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_2) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rx(%cst_1) %qubit0_out_11 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_0) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rx(%cst) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rx(%cst_4) %6 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_3) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rx(%cst_2) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rx(%cst_1) %61 : !qco.qubit -> !qco.qubit
    %qubit0_out_13, %qubit1_out_14 = qco.rzz(%cst_3) %68, %67 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %69 = qco.rx(%cst_3) %qubit1_out_14 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_2) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_1) %qubit0_out_13 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_0) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rx(%cst) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rx(%cst_4) %7 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_3) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rx(%cst_2) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rx(%cst_1) %70 : !qco.qubit -> !qco.qubit
    %qubit0_out_15, %qubit1_out_16 = qco.rzz(%cst_3) %77, %76 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %78 = qco.rx(%cst_3) %qubit1_out_16 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_2) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rx(%cst_1) %qubit0_out_15 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_0) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rx(%cst) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rx(%cst_4) %8 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_3) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rx(%cst_2) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rx(%cst_1) %79 : !qco.qubit -> !qco.qubit
    %qubit0_out_17, %qubit1_out_18 = qco.rzz(%cst_3) %86, %85 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %87 = qco.rx(%cst_3) %qubit1_out_18 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_2) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.rx(%cst_1) %qubit0_out_17 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_0) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rx(%cst) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rx(%cst_4) %9 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_3) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rx(%cst_2) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rx(%cst_1) %88 : !qco.qubit -> !qco.qubit
    %qubit0_out_19, %qubit1_out_20 = qco.rzz(%cst_3) %95, %94 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %96 = qco.rx(%cst_3) %qubit1_out_20 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_2) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rx(%cst_1) %qubit0_out_19 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_0) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rx(%cst) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.rx(%cst_4) %10 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_3) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rx(%cst_2) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rx(%cst_1) %97 : !qco.qubit -> !qco.qubit
    %qubit0_out_21, %qubit1_out_22 = qco.rzz(%cst_3) %104, %103 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %105 = qco.rx(%cst_3) %qubit1_out_22 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_2) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rx(%cst_1) %qubit0_out_21 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_0) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rx(%cst) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rx(%cst_4) %11 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_3) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rx(%cst_2) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rx(%cst_1) %106 : !qco.qubit -> !qco.qubit
    %qubit0_out_23, %qubit1_out_24 = qco.rzz(%cst_3) %113, %112 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %114 = qco.rx(%cst_3) %qubit1_out_24 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_2) %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rx(%cst_1) %qubit0_out_23 : !qco.qubit -> !qco.qubit
    %117 = qco.rz(%cst_0) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rx(%cst) %117 : !qco.qubit -> !qco.qubit
    %119 = qco.rx(%cst_4) %12 : !qco.qubit -> !qco.qubit
    %120 = qco.rz(%cst_3) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rx(%cst_2) %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rx(%cst_1) %115 : !qco.qubit -> !qco.qubit
    %qubit0_out_25, %qubit1_out_26 = qco.rzz(%cst_3) %122, %121 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %123 = qco.rx(%cst_3) %qubit1_out_26 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_2) %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rx(%cst_1) %qubit0_out_25 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst_0) %125 : !qco.qubit -> !qco.qubit
    %127 = qco.rx(%cst) %126 : !qco.qubit -> !qco.qubit
    %128 = qco.rx(%cst_4) %13 : !qco.qubit -> !qco.qubit
    %129 = qco.rz(%cst_3) %128 : !qco.qubit -> !qco.qubit
    %130 = qco.rx(%cst_2) %129 : !qco.qubit -> !qco.qubit
    %131 = qco.rx(%cst_1) %124 : !qco.qubit -> !qco.qubit
    %qubit0_out_27, %qubit1_out_28 = qco.rzz(%cst_3) %131, %130 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %132 = qco.rx(%cst_3) %qubit1_out_28 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst_2) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.rx(%cst_1) %qubit0_out_27 : !qco.qubit -> !qco.qubit
    %135 = qco.rz(%cst_0) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.rx(%cst) %135 : !qco.qubit -> !qco.qubit
    %137 = qco.rx(%cst_4) %14 : !qco.qubit -> !qco.qubit
    %138 = qco.rz(%cst_3) %137 : !qco.qubit -> !qco.qubit
    %139 = qco.rx(%cst_2) %138 : !qco.qubit -> !qco.qubit
    %140 = qco.rx(%cst_1) %133 : !qco.qubit -> !qco.qubit
    %qubit0_out_29, %qubit1_out_30 = qco.rzz(%cst_3) %140, %139 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %141 = qco.rx(%cst_3) %qubit1_out_30 : !qco.qubit -> !qco.qubit
    %142 = qco.rz(%cst_2) %141 : !qco.qubit -> !qco.qubit
    %143 = qco.rx(%cst_1) %qubit0_out_29 : !qco.qubit -> !qco.qubit
    %144 = qco.rz(%cst_0) %143 : !qco.qubit -> !qco.qubit
    %145 = qco.rx(%cst) %144 : !qco.qubit -> !qco.qubit
    %146 = qco.rx(%cst_4) %15 : !qco.qubit -> !qco.qubit
    %147 = qco.rz(%cst_3) %146 : !qco.qubit -> !qco.qubit
    %148 = qco.rx(%cst_2) %147 : !qco.qubit -> !qco.qubit
    %149 = qco.rx(%cst_1) %142 : !qco.qubit -> !qco.qubit
    %qubit0_out_31, %qubit1_out_32 = qco.rzz(%cst_3) %149, %148 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %150 = qco.rx(%cst_3) %qubit1_out_32 : !qco.qubit -> !qco.qubit
    %151 = qco.rz(%cst_2) %150 : !qco.qubit -> !qco.qubit
    %152 = qco.rx(%cst_1) %qubit0_out_31 : !qco.qubit -> !qco.qubit
    %153 = qco.rz(%cst_0) %152 : !qco.qubit -> !qco.qubit
    %154 = qco.rx(%cst) %153 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %28 : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<16>
    %qubit_out_33, %result_34 = qco.measure %37 : !qco.qubit
    cbit.store %result_34, %16[%c1] : !cbit.reg<16>
    %qubit_out_35, %result_36 = qco.measure %46 : !qco.qubit
    cbit.store %result_36, %16[%c2] : !cbit.reg<16>
    %qubit_out_37, %result_38 = qco.measure %55 : !qco.qubit
    cbit.store %result_38, %16[%c3] : !cbit.reg<16>
    %qubit_out_39, %result_40 = qco.measure %64 : !qco.qubit
    cbit.store %result_40, %16[%c4] : !cbit.reg<16>
    %qubit_out_41, %result_42 = qco.measure %73 : !qco.qubit
    cbit.store %result_42, %16[%c5] : !cbit.reg<16>
    %qubit_out_43, %result_44 = qco.measure %82 : !qco.qubit
    cbit.store %result_44, %16[%c6] : !cbit.reg<16>
    %qubit_out_45, %result_46 = qco.measure %91 : !qco.qubit
    cbit.store %result_46, %16[%c7] : !cbit.reg<16>
    %qubit_out_47, %result_48 = qco.measure %100 : !qco.qubit
    cbit.store %result_48, %16[%c8] : !cbit.reg<16>
    %qubit_out_49, %result_50 = qco.measure %109 : !qco.qubit
    cbit.store %result_50, %16[%c9] : !cbit.reg<16>
    %qubit_out_51, %result_52 = qco.measure %118 : !qco.qubit
    cbit.store %result_52, %16[%c10] : !cbit.reg<16>
    %qubit_out_53, %result_54 = qco.measure %127 : !qco.qubit
    cbit.store %result_54, %16[%c11] : !cbit.reg<16>
    %qubit_out_55, %result_56 = qco.measure %136 : !qco.qubit
    cbit.store %result_56, %16[%c12] : !cbit.reg<16>
    %qubit_out_57, %result_58 = qco.measure %145 : !qco.qubit
    cbit.store %result_58, %16[%c13] : !cbit.reg<16>
    %qubit_out_59, %result_60 = qco.measure %154 : !qco.qubit
    cbit.store %result_60, %16[%c14] : !cbit.reg<16>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_33 : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    qco.sink %qubit_out_37 : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    qco.sink %qubit_out_41 : !qco.qubit
    qco.sink %qubit_out_43 : !qco.qubit
    qco.sink %qubit_out_45 : !qco.qubit
    qco.sink %qubit_out_47 : !qco.qubit
    qco.sink %qubit_out_49 : !qco.qubit
    qco.sink %qubit_out_51 : !qco.qubit
    qco.sink %qubit_out_53 : !qco.qubit
    qco.sink %qubit_out_55 : !qco.qubit
    qco.sink %qubit_out_57 : !qco.qubit
    qco.sink %qubit_out_59 : !qco.qubit
    %qubit_out_61, %result_62 = qco.measure %151 : !qco.qubit
    qco.sink %qubit_out_61 : !qco.qubit
    cbit.store %result_62, %16[%c15] : !cbit.reg<16>
    %cst_63 = arith.constant 0.78539816339743573 : f64
    qco.gphase(%cst_63)
    return %16 : !cbit.reg<16>
  }
}
