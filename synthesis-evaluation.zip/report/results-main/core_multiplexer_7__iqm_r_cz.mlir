module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 0>, input_count = 7 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant 7.4273541408476067 : f64
    %cst_0 = arith.constant 2.3561944901923448 : f64
    %cst_1 = arith.constant -0.78539816339744739 : f64
    %cst_2 = arith.constant 1.5707963267948968 : f64
    %cst_3 = arith.constant 2.4805494847391065 : f64
    %cst_4 = arith.constant 7.1929384651237962 : f64
    %cst_5 = arith.constant 2.748893571891069 : f64
    %cst_6 = arith.constant -1.178097245096172 : f64
    %cst_7 = arith.constant 2.9452431127404313 : f64
    %cst_8 = arith.constant -1.3744467859455352 : f64
    %cst_9 = arith.constant 3.1415926535897949 : f64
    %cst_10 = arith.constant 3.0434178831651124 : f64
    %cst_11 = arith.constant -1.5707963267948948 : f64
    %cst_12 = arith.constant -1.4726215563702159 : f64
    %cst_13 = arith.constant 3.141592653589794 : f64
    %cst_14 = arith.constant 3.0925052683774528 : f64
    %cst_15 = arith.constant -1.5707963267948957 : f64
    %cst_16 = arith.constant -1.5217089415825562 : f64
    %cst_17 = arith.constant 2.714965160462917 : f64
    %cst_18 = arith.constant 1.1441688336680205 : f64
    %cst_19 = arith.constant 3.1415926535897931 : f64
    %cst_20 = arith.constant 3.1170489609836229 : f64
    %cst_21 = arith.constant -1.5462526341887255 : f64
    %cst_22 = arith.constant 4.7123889803846897 : f64
    %cst_23 = arith.constant -1.5707963267948966 : f64
    %cst_24 = arith.constant 3.1415926535897927 : f64
    %cst_25 = arith.constant 1.5707963267948966 : f64
    %cst_26 = arith.constant 1.570796326794897 : f64
    %cst_27 = arith.constant 0.000000e+00 : f64
    %cst_28 = arith.constant 6.2831853071795862 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %8 = qco.r(%cst_25, %cst_25) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_19, %cst_27) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_25, %cst_25) %2 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_19, %cst_27) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_25, %cst_25) %3 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_19, %cst_27) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_25, %cst_25) %4 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_19, %cst_27) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_25, %cst_25) %5 : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_19, %cst_27) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_25, %cst_25) %6 : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst_19, %cst_27) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_28, %cst_27) %0 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_26, %cst_25) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_26, %cst_27) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_19, %cst_27) %19 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_2, %cst_25) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_22, %cst_27) %24 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%25) targets (%arg0 = %22) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.r(%cst_22, %cst_27) %targets_out : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst_25, %cst_25) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_22, %cst_27) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.r(%cst_1, %cst_27) %controls_out : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_26, %cst_25) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%cst_2, %cst_27) %30 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%31) targets (%arg0 = %28) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qco.r(%cst_23, %cst_27) %targets_out_30 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_0, %cst_25) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.r(%cst_19, %cst_27) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst, %cst_27) %controls_out_29 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_24, %cst_25) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%cst_17, %cst_27) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst_26, %cst_25) %34 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst_26, %cst_27) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_24, %cst_27) %17 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst_26, %cst_25) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst_23, %cst_27) %41 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%42) targets (%arg0 = %39) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qco.r(%cst_22, %cst_27) %targets_out_32 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_25, %cst_25) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst_22, %cst_27) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.r(%cst_6, %cst_27) %controls_out_31 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%cst_26, %cst_25) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst_25, %cst_27) %47 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%48) targets (%arg0 = %45) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qco.r(%cst_22, %cst_27) %targets_out_34 : !qco.qubit -> !qco.qubit
    %50 = qco.r(%cst_5, %cst_25) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.r(%cst_24, %cst_27) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.r(%cst_4, %cst_27) %controls_out_33 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst_24, %cst_25) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.r(%cst_3, %cst_27) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.r(%cst_28, %cst_27) %51 : !qco.qubit -> !qco.qubit
    %56 = qco.r(%cst_26, %cst_25) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.r(%cst_26, %cst_27) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.r(%cst_24, %cst_27) %15 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%cst_26, %cst_25) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.r(%cst_23, %cst_27) %59 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%60) targets (%arg0 = %57) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qco.r(%cst_22, %cst_27) %targets_out_36 : !qco.qubit -> !qco.qubit
    %62 = qco.r(%cst_25, %cst_25) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%cst_22, %cst_27) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.r(%cst_8, %cst_27) %controls_out_35 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%cst_26, %cst_25) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.r(%cst_25, %cst_27) %65 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%66) targets (%arg0 = %63) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %67 = qco.r(%cst_23, %cst_27) %targets_out_38 : !qco.qubit -> !qco.qubit
    %68 = qco.r(%cst_7, %cst_25) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.r(%cst_19, %cst_27) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.r(%cst_18, %cst_27) %controls_out_37 : !qco.qubit -> !qco.qubit
    %71 = qco.r(%cst_24, %cst_25) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%cst_17, %cst_27) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%cst_28, %cst_27) %69 : !qco.qubit -> !qco.qubit
    %74 = qco.r(%cst_26, %cst_25) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.r(%cst_26, %cst_27) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.r(%cst_24, %cst_27) %13 : !qco.qubit -> !qco.qubit
    %77 = qco.r(%cst_26, %cst_25) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst_23, %cst_27) %77 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%78) targets (%arg0 = %75) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %79 = qco.r(%cst_22, %cst_27) %targets_out_40 : !qco.qubit -> !qco.qubit
    %80 = qco.r(%cst_25, %cst_25) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%cst_22, %cst_27) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.r(%cst_12, %cst_27) %controls_out_39 : !qco.qubit -> !qco.qubit
    %83 = qco.r(%cst_26, %cst_25) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.r(%cst_25, %cst_27) %83 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%84) targets (%arg0 = %81) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %85 = qco.r(%cst_11, %cst_27) %targets_out_42 : !qco.qubit -> !qco.qubit
    %86 = qco.r(%cst_10, %cst_25) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.r(%cst_9, %cst_27) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.r(%cst_18, %cst_27) %controls_out_41 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%cst_24, %cst_25) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.r(%cst_17, %cst_27) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.r(%cst_28, %cst_27) %87 : !qco.qubit -> !qco.qubit
    %92 = qco.r(%cst_26, %cst_25) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.r(%cst_26, %cst_27) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.r(%cst_24, %cst_27) %11 : !qco.qubit -> !qco.qubit
    %95 = qco.r(%cst_26, %cst_25) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.r(%cst_23, %cst_27) %95 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%96) targets (%arg0 = %93) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %97 = qco.r(%cst_22, %cst_27) %targets_out_44 : !qco.qubit -> !qco.qubit
    %98 = qco.r(%cst_25, %cst_25) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.r(%cst_22, %cst_27) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.r(%cst_16, %cst_27) %controls_out_43 : !qco.qubit -> !qco.qubit
    %101 = qco.r(%cst_26, %cst_25) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.r(%cst_25, %cst_27) %101 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%102) targets (%arg0 = %99) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %103 = qco.r(%cst_15, %cst_27) %targets_out_46 : !qco.qubit -> !qco.qubit
    %104 = qco.r(%cst_14, %cst_25) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.r(%cst_13, %cst_27) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.r(%cst_18, %cst_27) %controls_out_45 : !qco.qubit -> !qco.qubit
    %107 = qco.r(%cst_24, %cst_25) %106 : !qco.qubit -> !qco.qubit
    %108 = qco.r(%cst_17, %cst_27) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.r(%cst_28, %cst_27) %105 : !qco.qubit -> !qco.qubit
    %110 = qco.r(%cst_26, %cst_25) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.r(%cst_26, %cst_27) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.r(%cst_24, %cst_27) %9 : !qco.qubit -> !qco.qubit
    %113 = qco.r(%cst_26, %cst_25) %112 : !qco.qubit -> !qco.qubit
    %114 = qco.r(%cst_23, %cst_27) %113 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%114) targets (%arg0 = %111) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %115 = qco.r(%cst_22, %cst_27) %targets_out_48 : !qco.qubit -> !qco.qubit
    %116 = qco.r(%cst_25, %cst_25) %115 : !qco.qubit -> !qco.qubit
    %117 = qco.r(%cst_22, %cst_27) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.r(%cst_21, %cst_27) %controls_out_47 : !qco.qubit -> !qco.qubit
    %119 = qco.r(%cst_26, %cst_25) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.r(%cst_25, %cst_27) %119 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%120) targets (%arg0 = %117) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %121 = qco.r(%cst_23, %cst_27) %targets_out_50 : !qco.qubit -> !qco.qubit
    %122 = qco.r(%cst_20, %cst_25) %121 : !qco.qubit -> !qco.qubit
    %123 = qco.r(%cst_19, %cst_27) %122 : !qco.qubit -> !qco.qubit
    %124 = qco.r(%cst_18, %cst_27) %controls_out_49 : !qco.qubit -> !qco.qubit
    %125 = qco.r(%cst_24, %cst_25) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.r(%cst_17, %cst_27) %125 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %123 : !qco.qubit
    cbit.store %result, %7[%c0] : !cbit.reg<7>
    %qubit_out_51, %result_52 = qco.measure %126 : !qco.qubit
    cbit.store %result_52, %7[%c1] : !cbit.reg<7>
    %qubit_out_53, %result_54 = qco.measure %108 : !qco.qubit
    cbit.store %result_54, %7[%c2] : !cbit.reg<7>
    %qubit_out_55, %result_56 = qco.measure %90 : !qco.qubit
    cbit.store %result_56, %7[%c3] : !cbit.reg<7>
    %qubit_out_57, %result_58 = qco.measure %72 : !qco.qubit
    cbit.store %result_58, %7[%c4] : !cbit.reg<7>
    %qubit_out_59, %result_60 = qco.measure %54 : !qco.qubit
    cbit.store %result_60, %7[%c5] : !cbit.reg<7>
    qco.sink %qubit_out_51 : !qco.qubit
    qco.sink %qubit_out_53 : !qco.qubit
    qco.sink %qubit_out_55 : !qco.qubit
    qco.sink %qubit_out_57 : !qco.qubit
    qco.sink %qubit_out_59 : !qco.qubit
    %qubit_out_61, %result_62 = qco.measure %37 : !qco.qubit
    qco.sink %qubit_out_61 : !qco.qubit
    cbit.store %result_62, %7[%c6] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    %cst_63 = arith.constant -3.1415926535897825 : f64
    qco.gphase(%cst_63)
    return %7 : !cbit.reg<7>
  }
}
