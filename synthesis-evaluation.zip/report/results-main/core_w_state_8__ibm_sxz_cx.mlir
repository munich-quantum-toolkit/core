module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant -1.7763568394002505E-15 : f64
    %cst_0 = arith.constant -1.5707963267948939 : f64
    %cst_1 = arith.constant -1.2094292028881886 : f64
    %cst_2 = arith.constant 6.6583840710543658 : f64
    %cst_3 = arith.constant -2.766393889715014 : f64
    %cst_4 = arith.constant -2.7802255296830856 : f64
    %cst_5 = arith.constant -3.1415926535897913 : f64
    %cst_6 = arith.constant -2.6645352591003757E-15 : f64
    %cst_7 = arith.constant -1.5707963267948959 : f64
    %cst_8 = arith.constant -1.5707963267948988 : f64
    %cst_9 = arith.constant -1.183199640139716 : f64
    %cst_10 = arith.constant 6.2831853071795845 : f64
    %cst_11 = arith.constant -1.1831996401397165 : f64
    %cst_12 = arith.constant 4.7123889803846888 : f64
    %cst_13 = arith.constant -1.570796326794895 : f64
    %cst_14 = arith.constant -3.3306690738754696E-15 : f64
    %cst_15 = arith.constant -1.570796326794897 : f64
    %cst_16 = arith.constant -1.1502619915109311 : f64
    %cst_17 = arith.constant -1.1502619915109316 : f64
    %cst_18 = arith.constant -1.5707963267948941 : f64
    %cst_19 = arith.constant -1.5707963267948963 : f64
    %cst_20 = arith.constant -1.1071487177940909 : f64
    %cst_21 = arith.constant 3.6052402625905993 : f64
    %cst_22 = arith.constant 6.2831853071795862 : f64
    %cst_23 = arith.constant -1.5707963267948961 : f64
    %cst_24 = arith.constant -4.7123889803846915 : f64
    %cst_25 = arith.constant -1.0471975511965979 : f64
    %cst_26 = arith.constant -2.6179938779914949 : f64
    %cst_27 = arith.constant -1.5707963267948957 : f64
    %cst_28 = arith.constant 4.7123889803846897 : f64
    %cst_29 = arith.constant 4.7123889803846879 : f64
    %cst_30 = arith.constant -0.95531661812450918 : f64
    %cst_31 = arith.constant 2.5261129449194057 : f64
    %cst_32 = arith.constant 3.1415926535897931 : f64
    %cst_33 = arith.constant 3.1415926535897936 : f64
    %cst_34 = arith.constant 1.570796326794897 : f64
    %cst_35 = arith.constant -6.2831853071795862 : f64
    %cst_36 = arith.constant -3.1415926535897931 : f64
    %cst_37 = arith.constant -0.78539816339744872 : f64
    %cst_38 = arith.constant 1.5707963267948966 : f64
    %cst_39 = arith.constant 7.0685834705770345 : f64
    %cst_40 = arith.constant 4.7123889803846906 : f64
    %cst_41 = arith.constant 1.5707963267948974 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %9 = qco.x %0 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_5) %1 : !qco.qubit -> !qco.qubit
    %11 = qco.sx %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_4) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_3) %9 : !qco.qubit -> !qco.qubit
    %14 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_10) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_2) %16 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%17) targets (%arg0 = %12) {
      %124 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qco.rz(%cst_1) %targets_out : !qco.qubit -> !qco.qubit
    %19 = qco.sx %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_36) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_35) %controls_out : !qco.qubit -> !qco.qubit
    %22 = qco.sx %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_38) %22 : !qco.qubit -> !qco.qubit
    %controls_out_42, %targets_out_43 = qco.ctrl(%23) targets (%arg0 = %20) {
      %124 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.rz(%cst_0) %targets_out_43 : !qco.qubit -> !qco.qubit
    %25 = qco.sx %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_22) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_19) %controls_out_42 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_13) %2 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_12) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.sx %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_11) %33 : !qco.qubit -> !qco.qubit
    %controls_out_44, %targets_out_45 = qco.ctrl(%26) targets (%arg0 = %34) {
      %124 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.rz(%cst_9) %targets_out_45 : !qco.qubit -> !qco.qubit
    %36 = qco.sx %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_36) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_35) %controls_out_44 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_38) %39 : !qco.qubit -> !qco.qubit
    %controls_out_46, %targets_out_47 = qco.ctrl(%40) targets (%arg0 = %37) {
      %124 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.rz(%cst_8) %targets_out_47 : !qco.qubit -> !qco.qubit
    %42 = qco.sx %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_7) %controls_out_46 : !qco.qubit -> !qco.qubit
    %44 = qco.sx %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_6) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_18) %3 : !qco.qubit -> !qco.qubit
    %47 = qco.sx %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_29) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.sx %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_17) %49 : !qco.qubit -> !qco.qubit
    %controls_out_48, %targets_out_49 = qco.ctrl(%42) targets (%arg0 = %50) {
      %124 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %51 = qco.rz(%cst_16) %targets_out_49 : !qco.qubit -> !qco.qubit
    %52 = qco.sx %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_36) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_35) %controls_out_48 : !qco.qubit -> !qco.qubit
    %55 = qco.sx %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_38) %55 : !qco.qubit -> !qco.qubit
    %controls_out_50, %targets_out_51 = qco.ctrl(%56) targets (%arg0 = %53) {
      %124 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %57 = qco.rz(%cst_15) %targets_out_51 : !qco.qubit -> !qco.qubit
    %58 = qco.sx %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_36) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_19) %controls_out_50 : !qco.qubit -> !qco.qubit
    %61 = qco.sx %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_14) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_36) %4 : !qco.qubit -> !qco.qubit
    %64 = qco.sx %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_21) %64 : !qco.qubit -> !qco.qubit
    %controls_out_52, %targets_out_53 = qco.ctrl(%59) targets (%arg0 = %65) {
      %124 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = qco.rz(%cst_20) %targets_out_53 : !qco.qubit -> !qco.qubit
    %67 = qco.sx %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_36) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_35) %controls_out_52 : !qco.qubit -> !qco.qubit
    %70 = qco.sx %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_38) %70 : !qco.qubit -> !qco.qubit
    %controls_out_54, %targets_out_55 = qco.ctrl(%71) targets (%arg0 = %68) {
      %124 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %72 = qco.rz(%cst_19) %targets_out_55 : !qco.qubit -> !qco.qubit
    %73 = qco.sx %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_32) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_23) %controls_out_54 : !qco.qubit -> !qco.qubit
    %76 = qco.sx %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_36) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_36) %5 : !qco.qubit -> !qco.qubit
    %79 = qco.sx %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_26) %79 : !qco.qubit -> !qco.qubit
    %controls_out_56, %targets_out_57 = qco.ctrl(%74) targets (%arg0 = %80) {
      %124 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %81 = qco.rz(%cst_25) %targets_out_57 : !qco.qubit -> !qco.qubit
    %82 = qco.sx %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_36) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_35) %controls_out_56 : !qco.qubit -> !qco.qubit
    %85 = qco.sx %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_38) %85 : !qco.qubit -> !qco.qubit
    %controls_out_58, %targets_out_59 = qco.ctrl(%86) targets (%arg0 = %83) {
      %124 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %87 = qco.rz(%cst_24) %targets_out_59 : !qco.qubit -> !qco.qubit
    %88 = qco.sx %87 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_23) %controls_out_58 : !qco.qubit -> !qco.qubit
    %90 = qco.sx %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_22) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.sx %6 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_31) %92 : !qco.qubit -> !qco.qubit
    %controls_out_60, %targets_out_61 = qco.ctrl(%88) targets (%arg0 = %93) {
      %124 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %94 = qco.rz(%cst_30) %targets_out_61 : !qco.qubit -> !qco.qubit
    %95 = qco.sx %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_36) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_35) %controls_out_60 : !qco.qubit -> !qco.qubit
    %98 = qco.sx %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_38) %98 : !qco.qubit -> !qco.qubit
    %controls_out_62, %targets_out_63 = qco.ctrl(%99) targets (%arg0 = %96) {
      %124 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %100 = qco.sx %targets_out_63 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst_29) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.sx %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst_28) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_27) %controls_out_62 : !qco.qubit -> !qco.qubit
    %105 = qco.sx %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_32) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rz(%cst_41) %7 : !qco.qubit -> !qco.qubit
    %108 = qco.sx %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rz(%cst_40) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.sx %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_39) %110 : !qco.qubit -> !qco.qubit
    %controls_out_64, %targets_out_65 = qco.ctrl(%103) targets (%arg0 = %111) {
      %124 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %112 = qco.rz(%cst_37) %targets_out_65 : !qco.qubit -> !qco.qubit
    %113 = qco.sx %112 : !qco.qubit -> !qco.qubit
    %114 = qco.rz(%cst_36) %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_35) %controls_out_64 : !qco.qubit -> !qco.qubit
    %116 = qco.sx %115 : !qco.qubit -> !qco.qubit
    %117 = qco.rz(%cst_38) %116 : !qco.qubit -> !qco.qubit
    %controls_out_66, %targets_out_67 = qco.ctrl(%117) targets (%arg0 = %114) {
      %124 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %118 = qco.rz(%cst_34) %targets_out_67 : !qco.qubit -> !qco.qubit
    %119 = qco.sx %118 : !qco.qubit -> !qco.qubit
    %120 = qco.rz(%cst_33) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rz(%cst_41) %controls_out_66 : !qco.qubit -> !qco.qubit
    %122 = qco.sx %121 : !qco.qubit -> !qco.qubit
    %123 = qco.rz(%cst_32) %122 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %29 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<8>
    %qubit_out_68, %result_69 = qco.measure %45 : !qco.qubit
    cbit.store %result_69, %8[%c1] : !cbit.reg<8>
    %qubit_out_70, %result_71 = qco.measure %62 : !qco.qubit
    cbit.store %result_71, %8[%c2] : !cbit.reg<8>
    %qubit_out_72, %result_73 = qco.measure %77 : !qco.qubit
    cbit.store %result_73, %8[%c3] : !cbit.reg<8>
    %qubit_out_74, %result_75 = qco.measure %91 : !qco.qubit
    cbit.store %result_75, %8[%c4] : !cbit.reg<8>
    %qubit_out_76, %result_77 = qco.measure %106 : !qco.qubit
    cbit.store %result_77, %8[%c5] : !cbit.reg<8>
    %qubit_out_78, %result_79 = qco.measure %123 : !qco.qubit
    cbit.store %result_79, %8[%c6] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_68 : !qco.qubit
    qco.sink %qubit_out_70 : !qco.qubit
    qco.sink %qubit_out_72 : !qco.qubit
    qco.sink %qubit_out_74 : !qco.qubit
    qco.sink %qubit_out_76 : !qco.qubit
    qco.sink %qubit_out_78 : !qco.qubit
    %qubit_out_80, %result_81 = qco.measure %120 : !qco.qubit
    qco.sink %qubit_out_80 : !qco.qubit
    cbit.store %result_81, %8[%c7] : !cbit.reg<8>
    %cst_82 = arith.constant 1.3322676295501878E-14 : f64
    qco.gphase(%cst_82)
    return %8 : !cbit.reg<8>
  }
}
