module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main(%arg0: f64 {mqt.input_id = 1448859521991596184831488526587787482 : i128, mqt.input_name = "theta[0]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 0 : i64, name = "theta", size = 48 : i64}}, %arg1: f64 {mqt.input_id = 1448859521991596184831488526587787483 : i128, mqt.input_name = "theta[1]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 1 : i64, name = "theta", size = 48 : i64}}, %arg2: f64 {mqt.input_id = 1448859521991596184831488526587787484 : i128, mqt.input_name = "theta[2]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 2 : i64, name = "theta", size = 48 : i64}}, %arg3: f64 {mqt.input_id = 1448859521991596184831488526587787485 : i128, mqt.input_name = "theta[3]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 3 : i64, name = "theta", size = 48 : i64}}, %arg4: f64 {mqt.input_id = 1448859521991596184831488526587787486 : i128, mqt.input_name = "theta[4]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 4 : i64, name = "theta", size = 48 : i64}}, %arg5: f64 {mqt.input_id = 1448859521991596184831488526587787487 : i128, mqt.input_name = "theta[5]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 5 : i64, name = "theta", size = 48 : i64}}, %arg6: f64 {mqt.input_id = 1448859521991596184831488526587787488 : i128, mqt.input_name = "theta[6]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 6 : i64, name = "theta", size = 48 : i64}}, %arg7: f64 {mqt.input_id = 1448859521991596184831488526587787489 : i128, mqt.input_name = "theta[7]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 7 : i64, name = "theta", size = 48 : i64}}, %arg8: f64 {mqt.input_id = 1448859521991596184831488526587787490 : i128, mqt.input_name = "theta[8]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 8 : i64, name = "theta", size = 48 : i64}}, %arg9: f64 {mqt.input_id = 1448859521991596184831488526587787491 : i128, mqt.input_name = "theta[9]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 9 : i64, name = "theta", size = 48 : i64}}, %arg10: f64 {mqt.input_id = 1448859521991596184831488526587787492 : i128, mqt.input_name = "theta[10]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 10 : i64, name = "theta", size = 48 : i64}}, %arg11: f64 {mqt.input_id = 1448859521991596184831488526587787493 : i128, mqt.input_name = "theta[11]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 11 : i64, name = "theta", size = 48 : i64}}, %arg12: f64 {mqt.input_id = 1448859521991596184831488526587787494 : i128, mqt.input_name = "theta[12]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 12 : i64, name = "theta", size = 48 : i64}}, %arg13: f64 {mqt.input_id = 1448859521991596184831488526587787495 : i128, mqt.input_name = "theta[13]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 13 : i64, name = "theta", size = 48 : i64}}, %arg14: f64 {mqt.input_id = 1448859521991596184831488526587787496 : i128, mqt.input_name = "theta[14]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 14 : i64, name = "theta", size = 48 : i64}}, %arg15: f64 {mqt.input_id = 1448859521991596184831488526587787497 : i128, mqt.input_name = "theta[15]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 15 : i64, name = "theta", size = 48 : i64}}, %arg16: f64 {mqt.input_id = 1448859521991596184831488526587787498 : i128, mqt.input_name = "theta[16]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 16 : i64, name = "theta", size = 48 : i64}}, %arg17: f64 {mqt.input_id = 1448859521991596184831488526587787499 : i128, mqt.input_name = "theta[17]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 17 : i64, name = "theta", size = 48 : i64}}, %arg18: f64 {mqt.input_id = 1448859521991596184831488526587787500 : i128, mqt.input_name = "theta[18]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 18 : i64, name = "theta", size = 48 : i64}}, %arg19: f64 {mqt.input_id = 1448859521991596184831488526587787501 : i128, mqt.input_name = "theta[19]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 19 : i64, name = "theta", size = 48 : i64}}, %arg20: f64 {mqt.input_id = 1448859521991596184831488526587787502 : i128, mqt.input_name = "theta[20]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 20 : i64, name = "theta", size = 48 : i64}}, %arg21: f64 {mqt.input_id = 1448859521991596184831488526587787503 : i128, mqt.input_name = "theta[21]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 21 : i64, name = "theta", size = 48 : i64}}, %arg22: f64 {mqt.input_id = 1448859521991596184831488526587787504 : i128, mqt.input_name = "theta[22]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 22 : i64, name = "theta", size = 48 : i64}}, %arg23: f64 {mqt.input_id = 1448859521991596184831488526587787505 : i128, mqt.input_name = "theta[23]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 23 : i64, name = "theta", size = 48 : i64}}, %arg24: f64 {mqt.input_id = 1448859521991596184831488526587787506 : i128, mqt.input_name = "theta[24]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 24 : i64, name = "theta", size = 48 : i64}}, %arg25: f64 {mqt.input_id = 1448859521991596184831488526587787507 : i128, mqt.input_name = "theta[25]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 25 : i64, name = "theta", size = 48 : i64}}, %arg26: f64 {mqt.input_id = 1448859521991596184831488526587787508 : i128, mqt.input_name = "theta[26]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 26 : i64, name = "theta", size = 48 : i64}}, %arg27: f64 {mqt.input_id = 1448859521991596184831488526587787509 : i128, mqt.input_name = "theta[27]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 27 : i64, name = "theta", size = 48 : i64}}, %arg28: f64 {mqt.input_id = 1448859521991596184831488526587787510 : i128, mqt.input_name = "theta[28]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 28 : i64, name = "theta", size = 48 : i64}}, %arg29: f64 {mqt.input_id = 1448859521991596184831488526587787511 : i128, mqt.input_name = "theta[29]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 29 : i64, name = "theta", size = 48 : i64}}, %arg30: f64 {mqt.input_id = 1448859521991596184831488526587787512 : i128, mqt.input_name = "theta[30]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 30 : i64, name = "theta", size = 48 : i64}}, %arg31: f64 {mqt.input_id = 1448859521991596184831488526587787513 : i128, mqt.input_name = "theta[31]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 31 : i64, name = "theta", size = 48 : i64}}, %arg32: f64 {mqt.input_id = 1448859521991596184831488526587787514 : i128, mqt.input_name = "theta[32]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 32 : i64, name = "theta", size = 48 : i64}}, %arg33: f64 {mqt.input_id = 1448859521991596184831488526587787515 : i128, mqt.input_name = "theta[33]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 33 : i64, name = "theta", size = 48 : i64}}, %arg34: f64 {mqt.input_id = 1448859521991596184831488526587787516 : i128, mqt.input_name = "theta[34]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 34 : i64, name = "theta", size = 48 : i64}}, %arg35: f64 {mqt.input_id = 1448859521991596184831488526587787517 : i128, mqt.input_name = "theta[35]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 35 : i64, name = "theta", size = 48 : i64}}, %arg36: f64 {mqt.input_id = 1448859521991596184831488526587787518 : i128, mqt.input_name = "theta[36]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 36 : i64, name = "theta", size = 48 : i64}}, %arg37: f64 {mqt.input_id = 1448859521991596184831488526587787519 : i128, mqt.input_name = "theta[37]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 37 : i64, name = "theta", size = 48 : i64}}, %arg38: f64 {mqt.input_id = 1448859521991596184831488526587787520 : i128, mqt.input_name = "theta[38]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 38 : i64, name = "theta", size = 48 : i64}}, %arg39: f64 {mqt.input_id = 1448859521991596184831488526587787521 : i128, mqt.input_name = "theta[39]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 39 : i64, name = "theta", size = 48 : i64}}, %arg40: f64 {mqt.input_id = 1448859521991596184831488526587787522 : i128, mqt.input_name = "theta[40]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 40 : i64, name = "theta", size = 48 : i64}}, %arg41: f64 {mqt.input_id = 1448859521991596184831488526587787523 : i128, mqt.input_name = "theta[41]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 41 : i64, name = "theta", size = 48 : i64}}, %arg42: f64 {mqt.input_id = 1448859521991596184831488526587787524 : i128, mqt.input_name = "theta[42]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 42 : i64, name = "theta", size = 48 : i64}}, %arg43: f64 {mqt.input_id = 1448859521991596184831488526587787525 : i128, mqt.input_name = "theta[43]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 43 : i64, name = "theta", size = 48 : i64}}, %arg44: f64 {mqt.input_id = 1448859521991596184831488526587787526 : i128, mqt.input_name = "theta[44]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 44 : i64, name = "theta", size = 48 : i64}}, %arg45: f64 {mqt.input_id = 1448859521991596184831488526587787527 : i128, mqt.input_name = "theta[45]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 45 : i64, name = "theta", size = 48 : i64}}, %arg46: f64 {mqt.input_id = 1448859521991596184831488526587787528 : i128, mqt.input_name = "theta[46]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 46 : i64, name = "theta", size = 48 : i64}}, %arg47: f64 {mqt.input_id = 1448859521991596184831488526587787529 : i128, mqt.input_name = "theta[47]", mqt.parameter_group = {identity = "01170a4a-2518-4b9f-937b-759e9973f8da", index = 47 : i64, name = "theta", size = 48 : i64}}) -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 4.000000e+00 : f64
    %cst_0 = arith.constant 3.1415926535897931 : f64
    %cst_1 = arith.constant 2.000000e+00 : f64
    %cst_2 = arith.constant 0.000000e+00 : f64
    %cst_3 = arith.constant 3.000000e-01 : f64
    %cst_4 = arith.constant 2.000000e-01 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = arith.divf %arg0, %cst : f64
    %17 = math.tan %16 : f64
    %18 = math.atan %17 : f64
    %19 = arith.mulf %18, %cst : f64
    %20 = arith.divf %cst_0, %cst_1 : f64
    %21 = arith.negf %20 : f64
    %22 = qco.r(%21, %cst_2) %0 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%19, %20) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%20, %cst_2) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_3, %cst_4) %24 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%25) targets (%arg48 = %1) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = arith.divf %arg1, %cst : f64
    %27 = math.tan %26 : f64
    %28 = math.atan %27 : f64
    %29 = arith.mulf %28, %cst : f64
    %30 = qco.r(%21, %cst_2) %targets_out : !qco.qubit -> !qco.qubit
    %31 = qco.r(%29, %20) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%20, %cst_2) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_3, %cst_4) %32 : !qco.qubit -> !qco.qubit
    %controls_out_5, %targets_out_6 = qco.ctrl(%33) targets (%arg48 = %2) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = arith.divf %arg2, %cst : f64
    %35 = math.tan %34 : f64
    %36 = math.atan %35 : f64
    %37 = arith.mulf %36, %cst : f64
    %38 = qco.r(%21, %cst_2) %targets_out_6 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%37, %20) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%20, %cst_2) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst_3, %cst_4) %40 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%41) targets (%arg48 = %3) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = arith.divf %arg3, %cst : f64
    %43 = math.tan %42 : f64
    %44 = math.atan %43 : f64
    %45 = arith.mulf %44, %cst : f64
    %46 = qco.r(%21, %cst_2) %targets_out_8 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%45, %20) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%20, %cst_2) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.r(%cst_3, %cst_4) %48 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%49) targets (%arg48 = %4) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = arith.divf %arg4, %cst : f64
    %51 = math.tan %50 : f64
    %52 = math.atan %51 : f64
    %53 = arith.mulf %52, %cst : f64
    %54 = qco.r(%21, %cst_2) %targets_out_10 : !qco.qubit -> !qco.qubit
    %55 = qco.r(%53, %20) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.r(%20, %cst_2) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.r(%cst_3, %cst_4) %56 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%57) targets (%arg48 = %5) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = arith.divf %arg5, %cst : f64
    %59 = math.tan %58 : f64
    %60 = math.atan %59 : f64
    %61 = arith.mulf %60, %cst : f64
    %62 = qco.r(%21, %cst_2) %targets_out_12 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%61, %20) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.r(%20, %cst_2) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%cst_3, %cst_4) %64 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%65) targets (%arg48 = %6) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = arith.divf %arg6, %cst : f64
    %67 = math.tan %66 : f64
    %68 = math.atan %67 : f64
    %69 = arith.mulf %68, %cst : f64
    %70 = qco.r(%21, %cst_2) %targets_out_14 : !qco.qubit -> !qco.qubit
    %71 = qco.r(%69, %20) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%20, %cst_2) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%cst_3, %cst_4) %72 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%73) targets (%arg48 = %7) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %74 = arith.divf %arg7, %cst : f64
    %75 = math.tan %74 : f64
    %76 = math.atan %75 : f64
    %77 = arith.mulf %76, %cst : f64
    %78 = qco.r(%21, %cst_2) %targets_out_16 : !qco.qubit -> !qco.qubit
    %79 = qco.r(%77, %20) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.r(%20, %cst_2) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%cst_3, %cst_4) %80 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%81) targets (%arg48 = %8) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %82 = arith.divf %arg8, %cst : f64
    %83 = math.tan %82 : f64
    %84 = math.atan %83 : f64
    %85 = arith.mulf %84, %cst : f64
    %86 = qco.r(%21, %cst_2) %targets_out_18 : !qco.qubit -> !qco.qubit
    %87 = qco.r(%85, %20) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.r(%20, %cst_2) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%cst_3, %cst_4) %88 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%89) targets (%arg48 = %9) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %90 = arith.divf %arg9, %cst : f64
    %91 = math.tan %90 : f64
    %92 = math.atan %91 : f64
    %93 = arith.mulf %92, %cst : f64
    %94 = qco.r(%21, %cst_2) %targets_out_20 : !qco.qubit -> !qco.qubit
    %95 = qco.r(%93, %20) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.r(%20, %cst_2) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.r(%cst_3, %cst_4) %96 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%97) targets (%arg48 = %10) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %98 = arith.divf %arg10, %cst : f64
    %99 = math.tan %98 : f64
    %100 = math.atan %99 : f64
    %101 = arith.mulf %100, %cst : f64
    %102 = qco.r(%21, %cst_2) %targets_out_22 : !qco.qubit -> !qco.qubit
    %103 = qco.r(%101, %20) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.r(%20, %cst_2) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.r(%cst_3, %cst_4) %104 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%105) targets (%arg48 = %11) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %106 = arith.divf %arg11, %cst : f64
    %107 = math.tan %106 : f64
    %108 = math.atan %107 : f64
    %109 = arith.mulf %108, %cst : f64
    %110 = qco.r(%21, %cst_2) %targets_out_24 : !qco.qubit -> !qco.qubit
    %111 = qco.r(%109, %20) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.r(%20, %cst_2) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.r(%cst_3, %cst_4) %112 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%113) targets (%arg48 = %12) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %114 = arith.divf %arg12, %cst : f64
    %115 = math.tan %114 : f64
    %116 = math.atan %115 : f64
    %117 = arith.mulf %116, %cst : f64
    %118 = qco.r(%21, %cst_2) %targets_out_26 : !qco.qubit -> !qco.qubit
    %119 = qco.r(%117, %20) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.r(%20, %cst_2) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.r(%cst_3, %cst_4) %120 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%121) targets (%arg48 = %13) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %122 = arith.divf %arg13, %cst : f64
    %123 = math.tan %122 : f64
    %124 = math.atan %123 : f64
    %125 = arith.mulf %124, %cst : f64
    %126 = qco.r(%21, %cst_2) %targets_out_28 : !qco.qubit -> !qco.qubit
    %127 = qco.r(%125, %20) %126 : !qco.qubit -> !qco.qubit
    %128 = qco.r(%20, %cst_2) %127 : !qco.qubit -> !qco.qubit
    %129 = qco.r(%cst_3, %cst_4) %128 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%129) targets (%arg48 = %14) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %130 = arith.divf %arg14, %cst : f64
    %131 = math.tan %130 : f64
    %132 = math.atan %131 : f64
    %133 = arith.mulf %132, %cst : f64
    %134 = qco.r(%21, %cst_2) %targets_out_30 : !qco.qubit -> !qco.qubit
    %135 = qco.r(%133, %20) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.r(%20, %cst_2) %135 : !qco.qubit -> !qco.qubit
    %137 = qco.r(%cst_3, %cst_4) %136 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%137) targets (%arg48 = %15) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %138 = arith.divf %arg15, %cst : f64
    %139 = math.tan %138 : f64
    %140 = math.atan %139 : f64
    %141 = arith.mulf %140, %cst : f64
    %142 = qco.r(%21, %cst_2) %targets_out_32 : !qco.qubit -> !qco.qubit
    %143 = qco.r(%141, %20) %142 : !qco.qubit -> !qco.qubit
    %144 = qco.r(%20, %cst_2) %143 : !qco.qubit -> !qco.qubit
    %145 = qco.r(%cst_3, %cst_4) %144 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%145) targets (%arg48 = %controls_out) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %146 = arith.divf %arg16, %cst : f64
    %147 = math.tan %146 : f64
    %148 = math.atan %147 : f64
    %149 = arith.mulf %148, %cst : f64
    %150 = qco.r(%21, %cst_2) %targets_out_34 : !qco.qubit -> !qco.qubit
    %151 = qco.r(%149, %20) %150 : !qco.qubit -> !qco.qubit
    %152 = qco.r(%20, %cst_2) %151 : !qco.qubit -> !qco.qubit
    %153 = qco.r(%cst_3, %cst_4) %152 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%153) targets (%arg48 = %controls_out_5) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %154 = arith.divf %arg17, %cst : f64
    %155 = math.tan %154 : f64
    %156 = math.atan %155 : f64
    %157 = arith.mulf %156, %cst : f64
    %158 = qco.r(%21, %cst_2) %targets_out_36 : !qco.qubit -> !qco.qubit
    %159 = qco.r(%157, %20) %158 : !qco.qubit -> !qco.qubit
    %160 = qco.r(%20, %cst_2) %159 : !qco.qubit -> !qco.qubit
    %161 = qco.r(%cst_3, %cst_4) %160 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%161) targets (%arg48 = %controls_out_7) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %162 = arith.divf %arg18, %cst : f64
    %163 = math.tan %162 : f64
    %164 = math.atan %163 : f64
    %165 = arith.mulf %164, %cst : f64
    %166 = qco.r(%21, %cst_2) %targets_out_38 : !qco.qubit -> !qco.qubit
    %167 = qco.r(%165, %20) %166 : !qco.qubit -> !qco.qubit
    %168 = qco.r(%20, %cst_2) %167 : !qco.qubit -> !qco.qubit
    %169 = qco.r(%cst_3, %cst_4) %168 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%169) targets (%arg48 = %controls_out_9) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %170 = arith.divf %arg19, %cst : f64
    %171 = math.tan %170 : f64
    %172 = math.atan %171 : f64
    %173 = arith.mulf %172, %cst : f64
    %174 = qco.r(%21, %cst_2) %targets_out_40 : !qco.qubit -> !qco.qubit
    %175 = qco.r(%173, %20) %174 : !qco.qubit -> !qco.qubit
    %176 = qco.r(%20, %cst_2) %175 : !qco.qubit -> !qco.qubit
    %177 = qco.r(%cst_3, %cst_4) %176 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%177) targets (%arg48 = %controls_out_11) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %178 = arith.divf %arg20, %cst : f64
    %179 = math.tan %178 : f64
    %180 = math.atan %179 : f64
    %181 = arith.mulf %180, %cst : f64
    %182 = qco.r(%21, %cst_2) %targets_out_42 : !qco.qubit -> !qco.qubit
    %183 = qco.r(%181, %20) %182 : !qco.qubit -> !qco.qubit
    %184 = qco.r(%20, %cst_2) %183 : !qco.qubit -> !qco.qubit
    %185 = qco.r(%cst_3, %cst_4) %184 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%185) targets (%arg48 = %controls_out_13) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %186 = arith.divf %arg21, %cst : f64
    %187 = math.tan %186 : f64
    %188 = math.atan %187 : f64
    %189 = arith.mulf %188, %cst : f64
    %190 = qco.r(%21, %cst_2) %targets_out_44 : !qco.qubit -> !qco.qubit
    %191 = qco.r(%189, %20) %190 : !qco.qubit -> !qco.qubit
    %192 = qco.r(%20, %cst_2) %191 : !qco.qubit -> !qco.qubit
    %193 = qco.r(%cst_3, %cst_4) %192 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%193) targets (%arg48 = %controls_out_15) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %194 = arith.divf %arg22, %cst : f64
    %195 = math.tan %194 : f64
    %196 = math.atan %195 : f64
    %197 = arith.mulf %196, %cst : f64
    %198 = qco.r(%21, %cst_2) %targets_out_46 : !qco.qubit -> !qco.qubit
    %199 = qco.r(%197, %20) %198 : !qco.qubit -> !qco.qubit
    %200 = qco.r(%20, %cst_2) %199 : !qco.qubit -> !qco.qubit
    %201 = qco.r(%cst_3, %cst_4) %200 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%201) targets (%arg48 = %controls_out_17) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %202 = arith.divf %arg23, %cst : f64
    %203 = math.tan %202 : f64
    %204 = math.atan %203 : f64
    %205 = arith.mulf %204, %cst : f64
    %206 = qco.r(%21, %cst_2) %targets_out_48 : !qco.qubit -> !qco.qubit
    %207 = qco.r(%205, %20) %206 : !qco.qubit -> !qco.qubit
    %208 = qco.r(%20, %cst_2) %207 : !qco.qubit -> !qco.qubit
    %209 = qco.r(%cst_3, %cst_4) %208 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%209) targets (%arg48 = %controls_out_19) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %210 = arith.divf %arg24, %cst : f64
    %211 = math.tan %210 : f64
    %212 = math.atan %211 : f64
    %213 = arith.mulf %212, %cst : f64
    %214 = qco.r(%21, %cst_2) %targets_out_50 : !qco.qubit -> !qco.qubit
    %215 = qco.r(%213, %20) %214 : !qco.qubit -> !qco.qubit
    %216 = qco.r(%20, %cst_2) %215 : !qco.qubit -> !qco.qubit
    %217 = qco.r(%cst_3, %cst_4) %216 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%217) targets (%arg48 = %controls_out_21) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %218 = arith.divf %arg25, %cst : f64
    %219 = math.tan %218 : f64
    %220 = math.atan %219 : f64
    %221 = arith.mulf %220, %cst : f64
    %222 = qco.r(%21, %cst_2) %targets_out_52 : !qco.qubit -> !qco.qubit
    %223 = qco.r(%221, %20) %222 : !qco.qubit -> !qco.qubit
    %224 = qco.r(%20, %cst_2) %223 : !qco.qubit -> !qco.qubit
    %225 = qco.r(%cst_3, %cst_4) %224 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%225) targets (%arg48 = %controls_out_23) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %226 = arith.divf %arg26, %cst : f64
    %227 = math.tan %226 : f64
    %228 = math.atan %227 : f64
    %229 = arith.mulf %228, %cst : f64
    %230 = qco.r(%21, %cst_2) %targets_out_54 : !qco.qubit -> !qco.qubit
    %231 = qco.r(%229, %20) %230 : !qco.qubit -> !qco.qubit
    %232 = qco.r(%20, %cst_2) %231 : !qco.qubit -> !qco.qubit
    %233 = qco.r(%cst_3, %cst_4) %232 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%233) targets (%arg48 = %controls_out_25) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %234 = arith.divf %arg27, %cst : f64
    %235 = math.tan %234 : f64
    %236 = math.atan %235 : f64
    %237 = arith.mulf %236, %cst : f64
    %238 = qco.r(%21, %cst_2) %targets_out_56 : !qco.qubit -> !qco.qubit
    %239 = qco.r(%237, %20) %238 : !qco.qubit -> !qco.qubit
    %240 = qco.r(%20, %cst_2) %239 : !qco.qubit -> !qco.qubit
    %241 = qco.r(%cst_3, %cst_4) %240 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%241) targets (%arg48 = %controls_out_27) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %242 = arith.divf %arg28, %cst : f64
    %243 = math.tan %242 : f64
    %244 = math.atan %243 : f64
    %245 = arith.mulf %244, %cst : f64
    %246 = qco.r(%21, %cst_2) %targets_out_58 : !qco.qubit -> !qco.qubit
    %247 = qco.r(%245, %20) %246 : !qco.qubit -> !qco.qubit
    %248 = qco.r(%20, %cst_2) %247 : !qco.qubit -> !qco.qubit
    %249 = qco.r(%cst_3, %cst_4) %248 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%249) targets (%arg48 = %controls_out_29) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %250 = arith.divf %arg29, %cst : f64
    %251 = math.tan %250 : f64
    %252 = math.atan %251 : f64
    %253 = arith.mulf %252, %cst : f64
    %254 = qco.r(%21, %cst_2) %targets_out_60 : !qco.qubit -> !qco.qubit
    %255 = qco.r(%253, %20) %254 : !qco.qubit -> !qco.qubit
    %256 = qco.r(%20, %cst_2) %255 : !qco.qubit -> !qco.qubit
    %257 = qco.r(%cst_3, %cst_4) %256 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%257) targets (%arg48 = %controls_out_31) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %258 = arith.divf %arg30, %cst : f64
    %259 = math.tan %258 : f64
    %260 = math.atan %259 : f64
    %261 = arith.mulf %260, %cst : f64
    %262 = qco.r(%21, %cst_2) %targets_out_62 : !qco.qubit -> !qco.qubit
    %263 = qco.r(%261, %20) %262 : !qco.qubit -> !qco.qubit
    %264 = qco.r(%20, %cst_2) %263 : !qco.qubit -> !qco.qubit
    %265 = qco.r(%cst_3, %cst_4) %264 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%265) targets (%arg48 = %controls_out_33) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %266 = arith.divf %arg31, %cst : f64
    %267 = math.tan %266 : f64
    %268 = math.atan %267 : f64
    %269 = arith.mulf %268, %cst : f64
    %270 = qco.r(%21, %cst_2) %targets_out_64 : !qco.qubit -> !qco.qubit
    %271 = qco.r(%269, %20) %270 : !qco.qubit -> !qco.qubit
    %272 = qco.r(%20, %cst_2) %271 : !qco.qubit -> !qco.qubit
    %273 = qco.r(%cst_3, %cst_4) %272 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%273) targets (%arg48 = %controls_out_35) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %274 = arith.divf %arg32, %cst : f64
    %275 = math.tan %274 : f64
    %276 = math.atan %275 : f64
    %277 = arith.mulf %276, %cst : f64
    %278 = qco.r(%21, %cst_2) %targets_out_66 : !qco.qubit -> !qco.qubit
    %279 = qco.r(%277, %20) %278 : !qco.qubit -> !qco.qubit
    %280 = qco.r(%20, %cst_2) %279 : !qco.qubit -> !qco.qubit
    %281 = qco.r(%cst_3, %cst_4) %280 : !qco.qubit -> !qco.qubit
    %controls_out_67, %targets_out_68 = qco.ctrl(%281) targets (%arg48 = %controls_out_37) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %282 = arith.divf %arg33, %cst : f64
    %283 = math.tan %282 : f64
    %284 = math.atan %283 : f64
    %285 = arith.mulf %284, %cst : f64
    %286 = qco.r(%21, %cst_2) %targets_out_68 : !qco.qubit -> !qco.qubit
    %287 = qco.r(%285, %20) %286 : !qco.qubit -> !qco.qubit
    %288 = qco.r(%20, %cst_2) %287 : !qco.qubit -> !qco.qubit
    %289 = qco.r(%cst_3, %cst_4) %288 : !qco.qubit -> !qco.qubit
    %controls_out_69, %targets_out_70 = qco.ctrl(%289) targets (%arg48 = %controls_out_39) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %290 = arith.divf %arg34, %cst : f64
    %291 = math.tan %290 : f64
    %292 = math.atan %291 : f64
    %293 = arith.mulf %292, %cst : f64
    %294 = qco.r(%21, %cst_2) %targets_out_70 : !qco.qubit -> !qco.qubit
    %295 = qco.r(%293, %20) %294 : !qco.qubit -> !qco.qubit
    %296 = qco.r(%20, %cst_2) %295 : !qco.qubit -> !qco.qubit
    %297 = qco.r(%cst_3, %cst_4) %296 : !qco.qubit -> !qco.qubit
    %controls_out_71, %targets_out_72 = qco.ctrl(%297) targets (%arg48 = %controls_out_41) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %298 = arith.divf %arg35, %cst : f64
    %299 = math.tan %298 : f64
    %300 = math.atan %299 : f64
    %301 = arith.mulf %300, %cst : f64
    %302 = qco.r(%21, %cst_2) %targets_out_72 : !qco.qubit -> !qco.qubit
    %303 = qco.r(%301, %20) %302 : !qco.qubit -> !qco.qubit
    %304 = qco.r(%20, %cst_2) %303 : !qco.qubit -> !qco.qubit
    %305 = qco.r(%cst_3, %cst_4) %304 : !qco.qubit -> !qco.qubit
    %controls_out_73, %targets_out_74 = qco.ctrl(%305) targets (%arg48 = %controls_out_43) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %306 = arith.divf %arg36, %cst : f64
    %307 = math.tan %306 : f64
    %308 = math.atan %307 : f64
    %309 = arith.mulf %308, %cst : f64
    %310 = qco.r(%21, %cst_2) %targets_out_74 : !qco.qubit -> !qco.qubit
    %311 = qco.r(%309, %20) %310 : !qco.qubit -> !qco.qubit
    %312 = qco.r(%20, %cst_2) %311 : !qco.qubit -> !qco.qubit
    %313 = qco.r(%cst_3, %cst_4) %312 : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%313) targets (%arg48 = %controls_out_45) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %314 = arith.divf %arg37, %cst : f64
    %315 = math.tan %314 : f64
    %316 = math.atan %315 : f64
    %317 = arith.mulf %316, %cst : f64
    %318 = qco.r(%21, %cst_2) %targets_out_76 : !qco.qubit -> !qco.qubit
    %319 = qco.r(%317, %20) %318 : !qco.qubit -> !qco.qubit
    %320 = qco.r(%20, %cst_2) %319 : !qco.qubit -> !qco.qubit
    %321 = qco.r(%cst_3, %cst_4) %320 : !qco.qubit -> !qco.qubit
    %controls_out_77, %targets_out_78 = qco.ctrl(%321) targets (%arg48 = %controls_out_47) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %322 = arith.divf %arg38, %cst : f64
    %323 = math.tan %322 : f64
    %324 = math.atan %323 : f64
    %325 = arith.mulf %324, %cst : f64
    %326 = qco.r(%21, %cst_2) %targets_out_78 : !qco.qubit -> !qco.qubit
    %327 = qco.r(%325, %20) %326 : !qco.qubit -> !qco.qubit
    %328 = qco.r(%20, %cst_2) %327 : !qco.qubit -> !qco.qubit
    %329 = qco.r(%cst_3, %cst_4) %328 : !qco.qubit -> !qco.qubit
    %controls_out_79, %targets_out_80 = qco.ctrl(%329) targets (%arg48 = %controls_out_49) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %330 = arith.divf %arg39, %cst : f64
    %331 = math.tan %330 : f64
    %332 = math.atan %331 : f64
    %333 = arith.mulf %332, %cst : f64
    %334 = qco.r(%21, %cst_2) %targets_out_80 : !qco.qubit -> !qco.qubit
    %335 = qco.r(%333, %20) %334 : !qco.qubit -> !qco.qubit
    %336 = qco.r(%20, %cst_2) %335 : !qco.qubit -> !qco.qubit
    %337 = qco.r(%cst_3, %cst_4) %336 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%337) targets (%arg48 = %controls_out_51) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %338 = arith.divf %arg40, %cst : f64
    %339 = math.tan %338 : f64
    %340 = math.atan %339 : f64
    %341 = arith.mulf %340, %cst : f64
    %342 = qco.r(%21, %cst_2) %targets_out_82 : !qco.qubit -> !qco.qubit
    %343 = qco.r(%341, %20) %342 : !qco.qubit -> !qco.qubit
    %344 = qco.r(%20, %cst_2) %343 : !qco.qubit -> !qco.qubit
    %345 = qco.r(%cst_3, %cst_4) %344 : !qco.qubit -> !qco.qubit
    %controls_out_83, %targets_out_84 = qco.ctrl(%345) targets (%arg48 = %controls_out_53) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %346 = arith.divf %arg41, %cst : f64
    %347 = math.tan %346 : f64
    %348 = math.atan %347 : f64
    %349 = arith.mulf %348, %cst : f64
    %350 = qco.r(%21, %cst_2) %targets_out_84 : !qco.qubit -> !qco.qubit
    %351 = qco.r(%349, %20) %350 : !qco.qubit -> !qco.qubit
    %352 = qco.r(%20, %cst_2) %351 : !qco.qubit -> !qco.qubit
    %353 = qco.r(%cst_3, %cst_4) %352 : !qco.qubit -> !qco.qubit
    %controls_out_85, %targets_out_86 = qco.ctrl(%353) targets (%arg48 = %controls_out_55) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %354 = arith.divf %arg42, %cst : f64
    %355 = math.tan %354 : f64
    %356 = math.atan %355 : f64
    %357 = arith.mulf %356, %cst : f64
    %358 = qco.r(%21, %cst_2) %targets_out_86 : !qco.qubit -> !qco.qubit
    %359 = qco.r(%357, %20) %358 : !qco.qubit -> !qco.qubit
    %360 = qco.r(%20, %cst_2) %359 : !qco.qubit -> !qco.qubit
    %361 = qco.r(%cst_3, %cst_4) %360 : !qco.qubit -> !qco.qubit
    %controls_out_87, %targets_out_88 = qco.ctrl(%361) targets (%arg48 = %controls_out_57) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %362 = arith.divf %arg43, %cst : f64
    %363 = math.tan %362 : f64
    %364 = math.atan %363 : f64
    %365 = arith.mulf %364, %cst : f64
    %366 = qco.r(%21, %cst_2) %targets_out_88 : !qco.qubit -> !qco.qubit
    %367 = qco.r(%365, %20) %366 : !qco.qubit -> !qco.qubit
    %368 = qco.r(%20, %cst_2) %367 : !qco.qubit -> !qco.qubit
    %369 = qco.r(%cst_3, %cst_4) %368 : !qco.qubit -> !qco.qubit
    %controls_out_89, %targets_out_90 = qco.ctrl(%369) targets (%arg48 = %controls_out_59) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %370 = arith.divf %arg44, %cst : f64
    %371 = math.tan %370 : f64
    %372 = math.atan %371 : f64
    %373 = arith.mulf %372, %cst : f64
    %374 = qco.r(%21, %cst_2) %targets_out_90 : !qco.qubit -> !qco.qubit
    %375 = qco.r(%373, %20) %374 : !qco.qubit -> !qco.qubit
    %376 = qco.r(%20, %cst_2) %375 : !qco.qubit -> !qco.qubit
    %377 = qco.r(%cst_3, %cst_4) %376 : !qco.qubit -> !qco.qubit
    %controls_out_91, %targets_out_92 = qco.ctrl(%377) targets (%arg48 = %controls_out_61) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %378 = arith.divf %arg45, %cst : f64
    %379 = math.tan %378 : f64
    %380 = math.atan %379 : f64
    %381 = arith.mulf %380, %cst : f64
    %382 = qco.r(%21, %cst_2) %targets_out_92 : !qco.qubit -> !qco.qubit
    %383 = qco.r(%381, %20) %382 : !qco.qubit -> !qco.qubit
    %384 = qco.r(%20, %cst_2) %383 : !qco.qubit -> !qco.qubit
    %385 = qco.r(%cst_3, %cst_4) %384 : !qco.qubit -> !qco.qubit
    %controls_out_93, %targets_out_94 = qco.ctrl(%385) targets (%arg48 = %controls_out_63) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %386 = arith.divf %arg46, %cst : f64
    %387 = math.tan %386 : f64
    %388 = math.atan %387 : f64
    %389 = arith.mulf %388, %cst : f64
    %390 = qco.r(%21, %cst_2) %targets_out_94 : !qco.qubit -> !qco.qubit
    %391 = qco.r(%389, %20) %390 : !qco.qubit -> !qco.qubit
    %392 = qco.r(%20, %cst_2) %391 : !qco.qubit -> !qco.qubit
    %393 = qco.r(%cst_3, %cst_4) %392 : !qco.qubit -> !qco.qubit
    %controls_out_95, %targets_out_96 = qco.ctrl(%393) targets (%arg48 = %controls_out_65) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %394 = arith.divf %arg47, %cst : f64
    %395 = math.tan %394 : f64
    %396 = math.atan %395 : f64
    %397 = arith.mulf %396, %cst : f64
    %398 = qco.r(%21, %cst_2) %targets_out_96 : !qco.qubit -> !qco.qubit
    %399 = qco.r(%397, %20) %398 : !qco.qubit -> !qco.qubit
    %400 = qco.r(%20, %cst_2) %399 : !qco.qubit -> !qco.qubit
    %401 = qco.r(%cst_3, %cst_4) %400 : !qco.qubit -> !qco.qubit
    qco.sink %controls_out_69 : !qco.qubit
    qco.sink %controls_out_71 : !qco.qubit
    qco.sink %controls_out_73 : !qco.qubit
    qco.sink %controls_out_75 : !qco.qubit
    qco.sink %controls_out_77 : !qco.qubit
    qco.sink %controls_out_79 : !qco.qubit
    qco.sink %controls_out_81 : !qco.qubit
    qco.sink %controls_out_83 : !qco.qubit
    qco.sink %controls_out_85 : !qco.qubit
    qco.sink %controls_out_87 : !qco.qubit
    qco.sink %controls_out_89 : !qco.qubit
    qco.sink %controls_out_91 : !qco.qubit
    qco.sink %controls_out_93 : !qco.qubit
    qco.sink %controls_out_95 : !qco.qubit
    %controls_out_97, %targets_out_98 = qco.ctrl(%401) targets (%arg48 = %controls_out_67) {
      %402 = qco.z %arg48 : !qco.qubit -> !qco.qubit
      qco.yield %402 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    qco.sink %targets_out_98 : !qco.qubit
    qco.sink %controls_out_97 : !qco.qubit
    return %c0_i64 : i64
  }
}
