module attributes {mqt.layout = {initial = array<i64: 0, 1>, input_count = 2 : i64, sites = array<i64: 0, 1>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 5.413185307179587 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant 0.78539816339744828 : f64
    %cst_2 = arith.constant 3.1415926535897931 : f64
    %cst_3 = arith.constant 2.3561944901923448 : f64
    %cst_4 = arith.constant 4.7123889803846897 : f64
    %cst_5 = arith.constant 6.2831853071795862 : f64
    %cst_6 = arith.constant 1.5707963267948966 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.rx(%cst_6) %1 : !qco.qubit -> !qco.qubit
    %3 = qco.rz(%cst_5) %2 : !qco.qubit -> !qco.qubit
    %4 = qco.rz(%cst_4) %0 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %4, %3 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %5 = qco.rz(%cst_3) %qubit1_out : !qco.qubit -> !qco.qubit
    %6 = qco.rx(%cst_2) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_1) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_0) %qubit0_out : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_6) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_6) %10 : !qco.qubit -> !qco.qubit
    %qubit0_out_7, %qubit1_out_8 = qco.iswap %11, %7 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %12 = qco.rz(%cst_6) %qubit1_out_8 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_6) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_2) %qubit0_out_7 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_2) %14 : !qco.qubit -> !qco.qubit
    qco.sink %13 : !qco.qubit
    qco.sink %15 : !qco.qubit
    qco.gphase(%cst_2)
    return %c0_i64 : i64
  }
}
