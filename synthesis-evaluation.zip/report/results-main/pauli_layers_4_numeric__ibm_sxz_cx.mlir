module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 8.1757321883711249 : f64
    %cst_0 = arith.constant 0.32175055439664124 : f64
    %cst_1 = arith.constant 1.8223556888495702 : f64
    %cst_2 = arith.constant 4.2178132105483401 : f64
    %cst_3 = arith.constant -0.98915153967270175 : f64
    %cst_4 = arith.constant 4.4937200345107433 : f64
    %cst_5 = arith.constant -0.21866894587393737 : f64
    %cst_6 = arith.constant -2.9179081302638208 : f64
    %cst_7 = arith.constant 3.896270739753819 : f64
    %cst_8 = arith.constant -0.37733904308201249 : f64
    %cst_9 = arith.constant 1.5707963267948963 : f64
    %cst_10 = arith.constant 4.3690368483118416 : f64
    %cst_11 = arith.constant 3.1415926535898251 : f64
    %cst_12 = arith.constant -2.7982405215169375 : f64
    %cst_13 = arith.constant -3.1415926535897922 : f64
    %cst_14 = arith.constant -2.5510925972613201 : f64
    %cst_15 = arith.constant 3.8126462235677079 : f64
    %cst_16 = arith.constant -0.3355267849889576 : f64
    %cst_17 = arith.constant 4.7123889803846879 : f64
    %cst_18 = arith.constant 4.7123889803846915 : f64
    %cst_19 = arith.constant 1.5707963267948974 : f64
    %cst_20 = arith.constant -9.5479180117763462E-15 : f64
    %cst_21 = arith.constant -1.4081798484035641 : f64
    %cst_22 = arith.constant 4.612037059289432 : f64
    %cst_23 = arith.constant -0.20070384219051696 : f64
    %cst_24 = arith.constant -1.249045772398258 : f64
    %cst_25 = arith.constant 6.2831853071795845 : f64
    %cst_26 = arith.constant 0.32175055439664613 : f64
    %cst_27 = arith.constant 4.7123889803846657 : f64
    %cst_28 = arith.constant -1.4944464564138484 : f64
    %cst_29 = arith.constant 3.6294420887637959 : f64
    %cst_30 = arith.constant -0.24392471758700163 : f64
    %cst_31 = arith.constant 1.9723120286752505 : f64
    %cst_32 = arith.constant -2.7400769517094457 : f64
    %cst_33 = arith.constant 4.7123889803846719 : f64
    %cst_34 = arith.constant 4.7123889803846648 : f64
    %cst_35 = arith.constant 2.0661410128013955 : f64
    %cst_36 = arith.constant 3.1415926535897927 : f64
    %cst_37 = arith.constant 3.3706422647329704 : f64
    %cst_38 = arith.constant -0.11452480557158817 : f64
    %cst_39 = arith.constant 6.283185307179556 : f64
    %cst_40 = arith.constant 1.5707963267948961 : f64
    %cst_41 = arith.constant -0.45397016630484699 : f64
    %cst_42 = arith.constant 4.6276267116093104 : f64
    %cst_43 = arith.constant -0.74301702900975863 : f64
    %cst_44 = arith.constant -1.5707963267948961 : f64
    %cst_45 = arith.constant 3.1415926535897913 : f64
    %cst_46 = arith.constant -0.35121840729676679 : f64
    %cst_47 = arith.constant 4.5035031525043392 : f64
    %cst_48 = arith.constant -0.68095524945727237 : f64
    %cst_49 = arith.constant 4.7123889803846888 : f64
    %cst_50 = arith.constant 1.570796326794897 : f64
    %cst_51 = arith.constant 3.141592653589794 : f64
    %cst_52 = arith.constant 0.7314161935626049 : f64
    %cst_53 = arith.constant 4.195247875480093 : f64
    %cst_54 = arith.constant -0.52682761094514907 : f64
    %cst_55 = arith.constant 4.7123889803846906 : f64
    %cst_56 = arith.constant -0.74744975340117992 : f64
    %cst_57 = arith.constant 4.4006628534382317 : f64
    %cst_58 = arith.constant -3.141592653589794 : f64
    %cst_59 = arith.constant -0.62345225389291858 : f64
    %cst_60 = arith.constant -1.7126933813990615 : f64
    %cst_61 = arith.constant -0.14189705460416357 : f64
    %cst_62 = arith.constant 6.2831853071795853 : f64
    %cst_63 = arith.constant -1.7204317525353741 : f64
    %cst_64 = arith.constant 4.2627672836915638 : f64
    %cst_65 = arith.constant -0.89924339338625314 : f64
    %cst_66 = arith.constant 6.2831853071795862 : f64
    %cst_67 = arith.constant 1.5707963267948966 : f64
    %cst_68 = arith.constant -6.2831853071795862 : f64
    %cst_69 = arith.constant 3.1415926535897931 : f64
    %cst_70 = arith.constant 3.5904989308112261 : f64
    %cst_71 = arith.constant -3.1415926535897931 : f64
    %cst_72 = arith.constant -0.2244531386107167 : f64
    %cst_73 = arith.constant -4.7123889803846897 : f64
    %cst_74 = arith.constant 3.8590730248954901 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.sx %0 : !qco.qubit -> !qco.qubit
    %5 = qco.rz(%cst_74) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_69) %1 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%6) targets (%arg0 = %7) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %8 = qco.rz(%cst_3) %targets_out : !qco.qubit -> !qco.qubit
    %9 = qco.sx %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_58) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_73) %controls_out : !qco.qubit -> !qco.qubit
    %12 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_2) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_69) %14 : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%15) targets (%arg0 = %10) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.rz(%cst_1) %targets_out_76 : !qco.qubit -> !qco.qubit
    %17 = qco.sx %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_51) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_0) %controls_out_75 : !qco.qubit -> !qco.qubit
    %20 = qco.x %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_73) %2 : !qco.qubit -> !qco.qubit
    %23 = qco.sx %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_9) %23 : !qco.qubit -> !qco.qubit
    %controls_out_77, %targets_out_78 = qco.ctrl(%18) targets (%arg0 = %24) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %25 = qco.rz(%cst_8) %targets_out_78 : !qco.qubit -> !qco.qubit
    %26 = qco.sx %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_58) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_73) %controls_out_77 : !qco.qubit -> !qco.qubit
    %29 = qco.sx %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_7) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_69) %31 : !qco.qubit -> !qco.qubit
    %controls_out_79, %targets_out_80 = qco.ctrl(%32) targets (%arg0 = %27) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %33 = qco.rz(%cst_6) %targets_out_80 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_71) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_5) %controls_out_79 : !qco.qubit -> !qco.qubit
    %37 = qco.x %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_4) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %3 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_17) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.sx %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_69) %41 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%35) targets (%arg0 = %42) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qco.rz(%cst_16) %targets_out_82 : !qco.qubit -> !qco.qubit
    %44 = qco.sx %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_71) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_73) %controls_out_81 : !qco.qubit -> !qco.qubit
    %47 = qco.sx %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_15) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.sx %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_69) %49 : !qco.qubit -> !qco.qubit
    %controls_out_83, %targets_out_84 = qco.ctrl(%50) targets (%arg0 = %45) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %51 = qco.rz(%cst_14) %targets_out_84 : !qco.qubit -> !qco.qubit
    %52 = qco.sx %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_13) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_12) %controls_out_83 : !qco.qubit -> !qco.qubit
    %55 = qco.sx %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_11) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.sx %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_10) %57 : !qco.qubit -> !qco.qubit
    %controls_out_85, %targets_out_86 = qco.ctrl(%53) targets (%arg0 = %21) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qco.rz(%cst_23) %targets_out_86 : !qco.qubit -> !qco.qubit
    %60 = qco.sx %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_58) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_73) %controls_out_85 : !qco.qubit -> !qco.qubit
    %63 = qco.sx %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_22) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.sx %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_69) %65 : !qco.qubit -> !qco.qubit
    %controls_out_87, %targets_out_88 = qco.ctrl(%66) targets (%arg0 = %61) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %67 = qco.rz(%cst_21) %targets_out_88 : !qco.qubit -> !qco.qubit
    %68 = qco.sx %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_20) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_19) %controls_out_87 : !qco.qubit -> !qco.qubit
    %71 = qco.sx %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_18) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.sx %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_69) %73 : !qco.qubit -> !qco.qubit
    %controls_out_89, %targets_out_90 = qco.ctrl(%69) targets (%arg0 = %38) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %75 = qco.rz(%cst_30) %targets_out_90 : !qco.qubit -> !qco.qubit
    %76 = qco.sx %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_71) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_73) %controls_out_89 : !qco.qubit -> !qco.qubit
    %79 = qco.sx %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_29) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.sx %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_69) %81 : !qco.qubit -> !qco.qubit
    %controls_out_91, %targets_out_92 = qco.ctrl(%82) targets (%arg0 = %77) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qco.rz(%cst_28) %targets_out_92 : !qco.qubit -> !qco.qubit
    %84 = qco.sx %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_27) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.sx %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_49) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_26) %controls_out_91 : !qco.qubit -> !qco.qubit
    %89 = qco.sx %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_25) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.sx %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_24) %91 : !qco.qubit -> !qco.qubit
    %controls_out_93, %targets_out_94 = qco.ctrl(%87) targets (%arg0 = %58) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %93 = qco.rz(%cst_38) %targets_out_94 : !qco.qubit -> !qco.qubit
    %94 = qco.sx %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_58) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_73) %controls_out_93 : !qco.qubit -> !qco.qubit
    %97 = qco.sx %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_37) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.sx %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_36) %99 : !qco.qubit -> !qco.qubit
    %controls_out_95, %targets_out_96 = qco.ctrl(%100) targets (%arg0 = %95) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %101 = qco.rz(%cst_35) %targets_out_96 : !qco.qubit -> !qco.qubit
    %102 = qco.sx %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst_34) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.sx %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst_33) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_32) %controls_out_95 : !qco.qubit -> !qco.qubit
    %107 = qco.sx %106 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_39) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.sx %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst_31) %109 : !qco.qubit -> !qco.qubit
    %controls_out_97, %targets_out_98 = qco.ctrl(%105) targets (%arg0 = %74) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %111 = qco.rz(%cst_43) %targets_out_98 : !qco.qubit -> !qco.qubit
    %112 = qco.sx %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_71) %112 : !qco.qubit -> !qco.qubit
    %114 = qco.rz(%cst_73) %controls_out_97 : !qco.qubit -> !qco.qubit
    %115 = qco.sx %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst_42) %115 : !qco.qubit -> !qco.qubit
    %117 = qco.sx %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_69) %117 : !qco.qubit -> !qco.qubit
    %controls_out_99, %targets_out_100 = qco.ctrl(%118) targets (%arg0 = %113) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %119 = qco.rz(%cst_41) %targets_out_100 : !qco.qubit -> !qco.qubit
    %120 = qco.sx %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rz(%cst_68) %controls_out_99 : !qco.qubit -> !qco.qubit
    %122 = qco.sx %121 : !qco.qubit -> !qco.qubit
    %123 = qco.rz(%cst_40) %122 : !qco.qubit -> !qco.qubit
    %controls_out_101, %targets_out_102 = qco.ctrl(%120) targets (%arg0 = %92) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %124 = qco.rz(%cst_48) %targets_out_102 : !qco.qubit -> !qco.qubit
    %125 = qco.sx %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst_58) %125 : !qco.qubit -> !qco.qubit
    %127 = qco.rz(%cst_73) %controls_out_101 : !qco.qubit -> !qco.qubit
    %128 = qco.sx %127 : !qco.qubit -> !qco.qubit
    %129 = qco.rz(%cst_47) %128 : !qco.qubit -> !qco.qubit
    %130 = qco.sx %129 : !qco.qubit -> !qco.qubit
    %131 = qco.rz(%cst_69) %130 : !qco.qubit -> !qco.qubit
    %controls_out_103, %targets_out_104 = qco.ctrl(%131) targets (%arg0 = %126) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %132 = qco.rz(%cst_46) %targets_out_104 : !qco.qubit -> !qco.qubit
    %133 = qco.sx %132 : !qco.qubit -> !qco.qubit
    %134 = qco.rz(%cst_45) %133 : !qco.qubit -> !qco.qubit
    %135 = qco.rz(%cst_44) %controls_out_103 : !qco.qubit -> !qco.qubit
    %136 = qco.sx %135 : !qco.qubit -> !qco.qubit
    %137 = qco.rz(%cst_49) %136 : !qco.qubit -> !qco.qubit
    %138 = qco.sx %137 : !qco.qubit -> !qco.qubit
    %139 = qco.rz(%cst_66) %138 : !qco.qubit -> !qco.qubit
    %controls_out_105, %targets_out_106 = qco.ctrl(%134) targets (%arg0 = %110) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %140 = qco.rz(%cst_54) %targets_out_106 : !qco.qubit -> !qco.qubit
    %141 = qco.sx %140 : !qco.qubit -> !qco.qubit
    %142 = qco.rz(%cst_71) %141 : !qco.qubit -> !qco.qubit
    %143 = qco.rz(%cst_73) %controls_out_105 : !qco.qubit -> !qco.qubit
    %144 = qco.sx %143 : !qco.qubit -> !qco.qubit
    %145 = qco.rz(%cst_53) %144 : !qco.qubit -> !qco.qubit
    %146 = qco.sx %145 : !qco.qubit -> !qco.qubit
    %147 = qco.rz(%cst_69) %146 : !qco.qubit -> !qco.qubit
    %controls_out_107, %targets_out_108 = qco.ctrl(%147) targets (%arg0 = %142) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %148 = qco.rz(%cst_52) %targets_out_108 : !qco.qubit -> !qco.qubit
    %149 = qco.sx %148 : !qco.qubit -> !qco.qubit
    %150 = qco.rz(%cst_51) %149 : !qco.qubit -> !qco.qubit
    %151 = qco.rz(%cst_50) %controls_out_107 : !qco.qubit -> !qco.qubit
    %controls_out_109, %targets_out_110 = qco.ctrl(%150) targets (%arg0 = %123) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %152 = qco.rz(%cst_59) %targets_out_110 : !qco.qubit -> !qco.qubit
    %153 = qco.sx %152 : !qco.qubit -> !qco.qubit
    %154 = qco.rz(%cst_58) %153 : !qco.qubit -> !qco.qubit
    %155 = qco.rz(%cst_73) %controls_out_109 : !qco.qubit -> !qco.qubit
    %156 = qco.sx %155 : !qco.qubit -> !qco.qubit
    %157 = qco.rz(%cst_57) %156 : !qco.qubit -> !qco.qubit
    %158 = qco.sx %157 : !qco.qubit -> !qco.qubit
    %159 = qco.rz(%cst_69) %158 : !qco.qubit -> !qco.qubit
    %controls_out_111, %targets_out_112 = qco.ctrl(%159) targets (%arg0 = %154) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %160 = qco.rz(%cst_56) %targets_out_112 : !qco.qubit -> !qco.qubit
    %161 = qco.sx %160 : !qco.qubit -> !qco.qubit
    %162 = qco.rz(%cst_66) %161 : !qco.qubit -> !qco.qubit
    %163 = qco.rz(%cst_55) %controls_out_111 : !qco.qubit -> !qco.qubit
    %controls_out_113, %targets_out_114 = qco.ctrl(%162) targets (%arg0 = %139) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %164 = qco.rz(%cst_65) %targets_out_114 : !qco.qubit -> !qco.qubit
    %165 = qco.sx %164 : !qco.qubit -> !qco.qubit
    %166 = qco.rz(%cst_71) %165 : !qco.qubit -> !qco.qubit
    %167 = qco.rz(%cst_73) %controls_out_113 : !qco.qubit -> !qco.qubit
    %168 = qco.sx %167 : !qco.qubit -> !qco.qubit
    %169 = qco.rz(%cst_64) %168 : !qco.qubit -> !qco.qubit
    %170 = qco.sx %169 : !qco.qubit -> !qco.qubit
    %171 = qco.rz(%cst_69) %170 : !qco.qubit -> !qco.qubit
    %controls_out_115, %targets_out_116 = qco.ctrl(%171) targets (%arg0 = %166) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %172 = qco.rz(%cst_63) %targets_out_116 : !qco.qubit -> !qco.qubit
    %173 = qco.sx %172 : !qco.qubit -> !qco.qubit
    %174 = qco.rz(%cst_62) %173 : !qco.qubit -> !qco.qubit
    %175 = qco.rz(%cst_61) %controls_out_115 : !qco.qubit -> !qco.qubit
    %176 = qco.x %175 : !qco.qubit -> !qco.qubit
    %177 = qco.rz(%cst_60) %176 : !qco.qubit -> !qco.qubit
    qco.sink %163 : !qco.qubit
    qco.sink %177 : !qco.qubit
    %controls_out_117, %targets_out_118 = qco.ctrl(%174) targets (%arg0 = %151) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %178 = qco.rz(%cst_72) %targets_out_118 : !qco.qubit -> !qco.qubit
    %179 = qco.sx %178 : !qco.qubit -> !qco.qubit
    %180 = qco.rz(%cst_71) %179 : !qco.qubit -> !qco.qubit
    %181 = qco.rz(%cst_73) %controls_out_117 : !qco.qubit -> !qco.qubit
    %182 = qco.sx %181 : !qco.qubit -> !qco.qubit
    %183 = qco.rz(%cst_70) %182 : !qco.qubit -> !qco.qubit
    %184 = qco.sx %183 : !qco.qubit -> !qco.qubit
    %185 = qco.rz(%cst_69) %184 : !qco.qubit -> !qco.qubit
    %controls_out_119, %targets_out_120 = qco.ctrl(%185) targets (%arg0 = %180) {
      %191 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %191 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %186 = qco.rz(%cst_73) %targets_out_120 : !qco.qubit -> !qco.qubit
    %187 = qco.sx %186 : !qco.qubit -> !qco.qubit
    %188 = qco.rz(%cst_68) %controls_out_119 : !qco.qubit -> !qco.qubit
    %189 = qco.sx %188 : !qco.qubit -> !qco.qubit
    %190 = qco.rz(%cst_67) %189 : !qco.qubit -> !qco.qubit
    qco.sink %187 : !qco.qubit
    qco.sink %190 : !qco.qubit
    %cst_121 = arith.constant -0.78539816339742341 : f64
    qco.gphase(%cst_121)
    return %c0_i64 : i64
  }
}
