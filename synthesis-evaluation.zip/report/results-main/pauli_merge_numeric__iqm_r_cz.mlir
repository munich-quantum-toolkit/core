module attributes {mqt.layout = {initial = array<i64: 0, 1>, input_count = 2 : i64, sites = array<i64: 0, 1>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 5.7164560896560799 : f64
    %cst_0 = arith.constant 3.1415926535897927 : f64
    %cst_1 = arith.constant 1.0040671092713902 : f64
    %cst_2 = arith.constant 1.5707963267948963 : f64
    %cst_3 = arith.constant 3.1415926535897931 : f64
    %cst_4 = arith.constant 1.5707963267948968 : f64
    %cst_5 = arith.constant -0.70079632679489734 : f64
    %cst_6 = arith.constant 1.570796326794897 : f64
    %cst_7 = arith.constant 6.2831853071795862 : f64
    %cst_8 = arith.constant 7.8539816339744828 : f64
    %cst_9 = arith.constant 1.5707963267948966 : f64
    %cst_10 = arith.constant 0.000000e+00 : f64
    %cst_11 = arith.constant 4.7123889803846897 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.r(%cst_11, %cst_10) %1 : !qco.qubit -> !qco.qubit
    %3 = qco.r(%cst_9, %cst_9) %2 : !qco.qubit -> !qco.qubit
    %4 = qco.r(%cst_8, %cst_10) %3 : !qco.qubit -> !qco.qubit
    %5 = qco.r(%cst_7, %cst_10) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.r(%cst_6, %cst_9) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.r(%cst_11, %cst_10) %6 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%7) targets (%arg0 = %4) {
      %20 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %20 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %8 = qco.r(%cst_11, %cst_10) %targets_out : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_9, %cst_9) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_11, %cst_10) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_5, %cst_10) %controls_out : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_6, %cst_9) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_4, %cst_10) %12 : !qco.qubit -> !qco.qubit
    %controls_out_12, %targets_out_13 = qco.ctrl(%13) targets (%arg0 = %10) {
      %20 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %20 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.r(%cst_4, %cst_10) %targets_out_13 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_3, %cst_9) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_2, %cst_10) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_1, %cst_10) %controls_out_12 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_0, %cst_9) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst, %cst_10) %18 : !qco.qubit -> !qco.qubit
    qco.sink %16 : !qco.qubit
    qco.sink %19 : !qco.qubit
    %cst_14 = arith.constant -1.5707963267948948 : f64
    qco.gphase(%cst_14)
    return %c0_i64 : i64
  }
}
