module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 1.2259088264021467 : f64
    %cst_0 = arith.constant 1.5707963267948963 : f64
    %cst_1 = arith.constant 0.44051066300469843 : f64
    %cst_2 = arith.constant -2.7010819905850947 : f64
    %cst_3 = arith.constant -1.5707963267948966 : f64
    %cst_4 = arith.constant 2.3561944901923448 : f64
    %cst_5 = arith.constant -0.78539816339744828 : f64
    %cst_6 = arith.constant 3.1415926535897931 : f64
    %cst_7 = arith.constant 0.78539816339744828 : f64
    %cst_8 = arith.constant -1.5707963267948974 : f64
    %cst_9 = arith.constant 1.5707963267948966 : f64
    %cst_10 = arith.constant -3.1415926535897931 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.rz(%cst_9) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rx(%cst_9) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_4) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_10) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_9) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_8) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_6) %7 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_5) %11 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %12, %10 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %13 = qco.rz(%cst_4) %qubit1_out : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_6) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_7) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_10) %qubit0_out : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_9) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_3) %17 : !qco.qubit -> !qco.qubit
    %qubit0_out_11, %qubit1_out_12 = qco.iswap %18, %15 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %19 = qco.rz(%cst_2) %qubit1_out_12 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_6) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_0) %qubit0_out_11 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_10) %2 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_9) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_8) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_6) %21 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_5) %26 : !qco.qubit -> !qco.qubit
    %qubit0_out_13, %qubit1_out_14 = qco.iswap %27, %25 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %28 = qco.rz(%cst_4) %qubit1_out_14 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_6) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_7) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_10) %qubit0_out_13 : !qco.qubit -> !qco.qubit
    %32 = qco.rx(%cst_9) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_3) %32 : !qco.qubit -> !qco.qubit
    %qubit0_out_15, %qubit1_out_16 = qco.iswap %33, %30 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %34 = qco.rz(%cst_2) %qubit1_out_16 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_6) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_0) %qubit0_out_15 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_10) %3 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_9) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_8) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_6) %36 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_5) %41 : !qco.qubit -> !qco.qubit
    %qubit0_out_17, %qubit1_out_18 = qco.iswap %42, %40 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %43 = qco.rz(%cst_4) %qubit1_out_18 : !qco.qubit -> !qco.qubit
    %44 = qco.rx(%cst_6) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_7) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_10) %qubit0_out_17 : !qco.qubit -> !qco.qubit
    %47 = qco.rx(%cst_9) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_3) %47 : !qco.qubit -> !qco.qubit
    %qubit0_out_19, %qubit1_out_20 = qco.iswap %48, %45 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %49 = qco.rz(%cst_2) %qubit1_out_20 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_6) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_1) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_0) %qubit0_out_19 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %22 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<4>
    %qubit_out_21, %result_22 = qco.measure %37 : !qco.qubit
    cbit.store %result_22, %4[%c1] : !cbit.reg<4>
    %qubit_out_23, %result_24 = qco.measure %52 : !qco.qubit
    cbit.store %result_24, %4[%c2] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_21 : !qco.qubit
    qco.sink %qubit_out_23 : !qco.qubit
    %qubit_out_25, %result_26 = qco.measure %51 : !qco.qubit
    qco.sink %qubit_out_25 : !qco.qubit
    cbit.store %result_26, %4[%c3] : !cbit.reg<4>
    %cst_27 = arith.constant 2.3561944901923422 : f64
    qco.gphase(%cst_27)
    return %4 : !cbit.reg<4>
  }
}
