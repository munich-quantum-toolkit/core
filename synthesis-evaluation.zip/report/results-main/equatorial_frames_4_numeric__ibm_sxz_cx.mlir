module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 0.24890627722143344 : f64
    %cst_0 = arith.constant 2.0423492602035402 : f64
    %cst_1 = arith.constant -2.7181403996968747 : f64
    %cst_2 = arith.constant 0.85365522189029797 : f64
    %cst_3 = arith.constant 1.161910498914545 : f64
    %cst_4 = arith.constant 1.2860340580195175 : f64
    %cst_5 = arith.constant -0.4290496111431763 : f64
    %cst_6 = arith.constant -0.68784943517400321 : f64
    %cst_7 = arith.constant -3.1408888113992761 : f64
    %cst_8 = arith.constant -0.87105356997791517 : f64
    %cst_9 = arith.constant 0.55467808616402525 : f64
    %cst_10 = arith.constant -1.5707963267948966 : f64
    %cst_11 = arith.constant 1.5707963267948966 : f64
    %cst_12 = arith.constant 1.5707963267948968 : f64
    %cst_13 = arith.constant -1.5707963267948963 : f64
    %cst_14 = arith.constant 1.7707963267948967 : f64
    %cst_15 = arith.constant 1.7707963267948965 : f64
    %cst_16 = arith.constant 1.7707963267948963 : f64
    %cst_17 = arith.constant 3.4415926535897929 : f64
    %cst_18 = arith.constant 3.5232374407119882 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.rz(%cst_18) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.sx %4 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_17) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.sx %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_16) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_13) %1 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_12) %10 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%8) targets (%arg0 = %11) {
      %125 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %125 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qco.rz(%cst_11) %targets_out : !qco.qubit -> !qco.qubit
    %13 = qco.sx %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_9) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_17) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.sx %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_15) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_13) %2 : !qco.qubit -> !qco.qubit
    %20 = qco.sx %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_12) %20 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%18) targets (%arg0 = %21) {
      %125 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %125 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.rz(%cst_11) %targets_out_20 : !qco.qubit -> !qco.qubit
    %23 = qco.sx %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_8) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.sx %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_17) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.sx %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_15) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_13) %3 : !qco.qubit -> !qco.qubit
    %30 = qco.sx %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_12) %30 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%28) targets (%arg0 = %31) {
      %125 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %125 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qco.rz(%cst_11) %targets_out_22 : !qco.qubit -> !qco.qubit
    %33 = qco.sx %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_7) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.sx %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_17) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.sx %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_15) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_13) %controls_out : !qco.qubit -> !qco.qubit
    %40 = qco.sx %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_12) %40 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%38) targets (%arg0 = %41) {
      %125 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %125 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = qco.rz(%cst_11) %targets_out_24 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_6) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.sx %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_17) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.sx %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_15) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_13) %controls_out_19 : !qco.qubit -> !qco.qubit
    %50 = qco.sx %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_12) %50 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%48) targets (%arg0 = %51) {
      %125 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %125 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %52 = qco.rz(%cst_11) %targets_out_26 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_5) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.sx %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_17) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.sx %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_15) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_13) %controls_out_21 : !qco.qubit -> !qco.qubit
    %60 = qco.sx %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_12) %60 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%58) targets (%arg0 = %61) {
      %125 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %125 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %62 = qco.rz(%cst_11) %targets_out_28 : !qco.qubit -> !qco.qubit
    %63 = qco.sx %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_4) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.sx %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_17) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.sx %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_16) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_13) %controls_out_23 : !qco.qubit -> !qco.qubit
    %70 = qco.sx %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_12) %70 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%68) targets (%arg0 = %71) {
      %125 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %125 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %72 = qco.rz(%cst_11) %targets_out_30 : !qco.qubit -> !qco.qubit
    %73 = qco.sx %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_3) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.sx %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_17) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.sx %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_14) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_13) %controls_out_25 : !qco.qubit -> !qco.qubit
    %80 = qco.sx %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_12) %80 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%78) targets (%arg0 = %81) {
      %125 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %125 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %82 = qco.rz(%cst_11) %targets_out_32 : !qco.qubit -> !qco.qubit
    %83 = qco.sx %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_2) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.sx %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_17) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.sx %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_15) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_13) %controls_out_27 : !qco.qubit -> !qco.qubit
    %90 = qco.sx %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_12) %90 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%88) targets (%arg0 = %91) {
      %125 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %125 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %92 = qco.rz(%cst_11) %targets_out_34 : !qco.qubit -> !qco.qubit
    %93 = qco.sx %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_1) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.sx %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_17) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.sx %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_15) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_13) %controls_out_29 : !qco.qubit -> !qco.qubit
    %100 = qco.sx %99 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst_12) %100 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%98) targets (%arg0 = %101) {
      %125 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %125 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %102 = qco.rz(%cst_11) %targets_out_36 : !qco.qubit -> !qco.qubit
    %103 = qco.sx %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_0) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.sx %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_17) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.sx %106 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_14) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rz(%cst_13) %controls_out_31 : !qco.qubit -> !qco.qubit
    %110 = qco.sx %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_12) %110 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%108) targets (%arg0 = %111) {
      %125 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %125 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %112 = qco.rz(%cst_11) %targets_out_38 : !qco.qubit -> !qco.qubit
    %113 = qco.sx %112 : !qco.qubit -> !qco.qubit
    %114 = qco.rz(%cst) %113 : !qco.qubit -> !qco.qubit
    %115 = qco.sx %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst_17) %115 : !qco.qubit -> !qco.qubit
    %117 = qco.sx %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_15) %117 : !qco.qubit -> !qco.qubit
    qco.sink %controls_out_35 : !qco.qubit
    qco.sink %controls_out_37 : !qco.qubit
    %119 = qco.rz(%cst_13) %controls_out_33 : !qco.qubit -> !qco.qubit
    %120 = qco.sx %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rz(%cst_12) %120 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%118) targets (%arg0 = %121) {
      %125 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %125 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %122 = qco.rz(%cst_11) %targets_out_40 : !qco.qubit -> !qco.qubit
    %123 = qco.sx %122 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_10) %123 : !qco.qubit -> !qco.qubit
    qco.sink %124 : !qco.qubit
    qco.sink %controls_out_39 : !qco.qubit
    return %c0_i64 : i64
  }
}
