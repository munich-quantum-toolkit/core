module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 6.2831853071795862 : f64
    %cst_0 = arith.constant 1.5707963267948963 : f64
    %cst_1 = arith.constant -3.1415926535897931 : f64
    %cst_2 = arith.constant 1.5707963267948968 : f64
    %cst_3 = arith.constant 1.5707963267948966 : f64
    %cst_4 = arith.constant -1.5707963267948968 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.rx(%cst_3) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_3) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rx(%cst_3) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rx(%cst_4) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_3) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_2) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_1) %7 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_3) %11, %10 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %12 = qco.rx(%cst_3) %qubit1_out : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_2) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_1) %qubit0_out : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_0) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_4) %2 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_3) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_2) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_1) %13 : !qco.qubit -> !qco.qubit
    %qubit0_out_5, %qubit1_out_6 = qco.rzz(%cst_3) %20, %19 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %21 = qco.rx(%cst_3) %qubit1_out_6 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_2) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_1) %qubit0_out_5 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_0) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_4) %3 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_3) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_2) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_1) %22 : !qco.qubit -> !qco.qubit
    %qubit0_out_7, %qubit1_out_8 = qco.rzz(%cst_3) %29, %28 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %30 = qco.rx(%cst_3) %qubit1_out_8 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_2) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rx(%cst_1) %qubit0_out_7 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_0) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst) %33 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %16 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<4>
    %qubit_out_9, %result_10 = qco.measure %25 : !qco.qubit
    cbit.store %result_10, %4[%c1] : !cbit.reg<4>
    %qubit_out_11, %result_12 = qco.measure %34 : !qco.qubit
    cbit.store %result_12, %4[%c2] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_9 : !qco.qubit
    qco.sink %qubit_out_11 : !qco.qubit
    %qubit_out_13, %result_14 = qco.measure %31 : !qco.qubit
    qco.sink %qubit_out_13 : !qco.qubit
    cbit.store %result_14, %4[%c3] : !cbit.reg<4>
    %cst_15 = arith.constant -2.3561944901923475 : f64
    qco.gphase(%cst_15)
    return %4 : !cbit.reg<4>
  }
}
