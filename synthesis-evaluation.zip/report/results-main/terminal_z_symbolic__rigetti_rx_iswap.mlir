module attributes {mqt.layout = {initial = array<i64: 0, 1>, input_count = 2 : i64, sites = array<i64: 0, 1>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main(%arg0: f64 {mqt.input_id = -3033000624479524390794154133784343657 : i128, mqt.input_name = "theta[0]", mqt.parameter_group = {identity = "fdb7dd86-1c01-4fc1-b8da-f3c16e084b97", index = 0 : i64, name = "theta", size = 2 : i64}}) -> !cbit.reg<2> attributes {mqt.entry_point} {
    %cst = arith.constant 4.000000e+00 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "meas"} : !cbit.reg<2>
    %3 = qco.rz(%cst_0) %0 : !qco.qubit -> !qco.qubit
    %4 = qco.rx(%cst_0) %3 : !qco.qubit -> !qco.qubit
    %5 = arith.divf %arg0, %cst : f64
    %6 = math.tan %5 : f64
    %7 = math.atan %6 : f64
    %8 = arith.mulf %7, %cst : f64
    %9 = arith.addf %8, %cst_0 : f64
    %10 = qco.rz(%9) %4 : !qco.qubit -> !qco.qubit
    %11:2 = qco.barrier %10, %1 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %qubit_out, %result = qco.measure %11#0 : !qco.qubit
    cbit.store %result, %2[%c0] : !cbit.reg<2>
    qco.sink %qubit_out : !qco.qubit
    %qubit_out_1, %result_2 = qco.measure %11#1 : !qco.qubit
    qco.sink %qubit_out_1 : !qco.qubit
    cbit.store %result_2, %2[%c1] : !cbit.reg<2>
    qco.gphase(%cst_0)
    return %2 : !cbit.reg<2>
  }
}
