module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant 3.1415926535897931 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant 0.000000e+00 : f64
    %cst_2 = arith.constant 9.4247779607693793 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %9 = qco.r(%cst_2, %cst_1) %0 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_0, %cst_0) %1 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst, %cst_1) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_0, %cst_0) %3 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst, %cst_1) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_0, %cst_0) %5 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst, %cst_1) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_0, %cst_0) %7 : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst, %cst_1) %16 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%11) targets (%arg0 = %9) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_3, %targets_out_4 = qco.ctrl(%13) targets (%arg0 = %targets_out) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_5, %targets_out_6 = qco.ctrl(%15) targets (%arg0 = %targets_out_4) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_7, %targets_out_8 = qco.ctrl(%17) targets (%arg0 = %targets_out_6) {
      %26 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %26 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qco.r(%cst_0, %cst_0) %controls_out : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst, %cst_1) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_0, %cst_0) %controls_out_3 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst, %cst_1) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_0, %cst_0) %controls_out_5 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst, %cst_1) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_0, %cst_0) %controls_out_7 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst, %cst_1) %24 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %19 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<7>
    %qubit_out_9, %result_10 = qco.measure %2 : !qco.qubit
    cbit.store %result_10, %8[%c1] : !cbit.reg<7>
    %qubit_out_11, %result_12 = qco.measure %21 : !qco.qubit
    cbit.store %result_12, %8[%c2] : !cbit.reg<7>
    %qubit_out_13, %result_14 = qco.measure %4 : !qco.qubit
    cbit.store %result_14, %8[%c3] : !cbit.reg<7>
    %qubit_out_15, %result_16 = qco.measure %23 : !qco.qubit
    cbit.store %result_16, %8[%c4] : !cbit.reg<7>
    %qubit_out_17, %result_18 = qco.measure %6 : !qco.qubit
    cbit.store %result_18, %8[%c5] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_9 : !qco.qubit
    qco.sink %qubit_out_11 : !qco.qubit
    qco.sink %qubit_out_13 : !qco.qubit
    qco.sink %qubit_out_15 : !qco.qubit
    qco.sink %qubit_out_17 : !qco.qubit
    %qubit_out_19, %result_20 = qco.measure %25 : !qco.qubit
    qco.sink %qubit_out_19 : !qco.qubit
    cbit.store %result_20, %8[%c6] : !cbit.reg<7>
    qco.sink %targets_out_8 : !qco.qubit
    %cst_21 = arith.constant -1.5707963267948966 : f64
    qco.gphase(%cst_21)
    return %8 : !cbit.reg<7>
  }
}
