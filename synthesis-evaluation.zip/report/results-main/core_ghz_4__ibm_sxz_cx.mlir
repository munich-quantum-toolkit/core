module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.rz(%cst) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst) %6 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%7) targets (%arg0 = %1) {
      %8 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %8 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_0, %targets_out_1 = qco.ctrl(%targets_out) targets (%arg0 = %2) {
      %8 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %8 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_2, %targets_out_3 = qco.ctrl(%targets_out_1) targets (%arg0 = %3) {
      %8 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %8 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %qubit_out, %result = qco.measure %controls_out : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<4>
    %qubit_out_4, %result_5 = qco.measure %controls_out_0 : !qco.qubit
    cbit.store %result_5, %4[%c1] : !cbit.reg<4>
    %qubit_out_6, %result_7 = qco.measure %controls_out_2 : !qco.qubit
    cbit.store %result_7, %4[%c2] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_4 : !qco.qubit
    qco.sink %qubit_out_6 : !qco.qubit
    %qubit_out_8, %result_9 = qco.measure %targets_out_3 : !qco.qubit
    qco.sink %qubit_out_8 : !qco.qubit
    cbit.store %result_9, %4[%c3] : !cbit.reg<4>
    %cst_10 = arith.constant 0.78539816339744828 : f64
    qco.gphase(%cst_10)
    return %4 : !cbit.reg<4>
  }
}
