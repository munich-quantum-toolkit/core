module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 0>, input_count = 7 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant -3.9269908169872418 : f64
    %cst_0 = arith.constant 3.9269908169872423 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %cst_2 = arith.constant 2.7488935718910694 : f64
    %cst_3 = arith.constant 3.5342917352885177 : f64
    %cst_4 = arith.constant -3.337942194439155 : f64
    %cst_5 = arith.constant 3.3379421944391545 : f64
    %cst_6 = arith.constant -3.2397674240144738 : f64
    %cst_7 = arith.constant 3.2397674240144738 : f64
    %cst_8 = arith.constant -3.1906800388021335 : f64
    %cst_9 = arith.constant 3.1906800388021339 : f64
    %cst_10 = arith.constant 3.1415926535897927 : f64
    %cst_11 = arith.constant -6.2831853071795862 : f64
    %cst_12 = arith.constant -3.1661363461959633 : f64
    %cst_13 = arith.constant 3.1661363461959646 : f64
    %cst_14 = arith.constant -4.7123889803846897 : f64
    %cst_15 = arith.constant 3.9269908169872414 : f64
    %cst_16 = arith.constant 3.1415926535897931 : f64
    %cst_17 = arith.constant 5.497787143782138 : f64
    %cst_18 = arith.constant 4.7123889803846897 : f64
    %cst_19 = arith.constant 1.5707963267948968 : f64
    %cst_20 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %8 = qco.rz(%cst_20) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_20) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_20) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_20) %2 : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_20) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_20) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_20) %3 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_20) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_20) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_20) %4 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_20) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_20) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_20) %5 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_20) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_20) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_20) %6 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_20) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_20) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_20) %0 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_19) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_20) %25 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_1) %28 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%29) targets (%arg0 = %27) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.rz(%cst_17) %targets_out : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_16) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_15) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_14) %controls_out : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_20) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_0) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_20) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_16) %36 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%37) targets (%arg0 = %32) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qco.rz(%cst) %targets_out_22 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_20) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_20) %controls_out_21 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_16) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_11) %39 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_20) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_20) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rx(%cst_20) %22 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_18) %45 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%46) targets (%arg0 = %44) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.rz(%cst_17) %targets_out_24 : !qco.qubit -> !qco.qubit
    %48 = qco.rx(%cst_16) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_15) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_14) %controls_out_23 : !qco.qubit -> !qco.qubit
    %51 = qco.rx(%cst_20) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_3) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rx(%cst_20) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_16) %53 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%54) targets (%arg0 = %49) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.rz(%cst_2) %targets_out_26 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_20) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rx(%cst_20) %controls_out_25 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_16) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rx(%cst_20) %56 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_19) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rx(%cst_20) %19 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_18) %61 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%62) targets (%arg0 = %60) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %63 = qco.rz(%cst_17) %targets_out_28 : !qco.qubit -> !qco.qubit
    %64 = qco.rx(%cst_16) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_15) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_14) %controls_out_27 : !qco.qubit -> !qco.qubit
    %67 = qco.rx(%cst_20) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_5) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rx(%cst_20) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_16) %69 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%70) targets (%arg0 = %65) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qco.rz(%cst_4) %targets_out_30 : !qco.qubit -> !qco.qubit
    %72 = qco.rx(%cst_20) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_11) %controls_out_29 : !qco.qubit -> !qco.qubit
    %74 = qco.rx(%cst_20) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_10) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rx(%cst_20) %72 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_19) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rx(%cst_20) %16 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_18) %78 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%79) targets (%arg0 = %77) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %80 = qco.rz(%cst_17) %targets_out_32 : !qco.qubit -> !qco.qubit
    %81 = qco.rx(%cst_16) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_15) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_14) %controls_out_31 : !qco.qubit -> !qco.qubit
    %84 = qco.rx(%cst_20) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_7) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rx(%cst_20) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_16) %86 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%87) targets (%arg0 = %82) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %88 = qco.rz(%cst_6) %targets_out_34 : !qco.qubit -> !qco.qubit
    %89 = qco.rx(%cst_20) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_11) %controls_out_33 : !qco.qubit -> !qco.qubit
    %91 = qco.rx(%cst_20) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_10) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rx(%cst_20) %89 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_19) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rx(%cst_20) %13 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_18) %95 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%96) targets (%arg0 = %94) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %97 = qco.rz(%cst_17) %targets_out_36 : !qco.qubit -> !qco.qubit
    %98 = qco.rx(%cst_16) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_15) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_14) %controls_out_35 : !qco.qubit -> !qco.qubit
    %101 = qco.rx(%cst_20) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_9) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rx(%cst_20) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_16) %103 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%104) targets (%arg0 = %99) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %105 = qco.rz(%cst_8) %targets_out_38 : !qco.qubit -> !qco.qubit
    %106 = qco.rx(%cst_20) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rz(%cst_11) %controls_out_37 : !qco.qubit -> !qco.qubit
    %108 = qco.rx(%cst_20) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rz(%cst_10) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rx(%cst_20) %106 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_19) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rx(%cst_20) %10 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_18) %112 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%113) targets (%arg0 = %111) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %114 = qco.rz(%cst_17) %targets_out_40 : !qco.qubit -> !qco.qubit
    %115 = qco.rx(%cst_16) %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst_15) %115 : !qco.qubit -> !qco.qubit
    %117 = qco.rz(%cst_14) %controls_out_39 : !qco.qubit -> !qco.qubit
    %118 = qco.rx(%cst_20) %117 : !qco.qubit -> !qco.qubit
    %119 = qco.rz(%cst_13) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.rx(%cst_20) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rz(%cst_16) %120 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%121) targets (%arg0 = %116) {
      %127 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %127 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %122 = qco.rz(%cst_12) %targets_out_42 : !qco.qubit -> !qco.qubit
    %123 = qco.rx(%cst_20) %122 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_11) %controls_out_41 : !qco.qubit -> !qco.qubit
    %125 = qco.rx(%cst_20) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst_10) %125 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %123 : !qco.qubit
    cbit.store %result, %7[%c0] : !cbit.reg<7>
    %qubit_out_43, %result_44 = qco.measure %126 : !qco.qubit
    cbit.store %result_44, %7[%c1] : !cbit.reg<7>
    %qubit_out_45, %result_46 = qco.measure %109 : !qco.qubit
    cbit.store %result_46, %7[%c2] : !cbit.reg<7>
    %qubit_out_47, %result_48 = qco.measure %92 : !qco.qubit
    cbit.store %result_48, %7[%c3] : !cbit.reg<7>
    %qubit_out_49, %result_50 = qco.measure %75 : !qco.qubit
    cbit.store %result_50, %7[%c4] : !cbit.reg<7>
    %qubit_out_51, %result_52 = qco.measure %58 : !qco.qubit
    cbit.store %result_52, %7[%c5] : !cbit.reg<7>
    qco.sink %qubit_out_43 : !qco.qubit
    qco.sink %qubit_out_45 : !qco.qubit
    qco.sink %qubit_out_47 : !qco.qubit
    qco.sink %qubit_out_49 : !qco.qubit
    qco.sink %qubit_out_51 : !qco.qubit
    %qubit_out_53, %result_54 = qco.measure %41 : !qco.qubit
    qco.sink %qubit_out_53 : !qco.qubit
    cbit.store %result_54, %7[%c6] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    %cst_55 = arith.constant -3.1415926535897825 : f64
    qco.gphase(%cst_55)
    return %7 : !cbit.reg<7>
  }
}
