module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 0>, input_count = 7 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant 4.7123889803846888 : f64
    %cst_0 = arith.constant 4.7123889803846897 : f64
    %cst_1 = arith.constant -1.249045772398254 : f64
    %cst_2 = arith.constant 2.677945044588987 : f64
    %cst_3 = arith.constant 3.9269908169872414 : f64
    %cst_4 = arith.constant 5.4977871437821371 : f64
    %cst_5 = arith.constant -0.78539816339744828 : f64
    %cst_6 = arith.constant 3.5342917352885173 : f64
    %cst_7 = arith.constant 1.570796326794897 : f64
    %cst_8 = arith.constant 5.8904862254808616 : f64
    %cst_9 = arith.constant -1.570796326794897 : f64
    %cst_10 = arith.constant 1.8925468811915387 : f64
    %cst_11 = arith.constant 3.1415926535897927 : f64
    %cst_12 = arith.constant 3.337942194439155 : f64
    %cst_13 = arith.constant 6.0868357663302248 : f64
    %cst_14 = arith.constant 3.2397674240144738 : f64
    %cst_15 = arith.constant -4.7123889803846888 : f64
    %cst_16 = arith.constant 6.1850105367549055 : f64
    %cst_17 = arith.constant -1.5707963267948974 : f64
    %cst_18 = arith.constant 3.1906800388021335 : f64
    %cst_19 = arith.constant -4.7123889803846879 : f64
    %cst_20 = arith.constant 6.2340979219672459 : f64
    %cst_21 = arith.constant -3.1415926535897936 : f64
    %cst_22 = arith.constant 3.1661363461959633 : f64
    %cst_23 = arith.constant -4.7123889803846897 : f64
    %cst_24 = arith.constant 6.2586416145734152 : f64
    %cst_25 = arith.constant 1.5707963267948966 : f64
    %cst_26 = arith.constant -1.5707963267948966 : f64
    %cst_27 = arith.constant 0.78539816339744828 : f64
    %cst_28 = arith.constant 2.3561944901923448 : f64
    %cst_29 = arith.constant 5.8195376981787801 : f64
    %cst_30 = arith.constant 1.5707963267948963 : f64
    %cst_31 = arith.constant 3.1415926535897931 : f64
    %cst_32 = arith.constant 1.5707963267948968 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %8 = qco.rz(%cst_25) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_25) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_2) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_25) %2 : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_25) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_2) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_25) %3 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_25) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_2) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_25) %4 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_25) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_2) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_25) %5 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_25) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_2) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_25) %6 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_25) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_28) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_32) %0 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_31) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_30) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_31) %25 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_5) %29 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %30, %28 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %31 = qco.rz(%cst_28) %qubit1_out : !qco.qubit -> !qco.qubit
    %32 = qco.rx(%cst_31) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_27) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_26) %qubit0_out : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_25) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_4) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rx(%cst_25) %36 : !qco.qubit -> !qco.qubit
    %qubit0_out_33, %qubit1_out_34 = qco.iswap %37, %33 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %38 = qco.rz(%cst_23) %qubit1_out_34 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_25) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_3) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_25) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_1) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_31) %qubit0_out_33 : !qco.qubit -> !qco.qubit
    %44 = qco.rx(%cst_31) %42 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_10) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst_31) %22 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_29) %46 : !qco.qubit -> !qco.qubit
    %qubit0_out_35, %qubit1_out_36 = qco.iswap %47, %45 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %48 = qco.rz(%cst_28) %qubit1_out_36 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_31) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_27) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_9) %qubit0_out_35 : !qco.qubit -> !qco.qubit
    %52 = qco.rx(%cst_25) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_8) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rx(%cst_25) %53 : !qco.qubit -> !qco.qubit
    %qubit0_out_37, %qubit1_out_38 = qco.iswap %54, %50 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %55 = qco.rz(%cst_7) %qubit1_out_38 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_25) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_6) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_25) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_0) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_11) %qubit0_out_37 : !qco.qubit -> !qco.qubit
    %61 = qco.rx(%cst_31) %59 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_30) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rx(%cst_31) %19 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_29) %63 : !qco.qubit -> !qco.qubit
    %qubit0_out_39, %qubit1_out_40 = qco.iswap %64, %62 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %65 = qco.rz(%cst_28) %qubit1_out_40 : !qco.qubit -> !qco.qubit
    %66 = qco.rx(%cst_31) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_27) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_26) %qubit0_out_39 : !qco.qubit -> !qco.qubit
    %69 = qco.rx(%cst_25) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_13) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_25) %70 : !qco.qubit -> !qco.qubit
    %qubit0_out_41, %qubit1_out_42 = qco.iswap %71, %67 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %72 = qco.rz(%cst_23) %qubit1_out_42 : !qco.qubit -> !qco.qubit
    %73 = qco.rx(%cst_25) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_12) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rx(%cst_25) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_0) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_21) %qubit0_out_41 : !qco.qubit -> !qco.qubit
    %78 = qco.rx(%cst_31) %76 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_30) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rx(%cst_31) %16 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_29) %80 : !qco.qubit -> !qco.qubit
    %qubit0_out_43, %qubit1_out_44 = qco.iswap %81, %79 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %82 = qco.rz(%cst_28) %qubit1_out_44 : !qco.qubit -> !qco.qubit
    %83 = qco.rx(%cst_31) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_27) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_17) %qubit0_out_43 : !qco.qubit -> !qco.qubit
    %86 = qco.rx(%cst_25) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_16) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rx(%cst_25) %87 : !qco.qubit -> !qco.qubit
    %qubit0_out_45, %qubit1_out_46 = qco.iswap %88, %84 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %89 = qco.rz(%cst_15) %qubit1_out_46 : !qco.qubit -> !qco.qubit
    %90 = qco.rx(%cst_25) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_14) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rx(%cst_25) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_21) %qubit0_out_45 : !qco.qubit -> !qco.qubit
    %95 = qco.rx(%cst_31) %93 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_30) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rx(%cst_31) %13 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_29) %97 : !qco.qubit -> !qco.qubit
    %qubit0_out_47, %qubit1_out_48 = qco.iswap %98, %96 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %99 = qco.rz(%cst_28) %qubit1_out_48 : !qco.qubit -> !qco.qubit
    %100 = qco.rx(%cst_31) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst_27) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_26) %qubit0_out_47 : !qco.qubit -> !qco.qubit
    %103 = qco.rx(%cst_25) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_20) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rx(%cst_25) %104 : !qco.qubit -> !qco.qubit
    %qubit0_out_49, %qubit1_out_50 = qco.iswap %105, %101 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %106 = qco.rz(%cst_19) %qubit1_out_50 : !qco.qubit -> !qco.qubit
    %107 = qco.rx(%cst_25) %106 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_18) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rx(%cst_25) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_21) %qubit0_out_49 : !qco.qubit -> !qco.qubit
    %112 = qco.rx(%cst_31) %110 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_30) %112 : !qco.qubit -> !qco.qubit
    %114 = qco.rx(%cst_31) %10 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_29) %114 : !qco.qubit -> !qco.qubit
    %qubit0_out_51, %qubit1_out_52 = qco.iswap %115, %113 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %116 = qco.rz(%cst_28) %qubit1_out_52 : !qco.qubit -> !qco.qubit
    %117 = qco.rx(%cst_31) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_27) %117 : !qco.qubit -> !qco.qubit
    %119 = qco.rz(%cst_26) %qubit0_out_51 : !qco.qubit -> !qco.qubit
    %120 = qco.rx(%cst_25) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rz(%cst_24) %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rx(%cst_25) %121 : !qco.qubit -> !qco.qubit
    %qubit0_out_53, %qubit1_out_54 = qco.iswap %122, %118 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %123 = qco.rz(%cst_23) %qubit1_out_54 : !qco.qubit -> !qco.qubit
    %124 = qco.rx(%cst_25) %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rz(%cst_22) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rx(%cst_25) %125 : !qco.qubit -> !qco.qubit
    %127 = qco.rz(%cst_31) %126 : !qco.qubit -> !qco.qubit
    %128 = qco.rz(%cst_21) %qubit0_out_53 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %127 : !qco.qubit
    cbit.store %result, %7[%c0] : !cbit.reg<7>
    %qubit_out_55, %result_56 = qco.measure %128 : !qco.qubit
    cbit.store %result_56, %7[%c1] : !cbit.reg<7>
    %qubit_out_57, %result_58 = qco.measure %111 : !qco.qubit
    cbit.store %result_58, %7[%c2] : !cbit.reg<7>
    %qubit_out_59, %result_60 = qco.measure %94 : !qco.qubit
    cbit.store %result_60, %7[%c3] : !cbit.reg<7>
    %qubit_out_61, %result_62 = qco.measure %77 : !qco.qubit
    cbit.store %result_62, %7[%c4] : !cbit.reg<7>
    %qubit_out_63, %result_64 = qco.measure %60 : !qco.qubit
    cbit.store %result_64, %7[%c5] : !cbit.reg<7>
    qco.sink %qubit_out_55 : !qco.qubit
    qco.sink %qubit_out_57 : !qco.qubit
    qco.sink %qubit_out_59 : !qco.qubit
    qco.sink %qubit_out_61 : !qco.qubit
    qco.sink %qubit_out_63 : !qco.qubit
    %qubit_out_65, %result_66 = qco.measure %43 : !qco.qubit
    qco.sink %qubit_out_65 : !qco.qubit
    cbit.store %result_66, %7[%c6] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    return %7 : !cbit.reg<7>
  }
}
