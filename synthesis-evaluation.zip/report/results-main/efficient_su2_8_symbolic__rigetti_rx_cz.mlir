module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main(%arg0: f64 {mqt.input_id = 44246249981895013191645689038461798644 : i128, mqt.input_name = "\CE\B8[0]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 0 : i64, name = "\CE\B8", size = 64 : i64}}, %arg1: f64 {mqt.input_id = 44246249981895013191645689038461798645 : i128, mqt.input_name = "\CE\B8[1]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 1 : i64, name = "\CE\B8", size = 64 : i64}}, %arg2: f64 {mqt.input_id = 44246249981895013191645689038461798646 : i128, mqt.input_name = "\CE\B8[2]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 2 : i64, name = "\CE\B8", size = 64 : i64}}, %arg3: f64 {mqt.input_id = 44246249981895013191645689038461798647 : i128, mqt.input_name = "\CE\B8[3]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 3 : i64, name = "\CE\B8", size = 64 : i64}}, %arg4: f64 {mqt.input_id = 44246249981895013191645689038461798648 : i128, mqt.input_name = "\CE\B8[4]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 4 : i64, name = "\CE\B8", size = 64 : i64}}, %arg5: f64 {mqt.input_id = 44246249981895013191645689038461798649 : i128, mqt.input_name = "\CE\B8[5]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 5 : i64, name = "\CE\B8", size = 64 : i64}}, %arg6: f64 {mqt.input_id = 44246249981895013191645689038461798650 : i128, mqt.input_name = "\CE\B8[6]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 6 : i64, name = "\CE\B8", size = 64 : i64}}, %arg7: f64 {mqt.input_id = 44246249981895013191645689038461798651 : i128, mqt.input_name = "\CE\B8[7]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 7 : i64, name = "\CE\B8", size = 64 : i64}}, %arg8: f64 {mqt.input_id = 44246249981895013191645689038461798652 : i128, mqt.input_name = "\CE\B8[8]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 8 : i64, name = "\CE\B8", size = 64 : i64}}, %arg9: f64 {mqt.input_id = 44246249981895013191645689038461798653 : i128, mqt.input_name = "\CE\B8[9]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 9 : i64, name = "\CE\B8", size = 64 : i64}}, %arg10: f64 {mqt.input_id = 44246249981895013191645689038461798654 : i128, mqt.input_name = "\CE\B8[10]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 10 : i64, name = "\CE\B8", size = 64 : i64}}, %arg11: f64 {mqt.input_id = 44246249981895013191645689038461798655 : i128, mqt.input_name = "\CE\B8[11]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 11 : i64, name = "\CE\B8", size = 64 : i64}}, %arg12: f64 {mqt.input_id = 44246249981895013191645689038461798656 : i128, mqt.input_name = "\CE\B8[12]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 12 : i64, name = "\CE\B8", size = 64 : i64}}, %arg13: f64 {mqt.input_id = 44246249981895013191645689038461798657 : i128, mqt.input_name = "\CE\B8[13]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 13 : i64, name = "\CE\B8", size = 64 : i64}}, %arg14: f64 {mqt.input_id = 44246249981895013191645689038461798658 : i128, mqt.input_name = "\CE\B8[14]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 14 : i64, name = "\CE\B8", size = 64 : i64}}, %arg15: f64 {mqt.input_id = 44246249981895013191645689038461798659 : i128, mqt.input_name = "\CE\B8[15]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 15 : i64, name = "\CE\B8", size = 64 : i64}}, %arg16: f64 {mqt.input_id = 44246249981895013191645689038461798660 : i128, mqt.input_name = "\CE\B8[16]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 16 : i64, name = "\CE\B8", size = 64 : i64}}, %arg17: f64 {mqt.input_id = 44246249981895013191645689038461798661 : i128, mqt.input_name = "\CE\B8[17]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 17 : i64, name = "\CE\B8", size = 64 : i64}}, %arg18: f64 {mqt.input_id = 44246249981895013191645689038461798662 : i128, mqt.input_name = "\CE\B8[18]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 18 : i64, name = "\CE\B8", size = 64 : i64}}, %arg19: f64 {mqt.input_id = 44246249981895013191645689038461798663 : i128, mqt.input_name = "\CE\B8[19]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 19 : i64, name = "\CE\B8", size = 64 : i64}}, %arg20: f64 {mqt.input_id = 44246249981895013191645689038461798664 : i128, mqt.input_name = "\CE\B8[20]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 20 : i64, name = "\CE\B8", size = 64 : i64}}, %arg21: f64 {mqt.input_id = 44246249981895013191645689038461798665 : i128, mqt.input_name = "\CE\B8[21]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 21 : i64, name = "\CE\B8", size = 64 : i64}}, %arg22: f64 {mqt.input_id = 44246249981895013191645689038461798666 : i128, mqt.input_name = "\CE\B8[22]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 22 : i64, name = "\CE\B8", size = 64 : i64}}, %arg23: f64 {mqt.input_id = 44246249981895013191645689038461798667 : i128, mqt.input_name = "\CE\B8[23]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 23 : i64, name = "\CE\B8", size = 64 : i64}}, %arg24: f64 {mqt.input_id = 44246249981895013191645689038461798668 : i128, mqt.input_name = "\CE\B8[24]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 24 : i64, name = "\CE\B8", size = 64 : i64}}, %arg25: f64 {mqt.input_id = 44246249981895013191645689038461798669 : i128, mqt.input_name = "\CE\B8[25]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 25 : i64, name = "\CE\B8", size = 64 : i64}}, %arg26: f64 {mqt.input_id = 44246249981895013191645689038461798670 : i128, mqt.input_name = "\CE\B8[26]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 26 : i64, name = "\CE\B8", size = 64 : i64}}, %arg27: f64 {mqt.input_id = 44246249981895013191645689038461798671 : i128, mqt.input_name = "\CE\B8[27]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 27 : i64, name = "\CE\B8", size = 64 : i64}}, %arg28: f64 {mqt.input_id = 44246249981895013191645689038461798672 : i128, mqt.input_name = "\CE\B8[28]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 28 : i64, name = "\CE\B8", size = 64 : i64}}, %arg29: f64 {mqt.input_id = 44246249981895013191645689038461798673 : i128, mqt.input_name = "\CE\B8[29]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 29 : i64, name = "\CE\B8", size = 64 : i64}}, %arg30: f64 {mqt.input_id = 44246249981895013191645689038461798674 : i128, mqt.input_name = "\CE\B8[30]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 30 : i64, name = "\CE\B8", size = 64 : i64}}, %arg31: f64 {mqt.input_id = 44246249981895013191645689038461798675 : i128, mqt.input_name = "\CE\B8[31]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 31 : i64, name = "\CE\B8", size = 64 : i64}}, %arg32: f64 {mqt.input_id = 44246249981895013191645689038461798676 : i128, mqt.input_name = "\CE\B8[32]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 32 : i64, name = "\CE\B8", size = 64 : i64}}, %arg33: f64 {mqt.input_id = 44246249981895013191645689038461798677 : i128, mqt.input_name = "\CE\B8[33]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 33 : i64, name = "\CE\B8", size = 64 : i64}}, %arg34: f64 {mqt.input_id = 44246249981895013191645689038461798678 : i128, mqt.input_name = "\CE\B8[34]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 34 : i64, name = "\CE\B8", size = 64 : i64}}, %arg35: f64 {mqt.input_id = 44246249981895013191645689038461798679 : i128, mqt.input_name = "\CE\B8[35]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 35 : i64, name = "\CE\B8", size = 64 : i64}}, %arg36: f64 {mqt.input_id = 44246249981895013191645689038461798680 : i128, mqt.input_name = "\CE\B8[36]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 36 : i64, name = "\CE\B8", size = 64 : i64}}, %arg37: f64 {mqt.input_id = 44246249981895013191645689038461798681 : i128, mqt.input_name = "\CE\B8[37]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 37 : i64, name = "\CE\B8", size = 64 : i64}}, %arg38: f64 {mqt.input_id = 44246249981895013191645689038461798682 : i128, mqt.input_name = "\CE\B8[38]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 38 : i64, name = "\CE\B8", size = 64 : i64}}, %arg39: f64 {mqt.input_id = 44246249981895013191645689038461798683 : i128, mqt.input_name = "\CE\B8[39]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 39 : i64, name = "\CE\B8", size = 64 : i64}}, %arg40: f64 {mqt.input_id = 44246249981895013191645689038461798684 : i128, mqt.input_name = "\CE\B8[40]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 40 : i64, name = "\CE\B8", size = 64 : i64}}, %arg41: f64 {mqt.input_id = 44246249981895013191645689038461798685 : i128, mqt.input_name = "\CE\B8[41]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 41 : i64, name = "\CE\B8", size = 64 : i64}}, %arg42: f64 {mqt.input_id = 44246249981895013191645689038461798686 : i128, mqt.input_name = "\CE\B8[42]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 42 : i64, name = "\CE\B8", size = 64 : i64}}, %arg43: f64 {mqt.input_id = 44246249981895013191645689038461798687 : i128, mqt.input_name = "\CE\B8[43]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 43 : i64, name = "\CE\B8", size = 64 : i64}}, %arg44: f64 {mqt.input_id = 44246249981895013191645689038461798688 : i128, mqt.input_name = "\CE\B8[44]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 44 : i64, name = "\CE\B8", size = 64 : i64}}, %arg45: f64 {mqt.input_id = 44246249981895013191645689038461798689 : i128, mqt.input_name = "\CE\B8[45]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 45 : i64, name = "\CE\B8", size = 64 : i64}}, %arg46: f64 {mqt.input_id = 44246249981895013191645689038461798690 : i128, mqt.input_name = "\CE\B8[46]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 46 : i64, name = "\CE\B8", size = 64 : i64}}, %arg47: f64 {mqt.input_id = 44246249981895013191645689038461798691 : i128, mqt.input_name = "\CE\B8[47]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 47 : i64, name = "\CE\B8", size = 64 : i64}}, %arg48: f64 {mqt.input_id = 44246249981895013191645689038461798692 : i128, mqt.input_name = "\CE\B8[48]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 48 : i64, name = "\CE\B8", size = 64 : i64}}, %arg49: f64 {mqt.input_id = 44246249981895013191645689038461798693 : i128, mqt.input_name = "\CE\B8[49]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 49 : i64, name = "\CE\B8", size = 64 : i64}}, %arg50: f64 {mqt.input_id = 44246249981895013191645689038461798694 : i128, mqt.input_name = "\CE\B8[50]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 50 : i64, name = "\CE\B8", size = 64 : i64}}, %arg51: f64 {mqt.input_id = 44246249981895013191645689038461798695 : i128, mqt.input_name = "\CE\B8[51]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 51 : i64, name = "\CE\B8", size = 64 : i64}}, %arg52: f64 {mqt.input_id = 44246249981895013191645689038461798696 : i128, mqt.input_name = "\CE\B8[52]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 52 : i64, name = "\CE\B8", size = 64 : i64}}, %arg53: f64 {mqt.input_id = 44246249981895013191645689038461798697 : i128, mqt.input_name = "\CE\B8[53]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 53 : i64, name = "\CE\B8", size = 64 : i64}}, %arg54: f64 {mqt.input_id = 44246249981895013191645689038461798698 : i128, mqt.input_name = "\CE\B8[54]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 54 : i64, name = "\CE\B8", size = 64 : i64}}, %arg55: f64 {mqt.input_id = 44246249981895013191645689038461798699 : i128, mqt.input_name = "\CE\B8[55]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 55 : i64, name = "\CE\B8", size = 64 : i64}}, %arg56: f64 {mqt.input_id = 44246249981895013191645689038461798700 : i128, mqt.input_name = "\CE\B8[56]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 56 : i64, name = "\CE\B8", size = 64 : i64}}, %arg57: f64 {mqt.input_id = 44246249981895013191645689038461798701 : i128, mqt.input_name = "\CE\B8[57]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 57 : i64, name = "\CE\B8", size = 64 : i64}}, %arg58: f64 {mqt.input_id = 44246249981895013191645689038461798702 : i128, mqt.input_name = "\CE\B8[58]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 58 : i64, name = "\CE\B8", size = 64 : i64}}, %arg59: f64 {mqt.input_id = 44246249981895013191645689038461798703 : i128, mqt.input_name = "\CE\B8[59]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 59 : i64, name = "\CE\B8", size = 64 : i64}}, %arg60: f64 {mqt.input_id = 44246249981895013191645689038461798704 : i128, mqt.input_name = "\CE\B8[60]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 60 : i64, name = "\CE\B8", size = 64 : i64}}, %arg61: f64 {mqt.input_id = 44246249981895013191645689038461798705 : i128, mqt.input_name = "\CE\B8[61]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 61 : i64, name = "\CE\B8", size = 64 : i64}}, %arg62: f64 {mqt.input_id = 44246249981895013191645689038461798706 : i128, mqt.input_name = "\CE\B8[62]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 62 : i64, name = "\CE\B8", size = 64 : i64}}, %arg63: f64 {mqt.input_id = 44246249981895013191645689038461798707 : i128, mqt.input_name = "\CE\B8[63]", mqt.parameter_group = {identity = "2149848d-037e-4e82-a35e-2d37c59d08f4", index = 63 : i64, name = "\CE\B8", size = 64 : i64}}) -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 1.5707963267948963 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant 4.7123889803846897 : f64
    %cst_2 = arith.constant -4.7123889803846897 : f64
    %cst_3 = arith.constant 4.000000e+00 : f64
    %cst_4 = arith.constant 1.5707963267948966 : f64
    %cst_5 = arith.constant 3.1415926535897931 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = arith.divf %arg0, %cst_3 : f64
    %9 = math.tan %8 : f64
    %10 = math.atan %9 : f64
    %11 = arith.mulf %10, %cst_3 : f64
    %12 = qco.rx(%cst_4) %0 : !qco.qubit -> !qco.qubit
    %13 = arith.addf %11, %cst_5 : f64
    %14 = qco.rz(%13) %12 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_4) %14 : !qco.qubit -> !qco.qubit
    %16 = arith.divf %arg1, %cst_3 : f64
    %17 = math.tan %16 : f64
    %18 = math.atan %17 : f64
    %19 = arith.mulf %18, %cst_3 : f64
    %20 = qco.rx(%cst_4) %1 : !qco.qubit -> !qco.qubit
    %21 = arith.addf %19, %cst_5 : f64
    %22 = qco.rz(%21) %20 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_4) %22 : !qco.qubit -> !qco.qubit
    %24 = arith.divf %arg2, %cst_3 : f64
    %25 = math.tan %24 : f64
    %26 = math.atan %25 : f64
    %27 = arith.mulf %26, %cst_3 : f64
    %28 = qco.rx(%cst_4) %2 : !qco.qubit -> !qco.qubit
    %29 = arith.addf %27, %cst_5 : f64
    %30 = qco.rz(%29) %28 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_4) %30 : !qco.qubit -> !qco.qubit
    %32 = arith.divf %arg3, %cst_3 : f64
    %33 = math.tan %32 : f64
    %34 = math.atan %33 : f64
    %35 = arith.mulf %34, %cst_3 : f64
    %36 = qco.rx(%cst_4) %3 : !qco.qubit -> !qco.qubit
    %37 = arith.addf %35, %cst_5 : f64
    %38 = qco.rz(%37) %36 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_4) %38 : !qco.qubit -> !qco.qubit
    %40 = arith.divf %arg4, %cst_3 : f64
    %41 = math.tan %40 : f64
    %42 = math.atan %41 : f64
    %43 = arith.mulf %42, %cst_3 : f64
    %44 = qco.rx(%cst_4) %4 : !qco.qubit -> !qco.qubit
    %45 = arith.addf %43, %cst_5 : f64
    %46 = qco.rz(%45) %44 : !qco.qubit -> !qco.qubit
    %47 = qco.rx(%cst_4) %46 : !qco.qubit -> !qco.qubit
    %48 = arith.divf %arg5, %cst_3 : f64
    %49 = math.tan %48 : f64
    %50 = math.atan %49 : f64
    %51 = arith.mulf %50, %cst_3 : f64
    %52 = qco.rx(%cst_4) %5 : !qco.qubit -> !qco.qubit
    %53 = arith.addf %51, %cst_5 : f64
    %54 = qco.rz(%53) %52 : !qco.qubit -> !qco.qubit
    %55 = qco.rx(%cst_4) %54 : !qco.qubit -> !qco.qubit
    %56 = arith.divf %arg6, %cst_3 : f64
    %57 = math.tan %56 : f64
    %58 = math.atan %57 : f64
    %59 = arith.mulf %58, %cst_3 : f64
    %60 = qco.rx(%cst_4) %6 : !qco.qubit -> !qco.qubit
    %61 = arith.addf %59, %cst_5 : f64
    %62 = qco.rz(%61) %60 : !qco.qubit -> !qco.qubit
    %63 = qco.rx(%cst_4) %62 : !qco.qubit -> !qco.qubit
    %64 = arith.divf %arg7, %cst_3 : f64
    %65 = math.tan %64 : f64
    %66 = math.atan %65 : f64
    %67 = arith.mulf %66, %cst_3 : f64
    %68 = qco.rx(%cst_4) %7 : !qco.qubit -> !qco.qubit
    %69 = arith.addf %67, %cst_5 : f64
    %70 = qco.rz(%69) %68 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_4) %70 : !qco.qubit -> !qco.qubit
    %72 = arith.divf %arg15, %cst_3 : f64
    %73 = math.tan %72 : f64
    %74 = math.atan %73 : f64
    %75 = arith.mulf %74, %cst_3 : f64
    %76 = arith.addf %75, %cst_5 : f64
    %77 = qco.rz(%76) %71 : !qco.qubit -> !qco.qubit
    %78 = arith.divf %arg8, %cst_3 : f64
    %79 = math.tan %78 : f64
    %80 = math.atan %79 : f64
    %81 = arith.mulf %80, %cst_3 : f64
    %82 = arith.addf %81, %cst_2 : f64
    %83 = arith.divf %82, %cst_3 : f64
    %84 = math.tan %83 : f64
    %85 = math.atan %84 : f64
    %86 = arith.mulf %85, %cst_3 : f64
    %87 = arith.addf %86, %cst_5 : f64
    %88 = qco.rz(%87) %15 : !qco.qubit -> !qco.qubit
    %89 = qco.rx(%cst_4) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_1) %89 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%77) targets (%arg64 = %90) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %91 = qco.rz(%cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %92 = qco.rx(%cst_4) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst) %92 : !qco.qubit -> !qco.qubit
    %94 = arith.divf %arg9, %cst_3 : f64
    %95 = math.tan %94 : f64
    %96 = math.atan %95 : f64
    %97 = arith.mulf %96, %cst_3 : f64
    %98 = arith.addf %97, %cst_2 : f64
    %99 = arith.divf %98, %cst_3 : f64
    %100 = math.tan %99 : f64
    %101 = math.atan %100 : f64
    %102 = arith.mulf %101, %cst_3 : f64
    %103 = arith.addf %102, %cst_5 : f64
    %104 = qco.rz(%103) %23 : !qco.qubit -> !qco.qubit
    %105 = qco.rx(%cst_4) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_1) %105 : !qco.qubit -> !qco.qubit
    %controls_out_6, %targets_out_7 = qco.ctrl(%93) targets (%arg64 = %106) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %107 = qco.rz(%cst_0) %targets_out_7 : !qco.qubit -> !qco.qubit
    %108 = qco.rx(%cst_4) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rz(%cst) %108 : !qco.qubit -> !qco.qubit
    %110 = arith.divf %arg10, %cst_3 : f64
    %111 = math.tan %110 : f64
    %112 = math.atan %111 : f64
    %113 = arith.mulf %112, %cst_3 : f64
    %114 = arith.addf %113, %cst_2 : f64
    %115 = arith.divf %114, %cst_3 : f64
    %116 = math.tan %115 : f64
    %117 = math.atan %116 : f64
    %118 = arith.mulf %117, %cst_3 : f64
    %119 = arith.addf %118, %cst_5 : f64
    %120 = qco.rz(%119) %31 : !qco.qubit -> !qco.qubit
    %121 = qco.rx(%cst_4) %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rz(%cst_1) %121 : !qco.qubit -> !qco.qubit
    %controls_out_8, %targets_out_9 = qco.ctrl(%109) targets (%arg64 = %122) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %123 = qco.rz(%cst_0) %targets_out_9 : !qco.qubit -> !qco.qubit
    %124 = qco.rx(%cst_4) %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rz(%cst) %124 : !qco.qubit -> !qco.qubit
    %126 = arith.divf %arg11, %cst_3 : f64
    %127 = math.tan %126 : f64
    %128 = math.atan %127 : f64
    %129 = arith.mulf %128, %cst_3 : f64
    %130 = arith.addf %129, %cst_2 : f64
    %131 = arith.divf %130, %cst_3 : f64
    %132 = math.tan %131 : f64
    %133 = math.atan %132 : f64
    %134 = arith.mulf %133, %cst_3 : f64
    %135 = arith.addf %134, %cst_5 : f64
    %136 = qco.rz(%135) %39 : !qco.qubit -> !qco.qubit
    %137 = qco.rx(%cst_4) %136 : !qco.qubit -> !qco.qubit
    %138 = qco.rz(%cst_1) %137 : !qco.qubit -> !qco.qubit
    %controls_out_10, %targets_out_11 = qco.ctrl(%125) targets (%arg64 = %138) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %139 = qco.rz(%cst_0) %targets_out_11 : !qco.qubit -> !qco.qubit
    %140 = qco.rx(%cst_4) %139 : !qco.qubit -> !qco.qubit
    %141 = qco.rz(%cst) %140 : !qco.qubit -> !qco.qubit
    %142 = arith.divf %arg12, %cst_3 : f64
    %143 = math.tan %142 : f64
    %144 = math.atan %143 : f64
    %145 = arith.mulf %144, %cst_3 : f64
    %146 = arith.addf %145, %cst_2 : f64
    %147 = arith.divf %146, %cst_3 : f64
    %148 = math.tan %147 : f64
    %149 = math.atan %148 : f64
    %150 = arith.mulf %149, %cst_3 : f64
    %151 = arith.addf %150, %cst_5 : f64
    %152 = qco.rz(%151) %47 : !qco.qubit -> !qco.qubit
    %153 = qco.rx(%cst_4) %152 : !qco.qubit -> !qco.qubit
    %154 = qco.rz(%cst_1) %153 : !qco.qubit -> !qco.qubit
    %controls_out_12, %targets_out_13 = qco.ctrl(%141) targets (%arg64 = %154) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %155 = qco.rz(%cst_0) %targets_out_13 : !qco.qubit -> !qco.qubit
    %156 = qco.rx(%cst_4) %155 : !qco.qubit -> !qco.qubit
    %157 = qco.rz(%cst) %156 : !qco.qubit -> !qco.qubit
    %158 = arith.divf %arg13, %cst_3 : f64
    %159 = math.tan %158 : f64
    %160 = math.atan %159 : f64
    %161 = arith.mulf %160, %cst_3 : f64
    %162 = arith.addf %161, %cst_2 : f64
    %163 = arith.divf %162, %cst_3 : f64
    %164 = math.tan %163 : f64
    %165 = math.atan %164 : f64
    %166 = arith.mulf %165, %cst_3 : f64
    %167 = arith.addf %166, %cst_5 : f64
    %168 = qco.rz(%167) %55 : !qco.qubit -> !qco.qubit
    %169 = qco.rx(%cst_4) %168 : !qco.qubit -> !qco.qubit
    %170 = qco.rz(%cst_1) %169 : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%157) targets (%arg64 = %170) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %171 = qco.rz(%cst_0) %targets_out_15 : !qco.qubit -> !qco.qubit
    %172 = qco.rx(%cst_4) %171 : !qco.qubit -> !qco.qubit
    %173 = qco.rz(%cst) %172 : !qco.qubit -> !qco.qubit
    %174 = arith.divf %arg14, %cst_3 : f64
    %175 = math.tan %174 : f64
    %176 = math.atan %175 : f64
    %177 = arith.mulf %176, %cst_3 : f64
    %178 = arith.addf %177, %cst_2 : f64
    %179 = arith.divf %178, %cst_3 : f64
    %180 = math.tan %179 : f64
    %181 = math.atan %180 : f64
    %182 = arith.mulf %181, %cst_3 : f64
    %183 = arith.addf %182, %cst_5 : f64
    %184 = qco.rz(%183) %63 : !qco.qubit -> !qco.qubit
    %185 = qco.rx(%cst_4) %184 : !qco.qubit -> !qco.qubit
    %186 = qco.rz(%cst_1) %185 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%173) targets (%arg64 = %186) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %187 = qco.rz(%cst_0) %targets_out_17 : !qco.qubit -> !qco.qubit
    %188 = qco.rx(%cst_4) %187 : !qco.qubit -> !qco.qubit
    %189 = qco.rz(%cst) %188 : !qco.qubit -> !qco.qubit
    %190 = qco.rz(%cst_2) %controls_out : !qco.qubit -> !qco.qubit
    %191 = qco.rx(%cst_4) %190 : !qco.qubit -> !qco.qubit
    %192 = qco.rz(%cst_1) %191 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%189) targets (%arg64 = %192) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %193 = qco.rz(%cst_0) %targets_out_19 : !qco.qubit -> !qco.qubit
    %194 = qco.rx(%cst_4) %193 : !qco.qubit -> !qco.qubit
    %195 = qco.rz(%cst) %194 : !qco.qubit -> !qco.qubit
    %196 = arith.divf %arg16, %cst_3 : f64
    %197 = math.tan %196 : f64
    %198 = math.atan %197 : f64
    %199 = arith.mulf %198, %cst_3 : f64
    %200 = qco.rx(%cst_4) %controls_out_6 : !qco.qubit -> !qco.qubit
    %201 = arith.addf %199, %cst_5 : f64
    %202 = qco.rz(%201) %200 : !qco.qubit -> !qco.qubit
    %203 = qco.rx(%cst_4) %202 : !qco.qubit -> !qco.qubit
    %204 = arith.divf %arg17, %cst_3 : f64
    %205 = math.tan %204 : f64
    %206 = math.atan %205 : f64
    %207 = arith.mulf %206, %cst_3 : f64
    %208 = qco.rx(%cst_4) %controls_out_8 : !qco.qubit -> !qco.qubit
    %209 = arith.addf %207, %cst_5 : f64
    %210 = qco.rz(%209) %208 : !qco.qubit -> !qco.qubit
    %211 = qco.rx(%cst_4) %210 : !qco.qubit -> !qco.qubit
    %212 = arith.divf %arg18, %cst_3 : f64
    %213 = math.tan %212 : f64
    %214 = math.atan %213 : f64
    %215 = arith.mulf %214, %cst_3 : f64
    %216 = qco.rx(%cst_4) %controls_out_10 : !qco.qubit -> !qco.qubit
    %217 = arith.addf %215, %cst_5 : f64
    %218 = qco.rz(%217) %216 : !qco.qubit -> !qco.qubit
    %219 = qco.rx(%cst_4) %218 : !qco.qubit -> !qco.qubit
    %220 = arith.divf %arg19, %cst_3 : f64
    %221 = math.tan %220 : f64
    %222 = math.atan %221 : f64
    %223 = arith.mulf %222, %cst_3 : f64
    %224 = qco.rx(%cst_4) %controls_out_12 : !qco.qubit -> !qco.qubit
    %225 = arith.addf %223, %cst_5 : f64
    %226 = qco.rz(%225) %224 : !qco.qubit -> !qco.qubit
    %227 = qco.rx(%cst_4) %226 : !qco.qubit -> !qco.qubit
    %228 = arith.divf %arg20, %cst_3 : f64
    %229 = math.tan %228 : f64
    %230 = math.atan %229 : f64
    %231 = arith.mulf %230, %cst_3 : f64
    %232 = qco.rx(%cst_4) %controls_out_14 : !qco.qubit -> !qco.qubit
    %233 = arith.addf %231, %cst_5 : f64
    %234 = qco.rz(%233) %232 : !qco.qubit -> !qco.qubit
    %235 = qco.rx(%cst_4) %234 : !qco.qubit -> !qco.qubit
    %236 = arith.divf %arg21, %cst_3 : f64
    %237 = math.tan %236 : f64
    %238 = math.atan %237 : f64
    %239 = arith.mulf %238, %cst_3 : f64
    %240 = qco.rx(%cst_4) %controls_out_16 : !qco.qubit -> !qco.qubit
    %241 = arith.addf %239, %cst_5 : f64
    %242 = qco.rz(%241) %240 : !qco.qubit -> !qco.qubit
    %243 = qco.rx(%cst_4) %242 : !qco.qubit -> !qco.qubit
    %244 = arith.divf %arg22, %cst_3 : f64
    %245 = math.tan %244 : f64
    %246 = math.atan %245 : f64
    %247 = arith.mulf %246, %cst_3 : f64
    %248 = qco.rx(%cst_4) %controls_out_18 : !qco.qubit -> !qco.qubit
    %249 = arith.addf %247, %cst_5 : f64
    %250 = qco.rz(%249) %248 : !qco.qubit -> !qco.qubit
    %251 = qco.rx(%cst_4) %250 : !qco.qubit -> !qco.qubit
    %252 = arith.divf %arg23, %cst_3 : f64
    %253 = math.tan %252 : f64
    %254 = math.atan %253 : f64
    %255 = arith.mulf %254, %cst_3 : f64
    %256 = qco.rx(%cst_4) %195 : !qco.qubit -> !qco.qubit
    %257 = arith.addf %255, %cst_5 : f64
    %258 = qco.rz(%257) %256 : !qco.qubit -> !qco.qubit
    %259 = qco.rx(%cst_4) %258 : !qco.qubit -> !qco.qubit
    %260 = arith.divf %arg31, %cst_3 : f64
    %261 = math.tan %260 : f64
    %262 = math.atan %261 : f64
    %263 = arith.mulf %262, %cst_3 : f64
    %264 = arith.addf %263, %cst_5 : f64
    %265 = qco.rz(%264) %259 : !qco.qubit -> !qco.qubit
    %266 = arith.divf %arg24, %cst_3 : f64
    %267 = math.tan %266 : f64
    %268 = math.atan %267 : f64
    %269 = arith.mulf %268, %cst_3 : f64
    %270 = arith.addf %269, %cst_2 : f64
    %271 = arith.divf %270, %cst_3 : f64
    %272 = math.tan %271 : f64
    %273 = math.atan %272 : f64
    %274 = arith.mulf %273, %cst_3 : f64
    %275 = arith.addf %274, %cst_5 : f64
    %276 = qco.rz(%275) %203 : !qco.qubit -> !qco.qubit
    %277 = qco.rx(%cst_4) %276 : !qco.qubit -> !qco.qubit
    %278 = qco.rz(%cst_1) %277 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%265) targets (%arg64 = %278) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %279 = qco.rz(%cst_0) %targets_out_21 : !qco.qubit -> !qco.qubit
    %280 = qco.rx(%cst_4) %279 : !qco.qubit -> !qco.qubit
    %281 = qco.rz(%cst) %280 : !qco.qubit -> !qco.qubit
    %282 = arith.divf %arg25, %cst_3 : f64
    %283 = math.tan %282 : f64
    %284 = math.atan %283 : f64
    %285 = arith.mulf %284, %cst_3 : f64
    %286 = arith.addf %285, %cst_2 : f64
    %287 = arith.divf %286, %cst_3 : f64
    %288 = math.tan %287 : f64
    %289 = math.atan %288 : f64
    %290 = arith.mulf %289, %cst_3 : f64
    %291 = arith.addf %290, %cst_5 : f64
    %292 = qco.rz(%291) %211 : !qco.qubit -> !qco.qubit
    %293 = qco.rx(%cst_4) %292 : !qco.qubit -> !qco.qubit
    %294 = qco.rz(%cst_1) %293 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%281) targets (%arg64 = %294) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %295 = qco.rz(%cst_0) %targets_out_23 : !qco.qubit -> !qco.qubit
    %296 = qco.rx(%cst_4) %295 : !qco.qubit -> !qco.qubit
    %297 = qco.rz(%cst) %296 : !qco.qubit -> !qco.qubit
    %298 = arith.divf %arg26, %cst_3 : f64
    %299 = math.tan %298 : f64
    %300 = math.atan %299 : f64
    %301 = arith.mulf %300, %cst_3 : f64
    %302 = arith.addf %301, %cst_2 : f64
    %303 = arith.divf %302, %cst_3 : f64
    %304 = math.tan %303 : f64
    %305 = math.atan %304 : f64
    %306 = arith.mulf %305, %cst_3 : f64
    %307 = arith.addf %306, %cst_5 : f64
    %308 = qco.rz(%307) %219 : !qco.qubit -> !qco.qubit
    %309 = qco.rx(%cst_4) %308 : !qco.qubit -> !qco.qubit
    %310 = qco.rz(%cst_1) %309 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%297) targets (%arg64 = %310) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %311 = qco.rz(%cst_0) %targets_out_25 : !qco.qubit -> !qco.qubit
    %312 = qco.rx(%cst_4) %311 : !qco.qubit -> !qco.qubit
    %313 = qco.rz(%cst) %312 : !qco.qubit -> !qco.qubit
    %314 = arith.divf %arg27, %cst_3 : f64
    %315 = math.tan %314 : f64
    %316 = math.atan %315 : f64
    %317 = arith.mulf %316, %cst_3 : f64
    %318 = arith.addf %317, %cst_2 : f64
    %319 = arith.divf %318, %cst_3 : f64
    %320 = math.tan %319 : f64
    %321 = math.atan %320 : f64
    %322 = arith.mulf %321, %cst_3 : f64
    %323 = arith.addf %322, %cst_5 : f64
    %324 = qco.rz(%323) %227 : !qco.qubit -> !qco.qubit
    %325 = qco.rx(%cst_4) %324 : !qco.qubit -> !qco.qubit
    %326 = qco.rz(%cst_1) %325 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%313) targets (%arg64 = %326) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %327 = qco.rz(%cst_0) %targets_out_27 : !qco.qubit -> !qco.qubit
    %328 = qco.rx(%cst_4) %327 : !qco.qubit -> !qco.qubit
    %329 = qco.rz(%cst) %328 : !qco.qubit -> !qco.qubit
    %330 = arith.divf %arg28, %cst_3 : f64
    %331 = math.tan %330 : f64
    %332 = math.atan %331 : f64
    %333 = arith.mulf %332, %cst_3 : f64
    %334 = arith.addf %333, %cst_2 : f64
    %335 = arith.divf %334, %cst_3 : f64
    %336 = math.tan %335 : f64
    %337 = math.atan %336 : f64
    %338 = arith.mulf %337, %cst_3 : f64
    %339 = arith.addf %338, %cst_5 : f64
    %340 = qco.rz(%339) %235 : !qco.qubit -> !qco.qubit
    %341 = qco.rx(%cst_4) %340 : !qco.qubit -> !qco.qubit
    %342 = qco.rz(%cst_1) %341 : !qco.qubit -> !qco.qubit
    %controls_out_28, %targets_out_29 = qco.ctrl(%329) targets (%arg64 = %342) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %343 = qco.rz(%cst_0) %targets_out_29 : !qco.qubit -> !qco.qubit
    %344 = qco.rx(%cst_4) %343 : !qco.qubit -> !qco.qubit
    %345 = qco.rz(%cst) %344 : !qco.qubit -> !qco.qubit
    %346 = arith.divf %arg29, %cst_3 : f64
    %347 = math.tan %346 : f64
    %348 = math.atan %347 : f64
    %349 = arith.mulf %348, %cst_3 : f64
    %350 = arith.addf %349, %cst_2 : f64
    %351 = arith.divf %350, %cst_3 : f64
    %352 = math.tan %351 : f64
    %353 = math.atan %352 : f64
    %354 = arith.mulf %353, %cst_3 : f64
    %355 = arith.addf %354, %cst_5 : f64
    %356 = qco.rz(%355) %243 : !qco.qubit -> !qco.qubit
    %357 = qco.rx(%cst_4) %356 : !qco.qubit -> !qco.qubit
    %358 = qco.rz(%cst_1) %357 : !qco.qubit -> !qco.qubit
    %controls_out_30, %targets_out_31 = qco.ctrl(%345) targets (%arg64 = %358) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %359 = qco.rz(%cst_0) %targets_out_31 : !qco.qubit -> !qco.qubit
    %360 = qco.rx(%cst_4) %359 : !qco.qubit -> !qco.qubit
    %361 = qco.rz(%cst) %360 : !qco.qubit -> !qco.qubit
    %362 = arith.divf %arg30, %cst_3 : f64
    %363 = math.tan %362 : f64
    %364 = math.atan %363 : f64
    %365 = arith.mulf %364, %cst_3 : f64
    %366 = arith.addf %365, %cst_2 : f64
    %367 = arith.divf %366, %cst_3 : f64
    %368 = math.tan %367 : f64
    %369 = math.atan %368 : f64
    %370 = arith.mulf %369, %cst_3 : f64
    %371 = arith.addf %370, %cst_5 : f64
    %372 = qco.rz(%371) %251 : !qco.qubit -> !qco.qubit
    %373 = qco.rx(%cst_4) %372 : !qco.qubit -> !qco.qubit
    %374 = qco.rz(%cst_1) %373 : !qco.qubit -> !qco.qubit
    %controls_out_32, %targets_out_33 = qco.ctrl(%361) targets (%arg64 = %374) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %375 = qco.rz(%cst_0) %targets_out_33 : !qco.qubit -> !qco.qubit
    %376 = qco.rx(%cst_4) %375 : !qco.qubit -> !qco.qubit
    %377 = qco.rz(%cst) %376 : !qco.qubit -> !qco.qubit
    %378 = qco.rz(%cst_2) %controls_out_20 : !qco.qubit -> !qco.qubit
    %379 = qco.rx(%cst_4) %378 : !qco.qubit -> !qco.qubit
    %380 = qco.rz(%cst_1) %379 : !qco.qubit -> !qco.qubit
    %controls_out_34, %targets_out_35 = qco.ctrl(%377) targets (%arg64 = %380) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %381 = qco.rz(%cst_0) %targets_out_35 : !qco.qubit -> !qco.qubit
    %382 = qco.rx(%cst_4) %381 : !qco.qubit -> !qco.qubit
    %383 = qco.rz(%cst) %382 : !qco.qubit -> !qco.qubit
    %384 = arith.divf %arg32, %cst_3 : f64
    %385 = math.tan %384 : f64
    %386 = math.atan %385 : f64
    %387 = arith.mulf %386, %cst_3 : f64
    %388 = qco.rx(%cst_4) %controls_out_22 : !qco.qubit -> !qco.qubit
    %389 = arith.addf %387, %cst_5 : f64
    %390 = qco.rz(%389) %388 : !qco.qubit -> !qco.qubit
    %391 = qco.rx(%cst_4) %390 : !qco.qubit -> !qco.qubit
    %392 = arith.divf %arg33, %cst_3 : f64
    %393 = math.tan %392 : f64
    %394 = math.atan %393 : f64
    %395 = arith.mulf %394, %cst_3 : f64
    %396 = qco.rx(%cst_4) %controls_out_24 : !qco.qubit -> !qco.qubit
    %397 = arith.addf %395, %cst_5 : f64
    %398 = qco.rz(%397) %396 : !qco.qubit -> !qco.qubit
    %399 = qco.rx(%cst_4) %398 : !qco.qubit -> !qco.qubit
    %400 = arith.divf %arg34, %cst_3 : f64
    %401 = math.tan %400 : f64
    %402 = math.atan %401 : f64
    %403 = arith.mulf %402, %cst_3 : f64
    %404 = qco.rx(%cst_4) %controls_out_26 : !qco.qubit -> !qco.qubit
    %405 = arith.addf %403, %cst_5 : f64
    %406 = qco.rz(%405) %404 : !qco.qubit -> !qco.qubit
    %407 = qco.rx(%cst_4) %406 : !qco.qubit -> !qco.qubit
    %408 = arith.divf %arg35, %cst_3 : f64
    %409 = math.tan %408 : f64
    %410 = math.atan %409 : f64
    %411 = arith.mulf %410, %cst_3 : f64
    %412 = qco.rx(%cst_4) %controls_out_28 : !qco.qubit -> !qco.qubit
    %413 = arith.addf %411, %cst_5 : f64
    %414 = qco.rz(%413) %412 : !qco.qubit -> !qco.qubit
    %415 = qco.rx(%cst_4) %414 : !qco.qubit -> !qco.qubit
    %416 = arith.divf %arg36, %cst_3 : f64
    %417 = math.tan %416 : f64
    %418 = math.atan %417 : f64
    %419 = arith.mulf %418, %cst_3 : f64
    %420 = qco.rx(%cst_4) %controls_out_30 : !qco.qubit -> !qco.qubit
    %421 = arith.addf %419, %cst_5 : f64
    %422 = qco.rz(%421) %420 : !qco.qubit -> !qco.qubit
    %423 = qco.rx(%cst_4) %422 : !qco.qubit -> !qco.qubit
    %424 = arith.divf %arg37, %cst_3 : f64
    %425 = math.tan %424 : f64
    %426 = math.atan %425 : f64
    %427 = arith.mulf %426, %cst_3 : f64
    %428 = qco.rx(%cst_4) %controls_out_32 : !qco.qubit -> !qco.qubit
    %429 = arith.addf %427, %cst_5 : f64
    %430 = qco.rz(%429) %428 : !qco.qubit -> !qco.qubit
    %431 = qco.rx(%cst_4) %430 : !qco.qubit -> !qco.qubit
    %432 = arith.divf %arg38, %cst_3 : f64
    %433 = math.tan %432 : f64
    %434 = math.atan %433 : f64
    %435 = arith.mulf %434, %cst_3 : f64
    %436 = qco.rx(%cst_4) %controls_out_34 : !qco.qubit -> !qco.qubit
    %437 = arith.addf %435, %cst_5 : f64
    %438 = qco.rz(%437) %436 : !qco.qubit -> !qco.qubit
    %439 = qco.rx(%cst_4) %438 : !qco.qubit -> !qco.qubit
    %440 = arith.divf %arg39, %cst_3 : f64
    %441 = math.tan %440 : f64
    %442 = math.atan %441 : f64
    %443 = arith.mulf %442, %cst_3 : f64
    %444 = qco.rx(%cst_4) %383 : !qco.qubit -> !qco.qubit
    %445 = arith.addf %443, %cst_5 : f64
    %446 = qco.rz(%445) %444 : !qco.qubit -> !qco.qubit
    %447 = qco.rx(%cst_4) %446 : !qco.qubit -> !qco.qubit
    %448 = arith.divf %arg47, %cst_3 : f64
    %449 = math.tan %448 : f64
    %450 = math.atan %449 : f64
    %451 = arith.mulf %450, %cst_3 : f64
    %452 = arith.addf %451, %cst_5 : f64
    %453 = qco.rz(%452) %447 : !qco.qubit -> !qco.qubit
    %454 = arith.divf %arg40, %cst_3 : f64
    %455 = math.tan %454 : f64
    %456 = math.atan %455 : f64
    %457 = arith.mulf %456, %cst_3 : f64
    %458 = arith.addf %457, %cst_2 : f64
    %459 = arith.divf %458, %cst_3 : f64
    %460 = math.tan %459 : f64
    %461 = math.atan %460 : f64
    %462 = arith.mulf %461, %cst_3 : f64
    %463 = arith.addf %462, %cst_5 : f64
    %464 = qco.rz(%463) %391 : !qco.qubit -> !qco.qubit
    %465 = qco.rx(%cst_4) %464 : !qco.qubit -> !qco.qubit
    %466 = qco.rz(%cst_1) %465 : !qco.qubit -> !qco.qubit
    %controls_out_36, %targets_out_37 = qco.ctrl(%453) targets (%arg64 = %466) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %467 = qco.rz(%cst_0) %targets_out_37 : !qco.qubit -> !qco.qubit
    %468 = qco.rx(%cst_4) %467 : !qco.qubit -> !qco.qubit
    %469 = qco.rz(%cst) %468 : !qco.qubit -> !qco.qubit
    %470 = arith.divf %arg41, %cst_3 : f64
    %471 = math.tan %470 : f64
    %472 = math.atan %471 : f64
    %473 = arith.mulf %472, %cst_3 : f64
    %474 = arith.addf %473, %cst_2 : f64
    %475 = arith.divf %474, %cst_3 : f64
    %476 = math.tan %475 : f64
    %477 = math.atan %476 : f64
    %478 = arith.mulf %477, %cst_3 : f64
    %479 = arith.addf %478, %cst_5 : f64
    %480 = qco.rz(%479) %399 : !qco.qubit -> !qco.qubit
    %481 = qco.rx(%cst_4) %480 : !qco.qubit -> !qco.qubit
    %482 = qco.rz(%cst_1) %481 : !qco.qubit -> !qco.qubit
    %controls_out_38, %targets_out_39 = qco.ctrl(%469) targets (%arg64 = %482) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %483 = qco.rz(%cst_0) %targets_out_39 : !qco.qubit -> !qco.qubit
    %484 = qco.rx(%cst_4) %483 : !qco.qubit -> !qco.qubit
    %485 = qco.rz(%cst) %484 : !qco.qubit -> !qco.qubit
    %486 = arith.divf %arg42, %cst_3 : f64
    %487 = math.tan %486 : f64
    %488 = math.atan %487 : f64
    %489 = arith.mulf %488, %cst_3 : f64
    %490 = arith.addf %489, %cst_2 : f64
    %491 = arith.divf %490, %cst_3 : f64
    %492 = math.tan %491 : f64
    %493 = math.atan %492 : f64
    %494 = arith.mulf %493, %cst_3 : f64
    %495 = arith.addf %494, %cst_5 : f64
    %496 = qco.rz(%495) %407 : !qco.qubit -> !qco.qubit
    %497 = qco.rx(%cst_4) %496 : !qco.qubit -> !qco.qubit
    %498 = qco.rz(%cst_1) %497 : !qco.qubit -> !qco.qubit
    %controls_out_40, %targets_out_41 = qco.ctrl(%485) targets (%arg64 = %498) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %499 = qco.rz(%cst_0) %targets_out_41 : !qco.qubit -> !qco.qubit
    %500 = qco.rx(%cst_4) %499 : !qco.qubit -> !qco.qubit
    %501 = qco.rz(%cst) %500 : !qco.qubit -> !qco.qubit
    %502 = arith.divf %arg43, %cst_3 : f64
    %503 = math.tan %502 : f64
    %504 = math.atan %503 : f64
    %505 = arith.mulf %504, %cst_3 : f64
    %506 = arith.addf %505, %cst_2 : f64
    %507 = arith.divf %506, %cst_3 : f64
    %508 = math.tan %507 : f64
    %509 = math.atan %508 : f64
    %510 = arith.mulf %509, %cst_3 : f64
    %511 = arith.addf %510, %cst_5 : f64
    %512 = qco.rz(%511) %415 : !qco.qubit -> !qco.qubit
    %513 = qco.rx(%cst_4) %512 : !qco.qubit -> !qco.qubit
    %514 = qco.rz(%cst_1) %513 : !qco.qubit -> !qco.qubit
    %controls_out_42, %targets_out_43 = qco.ctrl(%501) targets (%arg64 = %514) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %515 = qco.rz(%cst_0) %targets_out_43 : !qco.qubit -> !qco.qubit
    %516 = qco.rx(%cst_4) %515 : !qco.qubit -> !qco.qubit
    %517 = qco.rz(%cst) %516 : !qco.qubit -> !qco.qubit
    %518 = arith.divf %arg44, %cst_3 : f64
    %519 = math.tan %518 : f64
    %520 = math.atan %519 : f64
    %521 = arith.mulf %520, %cst_3 : f64
    %522 = arith.addf %521, %cst_2 : f64
    %523 = arith.divf %522, %cst_3 : f64
    %524 = math.tan %523 : f64
    %525 = math.atan %524 : f64
    %526 = arith.mulf %525, %cst_3 : f64
    %527 = arith.addf %526, %cst_5 : f64
    %528 = qco.rz(%527) %423 : !qco.qubit -> !qco.qubit
    %529 = qco.rx(%cst_4) %528 : !qco.qubit -> !qco.qubit
    %530 = qco.rz(%cst_1) %529 : !qco.qubit -> !qco.qubit
    %controls_out_44, %targets_out_45 = qco.ctrl(%517) targets (%arg64 = %530) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %531 = qco.rz(%cst_0) %targets_out_45 : !qco.qubit -> !qco.qubit
    %532 = qco.rx(%cst_4) %531 : !qco.qubit -> !qco.qubit
    %533 = qco.rz(%cst) %532 : !qco.qubit -> !qco.qubit
    %534 = arith.divf %arg45, %cst_3 : f64
    %535 = math.tan %534 : f64
    %536 = math.atan %535 : f64
    %537 = arith.mulf %536, %cst_3 : f64
    %538 = arith.addf %537, %cst_2 : f64
    %539 = arith.divf %538, %cst_3 : f64
    %540 = math.tan %539 : f64
    %541 = math.atan %540 : f64
    %542 = arith.mulf %541, %cst_3 : f64
    %543 = arith.addf %542, %cst_5 : f64
    %544 = qco.rz(%543) %431 : !qco.qubit -> !qco.qubit
    %545 = qco.rx(%cst_4) %544 : !qco.qubit -> !qco.qubit
    %546 = qco.rz(%cst_1) %545 : !qco.qubit -> !qco.qubit
    %controls_out_46, %targets_out_47 = qco.ctrl(%533) targets (%arg64 = %546) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %547 = qco.rz(%cst_0) %targets_out_47 : !qco.qubit -> !qco.qubit
    %548 = qco.rx(%cst_4) %547 : !qco.qubit -> !qco.qubit
    %549 = qco.rz(%cst) %548 : !qco.qubit -> !qco.qubit
    %550 = arith.divf %arg46, %cst_3 : f64
    %551 = math.tan %550 : f64
    %552 = math.atan %551 : f64
    %553 = arith.mulf %552, %cst_3 : f64
    %554 = arith.addf %553, %cst_2 : f64
    %555 = arith.divf %554, %cst_3 : f64
    %556 = math.tan %555 : f64
    %557 = math.atan %556 : f64
    %558 = arith.mulf %557, %cst_3 : f64
    %559 = arith.addf %558, %cst_5 : f64
    %560 = qco.rz(%559) %439 : !qco.qubit -> !qco.qubit
    %561 = qco.rx(%cst_4) %560 : !qco.qubit -> !qco.qubit
    %562 = qco.rz(%cst_1) %561 : !qco.qubit -> !qco.qubit
    %controls_out_48, %targets_out_49 = qco.ctrl(%549) targets (%arg64 = %562) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %563 = qco.rz(%cst_0) %targets_out_49 : !qco.qubit -> !qco.qubit
    %564 = qco.rx(%cst_4) %563 : !qco.qubit -> !qco.qubit
    %565 = qco.rz(%cst) %564 : !qco.qubit -> !qco.qubit
    %566 = qco.rz(%cst_2) %controls_out_36 : !qco.qubit -> !qco.qubit
    %567 = qco.rx(%cst_4) %566 : !qco.qubit -> !qco.qubit
    %568 = qco.rz(%cst_1) %567 : !qco.qubit -> !qco.qubit
    %controls_out_50, %targets_out_51 = qco.ctrl(%565) targets (%arg64 = %568) {
      %684 = qco.z %arg64 : !qco.qubit -> !qco.qubit
      qco.yield %684 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %569 = qco.rz(%cst_0) %targets_out_51 : !qco.qubit -> !qco.qubit
    %570 = qco.rx(%cst_4) %569 : !qco.qubit -> !qco.qubit
    %571 = qco.rz(%cst) %570 : !qco.qubit -> !qco.qubit
    %572 = arith.divf %arg48, %cst_3 : f64
    %573 = math.tan %572 : f64
    %574 = math.atan %573 : f64
    %575 = arith.mulf %574, %cst_3 : f64
    %576 = qco.rx(%cst_4) %controls_out_38 : !qco.qubit -> !qco.qubit
    %577 = arith.addf %575, %cst_5 : f64
    %578 = qco.rz(%577) %576 : !qco.qubit -> !qco.qubit
    %579 = qco.rx(%cst_4) %578 : !qco.qubit -> !qco.qubit
    %580 = arith.divf %arg49, %cst_3 : f64
    %581 = math.tan %580 : f64
    %582 = math.atan %581 : f64
    %583 = arith.mulf %582, %cst_3 : f64
    %584 = qco.rx(%cst_4) %controls_out_40 : !qco.qubit -> !qco.qubit
    %585 = arith.addf %583, %cst_5 : f64
    %586 = qco.rz(%585) %584 : !qco.qubit -> !qco.qubit
    %587 = qco.rx(%cst_4) %586 : !qco.qubit -> !qco.qubit
    %588 = arith.divf %arg50, %cst_3 : f64
    %589 = math.tan %588 : f64
    %590 = math.atan %589 : f64
    %591 = arith.mulf %590, %cst_3 : f64
    %592 = qco.rx(%cst_4) %controls_out_42 : !qco.qubit -> !qco.qubit
    %593 = arith.addf %591, %cst_5 : f64
    %594 = qco.rz(%593) %592 : !qco.qubit -> !qco.qubit
    %595 = qco.rx(%cst_4) %594 : !qco.qubit -> !qco.qubit
    %596 = arith.divf %arg51, %cst_3 : f64
    %597 = math.tan %596 : f64
    %598 = math.atan %597 : f64
    %599 = arith.mulf %598, %cst_3 : f64
    %600 = qco.rx(%cst_4) %controls_out_44 : !qco.qubit -> !qco.qubit
    %601 = arith.addf %599, %cst_5 : f64
    %602 = qco.rz(%601) %600 : !qco.qubit -> !qco.qubit
    %603 = qco.rx(%cst_4) %602 : !qco.qubit -> !qco.qubit
    %604 = arith.divf %arg52, %cst_3 : f64
    %605 = math.tan %604 : f64
    %606 = math.atan %605 : f64
    %607 = arith.mulf %606, %cst_3 : f64
    %608 = qco.rx(%cst_4) %controls_out_46 : !qco.qubit -> !qco.qubit
    %609 = arith.addf %607, %cst_5 : f64
    %610 = qco.rz(%609) %608 : !qco.qubit -> !qco.qubit
    %611 = qco.rx(%cst_4) %610 : !qco.qubit -> !qco.qubit
    %612 = arith.divf %arg53, %cst_3 : f64
    %613 = math.tan %612 : f64
    %614 = math.atan %613 : f64
    %615 = arith.mulf %614, %cst_3 : f64
    %616 = qco.rx(%cst_4) %controls_out_48 : !qco.qubit -> !qco.qubit
    %617 = arith.addf %615, %cst_5 : f64
    %618 = qco.rz(%617) %616 : !qco.qubit -> !qco.qubit
    %619 = qco.rx(%cst_4) %618 : !qco.qubit -> !qco.qubit
    %620 = arith.divf %arg54, %cst_3 : f64
    %621 = math.tan %620 : f64
    %622 = math.atan %621 : f64
    %623 = arith.mulf %622, %cst_3 : f64
    %624 = qco.rx(%cst_4) %controls_out_50 : !qco.qubit -> !qco.qubit
    %625 = arith.addf %623, %cst_5 : f64
    %626 = qco.rz(%625) %624 : !qco.qubit -> !qco.qubit
    %627 = qco.rx(%cst_4) %626 : !qco.qubit -> !qco.qubit
    %628 = arith.divf %arg55, %cst_3 : f64
    %629 = math.tan %628 : f64
    %630 = math.atan %629 : f64
    %631 = arith.mulf %630, %cst_3 : f64
    %632 = qco.rx(%cst_4) %571 : !qco.qubit -> !qco.qubit
    %633 = arith.addf %631, %cst_5 : f64
    %634 = qco.rz(%633) %632 : !qco.qubit -> !qco.qubit
    %635 = qco.rx(%cst_4) %634 : !qco.qubit -> !qco.qubit
    %636 = arith.divf %arg56, %cst_3 : f64
    %637 = math.tan %636 : f64
    %638 = math.atan %637 : f64
    %639 = arith.mulf %638, %cst_3 : f64
    %640 = arith.addf %639, %cst_5 : f64
    %641 = qco.rz(%640) %579 : !qco.qubit -> !qco.qubit
    %642 = arith.divf %arg57, %cst_3 : f64
    %643 = math.tan %642 : f64
    %644 = math.atan %643 : f64
    %645 = arith.mulf %644, %cst_3 : f64
    %646 = arith.addf %645, %cst_5 : f64
    %647 = qco.rz(%646) %587 : !qco.qubit -> !qco.qubit
    %648 = arith.divf %arg58, %cst_3 : f64
    %649 = math.tan %648 : f64
    %650 = math.atan %649 : f64
    %651 = arith.mulf %650, %cst_3 : f64
    %652 = arith.addf %651, %cst_5 : f64
    %653 = qco.rz(%652) %595 : !qco.qubit -> !qco.qubit
    %654 = arith.divf %arg59, %cst_3 : f64
    %655 = math.tan %654 : f64
    %656 = math.atan %655 : f64
    %657 = arith.mulf %656, %cst_3 : f64
    %658 = arith.addf %657, %cst_5 : f64
    %659 = qco.rz(%658) %603 : !qco.qubit -> !qco.qubit
    %660 = arith.divf %arg60, %cst_3 : f64
    %661 = math.tan %660 : f64
    %662 = math.atan %661 : f64
    %663 = arith.mulf %662, %cst_3 : f64
    %664 = arith.addf %663, %cst_5 : f64
    %665 = qco.rz(%664) %611 : !qco.qubit -> !qco.qubit
    %666 = arith.divf %arg61, %cst_3 : f64
    %667 = math.tan %666 : f64
    %668 = math.atan %667 : f64
    %669 = arith.mulf %668, %cst_3 : f64
    %670 = arith.addf %669, %cst_5 : f64
    %671 = qco.rz(%670) %619 : !qco.qubit -> !qco.qubit
    %672 = arith.divf %arg62, %cst_3 : f64
    %673 = math.tan %672 : f64
    %674 = math.atan %673 : f64
    %675 = arith.mulf %674, %cst_3 : f64
    %676 = arith.addf %675, %cst_5 : f64
    %677 = qco.rz(%676) %627 : !qco.qubit -> !qco.qubit
    qco.sink %641 : !qco.qubit
    qco.sink %647 : !qco.qubit
    qco.sink %653 : !qco.qubit
    qco.sink %659 : !qco.qubit
    qco.sink %665 : !qco.qubit
    qco.sink %671 : !qco.qubit
    qco.sink %677 : !qco.qubit
    %678 = arith.divf %arg63, %cst_3 : f64
    %679 = math.tan %678 : f64
    %680 = math.atan %679 : f64
    %681 = arith.mulf %680, %cst_3 : f64
    %682 = arith.addf %681, %cst_5 : f64
    %683 = qco.rz(%682) %635 : !qco.qubit -> !qco.qubit
    qco.sink %683 : !qco.qubit
    return %c0_i64 : i64
  }
}
