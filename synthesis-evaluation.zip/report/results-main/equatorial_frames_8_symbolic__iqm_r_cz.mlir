module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main(%arg0: f64 {mqt.input_id = 16309916367715198394276235805800677067 : i128, mqt.input_name = "theta[0]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 0 : i64, name = "theta", size = 24 : i64}}, %arg1: f64 {mqt.input_id = 16309916367715198394276235805800677068 : i128, mqt.input_name = "theta[1]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 1 : i64, name = "theta", size = 24 : i64}}, %arg2: f64 {mqt.input_id = 16309916367715198394276235805800677069 : i128, mqt.input_name = "theta[2]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 2 : i64, name = "theta", size = 24 : i64}}, %arg3: f64 {mqt.input_id = 16309916367715198394276235805800677070 : i128, mqt.input_name = "theta[3]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 3 : i64, name = "theta", size = 24 : i64}}, %arg4: f64 {mqt.input_id = 16309916367715198394276235805800677071 : i128, mqt.input_name = "theta[4]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 4 : i64, name = "theta", size = 24 : i64}}, %arg5: f64 {mqt.input_id = 16309916367715198394276235805800677072 : i128, mqt.input_name = "theta[5]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 5 : i64, name = "theta", size = 24 : i64}}, %arg6: f64 {mqt.input_id = 16309916367715198394276235805800677073 : i128, mqt.input_name = "theta[6]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 6 : i64, name = "theta", size = 24 : i64}}, %arg7: f64 {mqt.input_id = 16309916367715198394276235805800677074 : i128, mqt.input_name = "theta[7]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 7 : i64, name = "theta", size = 24 : i64}}, %arg8: f64 {mqt.input_id = 16309916367715198394276235805800677075 : i128, mqt.input_name = "theta[8]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 8 : i64, name = "theta", size = 24 : i64}}, %arg9: f64 {mqt.input_id = 16309916367715198394276235805800677076 : i128, mqt.input_name = "theta[9]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 9 : i64, name = "theta", size = 24 : i64}}, %arg10: f64 {mqt.input_id = 16309916367715198394276235805800677077 : i128, mqt.input_name = "theta[10]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 10 : i64, name = "theta", size = 24 : i64}}, %arg11: f64 {mqt.input_id = 16309916367715198394276235805800677078 : i128, mqt.input_name = "theta[11]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 11 : i64, name = "theta", size = 24 : i64}}, %arg12: f64 {mqt.input_id = 16309916367715198394276235805800677079 : i128, mqt.input_name = "theta[12]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 12 : i64, name = "theta", size = 24 : i64}}, %arg13: f64 {mqt.input_id = 16309916367715198394276235805800677080 : i128, mqt.input_name = "theta[13]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 13 : i64, name = "theta", size = 24 : i64}}, %arg14: f64 {mqt.input_id = 16309916367715198394276235805800677081 : i128, mqt.input_name = "theta[14]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 14 : i64, name = "theta", size = 24 : i64}}, %arg15: f64 {mqt.input_id = 16309916367715198394276235805800677082 : i128, mqt.input_name = "theta[15]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 15 : i64, name = "theta", size = 24 : i64}}, %arg16: f64 {mqt.input_id = 16309916367715198394276235805800677083 : i128, mqt.input_name = "theta[16]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 16 : i64, name = "theta", size = 24 : i64}}, %arg17: f64 {mqt.input_id = 16309916367715198394276235805800677084 : i128, mqt.input_name = "theta[17]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 17 : i64, name = "theta", size = 24 : i64}}, %arg18: f64 {mqt.input_id = 16309916367715198394276235805800677085 : i128, mqt.input_name = "theta[18]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 18 : i64, name = "theta", size = 24 : i64}}, %arg19: f64 {mqt.input_id = 16309916367715198394276235805800677086 : i128, mqt.input_name = "theta[19]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 19 : i64, name = "theta", size = 24 : i64}}, %arg20: f64 {mqt.input_id = 16309916367715198394276235805800677087 : i128, mqt.input_name = "theta[20]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 20 : i64, name = "theta", size = 24 : i64}}, %arg21: f64 {mqt.input_id = 16309916367715198394276235805800677088 : i128, mqt.input_name = "theta[21]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 21 : i64, name = "theta", size = 24 : i64}}, %arg22: f64 {mqt.input_id = 16309916367715198394276235805800677089 : i128, mqt.input_name = "theta[22]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 22 : i64, name = "theta", size = 24 : i64}}, %arg23: f64 {mqt.input_id = 16309916367715198394276235805800677090 : i128, mqt.input_name = "theta[23]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 23 : i64, name = "theta", size = 24 : i64}}) -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 4.000000e+00 : f64
    %cst_0 = arith.constant 3.1415926535897931 : f64
    %cst_1 = arith.constant 2.000000e+00 : f64
    %cst_2 = arith.constant 0.000000e+00 : f64
    %cst_3 = arith.constant 3.000000e-01 : f64
    %cst_4 = arith.constant 2.000000e-01 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = arith.divf %arg0, %cst : f64
    %9 = math.tan %8 : f64
    %10 = math.atan %9 : f64
    %11 = arith.mulf %10, %cst : f64
    %12 = arith.divf %cst_0, %cst_1 : f64
    %13 = arith.negf %12 : f64
    %14 = qco.r(%13, %cst_2) %0 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%11, %12) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%12, %cst_2) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_3, %cst_4) %16 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%17) targets (%arg24 = %1) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = arith.divf %arg1, %cst : f64
    %19 = math.tan %18 : f64
    %20 = math.atan %19 : f64
    %21 = arith.mulf %20, %cst : f64
    %22 = qco.r(%13, %cst_2) %targets_out : !qco.qubit -> !qco.qubit
    %23 = qco.r(%21, %12) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%12, %cst_2) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_3, %cst_4) %24 : !qco.qubit -> !qco.qubit
    %controls_out_5, %targets_out_6 = qco.ctrl(%25) targets (%arg24 = %2) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = arith.divf %arg2, %cst : f64
    %27 = math.tan %26 : f64
    %28 = math.atan %27 : f64
    %29 = arith.mulf %28, %cst : f64
    %30 = qco.r(%13, %cst_2) %targets_out_6 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%29, %12) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%12, %cst_2) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_3, %cst_4) %32 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%33) targets (%arg24 = %3) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = arith.divf %arg3, %cst : f64
    %35 = math.tan %34 : f64
    %36 = math.atan %35 : f64
    %37 = arith.mulf %36, %cst : f64
    %38 = qco.r(%13, %cst_2) %targets_out_8 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%37, %12) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%12, %cst_2) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst_3, %cst_4) %40 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%41) targets (%arg24 = %4) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %42 = arith.divf %arg4, %cst : f64
    %43 = math.tan %42 : f64
    %44 = math.atan %43 : f64
    %45 = arith.mulf %44, %cst : f64
    %46 = qco.r(%13, %cst_2) %targets_out_10 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%45, %12) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%12, %cst_2) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.r(%cst_3, %cst_4) %48 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%49) targets (%arg24 = %5) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = arith.divf %arg5, %cst : f64
    %51 = math.tan %50 : f64
    %52 = math.atan %51 : f64
    %53 = arith.mulf %52, %cst : f64
    %54 = qco.r(%13, %cst_2) %targets_out_12 : !qco.qubit -> !qco.qubit
    %55 = qco.r(%53, %12) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.r(%12, %cst_2) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.r(%cst_3, %cst_4) %56 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%57) targets (%arg24 = %6) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = arith.divf %arg6, %cst : f64
    %59 = math.tan %58 : f64
    %60 = math.atan %59 : f64
    %61 = arith.mulf %60, %cst : f64
    %62 = qco.r(%13, %cst_2) %targets_out_14 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%61, %12) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.r(%12, %cst_2) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%cst_3, %cst_4) %64 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%65) targets (%arg24 = %7) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = arith.divf %arg7, %cst : f64
    %67 = math.tan %66 : f64
    %68 = math.atan %67 : f64
    %69 = arith.mulf %68, %cst : f64
    %70 = qco.r(%13, %cst_2) %targets_out_16 : !qco.qubit -> !qco.qubit
    %71 = qco.r(%69, %12) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%12, %cst_2) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%cst_3, %cst_4) %72 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%73) targets (%arg24 = %controls_out) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %74 = arith.divf %arg8, %cst : f64
    %75 = math.tan %74 : f64
    %76 = math.atan %75 : f64
    %77 = arith.mulf %76, %cst : f64
    %78 = qco.r(%13, %cst_2) %targets_out_18 : !qco.qubit -> !qco.qubit
    %79 = qco.r(%77, %12) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.r(%12, %cst_2) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%cst_3, %cst_4) %80 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%81) targets (%arg24 = %controls_out_5) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %82 = arith.divf %arg9, %cst : f64
    %83 = math.tan %82 : f64
    %84 = math.atan %83 : f64
    %85 = arith.mulf %84, %cst : f64
    %86 = qco.r(%13, %cst_2) %targets_out_20 : !qco.qubit -> !qco.qubit
    %87 = qco.r(%85, %12) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.r(%12, %cst_2) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%cst_3, %cst_4) %88 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%89) targets (%arg24 = %controls_out_7) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %90 = arith.divf %arg10, %cst : f64
    %91 = math.tan %90 : f64
    %92 = math.atan %91 : f64
    %93 = arith.mulf %92, %cst : f64
    %94 = qco.r(%13, %cst_2) %targets_out_22 : !qco.qubit -> !qco.qubit
    %95 = qco.r(%93, %12) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.r(%12, %cst_2) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.r(%cst_3, %cst_4) %96 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%97) targets (%arg24 = %controls_out_9) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %98 = arith.divf %arg11, %cst : f64
    %99 = math.tan %98 : f64
    %100 = math.atan %99 : f64
    %101 = arith.mulf %100, %cst : f64
    %102 = qco.r(%13, %cst_2) %targets_out_24 : !qco.qubit -> !qco.qubit
    %103 = qco.r(%101, %12) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.r(%12, %cst_2) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.r(%cst_3, %cst_4) %104 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%105) targets (%arg24 = %controls_out_11) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %106 = arith.divf %arg12, %cst : f64
    %107 = math.tan %106 : f64
    %108 = math.atan %107 : f64
    %109 = arith.mulf %108, %cst : f64
    %110 = qco.r(%13, %cst_2) %targets_out_26 : !qco.qubit -> !qco.qubit
    %111 = qco.r(%109, %12) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.r(%12, %cst_2) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.r(%cst_3, %cst_4) %112 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%113) targets (%arg24 = %controls_out_13) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %114 = arith.divf %arg13, %cst : f64
    %115 = math.tan %114 : f64
    %116 = math.atan %115 : f64
    %117 = arith.mulf %116, %cst : f64
    %118 = qco.r(%13, %cst_2) %targets_out_28 : !qco.qubit -> !qco.qubit
    %119 = qco.r(%117, %12) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.r(%12, %cst_2) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.r(%cst_3, %cst_4) %120 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%121) targets (%arg24 = %controls_out_15) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %122 = arith.divf %arg14, %cst : f64
    %123 = math.tan %122 : f64
    %124 = math.atan %123 : f64
    %125 = arith.mulf %124, %cst : f64
    %126 = qco.r(%13, %cst_2) %targets_out_30 : !qco.qubit -> !qco.qubit
    %127 = qco.r(%125, %12) %126 : !qco.qubit -> !qco.qubit
    %128 = qco.r(%12, %cst_2) %127 : !qco.qubit -> !qco.qubit
    %129 = qco.r(%cst_3, %cst_4) %128 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%129) targets (%arg24 = %controls_out_17) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %130 = arith.divf %arg15, %cst : f64
    %131 = math.tan %130 : f64
    %132 = math.atan %131 : f64
    %133 = arith.mulf %132, %cst : f64
    %134 = qco.r(%13, %cst_2) %targets_out_32 : !qco.qubit -> !qco.qubit
    %135 = qco.r(%133, %12) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.r(%12, %cst_2) %135 : !qco.qubit -> !qco.qubit
    %137 = qco.r(%cst_3, %cst_4) %136 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%137) targets (%arg24 = %controls_out_19) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %138 = arith.divf %arg16, %cst : f64
    %139 = math.tan %138 : f64
    %140 = math.atan %139 : f64
    %141 = arith.mulf %140, %cst : f64
    %142 = qco.r(%13, %cst_2) %targets_out_34 : !qco.qubit -> !qco.qubit
    %143 = qco.r(%141, %12) %142 : !qco.qubit -> !qco.qubit
    %144 = qco.r(%12, %cst_2) %143 : !qco.qubit -> !qco.qubit
    %145 = qco.r(%cst_3, %cst_4) %144 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%145) targets (%arg24 = %controls_out_21) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %146 = arith.divf %arg17, %cst : f64
    %147 = math.tan %146 : f64
    %148 = math.atan %147 : f64
    %149 = arith.mulf %148, %cst : f64
    %150 = qco.r(%13, %cst_2) %targets_out_36 : !qco.qubit -> !qco.qubit
    %151 = qco.r(%149, %12) %150 : !qco.qubit -> !qco.qubit
    %152 = qco.r(%12, %cst_2) %151 : !qco.qubit -> !qco.qubit
    %153 = qco.r(%cst_3, %cst_4) %152 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%153) targets (%arg24 = %controls_out_23) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %154 = arith.divf %arg18, %cst : f64
    %155 = math.tan %154 : f64
    %156 = math.atan %155 : f64
    %157 = arith.mulf %156, %cst : f64
    %158 = qco.r(%13, %cst_2) %targets_out_38 : !qco.qubit -> !qco.qubit
    %159 = qco.r(%157, %12) %158 : !qco.qubit -> !qco.qubit
    %160 = qco.r(%12, %cst_2) %159 : !qco.qubit -> !qco.qubit
    %161 = qco.r(%cst_3, %cst_4) %160 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%161) targets (%arg24 = %controls_out_25) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %162 = arith.divf %arg19, %cst : f64
    %163 = math.tan %162 : f64
    %164 = math.atan %163 : f64
    %165 = arith.mulf %164, %cst : f64
    %166 = qco.r(%13, %cst_2) %targets_out_40 : !qco.qubit -> !qco.qubit
    %167 = qco.r(%165, %12) %166 : !qco.qubit -> !qco.qubit
    %168 = qco.r(%12, %cst_2) %167 : !qco.qubit -> !qco.qubit
    %169 = qco.r(%cst_3, %cst_4) %168 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%169) targets (%arg24 = %controls_out_27) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %170 = arith.divf %arg20, %cst : f64
    %171 = math.tan %170 : f64
    %172 = math.atan %171 : f64
    %173 = arith.mulf %172, %cst : f64
    %174 = qco.r(%13, %cst_2) %targets_out_42 : !qco.qubit -> !qco.qubit
    %175 = qco.r(%173, %12) %174 : !qco.qubit -> !qco.qubit
    %176 = qco.r(%12, %cst_2) %175 : !qco.qubit -> !qco.qubit
    %177 = qco.r(%cst_3, %cst_4) %176 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%177) targets (%arg24 = %controls_out_29) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %178 = arith.divf %arg21, %cst : f64
    %179 = math.tan %178 : f64
    %180 = math.atan %179 : f64
    %181 = arith.mulf %180, %cst : f64
    %182 = qco.r(%13, %cst_2) %targets_out_44 : !qco.qubit -> !qco.qubit
    %183 = qco.r(%181, %12) %182 : !qco.qubit -> !qco.qubit
    %184 = qco.r(%12, %cst_2) %183 : !qco.qubit -> !qco.qubit
    %185 = qco.r(%cst_3, %cst_4) %184 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%185) targets (%arg24 = %controls_out_31) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %186 = arith.divf %arg22, %cst : f64
    %187 = math.tan %186 : f64
    %188 = math.atan %187 : f64
    %189 = arith.mulf %188, %cst : f64
    %190 = qco.r(%13, %cst_2) %targets_out_46 : !qco.qubit -> !qco.qubit
    %191 = qco.r(%189, %12) %190 : !qco.qubit -> !qco.qubit
    %192 = qco.r(%12, %cst_2) %191 : !qco.qubit -> !qco.qubit
    %193 = qco.r(%cst_3, %cst_4) %192 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%193) targets (%arg24 = %controls_out_33) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %194 = arith.divf %arg23, %cst : f64
    %195 = math.tan %194 : f64
    %196 = math.atan %195 : f64
    %197 = arith.mulf %196, %cst : f64
    %198 = qco.r(%13, %cst_2) %targets_out_48 : !qco.qubit -> !qco.qubit
    %199 = qco.r(%197, %12) %198 : !qco.qubit -> !qco.qubit
    %200 = qco.r(%12, %cst_2) %199 : !qco.qubit -> !qco.qubit
    %201 = qco.r(%cst_3, %cst_4) %200 : !qco.qubit -> !qco.qubit
    qco.sink %controls_out_37 : !qco.qubit
    qco.sink %controls_out_39 : !qco.qubit
    qco.sink %controls_out_41 : !qco.qubit
    qco.sink %controls_out_43 : !qco.qubit
    qco.sink %controls_out_45 : !qco.qubit
    qco.sink %controls_out_47 : !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%201) targets (%arg24 = %controls_out_35) {
      %202 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %202 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    qco.sink %targets_out_50 : !qco.qubit
    qco.sink %controls_out_49 : !qco.qubit
    return %c0_i64 : i64
  }
}
