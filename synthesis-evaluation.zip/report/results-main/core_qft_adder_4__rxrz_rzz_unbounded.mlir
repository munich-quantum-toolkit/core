module attributes {mqt.layout = {initial = array<i64: 1, 0, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant -5.497787143782138 : f64
    %cst_0 = arith.constant 2.3561944901923448 : f64
    %cst_1 = arith.constant 2.3561944901923439 : f64
    %cst_2 = arith.constant 1.5707963267948968 : f64
    %cst_3 = arith.constant 1.5707963267948961 : f64
    %cst_4 = arith.constant 4.7123889803846897 : f64
    %cst_5 = arith.constant 0.78539816339744828 : f64
    %cst_6 = arith.constant 0.78539816339744861 : f64
    %cst_7 = arith.constant -3.1415926535897931 : f64
    %cst_8 = arith.constant -1.5707963267948966 : f64
    %cst_9 = arith.constant 2.3561944901923457 : f64
    %cst_10 = arith.constant -1.5707963267948968 : f64
    %cst_11 = arith.constant 3.752318617979002 : f64
    %cst_12 = arith.constant 3.1415926535897931 : f64
    %cst_13 = arith.constant 0.6107259643892089 : f64
    %cst_14 = arith.constant 1.570796326794897 : f64
    %cst_15 = arith.constant 6.2831853071795862 : f64
    %cst_16 = arith.constant 1.5707963267948966 : f64
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.rx(%cst_12) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.rx(%cst_12) %2 : !qco.qubit -> !qco.qubit
    %6 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %7 = qco.rx(%cst_16) %3 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_16) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_16) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_16) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_15) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_8) %5 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_2) %12 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_16) %13, %11 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %14 = qco.rx(%cst_13) %qubit1_out : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_12) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_11) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_8) %qubit0_out : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_1) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_8) %18 : !qco.qubit -> !qco.qubit
    %qubit0_out_17, %qubit1_out_18 = qco.rzz(%cst_16) %19, %16 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %20 = qco.rx(%cst_7) %qubit1_out_18 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_0) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst_15) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst) %qubit0_out_17 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_16) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_16) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_16) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_16) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_16) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_7) %4 : !qco.qubit -> !qco.qubit
    %qubit0_out_19, %qubit1_out_20 = qco.rzz(%cst_16) %29, %22 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %30 = qco.rz(%cst_16) %qubit1_out_20 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_7) %qubit0_out_19 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_3) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_15) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_16) %30 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_15) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_8) %1 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_2) %36 : !qco.qubit -> !qco.qubit
    %qubit0_out_21, %qubit1_out_22 = qco.rzz(%cst_16) %37, %35 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %38 = qco.rx(%cst_13) %qubit1_out_22 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_12) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_11) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_8) %qubit0_out_21 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_1) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_8) %42 : !qco.qubit -> !qco.qubit
    %qubit0_out_23, %qubit1_out_24 = qco.rzz(%cst_16) %43, %40 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %44 = qco.rx(%cst_7) %qubit1_out_24 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_0) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst_15) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rx(%cst) %qubit0_out_23 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_16) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_16) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_7) %49 : !qco.qubit -> !qco.qubit
    %qubit0_out_25, %qubit1_out_26 = qco.rzz(%cst_16) %50, %28 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %51 = qco.rz(%cst_16) %qubit1_out_26 : !qco.qubit -> !qco.qubit
    %52 = qco.rx(%cst_7) %qubit0_out_25 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_3) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rx(%cst_15) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rx(%cst_16) %51 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_16) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rx(%cst_16) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_16) %46 : !qco.qubit -> !qco.qubit
    %59 = qco.rx(%cst_15) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rx(%cst_16) %57 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_14) %60 : !qco.qubit -> !qco.qubit
    %qubit0_out_27, %qubit1_out_28 = qco.rzz(%cst_16) %61, %59 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %62 = qco.rx(%cst_13) %qubit1_out_28 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_12) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rx(%cst_11) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rx(%cst_10) %qubit0_out_27 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_9) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rx(%cst_8) %66 : !qco.qubit -> !qco.qubit
    %qubit0_out_29, %qubit1_out_30 = qco.rzz(%cst_16) %67, %64 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %68 = qco.rx(%cst_7) %qubit1_out_30 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_6) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rx(%cst_5) %qubit0_out_29 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_16) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rx(%cst_4) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rx(%cst_16) %69 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_16) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rx(%cst_16) %74 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %72 : !qco.qubit
    cbit.store %result, %6[%c0] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    %qubit_out_31, %result_32 = qco.measure %75 : !qco.qubit
    qco.sink %qubit_out_31 : !qco.qubit
    cbit.store %result_32, %6[%c1] : !cbit.reg<4>
    %qubit_out_33, %result_34 = qco.measure %54 : !qco.qubit
    cbit.store %result_34, %6[%c2] : !cbit.reg<4>
    qco.sink %qubit_out_33 : !qco.qubit
    %qubit_out_35, %result_36 = qco.measure %33 : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    cbit.store %result_36, %6[%c3] : !cbit.reg<4>
    %cst_37 = arith.constant -1.1780972450961738 : f64
    qco.gphase(%cst_37)
    return %6 : !cbit.reg<4>
  }
}
