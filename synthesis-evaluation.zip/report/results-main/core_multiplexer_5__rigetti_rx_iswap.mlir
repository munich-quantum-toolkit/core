module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 0>, input_count = 5 : i64, sites = array<i64: 0, 1, 2, 3, 4>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<5> attributes {mqt.entry_point} {
    %cst = arith.constant 4.7123889803846897 : f64
    %cst_0 = arith.constant -1.249045772398254 : f64
    %cst_1 = arith.constant 2.677945044588987 : f64
    %cst_2 = arith.constant 3.9269908169872414 : f64
    %cst_3 = arith.constant 5.4977871437821371 : f64
    %cst_4 = arith.constant -0.78539816339744828 : f64
    %cst_5 = arith.constant 3.5342917352885173 : f64
    %cst_6 = arith.constant 1.570796326794897 : f64
    %cst_7 = arith.constant 5.8904862254808616 : f64
    %cst_8 = arith.constant -1.570796326794897 : f64
    %cst_9 = arith.constant 1.8925468811915387 : f64
    %cst_10 = arith.constant 3.1415926535897927 : f64
    %cst_11 = arith.constant 3.337942194439155 : f64
    %cst_12 = arith.constant -4.7123889803846897 : f64
    %cst_13 = arith.constant 6.0868357663302248 : f64
    %cst_14 = arith.constant -1.5707963267948966 : f64
    %cst_15 = arith.constant -3.1415926535897936 : f64
    %cst_16 = arith.constant 3.1415926535897922 : f64
    %cst_17 = arith.constant 3.2397674240144738 : f64
    %cst_18 = arith.constant -4.7123889803846888 : f64
    %cst_19 = arith.constant 6.1850105367549055 : f64
    %cst_20 = arith.constant 1.5707963267948966 : f64
    %cst_21 = arith.constant -1.5707963267948974 : f64
    %cst_22 = arith.constant 0.78539816339744828 : f64
    %cst_23 = arith.constant 2.3561944901923448 : f64
    %cst_24 = arith.constant 5.8195376981787801 : f64
    %cst_25 = arith.constant 1.5707963267948963 : f64
    %cst_26 = arith.constant 3.1415926535897931 : f64
    %cst_27 = arith.constant 1.5707963267948968 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<5>
    %6 = qco.rz(%cst_20) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.rx(%cst_20) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_1) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_20) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_20) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_1) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_20) %3 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_20) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_1) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_20) %4 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_20) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_23) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_27) %0 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_26) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_25) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_26) %17 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_4) %21 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %22, %20 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %23 = qco.rz(%cst_23) %qubit1_out : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_26) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_22) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_14) %qubit0_out : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_20) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_3) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rx(%cst_20) %28 : !qco.qubit -> !qco.qubit
    %qubit0_out_28, %qubit1_out_29 = qco.iswap %29, %25 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %30 = qco.rz(%cst_12) %qubit1_out_29 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_20) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_2) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_20) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_0) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_26) %qubit0_out_28 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_26) %34 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_9) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rx(%cst_26) %14 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_24) %38 : !qco.qubit -> !qco.qubit
    %qubit0_out_30, %qubit1_out_31 = qco.iswap %39, %37 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %40 = qco.rz(%cst_23) %qubit1_out_31 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_26) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_22) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_8) %qubit0_out_30 : !qco.qubit -> !qco.qubit
    %44 = qco.rx(%cst_20) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_7) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst_20) %45 : !qco.qubit -> !qco.qubit
    %qubit0_out_32, %qubit1_out_33 = qco.iswap %46, %42 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %47 = qco.rz(%cst_6) %qubit1_out_33 : !qco.qubit -> !qco.qubit
    %48 = qco.rx(%cst_20) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_5) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_20) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_10) %qubit0_out_32 : !qco.qubit -> !qco.qubit
    %53 = qco.rx(%cst_26) %51 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_25) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rx(%cst_26) %11 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_24) %55 : !qco.qubit -> !qco.qubit
    %qubit0_out_34, %qubit1_out_35 = qco.iswap %56, %54 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %57 = qco.rz(%cst_23) %qubit1_out_35 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_26) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_22) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_14) %qubit0_out_34 : !qco.qubit -> !qco.qubit
    %61 = qco.rx(%cst_20) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_13) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rx(%cst_20) %62 : !qco.qubit -> !qco.qubit
    %qubit0_out_36, %qubit1_out_37 = qco.iswap %63, %59 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %64 = qco.rz(%cst_12) %qubit1_out_37 : !qco.qubit -> !qco.qubit
    %65 = qco.rx(%cst_20) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_11) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rx(%cst_20) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_15) %qubit0_out_36 : !qco.qubit -> !qco.qubit
    %70 = qco.rx(%cst_26) %68 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_25) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rx(%cst_26) %8 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_24) %72 : !qco.qubit -> !qco.qubit
    %qubit0_out_38, %qubit1_out_39 = qco.iswap %73, %71 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %74 = qco.rz(%cst_23) %qubit1_out_39 : !qco.qubit -> !qco.qubit
    %75 = qco.rx(%cst_26) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_22) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_21) %qubit0_out_38 : !qco.qubit -> !qco.qubit
    %78 = qco.rx(%cst_20) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_19) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rx(%cst_20) %79 : !qco.qubit -> !qco.qubit
    %qubit0_out_40, %qubit1_out_41 = qco.iswap %80, %76 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %81 = qco.rz(%cst_18) %qubit1_out_41 : !qco.qubit -> !qco.qubit
    %82 = qco.rx(%cst_20) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_17) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rx(%cst_20) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_16) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_15) %qubit0_out_40 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %85 : !qco.qubit
    cbit.store %result, %5[%c0] : !cbit.reg<5>
    %qubit_out_42, %result_43 = qco.measure %86 : !qco.qubit
    cbit.store %result_43, %5[%c1] : !cbit.reg<5>
    %qubit_out_44, %result_45 = qco.measure %69 : !qco.qubit
    cbit.store %result_45, %5[%c2] : !cbit.reg<5>
    %qubit_out_46, %result_47 = qco.measure %52 : !qco.qubit
    cbit.store %result_47, %5[%c3] : !cbit.reg<5>
    qco.sink %qubit_out_42 : !qco.qubit
    qco.sink %qubit_out_44 : !qco.qubit
    qco.sink %qubit_out_46 : !qco.qubit
    %qubit_out_48, %result_49 = qco.measure %35 : !qco.qubit
    qco.sink %qubit_out_48 : !qco.qubit
    cbit.store %result_49, %5[%c4] : !cbit.reg<5>
    qco.sink %qubit_out : !qco.qubit
    qco.gphase(%cst_26)
    return %5 : !cbit.reg<5>
  }
}
