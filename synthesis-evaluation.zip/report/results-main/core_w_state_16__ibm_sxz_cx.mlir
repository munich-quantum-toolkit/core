module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<16> attributes {mqt.entry_point} {
    %cst = arith.constant 3.1415926535897927 : f64
    %cst_0 = arith.constant -1.3181160716528177 : f64
    %cst_1 = arith.constant 5.9207922990387614 : f64
    %cst_2 = arith.constant -3.503985661730618 : f64
    %cst_3 = arith.constant -2.8889123984477152 : f64
    %cst_4 = arith.constant -3.1415926535897927 : f64
    %cst_5 = arith.constant -1.5707963267948977 : f64
    %cst_6 = arith.constant -1.3096389158918726 : f64
    %cst_7 = arith.constant 3.4027500644928175 : f64
    %cst_8 = arith.constant -3.1415926535897936 : f64
    %cst_9 = arith.constant -3.1415926535897949 : f64
    %cst_10 = arith.constant -1.5707963267948981 : f64
    %cst_11 = arith.constant -1.3002465638163239 : f64
    %cst_12 = arith.constant 3.4121424165683663 : f64
    %cst_13 = arith.constant -3.1415926535897918 : f64
    %cst_14 = arith.constant -1.2897614252920833 : f64
    %cst_15 = arith.constant -2.8605577520869794 : f64
    %cst_16 = arith.constant -1.1102230246251565E-15 : f64
    %cst_17 = arith.constant -1.5707963267948979 : f64
    %cst_18 = arith.constant -3.141592653589794 : f64
    %cst_19 = arith.constant -1.277953555066321 : f64
    %cst_20 = arith.constant -2.8487498818612176 : f64
    %cst_21 = arith.constant 7.8539816339744819 : f64
    %cst_22 = arith.constant -3.5527136788005009E-15 : f64
    %cst_23 = arith.constant -1.2645189576252265 : f64
    %cst_24 = arith.constant -2.8353152844201235 : f64
    %cst_25 = arith.constant -1.9984014443252818E-15 : f64
    %cst_26 = arith.constant -1.5707963267948952 : f64
    %cst_27 = arith.constant -1.249045772398254 : f64
    %cst_28 = arith.constant -2.819842099193151 : f64
    %cst_29 = arith.constant -3.1415926535897922 : f64
    %cst_30 = arith.constant 7.8539816339744828 : f64
    %cst_31 = arith.constant -2.2204460492503131E-15 : f64
    %cst_32 = arith.constant -1.2309594173407743 : f64
    %cst_33 = arith.constant -2.8017557441356722 : f64
    %cst_34 = arith.constant -3.1415926535897944 : f64
    %cst_35 = arith.constant -1.7763568394002505E-15 : f64
    %cst_36 = arith.constant -1.5707963267948939 : f64
    %cst_37 = arith.constant -1.2094292028881886 : f64
    %cst_38 = arith.constant -2.7802255296830856 : f64
    %cst_39 = arith.constant -3.1415926535897913 : f64
    %cst_40 = arith.constant -2.6645352591003757E-15 : f64
    %cst_41 = arith.constant -1.5707963267948959 : f64
    %cst_42 = arith.constant -1.5707963267948988 : f64
    %cst_43 = arith.constant -1.183199640139716 : f64
    %cst_44 = arith.constant -1.1831996401397165 : f64
    %cst_45 = arith.constant 4.7123889803846888 : f64
    %cst_46 = arith.constant -1.570796326794895 : f64
    %cst_47 = arith.constant -3.3306690738754696E-15 : f64
    %cst_48 = arith.constant -1.570796326794897 : f64
    %cst_49 = arith.constant -1.1502619915109311 : f64
    %cst_50 = arith.constant -1.1502619915109316 : f64
    %cst_51 = arith.constant -1.5707963267948941 : f64
    %cst_52 = arith.constant -1.5707963267948963 : f64
    %cst_53 = arith.constant -1.1071487177940909 : f64
    %cst_54 = arith.constant 3.6052402625905993 : f64
    %cst_55 = arith.constant 6.2831853071795862 : f64
    %cst_56 = arith.constant -1.5707963267948961 : f64
    %cst_57 = arith.constant -4.7123889803846915 : f64
    %cst_58 = arith.constant -1.0471975511965979 : f64
    %cst_59 = arith.constant -2.6179938779914949 : f64
    %cst_60 = arith.constant -1.5707963267948957 : f64
    %cst_61 = arith.constant 4.7123889803846897 : f64
    %cst_62 = arith.constant 4.7123889803846879 : f64
    %cst_63 = arith.constant -0.95531661812450918 : f64
    %cst_64 = arith.constant 2.5261129449194057 : f64
    %cst_65 = arith.constant 3.1415926535897931 : f64
    %cst_66 = arith.constant 3.1415926535897936 : f64
    %cst_67 = arith.constant 1.570796326794897 : f64
    %cst_68 = arith.constant -6.2831853071795862 : f64
    %cst_69 = arith.constant -3.1415926535897931 : f64
    %cst_70 = arith.constant -0.78539816339744872 : f64
    %cst_71 = arith.constant 1.5707963267948966 : f64
    %cst_72 = arith.constant -1.5707963267948966 : f64
    %cst_73 = arith.constant 7.0685834705770345 : f64
    %cst_74 = arith.constant 4.7123889803846906 : f64
    %cst_75 = arith.constant 1.5707963267948974 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %c15 = arith.constant 15 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<16>
    %17 = qco.x %0 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_4) %1 : !qco.qubit -> !qco.qubit
    %19 = qco.sx %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_3) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_2) %17 : !qco.qubit -> !qco.qubit
    %22 = qco.x %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_1) %22 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%23) targets (%arg0 = %20) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.rz(%cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %25 = qco.sx %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_18) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_68) %controls_out : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_71) %28 : !qco.qubit -> !qco.qubit
    %controls_out_76, %targets_out_77 = qco.ctrl(%29) targets (%arg0 = %26) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.rz(%cst_17) %targets_out_77 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_72) %controls_out_76 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_16) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_8) %2 : !qco.qubit -> !qco.qubit
    %37 = qco.sx %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_7) %37 : !qco.qubit -> !qco.qubit
    %controls_out_78, %targets_out_79 = qco.ctrl(%32) targets (%arg0 = %38) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.rz(%cst_6) %targets_out_79 : !qco.qubit -> !qco.qubit
    %40 = qco.sx %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_69) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_68) %controls_out_78 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_71) %43 : !qco.qubit -> !qco.qubit
    %controls_out_80, %targets_out_81 = qco.ctrl(%44) targets (%arg0 = %41) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.rz(%cst_5) %targets_out_81 : !qco.qubit -> !qco.qubit
    %46 = qco.sx %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_60) %controls_out_80 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_18) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_13) %3 : !qco.qubit -> !qco.qubit
    %51 = qco.sx %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_12) %51 : !qco.qubit -> !qco.qubit
    %controls_out_82, %targets_out_83 = qco.ctrl(%46) targets (%arg0 = %52) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %53 = qco.rz(%cst_11) %targets_out_83 : !qco.qubit -> !qco.qubit
    %54 = qco.sx %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_18) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_68) %controls_out_82 : !qco.qubit -> !qco.qubit
    %57 = qco.sx %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_71) %57 : !qco.qubit -> !qco.qubit
    %controls_out_84, %targets_out_85 = qco.ctrl(%58) targets (%arg0 = %55) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %59 = qco.rz(%cst_10) %targets_out_85 : !qco.qubit -> !qco.qubit
    %60 = qco.sx %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_72) %controls_out_84 : !qco.qubit -> !qco.qubit
    %62 = qco.sx %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_9) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_69) %4 : !qco.qubit -> !qco.qubit
    %65 = qco.sx %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_15) %65 : !qco.qubit -> !qco.qubit
    %controls_out_86, %targets_out_87 = qco.ctrl(%60) targets (%arg0 = %66) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %67 = qco.rz(%cst_14) %targets_out_87 : !qco.qubit -> !qco.qubit
    %68 = qco.sx %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_69) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_68) %controls_out_86 : !qco.qubit -> !qco.qubit
    %71 = qco.sx %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_71) %71 : !qco.qubit -> !qco.qubit
    %controls_out_88, %targets_out_89 = qco.ctrl(%72) targets (%arg0 = %69) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %73 = qco.rz(%cst_72) %targets_out_89 : !qco.qubit -> !qco.qubit
    %74 = qco.sx %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_69) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_48) %controls_out_88 : !qco.qubit -> !qco.qubit
    %77 = qco.sx %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_69) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_39) %5 : !qco.qubit -> !qco.qubit
    %80 = qco.sx %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_20) %80 : !qco.qubit -> !qco.qubit
    %controls_out_90, %targets_out_91 = qco.ctrl(%75) targets (%arg0 = %81) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %82 = qco.rz(%cst_19) %targets_out_91 : !qco.qubit -> !qco.qubit
    %83 = qco.sx %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_18) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_68) %controls_out_90 : !qco.qubit -> !qco.qubit
    %86 = qco.sx %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_71) %86 : !qco.qubit -> !qco.qubit
    %controls_out_92, %targets_out_93 = qco.ctrl(%87) targets (%arg0 = %84) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %88 = qco.rz(%cst_17) %targets_out_93 : !qco.qubit -> !qco.qubit
    %89 = qco.sx %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_16) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_60) %controls_out_92 : !qco.qubit -> !qco.qubit
    %92 = qco.sx %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_25) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_39) %6 : !qco.qubit -> !qco.qubit
    %95 = qco.sx %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_24) %95 : !qco.qubit -> !qco.qubit
    %controls_out_94, %targets_out_95 = qco.ctrl(%90) targets (%arg0 = %96) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %97 = qco.rz(%cst_23) %targets_out_95 : !qco.qubit -> !qco.qubit
    %98 = qco.sx %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_69) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_68) %controls_out_94 : !qco.qubit -> !qco.qubit
    %101 = qco.sx %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_71) %101 : !qco.qubit -> !qco.qubit
    %controls_out_96, %targets_out_97 = qco.ctrl(%102) targets (%arg0 = %99) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %103 = qco.rz(%cst_22) %targets_out_97 : !qco.qubit -> !qco.qubit
    %104 = qco.sx %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst_45) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.sx %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rz(%cst_21) %106 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_56) %controls_out_96 : !qco.qubit -> !qco.qubit
    %109 = qco.sx %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst_40) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_29) %7 : !qco.qubit -> !qco.qubit
    %112 = qco.sx %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_28) %112 : !qco.qubit -> !qco.qubit
    %controls_out_98, %targets_out_99 = qco.ctrl(%107) targets (%arg0 = %113) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %114 = qco.rz(%cst_27) %targets_out_99 : !qco.qubit -> !qco.qubit
    %115 = qco.sx %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst_69) %115 : !qco.qubit -> !qco.qubit
    %117 = qco.rz(%cst_68) %controls_out_98 : !qco.qubit -> !qco.qubit
    %118 = qco.sx %117 : !qco.qubit -> !qco.qubit
    %119 = qco.rz(%cst_71) %118 : !qco.qubit -> !qco.qubit
    %controls_out_100, %targets_out_101 = qco.ctrl(%119) targets (%arg0 = %116) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %120 = qco.rz(%cst_26) %targets_out_101 : !qco.qubit -> !qco.qubit
    %121 = qco.sx %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rz(%cst_56) %controls_out_100 : !qco.qubit -> !qco.qubit
    %123 = qco.sx %122 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_25) %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rz(%cst_34) %8 : !qco.qubit -> !qco.qubit
    %126 = qco.sx %125 : !qco.qubit -> !qco.qubit
    %127 = qco.rz(%cst_33) %126 : !qco.qubit -> !qco.qubit
    %controls_out_102, %targets_out_103 = qco.ctrl(%121) targets (%arg0 = %127) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %128 = qco.rz(%cst_32) %targets_out_103 : !qco.qubit -> !qco.qubit
    %129 = qco.sx %128 : !qco.qubit -> !qco.qubit
    %130 = qco.rz(%cst_69) %129 : !qco.qubit -> !qco.qubit
    %131 = qco.rz(%cst_68) %controls_out_102 : !qco.qubit -> !qco.qubit
    %132 = qco.sx %131 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst_71) %132 : !qco.qubit -> !qco.qubit
    %controls_out_104, %targets_out_105 = qco.ctrl(%133) targets (%arg0 = %130) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %134 = qco.rz(%cst_31) %targets_out_105 : !qco.qubit -> !qco.qubit
    %135 = qco.sx %134 : !qco.qubit -> !qco.qubit
    %136 = qco.rz(%cst_45) %135 : !qco.qubit -> !qco.qubit
    %137 = qco.sx %136 : !qco.qubit -> !qco.qubit
    %138 = qco.rz(%cst_30) %137 : !qco.qubit -> !qco.qubit
    %139 = qco.rz(%cst_41) %controls_out_104 : !qco.qubit -> !qco.qubit
    %140 = qco.sx %139 : !qco.qubit -> !qco.qubit
    %141 = qco.rz(%cst_39) %9 : !qco.qubit -> !qco.qubit
    %142 = qco.sx %141 : !qco.qubit -> !qco.qubit
    %143 = qco.rz(%cst_38) %142 : !qco.qubit -> !qco.qubit
    %controls_out_106, %targets_out_107 = qco.ctrl(%138) targets (%arg0 = %143) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %144 = qco.rz(%cst_37) %targets_out_107 : !qco.qubit -> !qco.qubit
    %145 = qco.sx %144 : !qco.qubit -> !qco.qubit
    %146 = qco.rz(%cst_69) %145 : !qco.qubit -> !qco.qubit
    %147 = qco.rz(%cst_68) %controls_out_106 : !qco.qubit -> !qco.qubit
    %148 = qco.sx %147 : !qco.qubit -> !qco.qubit
    %149 = qco.rz(%cst_71) %148 : !qco.qubit -> !qco.qubit
    %controls_out_108, %targets_out_109 = qco.ctrl(%149) targets (%arg0 = %146) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %150 = qco.rz(%cst_36) %targets_out_109 : !qco.qubit -> !qco.qubit
    %151 = qco.sx %150 : !qco.qubit -> !qco.qubit
    %152 = qco.rz(%cst_55) %151 : !qco.qubit -> !qco.qubit
    %153 = qco.rz(%cst_52) %controls_out_108 : !qco.qubit -> !qco.qubit
    %154 = qco.sx %153 : !qco.qubit -> !qco.qubit
    %155 = qco.rz(%cst_35) %154 : !qco.qubit -> !qco.qubit
    %156 = qco.rz(%cst_46) %10 : !qco.qubit -> !qco.qubit
    %157 = qco.sx %156 : !qco.qubit -> !qco.qubit
    %158 = qco.rz(%cst_45) %157 : !qco.qubit -> !qco.qubit
    %159 = qco.sx %158 : !qco.qubit -> !qco.qubit
    %160 = qco.rz(%cst_44) %159 : !qco.qubit -> !qco.qubit
    %controls_out_110, %targets_out_111 = qco.ctrl(%152) targets (%arg0 = %160) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %161 = qco.rz(%cst_43) %targets_out_111 : !qco.qubit -> !qco.qubit
    %162 = qco.sx %161 : !qco.qubit -> !qco.qubit
    %163 = qco.rz(%cst_69) %162 : !qco.qubit -> !qco.qubit
    %164 = qco.rz(%cst_68) %controls_out_110 : !qco.qubit -> !qco.qubit
    %165 = qco.sx %164 : !qco.qubit -> !qco.qubit
    %166 = qco.rz(%cst_71) %165 : !qco.qubit -> !qco.qubit
    %controls_out_112, %targets_out_113 = qco.ctrl(%166) targets (%arg0 = %163) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %167 = qco.rz(%cst_42) %targets_out_113 : !qco.qubit -> !qco.qubit
    %168 = qco.sx %167 : !qco.qubit -> !qco.qubit
    %169 = qco.rz(%cst_41) %controls_out_112 : !qco.qubit -> !qco.qubit
    %170 = qco.sx %169 : !qco.qubit -> !qco.qubit
    %171 = qco.rz(%cst_40) %170 : !qco.qubit -> !qco.qubit
    %172 = qco.rz(%cst_51) %11 : !qco.qubit -> !qco.qubit
    %173 = qco.sx %172 : !qco.qubit -> !qco.qubit
    %174 = qco.rz(%cst_62) %173 : !qco.qubit -> !qco.qubit
    %175 = qco.sx %174 : !qco.qubit -> !qco.qubit
    %176 = qco.rz(%cst_50) %175 : !qco.qubit -> !qco.qubit
    %controls_out_114, %targets_out_115 = qco.ctrl(%168) targets (%arg0 = %176) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %177 = qco.rz(%cst_49) %targets_out_115 : !qco.qubit -> !qco.qubit
    %178 = qco.sx %177 : !qco.qubit -> !qco.qubit
    %179 = qco.rz(%cst_69) %178 : !qco.qubit -> !qco.qubit
    %180 = qco.rz(%cst_68) %controls_out_114 : !qco.qubit -> !qco.qubit
    %181 = qco.sx %180 : !qco.qubit -> !qco.qubit
    %182 = qco.rz(%cst_71) %181 : !qco.qubit -> !qco.qubit
    %controls_out_116, %targets_out_117 = qco.ctrl(%182) targets (%arg0 = %179) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %183 = qco.rz(%cst_48) %targets_out_117 : !qco.qubit -> !qco.qubit
    %184 = qco.sx %183 : !qco.qubit -> !qco.qubit
    %185 = qco.rz(%cst_69) %184 : !qco.qubit -> !qco.qubit
    %186 = qco.rz(%cst_52) %controls_out_116 : !qco.qubit -> !qco.qubit
    %187 = qco.sx %186 : !qco.qubit -> !qco.qubit
    %188 = qco.rz(%cst_47) %187 : !qco.qubit -> !qco.qubit
    %189 = qco.rz(%cst_69) %12 : !qco.qubit -> !qco.qubit
    %190 = qco.sx %189 : !qco.qubit -> !qco.qubit
    %191 = qco.rz(%cst_54) %190 : !qco.qubit -> !qco.qubit
    %controls_out_118, %targets_out_119 = qco.ctrl(%185) targets (%arg0 = %191) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %192 = qco.rz(%cst_53) %targets_out_119 : !qco.qubit -> !qco.qubit
    %193 = qco.sx %192 : !qco.qubit -> !qco.qubit
    %194 = qco.rz(%cst_69) %193 : !qco.qubit -> !qco.qubit
    %195 = qco.rz(%cst_68) %controls_out_118 : !qco.qubit -> !qco.qubit
    %196 = qco.sx %195 : !qco.qubit -> !qco.qubit
    %197 = qco.rz(%cst_71) %196 : !qco.qubit -> !qco.qubit
    %controls_out_120, %targets_out_121 = qco.ctrl(%197) targets (%arg0 = %194) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %198 = qco.rz(%cst_52) %targets_out_121 : !qco.qubit -> !qco.qubit
    %199 = qco.sx %198 : !qco.qubit -> !qco.qubit
    %200 = qco.rz(%cst_65) %199 : !qco.qubit -> !qco.qubit
    %201 = qco.rz(%cst_56) %controls_out_120 : !qco.qubit -> !qco.qubit
    %202 = qco.sx %201 : !qco.qubit -> !qco.qubit
    %203 = qco.rz(%cst_69) %202 : !qco.qubit -> !qco.qubit
    %204 = qco.rz(%cst_69) %13 : !qco.qubit -> !qco.qubit
    %205 = qco.sx %204 : !qco.qubit -> !qco.qubit
    %206 = qco.rz(%cst_59) %205 : !qco.qubit -> !qco.qubit
    %controls_out_122, %targets_out_123 = qco.ctrl(%200) targets (%arg0 = %206) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %207 = qco.rz(%cst_58) %targets_out_123 : !qco.qubit -> !qco.qubit
    %208 = qco.sx %207 : !qco.qubit -> !qco.qubit
    %209 = qco.rz(%cst_69) %208 : !qco.qubit -> !qco.qubit
    %210 = qco.rz(%cst_68) %controls_out_122 : !qco.qubit -> !qco.qubit
    %211 = qco.sx %210 : !qco.qubit -> !qco.qubit
    %212 = qco.rz(%cst_71) %211 : !qco.qubit -> !qco.qubit
    %controls_out_124, %targets_out_125 = qco.ctrl(%212) targets (%arg0 = %209) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %213 = qco.rz(%cst_57) %targets_out_125 : !qco.qubit -> !qco.qubit
    %214 = qco.sx %213 : !qco.qubit -> !qco.qubit
    %215 = qco.rz(%cst_56) %controls_out_124 : !qco.qubit -> !qco.qubit
    %216 = qco.sx %215 : !qco.qubit -> !qco.qubit
    %217 = qco.rz(%cst_55) %216 : !qco.qubit -> !qco.qubit
    %218 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %219 = qco.rz(%cst_64) %218 : !qco.qubit -> !qco.qubit
    %controls_out_126, %targets_out_127 = qco.ctrl(%214) targets (%arg0 = %219) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %220 = qco.rz(%cst_63) %targets_out_127 : !qco.qubit -> !qco.qubit
    %221 = qco.sx %220 : !qco.qubit -> !qco.qubit
    %222 = qco.rz(%cst_69) %221 : !qco.qubit -> !qco.qubit
    %223 = qco.rz(%cst_68) %controls_out_126 : !qco.qubit -> !qco.qubit
    %224 = qco.sx %223 : !qco.qubit -> !qco.qubit
    %225 = qco.rz(%cst_71) %224 : !qco.qubit -> !qco.qubit
    %controls_out_128, %targets_out_129 = qco.ctrl(%225) targets (%arg0 = %222) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %226 = qco.sx %targets_out_129 : !qco.qubit -> !qco.qubit
    %227 = qco.rz(%cst_62) %226 : !qco.qubit -> !qco.qubit
    %228 = qco.sx %227 : !qco.qubit -> !qco.qubit
    %229 = qco.rz(%cst_61) %228 : !qco.qubit -> !qco.qubit
    %230 = qco.rz(%cst_60) %controls_out_128 : !qco.qubit -> !qco.qubit
    %231 = qco.sx %230 : !qco.qubit -> !qco.qubit
    %232 = qco.rz(%cst_65) %231 : !qco.qubit -> !qco.qubit
    %233 = qco.rz(%cst_75) %15 : !qco.qubit -> !qco.qubit
    %234 = qco.sx %233 : !qco.qubit -> !qco.qubit
    %235 = qco.rz(%cst_74) %234 : !qco.qubit -> !qco.qubit
    %236 = qco.sx %235 : !qco.qubit -> !qco.qubit
    %237 = qco.rz(%cst_73) %236 : !qco.qubit -> !qco.qubit
    %controls_out_130, %targets_out_131 = qco.ctrl(%229) targets (%arg0 = %237) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %238 = qco.rz(%cst_70) %targets_out_131 : !qco.qubit -> !qco.qubit
    %239 = qco.sx %238 : !qco.qubit -> !qco.qubit
    %240 = qco.rz(%cst_69) %239 : !qco.qubit -> !qco.qubit
    %241 = qco.rz(%cst_68) %controls_out_130 : !qco.qubit -> !qco.qubit
    %242 = qco.sx %241 : !qco.qubit -> !qco.qubit
    %243 = qco.rz(%cst_71) %242 : !qco.qubit -> !qco.qubit
    %controls_out_132, %targets_out_133 = qco.ctrl(%243) targets (%arg0 = %240) {
      %250 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %250 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %244 = qco.rz(%cst_67) %targets_out_133 : !qco.qubit -> !qco.qubit
    %245 = qco.sx %244 : !qco.qubit -> !qco.qubit
    %246 = qco.rz(%cst_66) %245 : !qco.qubit -> !qco.qubit
    %247 = qco.rz(%cst_75) %controls_out_132 : !qco.qubit -> !qco.qubit
    %248 = qco.sx %247 : !qco.qubit -> !qco.qubit
    %249 = qco.rz(%cst_65) %248 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %35 : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<16>
    %qubit_out_134, %result_135 = qco.measure %49 : !qco.qubit
    cbit.store %result_135, %16[%c1] : !cbit.reg<16>
    %qubit_out_136, %result_137 = qco.measure %63 : !qco.qubit
    cbit.store %result_137, %16[%c2] : !cbit.reg<16>
    %qubit_out_138, %result_139 = qco.measure %78 : !qco.qubit
    cbit.store %result_139, %16[%c3] : !cbit.reg<16>
    %qubit_out_140, %result_141 = qco.measure %93 : !qco.qubit
    cbit.store %result_141, %16[%c4] : !cbit.reg<16>
    %qubit_out_142, %result_143 = qco.measure %110 : !qco.qubit
    cbit.store %result_143, %16[%c5] : !cbit.reg<16>
    %qubit_out_144, %result_145 = qco.measure %124 : !qco.qubit
    cbit.store %result_145, %16[%c6] : !cbit.reg<16>
    %qubit_out_146, %result_147 = qco.measure %140 : !qco.qubit
    cbit.store %result_147, %16[%c7] : !cbit.reg<16>
    %qubit_out_148, %result_149 = qco.measure %155 : !qco.qubit
    cbit.store %result_149, %16[%c8] : !cbit.reg<16>
    %qubit_out_150, %result_151 = qco.measure %171 : !qco.qubit
    cbit.store %result_151, %16[%c9] : !cbit.reg<16>
    %qubit_out_152, %result_153 = qco.measure %188 : !qco.qubit
    cbit.store %result_153, %16[%c10] : !cbit.reg<16>
    %qubit_out_154, %result_155 = qco.measure %203 : !qco.qubit
    cbit.store %result_155, %16[%c11] : !cbit.reg<16>
    %qubit_out_156, %result_157 = qco.measure %217 : !qco.qubit
    cbit.store %result_157, %16[%c12] : !cbit.reg<16>
    %qubit_out_158, %result_159 = qco.measure %232 : !qco.qubit
    cbit.store %result_159, %16[%c13] : !cbit.reg<16>
    %qubit_out_160, %result_161 = qco.measure %249 : !qco.qubit
    cbit.store %result_161, %16[%c14] : !cbit.reg<16>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_134 : !qco.qubit
    qco.sink %qubit_out_136 : !qco.qubit
    qco.sink %qubit_out_138 : !qco.qubit
    qco.sink %qubit_out_140 : !qco.qubit
    qco.sink %qubit_out_142 : !qco.qubit
    qco.sink %qubit_out_144 : !qco.qubit
    qco.sink %qubit_out_146 : !qco.qubit
    qco.sink %qubit_out_148 : !qco.qubit
    qco.sink %qubit_out_150 : !qco.qubit
    qco.sink %qubit_out_152 : !qco.qubit
    qco.sink %qubit_out_154 : !qco.qubit
    qco.sink %qubit_out_156 : !qco.qubit
    qco.sink %qubit_out_158 : !qco.qubit
    qco.sink %qubit_out_160 : !qco.qubit
    %qubit_out_162, %result_163 = qco.measure %246 : !qco.qubit
    qco.sink %qubit_out_162 : !qco.qubit
    cbit.store %result_163, %16[%c15] : !cbit.reg<16>
    %cst_164 = arith.constant -3.1415926535897638 : f64
    qco.gphase(%cst_164)
    return %16 : !cbit.reg<16>
  }
}
