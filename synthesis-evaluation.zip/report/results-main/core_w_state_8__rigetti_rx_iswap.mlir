module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant 3.2133908767650441 : f64
    %cst_0 = arith.constant 3.1415926535897962 : f64
    %cst_1 = arith.constant 3.0697944304145421 : f64
    %cst_2 = arith.constant 5.0737561042913972 : f64
    %cst_3 = arith.constant 9.4247779607693793 : f64
    %cst_4 = arith.constant 1.9321634507016037 : f64
    %cst_5 = arith.constant -1.5707963267948997 : f64
    %cst_6 = arith.constant -1.5707963267948979 : f64
    %cst_7 = arith.constant 3.1415926535897958 : f64
    %cst_8 = arith.constant 1.5707963267948963 : f64
    %cst_9 = arith.constant 5.0999856670398707 : f64
    %cst_10 = arith.constant 3.5291893402449737 : f64
    %cst_11 = arith.constant 4.7123889803846879 : f64
    %cst_12 = arith.constant 4.7123889803846932 : f64
    %cst_13 = arith.constant 2.892468459132826 : f64
    %cst_14 = arith.constant -0.24912419445696715 : f64
    %cst_15 = arith.constant 5.1329233156686547 : f64
    %cst_16 = arith.constant 4.7123889803846906 : f64
    %cst_17 = arith.constant 1.991330662078862 : f64
    %cst_18 = arith.constant 7.8539816339744828 : f64
    %cst_19 = arith.constant -1.5707963267948961 : f64
    %cst_20 = arith.constant 6.2831853071795862 : f64
    %cst_21 = arith.constant 5.1760365893854958 : f64
    %cst_22 = arith.constant 2.0344439357957023 : f64
    %cst_23 = arith.constant 7.8539816339744819 : f64
    %cst_24 = arith.constant -1.5707963267948957 : f64
    %cst_25 = arith.constant 3.1415926535897936 : f64
    %cst_26 = arith.constant 5.2359877559829879 : f64
    %cst_27 = arith.constant 2.0943951023931953 : f64
    %cst_28 = arith.constant 3.1415926535897949 : f64
    %cst_29 = arith.constant 1.5707963267948968 : f64
    %cst_30 = arith.constant 0.88369178103153434 : f64
    %cst_31 = arith.constant -2.2579008725582588 : f64
    %cst_32 = arith.constant 5.3278686890550766 : f64
    %cst_33 = arith.constant 3.1415926535897927 : f64
    %cst_34 = arith.constant 0.95531661812450896 : f64
    %cst_35 = arith.constant 1.5707963267948961 : f64
    %cst_36 = arith.constant 4.7123889803846897 : f64
    %cst_37 = arith.constant -1.5707963267948963 : f64
    %cst_38 = arith.constant -1.5707963267948966 : f64
    %cst_39 = arith.constant -3.1415926535897931 : f64
    %cst_40 = arith.constant 5.497787143782138 : f64
    %cst_41 = arith.constant 3.1415926535897931 : f64
    %cst_42 = arith.constant 3.9269908169872414 : f64
    %cst_43 = arith.constant 1.5707963267948966 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %9 = qco.rx(%cst_41) %0 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_41) %1 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_43) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_4) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_43) %9 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_16) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_43) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_3) %15 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %16, %12 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %17 = qco.rz(%cst_41) %qubit1_out : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_43) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_2) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_43) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_8) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_39) %qubit0_out : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_43) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_38) %23 : !qco.qubit -> !qco.qubit
    %qubit0_out_44, %qubit1_out_45 = qco.iswap %24, %21 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %25 = qco.rz(%cst_1) %qubit1_out_45 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_43) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_0) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_43) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_36) %qubit0_out_44 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_43) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_35) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_12) %2 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_43) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_11) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_43) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_10) %36 : !qco.qubit -> !qco.qubit
    %qubit0_out_46, %qubit1_out_47 = qco.iswap %29, %37 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %38 = qco.rz(%cst_41) %qubit1_out_47 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_43) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_9) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_43) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_8) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_39) %qubit0_out_46 : !qco.qubit -> !qco.qubit
    %44 = qco.rx(%cst_43) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_38) %44 : !qco.qubit -> !qco.qubit
    %qubit0_out_48, %qubit1_out_49 = qco.iswap %45, %42 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %46 = qco.rz(%cst_41) %qubit1_out_49 : !qco.qubit -> !qco.qubit
    %47 = qco.rx(%cst_43) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_7) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_43) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_41) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_6) %qubit0_out_48 : !qco.qubit -> !qco.qubit
    %52 = qco.rx(%cst_43) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_5) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_41) %3 : !qco.qubit -> !qco.qubit
    %55 = qco.rx(%cst_43) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_17) %55 : !qco.qubit -> !qco.qubit
    %qubit0_out_50, %qubit1_out_51 = qco.iswap %50, %56 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %57 = qco.rz(%cst_41) %qubit1_out_51 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_43) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_15) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rx(%cst_43) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_43) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_39) %qubit0_out_50 : !qco.qubit -> !qco.qubit
    %63 = qco.rx(%cst_43) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_38) %63 : !qco.qubit -> !qco.qubit
    %qubit0_out_52, %qubit1_out_53 = qco.iswap %64, %61 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %65 = qco.rz(%cst_14) %qubit1_out_53 : !qco.qubit -> !qco.qubit
    %66 = qco.rx(%cst_41) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_13) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_38) %qubit0_out_52 : !qco.qubit -> !qco.qubit
    %69 = qco.rx(%cst_43) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_18) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_28) %4 : !qco.qubit -> !qco.qubit
    %72 = qco.rx(%cst_43) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_22) %72 : !qco.qubit -> !qco.qubit
    %qubit0_out_54, %qubit1_out_55 = qco.iswap %67, %73 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %74 = qco.rz(%cst_41) %qubit1_out_55 : !qco.qubit -> !qco.qubit
    %75 = qco.rx(%cst_43) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_21) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rx(%cst_43) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_43) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_39) %qubit0_out_54 : !qco.qubit -> !qco.qubit
    %80 = qco.rx(%cst_43) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_38) %80 : !qco.qubit -> !qco.qubit
    %qubit0_out_56, %qubit1_out_57 = qco.iswap %81, %78 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %82 = qco.rz(%cst_41) %qubit1_out_57 : !qco.qubit -> !qco.qubit
    %83 = qco.rx(%cst_41) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_20) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_19) %qubit0_out_56 : !qco.qubit -> !qco.qubit
    %86 = qco.rx(%cst_43) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_18) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_28) %5 : !qco.qubit -> !qco.qubit
    %89 = qco.rx(%cst_43) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_27) %89 : !qco.qubit -> !qco.qubit
    %qubit0_out_58, %qubit1_out_59 = qco.iswap %84, %90 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %91 = qco.rz(%cst_41) %qubit1_out_59 : !qco.qubit -> !qco.qubit
    %92 = qco.rx(%cst_43) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_26) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rx(%cst_43) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_43) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_39) %qubit0_out_58 : !qco.qubit -> !qco.qubit
    %97 = qco.rx(%cst_43) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_38) %97 : !qco.qubit -> !qco.qubit
    %qubit0_out_60, %qubit1_out_61 = qco.iswap %98, %95 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %99 = qco.rz(%cst_39) %qubit1_out_61 : !qco.qubit -> !qco.qubit
    %100 = qco.rx(%cst_41) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst_25) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_24) %qubit0_out_60 : !qco.qubit -> !qco.qubit
    %103 = qco.rx(%cst_43) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_23) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rx(%cst_43) %6 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_34) %105 : !qco.qubit -> !qco.qubit
    %qubit0_out_62, %qubit1_out_63 = qco.iswap %101, %106 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %107 = qco.rz(%cst_33) %qubit1_out_63 : !qco.qubit -> !qco.qubit
    %108 = qco.rx(%cst_43) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rz(%cst_32) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rx(%cst_43) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_35) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rz(%cst_39) %qubit0_out_62 : !qco.qubit -> !qco.qubit
    %113 = qco.rx(%cst_43) %112 : !qco.qubit -> !qco.qubit
    %114 = qco.rz(%cst_38) %113 : !qco.qubit -> !qco.qubit
    %qubit0_out_64, %qubit1_out_65 = qco.iswap %114, %111 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %115 = qco.rz(%cst_31) %qubit1_out_65 : !qco.qubit -> !qco.qubit
    %116 = qco.rx(%cst_41) %115 : !qco.qubit -> !qco.qubit
    %117 = qco.rz(%cst_30) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_38) %qubit0_out_64 : !qco.qubit -> !qco.qubit
    %119 = qco.rx(%cst_43) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.rz(%cst_29) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rx(%cst_43) %7 : !qco.qubit -> !qco.qubit
    %122 = qco.rz(%cst_42) %121 : !qco.qubit -> !qco.qubit
    %qubit0_out_66, %qubit1_out_67 = qco.iswap %117, %122 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %123 = qco.rz(%cst_41) %qubit1_out_67 : !qco.qubit -> !qco.qubit
    %124 = qco.rx(%cst_43) %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rz(%cst_40) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rx(%cst_43) %125 : !qco.qubit -> !qco.qubit
    %127 = qco.rz(%cst_43) %126 : !qco.qubit -> !qco.qubit
    %128 = qco.rz(%cst_39) %qubit0_out_66 : !qco.qubit -> !qco.qubit
    %129 = qco.rx(%cst_43) %128 : !qco.qubit -> !qco.qubit
    %130 = qco.rz(%cst_38) %129 : !qco.qubit -> !qco.qubit
    %qubit0_out_68, %qubit1_out_69 = qco.iswap %130, %127 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %131 = qco.rz(%cst_37) %qubit1_out_69 : !qco.qubit -> !qco.qubit
    %132 = qco.rx(%cst_43) %131 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst_36) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.rz(%cst_43) %qubit0_out_68 : !qco.qubit -> !qco.qubit
    %135 = qco.rx(%cst_43) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.rz(%cst_35) %135 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %32 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<8>
    %qubit_out_70, %result_71 = qco.measure %53 : !qco.qubit
    cbit.store %result_71, %8[%c1] : !cbit.reg<8>
    %qubit_out_72, %result_73 = qco.measure %70 : !qco.qubit
    cbit.store %result_73, %8[%c2] : !cbit.reg<8>
    %qubit_out_74, %result_75 = qco.measure %87 : !qco.qubit
    cbit.store %result_75, %8[%c3] : !cbit.reg<8>
    %qubit_out_76, %result_77 = qco.measure %104 : !qco.qubit
    cbit.store %result_77, %8[%c4] : !cbit.reg<8>
    %qubit_out_78, %result_79 = qco.measure %120 : !qco.qubit
    cbit.store %result_79, %8[%c5] : !cbit.reg<8>
    %qubit_out_80, %result_81 = qco.measure %136 : !qco.qubit
    cbit.store %result_81, %8[%c6] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_70 : !qco.qubit
    qco.sink %qubit_out_72 : !qco.qubit
    qco.sink %qubit_out_74 : !qco.qubit
    qco.sink %qubit_out_76 : !qco.qubit
    qco.sink %qubit_out_78 : !qco.qubit
    qco.sink %qubit_out_80 : !qco.qubit
    %qubit_out_82, %result_83 = qco.measure %133 : !qco.qubit
    qco.sink %qubit_out_82 : !qco.qubit
    cbit.store %result_83, %8[%c7] : !cbit.reg<8>
    %cst_84 = arith.constant 2.3561944901923413 : f64
    qco.gphase(%cst_84)
    return %8 : !cbit.reg<8>
  }
}
