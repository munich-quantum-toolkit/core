module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant 3.3251200321995409 : f64
    %cst_0 = arith.constant 2.8284981344907521E-15 : f64
    %cst_1 = arith.constant -4.8959163589944383 : f64
    %cst_2 = arith.constant 1.4130275891989426 : f64
    %cst_3 = arith.constant -4.8701577179806437 : f64
    %cst_4 = arith.constant 1.9321634507016041 : f64
    %cst_5 = arith.constant 1.5270913053128807 : f64
    %cst_6 = arith.constant 1.209429202888189 : f64
    %cst_7 = arith.constant 6.601577541416642 : f64
    %cst_8 = arith.constant -1.2524040925578412 : f64
    %cst_9 = arith.constant -1.1071487177940904 : f64
    %cst_10 = arith.constant -1.1071487177940902 : f64
    %cst_11 = arith.constant 1.9583930134500771 : f64
    %cst_12 = arith.constant 1.1831996401397158 : f64
    %cst_13 = arith.constant 3.141592653589794 : f64
    %cst_14 = arith.constant 0.78539816339744817 : f64
    %cst_15 = arith.constant 1.6175737211824422E-15 : f64
    %cst_16 = arith.constant -2.3561944901923448 : f64
    %cst_17 = arith.constant 5.7640391929330637 : f64
    %cst_18 = arith.constant -0.51914611424652302 : f64
    %cst_19 = arith.constant 1.9913306620788613 : f64
    %cst_20 = arith.constant 1.1502619915109311 : f64
    %cst_21 = arith.constant 6.5986182762041015 : f64
    %cst_22 = arith.constant 3.1415926535897913 : f64
    %cst_23 = arith.constant -1.2553633577703809 : f64
    %cst_24 = arith.constant -1.885028225879235 : f64
    %cst_25 = arith.constant 2.0344439357957032 : f64
    %cst_26 = arith.constant 1.1071487177940909 : f64
    %cst_27 = arith.constant 1.5707963267948954 : f64
    %cst_28 = arith.constant 3.1415926535897949 : f64
    %cst_29 = arith.constant 6.3031826411527367 : f64
    %cst_30 = arith.constant 3.1415926535897922 : f64
    %cst_31 = arith.constant -3.1215953196166426 : f64
    %cst_32 = arith.constant 2.0943951023931948 : f64
    %cst_33 = arith.constant 1.0471975511965983 : f64
    %cst_34 = arith.constant 1.570796326794897 : f64
    %cst_35 = arith.constant 2.8269801602550242 : f64
    %cst_36 = arith.constant -5.0270014737194586 : f64
    %cst_37 = arith.constant 4.7891608716544676 : f64
    %cst_38 = arith.constant 3.1415926535897905 : f64
    %cst_39 = arith.constant -1.4940244355251184 : f64
    %cst_40 = arith.constant 2.1862760354652839 : f64
    %cst_41 = arith.constant 3.1415926535897931 : f64
    %cst_42 = arith.constant 5.3278686890550775 : f64
    %cst_43 = arith.constant 1.5707963267948939 : f64
    %cst_44 = arith.constant -1.5543122344752192E-15 : f64
    %cst_45 = arith.constant -4.7123889803846897 : f64
    %cst_46 = arith.constant 6.2831853071795862 : f64
    %cst_47 = arith.constant -1.5707963267948966 : f64
    %cst_48 = arith.constant 4.7123889803846897 : f64
    %cst_49 = arith.constant 2.3561944901923444 : f64
    %cst_50 = arith.constant 1.5707963267948966 : f64
    %cst_51 = arith.constant 3.1415926535897918 : f64
    %cst_52 = arith.constant 2.3561944901923457 : f64
    %cst_53 = arith.constant 1.5707963267948974 : f64
    %cst_54 = arith.constant -6.2831853071795853 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %9 = qco.rx(%cst_41) %0 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_13) %1 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_43) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_6) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_5) %9 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_51) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_5) %14 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_50) %15, %12 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %16 = qco.rx(%cst_50) %qubit1_out : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_4) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_48) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_47) %qubit0_out : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_50) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_47) %20 : !qco.qubit -> !qco.qubit
    %qubit0_out_55, %qubit1_out_56 = qco.rzz(%cst_50) %21, %18 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %22 = qco.rx(%cst_3) %qubit1_out_56 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_51) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_2) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_1) %qubit0_out_55 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_0) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_13) %2 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_27) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_12) %29 : !qco.qubit -> !qco.qubit
    %qubit0_out_57, %qubit1_out_58 = qco.rzz(%cst_50) %24, %30 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %31 = qco.rx(%cst_50) %qubit1_out_58 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_11) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_48) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_47) %qubit0_out_57 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_50) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_47) %35 : !qco.qubit -> !qco.qubit
    %qubit0_out_59, %qubit1_out_60 = qco.rzz(%cst_50) %36, %33 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %37 = qco.rx(%cst_10) %qubit1_out_60 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_22) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_9) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_8) %qubit0_out_59 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_22) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rx(%cst_7) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_41) %3 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_27) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rx(%cst_20) %44 : !qco.qubit -> !qco.qubit
    %qubit0_out_61, %qubit1_out_62 = qco.rzz(%cst_50) %39, %45 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %46 = qco.rx(%cst_50) %qubit1_out_62 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_19) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rx(%cst_48) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_47) %qubit0_out_61 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_50) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rx(%cst_47) %50 : !qco.qubit -> !qco.qubit
    %qubit0_out_63, %qubit1_out_64 = qco.rzz(%cst_50) %51, %48 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %52 = qco.rx(%cst_18) %qubit1_out_64 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_41) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rx(%cst_17) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rx(%cst_16) %qubit0_out_63 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_15) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rx(%cst_14) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_28) %4 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_27) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rx(%cst_26) %59 : !qco.qubit -> !qco.qubit
    %qubit0_out_65, %qubit1_out_66 = qco.rzz(%cst_50) %54, %60 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %61 = qco.rx(%cst_50) %qubit1_out_66 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_25) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rx(%cst_48) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rx(%cst_47) %qubit0_out_65 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_50) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rx(%cst_47) %65 : !qco.qubit -> !qco.qubit
    %qubit0_out_67, %qubit1_out_68 = qco.rzz(%cst_50) %66, %63 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %67 = qco.rx(%cst_24) %qubit1_out_68 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_51) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rx(%cst_24) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rx(%cst_23) %qubit0_out_67 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_22) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rx(%cst_21) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rx(%cst_41) %5 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_34) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rx(%cst_33) %74 : !qco.qubit -> !qco.qubit
    %qubit0_out_69, %qubit1_out_70 = qco.rzz(%cst_50) %69, %75 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %76 = qco.rx(%cst_50) %qubit1_out_70 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_32) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rx(%cst_48) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rx(%cst_47) %qubit0_out_69 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_50) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rx(%cst_47) %80 : !qco.qubit -> !qco.qubit
    %qubit0_out_71, %qubit1_out_72 = qco.rzz(%cst_50) %81, %78 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %82 = qco.rx(%cst_31) %qubit1_out_72 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_30) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rx(%cst_29) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rx(%cst_47) %qubit0_out_71 : !qco.qubit -> !qco.qubit
    %86 = qco.rx(%cst_44) %6 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_43) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rx(%cst_42) %87 : !qco.qubit -> !qco.qubit
    %qubit0_out_73, %qubit1_out_74 = qco.rzz(%cst_50) %84, %88 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %89 = qco.rx(%cst_50) %qubit1_out_74 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_40) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rx(%cst_48) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rx(%cst_47) %qubit0_out_73 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_50) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rx(%cst_47) %93 : !qco.qubit -> !qco.qubit
    %qubit0_out_75, %qubit1_out_76 = qco.rzz(%cst_50) %94, %91 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %95 = qco.rx(%cst_39) %qubit1_out_76 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_38) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rx(%cst_37) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rx(%cst_36) %qubit0_out_75 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_38) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rx(%cst_35) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.rx(%cst_54) %7 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_53) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rx(%cst_52) %102 : !qco.qubit -> !qco.qubit
    %qubit0_out_77, %qubit1_out_78 = qco.rzz(%cst_50) %97, %103 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %104 = qco.rx(%cst_50) %qubit1_out_78 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst_49) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rx(%cst_48) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rx(%cst_47) %qubit0_out_77 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_50) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rx(%cst_47) %108 : !qco.qubit -> !qco.qubit
    %qubit0_out_79, %qubit1_out_80 = qco.rzz(%cst_50) %109, %106 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %110 = qco.rx(%cst_46) %qubit1_out_80 : !qco.qubit -> !qco.qubit
    %111 = qco.rx(%cst_45) %qubit0_out_79 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %27 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<8>
    %qubit_out_81, %result_82 = qco.measure %42 : !qco.qubit
    cbit.store %result_82, %8[%c1] : !cbit.reg<8>
    %qubit_out_83, %result_84 = qco.measure %57 : !qco.qubit
    cbit.store %result_84, %8[%c2] : !cbit.reg<8>
    %qubit_out_85, %result_86 = qco.measure %72 : !qco.qubit
    cbit.store %result_86, %8[%c3] : !cbit.reg<8>
    %qubit_out_87, %result_88 = qco.measure %85 : !qco.qubit
    cbit.store %result_88, %8[%c4] : !cbit.reg<8>
    %qubit_out_89, %result_90 = qco.measure %100 : !qco.qubit
    cbit.store %result_90, %8[%c5] : !cbit.reg<8>
    %qubit_out_91, %result_92 = qco.measure %111 : !qco.qubit
    cbit.store %result_92, %8[%c6] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_81 : !qco.qubit
    qco.sink %qubit_out_83 : !qco.qubit
    qco.sink %qubit_out_85 : !qco.qubit
    qco.sink %qubit_out_87 : !qco.qubit
    qco.sink %qubit_out_89 : !qco.qubit
    qco.sink %qubit_out_91 : !qco.qubit
    %qubit_out_93, %result_94 = qco.measure %110 : !qco.qubit
    qco.sink %qubit_out_93 : !qco.qubit
    cbit.store %result_94, %8[%c7] : !cbit.reg<8>
    %cst_95 = arith.constant 2.3561944901923404 : f64
    qco.gphase(%cst_95)
    return %8 : !cbit.reg<8>
  }
}
