module attributes {mqt.layout = {initial = array<i64: 1, 2, 0>, input_count = 3 : i64, sites = array<i64: 0, 1, 2>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 4.7123889803846897 : f64
    %cst_0 = arith.constant 2.3561944901923453 : f64
    %cst_1 = arith.constant 2.3561944901923439 : f64
    %cst_2 = arith.constant 1.5707963267948968 : f64
    %cst_3 = arith.constant 1.5707963267948961 : f64
    %cst_4 = arith.constant -6.2831853071795862 : f64
    %cst_5 = arith.constant -1.5707963267948961 : f64
    %cst_6 = arith.constant 1.9634954084936209 : f64
    %cst_7 = arith.constant -3.1415926535897931 : f64
    %cst_8 = arith.constant 2.7488935718910685 : f64
    %cst_9 = arith.constant -1.5707963267948966 : f64
    %cst_10 = arith.constant 3.752318617979002 : f64
    %cst_11 = arith.constant 3.1415926535897931 : f64
    %cst_12 = arith.constant 0.6107259643892089 : f64
    %cst_13 = arith.constant 1.5707963267948966 : f64
    %cst_14 = arith.constant 6.2831853071795862 : f64
    %cst_15 = arith.constant -1.570796326794897 : f64
    %cst_16 = arith.constant 1.570796326794897 : f64
    %cst_17 = arith.constant -4.7123889803846897 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %4 = qco.rx(%cst_13) %1 : !qco.qubit -> !qco.qubit
    %5 = qco.rz(%cst_13) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.rx(%cst_13) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rx(%cst_13) %2 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_13) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_13) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_3) %0 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_16) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_9) %9 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_2) %12 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_13) %13, %11 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %14 = qco.rx(%cst_12) %qubit1_out : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_11) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_10) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_9) %qubit0_out : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_1) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_9) %18 : !qco.qubit -> !qco.qubit
    %qubit0_out_18, %qubit1_out_19 = qco.rzz(%cst_13) %19, %16 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %20 = qco.rx(%cst_7) %qubit1_out_19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_0) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_4) %qubit0_out_18 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_13) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_13) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_17) %22 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_16) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_15) %6 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_16) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_14) %29 : !qco.qubit -> !qco.qubit
    %qubit0_out_20, %qubit1_out_21 = qco.rzz(%cst_13) %30, %27 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %31 = qco.rx(%cst_12) %qubit1_out_21 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_11) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_10) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_9) %qubit0_out_20 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_8) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_9) %35 : !qco.qubit -> !qco.qubit
    %qubit0_out_22, %qubit1_out_23 = qco.rzz(%cst_13) %36, %33 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %37 = qco.rx(%cst_7) %qubit1_out_23 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_6) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_5) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_4) %qubit0_out_22 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_13) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rx(%cst_13) %41 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %39 : !qco.qubit
    cbit.store %result, %3[%c0] : !cbit.reg<3>
    %qubit_out_24, %result_25 = qco.measure %42 : !qco.qubit
    cbit.store %result_25, %3[%c1] : !cbit.reg<3>
    qco.sink %qubit_out_24 : !qco.qubit
    %qubit_out_26, %result_27 = qco.measure %25 : !qco.qubit
    qco.sink %qubit_out_26 : !qco.qubit
    cbit.store %result_27, %3[%c2] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    return %3 : !cbit.reg<3>
  }
}
