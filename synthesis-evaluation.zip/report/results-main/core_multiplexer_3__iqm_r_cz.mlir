module attributes {mqt.layout = {initial = array<i64: 1, 2, 0>, input_count = 3 : i64, sites = array<i64: 0, 1, 2>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant 2.714965160462917 : f64
    %cst_0 = arith.constant 7.4273541408476067 : f64
    %cst_1 = arith.constant 2.3561944901923448 : f64
    %cst_2 = arith.constant -0.78539816339744739 : f64
    %cst_3 = arith.constant 1.5707963267948968 : f64
    %cst_4 = arith.constant 3.1415926535897931 : f64
    %cst_5 = arith.constant 6.2831853071795862 : f64
    %cst_6 = arith.constant 2.4805494847391065 : f64
    %cst_7 = arith.constant 7.1929384651237962 : f64
    %cst_8 = arith.constant 2.748893571891069 : f64
    %cst_9 = arith.constant -1.178097245096172 : f64
    %cst_10 = arith.constant 4.7123889803846897 : f64
    %cst_11 = arith.constant -1.5707963267948966 : f64
    %cst_12 = arith.constant 3.1415926535897927 : f64
    %cst_13 = arith.constant 0.000000e+00 : f64
    %cst_14 = arith.constant 1.5707963267948966 : f64
    %cst_15 = arith.constant 1.570796326794897 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %4 = qco.r(%cst_14, %cst_14) %1 : !qco.qubit -> !qco.qubit
    %5 = qco.r(%cst_4, %cst_13) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.r(%cst_14, %cst_14) %2 : !qco.qubit -> !qco.qubit
    %7 = qco.r(%cst_4, %cst_13) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_5, %cst_13) %0 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_15, %cst_14) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_15, %cst_13) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_4, %cst_13) %7 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_3, %cst_14) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_10, %cst_13) %12 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%13) targets (%arg0 = %10) {
      %43 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.r(%cst_10, %cst_13) %targets_out : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_14, %cst_14) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_10, %cst_13) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_2, %cst_13) %controls_out : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_15, %cst_14) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst_3, %cst_13) %18 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%19) targets (%arg0 = %16) {
      %43 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.r(%cst_11, %cst_13) %targets_out_17 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_1, %cst_14) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_4, %cst_13) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_0, %cst_13) %controls_out_16 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_12, %cst_14) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst, %cst_13) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_15, %cst_14) %22 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst_15, %cst_13) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_12, %cst_13) %5 : !qco.qubit -> !qco.qubit
    %29 = qco.r(%cst_15, %cst_14) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_11, %cst_13) %29 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%30) targets (%arg0 = %27) {
      %43 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.r(%cst_10, %cst_13) %targets_out_19 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_14, %cst_14) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_10, %cst_13) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.r(%cst_9, %cst_13) %controls_out_18 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst_15, %cst_14) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_14, %cst_13) %35 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%36) targets (%arg0 = %33) {
      %43 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %37 = qco.r(%cst_10, %cst_13) %targets_out_21 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst_8, %cst_14) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst_12, %cst_13) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_7, %cst_13) %controls_out_20 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst_12, %cst_14) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst_6, %cst_13) %41 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %39 : !qco.qubit
    cbit.store %result, %3[%c0] : !cbit.reg<3>
    %qubit_out_22, %result_23 = qco.measure %42 : !qco.qubit
    cbit.store %result_23, %3[%c1] : !cbit.reg<3>
    qco.sink %qubit_out_22 : !qco.qubit
    %qubit_out_24, %result_25 = qco.measure %25 : !qco.qubit
    qco.sink %qubit_out_24 : !qco.qubit
    cbit.store %result_25, %3[%c2] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    %cst_26 = arith.constant -3.1415926535897896 : f64
    qco.gphase(%cst_26)
    return %3 : !cbit.reg<3>
  }
}
