module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 6.2831853071795862 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant 0.000000e+00 : f64
    %cst_2 = arith.constant 3.1415926535897931 : f64
    %cst_3 = arith.constant 4.1137905112835691 : f64
    %cst_4 = arith.constant 2.1371900420758787 : f64
    %cst_5 = arith.constant 4.3615322951968754 : f64
    %cst_6 = arith.constant 6.0250262555862042 : f64
    %cst_7 = arith.constant 1.7340708415008688 : f64
    %cst_8 = arith.constant 2.1226077124365608 : f64
    %cst_9 = arith.constant 2.9792972142727359 : f64
    %cst_10 = arith.constant 1.5293454451282278 : f64
    %cst_11 = arith.constant 1.3229162539814885 : f64
    %cst_12 = arith.constant 3.4527988102212008 : f64
    %cst_13 = arith.constant 1.9109891206913361 : f64
    %cst_14 = arith.constant 3.9086647555503813 : f64
    %cst_15 = arith.constant 1.8804777972427797 : f64
    %cst_16 = arith.constant 2.3022447370381602 : f64
    %cst_17 = arith.constant 1.7813560148940537 : f64
    %cst_18 = arith.constant 1.9041198515306859 : f64
    %cst_19 = arith.constant 1.3129427768512896 : f64
    %cst_20 = arith.constant 1.4827308882142842 : f64
    %cst_21 = arith.constant -1.1736698583283118 : f64
    %cst_22 = arith.constant 1.3506515126068535 : f64
    %cst_23 = arith.constant 4.621056795010821 : f64
    %cst_24 = arith.constant 3.351941619402997 : f64
    %cst_25 = arith.constant 1.6536386134852503 : f64
    %cst_26 = arith.constant 1.2010571115009814 : f64
    %cst_27 = arith.constant 5.5203889024503976 : f64
    %cst_28 = arith.constant 1.73041770237702 : f64
    %cst_29 = arith.constant 1.7355849949893656 : f64
    %cst_30 = arith.constant 4.2341124667313572 : f64
    %cst_31 = arith.constant 0.55189936766203296 : f64
    %cst_32 = arith.constant 1.9865191709132803 : f64
    %cst_33 = arith.constant 6.3354670398632607 : f64
    %cst_34 = arith.constant 1.6812383935825423 : f64
    %cst_35 = arith.constant 0.4432708019908822 : f64
    %cst_36 = arith.constant 5.1328889364892989 : f64
    %cst_37 = arith.constant 1.5353590711611065 : f64
    %cst_38 = arith.constant 1.5549544081008582 : f64
    %cst_39 = arith.constant 2.6750124708957457 : f64
    %cst_40 = arith.constant 0.69401868729788896 : f64
    %cst_41 = arith.constant 3.7216427874614082 : f64
    %cst_42 = arith.constant -0.93277901945688146 : f64
    %cst_43 = arith.constant 2.0046577347147831 : f64
    %cst_44 = arith.constant 5.0145411367343966 : f64
    %cst_45 = arith.constant 2.5540404538018247 : f64
    %cst_46 = arith.constant 1.7766233766715802 : f64
    %cst_47 = arith.constant 5.0101316187997877 : f64
    %cst_48 = arith.constant 3.4965107216772964 : f64
    %cst_49 = arith.constant 2.0809071385448066 : f64
    %cst_50 = arith.constant 3.7908445323455964 : f64
    %cst_51 = arith.constant 0.9824875172359504 : f64
    %cst_52 = arith.constant 2.2494905415142239 : f64
    %cst_53 = arith.constant 4.3157850450300348 : f64
    %cst_54 = arith.constant 2.3567480649498549 : f64
    %cst_55 = arith.constant 1.5526691934410322 : f64
    %cst_56 = arith.constant 4.6942447516583599 : f64
    %cst_57 = arith.constant 5.7706509120416083 : f64
    %cst_58 = arith.constant 2.3388519887411072 : f64
    %cst_59 = arith.constant 2.4608246950200154 : f64
    %cst_60 = arith.constant 0.49376313012054673 : f64
    %cst_61 = arith.constant 0.79750809405097866 : f64
    %cst_62 = arith.constant 5.6266537331624518 : f64
    %cst_63 = arith.constant 3.9260218738641779 : f64
    %cst_64 = arith.constant 1.3143706296120283 : f64
    %cst_65 = arith.constant 1.81964578060298 : f64
    %cst_66 = arith.constant 3.5622634309860945 : f64
    %cst_67 = arith.constant 1.0294378797669939 : f64
    %cst_68 = arith.constant 2.4266344035736154 : f64
    %cst_69 = arith.constant 3.150290301907563 : f64
    %cst_70 = arith.constant 1.53399277332928 : f64
    %cst_71 = arith.constant 6.0510606307622954 : f64
    %cst_72 = arith.constant -0.12053140210516977 : f64
    %cst_73 = arith.constant 2.1017182174927447 : f64
    %cst_74 = arith.constant 6.0483880881945158 : f64
    %cst_75 = arith.constant 2.8817021288310385 : f64
    %cst_76 = arith.constant 1.5081459338571703 : f64
    %cst_77 = arith.constant 1.3395499651330702 : f64
    %cst_78 = arith.constant 6.4175009495544737 : f64
    %cst_79 = arith.constant 2.4998305063474002 : f64
    %cst_80 = arith.constant 0.16711840937707301 : f64
    %cst_81 = arith.constant 5.545192933141573 : f64
    %cst_82 = arith.constant 1.7932487222047404 : f64
    %cst_83 = arith.constant 1.8087963972514447 : f64
    %cst_84 = arith.constant 0.93803912687958623 : f64
    %cst_85 = arith.constant 2.7387818035919165 : f64
    %cst_86 = arith.constant 4.1188789804590211 : f64
    %cst_87 = arith.constant 2.6055160165028743 : f64
    %cst_88 = arith.constant 1.0835999404569425 : f64
    %cst_89 = arith.constant 0.90342328590022003 : f64
    %cst_90 = arith.constant 4.1208049918381278 : f64
    %cst_91 = arith.constant 1.6898566080021342 : f64
    %cst_92 = arith.constant 1.4911630250693819 : f64
    %cst_93 = arith.constant 5.5253011991942209 : f64
    %cst_94 = arith.constant 2.0440653077577422 : f64
    %cst_95 = arith.constant 2.0196129765299444 : f64
    %cst_96 = arith.constant 5.3913489039619265 : f64
    %cst_97 = arith.constant 1.0627674955851263 : f64
    %cst_98 = arith.constant 1.1967357052820313 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.r(%cst_98, %cst_1) %0 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_97, %cst_0) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_96, %cst_1) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_95, %cst_1) %1 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_94, %cst_0) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_93, %cst_1) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_92, %cst_1) %2 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_91, %cst_0) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_90, %cst_1) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_89, %cst_1) %3 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_88, %cst_0) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst_87, %cst_1) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_86, %cst_1) %4 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_85, %cst_0) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_84, %cst_1) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_83, %cst_1) %5 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_82, %cst_0) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_81, %cst_1) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_80, %cst_1) %6 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst_79, %cst_0) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_78, %cst_1) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.r(%cst_77, %cst_1) %7 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_76, %cst_0) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%cst_75, %cst_1) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_2, %cst_1) %10 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_0, %cst_0) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.r(%cst_2, %cst_1) %33 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%31) targets (%arg0 = %34) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.r(%cst_0, %cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst, %cst_1) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%cst_2, %cst_1) %13 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst_0, %cst_0) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst_2, %cst_1) %38 : !qco.qubit -> !qco.qubit
    %controls_out_99, %targets_out_100 = qco.ctrl(%36) targets (%arg0 = %39) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %40 = qco.r(%cst_0, %cst_0) %targets_out_100 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst, %cst_1) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst_2, %cst_1) %16 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%cst_0, %cst_0) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_2, %cst_1) %43 : !qco.qubit -> !qco.qubit
    %controls_out_101, %targets_out_102 = qco.ctrl(%41) targets (%arg0 = %44) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.r(%cst_0, %cst_0) %targets_out_102 : !qco.qubit -> !qco.qubit
    %46 = qco.r(%cst, %cst_1) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%cst_2, %cst_1) %19 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst_0, %cst_0) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.r(%cst_2, %cst_1) %48 : !qco.qubit -> !qco.qubit
    %controls_out_103, %targets_out_104 = qco.ctrl(%46) targets (%arg0 = %49) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qco.r(%cst_0, %cst_0) %targets_out_104 : !qco.qubit -> !qco.qubit
    %51 = qco.r(%cst, %cst_1) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.r(%cst_2, %cst_1) %22 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst_0, %cst_0) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.r(%cst_2, %cst_1) %53 : !qco.qubit -> !qco.qubit
    %controls_out_105, %targets_out_106 = qco.ctrl(%51) targets (%arg0 = %54) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.r(%cst_0, %cst_0) %targets_out_106 : !qco.qubit -> !qco.qubit
    %56 = qco.r(%cst, %cst_1) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.r(%cst_2, %cst_1) %25 : !qco.qubit -> !qco.qubit
    %58 = qco.r(%cst_0, %cst_0) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%cst_2, %cst_1) %58 : !qco.qubit -> !qco.qubit
    %controls_out_107, %targets_out_108 = qco.ctrl(%56) targets (%arg0 = %59) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qco.r(%cst_0, %cst_0) %targets_out_108 : !qco.qubit -> !qco.qubit
    %61 = qco.r(%cst, %cst_1) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.r(%cst_2, %cst_1) %28 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%cst_0, %cst_0) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.r(%cst_2, %cst_1) %63 : !qco.qubit -> !qco.qubit
    %controls_out_109, %targets_out_110 = qco.ctrl(%61) targets (%arg0 = %64) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qco.r(%cst_0, %cst_0) %targets_out_110 : !qco.qubit -> !qco.qubit
    %66 = qco.r(%cst, %cst_1) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.r(%cst_2, %cst_1) %controls_out : !qco.qubit -> !qco.qubit
    %68 = qco.r(%cst_0, %cst_0) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.r(%cst_2, %cst_1) %68 : !qco.qubit -> !qco.qubit
    %controls_out_111, %targets_out_112 = qco.ctrl(%66) targets (%arg0 = %69) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %70 = qco.r(%cst_0, %cst_0) %targets_out_112 : !qco.qubit -> !qco.qubit
    %71 = qco.r(%cst, %cst_1) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%cst_74, %cst_1) %controls_out_99 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%cst_73, %cst_0) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.r(%cst_72, %cst_1) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.r(%cst_71, %cst_1) %controls_out_101 : !qco.qubit -> !qco.qubit
    %76 = qco.r(%cst_70, %cst_0) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.r(%cst_69, %cst_1) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst_68, %cst_1) %controls_out_103 : !qco.qubit -> !qco.qubit
    %79 = qco.r(%cst_67, %cst_0) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.r(%cst_66, %cst_1) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%cst_65, %cst_1) %controls_out_105 : !qco.qubit -> !qco.qubit
    %82 = qco.r(%cst_64, %cst_0) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.r(%cst_63, %cst_1) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.r(%cst_62, %cst_1) %controls_out_107 : !qco.qubit -> !qco.qubit
    %85 = qco.r(%cst_61, %cst_0) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.r(%cst_60, %cst_1) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.r(%cst_59, %cst_1) %controls_out_109 : !qco.qubit -> !qco.qubit
    %88 = qco.r(%cst_58, %cst_0) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%cst_57, %cst_1) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.r(%cst_56, %cst_1) %controls_out_111 : !qco.qubit -> !qco.qubit
    %91 = qco.r(%cst_55, %cst_0) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.r(%cst_54, %cst_1) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.r(%cst_53, %cst_1) %71 : !qco.qubit -> !qco.qubit
    %94 = qco.r(%cst_52, %cst_0) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.r(%cst_51, %cst_1) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.r(%cst_2, %cst_1) %74 : !qco.qubit -> !qco.qubit
    %97 = qco.r(%cst_0, %cst_0) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.r(%cst_2, %cst_1) %97 : !qco.qubit -> !qco.qubit
    %controls_out_113, %targets_out_114 = qco.ctrl(%95) targets (%arg0 = %98) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %99 = qco.r(%cst_0, %cst_0) %targets_out_114 : !qco.qubit -> !qco.qubit
    %100 = qco.r(%cst, %cst_1) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.r(%cst_2, %cst_1) %77 : !qco.qubit -> !qco.qubit
    %102 = qco.r(%cst_0, %cst_0) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.r(%cst_2, %cst_1) %102 : !qco.qubit -> !qco.qubit
    %controls_out_115, %targets_out_116 = qco.ctrl(%100) targets (%arg0 = %103) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %104 = qco.r(%cst_0, %cst_0) %targets_out_116 : !qco.qubit -> !qco.qubit
    %105 = qco.r(%cst, %cst_1) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.r(%cst_2, %cst_1) %80 : !qco.qubit -> !qco.qubit
    %107 = qco.r(%cst_0, %cst_0) %106 : !qco.qubit -> !qco.qubit
    %108 = qco.r(%cst_2, %cst_1) %107 : !qco.qubit -> !qco.qubit
    %controls_out_117, %targets_out_118 = qco.ctrl(%105) targets (%arg0 = %108) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %109 = qco.r(%cst_0, %cst_0) %targets_out_118 : !qco.qubit -> !qco.qubit
    %110 = qco.r(%cst, %cst_1) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.r(%cst_2, %cst_1) %83 : !qco.qubit -> !qco.qubit
    %112 = qco.r(%cst_0, %cst_0) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.r(%cst_2, %cst_1) %112 : !qco.qubit -> !qco.qubit
    %controls_out_119, %targets_out_120 = qco.ctrl(%110) targets (%arg0 = %113) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %114 = qco.r(%cst_0, %cst_0) %targets_out_120 : !qco.qubit -> !qco.qubit
    %115 = qco.r(%cst, %cst_1) %114 : !qco.qubit -> !qco.qubit
    %116 = qco.r(%cst_2, %cst_1) %86 : !qco.qubit -> !qco.qubit
    %117 = qco.r(%cst_0, %cst_0) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.r(%cst_2, %cst_1) %117 : !qco.qubit -> !qco.qubit
    %controls_out_121, %targets_out_122 = qco.ctrl(%115) targets (%arg0 = %118) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %119 = qco.r(%cst_0, %cst_0) %targets_out_122 : !qco.qubit -> !qco.qubit
    %120 = qco.r(%cst, %cst_1) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.r(%cst_2, %cst_1) %89 : !qco.qubit -> !qco.qubit
    %122 = qco.r(%cst_0, %cst_0) %121 : !qco.qubit -> !qco.qubit
    %123 = qco.r(%cst_2, %cst_1) %122 : !qco.qubit -> !qco.qubit
    %controls_out_123, %targets_out_124 = qco.ctrl(%120) targets (%arg0 = %123) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %124 = qco.r(%cst_0, %cst_0) %targets_out_124 : !qco.qubit -> !qco.qubit
    %125 = qco.r(%cst, %cst_1) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.r(%cst_2, %cst_1) %92 : !qco.qubit -> !qco.qubit
    %127 = qco.r(%cst_0, %cst_0) %126 : !qco.qubit -> !qco.qubit
    %128 = qco.r(%cst_2, %cst_1) %127 : !qco.qubit -> !qco.qubit
    %controls_out_125, %targets_out_126 = qco.ctrl(%125) targets (%arg0 = %128) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %129 = qco.r(%cst_0, %cst_0) %targets_out_126 : !qco.qubit -> !qco.qubit
    %130 = qco.r(%cst, %cst_1) %129 : !qco.qubit -> !qco.qubit
    %131 = qco.r(%cst_2, %cst_1) %controls_out_113 : !qco.qubit -> !qco.qubit
    %132 = qco.r(%cst_0, %cst_0) %131 : !qco.qubit -> !qco.qubit
    %133 = qco.r(%cst_2, %cst_1) %132 : !qco.qubit -> !qco.qubit
    %controls_out_127, %targets_out_128 = qco.ctrl(%130) targets (%arg0 = %133) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %134 = qco.r(%cst_0, %cst_0) %targets_out_128 : !qco.qubit -> !qco.qubit
    %135 = qco.r(%cst, %cst_1) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.r(%cst_50, %cst_1) %controls_out_115 : !qco.qubit -> !qco.qubit
    %137 = qco.r(%cst_49, %cst_0) %136 : !qco.qubit -> !qco.qubit
    %138 = qco.r(%cst_48, %cst_1) %137 : !qco.qubit -> !qco.qubit
    %139 = qco.r(%cst_47, %cst_1) %controls_out_117 : !qco.qubit -> !qco.qubit
    %140 = qco.r(%cst_46, %cst_0) %139 : !qco.qubit -> !qco.qubit
    %141 = qco.r(%cst_45, %cst_1) %140 : !qco.qubit -> !qco.qubit
    %142 = qco.r(%cst_44, %cst_1) %controls_out_119 : !qco.qubit -> !qco.qubit
    %143 = qco.r(%cst_43, %cst_0) %142 : !qco.qubit -> !qco.qubit
    %144 = qco.r(%cst_42, %cst_1) %143 : !qco.qubit -> !qco.qubit
    %145 = qco.r(%cst_41, %cst_1) %controls_out_121 : !qco.qubit -> !qco.qubit
    %146 = qco.r(%cst_40, %cst_0) %145 : !qco.qubit -> !qco.qubit
    %147 = qco.r(%cst_39, %cst_1) %146 : !qco.qubit -> !qco.qubit
    %148 = qco.r(%cst_38, %cst_1) %controls_out_123 : !qco.qubit -> !qco.qubit
    %149 = qco.r(%cst_37, %cst_0) %148 : !qco.qubit -> !qco.qubit
    %150 = qco.r(%cst_36, %cst_1) %149 : !qco.qubit -> !qco.qubit
    %151 = qco.r(%cst_35, %cst_1) %controls_out_125 : !qco.qubit -> !qco.qubit
    %152 = qco.r(%cst_34, %cst_0) %151 : !qco.qubit -> !qco.qubit
    %153 = qco.r(%cst_33, %cst_1) %152 : !qco.qubit -> !qco.qubit
    %154 = qco.r(%cst_32, %cst_1) %controls_out_127 : !qco.qubit -> !qco.qubit
    %155 = qco.r(%cst_31, %cst_0) %154 : !qco.qubit -> !qco.qubit
    %156 = qco.r(%cst_30, %cst_1) %155 : !qco.qubit -> !qco.qubit
    %157 = qco.r(%cst_29, %cst_1) %135 : !qco.qubit -> !qco.qubit
    %158 = qco.r(%cst_28, %cst_0) %157 : !qco.qubit -> !qco.qubit
    %159 = qco.r(%cst_27, %cst_1) %158 : !qco.qubit -> !qco.qubit
    %160 = qco.r(%cst_2, %cst_1) %138 : !qco.qubit -> !qco.qubit
    %161 = qco.r(%cst_0, %cst_0) %160 : !qco.qubit -> !qco.qubit
    %162 = qco.r(%cst_2, %cst_1) %161 : !qco.qubit -> !qco.qubit
    %controls_out_129, %targets_out_130 = qco.ctrl(%159) targets (%arg0 = %162) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %163 = qco.r(%cst_0, %cst_0) %targets_out_130 : !qco.qubit -> !qco.qubit
    %164 = qco.r(%cst, %cst_1) %163 : !qco.qubit -> !qco.qubit
    %165 = qco.r(%cst_2, %cst_1) %141 : !qco.qubit -> !qco.qubit
    %166 = qco.r(%cst_0, %cst_0) %165 : !qco.qubit -> !qco.qubit
    %167 = qco.r(%cst_2, %cst_1) %166 : !qco.qubit -> !qco.qubit
    %controls_out_131, %targets_out_132 = qco.ctrl(%164) targets (%arg0 = %167) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %168 = qco.r(%cst_0, %cst_0) %targets_out_132 : !qco.qubit -> !qco.qubit
    %169 = qco.r(%cst, %cst_1) %168 : !qco.qubit -> !qco.qubit
    %170 = qco.r(%cst_2, %cst_1) %144 : !qco.qubit -> !qco.qubit
    %171 = qco.r(%cst_0, %cst_0) %170 : !qco.qubit -> !qco.qubit
    %172 = qco.r(%cst_2, %cst_1) %171 : !qco.qubit -> !qco.qubit
    %controls_out_133, %targets_out_134 = qco.ctrl(%169) targets (%arg0 = %172) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %173 = qco.r(%cst_0, %cst_0) %targets_out_134 : !qco.qubit -> !qco.qubit
    %174 = qco.r(%cst, %cst_1) %173 : !qco.qubit -> !qco.qubit
    %175 = qco.r(%cst_2, %cst_1) %147 : !qco.qubit -> !qco.qubit
    %176 = qco.r(%cst_0, %cst_0) %175 : !qco.qubit -> !qco.qubit
    %177 = qco.r(%cst_2, %cst_1) %176 : !qco.qubit -> !qco.qubit
    %controls_out_135, %targets_out_136 = qco.ctrl(%174) targets (%arg0 = %177) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %178 = qco.r(%cst_0, %cst_0) %targets_out_136 : !qco.qubit -> !qco.qubit
    %179 = qco.r(%cst, %cst_1) %178 : !qco.qubit -> !qco.qubit
    %180 = qco.r(%cst_2, %cst_1) %150 : !qco.qubit -> !qco.qubit
    %181 = qco.r(%cst_0, %cst_0) %180 : !qco.qubit -> !qco.qubit
    %182 = qco.r(%cst_2, %cst_1) %181 : !qco.qubit -> !qco.qubit
    %controls_out_137, %targets_out_138 = qco.ctrl(%179) targets (%arg0 = %182) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %183 = qco.r(%cst_0, %cst_0) %targets_out_138 : !qco.qubit -> !qco.qubit
    %184 = qco.r(%cst, %cst_1) %183 : !qco.qubit -> !qco.qubit
    %185 = qco.r(%cst_2, %cst_1) %153 : !qco.qubit -> !qco.qubit
    %186 = qco.r(%cst_0, %cst_0) %185 : !qco.qubit -> !qco.qubit
    %187 = qco.r(%cst_2, %cst_1) %186 : !qco.qubit -> !qco.qubit
    %controls_out_139, %targets_out_140 = qco.ctrl(%184) targets (%arg0 = %187) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %188 = qco.r(%cst_0, %cst_0) %targets_out_140 : !qco.qubit -> !qco.qubit
    %189 = qco.r(%cst, %cst_1) %188 : !qco.qubit -> !qco.qubit
    %190 = qco.r(%cst_2, %cst_1) %156 : !qco.qubit -> !qco.qubit
    %191 = qco.r(%cst_0, %cst_0) %190 : !qco.qubit -> !qco.qubit
    %192 = qco.r(%cst_2, %cst_1) %191 : !qco.qubit -> !qco.qubit
    %controls_out_141, %targets_out_142 = qco.ctrl(%189) targets (%arg0 = %192) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %193 = qco.r(%cst_0, %cst_0) %targets_out_142 : !qco.qubit -> !qco.qubit
    %194 = qco.r(%cst, %cst_1) %193 : !qco.qubit -> !qco.qubit
    %195 = qco.r(%cst_2, %cst_1) %controls_out_129 : !qco.qubit -> !qco.qubit
    %196 = qco.r(%cst_0, %cst_0) %195 : !qco.qubit -> !qco.qubit
    %197 = qco.r(%cst_2, %cst_1) %196 : !qco.qubit -> !qco.qubit
    %controls_out_143, %targets_out_144 = qco.ctrl(%194) targets (%arg0 = %197) {
      %224 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %224 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %198 = qco.r(%cst_0, %cst_0) %targets_out_144 : !qco.qubit -> !qco.qubit
    %199 = qco.r(%cst, %cst_1) %198 : !qco.qubit -> !qco.qubit
    %200 = qco.r(%cst_26, %cst_1) %controls_out_131 : !qco.qubit -> !qco.qubit
    %201 = qco.r(%cst_25, %cst_0) %200 : !qco.qubit -> !qco.qubit
    %202 = qco.r(%cst_24, %cst_1) %201 : !qco.qubit -> !qco.qubit
    %203 = qco.r(%cst_23, %cst_1) %controls_out_133 : !qco.qubit -> !qco.qubit
    %204 = qco.r(%cst_22, %cst_0) %203 : !qco.qubit -> !qco.qubit
    %205 = qco.r(%cst_21, %cst_1) %204 : !qco.qubit -> !qco.qubit
    %206 = qco.r(%cst_20, %cst_1) %controls_out_135 : !qco.qubit -> !qco.qubit
    %207 = qco.r(%cst_19, %cst_0) %206 : !qco.qubit -> !qco.qubit
    %208 = qco.r(%cst_18, %cst_1) %207 : !qco.qubit -> !qco.qubit
    %209 = qco.r(%cst_17, %cst_1) %controls_out_137 : !qco.qubit -> !qco.qubit
    %210 = qco.r(%cst_16, %cst_0) %209 : !qco.qubit -> !qco.qubit
    %211 = qco.r(%cst_15, %cst_1) %210 : !qco.qubit -> !qco.qubit
    %212 = qco.r(%cst_14, %cst_1) %controls_out_139 : !qco.qubit -> !qco.qubit
    %213 = qco.r(%cst_13, %cst_0) %212 : !qco.qubit -> !qco.qubit
    %214 = qco.r(%cst_12, %cst_1) %213 : !qco.qubit -> !qco.qubit
    %215 = qco.r(%cst_11, %cst_1) %controls_out_141 : !qco.qubit -> !qco.qubit
    %216 = qco.r(%cst_10, %cst_0) %215 : !qco.qubit -> !qco.qubit
    %217 = qco.r(%cst_9, %cst_1) %216 : !qco.qubit -> !qco.qubit
    %218 = qco.r(%cst_8, %cst_1) %controls_out_143 : !qco.qubit -> !qco.qubit
    %219 = qco.r(%cst_7, %cst_0) %218 : !qco.qubit -> !qco.qubit
    %220 = qco.r(%cst_6, %cst_1) %219 : !qco.qubit -> !qco.qubit
    %221 = qco.r(%cst_5, %cst_1) %199 : !qco.qubit -> !qco.qubit
    %222 = qco.r(%cst_4, %cst_0) %221 : !qco.qubit -> !qco.qubit
    %223 = qco.r(%cst_3, %cst_1) %222 : !qco.qubit -> !qco.qubit
    qco.sink %202 : !qco.qubit
    qco.sink %205 : !qco.qubit
    qco.sink %208 : !qco.qubit
    qco.sink %211 : !qco.qubit
    qco.sink %214 : !qco.qubit
    qco.sink %217 : !qco.qubit
    qco.sink %220 : !qco.qubit
    qco.sink %223 : !qco.qubit
    return %c0_i64 : i64
  }
}
