module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant -1.3322676295501878E-15 : f64
    %cst_0 = arith.constant 3.2587013981566573 : f64
    %cst_1 = arith.constant -4.5952802358178255 : f64
    %cst_2 = arith.constant 6.6583840710543658 : f64
    %cst_3 = arith.constant -2.766393889715014 : f64
    %cst_4 = arith.constant 4.7123889803846906 : f64
    %cst_5 = arith.constant 5.0737561042913972 : f64
    %cst_6 = arith.constant 3.1415926535897949 : f64
    %cst_7 = arith.constant -2.2204460492503131E-15 : f64
    %cst_8 = arith.constant 0.10308160852269976 : f64
    %cst_9 = arith.constant -1.4677147182721959 : f64
    %cst_10 = arith.constant 5.0999856670398698 : f64
    %cst_11 = arith.constant 5.0999856670398707 : f64
    %cst_12 = arith.constant -3.1086244689504383E-15 : f64
    %cst_13 = arith.constant -1.5707963267948963 : f64
    %cst_14 = arith.constant 2.5535900500422257 : f64
    %cst_15 = arith.constant 4.1243863768371227 : f64
    %cst_16 = arith.constant 4.7123889803846915 : f64
    %cst_17 = arith.constant 5.1329233156686547 : f64
    %cst_18 = arith.constant 3.1415926535897958 : f64
    %cst_19 = arith.constant -3.1415926535897931 : f64
    %cst_20 = arith.constant 5.1760365893854949 : f64
    %cst_21 = arith.constant 5.1760365893854958 : f64
    %cst_22 = arith.constant -3.141592653589794 : f64
    %cst_23 = arith.constant 6.2831853071795862 : f64
    %cst_24 = arith.constant -1.5707963267948961 : f64
    %cst_25 = arith.constant 0.78539816339744828 : f64
    %cst_26 = arith.constant -2.3561944901923448 : f64
    %cst_27 = arith.constant 5.2359877559829879 : f64
    %cst_28 = arith.constant 3.1415926535897931 : f64
    %cst_29 = arith.constant -1.5707963267948957 : f64
    %cst_30 = arith.constant 4.2757618205711481 : f64
    %cst_31 = arith.constant 6.2831853071795845 : f64
    %cst_32 = arith.constant -0.43662715981354128 : f64
    %cst_33 = arith.constant 5.3278686890550766 : f64
    %cst_34 = arith.constant 4.0969092717143027 : f64
    %cst_35 = arith.constant 3.1415926535897927 : f64
    %cst_36 = arith.constant -6.2831853071795862 : f64
    %cst_37 = arith.constant 3.1415926535897936 : f64
    %cst_38 = arith.constant 5.4977871437821371 : f64
    %cst_39 = arith.constant 4.7123889803846897 : f64
    %cst_40 = arith.constant 1.5707963267948966 : f64
    %cst_41 = arith.constant 3.1415926535897944 : f64
    %cst_42 = arith.constant 1.5707963267948979 : f64
    %cst_43 = arith.constant 5.4977871437821388 : f64
    %cst_44 = arith.constant -3.1415926535897918 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %9 = qco.x %0 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_6) %1 : !qco.qubit -> !qco.qubit
    %11 = qco.sx %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_5) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.sx %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_4) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_3) %9 : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_31) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_2) %18 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%19) targets (%arg0 = %14) {
      %153 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.rz(%cst_39) %targets_out : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_5) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.sx %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_28) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_36) %controls_out : !qco.qubit -> !qco.qubit
    %26 = qco.sx %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_40) %26 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%27) targets (%arg0 = %24) {
      %153 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = qco.rz(%cst_1) %targets_out_46 : !qco.qubit -> !qco.qubit
    %29 = qco.sx %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_31) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_0) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_13) %controls_out_45 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_18) %2 : !qco.qubit -> !qco.qubit
    %37 = qco.sx %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_11) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_16) %39 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%32) targets (%arg0 = %40) {
      %153 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.rz(%cst_39) %targets_out_48 : !qco.qubit -> !qco.qubit
    %42 = qco.sx %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_10) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.sx %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_28) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_36) %controls_out_47 : !qco.qubit -> !qco.qubit
    %47 = qco.sx %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_40) %47 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%48) targets (%arg0 = %45) {
      %153 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %49 = qco.rz(%cst_9) %targets_out_50 : !qco.qubit -> !qco.qubit
    %50 = qco.sx %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_31) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.sx %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_8) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_24) %controls_out_49 : !qco.qubit -> !qco.qubit
    %55 = qco.sx %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_7) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_18) %3 : !qco.qubit -> !qco.qubit
    %58 = qco.sx %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_17) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.sx %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_16) %60 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%53) targets (%arg0 = %61) {
      %153 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %62 = qco.rz(%cst_39) %targets_out_52 : !qco.qubit -> !qco.qubit
    %63 = qco.sx %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_17) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.sx %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_28) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_36) %controls_out_51 : !qco.qubit -> !qco.qubit
    %68 = qco.sx %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_40) %68 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%69) targets (%arg0 = %66) {
      %153 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %70 = qco.rz(%cst_15) %targets_out_54 : !qco.qubit -> !qco.qubit
    %71 = qco.x %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_14) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_13) %controls_out_53 : !qco.qubit -> !qco.qubit
    %74 = qco.sx %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_12) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_22) %4 : !qco.qubit -> !qco.qubit
    %77 = qco.sx %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_21) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.sx %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_39) %79 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%72) targets (%arg0 = %80) {
      %153 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %81 = qco.rz(%cst_39) %targets_out_56 : !qco.qubit -> !qco.qubit
    %82 = qco.sx %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_20) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.sx %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_28) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_36) %controls_out_55 : !qco.qubit -> !qco.qubit
    %87 = qco.sx %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_40) %87 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%88) targets (%arg0 = %85) {
      %153 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %89 = qco.rz(%cst_19) %targets_out_58 : !qco.qubit -> !qco.qubit
    %90 = qco.x %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_40) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_24) %controls_out_57 : !qco.qubit -> !qco.qubit
    %93 = qco.sx %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_19) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_37) %5 : !qco.qubit -> !qco.qubit
    %96 = qco.sx %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_27) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.sx %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_39) %98 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%91) targets (%arg0 = %99) {
      %153 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %100 = qco.rz(%cst_39) %targets_out_60 : !qco.qubit -> !qco.qubit
    %101 = qco.sx %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_27) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.sx %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_37) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst_36) %controls_out_59 : !qco.qubit -> !qco.qubit
    %106 = qco.sx %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rz(%cst_40) %106 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%107) targets (%arg0 = %104) {
      %153 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %108 = qco.rz(%cst_26) %targets_out_62 : !qco.qubit -> !qco.qubit
    %109 = qco.sx %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst_41) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.sx %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rz(%cst_25) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_24) %controls_out_61 : !qco.qubit -> !qco.qubit
    %114 = qco.sx %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_23) %114 : !qco.qubit -> !qco.qubit
    %116 = qco.sx %6 : !qco.qubit -> !qco.qubit
    %117 = qco.rz(%cst_34) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.sx %117 : !qco.qubit -> !qco.qubit
    %119 = qco.rz(%cst_39) %118 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%112) targets (%arg0 = %119) {
      %153 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %120 = qco.rz(%cst_39) %targets_out_64 : !qco.qubit -> !qco.qubit
    %121 = qco.sx %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rz(%cst_33) %121 : !qco.qubit -> !qco.qubit
    %123 = qco.sx %122 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_37) %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rz(%cst_36) %controls_out_63 : !qco.qubit -> !qco.qubit
    %126 = qco.sx %125 : !qco.qubit -> !qco.qubit
    %127 = qco.rz(%cst_40) %126 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%127) targets (%arg0 = %124) {
      %153 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %128 = qco.rz(%cst_32) %targets_out_66 : !qco.qubit -> !qco.qubit
    %129 = qco.sx %128 : !qco.qubit -> !qco.qubit
    %130 = qco.rz(%cst_31) %129 : !qco.qubit -> !qco.qubit
    %131 = qco.sx %130 : !qco.qubit -> !qco.qubit
    %132 = qco.rz(%cst_30) %131 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst_29) %controls_out_65 : !qco.qubit -> !qco.qubit
    %134 = qco.sx %133 : !qco.qubit -> !qco.qubit
    %135 = qco.rz(%cst_28) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.rz(%cst_44) %7 : !qco.qubit -> !qco.qubit
    %137 = qco.sx %136 : !qco.qubit -> !qco.qubit
    %138 = qco.rz(%cst_43) %137 : !qco.qubit -> !qco.qubit
    %139 = qco.sx %138 : !qco.qubit -> !qco.qubit
    %140 = qco.rz(%cst_42) %139 : !qco.qubit -> !qco.qubit
    %controls_out_67, %targets_out_68 = qco.ctrl(%132) targets (%arg0 = %140) {
      %153 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %141 = qco.rz(%cst_39) %targets_out_68 : !qco.qubit -> !qco.qubit
    %142 = qco.sx %141 : !qco.qubit -> !qco.qubit
    %143 = qco.rz(%cst_38) %142 : !qco.qubit -> !qco.qubit
    %144 = qco.sx %143 : !qco.qubit -> !qco.qubit
    %145 = qco.rz(%cst_37) %144 : !qco.qubit -> !qco.qubit
    %146 = qco.rz(%cst_36) %controls_out_67 : !qco.qubit -> !qco.qubit
    %147 = qco.sx %146 : !qco.qubit -> !qco.qubit
    %148 = qco.rz(%cst_40) %147 : !qco.qubit -> !qco.qubit
    %controls_out_69, %targets_out_70 = qco.ctrl(%148) targets (%arg0 = %145) {
      %153 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %149 = qco.rz(%cst_39) %targets_out_70 : !qco.qubit -> !qco.qubit
    %150 = qco.rz(%cst_42) %controls_out_69 : !qco.qubit -> !qco.qubit
    %151 = qco.sx %150 : !qco.qubit -> !qco.qubit
    %152 = qco.rz(%cst_35) %151 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %35 : !qco.qubit
    cbit.store %result, %8[%c0] : !cbit.reg<8>
    %qubit_out_71, %result_72 = qco.measure %56 : !qco.qubit
    cbit.store %result_72, %8[%c1] : !cbit.reg<8>
    %qubit_out_73, %result_74 = qco.measure %75 : !qco.qubit
    cbit.store %result_74, %8[%c2] : !cbit.reg<8>
    %qubit_out_75, %result_76 = qco.measure %94 : !qco.qubit
    cbit.store %result_76, %8[%c3] : !cbit.reg<8>
    %qubit_out_77, %result_78 = qco.measure %115 : !qco.qubit
    cbit.store %result_78, %8[%c4] : !cbit.reg<8>
    %qubit_out_79, %result_80 = qco.measure %135 : !qco.qubit
    cbit.store %result_80, %8[%c5] : !cbit.reg<8>
    %qubit_out_81, %result_82 = qco.measure %152 : !qco.qubit
    cbit.store %result_82, %8[%c6] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_71 : !qco.qubit
    qco.sink %qubit_out_73 : !qco.qubit
    qco.sink %qubit_out_75 : !qco.qubit
    qco.sink %qubit_out_77 : !qco.qubit
    qco.sink %qubit_out_79 : !qco.qubit
    qco.sink %qubit_out_81 : !qco.qubit
    %qubit_out_83, %result_84 = qco.measure %149 : !qco.qubit
    qco.sink %qubit_out_83 : !qco.qubit
    cbit.store %result_84, %8[%c7] : !cbit.reg<8>
    %cst_85 = arith.constant 0.78539816339746515 : f64
    qco.gphase(%cst_85)
    return %8 : !cbit.reg<8>
  }
}
