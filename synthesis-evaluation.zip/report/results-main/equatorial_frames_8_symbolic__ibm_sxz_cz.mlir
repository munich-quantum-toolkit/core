module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main(%arg0: f64 {mqt.input_id = 16309916367715198394276235805800677067 : i128, mqt.input_name = "theta[0]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 0 : i64, name = "theta", size = 24 : i64}}, %arg1: f64 {mqt.input_id = 16309916367715198394276235805800677068 : i128, mqt.input_name = "theta[1]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 1 : i64, name = "theta", size = 24 : i64}}, %arg2: f64 {mqt.input_id = 16309916367715198394276235805800677069 : i128, mqt.input_name = "theta[2]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 2 : i64, name = "theta", size = 24 : i64}}, %arg3: f64 {mqt.input_id = 16309916367715198394276235805800677070 : i128, mqt.input_name = "theta[3]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 3 : i64, name = "theta", size = 24 : i64}}, %arg4: f64 {mqt.input_id = 16309916367715198394276235805800677071 : i128, mqt.input_name = "theta[4]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 4 : i64, name = "theta", size = 24 : i64}}, %arg5: f64 {mqt.input_id = 16309916367715198394276235805800677072 : i128, mqt.input_name = "theta[5]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 5 : i64, name = "theta", size = 24 : i64}}, %arg6: f64 {mqt.input_id = 16309916367715198394276235805800677073 : i128, mqt.input_name = "theta[6]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 6 : i64, name = "theta", size = 24 : i64}}, %arg7: f64 {mqt.input_id = 16309916367715198394276235805800677074 : i128, mqt.input_name = "theta[7]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 7 : i64, name = "theta", size = 24 : i64}}, %arg8: f64 {mqt.input_id = 16309916367715198394276235805800677075 : i128, mqt.input_name = "theta[8]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 8 : i64, name = "theta", size = 24 : i64}}, %arg9: f64 {mqt.input_id = 16309916367715198394276235805800677076 : i128, mqt.input_name = "theta[9]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 9 : i64, name = "theta", size = 24 : i64}}, %arg10: f64 {mqt.input_id = 16309916367715198394276235805800677077 : i128, mqt.input_name = "theta[10]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 10 : i64, name = "theta", size = 24 : i64}}, %arg11: f64 {mqt.input_id = 16309916367715198394276235805800677078 : i128, mqt.input_name = "theta[11]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 11 : i64, name = "theta", size = 24 : i64}}, %arg12: f64 {mqt.input_id = 16309916367715198394276235805800677079 : i128, mqt.input_name = "theta[12]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 12 : i64, name = "theta", size = 24 : i64}}, %arg13: f64 {mqt.input_id = 16309916367715198394276235805800677080 : i128, mqt.input_name = "theta[13]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 13 : i64, name = "theta", size = 24 : i64}}, %arg14: f64 {mqt.input_id = 16309916367715198394276235805800677081 : i128, mqt.input_name = "theta[14]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 14 : i64, name = "theta", size = 24 : i64}}, %arg15: f64 {mqt.input_id = 16309916367715198394276235805800677082 : i128, mqt.input_name = "theta[15]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 15 : i64, name = "theta", size = 24 : i64}}, %arg16: f64 {mqt.input_id = 16309916367715198394276235805800677083 : i128, mqt.input_name = "theta[16]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 16 : i64, name = "theta", size = 24 : i64}}, %arg17: f64 {mqt.input_id = 16309916367715198394276235805800677084 : i128, mqt.input_name = "theta[17]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 17 : i64, name = "theta", size = 24 : i64}}, %arg18: f64 {mqt.input_id = 16309916367715198394276235805800677085 : i128, mqt.input_name = "theta[18]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 18 : i64, name = "theta", size = 24 : i64}}, %arg19: f64 {mqt.input_id = 16309916367715198394276235805800677086 : i128, mqt.input_name = "theta[19]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 19 : i64, name = "theta", size = 24 : i64}}, %arg20: f64 {mqt.input_id = 16309916367715198394276235805800677087 : i128, mqt.input_name = "theta[20]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 20 : i64, name = "theta", size = 24 : i64}}, %arg21: f64 {mqt.input_id = 16309916367715198394276235805800677088 : i128, mqt.input_name = "theta[21]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 21 : i64, name = "theta", size = 24 : i64}}, %arg22: f64 {mqt.input_id = 16309916367715198394276235805800677089 : i128, mqt.input_name = "theta[22]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 22 : i64, name = "theta", size = 24 : i64}}, %arg23: f64 {mqt.input_id = 16309916367715198394276235805800677090 : i128, mqt.input_name = "theta[23]", mqt.parameter_group = {identity = "0c452cf6-3d17-4f5a-90a9-4bca89a63ecb", index = 23 : i64, name = "theta", size = 24 : i64}}) -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 1.7707963267948965 : f64
    %cst_0 = arith.constant 3.4415926535897929 : f64
    %cst_1 = arith.constant 1.3707963267948966 : f64
    %cst_2 = arith.constant 4.000000e+00 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = arith.divf %arg0, %cst_2 : f64
    %9 = math.tan %8 : f64
    %10 = math.atan %9 : f64
    %11 = arith.mulf %10, %cst_2 : f64
    %12 = arith.addf %11, %cst_1 : f64
    %13 = qco.rz(%12) %0 : !qco.qubit -> !qco.qubit
    %14 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_0) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst) %16 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%17) targets (%arg24 = %1) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = arith.divf %arg1, %cst_2 : f64
    %19 = math.tan %18 : f64
    %20 = math.atan %19 : f64
    %21 = arith.mulf %20, %cst_2 : f64
    %22 = arith.addf %21, %cst_1 : f64
    %23 = qco.rz(%22) %targets_out : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_0) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.sx %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst) %26 : !qco.qubit -> !qco.qubit
    %controls_out_3, %targets_out_4 = qco.ctrl(%27) targets (%arg24 = %2) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %28 = arith.divf %arg2, %cst_2 : f64
    %29 = math.tan %28 : f64
    %30 = math.atan %29 : f64
    %31 = arith.mulf %30, %cst_2 : f64
    %32 = arith.addf %31, %cst_1 : f64
    %33 = qco.rz(%32) %targets_out_4 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_0) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.sx %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst) %36 : !qco.qubit -> !qco.qubit
    %controls_out_5, %targets_out_6 = qco.ctrl(%37) targets (%arg24 = %3) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = arith.divf %arg3, %cst_2 : f64
    %39 = math.tan %38 : f64
    %40 = math.atan %39 : f64
    %41 = arith.mulf %40, %cst_2 : f64
    %42 = arith.addf %41, %cst_1 : f64
    %43 = qco.rz(%42) %targets_out_6 : !qco.qubit -> !qco.qubit
    %44 = qco.sx %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_0) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.sx %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst) %46 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%47) targets (%arg24 = %4) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %48 = arith.divf %arg4, %cst_2 : f64
    %49 = math.tan %48 : f64
    %50 = math.atan %49 : f64
    %51 = arith.mulf %50, %cst_2 : f64
    %52 = arith.addf %51, %cst_1 : f64
    %53 = qco.rz(%52) %targets_out_8 : !qco.qubit -> !qco.qubit
    %54 = qco.sx %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_0) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.sx %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst) %56 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%57) targets (%arg24 = %5) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %58 = arith.divf %arg5, %cst_2 : f64
    %59 = math.tan %58 : f64
    %60 = math.atan %59 : f64
    %61 = arith.mulf %60, %cst_2 : f64
    %62 = arith.addf %61, %cst_1 : f64
    %63 = qco.rz(%62) %targets_out_10 : !qco.qubit -> !qco.qubit
    %64 = qco.sx %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_0) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.sx %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst) %66 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%67) targets (%arg24 = %6) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %68 = arith.divf %arg6, %cst_2 : f64
    %69 = math.tan %68 : f64
    %70 = math.atan %69 : f64
    %71 = arith.mulf %70, %cst_2 : f64
    %72 = arith.addf %71, %cst_1 : f64
    %73 = qco.rz(%72) %targets_out_12 : !qco.qubit -> !qco.qubit
    %74 = qco.sx %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_0) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.sx %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst) %76 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%77) targets (%arg24 = %7) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %78 = arith.divf %arg7, %cst_2 : f64
    %79 = math.tan %78 : f64
    %80 = math.atan %79 : f64
    %81 = arith.mulf %80, %cst_2 : f64
    %82 = arith.addf %81, %cst_1 : f64
    %83 = qco.rz(%82) %targets_out_14 : !qco.qubit -> !qco.qubit
    %84 = qco.sx %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_0) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.sx %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst) %86 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%87) targets (%arg24 = %controls_out) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %88 = arith.divf %arg8, %cst_2 : f64
    %89 = math.tan %88 : f64
    %90 = math.atan %89 : f64
    %91 = arith.mulf %90, %cst_2 : f64
    %92 = arith.addf %91, %cst_1 : f64
    %93 = qco.rz(%92) %targets_out_16 : !qco.qubit -> !qco.qubit
    %94 = qco.sx %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_0) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.sx %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst) %96 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%97) targets (%arg24 = %controls_out_3) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %98 = arith.divf %arg9, %cst_2 : f64
    %99 = math.tan %98 : f64
    %100 = math.atan %99 : f64
    %101 = arith.mulf %100, %cst_2 : f64
    %102 = arith.addf %101, %cst_1 : f64
    %103 = qco.rz(%102) %targets_out_18 : !qco.qubit -> !qco.qubit
    %104 = qco.sx %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst_0) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.sx %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rz(%cst) %106 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%107) targets (%arg24 = %controls_out_5) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %108 = arith.divf %arg10, %cst_2 : f64
    %109 = math.tan %108 : f64
    %110 = math.atan %109 : f64
    %111 = arith.mulf %110, %cst_2 : f64
    %112 = arith.addf %111, %cst_1 : f64
    %113 = qco.rz(%112) %targets_out_20 : !qco.qubit -> !qco.qubit
    %114 = qco.sx %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_0) %114 : !qco.qubit -> !qco.qubit
    %116 = qco.sx %115 : !qco.qubit -> !qco.qubit
    %117 = qco.rz(%cst) %116 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%117) targets (%arg24 = %controls_out_7) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %118 = arith.divf %arg11, %cst_2 : f64
    %119 = math.tan %118 : f64
    %120 = math.atan %119 : f64
    %121 = arith.mulf %120, %cst_2 : f64
    %122 = arith.addf %121, %cst_1 : f64
    %123 = qco.rz(%122) %targets_out_22 : !qco.qubit -> !qco.qubit
    %124 = qco.sx %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rz(%cst_0) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.sx %125 : !qco.qubit -> !qco.qubit
    %127 = qco.rz(%cst) %126 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%127) targets (%arg24 = %controls_out_9) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %128 = arith.divf %arg12, %cst_2 : f64
    %129 = math.tan %128 : f64
    %130 = math.atan %129 : f64
    %131 = arith.mulf %130, %cst_2 : f64
    %132 = arith.addf %131, %cst_1 : f64
    %133 = qco.rz(%132) %targets_out_24 : !qco.qubit -> !qco.qubit
    %134 = qco.sx %133 : !qco.qubit -> !qco.qubit
    %135 = qco.rz(%cst_0) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.sx %135 : !qco.qubit -> !qco.qubit
    %137 = qco.rz(%cst) %136 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%137) targets (%arg24 = %controls_out_11) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %138 = arith.divf %arg13, %cst_2 : f64
    %139 = math.tan %138 : f64
    %140 = math.atan %139 : f64
    %141 = arith.mulf %140, %cst_2 : f64
    %142 = arith.addf %141, %cst_1 : f64
    %143 = qco.rz(%142) %targets_out_26 : !qco.qubit -> !qco.qubit
    %144 = qco.sx %143 : !qco.qubit -> !qco.qubit
    %145 = qco.rz(%cst_0) %144 : !qco.qubit -> !qco.qubit
    %146 = qco.sx %145 : !qco.qubit -> !qco.qubit
    %147 = qco.rz(%cst) %146 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%147) targets (%arg24 = %controls_out_13) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %148 = arith.divf %arg14, %cst_2 : f64
    %149 = math.tan %148 : f64
    %150 = math.atan %149 : f64
    %151 = arith.mulf %150, %cst_2 : f64
    %152 = arith.addf %151, %cst_1 : f64
    %153 = qco.rz(%152) %targets_out_28 : !qco.qubit -> !qco.qubit
    %154 = qco.sx %153 : !qco.qubit -> !qco.qubit
    %155 = qco.rz(%cst_0) %154 : !qco.qubit -> !qco.qubit
    %156 = qco.sx %155 : !qco.qubit -> !qco.qubit
    %157 = qco.rz(%cst) %156 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%157) targets (%arg24 = %controls_out_15) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %158 = arith.divf %arg15, %cst_2 : f64
    %159 = math.tan %158 : f64
    %160 = math.atan %159 : f64
    %161 = arith.mulf %160, %cst_2 : f64
    %162 = arith.addf %161, %cst_1 : f64
    %163 = qco.rz(%162) %targets_out_30 : !qco.qubit -> !qco.qubit
    %164 = qco.sx %163 : !qco.qubit -> !qco.qubit
    %165 = qco.rz(%cst_0) %164 : !qco.qubit -> !qco.qubit
    %166 = qco.sx %165 : !qco.qubit -> !qco.qubit
    %167 = qco.rz(%cst) %166 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%167) targets (%arg24 = %controls_out_17) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %168 = arith.divf %arg16, %cst_2 : f64
    %169 = math.tan %168 : f64
    %170 = math.atan %169 : f64
    %171 = arith.mulf %170, %cst_2 : f64
    %172 = arith.addf %171, %cst_1 : f64
    %173 = qco.rz(%172) %targets_out_32 : !qco.qubit -> !qco.qubit
    %174 = qco.sx %173 : !qco.qubit -> !qco.qubit
    %175 = qco.rz(%cst_0) %174 : !qco.qubit -> !qco.qubit
    %176 = qco.sx %175 : !qco.qubit -> !qco.qubit
    %177 = qco.rz(%cst) %176 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%177) targets (%arg24 = %controls_out_19) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %178 = arith.divf %arg17, %cst_2 : f64
    %179 = math.tan %178 : f64
    %180 = math.atan %179 : f64
    %181 = arith.mulf %180, %cst_2 : f64
    %182 = arith.addf %181, %cst_1 : f64
    %183 = qco.rz(%182) %targets_out_34 : !qco.qubit -> !qco.qubit
    %184 = qco.sx %183 : !qco.qubit -> !qco.qubit
    %185 = qco.rz(%cst_0) %184 : !qco.qubit -> !qco.qubit
    %186 = qco.sx %185 : !qco.qubit -> !qco.qubit
    %187 = qco.rz(%cst) %186 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%187) targets (%arg24 = %controls_out_21) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %188 = arith.divf %arg18, %cst_2 : f64
    %189 = math.tan %188 : f64
    %190 = math.atan %189 : f64
    %191 = arith.mulf %190, %cst_2 : f64
    %192 = arith.addf %191, %cst_1 : f64
    %193 = qco.rz(%192) %targets_out_36 : !qco.qubit -> !qco.qubit
    %194 = qco.sx %193 : !qco.qubit -> !qco.qubit
    %195 = qco.rz(%cst_0) %194 : !qco.qubit -> !qco.qubit
    %196 = qco.sx %195 : !qco.qubit -> !qco.qubit
    %197 = qco.rz(%cst) %196 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%197) targets (%arg24 = %controls_out_23) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %198 = arith.divf %arg19, %cst_2 : f64
    %199 = math.tan %198 : f64
    %200 = math.atan %199 : f64
    %201 = arith.mulf %200, %cst_2 : f64
    %202 = arith.addf %201, %cst_1 : f64
    %203 = qco.rz(%202) %targets_out_38 : !qco.qubit -> !qco.qubit
    %204 = qco.sx %203 : !qco.qubit -> !qco.qubit
    %205 = qco.rz(%cst_0) %204 : !qco.qubit -> !qco.qubit
    %206 = qco.sx %205 : !qco.qubit -> !qco.qubit
    %207 = qco.rz(%cst) %206 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%207) targets (%arg24 = %controls_out_25) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %208 = arith.divf %arg20, %cst_2 : f64
    %209 = math.tan %208 : f64
    %210 = math.atan %209 : f64
    %211 = arith.mulf %210, %cst_2 : f64
    %212 = arith.addf %211, %cst_1 : f64
    %213 = qco.rz(%212) %targets_out_40 : !qco.qubit -> !qco.qubit
    %214 = qco.sx %213 : !qco.qubit -> !qco.qubit
    %215 = qco.rz(%cst_0) %214 : !qco.qubit -> !qco.qubit
    %216 = qco.sx %215 : !qco.qubit -> !qco.qubit
    %217 = qco.rz(%cst) %216 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%217) targets (%arg24 = %controls_out_27) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %218 = arith.divf %arg21, %cst_2 : f64
    %219 = math.tan %218 : f64
    %220 = math.atan %219 : f64
    %221 = arith.mulf %220, %cst_2 : f64
    %222 = arith.addf %221, %cst_1 : f64
    %223 = qco.rz(%222) %targets_out_42 : !qco.qubit -> !qco.qubit
    %224 = qco.sx %223 : !qco.qubit -> !qco.qubit
    %225 = qco.rz(%cst_0) %224 : !qco.qubit -> !qco.qubit
    %226 = qco.sx %225 : !qco.qubit -> !qco.qubit
    %227 = qco.rz(%cst) %226 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%227) targets (%arg24 = %controls_out_29) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %228 = arith.divf %arg22, %cst_2 : f64
    %229 = math.tan %228 : f64
    %230 = math.atan %229 : f64
    %231 = arith.mulf %230, %cst_2 : f64
    %232 = arith.addf %231, %cst_1 : f64
    %233 = qco.rz(%232) %targets_out_44 : !qco.qubit -> !qco.qubit
    %234 = qco.sx %233 : !qco.qubit -> !qco.qubit
    %235 = qco.rz(%cst_0) %234 : !qco.qubit -> !qco.qubit
    %236 = qco.sx %235 : !qco.qubit -> !qco.qubit
    %237 = qco.rz(%cst) %236 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%237) targets (%arg24 = %controls_out_31) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %238 = arith.divf %arg23, %cst_2 : f64
    %239 = math.tan %238 : f64
    %240 = math.atan %239 : f64
    %241 = arith.mulf %240, %cst_2 : f64
    %242 = arith.addf %241, %cst_1 : f64
    %243 = qco.rz(%242) %targets_out_46 : !qco.qubit -> !qco.qubit
    %244 = qco.sx %243 : !qco.qubit -> !qco.qubit
    %245 = qco.rz(%cst_0) %244 : !qco.qubit -> !qco.qubit
    %246 = qco.sx %245 : !qco.qubit -> !qco.qubit
    %247 = qco.rz(%cst) %246 : !qco.qubit -> !qco.qubit
    qco.sink %controls_out_35 : !qco.qubit
    qco.sink %controls_out_37 : !qco.qubit
    qco.sink %controls_out_39 : !qco.qubit
    qco.sink %controls_out_41 : !qco.qubit
    qco.sink %controls_out_43 : !qco.qubit
    qco.sink %controls_out_45 : !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%247) targets (%arg24 = %controls_out_33) {
      %248 = qco.z %arg24 : !qco.qubit -> !qco.qubit
      qco.yield %248 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    qco.sink %targets_out_48 : !qco.qubit
    qco.sink %controls_out_47 : !qco.qubit
    return %c0_i64 : i64
  }
}
