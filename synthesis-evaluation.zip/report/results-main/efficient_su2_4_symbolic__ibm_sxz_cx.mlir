module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main(%arg0: f64 {mqt.input_id = -120262898746132594670008414538420507071 : i128, mqt.input_name = "\CE\B8[0]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 0 : i64, name = "\CE\B8", size = 32 : i64}}, %arg1: f64 {mqt.input_id = -120262898746132594670008414538420507070 : i128, mqt.input_name = "\CE\B8[1]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 1 : i64, name = "\CE\B8", size = 32 : i64}}, %arg2: f64 {mqt.input_id = -120262898746132594670008414538420507069 : i128, mqt.input_name = "\CE\B8[2]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 2 : i64, name = "\CE\B8", size = 32 : i64}}, %arg3: f64 {mqt.input_id = -120262898746132594670008414538420507068 : i128, mqt.input_name = "\CE\B8[3]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 3 : i64, name = "\CE\B8", size = 32 : i64}}, %arg4: f64 {mqt.input_id = -120262898746132594670008414538420507067 : i128, mqt.input_name = "\CE\B8[4]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 4 : i64, name = "\CE\B8", size = 32 : i64}}, %arg5: f64 {mqt.input_id = -120262898746132594670008414538420507066 : i128, mqt.input_name = "\CE\B8[5]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 5 : i64, name = "\CE\B8", size = 32 : i64}}, %arg6: f64 {mqt.input_id = -120262898746132594670008414538420507065 : i128, mqt.input_name = "\CE\B8[6]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 6 : i64, name = "\CE\B8", size = 32 : i64}}, %arg7: f64 {mqt.input_id = -120262898746132594670008414538420507064 : i128, mqt.input_name = "\CE\B8[7]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 7 : i64, name = "\CE\B8", size = 32 : i64}}, %arg8: f64 {mqt.input_id = -120262898746132594670008414538420507063 : i128, mqt.input_name = "\CE\B8[8]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 8 : i64, name = "\CE\B8", size = 32 : i64}}, %arg9: f64 {mqt.input_id = -120262898746132594670008414538420507062 : i128, mqt.input_name = "\CE\B8[9]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 9 : i64, name = "\CE\B8", size = 32 : i64}}, %arg10: f64 {mqt.input_id = -120262898746132594670008414538420507061 : i128, mqt.input_name = "\CE\B8[10]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 10 : i64, name = "\CE\B8", size = 32 : i64}}, %arg11: f64 {mqt.input_id = -120262898746132594670008414538420507060 : i128, mqt.input_name = "\CE\B8[11]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 11 : i64, name = "\CE\B8", size = 32 : i64}}, %arg12: f64 {mqt.input_id = -120262898746132594670008414538420507059 : i128, mqt.input_name = "\CE\B8[12]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 12 : i64, name = "\CE\B8", size = 32 : i64}}, %arg13: f64 {mqt.input_id = -120262898746132594670008414538420507058 : i128, mqt.input_name = "\CE\B8[13]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 13 : i64, name = "\CE\B8", size = 32 : i64}}, %arg14: f64 {mqt.input_id = -120262898746132594670008414538420507057 : i128, mqt.input_name = "\CE\B8[14]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 14 : i64, name = "\CE\B8", size = 32 : i64}}, %arg15: f64 {mqt.input_id = -120262898746132594670008414538420507056 : i128, mqt.input_name = "\CE\B8[15]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 15 : i64, name = "\CE\B8", size = 32 : i64}}, %arg16: f64 {mqt.input_id = -120262898746132594670008414538420507055 : i128, mqt.input_name = "\CE\B8[16]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 16 : i64, name = "\CE\B8", size = 32 : i64}}, %arg17: f64 {mqt.input_id = -120262898746132594670008414538420507054 : i128, mqt.input_name = "\CE\B8[17]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 17 : i64, name = "\CE\B8", size = 32 : i64}}, %arg18: f64 {mqt.input_id = -120262898746132594670008414538420507053 : i128, mqt.input_name = "\CE\B8[18]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 18 : i64, name = "\CE\B8", size = 32 : i64}}, %arg19: f64 {mqt.input_id = -120262898746132594670008414538420507052 : i128, mqt.input_name = "\CE\B8[19]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 19 : i64, name = "\CE\B8", size = 32 : i64}}, %arg20: f64 {mqt.input_id = -120262898746132594670008414538420507051 : i128, mqt.input_name = "\CE\B8[20]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 20 : i64, name = "\CE\B8", size = 32 : i64}}, %arg21: f64 {mqt.input_id = -120262898746132594670008414538420507050 : i128, mqt.input_name = "\CE\B8[21]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 21 : i64, name = "\CE\B8", size = 32 : i64}}, %arg22: f64 {mqt.input_id = -120262898746132594670008414538420507049 : i128, mqt.input_name = "\CE\B8[22]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 22 : i64, name = "\CE\B8", size = 32 : i64}}, %arg23: f64 {mqt.input_id = -120262898746132594670008414538420507048 : i128, mqt.input_name = "\CE\B8[23]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 23 : i64, name = "\CE\B8", size = 32 : i64}}, %arg24: f64 {mqt.input_id = -120262898746132594670008414538420507047 : i128, mqt.input_name = "\CE\B8[24]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 24 : i64, name = "\CE\B8", size = 32 : i64}}, %arg25: f64 {mqt.input_id = -120262898746132594670008414538420507046 : i128, mqt.input_name = "\CE\B8[25]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 25 : i64, name = "\CE\B8", size = 32 : i64}}, %arg26: f64 {mqt.input_id = -120262898746132594670008414538420507045 : i128, mqt.input_name = "\CE\B8[26]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 26 : i64, name = "\CE\B8", size = 32 : i64}}, %arg27: f64 {mqt.input_id = -120262898746132594670008414538420507044 : i128, mqt.input_name = "\CE\B8[27]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 27 : i64, name = "\CE\B8", size = 32 : i64}}, %arg28: f64 {mqt.input_id = -120262898746132594670008414538420507043 : i128, mqt.input_name = "\CE\B8[28]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 28 : i64, name = "\CE\B8", size = 32 : i64}}, %arg29: f64 {mqt.input_id = -120262898746132594670008414538420507042 : i128, mqt.input_name = "\CE\B8[29]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 29 : i64, name = "\CE\B8", size = 32 : i64}}, %arg30: f64 {mqt.input_id = -120262898746132594670008414538420507041 : i128, mqt.input_name = "\CE\B8[30]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 30 : i64, name = "\CE\B8", size = 32 : i64}}, %arg31: f64 {mqt.input_id = -120262898746132594670008414538420507040 : i128, mqt.input_name = "\CE\B8[31]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 31 : i64, name = "\CE\B8", size = 32 : i64}}) -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 4.000000e+00 : f64
    %cst_0 = arith.constant 3.1415926535897931 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = arith.divf %arg0, %cst : f64
    %5 = math.tan %4 : f64
    %6 = math.atan %5 : f64
    %7 = arith.mulf %6, %cst : f64
    %8 = qco.sx %0 : !qco.qubit -> !qco.qubit
    %9 = arith.addf %7, %cst_0 : f64
    %10 = qco.rz(%9) %8 : !qco.qubit -> !qco.qubit
    %11 = qco.sx %10 : !qco.qubit -> !qco.qubit
    %12 = arith.divf %arg1, %cst : f64
    %13 = math.tan %12 : f64
    %14 = math.atan %13 : f64
    %15 = arith.mulf %14, %cst : f64
    %16 = qco.sx %1 : !qco.qubit -> !qco.qubit
    %17 = arith.addf %15, %cst_0 : f64
    %18 = qco.rz(%17) %16 : !qco.qubit -> !qco.qubit
    %19 = qco.sx %18 : !qco.qubit -> !qco.qubit
    %20 = arith.divf %arg2, %cst : f64
    %21 = math.tan %20 : f64
    %22 = math.atan %21 : f64
    %23 = arith.mulf %22, %cst : f64
    %24 = qco.sx %2 : !qco.qubit -> !qco.qubit
    %25 = arith.addf %23, %cst_0 : f64
    %26 = qco.rz(%25) %24 : !qco.qubit -> !qco.qubit
    %27 = qco.sx %26 : !qco.qubit -> !qco.qubit
    %28 = arith.divf %arg3, %cst : f64
    %29 = math.tan %28 : f64
    %30 = math.atan %29 : f64
    %31 = arith.mulf %30, %cst : f64
    %32 = qco.sx %3 : !qco.qubit -> !qco.qubit
    %33 = arith.addf %31, %cst_0 : f64
    %34 = qco.rz(%33) %32 : !qco.qubit -> !qco.qubit
    %35 = qco.sx %34 : !qco.qubit -> !qco.qubit
    %36 = arith.divf %arg4, %cst : f64
    %37 = math.tan %36 : f64
    %38 = math.atan %37 : f64
    %39 = arith.mulf %38, %cst : f64
    %40 = arith.addf %39, %cst_0 : f64
    %41 = qco.rz(%40) %11 : !qco.qubit -> !qco.qubit
    %42 = arith.divf %arg5, %cst : f64
    %43 = math.tan %42 : f64
    %44 = math.atan %43 : f64
    %45 = arith.mulf %44, %cst : f64
    %46 = arith.addf %45, %cst_0 : f64
    %47 = qco.rz(%46) %19 : !qco.qubit -> !qco.qubit
    %48 = arith.divf %arg6, %cst : f64
    %49 = math.tan %48 : f64
    %50 = math.atan %49 : f64
    %51 = arith.mulf %50, %cst : f64
    %52 = arith.addf %51, %cst_0 : f64
    %53 = qco.rz(%52) %27 : !qco.qubit -> !qco.qubit
    %54 = arith.divf %arg7, %cst : f64
    %55 = math.tan %54 : f64
    %56 = math.atan %55 : f64
    %57 = arith.mulf %56, %cst : f64
    %58 = arith.addf %57, %cst_0 : f64
    %59 = qco.rz(%58) %35 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%59) targets (%arg32 = %41) {
      %228 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %228 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_1, %targets_out_2 = qco.ctrl(%targets_out) targets (%arg32 = %47) {
      %228 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %228 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_3, %targets_out_4 = qco.ctrl(%targets_out_2) targets (%arg32 = %53) {
      %228 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %228 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_5, %targets_out_6 = qco.ctrl(%targets_out_4) targets (%arg32 = %controls_out) {
      %228 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %228 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = arith.divf %arg8, %cst : f64
    %61 = math.tan %60 : f64
    %62 = math.atan %61 : f64
    %63 = arith.mulf %62, %cst : f64
    %64 = qco.sx %controls_out_1 : !qco.qubit -> !qco.qubit
    %65 = arith.addf %63, %cst_0 : f64
    %66 = qco.rz(%65) %64 : !qco.qubit -> !qco.qubit
    %67 = qco.sx %66 : !qco.qubit -> !qco.qubit
    %68 = arith.divf %arg9, %cst : f64
    %69 = math.tan %68 : f64
    %70 = math.atan %69 : f64
    %71 = arith.mulf %70, %cst : f64
    %72 = qco.sx %controls_out_3 : !qco.qubit -> !qco.qubit
    %73 = arith.addf %71, %cst_0 : f64
    %74 = qco.rz(%73) %72 : !qco.qubit -> !qco.qubit
    %75 = qco.sx %74 : !qco.qubit -> !qco.qubit
    %76 = arith.divf %arg10, %cst : f64
    %77 = math.tan %76 : f64
    %78 = math.atan %77 : f64
    %79 = arith.mulf %78, %cst : f64
    %80 = qco.sx %controls_out_5 : !qco.qubit -> !qco.qubit
    %81 = arith.addf %79, %cst_0 : f64
    %82 = qco.rz(%81) %80 : !qco.qubit -> !qco.qubit
    %83 = qco.sx %82 : !qco.qubit -> !qco.qubit
    %84 = arith.divf %arg11, %cst : f64
    %85 = math.tan %84 : f64
    %86 = math.atan %85 : f64
    %87 = arith.mulf %86, %cst : f64
    %88 = qco.sx %targets_out_6 : !qco.qubit -> !qco.qubit
    %89 = arith.addf %87, %cst_0 : f64
    %90 = qco.rz(%89) %88 : !qco.qubit -> !qco.qubit
    %91 = qco.sx %90 : !qco.qubit -> !qco.qubit
    %92 = arith.divf %arg12, %cst : f64
    %93 = math.tan %92 : f64
    %94 = math.atan %93 : f64
    %95 = arith.mulf %94, %cst : f64
    %96 = arith.addf %95, %cst_0 : f64
    %97 = qco.rz(%96) %67 : !qco.qubit -> !qco.qubit
    %98 = arith.divf %arg13, %cst : f64
    %99 = math.tan %98 : f64
    %100 = math.atan %99 : f64
    %101 = arith.mulf %100, %cst : f64
    %102 = arith.addf %101, %cst_0 : f64
    %103 = qco.rz(%102) %75 : !qco.qubit -> !qco.qubit
    %104 = arith.divf %arg14, %cst : f64
    %105 = math.tan %104 : f64
    %106 = math.atan %105 : f64
    %107 = arith.mulf %106, %cst : f64
    %108 = arith.addf %107, %cst_0 : f64
    %109 = qco.rz(%108) %83 : !qco.qubit -> !qco.qubit
    %110 = arith.divf %arg15, %cst : f64
    %111 = math.tan %110 : f64
    %112 = math.atan %111 : f64
    %113 = arith.mulf %112, %cst : f64
    %114 = arith.addf %113, %cst_0 : f64
    %115 = qco.rz(%114) %91 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%115) targets (%arg32 = %97) {
      %228 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %228 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_9, %targets_out_10 = qco.ctrl(%targets_out_8) targets (%arg32 = %103) {
      %228 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %228 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_11, %targets_out_12 = qco.ctrl(%targets_out_10) targets (%arg32 = %109) {
      %228 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %228 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_13, %targets_out_14 = qco.ctrl(%targets_out_12) targets (%arg32 = %controls_out_7) {
      %228 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %228 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %116 = arith.divf %arg16, %cst : f64
    %117 = math.tan %116 : f64
    %118 = math.atan %117 : f64
    %119 = arith.mulf %118, %cst : f64
    %120 = qco.sx %controls_out_9 : !qco.qubit -> !qco.qubit
    %121 = arith.addf %119, %cst_0 : f64
    %122 = qco.rz(%121) %120 : !qco.qubit -> !qco.qubit
    %123 = qco.sx %122 : !qco.qubit -> !qco.qubit
    %124 = arith.divf %arg17, %cst : f64
    %125 = math.tan %124 : f64
    %126 = math.atan %125 : f64
    %127 = arith.mulf %126, %cst : f64
    %128 = qco.sx %controls_out_11 : !qco.qubit -> !qco.qubit
    %129 = arith.addf %127, %cst_0 : f64
    %130 = qco.rz(%129) %128 : !qco.qubit -> !qco.qubit
    %131 = qco.sx %130 : !qco.qubit -> !qco.qubit
    %132 = arith.divf %arg18, %cst : f64
    %133 = math.tan %132 : f64
    %134 = math.atan %133 : f64
    %135 = arith.mulf %134, %cst : f64
    %136 = qco.sx %controls_out_13 : !qco.qubit -> !qco.qubit
    %137 = arith.addf %135, %cst_0 : f64
    %138 = qco.rz(%137) %136 : !qco.qubit -> !qco.qubit
    %139 = qco.sx %138 : !qco.qubit -> !qco.qubit
    %140 = arith.divf %arg19, %cst : f64
    %141 = math.tan %140 : f64
    %142 = math.atan %141 : f64
    %143 = arith.mulf %142, %cst : f64
    %144 = qco.sx %targets_out_14 : !qco.qubit -> !qco.qubit
    %145 = arith.addf %143, %cst_0 : f64
    %146 = qco.rz(%145) %144 : !qco.qubit -> !qco.qubit
    %147 = qco.sx %146 : !qco.qubit -> !qco.qubit
    %148 = arith.divf %arg20, %cst : f64
    %149 = math.tan %148 : f64
    %150 = math.atan %149 : f64
    %151 = arith.mulf %150, %cst : f64
    %152 = arith.addf %151, %cst_0 : f64
    %153 = qco.rz(%152) %123 : !qco.qubit -> !qco.qubit
    %154 = arith.divf %arg21, %cst : f64
    %155 = math.tan %154 : f64
    %156 = math.atan %155 : f64
    %157 = arith.mulf %156, %cst : f64
    %158 = arith.addf %157, %cst_0 : f64
    %159 = qco.rz(%158) %131 : !qco.qubit -> !qco.qubit
    %160 = arith.divf %arg22, %cst : f64
    %161 = math.tan %160 : f64
    %162 = math.atan %161 : f64
    %163 = arith.mulf %162, %cst : f64
    %164 = arith.addf %163, %cst_0 : f64
    %165 = qco.rz(%164) %139 : !qco.qubit -> !qco.qubit
    %166 = arith.divf %arg23, %cst : f64
    %167 = math.tan %166 : f64
    %168 = math.atan %167 : f64
    %169 = arith.mulf %168, %cst : f64
    %170 = arith.addf %169, %cst_0 : f64
    %171 = qco.rz(%170) %147 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%171) targets (%arg32 = %153) {
      %228 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %228 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_17, %targets_out_18 = qco.ctrl(%targets_out_16) targets (%arg32 = %159) {
      %228 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %228 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_19, %targets_out_20 = qco.ctrl(%targets_out_18) targets (%arg32 = %165) {
      %228 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %228 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_21, %targets_out_22 = qco.ctrl(%targets_out_20) targets (%arg32 = %controls_out_15) {
      %228 = qco.x %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %228 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %172 = arith.divf %arg24, %cst : f64
    %173 = math.tan %172 : f64
    %174 = math.atan %173 : f64
    %175 = arith.mulf %174, %cst : f64
    %176 = qco.sx %controls_out_17 : !qco.qubit -> !qco.qubit
    %177 = arith.addf %175, %cst_0 : f64
    %178 = qco.rz(%177) %176 : !qco.qubit -> !qco.qubit
    %179 = qco.sx %178 : !qco.qubit -> !qco.qubit
    %180 = arith.divf %arg25, %cst : f64
    %181 = math.tan %180 : f64
    %182 = math.atan %181 : f64
    %183 = arith.mulf %182, %cst : f64
    %184 = qco.sx %controls_out_19 : !qco.qubit -> !qco.qubit
    %185 = arith.addf %183, %cst_0 : f64
    %186 = qco.rz(%185) %184 : !qco.qubit -> !qco.qubit
    %187 = qco.sx %186 : !qco.qubit -> !qco.qubit
    %188 = arith.divf %arg26, %cst : f64
    %189 = math.tan %188 : f64
    %190 = math.atan %189 : f64
    %191 = arith.mulf %190, %cst : f64
    %192 = qco.sx %controls_out_21 : !qco.qubit -> !qco.qubit
    %193 = arith.addf %191, %cst_0 : f64
    %194 = qco.rz(%193) %192 : !qco.qubit -> !qco.qubit
    %195 = qco.sx %194 : !qco.qubit -> !qco.qubit
    %196 = arith.divf %arg27, %cst : f64
    %197 = math.tan %196 : f64
    %198 = math.atan %197 : f64
    %199 = arith.mulf %198, %cst : f64
    %200 = qco.sx %targets_out_22 : !qco.qubit -> !qco.qubit
    %201 = arith.addf %199, %cst_0 : f64
    %202 = qco.rz(%201) %200 : !qco.qubit -> !qco.qubit
    %203 = qco.sx %202 : !qco.qubit -> !qco.qubit
    %204 = arith.divf %arg28, %cst : f64
    %205 = math.tan %204 : f64
    %206 = math.atan %205 : f64
    %207 = arith.mulf %206, %cst : f64
    %208 = arith.addf %207, %cst_0 : f64
    %209 = qco.rz(%208) %179 : !qco.qubit -> !qco.qubit
    %210 = arith.divf %arg29, %cst : f64
    %211 = math.tan %210 : f64
    %212 = math.atan %211 : f64
    %213 = arith.mulf %212, %cst : f64
    %214 = arith.addf %213, %cst_0 : f64
    %215 = qco.rz(%214) %187 : !qco.qubit -> !qco.qubit
    %216 = arith.divf %arg30, %cst : f64
    %217 = math.tan %216 : f64
    %218 = math.atan %217 : f64
    %219 = arith.mulf %218, %cst : f64
    %220 = arith.addf %219, %cst_0 : f64
    %221 = qco.rz(%220) %195 : !qco.qubit -> !qco.qubit
    qco.sink %209 : !qco.qubit
    qco.sink %215 : !qco.qubit
    qco.sink %221 : !qco.qubit
    %222 = arith.divf %arg31, %cst : f64
    %223 = math.tan %222 : f64
    %224 = math.atan %223 : f64
    %225 = arith.mulf %224, %cst : f64
    %226 = arith.addf %225, %cst_0 : f64
    %227 = qco.rz(%226) %203 : !qco.qubit -> !qco.qubit
    qco.sink %227 : !qco.qubit
    return %c0_i64 : i64
  }
}
