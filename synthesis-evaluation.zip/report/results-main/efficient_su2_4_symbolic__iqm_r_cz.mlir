module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main(%arg0: f64 {mqt.input_id = -120262898746132594670008414538420507071 : i128, mqt.input_name = "\CE\B8[0]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 0 : i64, name = "\CE\B8", size = 32 : i64}}, %arg1: f64 {mqt.input_id = -120262898746132594670008414538420507070 : i128, mqt.input_name = "\CE\B8[1]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 1 : i64, name = "\CE\B8", size = 32 : i64}}, %arg2: f64 {mqt.input_id = -120262898746132594670008414538420507069 : i128, mqt.input_name = "\CE\B8[2]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 2 : i64, name = "\CE\B8", size = 32 : i64}}, %arg3: f64 {mqt.input_id = -120262898746132594670008414538420507068 : i128, mqt.input_name = "\CE\B8[3]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 3 : i64, name = "\CE\B8", size = 32 : i64}}, %arg4: f64 {mqt.input_id = -120262898746132594670008414538420507067 : i128, mqt.input_name = "\CE\B8[4]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 4 : i64, name = "\CE\B8", size = 32 : i64}}, %arg5: f64 {mqt.input_id = -120262898746132594670008414538420507066 : i128, mqt.input_name = "\CE\B8[5]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 5 : i64, name = "\CE\B8", size = 32 : i64}}, %arg6: f64 {mqt.input_id = -120262898746132594670008414538420507065 : i128, mqt.input_name = "\CE\B8[6]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 6 : i64, name = "\CE\B8", size = 32 : i64}}, %arg7: f64 {mqt.input_id = -120262898746132594670008414538420507064 : i128, mqt.input_name = "\CE\B8[7]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 7 : i64, name = "\CE\B8", size = 32 : i64}}, %arg8: f64 {mqt.input_id = -120262898746132594670008414538420507063 : i128, mqt.input_name = "\CE\B8[8]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 8 : i64, name = "\CE\B8", size = 32 : i64}}, %arg9: f64 {mqt.input_id = -120262898746132594670008414538420507062 : i128, mqt.input_name = "\CE\B8[9]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 9 : i64, name = "\CE\B8", size = 32 : i64}}, %arg10: f64 {mqt.input_id = -120262898746132594670008414538420507061 : i128, mqt.input_name = "\CE\B8[10]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 10 : i64, name = "\CE\B8", size = 32 : i64}}, %arg11: f64 {mqt.input_id = -120262898746132594670008414538420507060 : i128, mqt.input_name = "\CE\B8[11]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 11 : i64, name = "\CE\B8", size = 32 : i64}}, %arg12: f64 {mqt.input_id = -120262898746132594670008414538420507059 : i128, mqt.input_name = "\CE\B8[12]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 12 : i64, name = "\CE\B8", size = 32 : i64}}, %arg13: f64 {mqt.input_id = -120262898746132594670008414538420507058 : i128, mqt.input_name = "\CE\B8[13]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 13 : i64, name = "\CE\B8", size = 32 : i64}}, %arg14: f64 {mqt.input_id = -120262898746132594670008414538420507057 : i128, mqt.input_name = "\CE\B8[14]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 14 : i64, name = "\CE\B8", size = 32 : i64}}, %arg15: f64 {mqt.input_id = -120262898746132594670008414538420507056 : i128, mqt.input_name = "\CE\B8[15]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 15 : i64, name = "\CE\B8", size = 32 : i64}}, %arg16: f64 {mqt.input_id = -120262898746132594670008414538420507055 : i128, mqt.input_name = "\CE\B8[16]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 16 : i64, name = "\CE\B8", size = 32 : i64}}, %arg17: f64 {mqt.input_id = -120262898746132594670008414538420507054 : i128, mqt.input_name = "\CE\B8[17]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 17 : i64, name = "\CE\B8", size = 32 : i64}}, %arg18: f64 {mqt.input_id = -120262898746132594670008414538420507053 : i128, mqt.input_name = "\CE\B8[18]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 18 : i64, name = "\CE\B8", size = 32 : i64}}, %arg19: f64 {mqt.input_id = -120262898746132594670008414538420507052 : i128, mqt.input_name = "\CE\B8[19]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 19 : i64, name = "\CE\B8", size = 32 : i64}}, %arg20: f64 {mqt.input_id = -120262898746132594670008414538420507051 : i128, mqt.input_name = "\CE\B8[20]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 20 : i64, name = "\CE\B8", size = 32 : i64}}, %arg21: f64 {mqt.input_id = -120262898746132594670008414538420507050 : i128, mqt.input_name = "\CE\B8[21]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 21 : i64, name = "\CE\B8", size = 32 : i64}}, %arg22: f64 {mqt.input_id = -120262898746132594670008414538420507049 : i128, mqt.input_name = "\CE\B8[22]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 22 : i64, name = "\CE\B8", size = 32 : i64}}, %arg23: f64 {mqt.input_id = -120262898746132594670008414538420507048 : i128, mqt.input_name = "\CE\B8[23]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 23 : i64, name = "\CE\B8", size = 32 : i64}}, %arg24: f64 {mqt.input_id = -120262898746132594670008414538420507047 : i128, mqt.input_name = "\CE\B8[24]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 24 : i64, name = "\CE\B8", size = 32 : i64}}, %arg25: f64 {mqt.input_id = -120262898746132594670008414538420507046 : i128, mqt.input_name = "\CE\B8[25]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 25 : i64, name = "\CE\B8", size = 32 : i64}}, %arg26: f64 {mqt.input_id = -120262898746132594670008414538420507045 : i128, mqt.input_name = "\CE\B8[26]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 26 : i64, name = "\CE\B8", size = 32 : i64}}, %arg27: f64 {mqt.input_id = -120262898746132594670008414538420507044 : i128, mqt.input_name = "\CE\B8[27]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 27 : i64, name = "\CE\B8", size = 32 : i64}}, %arg28: f64 {mqt.input_id = -120262898746132594670008414538420507043 : i128, mqt.input_name = "\CE\B8[28]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 28 : i64, name = "\CE\B8", size = 32 : i64}}, %arg29: f64 {mqt.input_id = -120262898746132594670008414538420507042 : i128, mqt.input_name = "\CE\B8[29]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 29 : i64, name = "\CE\B8", size = 32 : i64}}, %arg30: f64 {mqt.input_id = -120262898746132594670008414538420507041 : i128, mqt.input_name = "\CE\B8[30]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 30 : i64, name = "\CE\B8", size = 32 : i64}}, %arg31: f64 {mqt.input_id = -120262898746132594670008414538420507040 : i128, mqt.input_name = "\CE\B8[31]", mqt.parameter_group = {identity = "a586354d-4a3b-4be3-8c17-14435f872e41", index = 31 : i64, name = "\CE\B8", size = 32 : i64}}) -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 6.2831853071795862 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant 4.000000e+00 : f64
    %cst_2 = arith.constant 3.1415926535897931 : f64
    %cst_3 = arith.constant 2.000000e+00 : f64
    %cst_4 = arith.constant 0.000000e+00 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.r(%arg0, %cst_0) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.r(%arg1, %cst_0) %1 : !qco.qubit -> !qco.qubit
    %6 = qco.r(%arg2, %cst_0) %2 : !qco.qubit -> !qco.qubit
    %7 = qco.r(%arg3, %cst_0) %3 : !qco.qubit -> !qco.qubit
    %8 = arith.divf %arg4, %cst_1 : f64
    %9 = math.tan %8 : f64
    %10 = math.atan %9 : f64
    %11 = arith.mulf %10, %cst_1 : f64
    %12 = arith.divf %cst_2, %cst_3 : f64
    %13 = arith.negf %12 : f64
    %14 = qco.r(%13, %cst_4) %4 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%11, %12) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%12, %cst_4) %15 : !qco.qubit -> !qco.qubit
    %17 = arith.divf %arg5, %cst_1 : f64
    %18 = math.tan %17 : f64
    %19 = math.atan %18 : f64
    %20 = arith.mulf %19, %cst_1 : f64
    %21 = qco.r(%13, %cst_4) %5 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%20, %12) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%12, %cst_4) %22 : !qco.qubit -> !qco.qubit
    %24 = arith.divf %arg6, %cst_1 : f64
    %25 = math.tan %24 : f64
    %26 = math.atan %25 : f64
    %27 = arith.mulf %26, %cst_1 : f64
    %28 = qco.r(%13, %cst_4) %6 : !qco.qubit -> !qco.qubit
    %29 = qco.r(%27, %12) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%12, %cst_4) %29 : !qco.qubit -> !qco.qubit
    %31 = arith.divf %arg7, %cst_1 : f64
    %32 = math.tan %31 : f64
    %33 = math.atan %32 : f64
    %34 = arith.mulf %33, %cst_1 : f64
    %35 = qco.r(%13, %cst_4) %7 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%34, %12) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%12, %cst_4) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst_2, %cst_4) %16 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst_0, %cst_0) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_2, %cst_4) %39 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%37) targets (%arg32 = %40) {
      %194 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %194 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.r(%cst_0, %cst_0) %targets_out : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst, %cst_4) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%cst_2, %cst_4) %23 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_0, %cst_0) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst_2, %cst_4) %44 : !qco.qubit -> !qco.qubit
    %controls_out_5, %targets_out_6 = qco.ctrl(%42) targets (%arg32 = %45) {
      %194 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %194 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = qco.r(%cst_0, %cst_0) %targets_out_6 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%cst, %cst_4) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst_2, %cst_4) %30 : !qco.qubit -> !qco.qubit
    %49 = qco.r(%cst_0, %cst_0) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.r(%cst_2, %cst_4) %49 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%47) targets (%arg32 = %50) {
      %194 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %194 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %51 = qco.r(%cst_0, %cst_0) %targets_out_8 : !qco.qubit -> !qco.qubit
    %52 = qco.r(%cst, %cst_4) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst_2, %cst_4) %controls_out : !qco.qubit -> !qco.qubit
    %54 = qco.r(%cst_0, %cst_0) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.r(%cst_2, %cst_4) %54 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%52) targets (%arg32 = %55) {
      %194 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %194 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qco.r(%cst_0, %cst_0) %targets_out_10 : !qco.qubit -> !qco.qubit
    %57 = qco.r(%cst, %cst_4) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.r(%arg8, %cst_0) %controls_out_5 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%arg9, %cst_0) %controls_out_7 : !qco.qubit -> !qco.qubit
    %60 = qco.r(%arg10, %cst_0) %controls_out_9 : !qco.qubit -> !qco.qubit
    %61 = qco.r(%arg11, %cst_0) %57 : !qco.qubit -> !qco.qubit
    %62 = arith.divf %arg12, %cst_1 : f64
    %63 = math.tan %62 : f64
    %64 = math.atan %63 : f64
    %65 = arith.mulf %64, %cst_1 : f64
    %66 = qco.r(%13, %cst_4) %58 : !qco.qubit -> !qco.qubit
    %67 = qco.r(%65, %12) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.r(%12, %cst_4) %67 : !qco.qubit -> !qco.qubit
    %69 = arith.divf %arg13, %cst_1 : f64
    %70 = math.tan %69 : f64
    %71 = math.atan %70 : f64
    %72 = arith.mulf %71, %cst_1 : f64
    %73 = qco.r(%13, %cst_4) %59 : !qco.qubit -> !qco.qubit
    %74 = qco.r(%72, %12) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.r(%12, %cst_4) %74 : !qco.qubit -> !qco.qubit
    %76 = arith.divf %arg14, %cst_1 : f64
    %77 = math.tan %76 : f64
    %78 = math.atan %77 : f64
    %79 = arith.mulf %78, %cst_1 : f64
    %80 = qco.r(%13, %cst_4) %60 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%79, %12) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.r(%12, %cst_4) %81 : !qco.qubit -> !qco.qubit
    %83 = arith.divf %arg15, %cst_1 : f64
    %84 = math.tan %83 : f64
    %85 = math.atan %84 : f64
    %86 = arith.mulf %85, %cst_1 : f64
    %87 = qco.r(%13, %cst_4) %61 : !qco.qubit -> !qco.qubit
    %88 = qco.r(%86, %12) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%12, %cst_4) %88 : !qco.qubit -> !qco.qubit
    %90 = qco.r(%cst_2, %cst_4) %68 : !qco.qubit -> !qco.qubit
    %91 = qco.r(%cst_0, %cst_0) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.r(%cst_2, %cst_4) %91 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%89) targets (%arg32 = %92) {
      %194 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %194 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %93 = qco.r(%cst_0, %cst_0) %targets_out_12 : !qco.qubit -> !qco.qubit
    %94 = qco.r(%cst, %cst_4) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.r(%cst_2, %cst_4) %75 : !qco.qubit -> !qco.qubit
    %96 = qco.r(%cst_0, %cst_0) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.r(%cst_2, %cst_4) %96 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%94) targets (%arg32 = %97) {
      %194 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %194 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %98 = qco.r(%cst_0, %cst_0) %targets_out_14 : !qco.qubit -> !qco.qubit
    %99 = qco.r(%cst, %cst_4) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.r(%cst_2, %cst_4) %82 : !qco.qubit -> !qco.qubit
    %101 = qco.r(%cst_0, %cst_0) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.r(%cst_2, %cst_4) %101 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%99) targets (%arg32 = %102) {
      %194 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %194 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %103 = qco.r(%cst_0, %cst_0) %targets_out_16 : !qco.qubit -> !qco.qubit
    %104 = qco.r(%cst, %cst_4) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.r(%cst_2, %cst_4) %controls_out_11 : !qco.qubit -> !qco.qubit
    %106 = qco.r(%cst_0, %cst_0) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.r(%cst_2, %cst_4) %106 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%104) targets (%arg32 = %107) {
      %194 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %194 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %108 = qco.r(%cst_0, %cst_0) %targets_out_18 : !qco.qubit -> !qco.qubit
    %109 = qco.r(%cst, %cst_4) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.r(%arg16, %cst_0) %controls_out_13 : !qco.qubit -> !qco.qubit
    %111 = qco.r(%arg17, %cst_0) %controls_out_15 : !qco.qubit -> !qco.qubit
    %112 = qco.r(%arg18, %cst_0) %controls_out_17 : !qco.qubit -> !qco.qubit
    %113 = qco.r(%arg19, %cst_0) %109 : !qco.qubit -> !qco.qubit
    %114 = arith.divf %arg20, %cst_1 : f64
    %115 = math.tan %114 : f64
    %116 = math.atan %115 : f64
    %117 = arith.mulf %116, %cst_1 : f64
    %118 = qco.r(%13, %cst_4) %110 : !qco.qubit -> !qco.qubit
    %119 = qco.r(%117, %12) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.r(%12, %cst_4) %119 : !qco.qubit -> !qco.qubit
    %121 = arith.divf %arg21, %cst_1 : f64
    %122 = math.tan %121 : f64
    %123 = math.atan %122 : f64
    %124 = arith.mulf %123, %cst_1 : f64
    %125 = qco.r(%13, %cst_4) %111 : !qco.qubit -> !qco.qubit
    %126 = qco.r(%124, %12) %125 : !qco.qubit -> !qco.qubit
    %127 = qco.r(%12, %cst_4) %126 : !qco.qubit -> !qco.qubit
    %128 = arith.divf %arg22, %cst_1 : f64
    %129 = math.tan %128 : f64
    %130 = math.atan %129 : f64
    %131 = arith.mulf %130, %cst_1 : f64
    %132 = qco.r(%13, %cst_4) %112 : !qco.qubit -> !qco.qubit
    %133 = qco.r(%131, %12) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.r(%12, %cst_4) %133 : !qco.qubit -> !qco.qubit
    %135 = arith.divf %arg23, %cst_1 : f64
    %136 = math.tan %135 : f64
    %137 = math.atan %136 : f64
    %138 = arith.mulf %137, %cst_1 : f64
    %139 = qco.r(%13, %cst_4) %113 : !qco.qubit -> !qco.qubit
    %140 = qco.r(%138, %12) %139 : !qco.qubit -> !qco.qubit
    %141 = qco.r(%12, %cst_4) %140 : !qco.qubit -> !qco.qubit
    %142 = qco.r(%cst_2, %cst_4) %120 : !qco.qubit -> !qco.qubit
    %143 = qco.r(%cst_0, %cst_0) %142 : !qco.qubit -> !qco.qubit
    %144 = qco.r(%cst_2, %cst_4) %143 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%141) targets (%arg32 = %144) {
      %194 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %194 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %145 = qco.r(%cst_0, %cst_0) %targets_out_20 : !qco.qubit -> !qco.qubit
    %146 = qco.r(%cst, %cst_4) %145 : !qco.qubit -> !qco.qubit
    %147 = qco.r(%cst_2, %cst_4) %127 : !qco.qubit -> !qco.qubit
    %148 = qco.r(%cst_0, %cst_0) %147 : !qco.qubit -> !qco.qubit
    %149 = qco.r(%cst_2, %cst_4) %148 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%146) targets (%arg32 = %149) {
      %194 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %194 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %150 = qco.r(%cst_0, %cst_0) %targets_out_22 : !qco.qubit -> !qco.qubit
    %151 = qco.r(%cst, %cst_4) %150 : !qco.qubit -> !qco.qubit
    %152 = qco.r(%cst_2, %cst_4) %134 : !qco.qubit -> !qco.qubit
    %153 = qco.r(%cst_0, %cst_0) %152 : !qco.qubit -> !qco.qubit
    %154 = qco.r(%cst_2, %cst_4) %153 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%151) targets (%arg32 = %154) {
      %194 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %194 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %155 = qco.r(%cst_0, %cst_0) %targets_out_24 : !qco.qubit -> !qco.qubit
    %156 = qco.r(%cst, %cst_4) %155 : !qco.qubit -> !qco.qubit
    %157 = qco.r(%cst_2, %cst_4) %controls_out_19 : !qco.qubit -> !qco.qubit
    %158 = qco.r(%cst_0, %cst_0) %157 : !qco.qubit -> !qco.qubit
    %159 = qco.r(%cst_2, %cst_4) %158 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%156) targets (%arg32 = %159) {
      %194 = qco.z %arg32 : !qco.qubit -> !qco.qubit
      qco.yield %194 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %160 = qco.r(%cst_0, %cst_0) %targets_out_26 : !qco.qubit -> !qco.qubit
    %161 = qco.r(%cst, %cst_4) %160 : !qco.qubit -> !qco.qubit
    %162 = qco.r(%arg24, %cst_0) %controls_out_21 : !qco.qubit -> !qco.qubit
    %163 = qco.r(%arg25, %cst_0) %controls_out_23 : !qco.qubit -> !qco.qubit
    %164 = qco.r(%arg26, %cst_0) %controls_out_25 : !qco.qubit -> !qco.qubit
    %165 = qco.r(%arg27, %cst_0) %161 : !qco.qubit -> !qco.qubit
    %166 = arith.divf %arg28, %cst_1 : f64
    %167 = math.tan %166 : f64
    %168 = math.atan %167 : f64
    %169 = arith.mulf %168, %cst_1 : f64
    %170 = qco.r(%13, %cst_4) %162 : !qco.qubit -> !qco.qubit
    %171 = qco.r(%169, %12) %170 : !qco.qubit -> !qco.qubit
    %172 = qco.r(%12, %cst_4) %171 : !qco.qubit -> !qco.qubit
    %173 = arith.divf %arg29, %cst_1 : f64
    %174 = math.tan %173 : f64
    %175 = math.atan %174 : f64
    %176 = arith.mulf %175, %cst_1 : f64
    %177 = qco.r(%13, %cst_4) %163 : !qco.qubit -> !qco.qubit
    %178 = qco.r(%176, %12) %177 : !qco.qubit -> !qco.qubit
    %179 = qco.r(%12, %cst_4) %178 : !qco.qubit -> !qco.qubit
    %180 = arith.divf %arg30, %cst_1 : f64
    %181 = math.tan %180 : f64
    %182 = math.atan %181 : f64
    %183 = arith.mulf %182, %cst_1 : f64
    %184 = qco.r(%13, %cst_4) %164 : !qco.qubit -> !qco.qubit
    %185 = qco.r(%183, %12) %184 : !qco.qubit -> !qco.qubit
    %186 = qco.r(%12, %cst_4) %185 : !qco.qubit -> !qco.qubit
    qco.sink %172 : !qco.qubit
    qco.sink %179 : !qco.qubit
    qco.sink %186 : !qco.qubit
    %187 = arith.divf %arg31, %cst_1 : f64
    %188 = math.tan %187 : f64
    %189 = math.atan %188 : f64
    %190 = arith.mulf %189, %cst_1 : f64
    %191 = qco.r(%13, %cst_4) %165 : !qco.qubit -> !qco.qubit
    %192 = qco.r(%190, %12) %191 : !qco.qubit -> !qco.qubit
    %193 = qco.r(%12, %cst_4) %192 : !qco.qubit -> !qco.qubit
    qco.sink %193 : !qco.qubit
    return %c0_i64 : i64
  }
}
