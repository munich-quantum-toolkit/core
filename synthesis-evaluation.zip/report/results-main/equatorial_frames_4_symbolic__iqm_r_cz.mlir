module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main(%arg0: f64 {mqt.input_id = 12927349219598359841868690406665925546 : i128, mqt.input_name = "theta[0]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 0 : i64, name = "theta", size = 12 : i64}}, %arg1: f64 {mqt.input_id = 12927349219598359841868690406665925547 : i128, mqt.input_name = "theta[1]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 1 : i64, name = "theta", size = 12 : i64}}, %arg2: f64 {mqt.input_id = 12927349219598359841868690406665925548 : i128, mqt.input_name = "theta[2]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 2 : i64, name = "theta", size = 12 : i64}}, %arg3: f64 {mqt.input_id = 12927349219598359841868690406665925549 : i128, mqt.input_name = "theta[3]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 3 : i64, name = "theta", size = 12 : i64}}, %arg4: f64 {mqt.input_id = 12927349219598359841868690406665925550 : i128, mqt.input_name = "theta[4]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 4 : i64, name = "theta", size = 12 : i64}}, %arg5: f64 {mqt.input_id = 12927349219598359841868690406665925551 : i128, mqt.input_name = "theta[5]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 5 : i64, name = "theta", size = 12 : i64}}, %arg6: f64 {mqt.input_id = 12927349219598359841868690406665925552 : i128, mqt.input_name = "theta[6]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 6 : i64, name = "theta", size = 12 : i64}}, %arg7: f64 {mqt.input_id = 12927349219598359841868690406665925553 : i128, mqt.input_name = "theta[7]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 7 : i64, name = "theta", size = 12 : i64}}, %arg8: f64 {mqt.input_id = 12927349219598359841868690406665925554 : i128, mqt.input_name = "theta[8]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 8 : i64, name = "theta", size = 12 : i64}}, %arg9: f64 {mqt.input_id = 12927349219598359841868690406665925555 : i128, mqt.input_name = "theta[9]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 9 : i64, name = "theta", size = 12 : i64}}, %arg10: f64 {mqt.input_id = 12927349219598359841868690406665925556 : i128, mqt.input_name = "theta[10]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 10 : i64, name = "theta", size = 12 : i64}}, %arg11: f64 {mqt.input_id = 12927349219598359841868690406665925557 : i128, mqt.input_name = "theta[11]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 11 : i64, name = "theta", size = 12 : i64}}) -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 4.000000e+00 : f64
    %cst_0 = arith.constant 3.1415926535897931 : f64
    %cst_1 = arith.constant 2.000000e+00 : f64
    %cst_2 = arith.constant 0.000000e+00 : f64
    %cst_3 = arith.constant 3.000000e-01 : f64
    %cst_4 = arith.constant 2.000000e-01 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = arith.divf %arg0, %cst : f64
    %5 = math.tan %4 : f64
    %6 = math.atan %5 : f64
    %7 = arith.mulf %6, %cst : f64
    %8 = arith.divf %cst_0, %cst_1 : f64
    %9 = arith.negf %8 : f64
    %10 = qco.r(%9, %cst_2) %0 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%7, %8) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%8, %cst_2) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_3, %cst_4) %12 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%13) targets (%arg12 = %1) {
      %102 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = arith.divf %arg1, %cst : f64
    %15 = math.tan %14 : f64
    %16 = math.atan %15 : f64
    %17 = arith.mulf %16, %cst : f64
    %18 = qco.r(%9, %cst_2) %targets_out : !qco.qubit -> !qco.qubit
    %19 = qco.r(%17, %8) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%8, %cst_2) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_3, %cst_4) %20 : !qco.qubit -> !qco.qubit
    %controls_out_5, %targets_out_6 = qco.ctrl(%21) targets (%arg12 = %2) {
      %102 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = arith.divf %arg2, %cst : f64
    %23 = math.tan %22 : f64
    %24 = math.atan %23 : f64
    %25 = arith.mulf %24, %cst : f64
    %26 = qco.r(%9, %cst_2) %targets_out_6 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%25, %8) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%8, %cst_2) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.r(%cst_3, %cst_4) %28 : !qco.qubit -> !qco.qubit
    %controls_out_7, %targets_out_8 = qco.ctrl(%29) targets (%arg12 = %3) {
      %102 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = arith.divf %arg3, %cst : f64
    %31 = math.tan %30 : f64
    %32 = math.atan %31 : f64
    %33 = arith.mulf %32, %cst : f64
    %34 = qco.r(%9, %cst_2) %targets_out_8 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%33, %8) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%8, %cst_2) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%cst_3, %cst_4) %36 : !qco.qubit -> !qco.qubit
    %controls_out_9, %targets_out_10 = qco.ctrl(%37) targets (%arg12 = %controls_out) {
      %102 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = arith.divf %arg4, %cst : f64
    %39 = math.tan %38 : f64
    %40 = math.atan %39 : f64
    %41 = arith.mulf %40, %cst : f64
    %42 = qco.r(%9, %cst_2) %targets_out_10 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%41, %8) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%8, %cst_2) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst_3, %cst_4) %44 : !qco.qubit -> !qco.qubit
    %controls_out_11, %targets_out_12 = qco.ctrl(%45) targets (%arg12 = %controls_out_5) {
      %102 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %46 = arith.divf %arg5, %cst : f64
    %47 = math.tan %46 : f64
    %48 = math.atan %47 : f64
    %49 = arith.mulf %48, %cst : f64
    %50 = qco.r(%9, %cst_2) %targets_out_12 : !qco.qubit -> !qco.qubit
    %51 = qco.r(%49, %8) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.r(%8, %cst_2) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst_3, %cst_4) %52 : !qco.qubit -> !qco.qubit
    %controls_out_13, %targets_out_14 = qco.ctrl(%53) targets (%arg12 = %controls_out_7) {
      %102 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %54 = arith.divf %arg6, %cst : f64
    %55 = math.tan %54 : f64
    %56 = math.atan %55 : f64
    %57 = arith.mulf %56, %cst : f64
    %58 = qco.r(%9, %cst_2) %targets_out_14 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%57, %8) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.r(%8, %cst_2) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.r(%cst_3, %cst_4) %60 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%61) targets (%arg12 = %controls_out_9) {
      %102 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %62 = arith.divf %arg7, %cst : f64
    %63 = math.tan %62 : f64
    %64 = math.atan %63 : f64
    %65 = arith.mulf %64, %cst : f64
    %66 = qco.r(%9, %cst_2) %targets_out_16 : !qco.qubit -> !qco.qubit
    %67 = qco.r(%65, %8) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.r(%8, %cst_2) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.r(%cst_3, %cst_4) %68 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%69) targets (%arg12 = %controls_out_11) {
      %102 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %70 = arith.divf %arg8, %cst : f64
    %71 = math.tan %70 : f64
    %72 = math.atan %71 : f64
    %73 = arith.mulf %72, %cst : f64
    %74 = qco.r(%9, %cst_2) %targets_out_18 : !qco.qubit -> !qco.qubit
    %75 = qco.r(%73, %8) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.r(%8, %cst_2) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.r(%cst_3, %cst_4) %76 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%77) targets (%arg12 = %controls_out_13) {
      %102 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %78 = arith.divf %arg9, %cst : f64
    %79 = math.tan %78 : f64
    %80 = math.atan %79 : f64
    %81 = arith.mulf %80, %cst : f64
    %82 = qco.r(%9, %cst_2) %targets_out_20 : !qco.qubit -> !qco.qubit
    %83 = qco.r(%81, %8) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.r(%8, %cst_2) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.r(%cst_3, %cst_4) %84 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%85) targets (%arg12 = %controls_out_15) {
      %102 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %86 = arith.divf %arg10, %cst : f64
    %87 = math.tan %86 : f64
    %88 = math.atan %87 : f64
    %89 = arith.mulf %88, %cst : f64
    %90 = qco.r(%9, %cst_2) %targets_out_22 : !qco.qubit -> !qco.qubit
    %91 = qco.r(%89, %8) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.r(%8, %cst_2) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.r(%cst_3, %cst_4) %92 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%93) targets (%arg12 = %controls_out_17) {
      %102 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %94 = arith.divf %arg11, %cst : f64
    %95 = math.tan %94 : f64
    %96 = math.atan %95 : f64
    %97 = arith.mulf %96, %cst : f64
    %98 = qco.r(%9, %cst_2) %targets_out_24 : !qco.qubit -> !qco.qubit
    %99 = qco.r(%97, %8) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.r(%8, %cst_2) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.r(%cst_3, %cst_4) %100 : !qco.qubit -> !qco.qubit
    qco.sink %controls_out_21 : !qco.qubit
    qco.sink %controls_out_23 : !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%101) targets (%arg12 = %controls_out_19) {
      %102 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %102 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    qco.sink %targets_out_26 : !qco.qubit
    qco.sink %controls_out_25 : !qco.qubit
    return %c0_i64 : i64
  }
}
