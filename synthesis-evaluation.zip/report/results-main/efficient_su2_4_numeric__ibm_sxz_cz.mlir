module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant -2.0899032380588896 : f64
    %cst_0 = arith.constant -1.2658648975223281 : f64
    %cst_1 = arith.constant -3.5065593305197398 : f64
    %cst_2 = arith.constant 0.49807597633808687 : f64
    %cst_3 = arith.constant 1.0431143540228902 : f64
    %cst_4 = arith.constant -0.66496539210011463 : f64
    %cst_5 = arith.constant -3.2263549223651729 : f64
    %cst_6 = arith.constant -1.7998459379380729 : f64
    %cst_7 = arith.constant -2.0586457619688998 : f64
    %cst_8 = arith.constant 1.5707963267948963 : f64
    %cst_9 = arith.constant -1.5707963267948966 : f64
    %cst_10 = arith.constant 4.7123889803846897 : f64
    %cst_11 = arith.constant -4.7123889803846897 : f64
    %cst_12 = arith.constant 1.692378069204338 : f64
    %cst_13 = arith.constant 3.2372089537235489 : f64
    %cst_14 = arith.constant 0.60283548945758003 : f64
    %cst_15 = arith.constant 4.8678311294584828 : f64
    %cst_16 = arith.constant 1.0061459307786649 : f64
    %cst_17 = arith.constant 4.2332842346068036 : f64
    %cst_18 = arith.constant 4.7669418028860102 : f64
    %cst_19 = arith.constant 4.5953251390072261 : f64
    %cst_20 = arith.constant 0.11888888386212493 : f64
    %cst_21 = arith.constant 4.4588523966648923 : f64
    %cst_22 = arith.constant 5.6100533141107558 : f64
    %cst_23 = arith.constant 5.6626956550635681 : f64
    %cst_24 = arith.constant 3.4517052679728941 : f64
    %cst_25 = arith.constant 2.9164052298172143 : f64
    %cst_26 = arith.constant 3.5904989308112265 : f64
    %cst_27 = arith.constant 5.3839419137933335 : f64
    %cst_28 = arith.constant 5.6597330532866676 : f64
    %cst_29 = arith.constant -3.1415926535897931 : f64
    %cst_30 = arith.constant 4.1952478754800913 : f64
    %cst_31 = arith.constant 1.3619104989145452 : f64
    %cst_32 = arith.constant 6.0824814649890691 : f64
    %cst_33 = arith.constant 3.1415926535897931 : f64
    %cst_34 = arith.constant 3.8126462235677083 : f64
    %cst_35 = arith.constant 3.1415926535897936 : f64
    %cst_36 = arith.constant 3.8962707397538181 : f64
    %cst_37 = arith.constant 5.2940337675068845 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.sx %0 : !qco.qubit -> !qco.qubit
    %5 = qco.rz(%cst_37) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_7) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.sx %1 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_36) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_6) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_35) %2 : !qco.qubit -> !qco.qubit
    %13 = qco.sx %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_34) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_5) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_33) %3 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_32) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.sx %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_31) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.sx %7 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_10) %22 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%21) targets (%arg0 = %23) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = qco.rz(%cst_9) %targets_out : !qco.qubit -> !qco.qubit
    %25 = qco.sx %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_8) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_10) %27 : !qco.qubit -> !qco.qubit
    %controls_out_38, %targets_out_39 = qco.ctrl(%26) targets (%arg0 = %28) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.rz(%cst_9) %targets_out_39 : !qco.qubit -> !qco.qubit
    %30 = qco.sx %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_8) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.sx %16 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_10) %32 : !qco.qubit -> !qco.qubit
    %controls_out_40, %targets_out_41 = qco.ctrl(%31) targets (%arg0 = %33) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.rz(%cst_9) %targets_out_41 : !qco.qubit -> !qco.qubit
    %35 = qco.sx %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_8) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_11) %controls_out : !qco.qubit -> !qco.qubit
    %38 = qco.sx %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_10) %38 : !qco.qubit -> !qco.qubit
    %controls_out_42, %targets_out_43 = qco.ctrl(%36) targets (%arg0 = %39) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %40 = qco.rz(%cst_9) %targets_out_43 : !qco.qubit -> !qco.qubit
    %41 = qco.sx %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_8) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %controls_out_38 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_30) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.sx %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_4) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_29) %controls_out_40 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_28) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.sx %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_3) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.sx %controls_out_42 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_27) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.sx %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_2) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.sx %42 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_26) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.sx %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_25) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.sx %46 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_10) %60 : !qco.qubit -> !qco.qubit
    %controls_out_44, %targets_out_45 = qco.ctrl(%59) targets (%arg0 = %61) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %62 = qco.rz(%cst_9) %targets_out_45 : !qco.qubit -> !qco.qubit
    %63 = qco.sx %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_8) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.sx %51 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_10) %65 : !qco.qubit -> !qco.qubit
    %controls_out_46, %targets_out_47 = qco.ctrl(%64) targets (%arg0 = %66) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %67 = qco.rz(%cst_9) %targets_out_47 : !qco.qubit -> !qco.qubit
    %68 = qco.sx %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_8) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.sx %55 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_10) %70 : !qco.qubit -> !qco.qubit
    %controls_out_48, %targets_out_49 = qco.ctrl(%69) targets (%arg0 = %71) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %72 = qco.rz(%cst_9) %targets_out_49 : !qco.qubit -> !qco.qubit
    %73 = qco.sx %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_8) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_11) %controls_out_44 : !qco.qubit -> !qco.qubit
    %76 = qco.sx %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_10) %76 : !qco.qubit -> !qco.qubit
    %controls_out_50, %targets_out_51 = qco.ctrl(%74) targets (%arg0 = %77) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %78 = qco.rz(%cst_9) %targets_out_51 : !qco.qubit -> !qco.qubit
    %79 = qco.sx %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_10) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.sx %controls_out_46 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_24) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.sx %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_1) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.sx %controls_out_48 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_23) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.sx %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_0) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_33) %controls_out_50 : !qco.qubit -> !qco.qubit
    %90 = qco.sx %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_22) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.sx %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.sx %80 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_21) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.sx %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_20) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.sx %84 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_10) %98 : !qco.qubit -> !qco.qubit
    %controls_out_52, %targets_out_53 = qco.ctrl(%97) targets (%arg0 = %99) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %100 = qco.rz(%cst_9) %targets_out_53 : !qco.qubit -> !qco.qubit
    %101 = qco.sx %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_8) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.sx %88 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_10) %103 : !qco.qubit -> !qco.qubit
    %controls_out_54, %targets_out_55 = qco.ctrl(%102) targets (%arg0 = %104) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %105 = qco.rz(%cst_9) %targets_out_55 : !qco.qubit -> !qco.qubit
    %106 = qco.sx %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rz(%cst_8) %106 : !qco.qubit -> !qco.qubit
    %108 = qco.sx %93 : !qco.qubit -> !qco.qubit
    %109 = qco.rz(%cst_10) %108 : !qco.qubit -> !qco.qubit
    %controls_out_56, %targets_out_57 = qco.ctrl(%107) targets (%arg0 = %109) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %110 = qco.rz(%cst_9) %targets_out_57 : !qco.qubit -> !qco.qubit
    %111 = qco.sx %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rz(%cst_8) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_11) %controls_out_52 : !qco.qubit -> !qco.qubit
    %114 = qco.sx %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_10) %114 : !qco.qubit -> !qco.qubit
    %controls_out_58, %targets_out_59 = qco.ctrl(%112) targets (%arg0 = %115) {
      %136 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %136 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %116 = qco.rz(%cst_9) %targets_out_59 : !qco.qubit -> !qco.qubit
    %117 = qco.sx %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_8) %117 : !qco.qubit -> !qco.qubit
    %119 = qco.sx %controls_out_54 : !qco.qubit -> !qco.qubit
    %120 = qco.rz(%cst_19) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.sx %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rz(%cst_18) %121 : !qco.qubit -> !qco.qubit
    %123 = qco.sx %controls_out_56 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_17) %123 : !qco.qubit -> !qco.qubit
    %125 = qco.sx %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst_16) %125 : !qco.qubit -> !qco.qubit
    %127 = qco.rz(%cst_33) %controls_out_58 : !qco.qubit -> !qco.qubit
    %128 = qco.sx %127 : !qco.qubit -> !qco.qubit
    %129 = qco.rz(%cst_15) %128 : !qco.qubit -> !qco.qubit
    %130 = qco.sx %129 : !qco.qubit -> !qco.qubit
    %131 = qco.rz(%cst_14) %130 : !qco.qubit -> !qco.qubit
    %132 = qco.sx %118 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst_13) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.sx %133 : !qco.qubit -> !qco.qubit
    %135 = qco.rz(%cst_12) %134 : !qco.qubit -> !qco.qubit
    qco.sink %122 : !qco.qubit
    qco.sink %126 : !qco.qubit
    qco.sink %131 : !qco.qubit
    qco.sink %135 : !qco.qubit
    return %c0_i64 : i64
  }
}
