module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant -3.1415926535897913 : f64
    %cst_0 = arith.constant 2.2204460492503131E-15 : f64
    %cst_1 = arith.constant 3.3931520156444677 : f64
    %cst_2 = arith.constant -1.5707963267948981 : f64
    %cst_3 = arith.constant 4.2178132105483392 : f64
    %cst_4 = arith.constant 5.2940337675068836 : f64
    %cst_5 = arith.constant 4.4887044570587156 : f64
    %cst_6 = arith.constant 3.8962707397538185 : f64
    %cst_7 = arith.constant 5.9058462640975726 : f64
    %cst_8 = arith.constant -1.4056476493802696 : f64
    %cst_9 = arith.constant 1.7359450042095235 : f64
    %cst_10 = arith.constant -1.5707963267948974 : f64
    %cst_11 = arith.constant 4.1218889240562167 : f64
    %cst_12 = arith.constant 3.8126462235677074 : f64
    %cst_13 = arith.constant 5.9476585221906282 : f64
    %cst_14 = arith.constant 3.141592653589794 : f64
    %cst_15 = arith.constant 4.7123889803846888 : f64
    %cst_16 = arith.constant 6.9779235833762883 : f64
    %cst_17 = arith.constant 0.69473827619670359 : f64
    %cst_18 = arith.constant 2.9229237077158507 : f64
    %cst_19 = arith.constant 4.4937200345107478 : f64
    %cst_20 = arith.constant 7.1054273576010019E-15 : f64
    %cst_21 = arith.constant 6.1205688287882509 : f64
    %cst_22 = arith.constant -1.5707963267948903 : f64
    %cst_23 = arith.constant 4.6120370592894311 : f64
    %cst_24 = arith.constant 3.1415926535897944 : f64
    %cst_25 = arith.constant 6.0824814649890691 : f64
    %cst_26 = arith.constant -1.5707963267948957 : f64
    %cst_27 = arith.constant -1.1102230246251565E-15 : f64
    %cst_28 = arith.constant 3.141592653589786 : f64
    %cst_29 = arith.constant 4.7887388507657525 : f64
    %cst_30 = arith.constant -4.7123889803846879 : f64
    %cst_31 = arith.constant 3.6294420887637955 : f64
    %cst_32 = arith.constant 6.0392605895925842 : f64
    %cst_33 = arith.constant 3.5527136788005009E-15 : f64
    %cst_34 = arith.constant 4.7123889803846861 : f64
    %cst_35 = arith.constant 1.5707963267949021 : f64
    %cst_36 = arith.constant 3.1415926535897878 : f64
    %cst_37 = arith.constant 5.2077336663912002 : f64
    %cst_38 = arith.constant 4.7123889803846852 : f64
    %cst_39 = arith.constant 3.1415926535897927 : f64
    %cst_40 = arith.constant 3.3706422647329704 : f64
    %cst_41 = arith.constant 3.1415926535897953 : f64
    %cst_42 = arith.constant 6.1686605016079969 : f64
    %cst_43 = arith.constant 4.0688878715914045 : f64
    %cst_44 = arith.constant -3.7850937623830774 : f64
    %cst_45 = arith.constant 4.2584188140798416 : f64
    %cst_46 = arith.constant -1.5707963267948972 : f64
    %cst_47 = arith.constant 4.6276267116093095 : f64
    %cst_48 = arith.constant 5.5401682781698272 : f64
    %cst_49 = arith.constant 6.2831853071795845 : f64
    %cst_50 = arith.constant 3.9269908169872414 : f64
    %cst_51 = arith.constant -0.78539816339744817 : f64
    %cst_52 = arith.constant 5.063607387681456 : f64
    %cst_53 = arith.constant 4.5035031525043383 : f64
    %cst_54 = arith.constant 5.6022300577223128 : f64
    %cst_55 = arith.constant 3.1415926535897922 : f64
    %cst_56 = arith.constant -4.7123889803846888 : f64
    %cst_57 = arith.constant 5.4438051739472932 : f64
    %cst_58 = arith.constant -1.5707963267948968 : f64
    %cst_59 = arith.constant 4.1952478754800904 : f64
    %cst_60 = arith.constant 5.7563576962344367 : f64
    %cst_61 = arith.constant 4.7123889803846906 : f64
    %cst_62 = arith.constant 5.4598387337858707 : f64
    %cst_63 = arith.constant 4.4006628534382308 : f64
    %cst_64 = arith.constant 5.6597330532866668 : f64
    %cst_65 = arith.constant 1.5707963267948968 : f64
    %cst_66 = arith.constant -1.0303768265243125 : f64
    %cst_67 = arith.constant 0.5404195002705845 : f64
    %cst_68 = arith.constant 6.1335498814391078 : f64
    %cst_69 = arith.constant -1.5707963267948961 : f64
    %cst_70 = arith.constant 4.2627672836915629 : f64
    %cst_71 = arith.constant 5.3839419137933326 : f64
    %cst_72 = arith.constant 6.2831853071795862 : f64
    %cst_73 = arith.constant -1.5707963267948966 : f64
    %cst_74 = arith.constant 4.7123889803846915 : f64
    %cst_75 = arith.constant 1.5707963267948966 : f64
    %cst_76 = arith.constant -6.2831853071795862 : f64
    %cst_77 = arith.constant 3.1415926535897931 : f64
    %cst_78 = arith.constant 3.5904989308112256 : f64
    %cst_79 = arith.constant 3.1415926535897936 : f64
    %cst_80 = arith.constant 6.0587321685688691 : f64
    %cst_81 = arith.constant 4.7123889803846897 : f64
    %cst_82 = arith.constant -4.7123889803846897 : f64
    %cst_83 = arith.constant 3.8590730248954901 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.sx %0 : !qco.qubit -> !qco.qubit
    %5 = qco.rz(%cst_83) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_58) %1 : !qco.qubit -> !qco.qubit
    %8 = qco.sx %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_81) %8 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%6) targets (%arg0 = %9) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %10 = qco.rz(%cst_81) %targets_out : !qco.qubit -> !qco.qubit
    %11 = qco.sx %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_4) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.sx %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_79) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_82) %controls_out : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_3) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_77) %18 : !qco.qubit -> !qco.qubit
    %controls_out_84, %targets_out_85 = qco.ctrl(%19) targets (%arg0 = %14) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %20 = qco.rz(%cst_2) %targets_out_85 : !qco.qubit -> !qco.qubit
    %21 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rz(%cst_1) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.sx %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_0) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst) %controls_out_84 : !qco.qubit -> !qco.qubit
    %26 = qco.sx %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_65) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_9) %2 : !qco.qubit -> !qco.qubit
    %29 = qco.x %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_8) %29 : !qco.qubit -> !qco.qubit
    %controls_out_86, %targets_out_87 = qco.ctrl(%24) targets (%arg0 = %30) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.rz(%cst_81) %targets_out_87 : !qco.qubit -> !qco.qubit
    %32 = qco.sx %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_7) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_79) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_82) %controls_out_86 : !qco.qubit -> !qco.qubit
    %37 = qco.sx %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_6) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_77) %39 : !qco.qubit -> !qco.qubit
    %controls_out_88, %targets_out_89 = qco.ctrl(%40) targets (%arg0 = %35) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.rz(%cst_74) %targets_out_89 : !qco.qubit -> !qco.qubit
    %42 = qco.sx %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_5) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.sx %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_79) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.sx %controls_out_88 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_73) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_17) %3 : !qco.qubit -> !qco.qubit
    %49 = qco.x %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_16) %49 : !qco.qubit -> !qco.qubit
    %controls_out_90, %targets_out_91 = qco.ctrl(%45) targets (%arg0 = %50) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %51 = qco.rz(%cst_61) %targets_out_91 : !qco.qubit -> !qco.qubit
    %52 = qco.sx %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_13) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.sx %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_14) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_82) %controls_out_90 : !qco.qubit -> !qco.qubit
    %57 = qco.sx %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_12) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.sx %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_77) %59 : !qco.qubit -> !qco.qubit
    %controls_out_92, %targets_out_93 = qco.ctrl(%60) targets (%arg0 = %55) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qco.rz(%cst_81) %targets_out_93 : !qco.qubit -> !qco.qubit
    %62 = qco.sx %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_11) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.sx %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_79) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_10) %controls_out_92 : !qco.qubit -> !qco.qubit
    %67 = qco.sx %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_15) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.sx %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_72) %69 : !qco.qubit -> !qco.qubit
    %controls_out_94, %targets_out_95 = qco.ctrl(%65) targets (%arg0 = %27) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %71 = qco.rz(%cst_74) %targets_out_95 : !qco.qubit -> !qco.qubit
    %72 = qco.sx %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_25) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.sx %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_24) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_82) %controls_out_94 : !qco.qubit -> !qco.qubit
    %77 = qco.sx %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_23) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.sx %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_77) %79 : !qco.qubit -> !qco.qubit
    %controls_out_96, %targets_out_97 = qco.ctrl(%80) targets (%arg0 = %75) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %81 = qco.rz(%cst_22) %targets_out_97 : !qco.qubit -> !qco.qubit
    %82 = qco.sx %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_21) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.sx %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_20) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_19) %controls_out_96 : !qco.qubit -> !qco.qubit
    %87 = qco.sx %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_49) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.sx %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_18) %89 : !qco.qubit -> !qco.qubit
    %controls_out_98, %targets_out_99 = qco.ctrl(%85) targets (%arg0 = %47) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %91 = qco.rz(%cst_81) %targets_out_99 : !qco.qubit -> !qco.qubit
    %92 = qco.sx %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_32) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.sx %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_79) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_82) %controls_out_98 : !qco.qubit -> !qco.qubit
    %97 = qco.sx %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_31) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.sx %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_39) %99 : !qco.qubit -> !qco.qubit
    %controls_out_100, %targets_out_101 = qco.ctrl(%100) targets (%arg0 = %95) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %101 = qco.rz(%cst_30) %targets_out_101 : !qco.qubit -> !qco.qubit
    %102 = qco.sx %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst_29) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.sx %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst_28) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_27) %controls_out_100 : !qco.qubit -> !qco.qubit
    %107 = qco.sx %106 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_26) %107 : !qco.qubit -> !qco.qubit
    %controls_out_102, %targets_out_103 = qco.ctrl(%105) targets (%arg0 = %70) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %109 = qco.rz(%cst_74) %targets_out_103 : !qco.qubit -> !qco.qubit
    %110 = qco.sx %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_42) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.sx %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_41) %112 : !qco.qubit -> !qco.qubit
    %114 = qco.rz(%cst_82) %controls_out_102 : !qco.qubit -> !qco.qubit
    %115 = qco.sx %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst_40) %115 : !qco.qubit -> !qco.qubit
    %117 = qco.sx %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_39) %117 : !qco.qubit -> !qco.qubit
    %controls_out_104, %targets_out_105 = qco.ctrl(%118) targets (%arg0 = %113) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %119 = qco.rz(%cst_38) %targets_out_105 : !qco.qubit -> !qco.qubit
    %120 = qco.sx %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rz(%cst_37) %120 : !qco.qubit -> !qco.qubit
    %122 = qco.sx %121 : !qco.qubit -> !qco.qubit
    %123 = qco.rz(%cst_36) %122 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_35) %controls_out_104 : !qco.qubit -> !qco.qubit
    %125 = qco.sx %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst_34) %125 : !qco.qubit -> !qco.qubit
    %127 = qco.sx %126 : !qco.qubit -> !qco.qubit
    %128 = qco.rz(%cst_33) %127 : !qco.qubit -> !qco.qubit
    %controls_out_106, %targets_out_107 = qco.ctrl(%123) targets (%arg0 = %90) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %129 = qco.rz(%cst_81) %targets_out_107 : !qco.qubit -> !qco.qubit
    %130 = qco.sx %129 : !qco.qubit -> !qco.qubit
    %131 = qco.rz(%cst_48) %130 : !qco.qubit -> !qco.qubit
    %132 = qco.sx %131 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst_79) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.rz(%cst_82) %controls_out_106 : !qco.qubit -> !qco.qubit
    %135 = qco.sx %134 : !qco.qubit -> !qco.qubit
    %136 = qco.rz(%cst_47) %135 : !qco.qubit -> !qco.qubit
    %137 = qco.sx %136 : !qco.qubit -> !qco.qubit
    %138 = qco.rz(%cst_77) %137 : !qco.qubit -> !qco.qubit
    %controls_out_108, %targets_out_109 = qco.ctrl(%138) targets (%arg0 = %133) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %139 = qco.rz(%cst_46) %targets_out_109 : !qco.qubit -> !qco.qubit
    %140 = qco.sx %139 : !qco.qubit -> !qco.qubit
    %141 = qco.rz(%cst_45) %140 : !qco.qubit -> !qco.qubit
    %142 = qco.sx %141 : !qco.qubit -> !qco.qubit
    %143 = qco.rz(%cst_77) %142 : !qco.qubit -> !qco.qubit
    %144 = qco.rz(%cst_44) %controls_out_108 : !qco.qubit -> !qco.qubit
    %145 = qco.sx %144 : !qco.qubit -> !qco.qubit
    %146 = qco.rz(%cst_49) %145 : !qco.qubit -> !qco.qubit
    %147 = qco.sx %146 : !qco.qubit -> !qco.qubit
    %148 = qco.rz(%cst_43) %147 : !qco.qubit -> !qco.qubit
    %controls_out_110, %targets_out_111 = qco.ctrl(%143) targets (%arg0 = %108) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %149 = qco.rz(%cst_81) %targets_out_111 : !qco.qubit -> !qco.qubit
    %150 = qco.sx %149 : !qco.qubit -> !qco.qubit
    %151 = qco.rz(%cst_54) %150 : !qco.qubit -> !qco.qubit
    %152 = qco.sx %151 : !qco.qubit -> !qco.qubit
    %153 = qco.rz(%cst_79) %152 : !qco.qubit -> !qco.qubit
    %154 = qco.rz(%cst_82) %controls_out_110 : !qco.qubit -> !qco.qubit
    %155 = qco.sx %154 : !qco.qubit -> !qco.qubit
    %156 = qco.rz(%cst_53) %155 : !qco.qubit -> !qco.qubit
    %157 = qco.sx %156 : !qco.qubit -> !qco.qubit
    %158 = qco.rz(%cst_77) %157 : !qco.qubit -> !qco.qubit
    %controls_out_112, %targets_out_113 = qco.ctrl(%158) targets (%arg0 = %153) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %159 = qco.rz(%cst_58) %targets_out_113 : !qco.qubit -> !qco.qubit
    %160 = qco.sx %159 : !qco.qubit -> !qco.qubit
    %161 = qco.rz(%cst_52) %160 : !qco.qubit -> !qco.qubit
    %162 = qco.sx %161 : !qco.qubit -> !qco.qubit
    %163 = qco.rz(%cst_72) %162 : !qco.qubit -> !qco.qubit
    %164 = qco.rz(%cst_51) %controls_out_112 : !qco.qubit -> !qco.qubit
    %165 = qco.x %164 : !qco.qubit -> !qco.qubit
    %166 = qco.rz(%cst_50) %165 : !qco.qubit -> !qco.qubit
    %controls_out_114, %targets_out_115 = qco.ctrl(%163) targets (%arg0 = %128) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %167 = qco.rz(%cst_81) %targets_out_115 : !qco.qubit -> !qco.qubit
    %168 = qco.sx %167 : !qco.qubit -> !qco.qubit
    %169 = qco.rz(%cst_60) %168 : !qco.qubit -> !qco.qubit
    %170 = qco.sx %169 : !qco.qubit -> !qco.qubit
    %171 = qco.rz(%cst_79) %170 : !qco.qubit -> !qco.qubit
    %172 = qco.rz(%cst_82) %controls_out_114 : !qco.qubit -> !qco.qubit
    %173 = qco.sx %172 : !qco.qubit -> !qco.qubit
    %174 = qco.rz(%cst_59) %173 : !qco.qubit -> !qco.qubit
    %175 = qco.sx %174 : !qco.qubit -> !qco.qubit
    %176 = qco.rz(%cst_77) %175 : !qco.qubit -> !qco.qubit
    %controls_out_116, %targets_out_117 = qco.ctrl(%176) targets (%arg0 = %171) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %177 = qco.rz(%cst_58) %targets_out_117 : !qco.qubit -> !qco.qubit
    %178 = qco.sx %177 : !qco.qubit -> !qco.qubit
    %179 = qco.rz(%cst_57) %178 : !qco.qubit -> !qco.qubit
    %180 = qco.sx %179 : !qco.qubit -> !qco.qubit
    %181 = qco.rz(%cst_79) %180 : !qco.qubit -> !qco.qubit
    %182 = qco.rz(%cst_56) %controls_out_116 : !qco.qubit -> !qco.qubit
    %183 = qco.sx %182 : !qco.qubit -> !qco.qubit
    %184 = qco.rz(%cst_61) %183 : !qco.qubit -> !qco.qubit
    %185 = qco.sx %184 : !qco.qubit -> !qco.qubit
    %186 = qco.rz(%cst_55) %185 : !qco.qubit -> !qco.qubit
    %controls_out_118, %targets_out_119 = qco.ctrl(%181) targets (%arg0 = %148) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %187 = qco.rz(%cst_81) %targets_out_119 : !qco.qubit -> !qco.qubit
    %188 = qco.sx %187 : !qco.qubit -> !qco.qubit
    %189 = qco.rz(%cst_64) %188 : !qco.qubit -> !qco.qubit
    %190 = qco.sx %189 : !qco.qubit -> !qco.qubit
    %191 = qco.rz(%cst_77) %190 : !qco.qubit -> !qco.qubit
    %192 = qco.rz(%cst_82) %controls_out_118 : !qco.qubit -> !qco.qubit
    %193 = qco.sx %192 : !qco.qubit -> !qco.qubit
    %194 = qco.rz(%cst_63) %193 : !qco.qubit -> !qco.qubit
    %195 = qco.sx %194 : !qco.qubit -> !qco.qubit
    %196 = qco.rz(%cst_77) %195 : !qco.qubit -> !qco.qubit
    %controls_out_120, %targets_out_121 = qco.ctrl(%196) targets (%arg0 = %191) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %197 = qco.rz(%cst_82) %targets_out_121 : !qco.qubit -> !qco.qubit
    %198 = qco.sx %197 : !qco.qubit -> !qco.qubit
    %199 = qco.rz(%cst_62) %198 : !qco.qubit -> !qco.qubit
    %200 = qco.sx %199 : !qco.qubit -> !qco.qubit
    %201 = qco.rz(%cst_77) %200 : !qco.qubit -> !qco.qubit
    %202 = qco.rz(%cst_61) %controls_out_120 : !qco.qubit -> !qco.qubit
    %controls_out_122, %targets_out_123 = qco.ctrl(%201) targets (%arg0 = %166) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %203 = qco.rz(%cst_81) %targets_out_123 : !qco.qubit -> !qco.qubit
    %204 = qco.sx %203 : !qco.qubit -> !qco.qubit
    %205 = qco.rz(%cst_71) %204 : !qco.qubit -> !qco.qubit
    %206 = qco.sx %205 : !qco.qubit -> !qco.qubit
    %207 = qco.rz(%cst_79) %206 : !qco.qubit -> !qco.qubit
    %208 = qco.rz(%cst_82) %controls_out_122 : !qco.qubit -> !qco.qubit
    %209 = qco.sx %208 : !qco.qubit -> !qco.qubit
    %210 = qco.rz(%cst_70) %209 : !qco.qubit -> !qco.qubit
    %211 = qco.sx %210 : !qco.qubit -> !qco.qubit
    %212 = qco.rz(%cst_77) %211 : !qco.qubit -> !qco.qubit
    %controls_out_124, %targets_out_125 = qco.ctrl(%212) targets (%arg0 = %207) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %213 = qco.rz(%cst_69) %targets_out_125 : !qco.qubit -> !qco.qubit
    %214 = qco.sx %213 : !qco.qubit -> !qco.qubit
    %215 = qco.rz(%cst_68) %214 : !qco.qubit -> !qco.qubit
    %216 = qco.sx %215 : !qco.qubit -> !qco.qubit
    %217 = qco.rz(%cst_72) %216 : !qco.qubit -> !qco.qubit
    %218 = qco.rz(%cst_67) %controls_out_124 : !qco.qubit -> !qco.qubit
    %219 = qco.x %218 : !qco.qubit -> !qco.qubit
    %220 = qco.rz(%cst_66) %219 : !qco.qubit -> !qco.qubit
    qco.sink %202 : !qco.qubit
    qco.sink %220 : !qco.qubit
    %controls_out_126, %targets_out_127 = qco.ctrl(%217) targets (%arg0 = %186) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %221 = qco.rz(%cst_81) %targets_out_127 : !qco.qubit -> !qco.qubit
    %222 = qco.sx %221 : !qco.qubit -> !qco.qubit
    %223 = qco.rz(%cst_80) %222 : !qco.qubit -> !qco.qubit
    %224 = qco.sx %223 : !qco.qubit -> !qco.qubit
    %225 = qco.rz(%cst_79) %224 : !qco.qubit -> !qco.qubit
    %226 = qco.rz(%cst_82) %controls_out_126 : !qco.qubit -> !qco.qubit
    %227 = qco.sx %226 : !qco.qubit -> !qco.qubit
    %228 = qco.rz(%cst_78) %227 : !qco.qubit -> !qco.qubit
    %229 = qco.sx %228 : !qco.qubit -> !qco.qubit
    %230 = qco.rz(%cst_77) %229 : !qco.qubit -> !qco.qubit
    %controls_out_128, %targets_out_129 = qco.ctrl(%230) targets (%arg0 = %225) {
      %235 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %235 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %231 = qco.rz(%cst_82) %targets_out_129 : !qco.qubit -> !qco.qubit
    %232 = qco.rz(%cst_76) %controls_out_128 : !qco.qubit -> !qco.qubit
    %233 = qco.sx %232 : !qco.qubit -> !qco.qubit
    %234 = qco.rz(%cst_75) %233 : !qco.qubit -> !qco.qubit
    qco.sink %231 : !qco.qubit
    qco.sink %234 : !qco.qubit
    %cst_130 = arith.constant -2.3561944901923191 : f64
    qco.gphase(%cst_130)
    return %c0_i64 : i64
  }
}
