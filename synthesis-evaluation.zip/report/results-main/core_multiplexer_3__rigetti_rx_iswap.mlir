module attributes {mqt.layout = {initial = array<i64: 1, 2, 0>, input_count = 3 : i64, sites = array<i64: 0, 1, 2>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant -1.249045772398254 : f64
    %cst_0 = arith.constant 2.677945044588987 : f64
    %cst_1 = arith.constant 3.9269908169872414 : f64
    %cst_2 = arith.constant -4.7123889803846897 : f64
    %cst_3 = arith.constant 5.4977871437821371 : f64
    %cst_4 = arith.constant -1.5707963267948966 : f64
    %cst_5 = arith.constant -0.78539816339744828 : f64
    %cst_6 = arith.constant 1.5707963267948963 : f64
    %cst_7 = arith.constant 1.5707963267948968 : f64
    %cst_8 = arith.constant 3.1415926535897927 : f64
    %cst_9 = arith.constant 3.5342917352885173 : f64
    %cst_10 = arith.constant 1.570796326794897 : f64
    %cst_11 = arith.constant 5.8904862254808616 : f64
    %cst_12 = arith.constant 1.5707963267948966 : f64
    %cst_13 = arith.constant -1.570796326794897 : f64
    %cst_14 = arith.constant 0.78539816339744828 : f64
    %cst_15 = arith.constant 2.3561944901923448 : f64
    %cst_16 = arith.constant 5.8195376981787801 : f64
    %cst_17 = arith.constant 1.8925468811915387 : f64
    %cst_18 = arith.constant 3.1415926535897931 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %4 = qco.rz(%cst_12) %1 : !qco.qubit -> !qco.qubit
    %5 = qco.rx(%cst_12) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_0) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_12) %2 : !qco.qubit -> !qco.qubit
    %8 = qco.rx(%cst_12) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_15) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_7) %0 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_18) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_6) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_18) %9 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_5) %13 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %14, %12 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %15 = qco.rz(%cst_15) %qubit1_out : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_18) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_14) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_4) %qubit0_out : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_12) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_3) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_12) %20 : !qco.qubit -> !qco.qubit
    %qubit0_out_19, %qubit1_out_20 = qco.iswap %21, %17 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %22 = qco.rz(%cst_2) %qubit1_out_20 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_12) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_1) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_12) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_18) %qubit0_out_19 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_18) %26 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_17) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_18) %6 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_16) %30 : !qco.qubit -> !qco.qubit
    %qubit0_out_21, %qubit1_out_22 = qco.iswap %31, %29 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %32 = qco.rz(%cst_15) %qubit1_out_22 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_18) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_14) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_13) %qubit0_out_21 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_12) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_11) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rx(%cst_12) %37 : !qco.qubit -> !qco.qubit
    %qubit0_out_23, %qubit1_out_24 = qco.iswap %38, %34 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %39 = qco.rz(%cst_10) %qubit1_out_24 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_12) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_9) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rx(%cst_12) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_8) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_8) %qubit0_out_23 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %43 : !qco.qubit
    cbit.store %result, %3[%c0] : !cbit.reg<3>
    %qubit_out_25, %result_26 = qco.measure %44 : !qco.qubit
    cbit.store %result_26, %3[%c1] : !cbit.reg<3>
    qco.sink %qubit_out_25 : !qco.qubit
    %qubit_out_27, %result_28 = qco.measure %27 : !qco.qubit
    qco.sink %qubit_out_27 : !qco.qubit
    cbit.store %result_28, %3[%c2] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    return %3 : !cbit.reg<3>
  }
}
