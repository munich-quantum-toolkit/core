module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 5, 6, 0>, input_count = 7 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<7> attributes {mqt.entry_point} {
    %cst = arith.constant 2.3561944901923453 : f64
    %cst_0 = arith.constant 2.3561944901923439 : f64
    %cst_1 = arith.constant 1.5707963267948968 : f64
    %cst_2 = arith.constant -6.2831853071795862 : f64
    %cst_3 = arith.constant -1.5707963267948961 : f64
    %cst_4 = arith.constant 1.9634954084936209 : f64
    %cst_5 = arith.constant 2.7488935718910685 : f64
    %cst_6 = arith.constant -4.7123889803846897 : f64
    %cst_7 = arith.constant 1.7671458676442588 : f64
    %cst_8 = arith.constant 2.9452431127404317 : f64
    %cst_9 = arith.constant 1.6689710972195777 : f64
    %cst_10 = arith.constant 3.0434178831651124 : f64
    %cst_11 = arith.constant 1.6198837120072371 : f64
    %cst_12 = arith.constant 3.0925052683774528 : f64
    %cst_13 = arith.constant 4.7123889803846897 : f64
    %cst_14 = arith.constant 1.595340019401067 : f64
    %cst_15 = arith.constant -3.1415926535897931 : f64
    %cst_16 = arith.constant 3.1170489609836221 : f64
    %cst_17 = arith.constant -1.5707963267948966 : f64
    %cst_18 = arith.constant 3.752318617979002 : f64
    %cst_19 = arith.constant 3.1415926535897931 : f64
    %cst_20 = arith.constant 0.6107259643892089 : f64
    %cst_21 = arith.constant 1.5707963267948966 : f64
    %cst_22 = arith.constant 6.2831853071795862 : f64
    %cst_23 = arith.constant -1.570796326794897 : f64
    %cst_24 = arith.constant 1.570796326794897 : f64
    %cst_25 = arith.constant 1.5707963267948961 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<7>
    %8 = qco.rx(%cst_21) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_21) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_21) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_21) %2 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_21) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rx(%cst_21) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_21) %3 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_21) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rx(%cst_21) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_21) %4 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_21) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_21) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_21) %5 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_21) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst_21) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rx(%cst_21) %6 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_21) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_21) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rx(%cst_25) %0 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_24) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_17) %25 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_1) %28 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_21) %29, %27 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %30 = qco.rx(%cst_20) %qubit1_out : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_19) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rx(%cst_18) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_17) %qubit0_out : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_0) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rx(%cst_17) %34 : !qco.qubit -> !qco.qubit
    %qubit0_out_26, %qubit1_out_27 = qco.rzz(%cst_21) %35, %32 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %36 = qco.rx(%cst_15) %qubit1_out_27 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rx(%cst_13) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_2) %qubit0_out_26 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_21) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_21) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rx(%cst_6) %38 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_24) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rx(%cst_23) %22 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_24) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rx(%cst_22) %45 : !qco.qubit -> !qco.qubit
    %qubit0_out_28, %qubit1_out_29 = qco.rzz(%cst_21) %46, %43 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %47 = qco.rx(%cst_20) %qubit1_out_29 : !qco.qubit -> !qco.qubit
    %48 = qco.rz(%cst_19) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rx(%cst_18) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_17) %qubit0_out_28 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_5) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rx(%cst_17) %51 : !qco.qubit -> !qco.qubit
    %qubit0_out_30, %qubit1_out_31 = qco.rzz(%cst_21) %52, %49 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %53 = qco.rx(%cst_15) %qubit1_out_31 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_4) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rx(%cst_3) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rx(%cst_2) %qubit0_out_30 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_21) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_21) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rx(%cst_25) %55 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_24) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rx(%cst_23) %19 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_24) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rx(%cst_22) %62 : !qco.qubit -> !qco.qubit
    %qubit0_out_32, %qubit1_out_33 = qco.rzz(%cst_21) %63, %60 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %64 = qco.rx(%cst_20) %qubit1_out_33 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_19) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rx(%cst_18) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rx(%cst_17) %qubit0_out_32 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_8) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rx(%cst_17) %68 : !qco.qubit -> !qco.qubit
    %qubit0_out_34, %qubit1_out_35 = qco.rzz(%cst_21) %69, %66 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %70 = qco.rx(%cst_15) %qubit1_out_35 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_7) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rx(%cst_13) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_21) %qubit0_out_34 : !qco.qubit -> !qco.qubit
    %74 = qco.rx(%cst_21) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rx(%cst_25) %72 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_24) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rx(%cst_23) %16 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_24) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rx(%cst_22) %78 : !qco.qubit -> !qco.qubit
    %qubit0_out_36, %qubit1_out_37 = qco.rzz(%cst_21) %79, %76 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %80 = qco.rx(%cst_20) %qubit1_out_37 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_19) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rx(%cst_18) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rx(%cst_17) %qubit0_out_36 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_10) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rx(%cst_17) %84 : !qco.qubit -> !qco.qubit
    %qubit0_out_38, %qubit1_out_39 = qco.rzz(%cst_21) %85, %82 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %86 = qco.rx(%cst_15) %qubit1_out_39 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_9) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rx(%cst_13) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.rz(%cst_21) %qubit0_out_38 : !qco.qubit -> !qco.qubit
    %90 = qco.rx(%cst_21) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rx(%cst_25) %88 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_24) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rx(%cst_23) %13 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_24) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rx(%cst_22) %94 : !qco.qubit -> !qco.qubit
    %qubit0_out_40, %qubit1_out_41 = qco.rzz(%cst_21) %95, %92 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %96 = qco.rx(%cst_20) %qubit1_out_41 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_19) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rx(%cst_18) %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rx(%cst_17) %qubit0_out_40 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_12) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.rx(%cst_17) %100 : !qco.qubit -> !qco.qubit
    %qubit0_out_42, %qubit1_out_43 = qco.rzz(%cst_21) %101, %98 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %102 = qco.rx(%cst_15) %qubit1_out_43 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst_11) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rx(%cst_13) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst_21) %qubit0_out_42 : !qco.qubit -> !qco.qubit
    %106 = qco.rx(%cst_21) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rx(%cst_25) %104 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_24) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rx(%cst_23) %10 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst_24) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rx(%cst_22) %110 : !qco.qubit -> !qco.qubit
    %qubit0_out_44, %qubit1_out_45 = qco.rzz(%cst_21) %111, %108 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %112 = qco.rx(%cst_20) %qubit1_out_45 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_19) %112 : !qco.qubit -> !qco.qubit
    %114 = qco.rx(%cst_18) %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rx(%cst_17) %qubit0_out_44 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst_16) %115 : !qco.qubit -> !qco.qubit
    %117 = qco.rx(%cst_17) %116 : !qco.qubit -> !qco.qubit
    %qubit0_out_46, %qubit1_out_47 = qco.rzz(%cst_21) %117, %114 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %118 = qco.rx(%cst_15) %qubit1_out_47 : !qco.qubit -> !qco.qubit
    %119 = qco.rz(%cst_14) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.rx(%cst_13) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rz(%cst_21) %qubit0_out_46 : !qco.qubit -> !qco.qubit
    %122 = qco.rx(%cst_21) %121 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %120 : !qco.qubit
    cbit.store %result, %7[%c0] : !cbit.reg<7>
    %qubit_out_48, %result_49 = qco.measure %122 : !qco.qubit
    cbit.store %result_49, %7[%c1] : !cbit.reg<7>
    %qubit_out_50, %result_51 = qco.measure %106 : !qco.qubit
    cbit.store %result_51, %7[%c2] : !cbit.reg<7>
    %qubit_out_52, %result_53 = qco.measure %90 : !qco.qubit
    cbit.store %result_53, %7[%c3] : !cbit.reg<7>
    %qubit_out_54, %result_55 = qco.measure %74 : !qco.qubit
    cbit.store %result_55, %7[%c4] : !cbit.reg<7>
    %qubit_out_56, %result_57 = qco.measure %58 : !qco.qubit
    cbit.store %result_57, %7[%c5] : !cbit.reg<7>
    qco.sink %qubit_out_48 : !qco.qubit
    qco.sink %qubit_out_50 : !qco.qubit
    qco.sink %qubit_out_52 : !qco.qubit
    qco.sink %qubit_out_54 : !qco.qubit
    qco.sink %qubit_out_56 : !qco.qubit
    %qubit_out_58, %result_59 = qco.measure %41 : !qco.qubit
    qco.sink %qubit_out_58 : !qco.qubit
    cbit.store %result_59, %7[%c6] : !cbit.reg<7>
    qco.sink %qubit_out : !qco.qubit
    return %7 : !cbit.reg<7>
  }
}
