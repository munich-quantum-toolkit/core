module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 1.692378069204338 : f64
    %cst_0 = arith.constant 3.2372089537235489 : f64
    %cst_1 = arith.constant 0.60283548945758003 : f64
    %cst_2 = arith.constant 4.8678311294584828 : f64
    %cst_3 = arith.constant 1.0061459307786649 : f64
    %cst_4 = arith.constant 4.2332842346068036 : f64
    %cst_5 = arith.constant 4.7669418028860102 : f64
    %cst_6 = arith.constant 4.5953251390072261 : f64
    %cst_7 = arith.constant 0.11888888386212493 : f64
    %cst_8 = arith.constant 4.4588523966648923 : f64
    %cst_9 = arith.constant 2.6224857423258001 : f64
    %cst_10 = arith.constant 5.6100533141107558 : f64
    %cst_11 = arith.constant 3.4465240828623616 : f64
    %cst_12 = arith.constant 5.6626956550635681 : f64
    %cst_13 = arith.constant 1.2058296498649499 : f64
    %cst_14 = arith.constant 3.4517052679728941 : f64
    %cst_15 = arith.constant 2.9164052298172143 : f64
    %cst_16 = arith.constant 3.5904989308112265 : f64
    %cst_17 = arith.constant 5.2104649567227765 : f64
    %cst_18 = arith.constant 5.3839419137933335 : f64
    %cst_19 = arith.constant 5.7555033344075799 : f64
    %cst_20 = arith.constant 5.6597330532866676 : f64
    %cst_21 = arith.constant -3.1415926535897931 : f64
    %cst_22 = arith.constant 4.047423588284575 : f64
    %cst_23 = arith.constant 4.1952478754800913 : f64
    %cst_24 = arith.constant 1.3619104989145452 : f64
    %cst_25 = arith.constant 6.0824814649890691 : f64
    %cst_26 = arith.constant 3.1415926535897931 : f64
    %cst_27 = arith.constant 1.4860340580195168 : f64
    %cst_28 = arith.constant 3.8126462235677083 : f64
    %cst_29 = arith.constant 3.1415926535897936 : f64
    %cst_30 = arith.constant 2.9125430424466168 : f64
    %cst_31 = arith.constant 3.8962707397538181 : f64
    %cst_32 = arith.constant 2.6537432184157899 : f64
    %cst_33 = arith.constant 5.2940337675068845 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.sx %0 : !qco.qubit -> !qco.qubit
    %5 = qco.rz(%cst_33) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_32) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.sx %1 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_31) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_30) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_29) %2 : !qco.qubit -> !qco.qubit
    %13 = qco.sx %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_28) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_27) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_26) %3 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_25) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.sx %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_24) %20 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%21) targets (%arg0 = %7) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_34, %targets_out_35 = qco.ctrl(%targets_out) targets (%arg0 = %11) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_36, %targets_out_37 = qco.ctrl(%targets_out_35) targets (%arg0 = %16) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_38, %targets_out_39 = qco.ctrl(%targets_out_37) targets (%arg0 = %controls_out) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.sx %controls_out_34 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_23) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_22) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_21) %controls_out_36 : !qco.qubit -> !qco.qubit
    %27 = qco.sx %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_20) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.sx %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_19) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %controls_out_38 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_18) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.sx %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_17) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.sx %targets_out_39 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_16) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.sx %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_15) %37 : !qco.qubit -> !qco.qubit
    %controls_out_40, %targets_out_41 = qco.ctrl(%38) targets (%arg0 = %25) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_42, %targets_out_43 = qco.ctrl(%targets_out_41) targets (%arg0 = %30) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_44, %targets_out_45 = qco.ctrl(%targets_out_43) targets (%arg0 = %34) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_46, %targets_out_47 = qco.ctrl(%targets_out_45) targets (%arg0 = %controls_out_40) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.sx %controls_out_42 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_14) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.sx %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_13) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %controls_out_44 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_12) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.sx %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_11) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_26) %controls_out_46 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_10) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.sx %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_9) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_26) %targets_out_47 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_8) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.sx %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_7) %55 : !qco.qubit -> !qco.qubit
    %controls_out_48, %targets_out_49 = qco.ctrl(%56) targets (%arg0 = %42) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_50, %targets_out_51 = qco.ctrl(%targets_out_49) targets (%arg0 = %46) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_52, %targets_out_53 = qco.ctrl(%targets_out_51) targets (%arg0 = %51) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_54, %targets_out_55 = qco.ctrl(%targets_out_53) targets (%arg0 = %controls_out_48) {
      %74 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %74 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %57 = qco.sx %controls_out_50 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_6) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.sx %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_5) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.sx %controls_out_52 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_4) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.sx %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_3) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_26) %controls_out_54 : !qco.qubit -> !qco.qubit
    %66 = qco.sx %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_2) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.sx %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_1) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.sx %targets_out_55 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_0) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.sx %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst) %72 : !qco.qubit -> !qco.qubit
    qco.sink %60 : !qco.qubit
    qco.sink %64 : !qco.qubit
    qco.sink %69 : !qco.qubit
    qco.sink %73 : !qco.qubit
    return %c0_i64 : i64
  }
}
