module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main(%arg0: f64 {mqt.input_id = 12927349219598359841868690406665925546 : i128, mqt.input_name = "theta[0]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 0 : i64, name = "theta", size = 12 : i64}}, %arg1: f64 {mqt.input_id = 12927349219598359841868690406665925547 : i128, mqt.input_name = "theta[1]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 1 : i64, name = "theta", size = 12 : i64}}, %arg2: f64 {mqt.input_id = 12927349219598359841868690406665925548 : i128, mqt.input_name = "theta[2]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 2 : i64, name = "theta", size = 12 : i64}}, %arg3: f64 {mqt.input_id = 12927349219598359841868690406665925549 : i128, mqt.input_name = "theta[3]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 3 : i64, name = "theta", size = 12 : i64}}, %arg4: f64 {mqt.input_id = 12927349219598359841868690406665925550 : i128, mqt.input_name = "theta[4]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 4 : i64, name = "theta", size = 12 : i64}}, %arg5: f64 {mqt.input_id = 12927349219598359841868690406665925551 : i128, mqt.input_name = "theta[5]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 5 : i64, name = "theta", size = 12 : i64}}, %arg6: f64 {mqt.input_id = 12927349219598359841868690406665925552 : i128, mqt.input_name = "theta[6]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 6 : i64, name = "theta", size = 12 : i64}}, %arg7: f64 {mqt.input_id = 12927349219598359841868690406665925553 : i128, mqt.input_name = "theta[7]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 7 : i64, name = "theta", size = 12 : i64}}, %arg8: f64 {mqt.input_id = 12927349219598359841868690406665925554 : i128, mqt.input_name = "theta[8]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 8 : i64, name = "theta", size = 12 : i64}}, %arg9: f64 {mqt.input_id = 12927349219598359841868690406665925555 : i128, mqt.input_name = "theta[9]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 9 : i64, name = "theta", size = 12 : i64}}, %arg10: f64 {mqt.input_id = 12927349219598359841868690406665925556 : i128, mqt.input_name = "theta[10]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 10 : i64, name = "theta", size = 12 : i64}}, %arg11: f64 {mqt.input_id = 12927349219598359841868690406665925557 : i128, mqt.input_name = "theta[11]", mqt.parameter_group = {identity = "09b9b786-850a-468b-b6a5-f77e6d00b3aa", index = 11 : i64, name = "theta", size = 12 : i64}}) -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 1.7707963267948965 : f64
    %cst_0 = arith.constant 3.4415926535897929 : f64
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %cst_2 = arith.constant 1.3707963267948966 : f64
    %cst_3 = arith.constant 4.000000e+00 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = arith.divf %arg0, %cst_3 : f64
    %5 = math.tan %4 : f64
    %6 = math.atan %5 : f64
    %7 = arith.mulf %6, %cst_3 : f64
    %8 = arith.addf %7, %cst_2 : f64
    %9 = qco.rz(%8) %0 : !qco.qubit -> !qco.qubit
    %10 = qco.rx(%cst_1) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_0) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_1) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst) %12 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%13) targets (%arg12 = %1) {
      %124 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = arith.divf %arg1, %cst_3 : f64
    %15 = math.tan %14 : f64
    %16 = math.atan %15 : f64
    %17 = arith.mulf %16, %cst_3 : f64
    %18 = arith.addf %17, %cst_2 : f64
    %19 = qco.rz(%18) %targets_out : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_1) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_0) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst_1) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst) %22 : !qco.qubit -> !qco.qubit
    %controls_out_4, %targets_out_5 = qco.ctrl(%23) targets (%arg12 = %2) {
      %124 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %24 = arith.divf %arg2, %cst_3 : f64
    %25 = math.tan %24 : f64
    %26 = math.atan %25 : f64
    %27 = arith.mulf %26, %cst_3 : f64
    %28 = arith.addf %27, %cst_2 : f64
    %29 = qco.rz(%28) %targets_out_5 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_1) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_0) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rx(%cst_1) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst) %32 : !qco.qubit -> !qco.qubit
    %controls_out_6, %targets_out_7 = qco.ctrl(%33) targets (%arg12 = %3) {
      %124 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = arith.divf %arg3, %cst_3 : f64
    %35 = math.tan %34 : f64
    %36 = math.atan %35 : f64
    %37 = arith.mulf %36, %cst_3 : f64
    %38 = arith.addf %37, %cst_2 : f64
    %39 = qco.rz(%38) %targets_out_7 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_1) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_0) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rx(%cst_1) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst) %42 : !qco.qubit -> !qco.qubit
    %controls_out_8, %targets_out_9 = qco.ctrl(%43) targets (%arg12 = %controls_out) {
      %124 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = arith.divf %arg4, %cst_3 : f64
    %45 = math.tan %44 : f64
    %46 = math.atan %45 : f64
    %47 = arith.mulf %46, %cst_3 : f64
    %48 = arith.addf %47, %cst_2 : f64
    %49 = qco.rz(%48) %targets_out_9 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_1) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_0) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rx(%cst_1) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst) %52 : !qco.qubit -> !qco.qubit
    %controls_out_10, %targets_out_11 = qco.ctrl(%53) targets (%arg12 = %controls_out_4) {
      %124 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %54 = arith.divf %arg5, %cst_3 : f64
    %55 = math.tan %54 : f64
    %56 = math.atan %55 : f64
    %57 = arith.mulf %56, %cst_3 : f64
    %58 = arith.addf %57, %cst_2 : f64
    %59 = qco.rz(%58) %targets_out_11 : !qco.qubit -> !qco.qubit
    %60 = qco.rx(%cst_1) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_0) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rx(%cst_1) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst) %62 : !qco.qubit -> !qco.qubit
    %controls_out_12, %targets_out_13 = qco.ctrl(%63) targets (%arg12 = %controls_out_6) {
      %124 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %64 = arith.divf %arg6, %cst_3 : f64
    %65 = math.tan %64 : f64
    %66 = math.atan %65 : f64
    %67 = arith.mulf %66, %cst_3 : f64
    %68 = arith.addf %67, %cst_2 : f64
    %69 = qco.rz(%68) %targets_out_13 : !qco.qubit -> !qco.qubit
    %70 = qco.rx(%cst_1) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_0) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rx(%cst_1) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst) %72 : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%73) targets (%arg12 = %controls_out_8) {
      %124 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %74 = arith.divf %arg7, %cst_3 : f64
    %75 = math.tan %74 : f64
    %76 = math.atan %75 : f64
    %77 = arith.mulf %76, %cst_3 : f64
    %78 = arith.addf %77, %cst_2 : f64
    %79 = qco.rz(%78) %targets_out_15 : !qco.qubit -> !qco.qubit
    %80 = qco.rx(%cst_1) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_0) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rx(%cst_1) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst) %82 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%83) targets (%arg12 = %controls_out_10) {
      %124 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %84 = arith.divf %arg8, %cst_3 : f64
    %85 = math.tan %84 : f64
    %86 = math.atan %85 : f64
    %87 = arith.mulf %86, %cst_3 : f64
    %88 = arith.addf %87, %cst_2 : f64
    %89 = qco.rz(%88) %targets_out_17 : !qco.qubit -> !qco.qubit
    %90 = qco.rx(%cst_1) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_0) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rx(%cst_1) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst) %92 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%93) targets (%arg12 = %controls_out_12) {
      %124 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %94 = arith.divf %arg9, %cst_3 : f64
    %95 = math.tan %94 : f64
    %96 = math.atan %95 : f64
    %97 = arith.mulf %96, %cst_3 : f64
    %98 = arith.addf %97, %cst_2 : f64
    %99 = qco.rz(%98) %targets_out_19 : !qco.qubit -> !qco.qubit
    %100 = qco.rx(%cst_1) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst_0) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rx(%cst_1) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst) %102 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%103) targets (%arg12 = %controls_out_14) {
      %124 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %104 = arith.divf %arg10, %cst_3 : f64
    %105 = math.tan %104 : f64
    %106 = math.atan %105 : f64
    %107 = arith.mulf %106, %cst_3 : f64
    %108 = arith.addf %107, %cst_2 : f64
    %109 = qco.rz(%108) %targets_out_21 : !qco.qubit -> !qco.qubit
    %110 = qco.rx(%cst_1) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_0) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rx(%cst_1) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst) %112 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%113) targets (%arg12 = %controls_out_16) {
      %124 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %114 = arith.divf %arg11, %cst_3 : f64
    %115 = math.tan %114 : f64
    %116 = math.atan %115 : f64
    %117 = arith.mulf %116, %cst_3 : f64
    %118 = arith.addf %117, %cst_2 : f64
    %119 = qco.rz(%118) %targets_out_23 : !qco.qubit -> !qco.qubit
    %120 = qco.rx(%cst_1) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.rz(%cst_0) %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rx(%cst_1) %121 : !qco.qubit -> !qco.qubit
    %123 = qco.rz(%cst) %122 : !qco.qubit -> !qco.qubit
    qco.sink %controls_out_20 : !qco.qubit
    qco.sink %controls_out_22 : !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%123) targets (%arg12 = %controls_out_18) {
      %124 = qco.z %arg12 : !qco.qubit -> !qco.qubit
      qco.yield %124 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    qco.sink %targets_out_25 : !qco.qubit
    qco.sink %controls_out_24 : !qco.qubit
    return %c0_i64 : i64
  }
}
