module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<15> attributes {mqt.entry_point} {
    %cst = arith.constant 3.1415926535897931 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant 0.000000e+00 : f64
    %cst_2 = arith.constant 9.4247779607693793 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<15>
    %17 = qco.r(%cst_2, %cst_1) %0 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_0, %cst_0) %1 : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst, %cst_1) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_0, %cst_0) %3 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst, %cst_1) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_0, %cst_0) %5 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst, %cst_1) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_0, %cst_0) %7 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst, %cst_1) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_0, %cst_0) %9 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst, %cst_1) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_0, %cst_0) %11 : !qco.qubit -> !qco.qubit
    %29 = qco.r(%cst, %cst_1) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_0, %cst_0) %13 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%cst, %cst_1) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_0, %cst_0) %15 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst, %cst_1) %32 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%19) targets (%arg0 = %17) {
      %50 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_3, %targets_out_4 = qco.ctrl(%21) targets (%arg0 = %targets_out) {
      %50 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_5, %targets_out_6 = qco.ctrl(%23) targets (%arg0 = %targets_out_4) {
      %50 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_7, %targets_out_8 = qco.ctrl(%25) targets (%arg0 = %targets_out_6) {
      %50 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_9, %targets_out_10 = qco.ctrl(%27) targets (%arg0 = %targets_out_8) {
      %50 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_11, %targets_out_12 = qco.ctrl(%29) targets (%arg0 = %targets_out_10) {
      %50 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_13, %targets_out_14 = qco.ctrl(%31) targets (%arg0 = %targets_out_12) {
      %50 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_15, %targets_out_16 = qco.ctrl(%33) targets (%arg0 = %targets_out_14) {
      %50 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %50 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %34 = qco.r(%cst_0, %cst_0) %controls_out : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst, %cst_1) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_0, %cst_0) %controls_out_3 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%cst, %cst_1) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst_0, %cst_0) %controls_out_5 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst, %cst_1) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_0, %cst_0) %controls_out_7 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst, %cst_1) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst_0, %cst_0) %controls_out_9 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%cst, %cst_1) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_0, %cst_0) %controls_out_11 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst, %cst_1) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.r(%cst_0, %cst_0) %controls_out_13 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%cst, %cst_1) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst_0, %cst_0) %controls_out_15 : !qco.qubit -> !qco.qubit
    %49 = qco.r(%cst, %cst_1) %48 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %35 : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<15>
    %qubit_out_17, %result_18 = qco.measure %2 : !qco.qubit
    cbit.store %result_18, %16[%c1] : !cbit.reg<15>
    %qubit_out_19, %result_20 = qco.measure %37 : !qco.qubit
    cbit.store %result_20, %16[%c2] : !cbit.reg<15>
    %qubit_out_21, %result_22 = qco.measure %4 : !qco.qubit
    cbit.store %result_22, %16[%c3] : !cbit.reg<15>
    %qubit_out_23, %result_24 = qco.measure %39 : !qco.qubit
    cbit.store %result_24, %16[%c4] : !cbit.reg<15>
    %qubit_out_25, %result_26 = qco.measure %6 : !qco.qubit
    cbit.store %result_26, %16[%c5] : !cbit.reg<15>
    %qubit_out_27, %result_28 = qco.measure %41 : !qco.qubit
    cbit.store %result_28, %16[%c6] : !cbit.reg<15>
    %qubit_out_29, %result_30 = qco.measure %8 : !qco.qubit
    cbit.store %result_30, %16[%c7] : !cbit.reg<15>
    %qubit_out_31, %result_32 = qco.measure %43 : !qco.qubit
    cbit.store %result_32, %16[%c8] : !cbit.reg<15>
    %qubit_out_33, %result_34 = qco.measure %10 : !qco.qubit
    cbit.store %result_34, %16[%c9] : !cbit.reg<15>
    %qubit_out_35, %result_36 = qco.measure %45 : !qco.qubit
    cbit.store %result_36, %16[%c10] : !cbit.reg<15>
    %qubit_out_37, %result_38 = qco.measure %12 : !qco.qubit
    cbit.store %result_38, %16[%c11] : !cbit.reg<15>
    %qubit_out_39, %result_40 = qco.measure %47 : !qco.qubit
    cbit.store %result_40, %16[%c12] : !cbit.reg<15>
    %qubit_out_41, %result_42 = qco.measure %14 : !qco.qubit
    cbit.store %result_42, %16[%c13] : !cbit.reg<15>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_17 : !qco.qubit
    qco.sink %qubit_out_19 : !qco.qubit
    qco.sink %qubit_out_21 : !qco.qubit
    qco.sink %qubit_out_23 : !qco.qubit
    qco.sink %qubit_out_25 : !qco.qubit
    qco.sink %qubit_out_27 : !qco.qubit
    qco.sink %qubit_out_29 : !qco.qubit
    qco.sink %qubit_out_31 : !qco.qubit
    qco.sink %qubit_out_33 : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    qco.sink %qubit_out_37 : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    qco.sink %qubit_out_41 : !qco.qubit
    %qubit_out_43, %result_44 = qco.measure %49 : !qco.qubit
    qco.sink %qubit_out_43 : !qco.qubit
    cbit.store %result_44, %16[%c14] : !cbit.reg<15>
    qco.sink %targets_out_16 : !qco.qubit
    %cst_45 = arith.constant -1.5707963267948966 : f64
    qco.gphase(%cst_45)
    return %16 : !cbit.reg<15>
  }
}
