module attributes {mqt.layout = {initial = array<i64: 1, 2, 0>, input_count = 3 : i64, sites = array<i64: 0, 1, 2>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<3> attributes {mqt.entry_point} {
    %cst = arith.constant -3.9269908169872418 : f64
    %cst_0 = arith.constant 3.9269908169872423 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %cst_2 = arith.constant 1.5707963267948968 : f64
    %cst_3 = arith.constant 2.7488935718910694 : f64
    %cst_4 = arith.constant 3.1415926535897931 : f64
    %cst_5 = arith.constant 3.5342917352885177 : f64
    %cst_6 = arith.constant -4.7123889803846897 : f64
    %cst_7 = arith.constant 3.9269908169872414 : f64
    %cst_8 = arith.constant 5.497787143782138 : f64
    %cst_9 = arith.constant 4.7123889803846897 : f64
    %cst_10 = arith.constant 1.5707963267948966 : f64
    %cst_11 = arith.constant -6.2831853071795862 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<3>
    %4 = qco.rz(%cst_10) %1 : !qco.qubit -> !qco.qubit
    %5 = qco.sx %4 : !qco.qubit -> !qco.qubit
    %6 = qco.rz(%cst_10) %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_10) %2 : !qco.qubit -> !qco.qubit
    %8 = qco.sx %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_10) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %0 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_2) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_1) %12 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%13) targets (%arg0 = %11) {
      %43 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %14 = qco.rz(%cst_8) %targets_out : !qco.qubit -> !qco.qubit
    %15 = qco.x %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_7) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_6) %controls_out : !qco.qubit -> !qco.qubit
    %18 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_0) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.sx %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_4) %20 : !qco.qubit -> !qco.qubit
    %controls_out_12, %targets_out_13 = qco.ctrl(%21) targets (%arg0 = %16) {
      %43 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.rz(%cst) %targets_out_13 : !qco.qubit -> !qco.qubit
    %23 = qco.sx %22 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %controls_out_12 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_4) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_11) %23 : !qco.qubit -> !qco.qubit
    %27 = qco.sx %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_10) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.sx %6 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_9) %29 : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%30) targets (%arg0 = %28) {
      %43 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %31 = qco.rz(%cst_8) %targets_out_15 : !qco.qubit -> !qco.qubit
    %32 = qco.x %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_7) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_6) %controls_out_14 : !qco.qubit -> !qco.qubit
    %35 = qco.sx %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_5) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.sx %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_4) %37 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%38) targets (%arg0 = %33) {
      %43 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %43 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.rz(%cst_3) %targets_out_17 : !qco.qubit -> !qco.qubit
    %40 = qco.sx %39 : !qco.qubit -> !qco.qubit
    %41 = qco.sx %controls_out_16 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_4) %41 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %40 : !qco.qubit
    cbit.store %result, %3[%c0] : !cbit.reg<3>
    %qubit_out_18, %result_19 = qco.measure %42 : !qco.qubit
    cbit.store %result_19, %3[%c1] : !cbit.reg<3>
    qco.sink %qubit_out_18 : !qco.qubit
    %qubit_out_20, %result_21 = qco.measure %25 : !qco.qubit
    qco.sink %qubit_out_20 : !qco.qubit
    cbit.store %result_21, %3[%c2] : !cbit.reg<3>
    qco.sink %qubit_out : !qco.qubit
    %cst_22 = arith.constant 1.5707963267949001 : f64
    qco.gphase(%cst_22)
    return %3 : !cbit.reg<3>
  }
}
