module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 0>, input_count = 5 : i64, sites = array<i64: 0, 1, 2, 3, 4>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<5> attributes {mqt.entry_point} {
    %cst = arith.constant 2.3561944901923453 : f64
    %cst_0 = arith.constant 2.3561944901923439 : f64
    %cst_1 = arith.constant 1.5707963267948968 : f64
    %cst_2 = arith.constant -6.2831853071795862 : f64
    %cst_3 = arith.constant -1.5707963267948961 : f64
    %cst_4 = arith.constant 1.9634954084936209 : f64
    %cst_5 = arith.constant 2.7488935718910685 : f64
    %cst_6 = arith.constant -4.7123889803846897 : f64
    %cst_7 = arith.constant 1.7671458676442588 : f64
    %cst_8 = arith.constant 2.9452431127404317 : f64
    %cst_9 = arith.constant 4.7123889803846897 : f64
    %cst_10 = arith.constant 1.6689710972195777 : f64
    %cst_11 = arith.constant -3.1415926535897931 : f64
    %cst_12 = arith.constant 3.0434178831651124 : f64
    %cst_13 = arith.constant -1.5707963267948966 : f64
    %cst_14 = arith.constant 3.752318617979002 : f64
    %cst_15 = arith.constant 3.1415926535897931 : f64
    %cst_16 = arith.constant 0.6107259643892089 : f64
    %cst_17 = arith.constant 1.5707963267948966 : f64
    %cst_18 = arith.constant 6.2831853071795862 : f64
    %cst_19 = arith.constant -1.570796326794897 : f64
    %cst_20 = arith.constant 1.570796326794897 : f64
    %cst_21 = arith.constant 1.5707963267948961 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<5>
    %6 = qco.rx(%cst_17) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_17) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rx(%cst_17) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_17) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_17) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_17) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rx(%cst_17) %3 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_17) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_17) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_17) %4 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_17) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_17) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rx(%cst_21) %0 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_20) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst_13) %17 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_1) %20 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_17) %21, %19 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %22 = qco.rx(%cst_16) %qubit1_out : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_15) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_14) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_13) %qubit0_out : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_0) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_13) %26 : !qco.qubit -> !qco.qubit
    %qubit0_out_22, %qubit1_out_23 = qco.rzz(%cst_17) %27, %24 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %28 = qco.rx(%cst_11) %qubit1_out_23 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_9) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_2) %qubit0_out_22 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_17) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_17) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_6) %30 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_20) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_19) %14 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_20) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rx(%cst_18) %37 : !qco.qubit -> !qco.qubit
    %qubit0_out_24, %qubit1_out_25 = qco.rzz(%cst_17) %38, %35 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %39 = qco.rx(%cst_16) %qubit1_out_25 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_15) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rx(%cst_14) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rx(%cst_13) %qubit0_out_24 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_5) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rx(%cst_13) %43 : !qco.qubit -> !qco.qubit
    %qubit0_out_26, %qubit1_out_27 = qco.rzz(%cst_17) %44, %41 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %45 = qco.rx(%cst_11) %qubit1_out_27 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_4) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rx(%cst_3) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.rx(%cst_2) %qubit0_out_26 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_17) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rx(%cst_17) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rx(%cst_21) %47 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_20) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rx(%cst_19) %11 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_20) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rx(%cst_18) %54 : !qco.qubit -> !qco.qubit
    %qubit0_out_28, %qubit1_out_29 = qco.rzz(%cst_17) %55, %52 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %56 = qco.rx(%cst_16) %qubit1_out_29 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_15) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rx(%cst_14) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rx(%cst_13) %qubit0_out_28 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_8) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rx(%cst_13) %60 : !qco.qubit -> !qco.qubit
    %qubit0_out_30, %qubit1_out_31 = qco.rzz(%cst_17) %61, %58 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %62 = qco.rx(%cst_11) %qubit1_out_31 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_7) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rx(%cst_9) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_17) %qubit0_out_30 : !qco.qubit -> !qco.qubit
    %66 = qco.rx(%cst_17) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rx(%cst_21) %64 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_20) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rx(%cst_19) %8 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_20) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_18) %70 : !qco.qubit -> !qco.qubit
    %qubit0_out_32, %qubit1_out_33 = qco.rzz(%cst_17) %71, %68 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %72 = qco.rx(%cst_16) %qubit1_out_33 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_15) %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rx(%cst_14) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rx(%cst_13) %qubit0_out_32 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_12) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rx(%cst_13) %76 : !qco.qubit -> !qco.qubit
    %qubit0_out_34, %qubit1_out_35 = qco.rzz(%cst_17) %77, %74 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %78 = qco.rx(%cst_11) %qubit1_out_35 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_10) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rx(%cst_9) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_17) %qubit0_out_34 : !qco.qubit -> !qco.qubit
    %82 = qco.rx(%cst_17) %81 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %80 : !qco.qubit
    cbit.store %result, %5[%c0] : !cbit.reg<5>
    %qubit_out_36, %result_37 = qco.measure %82 : !qco.qubit
    cbit.store %result_37, %5[%c1] : !cbit.reg<5>
    %qubit_out_38, %result_39 = qco.measure %66 : !qco.qubit
    cbit.store %result_39, %5[%c2] : !cbit.reg<5>
    %qubit_out_40, %result_41 = qco.measure %50 : !qco.qubit
    cbit.store %result_41, %5[%c3] : !cbit.reg<5>
    qco.sink %qubit_out_36 : !qco.qubit
    qco.sink %qubit_out_38 : !qco.qubit
    qco.sink %qubit_out_40 : !qco.qubit
    %qubit_out_42, %result_43 = qco.measure %33 : !qco.qubit
    qco.sink %qubit_out_42 : !qco.qubit
    cbit.store %result_43, %5[%c4] : !cbit.reg<5>
    qco.sink %qubit_out : !qco.qubit
    qco.gphase(%cst_15)
    return %5 : !cbit.reg<5>
  }
}
