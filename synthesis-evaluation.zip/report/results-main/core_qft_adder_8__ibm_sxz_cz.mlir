module attributes {mqt.layout = {initial = array<i64: 3, 1, 2, 0, 5, 7, 4, 6>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<8> attributes {mqt.entry_point} {
    %cst = arith.constant 7.7558068635498021 : f64
    %cst_0 = arith.constant 1.3744467859455352 : f64
    %cst_1 = arith.constant 2.7488935718910694 : f64
    %cst_2 = arith.constant 7.6576320931251214 : f64
    %cst_3 = arith.constant 2.7488935718910685 : f64
    %cst_4 = arith.constant 2.3561944901923448 : f64
    %cst_5 = arith.constant 9.0320788790706548 : f64
    %cst_6 = arith.constant 4.7123889803846897 : f64
    %cst_7 = arith.constant -1.3744467859455347 : f64
    %cst_8 = arith.constant -1.4726215563702154 : f64
    %cst_9 = arith.constant 4.9087385212340511 : f64
    %cst_10 = arith.constant 5.1050880620834143 : f64
    %cst_11 = arith.constant 3.2397674240144743 : f64
    %cst_12 = arith.constant -0.098174770424680716 : f64
    %cst_13 = arith.constant 3.5342917352885168 : f64
    %cst_14 = arith.constant 3.337942194439155 : f64
    %cst_15 = arith.constant -0.1963495408493619 : f64
    %cst_16 = arith.constant 1.5707963267948966 : f64
    %cst_17 = arith.constant 3.5342917352885173 : f64
    %cst_18 = arith.constant -0.39269908169872414 : f64
    %cst_19 = arith.constant 3.9269908169872423 : f64
    %cst_20 = arith.constant -1.5707963267948966 : f64
    %cst_21 = arith.constant -0.78539816339744828 : f64
    %cst_22 = arith.constant -1.1780972450961724 : f64
    %cst_23 = arith.constant 3.9269908169872405 : f64
    %cst_24 = arith.constant -0.39269908169872392 : f64
    %cst_25 = arith.constant -3.1415926535897931 : f64
    %cst_26 = arith.constant -2.9452431127404313 : f64
    %cst_27 = arith.constant 3.5342917352885177 : f64
    %cst_28 = arith.constant -0.19634954084936185 : f64
    %cst_29 = arith.constant -3.1415926535897927 : f64
    %cst_30 = arith.constant -3.0434178831651124 : f64
    %cst_31 = arith.constant 3.3379421944391545 : f64
    %cst_32 = arith.constant 3.9269908169872414 : f64
    %cst_33 = arith.constant 5.497787143782138 : f64
    %cst_34 = arith.constant 1.5707963267948961 : f64
    %cst_35 = arith.constant 3.1415926535897931 : f64
    %cst_36 = arith.constant -4.7123889803846897 : f64
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.x %0 : !qco.qubit -> !qco.qubit
    %9 = qco.x %1 : !qco.qubit -> !qco.qubit
    %10 = qco.x %4 : !qco.qubit -> !qco.qubit
    %11 = qco.x %5 : !qco.qubit -> !qco.qubit
    %12 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<8>
    %13 = qco.rz(%cst_16) %6 : !qco.qubit -> !qco.qubit
    %14 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_25) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.sx %10 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_20) %16 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%17) targets (%arg0 = %15) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %18 = qco.rz(%cst_33) %targets_out : !qco.qubit -> !qco.qubit
    %19 = qco.x %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_32) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_36) %controls_out : !qco.qubit -> !qco.qubit
    %22 = qco.sx %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_19) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_35) %24 : !qco.qubit -> !qco.qubit
    %controls_out_37, %targets_out_38 = qco.ctrl(%25) targets (%arg0 = %20) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.rz(%cst_18) %targets_out_38 : !qco.qubit -> !qco.qubit
    %27 = qco.x %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rz(%cst_10) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.sx %controls_out_37 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_33) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %7 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_20) %31 : !qco.qubit -> !qco.qubit
    %controls_out_39, %targets_out_40 = qco.ctrl(%32) targets (%arg0 = %28) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %33 = qco.rz(%cst_33) %targets_out_40 : !qco.qubit -> !qco.qubit
    %34 = qco.x %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_32) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_36) %controls_out_39 : !qco.qubit -> !qco.qubit
    %37 = qco.sx %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_27) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_35) %39 : !qco.qubit -> !qco.qubit
    %controls_out_41, %targets_out_42 = qco.ctrl(%40) targets (%arg0 = %35) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.rz(%cst_15) %targets_out_42 : !qco.qubit -> !qco.qubit
    %42 = qco.x %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rz(%cst_9) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.sx %controls_out_41 : !qco.qubit -> !qco.qubit
    %45 = qco.rz(%cst_13) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_20) %46 : !qco.qubit -> !qco.qubit
    %controls_out_43, %targets_out_44 = qco.ctrl(%47) targets (%arg0 = %43) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %48 = qco.rz(%cst_33) %targets_out_44 : !qco.qubit -> !qco.qubit
    %49 = qco.x %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_32) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_36) %controls_out_43 : !qco.qubit -> !qco.qubit
    %52 = qco.sx %51 : !qco.qubit -> !qco.qubit
    %53 = qco.rz(%cst_31) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.sx %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_35) %54 : !qco.qubit -> !qco.qubit
    %controls_out_45, %targets_out_46 = qco.ctrl(%55) targets (%arg0 = %50) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qco.rz(%cst_12) %targets_out_46 : !qco.qubit -> !qco.qubit
    %57 = qco.x %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_11) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.sx %controls_out_45 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_14) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_25) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.sx %45 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_20) %63 : !qco.qubit -> !qco.qubit
    %controls_out_47, %targets_out_48 = qco.ctrl(%64) targets (%arg0 = %62) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qco.rz(%cst_33) %targets_out_48 : !qco.qubit -> !qco.qubit
    %66 = qco.x %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_32) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_36) %controls_out_47 : !qco.qubit -> !qco.qubit
    %69 = qco.sx %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_19) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.sx %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_35) %71 : !qco.qubit -> !qco.qubit
    %controls_out_49, %targets_out_50 = qco.ctrl(%72) targets (%arg0 = %67) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %73 = qco.rz(%cst_18) %targets_out_50 : !qco.qubit -> !qco.qubit
    %74 = qco.x %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_10) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.sx %controls_out_49 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_33) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.sx %60 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_20) %78 : !qco.qubit -> !qco.qubit
    %controls_out_51, %targets_out_52 = qco.ctrl(%79) targets (%arg0 = %75) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %80 = qco.rz(%cst_33) %targets_out_52 : !qco.qubit -> !qco.qubit
    %81 = qco.x %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_32) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_36) %controls_out_51 : !qco.qubit -> !qco.qubit
    %84 = qco.sx %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_27) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.sx %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_35) %86 : !qco.qubit -> !qco.qubit
    %controls_out_53, %targets_out_54 = qco.ctrl(%87) targets (%arg0 = %82) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %88 = qco.rz(%cst_15) %targets_out_54 : !qco.qubit -> !qco.qubit
    %89 = qco.x %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_14) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.sx %controls_out_53 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_13) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.sx %77 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_25) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.sx %92 : !qco.qubit -> !qco.qubit
    %96 = qco.rz(%cst_20) %95 : !qco.qubit -> !qco.qubit
    %controls_out_55, %targets_out_56 = qco.ctrl(%96) targets (%arg0 = %94) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %97 = qco.rz(%cst_33) %targets_out_56 : !qco.qubit -> !qco.qubit
    %98 = qco.x %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_32) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_36) %controls_out_55 : !qco.qubit -> !qco.qubit
    %101 = qco.sx %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_19) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.sx %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_35) %103 : !qco.qubit -> !qco.qubit
    %controls_out_57, %targets_out_58 = qco.ctrl(%104) targets (%arg0 = %99) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %105 = qco.rz(%cst_18) %targets_out_58 : !qco.qubit -> !qco.qubit
    %106 = qco.x %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rz(%cst_17) %106 : !qco.qubit -> !qco.qubit
    %108 = qco.sx %controls_out_57 : !qco.qubit -> !qco.qubit
    %109 = qco.rz(%cst_33) %108 : !qco.qubit -> !qco.qubit
    %110 = qco.sx %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_16) %110 : !qco.qubit -> !qco.qubit
    %controls_out_59, %targets_out_60 = qco.ctrl(%8) targets (%arg0 = %58) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %112 = qco.rz(%cst_36) %targets_out_60 : !qco.qubit -> !qco.qubit
    %113 = qco.sx %2 : !qco.qubit -> !qco.qubit
    %114 = qco.rz(%cst_20) %113 : !qco.qubit -> !qco.qubit
    %controls_out_61, %targets_out_62 = qco.ctrl(%114) targets (%arg0 = %112) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %115 = qco.rz(%cst_33) %targets_out_62 : !qco.qubit -> !qco.qubit
    %116 = qco.x %115 : !qco.qubit -> !qco.qubit
    %117 = qco.rz(%cst_32) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.rz(%cst_36) %controls_out_61 : !qco.qubit -> !qco.qubit
    %119 = qco.sx %118 : !qco.qubit -> !qco.qubit
    %120 = qco.rz(%cst_19) %119 : !qco.qubit -> !qco.qubit
    %121 = qco.sx %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rz(%cst_35) %121 : !qco.qubit -> !qco.qubit
    %controls_out_63, %targets_out_64 = qco.ctrl(%122) targets (%arg0 = %117) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %123 = qco.rz(%cst_18) %targets_out_64 : !qco.qubit -> !qco.qubit
    %124 = qco.x %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rz(%cst_10) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.sx %controls_out_63 : !qco.qubit -> !qco.qubit
    %127 = qco.rz(%cst_32) %126 : !qco.qubit -> !qco.qubit
    %128 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %129 = qco.rz(%cst_20) %128 : !qco.qubit -> !qco.qubit
    %controls_out_65, %targets_out_66 = qco.ctrl(%129) targets (%arg0 = %125) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %130 = qco.rz(%cst_33) %targets_out_66 : !qco.qubit -> !qco.qubit
    %131 = qco.x %130 : !qco.qubit -> !qco.qubit
    %132 = qco.rz(%cst_32) %131 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst_36) %controls_out_65 : !qco.qubit -> !qco.qubit
    %134 = qco.sx %133 : !qco.qubit -> !qco.qubit
    %135 = qco.rz(%cst_27) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.sx %135 : !qco.qubit -> !qco.qubit
    %137 = qco.rz(%cst_35) %136 : !qco.qubit -> !qco.qubit
    %controls_out_67, %targets_out_68 = qco.ctrl(%137) targets (%arg0 = %132) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %138 = qco.rz(%cst_15) %targets_out_68 : !qco.qubit -> !qco.qubit
    %139 = qco.x %138 : !qco.qubit -> !qco.qubit
    %140 = qco.rz(%cst_9) %139 : !qco.qubit -> !qco.qubit
    %141 = qco.sx %controls_out_67 : !qco.qubit -> !qco.qubit
    %142 = qco.rz(%cst_13) %141 : !qco.qubit -> !qco.qubit
    %143 = qco.sx %3 : !qco.qubit -> !qco.qubit
    %144 = qco.rz(%cst_20) %143 : !qco.qubit -> !qco.qubit
    %controls_out_69, %targets_out_70 = qco.ctrl(%144) targets (%arg0 = %140) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %145 = qco.rz(%cst_33) %targets_out_70 : !qco.qubit -> !qco.qubit
    %146 = qco.x %145 : !qco.qubit -> !qco.qubit
    %147 = qco.rz(%cst_32) %146 : !qco.qubit -> !qco.qubit
    %148 = qco.rz(%cst_36) %controls_out_69 : !qco.qubit -> !qco.qubit
    %149 = qco.sx %148 : !qco.qubit -> !qco.qubit
    %150 = qco.rz(%cst_31) %149 : !qco.qubit -> !qco.qubit
    %151 = qco.sx %150 : !qco.qubit -> !qco.qubit
    %152 = qco.rz(%cst_35) %151 : !qco.qubit -> !qco.qubit
    %controls_out_71, %targets_out_72 = qco.ctrl(%152) targets (%arg0 = %147) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %153 = qco.rz(%cst_12) %targets_out_72 : !qco.qubit -> !qco.qubit
    %154 = qco.x %153 : !qco.qubit -> !qco.qubit
    %155 = qco.rz(%cst_8) %154 : !qco.qubit -> !qco.qubit
    %156 = qco.sx %controls_out_71 : !qco.qubit -> !qco.qubit
    %157 = qco.rz(%cst_14) %156 : !qco.qubit -> !qco.qubit
    %controls_out_73, %targets_out_74 = qco.ctrl(%127) targets (%arg0 = %90) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %158 = qco.rz(%cst_36) %targets_out_74 : !qco.qubit -> !qco.qubit
    %159 = qco.sx %142 : !qco.qubit -> !qco.qubit
    %160 = qco.rz(%cst_20) %159 : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%160) targets (%arg0 = %158) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %161 = qco.rz(%cst_33) %targets_out_76 : !qco.qubit -> !qco.qubit
    %162 = qco.x %161 : !qco.qubit -> !qco.qubit
    %163 = qco.rz(%cst_32) %162 : !qco.qubit -> !qco.qubit
    %164 = qco.rz(%cst_36) %controls_out_75 : !qco.qubit -> !qco.qubit
    %165 = qco.sx %164 : !qco.qubit -> !qco.qubit
    %166 = qco.rz(%cst_19) %165 : !qco.qubit -> !qco.qubit
    %167 = qco.sx %166 : !qco.qubit -> !qco.qubit
    %168 = qco.rz(%cst_35) %167 : !qco.qubit -> !qco.qubit
    %controls_out_77, %targets_out_78 = qco.ctrl(%168) targets (%arg0 = %163) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %169 = qco.rz(%cst_18) %targets_out_78 : !qco.qubit -> !qco.qubit
    %170 = qco.x %169 : !qco.qubit -> !qco.qubit
    %171 = qco.rz(%cst_10) %170 : !qco.qubit -> !qco.qubit
    %172 = qco.sx %controls_out_77 : !qco.qubit -> !qco.qubit
    %173 = qco.rz(%cst_32) %172 : !qco.qubit -> !qco.qubit
    %174 = qco.sx %157 : !qco.qubit -> !qco.qubit
    %175 = qco.rz(%cst_20) %174 : !qco.qubit -> !qco.qubit
    %controls_out_79, %targets_out_80 = qco.ctrl(%175) targets (%arg0 = %171) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %176 = qco.rz(%cst_33) %targets_out_80 : !qco.qubit -> !qco.qubit
    %177 = qco.x %176 : !qco.qubit -> !qco.qubit
    %178 = qco.rz(%cst_32) %177 : !qco.qubit -> !qco.qubit
    %179 = qco.rz(%cst_36) %controls_out_79 : !qco.qubit -> !qco.qubit
    %180 = qco.sx %179 : !qco.qubit -> !qco.qubit
    %181 = qco.rz(%cst_27) %180 : !qco.qubit -> !qco.qubit
    %182 = qco.sx %181 : !qco.qubit -> !qco.qubit
    %183 = qco.rz(%cst_35) %182 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%183) targets (%arg0 = %178) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %184 = qco.rz(%cst_15) %targets_out_82 : !qco.qubit -> !qco.qubit
    %185 = qco.x %184 : !qco.qubit -> !qco.qubit
    %186 = qco.rz(%cst_7) %185 : !qco.qubit -> !qco.qubit
    %187 = qco.sx %controls_out_81 : !qco.qubit -> !qco.qubit
    %188 = qco.rz(%cst_13) %187 : !qco.qubit -> !qco.qubit
    %controls_out_83, %targets_out_84 = qco.ctrl(%173) targets (%arg0 = %107) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %189 = qco.rz(%cst_36) %targets_out_84 : !qco.qubit -> !qco.qubit
    %190 = qco.sx %188 : !qco.qubit -> !qco.qubit
    %191 = qco.rz(%cst_20) %190 : !qco.qubit -> !qco.qubit
    %controls_out_85, %targets_out_86 = qco.ctrl(%191) targets (%arg0 = %189) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %192 = qco.rz(%cst_33) %targets_out_86 : !qco.qubit -> !qco.qubit
    %193 = qco.x %192 : !qco.qubit -> !qco.qubit
    %194 = qco.rz(%cst_32) %193 : !qco.qubit -> !qco.qubit
    %195 = qco.rz(%cst_36) %controls_out_85 : !qco.qubit -> !qco.qubit
    %196 = qco.sx %195 : !qco.qubit -> !qco.qubit
    %197 = qco.rz(%cst_19) %196 : !qco.qubit -> !qco.qubit
    %198 = qco.sx %197 : !qco.qubit -> !qco.qubit
    %199 = qco.rz(%cst_35) %198 : !qco.qubit -> !qco.qubit
    %controls_out_87, %targets_out_88 = qco.ctrl(%199) targets (%arg0 = %194) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %200 = qco.rz(%cst_18) %targets_out_88 : !qco.qubit -> !qco.qubit
    %201 = qco.x %200 : !qco.qubit -> !qco.qubit
    %202 = qco.rz(%cst_22) %201 : !qco.qubit -> !qco.qubit
    %203 = qco.sx %controls_out_87 : !qco.qubit -> !qco.qubit
    %204 = qco.rz(%cst_32) %203 : !qco.qubit -> !qco.qubit
    %controls_out_89, %targets_out_90 = qco.ctrl(%204) targets (%arg0 = %111) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %205 = qco.rz(%cst_16) %targets_out_90 : !qco.qubit -> !qco.qubit
    %206 = qco.sx %205 : !qco.qubit -> !qco.qubit
    %207 = qco.rz(%cst_6) %206 : !qco.qubit -> !qco.qubit
    %208 = qco.sx %207 : !qco.qubit -> !qco.qubit
    %209 = qco.rz(%cst_34) %208 : !qco.qubit -> !qco.qubit
    %controls_out_91, %targets_out_92 = qco.ctrl(%209) targets (%arg0 = %202) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %210 = qco.rz(%cst_33) %targets_out_92 : !qco.qubit -> !qco.qubit
    %211 = qco.x %210 : !qco.qubit -> !qco.qubit
    %212 = qco.rz(%cst_32) %211 : !qco.qubit -> !qco.qubit
    %213 = qco.rz(%cst_36) %controls_out_91 : !qco.qubit -> !qco.qubit
    %214 = qco.sx %213 : !qco.qubit -> !qco.qubit
    %215 = qco.rz(%cst_23) %214 : !qco.qubit -> !qco.qubit
    %216 = qco.sx %215 : !qco.qubit -> !qco.qubit
    %217 = qco.rz(%cst_35) %216 : !qco.qubit -> !qco.qubit
    %controls_out_93, %targets_out_94 = qco.ctrl(%217) targets (%arg0 = %212) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %218 = qco.rz(%cst_22) %targets_out_94 : !qco.qubit -> !qco.qubit
    %219 = qco.x %218 : !qco.qubit -> !qco.qubit
    %220 = qco.rz(%cst_5) %219 : !qco.qubit -> !qco.qubit
    %221 = qco.rz(%cst_29) %controls_out_93 : !qco.qubit -> !qco.qubit
    %222 = qco.sx %221 : !qco.qubit -> !qco.qubit
    %223 = qco.rz(%cst_4) %222 : !qco.qubit -> !qco.qubit
    %224 = qco.sx %220 : !qco.qubit -> !qco.qubit
    %225 = qco.rz(%cst_6) %224 : !qco.qubit -> !qco.qubit
    %226 = qco.sx %225 : !qco.qubit -> !qco.qubit
    %227 = qco.rz(%cst_34) %226 : !qco.qubit -> !qco.qubit
    %controls_out_95, %targets_out_96 = qco.ctrl(%227) targets (%arg0 = %186) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %228 = qco.rz(%cst_33) %targets_out_96 : !qco.qubit -> !qco.qubit
    %229 = qco.x %228 : !qco.qubit -> !qco.qubit
    %230 = qco.rz(%cst_32) %229 : !qco.qubit -> !qco.qubit
    %231 = qco.rz(%cst_36) %controls_out_95 : !qco.qubit -> !qco.qubit
    %232 = qco.sx %231 : !qco.qubit -> !qco.qubit
    %233 = qco.rz(%cst_23) %232 : !qco.qubit -> !qco.qubit
    %234 = qco.sx %233 : !qco.qubit -> !qco.qubit
    %235 = qco.rz(%cst_35) %234 : !qco.qubit -> !qco.qubit
    %controls_out_97, %targets_out_98 = qco.ctrl(%235) targets (%arg0 = %230) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %236 = qco.rz(%cst_22) %targets_out_98 : !qco.qubit -> !qco.qubit
    %237 = qco.x %236 : !qco.qubit -> !qco.qubit
    %238 = qco.rz(%cst_3) %237 : !qco.qubit -> !qco.qubit
    %239 = qco.rz(%cst_29) %controls_out_97 : !qco.qubit -> !qco.qubit
    %240 = qco.sx %239 : !qco.qubit -> !qco.qubit
    %241 = qco.rz(%cst_4) %240 : !qco.qubit -> !qco.qubit
    %242 = qco.sx %223 : !qco.qubit -> !qco.qubit
    %243 = qco.rz(%cst_34) %242 : !qco.qubit -> !qco.qubit
    %controls_out_99, %targets_out_100 = qco.ctrl(%243) targets (%arg0 = %238) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %244 = qco.rz(%cst_33) %targets_out_100 : !qco.qubit -> !qco.qubit
    %245 = qco.x %244 : !qco.qubit -> !qco.qubit
    %246 = qco.rz(%cst_32) %245 : !qco.qubit -> !qco.qubit
    %247 = qco.rz(%cst_36) %controls_out_99 : !qco.qubit -> !qco.qubit
    %248 = qco.sx %247 : !qco.qubit -> !qco.qubit
    %249 = qco.rz(%cst_27) %248 : !qco.qubit -> !qco.qubit
    %250 = qco.sx %249 : !qco.qubit -> !qco.qubit
    %251 = qco.rz(%cst_35) %250 : !qco.qubit -> !qco.qubit
    %controls_out_101, %targets_out_102 = qco.ctrl(%251) targets (%arg0 = %246) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %252 = qco.rz(%cst_26) %targets_out_102 : !qco.qubit -> !qco.qubit
    %253 = qco.x %252 : !qco.qubit -> !qco.qubit
    %254 = qco.rz(%cst_2) %253 : !qco.qubit -> !qco.qubit
    %255 = qco.rz(%cst_25) %controls_out_101 : !qco.qubit -> !qco.qubit
    %256 = qco.sx %255 : !qco.qubit -> !qco.qubit
    %257 = qco.rz(%cst_1) %256 : !qco.qubit -> !qco.qubit
    %258 = qco.sx %254 : !qco.qubit -> !qco.qubit
    %259 = qco.rz(%cst_6) %258 : !qco.qubit -> !qco.qubit
    %260 = qco.sx %259 : !qco.qubit -> !qco.qubit
    %261 = qco.rz(%cst_34) %260 : !qco.qubit -> !qco.qubit
    %controls_out_103, %targets_out_104 = qco.ctrl(%261) targets (%arg0 = %155) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %262 = qco.rz(%cst_33) %targets_out_104 : !qco.qubit -> !qco.qubit
    %263 = qco.x %262 : !qco.qubit -> !qco.qubit
    %264 = qco.rz(%cst_32) %263 : !qco.qubit -> !qco.qubit
    %265 = qco.rz(%cst_36) %controls_out_103 : !qco.qubit -> !qco.qubit
    %266 = qco.sx %265 : !qco.qubit -> !qco.qubit
    %267 = qco.rz(%cst_23) %266 : !qco.qubit -> !qco.qubit
    %268 = qco.sx %267 : !qco.qubit -> !qco.qubit
    %269 = qco.rz(%cst_35) %268 : !qco.qubit -> !qco.qubit
    %controls_out_105, %targets_out_106 = qco.ctrl(%269) targets (%arg0 = %264) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %270 = qco.rz(%cst_22) %targets_out_106 : !qco.qubit -> !qco.qubit
    %271 = qco.x %270 : !qco.qubit -> !qco.qubit
    %272 = qco.rz(%cst_3) %271 : !qco.qubit -> !qco.qubit
    %273 = qco.rz(%cst_29) %controls_out_105 : !qco.qubit -> !qco.qubit
    %274 = qco.sx %273 : !qco.qubit -> !qco.qubit
    %275 = qco.rz(%cst_21) %274 : !qco.qubit -> !qco.qubit
    %276 = qco.sx %241 : !qco.qubit -> !qco.qubit
    %277 = qco.rz(%cst_34) %276 : !qco.qubit -> !qco.qubit
    %controls_out_107, %targets_out_108 = qco.ctrl(%277) targets (%arg0 = %272) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %278 = qco.rz(%cst_33) %targets_out_108 : !qco.qubit -> !qco.qubit
    %279 = qco.x %278 : !qco.qubit -> !qco.qubit
    %280 = qco.rz(%cst_32) %279 : !qco.qubit -> !qco.qubit
    %281 = qco.rz(%cst_36) %controls_out_107 : !qco.qubit -> !qco.qubit
    %282 = qco.sx %281 : !qco.qubit -> !qco.qubit
    %283 = qco.rz(%cst_27) %282 : !qco.qubit -> !qco.qubit
    %284 = qco.sx %283 : !qco.qubit -> !qco.qubit
    %285 = qco.rz(%cst_35) %284 : !qco.qubit -> !qco.qubit
    %controls_out_109, %targets_out_110 = qco.ctrl(%285) targets (%arg0 = %280) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %286 = qco.rz(%cst_26) %targets_out_110 : !qco.qubit -> !qco.qubit
    %287 = qco.x %286 : !qco.qubit -> !qco.qubit
    %288 = qco.rz(%cst_0) %287 : !qco.qubit -> !qco.qubit
    %289 = qco.rz(%cst_25) %controls_out_109 : !qco.qubit -> !qco.qubit
    %290 = qco.sx %289 : !qco.qubit -> !qco.qubit
    %291 = qco.rz(%cst_24) %290 : !qco.qubit -> !qco.qubit
    %292 = qco.sx %257 : !qco.qubit -> !qco.qubit
    %293 = qco.rz(%cst_34) %292 : !qco.qubit -> !qco.qubit
    %controls_out_111, %targets_out_112 = qco.ctrl(%293) targets (%arg0 = %288) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %294 = qco.rz(%cst_33) %targets_out_112 : !qco.qubit -> !qco.qubit
    %295 = qco.x %294 : !qco.qubit -> !qco.qubit
    %296 = qco.rz(%cst_32) %295 : !qco.qubit -> !qco.qubit
    %297 = qco.rz(%cst_36) %controls_out_111 : !qco.qubit -> !qco.qubit
    %298 = qco.sx %297 : !qco.qubit -> !qco.qubit
    %299 = qco.rz(%cst_31) %298 : !qco.qubit -> !qco.qubit
    %300 = qco.sx %299 : !qco.qubit -> !qco.qubit
    %301 = qco.rz(%cst_35) %300 : !qco.qubit -> !qco.qubit
    %controls_out_113, %targets_out_114 = qco.ctrl(%301) targets (%arg0 = %296) {
      %310 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %310 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %302 = qco.rz(%cst_30) %targets_out_114 : !qco.qubit -> !qco.qubit
    %303 = qco.x %302 : !qco.qubit -> !qco.qubit
    %304 = qco.rz(%cst) %303 : !qco.qubit -> !qco.qubit
    %305 = qco.rz(%cst_29) %controls_out_113 : !qco.qubit -> !qco.qubit
    %306 = qco.sx %305 : !qco.qubit -> !qco.qubit
    %307 = qco.rz(%cst_28) %306 : !qco.qubit -> !qco.qubit
    %308 = qco.sx %304 : !qco.qubit -> !qco.qubit
    %309 = qco.rz(%cst_16) %308 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %307 : !qco.qubit
    cbit.store %result, %12[%c0] : !cbit.reg<8>
    %qubit_out_115, %result_116 = qco.measure %291 : !qco.qubit
    cbit.store %result_116, %12[%c1] : !cbit.reg<8>
    %qubit_out_117, %result_118 = qco.measure %275 : !qco.qubit
    cbit.store %result_118, %12[%c2] : !cbit.reg<8>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_115 : !qco.qubit
    qco.sink %qubit_out_117 : !qco.qubit
    %qubit_out_119, %result_120 = qco.measure %309 : !qco.qubit
    qco.sink %qubit_out_119 : !qco.qubit
    cbit.store %result_120, %12[%c3] : !cbit.reg<8>
    %qubit_out_121, %result_122 = qco.measure %controls_out_89 : !qco.qubit
    cbit.store %result_122, %12[%c4] : !cbit.reg<8>
    %qubit_out_123, %result_124 = qco.measure %controls_out_83 : !qco.qubit
    cbit.store %result_124, %12[%c5] : !cbit.reg<8>
    %qubit_out_125, %result_126 = qco.measure %controls_out_73 : !qco.qubit
    cbit.store %result_126, %12[%c6] : !cbit.reg<8>
    qco.sink %qubit_out_121 : !qco.qubit
    qco.sink %qubit_out_123 : !qco.qubit
    qco.sink %qubit_out_125 : !qco.qubit
    %qubit_out_127, %result_128 = qco.measure %controls_out_59 : !qco.qubit
    qco.sink %qubit_out_127 : !qco.qubit
    cbit.store %result_128, %12[%c7] : !cbit.reg<8>
    %cst_129 = arith.constant -1.4726215563701839 : f64
    qco.gphase(%cst_129)
    return %12 : !cbit.reg<8>
  }
}
