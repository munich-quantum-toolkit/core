module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rx", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rzz", arity = <kind = fixed, value = 2>, num_parameters = 1, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 6.3031826411527367 : f64
    %cst_0 = arith.constant 3.1415926535897922 : f64
    %cst_1 = arith.constant -3.1215953196166426 : f64
    %cst_2 = arith.constant 2.0943951023931948 : f64
    %cst_3 = arith.constant -2.3637982847085901 : f64
    %cst_4 = arith.constant 1.0471975511965983 : f64
    %cst_5 = arith.constant 1.570796326794897 : f64
    %cst_6 = arith.constant 2.8269801602550242 : f64
    %cst_7 = arith.constant -5.0270014737194586 : f64
    %cst_8 = arith.constant 4.7891608716544676 : f64
    %cst_9 = arith.constant 3.1415926535897905 : f64
    %cst_10 = arith.constant -1.4940244355251184 : f64
    %cst_11 = arith.constant 2.1862760354652839 : f64
    %cst_12 = arith.constant 3.1415926535897931 : f64
    %cst_13 = arith.constant 5.3278686890550775 : f64
    %cst_14 = arith.constant 1.5707963267948939 : f64
    %cst_15 = arith.constant -1.5543122344752192E-15 : f64
    %cst_16 = arith.constant -4.7123889803846897 : f64
    %cst_17 = arith.constant 6.2831853071795862 : f64
    %cst_18 = arith.constant -1.5707963267948966 : f64
    %cst_19 = arith.constant 4.7123889803846897 : f64
    %cst_20 = arith.constant 2.3561944901923444 : f64
    %cst_21 = arith.constant 1.5707963267948966 : f64
    %cst_22 = arith.constant 2.3561944901923457 : f64
    %cst_23 = arith.constant 1.5707963267948974 : f64
    %cst_24 = arith.constant -6.2831853071795853 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.rx(%cst_12) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.rx(%cst_12) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_5) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rx(%cst_4) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rx(%cst_3) %5 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_12) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rx(%cst_3) %10 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.rzz(%cst_21) %11, %8 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %12 = qco.rx(%cst_21) %qubit1_out : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_2) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rx(%cst_19) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rx(%cst_18) %qubit0_out : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_21) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rx(%cst_18) %16 : !qco.qubit -> !qco.qubit
    %qubit0_out_25, %qubit1_out_26 = qco.rzz(%cst_21) %17, %14 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %18 = qco.rx(%cst_1) %qubit1_out_26 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_0) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rx(%cst) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rx(%cst_18) %qubit0_out_25 : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst_15) %2 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_14) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rx(%cst_13) %23 : !qco.qubit -> !qco.qubit
    %qubit0_out_27, %qubit1_out_28 = qco.rzz(%cst_21) %20, %24 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %25 = qco.rx(%cst_21) %qubit1_out_28 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_11) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rx(%cst_19) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_18) %qubit0_out_27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_21) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rx(%cst_18) %29 : !qco.qubit -> !qco.qubit
    %qubit0_out_29, %qubit1_out_30 = qco.rzz(%cst_21) %30, %27 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %31 = qco.rx(%cst_10) %qubit1_out_30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_9) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rx(%cst_8) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_7) %qubit0_out_29 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_9) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rx(%cst_6) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rx(%cst_24) %3 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_23) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rx(%cst_22) %38 : !qco.qubit -> !qco.qubit
    %qubit0_out_31, %qubit1_out_32 = qco.rzz(%cst_21) %33, %39 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %40 = qco.rx(%cst_21) %qubit1_out_32 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_20) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rx(%cst_19) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_18) %qubit0_out_31 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_21) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rx(%cst_18) %44 : !qco.qubit -> !qco.qubit
    %qubit0_out_33, %qubit1_out_34 = qco.rzz(%cst_21) %45, %42 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %46 = qco.rx(%cst_17) %qubit1_out_34 : !qco.qubit -> !qco.qubit
    %47 = qco.rx(%cst_16) %qubit0_out_33 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %21 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<4>
    %qubit_out_35, %result_36 = qco.measure %36 : !qco.qubit
    cbit.store %result_36, %4[%c1] : !cbit.reg<4>
    %qubit_out_37, %result_38 = qco.measure %47 : !qco.qubit
    cbit.store %result_38, %4[%c2] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    qco.sink %qubit_out_37 : !qco.qubit
    %qubit_out_39, %result_40 = qco.measure %46 : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    cbit.store %result_40, %4[%c3] : !cbit.reg<4>
    %cst_41 = arith.constant 2.3561944901923422 : f64
    qco.gphase(%cst_41)
    return %4 : !cbit.reg<4>
  }
}
