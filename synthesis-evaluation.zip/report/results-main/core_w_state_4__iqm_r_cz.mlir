module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 5.759586531581288 : f64
    %cst_0 = arith.constant 5.9617708255034509 : f64
    %cst_1 = arith.constant 2.6179938779914944 : f64
    %cst_2 = arith.constant 1.5707963267948961 : f64
    %cst_3 = arith.constant 5.6677055985091993 : f64
    %cst_4 = arith.constant 0.61547970867038737 : f64
    %cst_5 = arith.constant 3.1415926535897931 : f64
    %cst_6 = arith.constant 1.5707963267948954 : f64
    %cst_7 = arith.constant 7.8539816339744828 : f64
    %cst_8 = arith.constant 1.570796326794897 : f64
    %cst_9 = arith.constant 7.8539816339744819 : f64
    %cst_10 = arith.constant 1.5707963267948968 : f64
    %cst_11 = arith.constant 4.7123889803846897 : f64
    %cst_12 = arith.constant 1.5707963267948963 : f64
    %cst_13 = arith.constant 5.4977871437821388 : f64
    %cst_14 = arith.constant 3.1415926535897922 : f64
    %cst_15 = arith.constant 3.9269908169872423 : f64
    %cst_16 = arith.constant 1.5707963267948966 : f64
    %cst_17 = arith.constant 1.5707963267948974 : f64
    %cst_18 = arith.constant 0.000000e+00 : f64
    %cst_19 = arith.constant -1.5707963267948957 : f64
    %cst_20 = arith.constant 9.4247779607693793 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.r(%cst_20, %cst_18) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.r(%cst_7, %cst_18) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.r(%cst_2, %cst_16) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_1, %cst_18) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_0, %cst_18) %5 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_14, %cst_16) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_0, %cst_18) %10 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%11) targets (%arg0 = %8) {
      %49 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %49 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %12 = qco.r(%cst, %cst_18) %targets_out : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_12, %cst_16) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_11, %cst_18) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_16, %cst_16) %controls_out : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_10, %cst_18) %15 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%16) targets (%arg0 = %14) {
      %49 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %49 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.r(%cst_19, %cst_18) %targets_out_22 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_16, %cst_16) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst_10, %cst_18) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_17, %cst_18) %controls_out_21 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_8, %cst_16) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_11, %cst_18) %2 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_16, %cst_16) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_4, %cst_18) %23 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%19) targets (%arg0 = %24) {
      %49 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %49 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %25 = qco.r(%cst_3, %cst_18) %targets_out_24 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst_2, %cst_16) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst_11, %cst_18) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_16, %cst_16) %controls_out_23 : !qco.qubit -> !qco.qubit
    %29 = qco.r(%cst_10, %cst_18) %28 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%29) targets (%arg0 = %27) {
      %49 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %49 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.r(%cst_11, %cst_18) %targets_out_26 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%cst_8, %cst_16) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_11, %cst_18) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_11, %cst_18) %controls_out_25 : !qco.qubit -> !qco.qubit
    %34 = qco.r(%cst_8, %cst_16) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst_19, %cst_18) %3 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_17, %cst_16) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%cst_15, %cst_18) %36 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%32) targets (%arg0 = %37) {
      %49 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %49 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qco.r(%cst_13, %cst_18) %targets_out_28 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst_12, %cst_16) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_11, %cst_18) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst_16, %cst_16) %controls_out_27 : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst_10, %cst_18) %41 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%42) targets (%arg0 = %40) {
      %49 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %49 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qco.r(%cst_9, %cst_18) %targets_out_30 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_8, %cst_16) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst_11, %cst_18) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.r(%cst_7, %cst_18) %controls_out_29 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%cst_6, %cst_16) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst_5, %cst_18) %47 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %21 : !qco.qubit
    cbit.store %result, %4[%c0] : !cbit.reg<4>
    %qubit_out_31, %result_32 = qco.measure %34 : !qco.qubit
    cbit.store %result_32, %4[%c1] : !cbit.reg<4>
    %qubit_out_33, %result_34 = qco.measure %48 : !qco.qubit
    cbit.store %result_34, %4[%c2] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_31 : !qco.qubit
    qco.sink %qubit_out_33 : !qco.qubit
    %qubit_out_35, %result_36 = qco.measure %45 : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    cbit.store %result_36, %4[%c3] : !cbit.reg<4>
    %cst_37 = arith.constant -2.3561944901923422 : f64
    qco.gphase(%cst_37)
    return %4 : !cbit.reg<4>
  }
}
