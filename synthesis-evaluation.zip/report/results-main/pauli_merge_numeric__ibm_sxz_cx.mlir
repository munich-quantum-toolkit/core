module attributes {mqt.layout = {initial = array<i64: 0, 1>, input_count = 2 : i64, sites = array<i64: 0, 1>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant -3.1415926535897927 : f64
    %cst_0 = arith.constant 7.8539816339744828 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %cst_2 = arith.constant 4.0115926535897932 : f64
    %cst_3 = arith.constant -4.7123889803846897 : f64
    %cst_4 = arith.constant 1.5707963267948961 : f64
    %cst_5 = arith.constant 3.1415926535897931 : f64
    %cst_6 = arith.constant 1.5707963267948966 : f64
    %cst_7 = arith.constant -6.2831853071795862 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.rz(%cst_7) %1 : !qco.qubit -> !qco.qubit
    %3 = qco.sx %2 : !qco.qubit -> !qco.qubit
    %4 = qco.rz(%cst_6) %3 : !qco.qubit -> !qco.qubit
    %5 = qco.rz(%cst_5) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_4) %6 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%7) targets (%arg0 = %4) {
      %21 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %21 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %8 = qco.rz(%cst_7) %targets_out : !qco.qubit -> !qco.qubit
    %9 = qco.sx %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_5) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_3) %controls_out : !qco.qubit -> !qco.qubit
    %12 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_2) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_5) %14 : !qco.qubit -> !qco.qubit
    %controls_out_8, %targets_out_9 = qco.ctrl(%15) targets (%arg0 = %10) {
      %21 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %21 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %16 = qco.rz(%cst_1) %targets_out_9 : !qco.qubit -> !qco.qubit
    %17 = qco.sx %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_0) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst) %controls_out_8 : !qco.qubit -> !qco.qubit
    %20 = qco.sx %19 : !qco.qubit -> !qco.qubit
    qco.sink %18 : !qco.qubit
    qco.sink %20 : !qco.qubit
    %cst_10 = arith.constant 2.3561944901923466 : f64
    qco.gphase(%cst_10)
    return %c0_i64 : i64
  }
}
