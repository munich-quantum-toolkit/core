module attributes {mqt.layout = {initial = array<i64: 3, 2, 0, 1>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant 5.497787143782138 : f64
    %cst_0 = arith.constant 3.337942194439155 : f64
    %cst_1 = arith.constant 1.7671458676442582 : f64
    %cst_2 = arith.constant 3.1415926535897927 : f64
    %cst_3 = arith.constant 3.3379421944391554 : f64
    %cst_4 = arith.constant 3.5342917352885168 : f64
    %cst_5 = arith.constant 1.9634954084936203 : f64
    %cst_6 = arith.constant -1.5707963267948963 : f64
    %cst_7 = arith.constant 3.5342917352885181 : f64
    %cst_8 = arith.constant 2.3561944901923444 : f64
    %cst_9 = arith.constant 3.9269908169872432 : f64
    %cst_10 = arith.constant -4.7123889803846897 : f64
    %cst_11 = arith.constant 3.1415926535897931 : f64
    %cst_12 = arith.constant -1.5707963267948966 : f64
    %cst_13 = arith.constant 1.5707963267948966 : f64
    %cst_14 = arith.constant -6.2831853071795862 : f64
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %5 = qco.rz(%cst_13) %0 : !qco.qubit -> !qco.qubit
    %6 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %7 = qco.rz(%cst_13) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_14) %1 : !qco.qubit -> !qco.qubit
    %9 = qco.sx %8 : !qco.qubit -> !qco.qubit
    %10 = qco.rz(%cst_13) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.sx %7 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_12) %11 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%12) targets (%arg0 = %10) {
      %117 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %117 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %13 = qco.rz(%cst_14) %targets_out : !qco.qubit -> !qco.qubit
    %14 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_11) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_10) %controls_out : !qco.qubit -> !qco.qubit
    %17 = qco.sx %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_9) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.sx %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_11) %19 : !qco.qubit -> !qco.qubit
    %controls_out_15, %targets_out_16 = qco.ctrl(%20) targets (%arg0 = %15) {
      %117 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %117 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.rz(%cst_12) %targets_out_16 : !qco.qubit -> !qco.qubit
    %22 = qco.sx %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_8) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %controls_out_15 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_13) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %2 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_12) %28 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%29) targets (%arg0 = %27) {
      %117 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %117 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.rz(%cst_14) %targets_out_18 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_11) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_10) %controls_out_17 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_7) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.sx %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_11) %36 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%37) targets (%arg0 = %32) {
      %117 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %117 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qco.rz(%cst_6) %targets_out_20 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_5) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.sx %controls_out_19 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_4) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %40 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_13) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.sx %3 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_12) %45 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%46) targets (%arg0 = %44) {
      %117 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %117 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.rz(%cst_14) %targets_out_22 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_11) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_10) %controls_out_21 : !qco.qubit -> !qco.qubit
    %51 = qco.sx %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_3) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_2) %53 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%54) targets (%arg0 = %49) {
      %117 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %117 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.rz(%cst_6) %targets_out_24 : !qco.qubit -> !qco.qubit
    %56 = qco.sx %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_1) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.sx %controls_out_23 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_0) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.sx %25 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_10) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.sx %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_13) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.sx %42 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_12) %64 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%65) targets (%arg0 = %63) {
      %117 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %117 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %66 = qco.rz(%cst_14) %targets_out_26 : !qco.qubit -> !qco.qubit
    %67 = qco.sx %66 : !qco.qubit -> !qco.qubit
    %68 = qco.rz(%cst_11) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_10) %controls_out_25 : !qco.qubit -> !qco.qubit
    %70 = qco.sx %69 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_9) %70 : !qco.qubit -> !qco.qubit
    %72 = qco.sx %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rz(%cst_11) %72 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%73) targets (%arg0 = %68) {
      %117 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %117 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %74 = qco.rz(%cst_12) %targets_out_28 : !qco.qubit -> !qco.qubit
    %75 = qco.sx %74 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_8) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.sx %controls_out_27 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.sx %76 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_13) %79 : !qco.qubit -> !qco.qubit
    %81 = qco.sx %59 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_12) %81 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%82) targets (%arg0 = %80) {
      %117 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %117 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %83 = qco.rz(%cst_14) %targets_out_30 : !qco.qubit -> !qco.qubit
    %84 = qco.sx %83 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_11) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_10) %controls_out_29 : !qco.qubit -> !qco.qubit
    %87 = qco.sx %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_7) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.sx %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_11) %89 : !qco.qubit -> !qco.qubit
    %controls_out_31, %targets_out_32 = qco.ctrl(%90) targets (%arg0 = %85) {
      %117 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %117 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %91 = qco.rz(%cst_6) %targets_out_32 : !qco.qubit -> !qco.qubit
    %92 = qco.sx %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_5) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.sx %controls_out_31 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_4) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.sx %78 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_10) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.sx %97 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_13) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.sx %95 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst_12) %100 : !qco.qubit -> !qco.qubit
    %controls_out_33, %targets_out_34 = qco.ctrl(%101) targets (%arg0 = %99) {
      %117 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %117 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %102 = qco.rz(%cst_14) %targets_out_34 : !qco.qubit -> !qco.qubit
    %103 = qco.sx %102 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_11) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst_10) %controls_out_33 : !qco.qubit -> !qco.qubit
    %106 = qco.sx %105 : !qco.qubit -> !qco.qubit
    %107 = qco.rz(%cst_9) %106 : !qco.qubit -> !qco.qubit
    %108 = qco.sx %107 : !qco.qubit -> !qco.qubit
    %109 = qco.rz(%cst_11) %108 : !qco.qubit -> !qco.qubit
    %controls_out_35, %targets_out_36 = qco.ctrl(%109) targets (%arg0 = %104) {
      %117 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %117 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %110 = qco.rz(%cst_12) %targets_out_36 : !qco.qubit -> !qco.qubit
    %111 = qco.sx %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rz(%cst_8) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.sx %controls_out_35 : !qco.qubit -> !qco.qubit
    %114 = qco.rz(%cst) %113 : !qco.qubit -> !qco.qubit
    %115 = qco.sx %114 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst_13) %115 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %116 : !qco.qubit
    cbit.store %result, %4[%c3] : !cbit.reg<4>
    %qubit_out_37, %result_38 = qco.measure %112 : !qco.qubit
    cbit.store %result_38, %4[%c2] : !cbit.reg<4>
    %qubit_out_39, %result_40 = qco.measure %93 : !qco.qubit
    cbit.store %result_40, %4[%c1] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_37 : !qco.qubit
    qco.sink %qubit_out_39 : !qco.qubit
    %qubit_out_41, %result_42 = qco.measure %57 : !qco.qubit
    qco.sink %qubit_out_41 : !qco.qubit
    cbit.store %result_42, %4[%c0] : !cbit.reg<4>
    %cst_43 = arith.constant -3.0434178831651018 : f64
    qco.gphase(%cst_43)
    return %4 : !cbit.reg<4>
  }
}
