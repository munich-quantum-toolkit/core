module attributes {mqt.layout = {initial = array<i64: 1, 2, 3, 4, 0>, input_count = 5 : i64, sites = array<i64: 0, 1, 2, 3, 4>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<5> attributes {mqt.entry_point} {
    %cst = arith.constant -3.9269908169872418 : f64
    %cst_0 = arith.constant 3.9269908169872423 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %cst_2 = arith.constant 2.7488935718910694 : f64
    %cst_3 = arith.constant 3.5342917352885177 : f64
    %cst_4 = arith.constant 1.5707963267948966 : f64
    %cst_5 = arith.constant -3.337942194439155 : f64
    %cst_6 = arith.constant 3.3379421944391545 : f64
    %cst_7 = arith.constant 3.1415926535897927 : f64
    %cst_8 = arith.constant -6.2831853071795862 : f64
    %cst_9 = arith.constant -3.2397674240144738 : f64
    %cst_10 = arith.constant 3.1415926535897931 : f64
    %cst_11 = arith.constant 3.2397674240144738 : f64
    %cst_12 = arith.constant -4.7123889803846897 : f64
    %cst_13 = arith.constant 3.9269908169872414 : f64
    %cst_14 = arith.constant 5.497787143782138 : f64
    %cst_15 = arith.constant 4.7123889803846897 : f64
    %cst_16 = arith.constant 1.5707963267948968 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<5>
    %6 = qco.rz(%cst_4) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.sx %6 : !qco.qubit -> !qco.qubit
    %8 = qco.rz(%cst_4) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_4) %2 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_4) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.rz(%cst_4) %3 : !qco.qubit -> !qco.qubit
    %13 = qco.sx %12 : !qco.qubit -> !qco.qubit
    %14 = qco.rz(%cst_4) %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_4) %4 : !qco.qubit -> !qco.qubit
    %16 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %17 = qco.rz(%cst_4) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.sx %0 : !qco.qubit -> !qco.qubit
    %19 = qco.rz(%cst_16) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.sx %17 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_1) %20 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%21) targets (%arg0 = %19) {
      %85 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %85 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %22 = qco.rz(%cst_14) %targets_out : !qco.qubit -> !qco.qubit
    %23 = qco.x %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_13) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_12) %controls_out : !qco.qubit -> !qco.qubit
    %26 = qco.sx %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_0) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_10) %28 : !qco.qubit -> !qco.qubit
    %controls_out_17, %targets_out_18 = qco.ctrl(%29) targets (%arg0 = %24) {
      %85 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %85 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %30 = qco.rz(%cst) %targets_out_18 : !qco.qubit -> !qco.qubit
    %31 = qco.sx %30 : !qco.qubit -> !qco.qubit
    %32 = qco.sx %controls_out_17 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_10) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.rz(%cst_8) %31 : !qco.qubit -> !qco.qubit
    %35 = qco.sx %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_4) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.sx %14 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_15) %37 : !qco.qubit -> !qco.qubit
    %controls_out_19, %targets_out_20 = qco.ctrl(%38) targets (%arg0 = %36) {
      %85 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %85 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %39 = qco.rz(%cst_14) %targets_out_20 : !qco.qubit -> !qco.qubit
    %40 = qco.x %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_13) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_12) %controls_out_19 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_3) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.sx %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_10) %45 : !qco.qubit -> !qco.qubit
    %controls_out_21, %targets_out_22 = qco.ctrl(%46) targets (%arg0 = %41) {
      %85 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %85 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.rz(%cst_2) %targets_out_22 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %49 = qco.sx %controls_out_21 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_10) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.sx %48 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_16) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_15) %53 : !qco.qubit -> !qco.qubit
    %controls_out_23, %targets_out_24 = qco.ctrl(%54) targets (%arg0 = %52) {
      %85 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %85 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.rz(%cst_14) %targets_out_24 : !qco.qubit -> !qco.qubit
    %56 = qco.x %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_13) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_12) %controls_out_23 : !qco.qubit -> !qco.qubit
    %59 = qco.sx %58 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_6) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.sx %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_10) %61 : !qco.qubit -> !qco.qubit
    %controls_out_25, %targets_out_26 = qco.ctrl(%62) targets (%arg0 = %57) {
      %85 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %85 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %63 = qco.rz(%cst_5) %targets_out_26 : !qco.qubit -> !qco.qubit
    %64 = qco.sx %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_8) %controls_out_25 : !qco.qubit -> !qco.qubit
    %66 = qco.sx %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_7) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.sx %64 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_16) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.sx %8 : !qco.qubit -> !qco.qubit
    %71 = qco.rz(%cst_15) %70 : !qco.qubit -> !qco.qubit
    %controls_out_27, %targets_out_28 = qco.ctrl(%71) targets (%arg0 = %69) {
      %85 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %85 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %72 = qco.rz(%cst_14) %targets_out_28 : !qco.qubit -> !qco.qubit
    %73 = qco.x %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_13) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.rz(%cst_12) %controls_out_27 : !qco.qubit -> !qco.qubit
    %76 = qco.sx %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_11) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.sx %77 : !qco.qubit -> !qco.qubit
    %79 = qco.rz(%cst_10) %78 : !qco.qubit -> !qco.qubit
    %controls_out_29, %targets_out_30 = qco.ctrl(%79) targets (%arg0 = %74) {
      %85 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %85 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %80 = qco.rz(%cst_9) %targets_out_30 : !qco.qubit -> !qco.qubit
    %81 = qco.sx %80 : !qco.qubit -> !qco.qubit
    %82 = qco.rz(%cst_8) %controls_out_29 : !qco.qubit -> !qco.qubit
    %83 = qco.sx %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_7) %83 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %81 : !qco.qubit
    cbit.store %result, %5[%c0] : !cbit.reg<5>
    %qubit_out_31, %result_32 = qco.measure %84 : !qco.qubit
    cbit.store %result_32, %5[%c1] : !cbit.reg<5>
    %qubit_out_33, %result_34 = qco.measure %67 : !qco.qubit
    cbit.store %result_34, %5[%c2] : !cbit.reg<5>
    %qubit_out_35, %result_36 = qco.measure %50 : !qco.qubit
    cbit.store %result_36, %5[%c3] : !cbit.reg<5>
    qco.sink %qubit_out_31 : !qco.qubit
    qco.sink %qubit_out_33 : !qco.qubit
    qco.sink %qubit_out_35 : !qco.qubit
    %qubit_out_37, %result_38 = qco.measure %33 : !qco.qubit
    qco.sink %qubit_out_37 : !qco.qubit
    cbit.store %result_38, %5[%c4] : !cbit.reg<5>
    qco.sink %qubit_out : !qco.qubit
    %cst_39 = arith.constant 7.1054273576010019E-15 : f64
    qco.gphase(%cst_39)
    return %5 : !cbit.reg<5>
  }
}
