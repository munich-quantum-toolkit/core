module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cx", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 0.91478844433790929 : f64
    %cst_0 = arith.constant 5.7876618409684246 : f64
    %cst_1 = arith.constant 0.99774530031496544 : f64
    %cst_2 = arith.constant 4.4079078748703449 : f64
    %cst_3 = arith.constant 4.4611373808406647 : f64
    %cst_4 = arith.constant 4.8798490396984446 : f64
    %cst_5 = arith.constant 0.71319797786939043 : f64
    %cst_6 = arith.constant 5.1693258663051704 : f64
    %cst_7 = arith.constant 3.1415926535897936 : f64
    %cst_8 = arith.constant 5.4681187962042825 : f64
    %cst_9 = arith.constant 6.0543932459329088 : f64
    %cst_10 = arith.constant 4.4402286674258473 : f64
    %cst_11 = arith.constant 5.961286366056429 : f64
    %cst_12 = arith.constant 4.9504436822444715 : f64
    %cst_13 = arith.constant 5.8961597276494304 : f64
    %cst_14 = arith.constant 4.333899652246493 : f64
    %cst_15 = arith.constant 4.4865395466430327 : f64
    %cst_16 = arith.constant 1.3418796397663582 : f64
    %cst_17 = arith.constant 3.9363829681628495 : f64
    %cst_18 = arith.constant 5.782932219893433 : f64
    %cst_19 = arith.constant 3.3853097199905275 : f64
    %cst_20 = arith.constant 2.7012124974981928 : f64
    %cst_21 = arith.constant 4.834535225516988 : f64
    %cst_22 = arith.constant 1.6096120505387099 : f64
    %cst_23 = arith.constant 3.5618118773851632 : f64
    %cst_24 = arith.constant 0.35816915007743777 : f64
    %cst_25 = arith.constant 3.7496357798545175 : f64
    %cst_26 = arith.constant 4.1892291213784709 : f64
    %cst_27 = arith.constant 5.7122481360120467 : f64
    %cst_28 = arith.constant 1.9310082290702484 : f64
    %cst_29 = arith.constant 4.0938596733670964 : f64
    %cst_30 = arith.constant 0.55579696878501927 : f64
    %cst_31 = arith.constant 5.3247382347734789 : f64
    %cst_32 = arith.constant 5.4822996892555329 : f64
    %cst_33 = arith.constant 3.5882720532471737 : f64
    %cst_34 = arith.constant 1.5451493008641624 : f64
    %cst_35 = arith.constant 3.9273799313030784 : f64
    %cst_36 = arith.constant 0.46978750601543329 : f64
    %cst_37 = arith.constant 3.8190844999308764 : f64
    %cst_38 = arith.constant 3.593624100344293 : f64
    %cst_39 = arith.constant 3.8233276960839917 : f64
    %cst_40 = arith.constant 5.0677920463704123 : f64
    %cst_41 = arith.constant 3.8957142827948434 : f64
    %cst_42 = arith.constant 5.6865729302844743 : f64
    %cst_43 = arith.constant 4.0399283551934113 : f64
    %cst_44 = arith.constant 2.9096280484320678 : f64
    %cst_45 = arith.constant 4.7502058612065898 : f64
    %cst_46 = arith.constant 3.1415926535897931 : f64
    %cst_47 = arith.constant 3.3435833073437564 : f64
    %cst_48 = arith.constant 5.2555401946039604 : f64
    %cst_49 = arith.constant 4.4729527290640476 : f64
    %cst_50 = arith.constant 4.9795581454892073 : f64
    %cst_51 = arith.constant -3.1415926535897936 : f64
    %cst_52 = arith.constant 3.0418539731835006 : f64
    %cst_53 = arith.constant 5.648137022070558 : f64
    %cst_54 = arith.constant 1.2464691048979795 : f64
    %cst_55 = arith.constant 3.9476904558401218 : f64
    %cst_56 = arith.constant 5.9522095178832863 : f64
    %cst_57 = arith.constant 3.375541514797292 : f64
    %cst_58 = arith.constant 3.9087091045624893 : f64
    %cst_59 = arith.constant 5.4203492065536292 : f64
    %cst_60 = arith.constant 4.5692568450822915 : f64
    %cst_61 = arith.constant 3.7284279517712022 : f64
    %cst_62 = arith.constant -3.1415926535897931 : f64
    %cst_63 = arith.constant 0.93051929144274759 : f64
    %cst_64 = arith.constant 3.8445283620180843 : f64
    %cst_65 = arith.constant 2.1918092377084188 : f64
    %cst_66 = arith.constant 3.7223685420328652 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.sx %0 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_66) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_65) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.sx %1 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_64) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_63) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_62) %2 : !qco.qubit -> !qco.qubit
    %17 = qco.sx %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_61) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.sx %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_60) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_62) %3 : !qco.qubit -> !qco.qubit
    %22 = qco.sx %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_59) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_58) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.sx %4 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_57) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_56) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_55) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.sx %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_54) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %6 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_53) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.sx %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_52) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_51) %7 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_50) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.sx %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_49) %41 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%42) targets (%arg0 = %11) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_67, %targets_out_68 = qco.ctrl(%targets_out) targets (%arg0 = %15) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_69, %targets_out_70 = qco.ctrl(%targets_out_68) targets (%arg0 = %20) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_71, %targets_out_72 = qco.ctrl(%targets_out_70) targets (%arg0 = %25) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_73, %targets_out_74 = qco.ctrl(%targets_out_72) targets (%arg0 = %29) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_75, %targets_out_76 = qco.ctrl(%targets_out_74) targets (%arg0 = %33) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_77, %targets_out_78 = qco.ctrl(%targets_out_76) targets (%arg0 = %37) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_79, %targets_out_80 = qco.ctrl(%targets_out_78) targets (%arg0 = %controls_out) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %43 = qco.sx %controls_out_67 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_48) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.sx %44 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_47) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_46) %controls_out_69 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_45) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.sx %49 : !qco.qubit -> !qco.qubit
    %51 = qco.rz(%cst_44) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_62) %controls_out_71 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %52 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_43) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.sx %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst_42) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_62) %controls_out_73 : !qco.qubit -> !qco.qubit
    %58 = qco.sx %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_41) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.sx %59 : !qco.qubit -> !qco.qubit
    %61 = qco.rz(%cst_40) %60 : !qco.qubit -> !qco.qubit
    %62 = qco.sx %controls_out_75 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_39) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.sx %63 : !qco.qubit -> !qco.qubit
    %65 = qco.rz(%cst_38) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.sx %controls_out_77 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_37) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.sx %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_36) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst_46) %controls_out_79 : !qco.qubit -> !qco.qubit
    %71 = qco.sx %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_35) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.sx %72 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_34) %73 : !qco.qubit -> !qco.qubit
    %75 = qco.sx %targets_out_80 : !qco.qubit -> !qco.qubit
    %76 = qco.rz(%cst_33) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.sx %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_32) %77 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%78) targets (%arg0 = %46) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_83, %targets_out_84 = qco.ctrl(%targets_out_82) targets (%arg0 = %51) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_85, %targets_out_86 = qco.ctrl(%targets_out_84) targets (%arg0 = %56) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_87, %targets_out_88 = qco.ctrl(%targets_out_86) targets (%arg0 = %61) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_89, %targets_out_90 = qco.ctrl(%targets_out_88) targets (%arg0 = %65) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_91, %targets_out_92 = qco.ctrl(%targets_out_90) targets (%arg0 = %69) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_93, %targets_out_94 = qco.ctrl(%targets_out_92) targets (%arg0 = %74) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_95, %targets_out_96 = qco.ctrl(%targets_out_94) targets (%arg0 = %controls_out_81) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %79 = qco.rz(%cst_46) %controls_out_83 : !qco.qubit -> !qco.qubit
    %80 = qco.sx %79 : !qco.qubit -> !qco.qubit
    %81 = qco.rz(%cst_31) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.sx %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_30) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst_46) %controls_out_85 : !qco.qubit -> !qco.qubit
    %85 = qco.sx %84 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_29) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.sx %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_28) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.sx %controls_out_87 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_27) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.sx %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_26) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_46) %controls_out_89 : !qco.qubit -> !qco.qubit
    %94 = qco.sx %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_25) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.sx %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_24) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.sx %controls_out_91 : !qco.qubit -> !qco.qubit
    %99 = qco.rz(%cst_23) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.sx %99 : !qco.qubit -> !qco.qubit
    %101 = qco.rz(%cst_22) %100 : !qco.qubit -> !qco.qubit
    %102 = qco.sx %controls_out_93 : !qco.qubit -> !qco.qubit
    %103 = qco.rz(%cst_21) %102 : !qco.qubit -> !qco.qubit
    %104 = qco.sx %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst_20) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_62) %controls_out_95 : !qco.qubit -> !qco.qubit
    %107 = qco.sx %106 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_19) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.sx %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst_18) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.sx %targets_out_96 : !qco.qubit -> !qco.qubit
    %112 = qco.rz(%cst_17) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.sx %112 : !qco.qubit -> !qco.qubit
    %114 = qco.rz(%cst_16) %113 : !qco.qubit -> !qco.qubit
    %controls_out_97, %targets_out_98 = qco.ctrl(%114) targets (%arg0 = %83) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_99, %targets_out_100 = qco.ctrl(%targets_out_98) targets (%arg0 = %88) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_101, %targets_out_102 = qco.ctrl(%targets_out_100) targets (%arg0 = %92) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_103, %targets_out_104 = qco.ctrl(%targets_out_102) targets (%arg0 = %97) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_105, %targets_out_106 = qco.ctrl(%targets_out_104) targets (%arg0 = %101) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_107, %targets_out_108 = qco.ctrl(%targets_out_106) targets (%arg0 = %105) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_109, %targets_out_110 = qco.ctrl(%targets_out_108) targets (%arg0 = %110) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %controls_out_111, %targets_out_112 = qco.ctrl(%targets_out_110) targets (%arg0 = %controls_out_97) {
      %153 = qco.x %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %153 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %115 = qco.rz(%cst_62) %controls_out_99 : !qco.qubit -> !qco.qubit
    %116 = qco.sx %115 : !qco.qubit -> !qco.qubit
    %117 = qco.rz(%cst_15) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.sx %117 : !qco.qubit -> !qco.qubit
    %119 = qco.rz(%cst_14) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.sx %controls_out_101 : !qco.qubit -> !qco.qubit
    %121 = qco.rz(%cst_13) %120 : !qco.qubit -> !qco.qubit
    %122 = qco.sx %121 : !qco.qubit -> !qco.qubit
    %123 = qco.rz(%cst_12) %122 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_62) %controls_out_103 : !qco.qubit -> !qco.qubit
    %125 = qco.sx %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst_11) %125 : !qco.qubit -> !qco.qubit
    %127 = qco.sx %126 : !qco.qubit -> !qco.qubit
    %128 = qco.rz(%cst_10) %127 : !qco.qubit -> !qco.qubit
    %129 = qco.rz(%cst_62) %controls_out_105 : !qco.qubit -> !qco.qubit
    %130 = qco.sx %129 : !qco.qubit -> !qco.qubit
    %131 = qco.rz(%cst_9) %130 : !qco.qubit -> !qco.qubit
    %132 = qco.sx %131 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst_8) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.rz(%cst_7) %controls_out_107 : !qco.qubit -> !qco.qubit
    %135 = qco.sx %134 : !qco.qubit -> !qco.qubit
    %136 = qco.rz(%cst_6) %135 : !qco.qubit -> !qco.qubit
    %137 = qco.sx %136 : !qco.qubit -> !qco.qubit
    %138 = qco.rz(%cst_5) %137 : !qco.qubit -> !qco.qubit
    %139 = qco.rz(%cst_62) %controls_out_109 : !qco.qubit -> !qco.qubit
    %140 = qco.sx %139 : !qco.qubit -> !qco.qubit
    %141 = qco.rz(%cst_4) %140 : !qco.qubit -> !qco.qubit
    %142 = qco.sx %141 : !qco.qubit -> !qco.qubit
    %143 = qco.rz(%cst_3) %142 : !qco.qubit -> !qco.qubit
    %144 = qco.sx %controls_out_111 : !qco.qubit -> !qco.qubit
    %145 = qco.rz(%cst_2) %144 : !qco.qubit -> !qco.qubit
    %146 = qco.sx %145 : !qco.qubit -> !qco.qubit
    %147 = qco.rz(%cst_1) %146 : !qco.qubit -> !qco.qubit
    %148 = qco.rz(%cst_46) %targets_out_112 : !qco.qubit -> !qco.qubit
    %149 = qco.sx %148 : !qco.qubit -> !qco.qubit
    %150 = qco.rz(%cst_0) %149 : !qco.qubit -> !qco.qubit
    %151 = qco.sx %150 : !qco.qubit -> !qco.qubit
    %152 = qco.rz(%cst) %151 : !qco.qubit -> !qco.qubit
    qco.sink %119 : !qco.qubit
    qco.sink %123 : !qco.qubit
    qco.sink %128 : !qco.qubit
    qco.sink %133 : !qco.qubit
    qco.sink %138 : !qco.qubit
    qco.sink %143 : !qco.qubit
    qco.sink %147 : !qco.qubit
    qco.sink %152 : !qco.qubit
    return %c0_i64 : i64
  }
}
