module attributes {mqt.layout = {initial = array<i64: 1, 0, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<4> attributes {mqt.entry_point} {
    %cst = arith.constant -1.5707963267948966 : f64
    %cst_0 = arith.constant -0.78539816339744739 : f64
    %cst_1 = arith.constant 3.1415926535897931 : f64
    %cst_2 = arith.constant 2.3561944901923453 : f64
    %cst_3 = arith.constant 3.1415926535897927 : f64
    %cst_4 = arith.constant 1.5707963267948968 : f64
    %cst_5 = arith.constant 2.3561944901923448 : f64
    %cst_6 = arith.constant -0.78539816339744916 : f64
    %cst_7 = arith.constant 1.570796326794897 : f64
    %cst_8 = arith.constant 6.2831853071795862 : f64
    %cst_9 = arith.constant 7.8539816339744828 : f64
    %cst_10 = arith.constant 1.5707963267948966 : f64
    %cst_11 = arith.constant 0.000000e+00 : f64
    %cst_12 = arith.constant 4.7123889803846897 : f64
    %cst_13 = arith.constant 9.4247779607693793 : f64
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0 = arith.constant 0 : index
    %c3 = arith.constant 3 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.r(%cst_13, %cst_11) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.r(%cst_13, %cst_11) %2 : !qco.qubit -> !qco.qubit
    %6 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<4>
    %7 = qco.r(%cst_10, %cst_10) %3 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_1, %cst_11) %7 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_12, %cst_11) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_10, %cst_10) %9 : !qco.qubit -> !qco.qubit
    %11 = qco.r(%cst_9, %cst_11) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_1, %cst_11) %5 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_4, %cst_10) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_12, %cst_11) %13 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%14) targets (%arg0 = %11) {
      %69 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %69 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %15 = qco.r(%cst_12, %cst_11) %targets_out : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_10, %cst_10) %15 : !qco.qubit -> !qco.qubit
    %17 = qco.r(%cst_12, %cst_11) %16 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_0, %cst_11) %controls_out : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst_7, %cst_10) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_4, %cst_11) %19 : !qco.qubit -> !qco.qubit
    %controls_out_14, %targets_out_15 = qco.ctrl(%20) targets (%arg0 = %17) {
      %69 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %69 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %21 = qco.r(%cst, %cst_11) %targets_out_15 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_5, %cst_10) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_12, %cst_11) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_3, %cst_11) %controls_out_14 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_5, %cst_10) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.r(%cst, %cst_11) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst_10, %cst_10) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_1, %cst_11) %27 : !qco.qubit -> !qco.qubit
    %controls_out_16, %targets_out_17 = qco.ctrl(%4) targets (%arg0 = %23) {
      %69 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %69 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %29 = qco.r(%cst_12, %cst_11) %targets_out_17 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_10, %cst_10) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%cst_9, %cst_11) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.r(%cst_1, %cst_11) %1 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_4, %cst_10) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.r(%cst_12, %cst_11) %33 : !qco.qubit -> !qco.qubit
    %controls_out_18, %targets_out_19 = qco.ctrl(%34) targets (%arg0 = %31) {
      %69 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %69 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %35 = qco.r(%cst_12, %cst_11) %targets_out_19 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_10, %cst_10) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%cst_12, %cst_11) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.r(%cst_0, %cst_11) %controls_out_18 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst_7, %cst_10) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_4, %cst_11) %39 : !qco.qubit -> !qco.qubit
    %controls_out_20, %targets_out_21 = qco.ctrl(%40) targets (%arg0 = %37) {
      %69 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %69 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %41 = qco.r(%cst, %cst_11) %targets_out_21 : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst_5, %cst_10) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%cst_12, %cst_11) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.r(%cst_3, %cst_11) %controls_out_20 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst_5, %cst_10) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.r(%cst, %cst_11) %45 : !qco.qubit -> !qco.qubit
    %controls_out_22, %targets_out_23 = qco.ctrl(%46) targets (%arg0 = %28) {
      %69 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %69 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %47 = qco.r(%cst_10, %cst_10) %targets_out_23 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst_1, %cst_11) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.r(%cst_12, %cst_11) %43 : !qco.qubit -> !qco.qubit
    %50 = qco.r(%cst_10, %cst_10) %49 : !qco.qubit -> !qco.qubit
    %51 = qco.r(%cst_9, %cst_11) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.r(%cst_8, %cst_11) %48 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst_7, %cst_10) %52 : !qco.qubit -> !qco.qubit
    %54 = qco.r(%cst_12, %cst_11) %53 : !qco.qubit -> !qco.qubit
    %controls_out_24, %targets_out_25 = qco.ctrl(%54) targets (%arg0 = %51) {
      %69 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %69 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.r(%cst_12, %cst_11) %targets_out_25 : !qco.qubit -> !qco.qubit
    %56 = qco.r(%cst_10, %cst_10) %55 : !qco.qubit -> !qco.qubit
    %57 = qco.r(%cst_12, %cst_11) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.r(%cst_6, %cst_11) %controls_out_24 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%cst_7, %cst_10) %58 : !qco.qubit -> !qco.qubit
    %60 = qco.r(%cst_10, %cst_11) %59 : !qco.qubit -> !qco.qubit
    %controls_out_26, %targets_out_27 = qco.ctrl(%60) targets (%arg0 = %57) {
      %69 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %69 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %61 = qco.r(%cst_7, %cst_11) %targets_out_27 : !qco.qubit -> !qco.qubit
    %62 = qco.r(%cst_5, %cst_10) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%cst_4, %cst_11) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.r(%cst_3, %cst_11) %controls_out_26 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%cst_2, %cst_10) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.r(%cst_9, %cst_11) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.r(%cst_10, %cst_10) %63 : !qco.qubit -> !qco.qubit
    %68 = qco.r(%cst_1, %cst_11) %67 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %66 : !qco.qubit
    cbit.store %result, %6[%c0] : !cbit.reg<4>
    qco.sink %qubit_out : !qco.qubit
    %qubit_out_28, %result_29 = qco.measure %68 : !qco.qubit
    qco.sink %qubit_out_28 : !qco.qubit
    cbit.store %result_29, %6[%c1] : !cbit.reg<4>
    %qubit_out_30, %result_31 = qco.measure %controls_out_22 : !qco.qubit
    cbit.store %result_31, %6[%c2] : !cbit.reg<4>
    qco.sink %qubit_out_30 : !qco.qubit
    %qubit_out_32, %result_33 = qco.measure %controls_out_16 : !qco.qubit
    qco.sink %qubit_out_32 : !qco.qubit
    cbit.store %result_33, %6[%c3] : !cbit.reg<4>
    %cst_34 = arith.constant -1.1780972450961649 : f64
    qco.gphase(%cst_34)
    return %6 : !cbit.reg<4>
  }
}
