module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3>, input_count = 4 : i64, sites = array<i64: 0, 1, 2, 3>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "r", arity = <kind = fixed, value = 1>, num_parameters = 2, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant -1.3192369647402202 : f64
    %cst_0 = arith.constant -0.49457576983635043 : f64
    %cst_1 = arith.constant 5.7015405200573923 : f64
    %cst_2 = arith.constant 1.93552867079742 : f64
    %cst_3 = arith.constant 2.9179081302638199 : f64
    %cst_4 = arith.constant -0.81611824063087113 : f64
    %cst_5 = arith.constant 5.0897280234667024 : f64
    %cst_6 = arith.constant -0.02272336084164106 : f64
    %cst_7 = arith.constant 3.1188692927481521 : f64
    %cst_8 = arith.constant 6.8736853635080593 : f64
    %cst_9 = arith.constant -0.89974275681698224 : f64
    %cst_10 = arith.constant 5.0479157653736477 : f64
    %cst_11 = arith.constant 1.5707963267948948 : f64
    %cst_12 = arith.constant 1.7334128051862285 : f64
    %cst_13 = arith.constant -0.10035192109525859 : f64
    %cst_14 = arith.constant 4.9130928225752077 : f64
    %cst_15 = arith.constant 4.7123889803846879 : f64
    %cst_16 = arith.constant -1.7763568394002505E-15 : f64
    %cst_17 = arith.constant 4.7123889803846906 : f64
    %cst_18 = arith.constant 3.0652427832087277 : f64
    %cst_19 = arith.constant -1.0829468916208942 : f64
    %cst_20 = arith.constant 4.9563136979716917 : f64
    %cst_21 = arith.constant 3.1415926535897918 : f64
    %cst_22 = arith.constant -3.5527136788005009E-15 : f64
    %cst_23 = arith.constant -0.4953446860065096 : f64
    %cst_24 = arith.constant -1.3417467156517198 : f64
    %cst_25 = arith.constant 4.8269137859562781 : f64
    %cst_26 = arith.constant 1.5707963267948957 : f64
    %cst_27 = arith.constant -0.4539701663048481 : f64
    %cst_28 = arith.constant -0.084762268775380178 : f64
    %cst_29 = arith.constant 5.4554060093944488 : f64
    %cst_30 = arith.constant 0.35121840729676634 : f64
    %cst_31 = arith.constant -0.20888582788035137 : f64
    %cst_32 = arith.constant 5.3933442298419632 : f64
    %cst_33 = arith.constant 9.4247779607693793 : f64
    %cst_34 = arith.constant 5.5517691136169809 : f64
    %cst_35 = arith.constant -0.51714110490459753 : f64
    %cst_36 = arith.constant 5.2392165913298392 : f64
    %cst_37 = arith.constant 5.5357355537784052 : f64
    %cst_38 = arith.constant -0.31172612694645885 : f64
    %cst_39 = arith.constant 1.5707963267948961 : f64
    %cst_40 = arith.constant 5.3358412342776091 : f64
    %cst_41 = arith.constant 3.1415926535897927 : f64
    %cst_42 = arith.constant 1.5707963267948959 : f64
    %cst_43 = arith.constant 7.8539816339744828 : f64
    %cst_44 = arith.constant 1.5707963267948981 : f64
    %cst_45 = arith.constant 1.7204317525353745 : f64
    %cst_46 = arith.constant -0.44962169669312679 : f64
    %cst_47 = arith.constant 5.6116323737709433 : f64
    %cst_48 = arith.constant 6.2831853071795862 : f64
    %cst_49 = arith.constant 1.5707963267948968 : f64
    %cst_50 = arith.constant 1.5707963267948963 : f64
    %cst_51 = arith.constant -1.5707963267948966 : f64
    %cst_52 = arith.constant 1.570796326794897 : f64
    %cst_53 = arith.constant -1.1218900495734641 : f64
    %cst_54 = arith.constant 4.7123889803846897 : f64
    %cst_55 = arith.constant 4.9368421189954068 : f64
    %cst_56 = arith.constant 1.5707963267948966 : f64
    %cst_57 = arith.constant 0.000000e+00 : f64
    %cst_58 = arith.constant 3.1415926535897931 : f64
    %cst_59 = arith.constant 0.71748037130569708 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.r(%cst_59, %cst_56) %0 : !qco.qubit -> !qco.qubit
    %5 = qco.r(%cst_48, %cst_57) %4 : !qco.qubit -> !qco.qubit
    %6 = qco.r(%cst_48, %cst_57) %1 : !qco.qubit -> !qco.qubit
    %7 = qco.r(%cst_49, %cst_56) %6 : !qco.qubit -> !qco.qubit
    %8 = qco.r(%cst_2, %cst_57) %5 : !qco.qubit -> !qco.qubit
    %9 = qco.r(%cst_41, %cst_56) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.r(%cst_2, %cst_57) %9 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%10) targets (%arg0 = %7) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %11 = qco.r(%cst_1, %cst_57) %targets_out : !qco.qubit -> !qco.qubit
    %12 = qco.r(%cst_39, %cst_56) %11 : !qco.qubit -> !qco.qubit
    %13 = qco.r(%cst_54, %cst_57) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.r(%cst_0, %cst_57) %controls_out : !qco.qubit -> !qco.qubit
    %15 = qco.r(%cst_49, %cst_56) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.r(%cst_49, %cst_57) %15 : !qco.qubit -> !qco.qubit
    %controls_out_60, %targets_out_61 = qco.ctrl(%16) targets (%arg0 = %13) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %17 = qco.r(%cst, %cst_57) %targets_out_61 : !qco.qubit -> !qco.qubit
    %18 = qco.r(%cst_56, %cst_56) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.r(%cst_56, %cst_57) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.r(%cst_58, %cst_57) %controls_out_60 : !qco.qubit -> !qco.qubit
    %21 = qco.r(%cst_49, %cst_56) %20 : !qco.qubit -> !qco.qubit
    %22 = qco.r(%cst_42, %cst_57) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.r(%cst_7, %cst_57) %2 : !qco.qubit -> !qco.qubit
    %24 = qco.r(%cst_21, %cst_56) %23 : !qco.qubit -> !qco.qubit
    %25 = qco.r(%cst_6, %cst_57) %24 : !qco.qubit -> !qco.qubit
    %controls_out_62, %targets_out_63 = qco.ctrl(%19) targets (%arg0 = %25) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %26 = qco.r(%cst_5, %cst_57) %targets_out_63 : !qco.qubit -> !qco.qubit
    %27 = qco.r(%cst_56, %cst_56) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.r(%cst_54, %cst_57) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.r(%cst_4, %cst_57) %controls_out_62 : !qco.qubit -> !qco.qubit
    %30 = qco.r(%cst_52, %cst_56) %29 : !qco.qubit -> !qco.qubit
    %31 = qco.r(%cst_49, %cst_57) %30 : !qco.qubit -> !qco.qubit
    %controls_out_64, %targets_out_65 = qco.ctrl(%31) targets (%arg0 = %28) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %32 = qco.r(%cst_3, %cst_57) %targets_out_65 : !qco.qubit -> !qco.qubit
    %33 = qco.r(%cst_50, %cst_56) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.r(%cst_43, %cst_57) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.r(%cst_52, %cst_56) %controls_out_64 : !qco.qubit -> !qco.qubit
    %36 = qco.r(%cst_15, %cst_57) %35 : !qco.qubit -> !qco.qubit
    %37 = qco.r(%cst_33, %cst_57) %3 : !qco.qubit -> !qco.qubit
    %controls_out_66, %targets_out_67 = qco.ctrl(%34) targets (%arg0 = %37) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %38 = qco.r(%cst_10, %cst_57) %targets_out_67 : !qco.qubit -> !qco.qubit
    %39 = qco.r(%cst_56, %cst_56) %38 : !qco.qubit -> !qco.qubit
    %40 = qco.r(%cst_54, %cst_57) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.r(%cst_9, %cst_57) %controls_out_66 : !qco.qubit -> !qco.qubit
    %42 = qco.r(%cst_52, %cst_56) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.r(%cst_49, %cst_57) %42 : !qco.qubit -> !qco.qubit
    %controls_out_68, %targets_out_69 = qco.ctrl(%43) targets (%arg0 = %40) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %44 = qco.r(%cst_8, %cst_57) %targets_out_69 : !qco.qubit -> !qco.qubit
    %45 = qco.r(%cst_49, %cst_56) %44 : !qco.qubit -> !qco.qubit
    %46 = qco.r(%cst_54, %cst_57) %45 : !qco.qubit -> !qco.qubit
    %47 = qco.r(%cst_22, %cst_57) %controls_out_68 : !qco.qubit -> !qco.qubit
    %48 = qco.r(%cst_49, %cst_56) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.r(%cst_26, %cst_57) %48 : !qco.qubit -> !qco.qubit
    %controls_out_70, %targets_out_71 = qco.ctrl(%46) targets (%arg0 = %22) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qco.r(%cst_14, %cst_57) %targets_out_71 : !qco.qubit -> !qco.qubit
    %51 = qco.r(%cst_56, %cst_56) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.r(%cst_54, %cst_57) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.r(%cst_13, %cst_57) %controls_out_70 : !qco.qubit -> !qco.qubit
    %54 = qco.r(%cst_56, %cst_56) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.r(%cst_56, %cst_57) %54 : !qco.qubit -> !qco.qubit
    %controls_out_72, %targets_out_73 = qco.ctrl(%55) targets (%arg0 = %52) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %56 = qco.r(%cst_12, %cst_57) %targets_out_73 : !qco.qubit -> !qco.qubit
    %57 = qco.r(%cst_11, %cst_56) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.r(%cst_54, %cst_57) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.r(%cst_51, %cst_57) %controls_out_72 : !qco.qubit -> !qco.qubit
    %60 = qco.r(%cst_52, %cst_56) %59 : !qco.qubit -> !qco.qubit
    %61 = qco.r(%cst_49, %cst_57) %60 : !qco.qubit -> !qco.qubit
    %controls_out_74, %targets_out_75 = qco.ctrl(%58) targets (%arg0 = %36) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %62 = qco.r(%cst_20, %cst_57) %targets_out_75 : !qco.qubit -> !qco.qubit
    %63 = qco.r(%cst_56, %cst_56) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.r(%cst_54, %cst_57) %63 : !qco.qubit -> !qco.qubit
    %65 = qco.r(%cst_19, %cst_57) %controls_out_74 : !qco.qubit -> !qco.qubit
    %66 = qco.r(%cst_52, %cst_56) %65 : !qco.qubit -> !qco.qubit
    %67 = qco.r(%cst_56, %cst_57) %66 : !qco.qubit -> !qco.qubit
    %controls_out_76, %targets_out_77 = qco.ctrl(%67) targets (%arg0 = %64) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %68 = qco.r(%cst_18, %cst_57) %targets_out_77 : !qco.qubit -> !qco.qubit
    %69 = qco.r(%cst_44, %cst_56) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.r(%cst_17, %cst_57) %69 : !qco.qubit -> !qco.qubit
    %71 = qco.r(%cst_16, %cst_57) %controls_out_76 : !qco.qubit -> !qco.qubit
    %72 = qco.r(%cst_42, %cst_56) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.r(%cst_15, %cst_57) %72 : !qco.qubit -> !qco.qubit
    %controls_out_78, %targets_out_79 = qco.ctrl(%70) targets (%arg0 = %49) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %74 = qco.r(%cst_25, %cst_57) %targets_out_79 : !qco.qubit -> !qco.qubit
    %75 = qco.r(%cst_50, %cst_56) %74 : !qco.qubit -> !qco.qubit
    %76 = qco.r(%cst_54, %cst_57) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.r(%cst_24, %cst_57) %controls_out_78 : !qco.qubit -> !qco.qubit
    %78 = qco.r(%cst_52, %cst_56) %77 : !qco.qubit -> !qco.qubit
    %79 = qco.r(%cst_56, %cst_57) %78 : !qco.qubit -> !qco.qubit
    %controls_out_80, %targets_out_81 = qco.ctrl(%79) targets (%arg0 = %76) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %80 = qco.r(%cst_23, %cst_57) %targets_out_81 : !qco.qubit -> !qco.qubit
    %81 = qco.r(%cst_39, %cst_56) %80 : !qco.qubit -> !qco.qubit
    %82 = qco.r(%cst_50, %cst_57) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.r(%cst_22, %cst_57) %controls_out_80 : !qco.qubit -> !qco.qubit
    %84 = qco.r(%cst_49, %cst_56) %83 : !qco.qubit -> !qco.qubit
    %85 = qco.r(%cst_54, %cst_57) %84 : !qco.qubit -> !qco.qubit
    %controls_out_82, %targets_out_83 = qco.ctrl(%82) targets (%arg0 = %61) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %86 = qco.r(%cst_29, %cst_57) %targets_out_83 : !qco.qubit -> !qco.qubit
    %87 = qco.r(%cst_50, %cst_56) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.r(%cst_54, %cst_57) %87 : !qco.qubit -> !qco.qubit
    %89 = qco.r(%cst_28, %cst_57) %controls_out_82 : !qco.qubit -> !qco.qubit
    %90 = qco.r(%cst_56, %cst_56) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.r(%cst_56, %cst_57) %90 : !qco.qubit -> !qco.qubit
    %controls_out_84, %targets_out_85 = qco.ctrl(%91) targets (%arg0 = %88) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %92 = qco.r(%cst_27, %cst_57) %targets_out_85 : !qco.qubit -> !qco.qubit
    %93 = qco.r(%cst_56, %cst_56) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.r(%cst_54, %cst_57) %93 : !qco.qubit -> !qco.qubit
    %95 = qco.r(%cst_26, %cst_57) %controls_out_84 : !qco.qubit -> !qco.qubit
    %96 = qco.r(%cst_42, %cst_56) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.r(%cst_26, %cst_57) %96 : !qco.qubit -> !qco.qubit
    %controls_out_86, %targets_out_87 = qco.ctrl(%94) targets (%arg0 = %73) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %98 = qco.r(%cst_32, %cst_57) %targets_out_87 : !qco.qubit -> !qco.qubit
    %99 = qco.r(%cst_42, %cst_56) %98 : !qco.qubit -> !qco.qubit
    %100 = qco.r(%cst_54, %cst_57) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.r(%cst_31, %cst_57) %controls_out_86 : !qco.qubit -> !qco.qubit
    %102 = qco.r(%cst_56, %cst_56) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.r(%cst_49, %cst_57) %102 : !qco.qubit -> !qco.qubit
    %controls_out_88, %targets_out_89 = qco.ctrl(%103) targets (%arg0 = %100) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %104 = qco.r(%cst_30, %cst_57) %targets_out_89 : !qco.qubit -> !qco.qubit
    %105 = qco.r(%cst_52, %cst_56) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.r(%cst_54, %cst_57) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.r(%cst_39, %cst_57) %controls_out_88 : !qco.qubit -> !qco.qubit
    %108 = qco.r(%cst_39, %cst_56) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.r(%cst_52, %cst_57) %108 : !qco.qubit -> !qco.qubit
    %controls_out_90, %targets_out_91 = qco.ctrl(%106) targets (%arg0 = %85) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %110 = qco.r(%cst_36, %cst_57) %targets_out_91 : !qco.qubit -> !qco.qubit
    %111 = qco.r(%cst_42, %cst_56) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.r(%cst_54, %cst_57) %111 : !qco.qubit -> !qco.qubit
    %113 = qco.r(%cst_35, %cst_57) %controls_out_90 : !qco.qubit -> !qco.qubit
    %114 = qco.r(%cst_49, %cst_56) %113 : !qco.qubit -> !qco.qubit
    %115 = qco.r(%cst_49, %cst_57) %114 : !qco.qubit -> !qco.qubit
    %controls_out_92, %targets_out_93 = qco.ctrl(%115) targets (%arg0 = %112) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %116 = qco.r(%cst_34, %cst_57) %targets_out_93 : !qco.qubit -> !qco.qubit
    %117 = qco.r(%cst_42, %cst_56) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.r(%cst_50, %cst_57) %117 : !qco.qubit -> !qco.qubit
    %119 = qco.r(%cst_39, %cst_56) %controls_out_92 : !qco.qubit -> !qco.qubit
    %120 = qco.r(%cst_49, %cst_57) %119 : !qco.qubit -> !qco.qubit
    %controls_out_94, %targets_out_95 = qco.ctrl(%118) targets (%arg0 = %97) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %121 = qco.r(%cst_40, %cst_57) %targets_out_95 : !qco.qubit -> !qco.qubit
    %122 = qco.r(%cst_39, %cst_56) %121 : !qco.qubit -> !qco.qubit
    %123 = qco.r(%cst_54, %cst_57) %122 : !qco.qubit -> !qco.qubit
    %124 = qco.r(%cst_38, %cst_57) %controls_out_94 : !qco.qubit -> !qco.qubit
    %125 = qco.r(%cst_56, %cst_56) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.r(%cst_49, %cst_57) %125 : !qco.qubit -> !qco.qubit
    %controls_out_96, %targets_out_97 = qco.ctrl(%126) targets (%arg0 = %123) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %127 = qco.r(%cst_37, %cst_57) %targets_out_97 : !qco.qubit -> !qco.qubit
    %128 = qco.r(%cst_52, %cst_56) %127 : !qco.qubit -> !qco.qubit
    %129 = qco.r(%cst_54, %cst_57) %128 : !qco.qubit -> !qco.qubit
    %130 = qco.r(%cst_56, %cst_57) %controls_out_96 : !qco.qubit -> !qco.qubit
    %131 = qco.r(%cst_42, %cst_56) %130 : !qco.qubit -> !qco.qubit
    %132 = qco.r(%cst_56, %cst_57) %131 : !qco.qubit -> !qco.qubit
    %controls_out_98, %targets_out_99 = qco.ctrl(%129) targets (%arg0 = %109) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %133 = qco.r(%cst_47, %cst_57) %targets_out_99 : !qco.qubit -> !qco.qubit
    %134 = qco.r(%cst_50, %cst_56) %133 : !qco.qubit -> !qco.qubit
    %135 = qco.r(%cst_54, %cst_57) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.r(%cst_46, %cst_57) %controls_out_98 : !qco.qubit -> !qco.qubit
    %137 = qco.r(%cst_56, %cst_56) %136 : !qco.qubit -> !qco.qubit
    %138 = qco.r(%cst_49, %cst_57) %137 : !qco.qubit -> !qco.qubit
    %controls_out_100, %targets_out_101 = qco.ctrl(%138) targets (%arg0 = %135) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %139 = qco.r(%cst_45, %cst_57) %targets_out_101 : !qco.qubit -> !qco.qubit
    %140 = qco.r(%cst_44, %cst_56) %139 : !qco.qubit -> !qco.qubit
    %141 = qco.r(%cst_43, %cst_57) %140 : !qco.qubit -> !qco.qubit
    %142 = qco.r(%cst_51, %cst_57) %controls_out_100 : !qco.qubit -> !qco.qubit
    %143 = qco.r(%cst_49, %cst_56) %142 : !qco.qubit -> !qco.qubit
    %144 = qco.r(%cst_54, %cst_57) %143 : !qco.qubit -> !qco.qubit
    qco.sink %132 : !qco.qubit
    qco.sink %144 : !qco.qubit
    %controls_out_102, %targets_out_103 = qco.ctrl(%141) targets (%arg0 = %120) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %145 = qco.r(%cst_55, %cst_57) %targets_out_103 : !qco.qubit -> !qco.qubit
    %146 = qco.r(%cst_56, %cst_56) %145 : !qco.qubit -> !qco.qubit
    %147 = qco.r(%cst_54, %cst_57) %146 : !qco.qubit -> !qco.qubit
    %148 = qco.r(%cst_53, %cst_57) %controls_out_102 : !qco.qubit -> !qco.qubit
    %149 = qco.r(%cst_52, %cst_56) %148 : !qco.qubit -> !qco.qubit
    %150 = qco.r(%cst_56, %cst_57) %149 : !qco.qubit -> !qco.qubit
    %controls_out_104, %targets_out_105 = qco.ctrl(%150) targets (%arg0 = %147) {
      %156 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %156 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %151 = qco.r(%cst_51, %cst_57) %targets_out_105 : !qco.qubit -> !qco.qubit
    %152 = qco.r(%cst_50, %cst_56) %151 : !qco.qubit -> !qco.qubit
    %153 = qco.r(%cst_49, %cst_57) %152 : !qco.qubit -> !qco.qubit
    %154 = qco.r(%cst_56, %cst_56) %controls_out_104 : !qco.qubit -> !qco.qubit
    %155 = qco.r(%cst_49, %cst_57) %154 : !qco.qubit -> !qco.qubit
    qco.sink %153 : !qco.qubit
    qco.sink %155 : !qco.qubit
    %cst_106 = arith.constant 1.4210854715202004E-14 : f64
    qco.gphase(%cst_106)
    return %c0_i64 : i64
  }
}
