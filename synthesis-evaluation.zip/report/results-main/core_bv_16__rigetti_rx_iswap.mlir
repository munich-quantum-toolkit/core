module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>, input_count = 16 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>, <id = 8>, <id = 9>, <id = 10>, <id = 11>, <id = 12>, <id = 13>, <id = 14>, <id = 15>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "rxpi", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [3.1415926535897931], canonical_name = "rx">, <name = "rxpidg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-3.1415926535897931], canonical_name = "rx">, <name = "rxpi2", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [1.5707963267948966], canonical_name = "rx">, <name = "rxpi2dg", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = [], fixed_parameters = [-1.5707963267948966], canonical_name = "rx">, <name = "iswap", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> !cbit.reg<15> attributes {mqt.entry_point} {
    %cst = arith.constant 3.1415926535897927 : f64
    %cst_0 = arith.constant 4.7123889803846897 : f64
    %cst_1 = arith.constant -1.5707963267948966 : f64
    %cst_2 = arith.constant -3.1415926535897931 : f64
    %cst_3 = arith.constant 2.3561944901923448 : f64
    %cst_4 = arith.constant -0.78539816339744828 : f64
    %cst_5 = arith.constant 0.78539816339744828 : f64
    %cst_6 = arith.constant 1.5707963267948966 : f64
    %cst_7 = arith.constant 3.1415926535897931 : f64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c3 = arith.constant 3 : index
    %c4 = arith.constant 4 : index
    %c5 = arith.constant 5 : index
    %c6 = arith.constant 6 : index
    %c7 = arith.constant 7 : index
    %c8 = arith.constant 8 : index
    %c9 = arith.constant 9 : index
    %c10 = arith.constant 10 : index
    %c11 = arith.constant 11 : index
    %c12 = arith.constant 12 : index
    %c13 = arith.constant 13 : index
    %c14 = arith.constant 14 : index
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.static 8 : !qco.qubit
    %9 = qco.static 9 : !qco.qubit
    %10 = qco.static 10 : !qco.qubit
    %11 = qco.static 11 : !qco.qubit
    %12 = qco.static 12 : !qco.qubit
    %13 = qco.static 13 : !qco.qubit
    %14 = qco.static 14 : !qco.qubit
    %15 = qco.static 15 : !qco.qubit
    %16 = cbit.alloc(#cbit.init<zero>) {mqt.register_name = "result"} : !cbit.reg<15>
    %17 = qco.rx(%cst_7) %0 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_6) %1 : !qco.qubit -> !qco.qubit
    %19 = qco.rx(%cst_6) %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_3) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_6) %3 : !qco.qubit -> !qco.qubit
    %22 = qco.rx(%cst_6) %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_3) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.rz(%cst_6) %5 : !qco.qubit -> !qco.qubit
    %25 = qco.rx(%cst_6) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.rz(%cst_3) %25 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_6) %7 : !qco.qubit -> !qco.qubit
    %28 = qco.rx(%cst_6) %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_3) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.rz(%cst_6) %9 : !qco.qubit -> !qco.qubit
    %31 = qco.rx(%cst_6) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.rz(%cst_3) %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_6) %11 : !qco.qubit -> !qco.qubit
    %34 = qco.rx(%cst_6) %33 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_3) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.rz(%cst_6) %13 : !qco.qubit -> !qco.qubit
    %37 = qco.rx(%cst_6) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_3) %37 : !qco.qubit -> !qco.qubit
    %39 = qco.rz(%cst_6) %15 : !qco.qubit -> !qco.qubit
    %40 = qco.rx(%cst_6) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.rz(%cst_3) %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_7) %17 : !qco.qubit -> !qco.qubit
    %43 = qco.rx(%cst_6) %42 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_7) %43 : !qco.qubit -> !qco.qubit
    %45 = qco.rx(%cst_7) %20 : !qco.qubit -> !qco.qubit
    %46 = qco.rz(%cst_4) %45 : !qco.qubit -> !qco.qubit
    %qubit0_out, %qubit1_out = qco.iswap %46, %44 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %47 = qco.rz(%cst_3) %qubit1_out : !qco.qubit -> !qco.qubit
    %48 = qco.rx(%cst_7) %47 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_5) %48 : !qco.qubit -> !qco.qubit
    %50 = qco.rz(%cst_2) %qubit0_out : !qco.qubit -> !qco.qubit
    %51 = qco.rx(%cst_6) %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_1) %51 : !qco.qubit -> !qco.qubit
    %qubit0_out_8, %qubit1_out_9 = qco.iswap %52, %49 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %53 = qco.rz(%cst_1) %qubit1_out_9 : !qco.qubit -> !qco.qubit
    %54 = qco.rx(%cst_6) %53 : !qco.qubit -> !qco.qubit
    %55 = qco.rz(%cst_0) %54 : !qco.qubit -> !qco.qubit
    %56 = qco.rz(%cst) %qubit0_out_8 : !qco.qubit -> !qco.qubit
    %57 = qco.rx(%cst_6) %55 : !qco.qubit -> !qco.qubit
    %58 = qco.rz(%cst_7) %57 : !qco.qubit -> !qco.qubit
    %59 = qco.rx(%cst_7) %23 : !qco.qubit -> !qco.qubit
    %60 = qco.rz(%cst_4) %59 : !qco.qubit -> !qco.qubit
    %qubit0_out_10, %qubit1_out_11 = qco.iswap %60, %58 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %61 = qco.rz(%cst_3) %qubit1_out_11 : !qco.qubit -> !qco.qubit
    %62 = qco.rx(%cst_7) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.rz(%cst_5) %62 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_2) %qubit0_out_10 : !qco.qubit -> !qco.qubit
    %65 = qco.rx(%cst_6) %64 : !qco.qubit -> !qco.qubit
    %66 = qco.rz(%cst_1) %65 : !qco.qubit -> !qco.qubit
    %qubit0_out_12, %qubit1_out_13 = qco.iswap %66, %63 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %67 = qco.rz(%cst_1) %qubit1_out_13 : !qco.qubit -> !qco.qubit
    %68 = qco.rx(%cst_6) %67 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_0) %68 : !qco.qubit -> !qco.qubit
    %70 = qco.rz(%cst) %qubit0_out_12 : !qco.qubit -> !qco.qubit
    %71 = qco.rx(%cst_6) %69 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_7) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.rx(%cst_7) %26 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_4) %73 : !qco.qubit -> !qco.qubit
    %qubit0_out_14, %qubit1_out_15 = qco.iswap %74, %72 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %75 = qco.rz(%cst_3) %qubit1_out_15 : !qco.qubit -> !qco.qubit
    %76 = qco.rx(%cst_7) %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_5) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_2) %qubit0_out_14 : !qco.qubit -> !qco.qubit
    %79 = qco.rx(%cst_6) %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_1) %79 : !qco.qubit -> !qco.qubit
    %qubit0_out_16, %qubit1_out_17 = qco.iswap %80, %77 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %81 = qco.rz(%cst_1) %qubit1_out_17 : !qco.qubit -> !qco.qubit
    %82 = qco.rx(%cst_6) %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_0) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.rz(%cst) %qubit0_out_16 : !qco.qubit -> !qco.qubit
    %85 = qco.rx(%cst_6) %83 : !qco.qubit -> !qco.qubit
    %86 = qco.rz(%cst_7) %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rx(%cst_7) %29 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_4) %87 : !qco.qubit -> !qco.qubit
    %qubit0_out_18, %qubit1_out_19 = qco.iswap %88, %86 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %89 = qco.rz(%cst_3) %qubit1_out_19 : !qco.qubit -> !qco.qubit
    %90 = qco.rx(%cst_7) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.rz(%cst_5) %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_2) %qubit0_out_18 : !qco.qubit -> !qco.qubit
    %93 = qco.rx(%cst_6) %92 : !qco.qubit -> !qco.qubit
    %94 = qco.rz(%cst_1) %93 : !qco.qubit -> !qco.qubit
    %qubit0_out_20, %qubit1_out_21 = qco.iswap %94, %91 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %95 = qco.rz(%cst_1) %qubit1_out_21 : !qco.qubit -> !qco.qubit
    %96 = qco.rx(%cst_6) %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_0) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst) %qubit0_out_20 : !qco.qubit -> !qco.qubit
    %99 = qco.rx(%cst_6) %97 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_7) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.rx(%cst_7) %32 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_4) %101 : !qco.qubit -> !qco.qubit
    %qubit0_out_22, %qubit1_out_23 = qco.iswap %102, %100 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %103 = qco.rz(%cst_3) %qubit1_out_23 : !qco.qubit -> !qco.qubit
    %104 = qco.rx(%cst_7) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.rz(%cst_5) %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_2) %qubit0_out_22 : !qco.qubit -> !qco.qubit
    %107 = qco.rx(%cst_6) %106 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_1) %107 : !qco.qubit -> !qco.qubit
    %qubit0_out_24, %qubit1_out_25 = qco.iswap %108, %105 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %109 = qco.rz(%cst_1) %qubit1_out_25 : !qco.qubit -> !qco.qubit
    %110 = qco.rx(%cst_6) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_0) %110 : !qco.qubit -> !qco.qubit
    %112 = qco.rz(%cst) %qubit0_out_24 : !qco.qubit -> !qco.qubit
    %113 = qco.rx(%cst_6) %111 : !qco.qubit -> !qco.qubit
    %114 = qco.rz(%cst_7) %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rx(%cst_7) %35 : !qco.qubit -> !qco.qubit
    %116 = qco.rz(%cst_4) %115 : !qco.qubit -> !qco.qubit
    %qubit0_out_26, %qubit1_out_27 = qco.iswap %116, %114 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %117 = qco.rz(%cst_3) %qubit1_out_27 : !qco.qubit -> !qco.qubit
    %118 = qco.rx(%cst_7) %117 : !qco.qubit -> !qco.qubit
    %119 = qco.rz(%cst_5) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.rz(%cst_2) %qubit0_out_26 : !qco.qubit -> !qco.qubit
    %121 = qco.rx(%cst_6) %120 : !qco.qubit -> !qco.qubit
    %122 = qco.rz(%cst_1) %121 : !qco.qubit -> !qco.qubit
    %qubit0_out_28, %qubit1_out_29 = qco.iswap %122, %119 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %123 = qco.rz(%cst_1) %qubit1_out_29 : !qco.qubit -> !qco.qubit
    %124 = qco.rx(%cst_6) %123 : !qco.qubit -> !qco.qubit
    %125 = qco.rz(%cst_0) %124 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst) %qubit0_out_28 : !qco.qubit -> !qco.qubit
    %127 = qco.rx(%cst_6) %125 : !qco.qubit -> !qco.qubit
    %128 = qco.rz(%cst_7) %127 : !qco.qubit -> !qco.qubit
    %129 = qco.rx(%cst_7) %38 : !qco.qubit -> !qco.qubit
    %130 = qco.rz(%cst_4) %129 : !qco.qubit -> !qco.qubit
    %qubit0_out_30, %qubit1_out_31 = qco.iswap %130, %128 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %131 = qco.rz(%cst_3) %qubit1_out_31 : !qco.qubit -> !qco.qubit
    %132 = qco.rx(%cst_7) %131 : !qco.qubit -> !qco.qubit
    %133 = qco.rz(%cst_5) %132 : !qco.qubit -> !qco.qubit
    %134 = qco.rz(%cst_2) %qubit0_out_30 : !qco.qubit -> !qco.qubit
    %135 = qco.rx(%cst_6) %134 : !qco.qubit -> !qco.qubit
    %136 = qco.rz(%cst_1) %135 : !qco.qubit -> !qco.qubit
    %qubit0_out_32, %qubit1_out_33 = qco.iswap %136, %133 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %137 = qco.rz(%cst_1) %qubit1_out_33 : !qco.qubit -> !qco.qubit
    %138 = qco.rx(%cst_6) %137 : !qco.qubit -> !qco.qubit
    %139 = qco.rz(%cst_0) %138 : !qco.qubit -> !qco.qubit
    %140 = qco.rz(%cst) %qubit0_out_32 : !qco.qubit -> !qco.qubit
    %141 = qco.rx(%cst_6) %139 : !qco.qubit -> !qco.qubit
    %142 = qco.rz(%cst_7) %141 : !qco.qubit -> !qco.qubit
    %143 = qco.rx(%cst_7) %41 : !qco.qubit -> !qco.qubit
    %144 = qco.rz(%cst_4) %143 : !qco.qubit -> !qco.qubit
    %qubit0_out_34, %qubit1_out_35 = qco.iswap %144, %142 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %145 = qco.rz(%cst_3) %qubit1_out_35 : !qco.qubit -> !qco.qubit
    %146 = qco.rx(%cst_7) %145 : !qco.qubit -> !qco.qubit
    %147 = qco.rz(%cst_5) %146 : !qco.qubit -> !qco.qubit
    %148 = qco.rz(%cst_2) %qubit0_out_34 : !qco.qubit -> !qco.qubit
    %149 = qco.rx(%cst_6) %148 : !qco.qubit -> !qco.qubit
    %150 = qco.rz(%cst_1) %149 : !qco.qubit -> !qco.qubit
    %qubit0_out_36, %qubit1_out_37 = qco.iswap %150, %147 : !qco.qubit, !qco.qubit -> !qco.qubit, !qco.qubit
    %151 = qco.rz(%cst_1) %qubit1_out_37 : !qco.qubit -> !qco.qubit
    %152 = qco.rx(%cst_6) %151 : !qco.qubit -> !qco.qubit
    %153 = qco.rz(%cst_6) %152 : !qco.qubit -> !qco.qubit
    %154 = qco.rz(%cst) %qubit0_out_36 : !qco.qubit -> !qco.qubit
    %155 = qco.rx(%cst_6) %56 : !qco.qubit -> !qco.qubit
    %156 = qco.rz(%cst_6) %155 : !qco.qubit -> !qco.qubit
    %157 = qco.rx(%cst_6) %70 : !qco.qubit -> !qco.qubit
    %158 = qco.rz(%cst_6) %157 : !qco.qubit -> !qco.qubit
    %159 = qco.rx(%cst_6) %84 : !qco.qubit -> !qco.qubit
    %160 = qco.rz(%cst_6) %159 : !qco.qubit -> !qco.qubit
    %161 = qco.rx(%cst_6) %98 : !qco.qubit -> !qco.qubit
    %162 = qco.rz(%cst_6) %161 : !qco.qubit -> !qco.qubit
    %163 = qco.rx(%cst_6) %112 : !qco.qubit -> !qco.qubit
    %164 = qco.rz(%cst_6) %163 : !qco.qubit -> !qco.qubit
    %165 = qco.rx(%cst_6) %126 : !qco.qubit -> !qco.qubit
    %166 = qco.rz(%cst_6) %165 : !qco.qubit -> !qco.qubit
    %167 = qco.rx(%cst_6) %140 : !qco.qubit -> !qco.qubit
    %168 = qco.rz(%cst_6) %167 : !qco.qubit -> !qco.qubit
    %169 = qco.rx(%cst_6) %154 : !qco.qubit -> !qco.qubit
    %170 = qco.rz(%cst_6) %169 : !qco.qubit -> !qco.qubit
    %qubit_out, %result = qco.measure %156 : !qco.qubit
    cbit.store %result, %16[%c0] : !cbit.reg<15>
    %qubit_out_38, %result_39 = qco.measure %2 : !qco.qubit
    cbit.store %result_39, %16[%c1] : !cbit.reg<15>
    %qubit_out_40, %result_41 = qco.measure %158 : !qco.qubit
    cbit.store %result_41, %16[%c2] : !cbit.reg<15>
    %qubit_out_42, %result_43 = qco.measure %4 : !qco.qubit
    cbit.store %result_43, %16[%c3] : !cbit.reg<15>
    %qubit_out_44, %result_45 = qco.measure %160 : !qco.qubit
    cbit.store %result_45, %16[%c4] : !cbit.reg<15>
    %qubit_out_46, %result_47 = qco.measure %6 : !qco.qubit
    cbit.store %result_47, %16[%c5] : !cbit.reg<15>
    %qubit_out_48, %result_49 = qco.measure %162 : !qco.qubit
    cbit.store %result_49, %16[%c6] : !cbit.reg<15>
    %qubit_out_50, %result_51 = qco.measure %8 : !qco.qubit
    cbit.store %result_51, %16[%c7] : !cbit.reg<15>
    %qubit_out_52, %result_53 = qco.measure %164 : !qco.qubit
    cbit.store %result_53, %16[%c8] : !cbit.reg<15>
    %qubit_out_54, %result_55 = qco.measure %10 : !qco.qubit
    cbit.store %result_55, %16[%c9] : !cbit.reg<15>
    %qubit_out_56, %result_57 = qco.measure %166 : !qco.qubit
    cbit.store %result_57, %16[%c10] : !cbit.reg<15>
    %qubit_out_58, %result_59 = qco.measure %12 : !qco.qubit
    cbit.store %result_59, %16[%c11] : !cbit.reg<15>
    %qubit_out_60, %result_61 = qco.measure %168 : !qco.qubit
    cbit.store %result_61, %16[%c12] : !cbit.reg<15>
    %qubit_out_62, %result_63 = qco.measure %14 : !qco.qubit
    cbit.store %result_63, %16[%c13] : !cbit.reg<15>
    qco.sink %qubit_out : !qco.qubit
    qco.sink %qubit_out_38 : !qco.qubit
    qco.sink %qubit_out_40 : !qco.qubit
    qco.sink %qubit_out_42 : !qco.qubit
    qco.sink %qubit_out_44 : !qco.qubit
    qco.sink %qubit_out_46 : !qco.qubit
    qco.sink %qubit_out_48 : !qco.qubit
    qco.sink %qubit_out_50 : !qco.qubit
    qco.sink %qubit_out_52 : !qco.qubit
    qco.sink %qubit_out_54 : !qco.qubit
    qco.sink %qubit_out_56 : !qco.qubit
    qco.sink %qubit_out_58 : !qco.qubit
    qco.sink %qubit_out_60 : !qco.qubit
    qco.sink %qubit_out_62 : !qco.qubit
    %qubit_out_64, %result_65 = qco.measure %170 : !qco.qubit
    qco.sink %qubit_out_64 : !qco.qubit
    cbit.store %result_65, %16[%c14] : !cbit.reg<15>
    qco.sink %153 : !qco.qubit
    %cst_66 = arith.constant 1.5707963267948895 : f64
    qco.gphase(%cst_66)
    return %16 : !cbit.reg<15>
  }
}
