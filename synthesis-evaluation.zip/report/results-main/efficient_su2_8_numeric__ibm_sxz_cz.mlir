module attributes {mqt.layout = {initial = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>, input_count = 8 : i64, sites = array<i64: 0, 1, 2, 3, 4, 5, 6, 7>}, mqt.target_env = #mqt.target_env<compilation_target = <sites = [<id = 0>, <id = 1>, <id = 2>, <id = 3>, <id = 4>, <id = 5>, <id = 6>, <id = 7>], connectivity = all_to_all, couplings = [], native_operations = explicit, operations = [<name = "rz", arity = <kind = fixed, value = 1>, num_parameters = 1, site_tuples = []>, <name = "sx", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "x", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "cz", arity = <kind = fixed, value = 2>, num_parameters = 0, site_tuples = []>, <name = "gphase", arity = <kind = fixed, value = 0>, num_parameters = 1, site_tuples = []>, <name = "measure", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>, <name = "reset", arity = <kind = fixed, value = 1>, num_parameters = 0, site_tuples = []>]>, payload_specification = <format = <id = "openqasm", version = "3.0.0", profile = "", encoding = text>, capabilities = [], optional_capabilities_known = false>>} {
  func.func @main() -> i64 attributes {mqt.entry_point} {
    %cst = arith.constant 1.0705432395087433 : f64
    %cst_0 = arith.constant -2.0111764828864969 : f64
    %cst_1 = arith.constant -3.1027769298459797 : f64
    %cst_2 = arith.constant -4.3542198303072519 : f64
    %cst_3 = arith.constant -0.52315985900621875 : f64
    %cst_4 = arith.constant -2.7813807513144413 : f64
    %cst_5 = arith.constant -4.1565920115996704 : f64
    %cst_6 = arith.constant -3.1672396795205273 : f64
    %cst_7 = arith.constant -4.2426014743692564 : f64
    %cst_8 = arith.constant -1.1187648800403966 : f64
    %cst_9 = arith.constant 0.35540306598572258 : f64
    %cst_10 = arith.constant 0.97418394989978462 : f64
    %cst_11 = arith.constant -1.8027609319526219 : f64
    %cst_12 = arith.constant -1.3688056730409333 : f64
    %cst_13 = arith.constant -1.6705350072011891 : f64
    %cst_14 = arith.constant -3.4659198754867102 : f64
    %cst_15 = arith.constant 1.2398205374985967 : f64
    %cst_16 = arith.constant -0.80367987582220035 : f64
    %cst_17 = arith.constant -0.14313213530239821 : f64
    %cst_18 = arith.constant -3.7818696889419421 : f64
    %cst_19 = arith.constant -2.5205797426762708 : f64
    %cst_20 = arith.constant 1.5707963267948963 : f64
    %cst_21 = arith.constant -1.5707963267948966 : f64
    %cst_22 = arith.constant 4.7123889803846897 : f64
    %cst_23 = arith.constant -4.7123889803846897 : f64
    %cst_24 = arith.constant 0.91478844433790929 : f64
    %cst_25 = arith.constant 5.7876618409684246 : f64
    %cst_26 = arith.constant 0.99774530031496544 : f64
    %cst_27 = arith.constant 4.4079078748703449 : f64
    %cst_28 = arith.constant 4.4611373808406647 : f64
    %cst_29 = arith.constant 4.8798490396984446 : f64
    %cst_30 = arith.constant 0.71319797786939043 : f64
    %cst_31 = arith.constant 5.1693258663051704 : f64
    %cst_32 = arith.constant 3.1415926535897936 : f64
    %cst_33 = arith.constant 5.4681187962042825 : f64
    %cst_34 = arith.constant 6.0543932459329088 : f64
    %cst_35 = arith.constant 4.4402286674258473 : f64
    %cst_36 = arith.constant 5.961286366056429 : f64
    %cst_37 = arith.constant 4.9504436822444715 : f64
    %cst_38 = arith.constant 5.8961597276494304 : f64
    %cst_39 = arith.constant 4.333899652246493 : f64
    %cst_40 = arith.constant 4.4865395466430327 : f64
    %cst_41 = arith.constant 1.3418796397663582 : f64
    %cst_42 = arith.constant 3.9363829681628495 : f64
    %cst_43 = arith.constant 3.3853097199905275 : f64
    %cst_44 = arith.constant 4.834535225516988 : f64
    %cst_45 = arith.constant 3.5618118773851632 : f64
    %cst_46 = arith.constant 3.7496357798545175 : f64
    %cst_47 = arith.constant 5.7122481360120467 : f64
    %cst_48 = arith.constant 4.0938596733670964 : f64
    %cst_49 = arith.constant 5.3247382347734789 : f64
    %cst_50 = arith.constant 5.4822996892555329 : f64
    %cst_51 = arith.constant 3.5882720532471737 : f64
    %cst_52 = arith.constant 3.9273799313030784 : f64
    %cst_53 = arith.constant 3.8190844999308764 : f64
    %cst_54 = arith.constant 3.8233276960839917 : f64
    %cst_55 = arith.constant 3.8957142827948434 : f64
    %cst_56 = arith.constant 4.0399283551934113 : f64
    %cst_57 = arith.constant 4.7502058612065898 : f64
    %cst_58 = arith.constant 3.1415926535897931 : f64
    %cst_59 = arith.constant 5.2555401946039604 : f64
    %cst_60 = arith.constant 4.4729527290640476 : f64
    %cst_61 = arith.constant 4.9795581454892073 : f64
    %cst_62 = arith.constant -3.1415926535897936 : f64
    %cst_63 = arith.constant 5.648137022070558 : f64
    %cst_64 = arith.constant 3.9476904558401218 : f64
    %cst_65 = arith.constant 3.375541514797292 : f64
    %cst_66 = arith.constant 5.4203492065536292 : f64
    %cst_67 = arith.constant 3.7284279517712022 : f64
    %cst_68 = arith.constant -3.1415926535897931 : f64
    %cst_69 = arith.constant 3.8445283620180843 : f64
    %cst_70 = arith.constant 3.7223685420328652 : f64
    %c0_i64 = arith.constant 0 : i64
    %0 = qco.static 0 : !qco.qubit
    %1 = qco.static 1 : !qco.qubit
    %2 = qco.static 2 : !qco.qubit
    %3 = qco.static 3 : !qco.qubit
    %4 = qco.static 4 : !qco.qubit
    %5 = qco.static 5 : !qco.qubit
    %6 = qco.static 6 : !qco.qubit
    %7 = qco.static 7 : !qco.qubit
    %8 = qco.sx %0 : !qco.qubit -> !qco.qubit
    %9 = qco.rz(%cst_70) %8 : !qco.qubit -> !qco.qubit
    %10 = qco.sx %9 : !qco.qubit -> !qco.qubit
    %11 = qco.rz(%cst_19) %10 : !qco.qubit -> !qco.qubit
    %12 = qco.sx %1 : !qco.qubit -> !qco.qubit
    %13 = qco.rz(%cst_69) %12 : !qco.qubit -> !qco.qubit
    %14 = qco.sx %13 : !qco.qubit -> !qco.qubit
    %15 = qco.rz(%cst_18) %14 : !qco.qubit -> !qco.qubit
    %16 = qco.rz(%cst_68) %2 : !qco.qubit -> !qco.qubit
    %17 = qco.sx %16 : !qco.qubit -> !qco.qubit
    %18 = qco.rz(%cst_67) %17 : !qco.qubit -> !qco.qubit
    %19 = qco.sx %18 : !qco.qubit -> !qco.qubit
    %20 = qco.rz(%cst_17) %19 : !qco.qubit -> !qco.qubit
    %21 = qco.rz(%cst_68) %3 : !qco.qubit -> !qco.qubit
    %22 = qco.sx %21 : !qco.qubit -> !qco.qubit
    %23 = qco.rz(%cst_66) %22 : !qco.qubit -> !qco.qubit
    %24 = qco.sx %23 : !qco.qubit -> !qco.qubit
    %25 = qco.rz(%cst_16) %24 : !qco.qubit -> !qco.qubit
    %26 = qco.sx %4 : !qco.qubit -> !qco.qubit
    %27 = qco.rz(%cst_65) %26 : !qco.qubit -> !qco.qubit
    %28 = qco.sx %27 : !qco.qubit -> !qco.qubit
    %29 = qco.rz(%cst_15) %28 : !qco.qubit -> !qco.qubit
    %30 = qco.sx %5 : !qco.qubit -> !qco.qubit
    %31 = qco.rz(%cst_64) %30 : !qco.qubit -> !qco.qubit
    %32 = qco.sx %31 : !qco.qubit -> !qco.qubit
    %33 = qco.rz(%cst_14) %32 : !qco.qubit -> !qco.qubit
    %34 = qco.sx %6 : !qco.qubit -> !qco.qubit
    %35 = qco.rz(%cst_63) %34 : !qco.qubit -> !qco.qubit
    %36 = qco.sx %35 : !qco.qubit -> !qco.qubit
    %37 = qco.rz(%cst_13) %36 : !qco.qubit -> !qco.qubit
    %38 = qco.rz(%cst_62) %7 : !qco.qubit -> !qco.qubit
    %39 = qco.sx %38 : !qco.qubit -> !qco.qubit
    %40 = qco.rz(%cst_61) %39 : !qco.qubit -> !qco.qubit
    %41 = qco.sx %40 : !qco.qubit -> !qco.qubit
    %42 = qco.rz(%cst_60) %41 : !qco.qubit -> !qco.qubit
    %43 = qco.sx %11 : !qco.qubit -> !qco.qubit
    %44 = qco.rz(%cst_22) %43 : !qco.qubit -> !qco.qubit
    %controls_out, %targets_out = qco.ctrl(%42) targets (%arg0 = %44) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %45 = qco.rz(%cst_21) %targets_out : !qco.qubit -> !qco.qubit
    %46 = qco.sx %45 : !qco.qubit -> !qco.qubit
    %47 = qco.rz(%cst_20) %46 : !qco.qubit -> !qco.qubit
    %48 = qco.sx %15 : !qco.qubit -> !qco.qubit
    %49 = qco.rz(%cst_22) %48 : !qco.qubit -> !qco.qubit
    %controls_out_71, %targets_out_72 = qco.ctrl(%47) targets (%arg0 = %49) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %50 = qco.rz(%cst_21) %targets_out_72 : !qco.qubit -> !qco.qubit
    %51 = qco.sx %50 : !qco.qubit -> !qco.qubit
    %52 = qco.rz(%cst_20) %51 : !qco.qubit -> !qco.qubit
    %53 = qco.sx %20 : !qco.qubit -> !qco.qubit
    %54 = qco.rz(%cst_22) %53 : !qco.qubit -> !qco.qubit
    %controls_out_73, %targets_out_74 = qco.ctrl(%52) targets (%arg0 = %54) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %55 = qco.rz(%cst_21) %targets_out_74 : !qco.qubit -> !qco.qubit
    %56 = qco.sx %55 : !qco.qubit -> !qco.qubit
    %57 = qco.rz(%cst_20) %56 : !qco.qubit -> !qco.qubit
    %58 = qco.sx %25 : !qco.qubit -> !qco.qubit
    %59 = qco.rz(%cst_22) %58 : !qco.qubit -> !qco.qubit
    %controls_out_75, %targets_out_76 = qco.ctrl(%57) targets (%arg0 = %59) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %60 = qco.rz(%cst_21) %targets_out_76 : !qco.qubit -> !qco.qubit
    %61 = qco.sx %60 : !qco.qubit -> !qco.qubit
    %62 = qco.rz(%cst_20) %61 : !qco.qubit -> !qco.qubit
    %63 = qco.sx %29 : !qco.qubit -> !qco.qubit
    %64 = qco.rz(%cst_22) %63 : !qco.qubit -> !qco.qubit
    %controls_out_77, %targets_out_78 = qco.ctrl(%62) targets (%arg0 = %64) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %65 = qco.rz(%cst_21) %targets_out_78 : !qco.qubit -> !qco.qubit
    %66 = qco.sx %65 : !qco.qubit -> !qco.qubit
    %67 = qco.rz(%cst_20) %66 : !qco.qubit -> !qco.qubit
    %68 = qco.sx %33 : !qco.qubit -> !qco.qubit
    %69 = qco.rz(%cst_22) %68 : !qco.qubit -> !qco.qubit
    %controls_out_79, %targets_out_80 = qco.ctrl(%67) targets (%arg0 = %69) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %70 = qco.rz(%cst_21) %targets_out_80 : !qco.qubit -> !qco.qubit
    %71 = qco.sx %70 : !qco.qubit -> !qco.qubit
    %72 = qco.rz(%cst_20) %71 : !qco.qubit -> !qco.qubit
    %73 = qco.sx %37 : !qco.qubit -> !qco.qubit
    %74 = qco.rz(%cst_22) %73 : !qco.qubit -> !qco.qubit
    %controls_out_81, %targets_out_82 = qco.ctrl(%72) targets (%arg0 = %74) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %75 = qco.rz(%cst_21) %targets_out_82 : !qco.qubit -> !qco.qubit
    %76 = qco.sx %75 : !qco.qubit -> !qco.qubit
    %77 = qco.rz(%cst_20) %76 : !qco.qubit -> !qco.qubit
    %78 = qco.rz(%cst_23) %controls_out : !qco.qubit -> !qco.qubit
    %79 = qco.sx %78 : !qco.qubit -> !qco.qubit
    %80 = qco.rz(%cst_22) %79 : !qco.qubit -> !qco.qubit
    %controls_out_83, %targets_out_84 = qco.ctrl(%77) targets (%arg0 = %80) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %81 = qco.rz(%cst_21) %targets_out_84 : !qco.qubit -> !qco.qubit
    %82 = qco.sx %81 : !qco.qubit -> !qco.qubit
    %83 = qco.rz(%cst_20) %82 : !qco.qubit -> !qco.qubit
    %84 = qco.sx %controls_out_71 : !qco.qubit -> !qco.qubit
    %85 = qco.rz(%cst_59) %84 : !qco.qubit -> !qco.qubit
    %86 = qco.sx %85 : !qco.qubit -> !qco.qubit
    %87 = qco.rz(%cst_12) %86 : !qco.qubit -> !qco.qubit
    %88 = qco.rz(%cst_58) %controls_out_73 : !qco.qubit -> !qco.qubit
    %89 = qco.sx %88 : !qco.qubit -> !qco.qubit
    %90 = qco.rz(%cst_57) %89 : !qco.qubit -> !qco.qubit
    %91 = qco.sx %90 : !qco.qubit -> !qco.qubit
    %92 = qco.rz(%cst_11) %91 : !qco.qubit -> !qco.qubit
    %93 = qco.rz(%cst_68) %controls_out_75 : !qco.qubit -> !qco.qubit
    %94 = qco.sx %93 : !qco.qubit -> !qco.qubit
    %95 = qco.rz(%cst_56) %94 : !qco.qubit -> !qco.qubit
    %96 = qco.sx %95 : !qco.qubit -> !qco.qubit
    %97 = qco.rz(%cst_10) %96 : !qco.qubit -> !qco.qubit
    %98 = qco.rz(%cst_68) %controls_out_77 : !qco.qubit -> !qco.qubit
    %99 = qco.sx %98 : !qco.qubit -> !qco.qubit
    %100 = qco.rz(%cst_55) %99 : !qco.qubit -> !qco.qubit
    %101 = qco.sx %100 : !qco.qubit -> !qco.qubit
    %102 = qco.rz(%cst_9) %101 : !qco.qubit -> !qco.qubit
    %103 = qco.sx %controls_out_79 : !qco.qubit -> !qco.qubit
    %104 = qco.rz(%cst_54) %103 : !qco.qubit -> !qco.qubit
    %105 = qco.sx %104 : !qco.qubit -> !qco.qubit
    %106 = qco.rz(%cst_8) %105 : !qco.qubit -> !qco.qubit
    %107 = qco.sx %controls_out_81 : !qco.qubit -> !qco.qubit
    %108 = qco.rz(%cst_53) %107 : !qco.qubit -> !qco.qubit
    %109 = qco.sx %108 : !qco.qubit -> !qco.qubit
    %110 = qco.rz(%cst_7) %109 : !qco.qubit -> !qco.qubit
    %111 = qco.rz(%cst_58) %controls_out_83 : !qco.qubit -> !qco.qubit
    %112 = qco.sx %111 : !qco.qubit -> !qco.qubit
    %113 = qco.rz(%cst_52) %112 : !qco.qubit -> !qco.qubit
    %114 = qco.sx %113 : !qco.qubit -> !qco.qubit
    %115 = qco.rz(%cst_6) %114 : !qco.qubit -> !qco.qubit
    %116 = qco.sx %83 : !qco.qubit -> !qco.qubit
    %117 = qco.rz(%cst_51) %116 : !qco.qubit -> !qco.qubit
    %118 = qco.sx %117 : !qco.qubit -> !qco.qubit
    %119 = qco.rz(%cst_50) %118 : !qco.qubit -> !qco.qubit
    %120 = qco.sx %87 : !qco.qubit -> !qco.qubit
    %121 = qco.rz(%cst_22) %120 : !qco.qubit -> !qco.qubit
    %controls_out_85, %targets_out_86 = qco.ctrl(%119) targets (%arg0 = %121) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %122 = qco.rz(%cst_21) %targets_out_86 : !qco.qubit -> !qco.qubit
    %123 = qco.sx %122 : !qco.qubit -> !qco.qubit
    %124 = qco.rz(%cst_20) %123 : !qco.qubit -> !qco.qubit
    %125 = qco.sx %92 : !qco.qubit -> !qco.qubit
    %126 = qco.rz(%cst_22) %125 : !qco.qubit -> !qco.qubit
    %controls_out_87, %targets_out_88 = qco.ctrl(%124) targets (%arg0 = %126) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %127 = qco.rz(%cst_21) %targets_out_88 : !qco.qubit -> !qco.qubit
    %128 = qco.sx %127 : !qco.qubit -> !qco.qubit
    %129 = qco.rz(%cst_20) %128 : !qco.qubit -> !qco.qubit
    %130 = qco.sx %97 : !qco.qubit -> !qco.qubit
    %131 = qco.rz(%cst_22) %130 : !qco.qubit -> !qco.qubit
    %controls_out_89, %targets_out_90 = qco.ctrl(%129) targets (%arg0 = %131) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %132 = qco.rz(%cst_21) %targets_out_90 : !qco.qubit -> !qco.qubit
    %133 = qco.sx %132 : !qco.qubit -> !qco.qubit
    %134 = qco.rz(%cst_20) %133 : !qco.qubit -> !qco.qubit
    %135 = qco.sx %102 : !qco.qubit -> !qco.qubit
    %136 = qco.rz(%cst_22) %135 : !qco.qubit -> !qco.qubit
    %controls_out_91, %targets_out_92 = qco.ctrl(%134) targets (%arg0 = %136) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %137 = qco.rz(%cst_21) %targets_out_92 : !qco.qubit -> !qco.qubit
    %138 = qco.sx %137 : !qco.qubit -> !qco.qubit
    %139 = qco.rz(%cst_20) %138 : !qco.qubit -> !qco.qubit
    %140 = qco.sx %106 : !qco.qubit -> !qco.qubit
    %141 = qco.rz(%cst_22) %140 : !qco.qubit -> !qco.qubit
    %controls_out_93, %targets_out_94 = qco.ctrl(%139) targets (%arg0 = %141) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %142 = qco.rz(%cst_21) %targets_out_94 : !qco.qubit -> !qco.qubit
    %143 = qco.sx %142 : !qco.qubit -> !qco.qubit
    %144 = qco.rz(%cst_20) %143 : !qco.qubit -> !qco.qubit
    %145 = qco.sx %110 : !qco.qubit -> !qco.qubit
    %146 = qco.rz(%cst_22) %145 : !qco.qubit -> !qco.qubit
    %controls_out_95, %targets_out_96 = qco.ctrl(%144) targets (%arg0 = %146) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %147 = qco.rz(%cst_21) %targets_out_96 : !qco.qubit -> !qco.qubit
    %148 = qco.sx %147 : !qco.qubit -> !qco.qubit
    %149 = qco.rz(%cst_20) %148 : !qco.qubit -> !qco.qubit
    %150 = qco.sx %115 : !qco.qubit -> !qco.qubit
    %151 = qco.rz(%cst_22) %150 : !qco.qubit -> !qco.qubit
    %controls_out_97, %targets_out_98 = qco.ctrl(%149) targets (%arg0 = %151) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %152 = qco.rz(%cst_21) %targets_out_98 : !qco.qubit -> !qco.qubit
    %153 = qco.sx %152 : !qco.qubit -> !qco.qubit
    %154 = qco.rz(%cst_20) %153 : !qco.qubit -> !qco.qubit
    %155 = qco.rz(%cst_23) %controls_out_85 : !qco.qubit -> !qco.qubit
    %156 = qco.sx %155 : !qco.qubit -> !qco.qubit
    %157 = qco.rz(%cst_22) %156 : !qco.qubit -> !qco.qubit
    %controls_out_99, %targets_out_100 = qco.ctrl(%154) targets (%arg0 = %157) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %158 = qco.rz(%cst_21) %targets_out_100 : !qco.qubit -> !qco.qubit
    %159 = qco.sx %158 : !qco.qubit -> !qco.qubit
    %160 = qco.rz(%cst_20) %159 : !qco.qubit -> !qco.qubit
    %161 = qco.rz(%cst_58) %controls_out_87 : !qco.qubit -> !qco.qubit
    %162 = qco.sx %161 : !qco.qubit -> !qco.qubit
    %163 = qco.rz(%cst_49) %162 : !qco.qubit -> !qco.qubit
    %164 = qco.sx %163 : !qco.qubit -> !qco.qubit
    %165 = qco.rz(%cst_5) %164 : !qco.qubit -> !qco.qubit
    %166 = qco.rz(%cst_58) %controls_out_89 : !qco.qubit -> !qco.qubit
    %167 = qco.sx %166 : !qco.qubit -> !qco.qubit
    %168 = qco.rz(%cst_48) %167 : !qco.qubit -> !qco.qubit
    %169 = qco.sx %168 : !qco.qubit -> !qco.qubit
    %170 = qco.rz(%cst_4) %169 : !qco.qubit -> !qco.qubit
    %171 = qco.sx %controls_out_91 : !qco.qubit -> !qco.qubit
    %172 = qco.rz(%cst_47) %171 : !qco.qubit -> !qco.qubit
    %173 = qco.sx %172 : !qco.qubit -> !qco.qubit
    %174 = qco.rz(%cst_3) %173 : !qco.qubit -> !qco.qubit
    %175 = qco.rz(%cst_58) %controls_out_93 : !qco.qubit -> !qco.qubit
    %176 = qco.sx %175 : !qco.qubit -> !qco.qubit
    %177 = qco.rz(%cst_46) %176 : !qco.qubit -> !qco.qubit
    %178 = qco.sx %177 : !qco.qubit -> !qco.qubit
    %179 = qco.rz(%cst_2) %178 : !qco.qubit -> !qco.qubit
    %180 = qco.sx %controls_out_95 : !qco.qubit -> !qco.qubit
    %181 = qco.rz(%cst_45) %180 : !qco.qubit -> !qco.qubit
    %182 = qco.sx %181 : !qco.qubit -> !qco.qubit
    %183 = qco.rz(%cst_1) %182 : !qco.qubit -> !qco.qubit
    %184 = qco.sx %controls_out_97 : !qco.qubit -> !qco.qubit
    %185 = qco.rz(%cst_44) %184 : !qco.qubit -> !qco.qubit
    %186 = qco.sx %185 : !qco.qubit -> !qco.qubit
    %187 = qco.rz(%cst_0) %186 : !qco.qubit -> !qco.qubit
    %188 = qco.rz(%cst_68) %controls_out_99 : !qco.qubit -> !qco.qubit
    %189 = qco.sx %188 : !qco.qubit -> !qco.qubit
    %190 = qco.rz(%cst_43) %189 : !qco.qubit -> !qco.qubit
    %191 = qco.sx %190 : !qco.qubit -> !qco.qubit
    %192 = qco.rz(%cst) %191 : !qco.qubit -> !qco.qubit
    %193 = qco.sx %160 : !qco.qubit -> !qco.qubit
    %194 = qco.rz(%cst_42) %193 : !qco.qubit -> !qco.qubit
    %195 = qco.sx %194 : !qco.qubit -> !qco.qubit
    %196 = qco.rz(%cst_41) %195 : !qco.qubit -> !qco.qubit
    %197 = qco.sx %165 : !qco.qubit -> !qco.qubit
    %198 = qco.rz(%cst_22) %197 : !qco.qubit -> !qco.qubit
    %controls_out_101, %targets_out_102 = qco.ctrl(%196) targets (%arg0 = %198) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %199 = qco.rz(%cst_21) %targets_out_102 : !qco.qubit -> !qco.qubit
    %200 = qco.sx %199 : !qco.qubit -> !qco.qubit
    %201 = qco.rz(%cst_20) %200 : !qco.qubit -> !qco.qubit
    %202 = qco.sx %170 : !qco.qubit -> !qco.qubit
    %203 = qco.rz(%cst_22) %202 : !qco.qubit -> !qco.qubit
    %controls_out_103, %targets_out_104 = qco.ctrl(%201) targets (%arg0 = %203) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %204 = qco.rz(%cst_21) %targets_out_104 : !qco.qubit -> !qco.qubit
    %205 = qco.sx %204 : !qco.qubit -> !qco.qubit
    %206 = qco.rz(%cst_20) %205 : !qco.qubit -> !qco.qubit
    %207 = qco.sx %174 : !qco.qubit -> !qco.qubit
    %208 = qco.rz(%cst_22) %207 : !qco.qubit -> !qco.qubit
    %controls_out_105, %targets_out_106 = qco.ctrl(%206) targets (%arg0 = %208) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %209 = qco.rz(%cst_21) %targets_out_106 : !qco.qubit -> !qco.qubit
    %210 = qco.sx %209 : !qco.qubit -> !qco.qubit
    %211 = qco.rz(%cst_20) %210 : !qco.qubit -> !qco.qubit
    %212 = qco.sx %179 : !qco.qubit -> !qco.qubit
    %213 = qco.rz(%cst_22) %212 : !qco.qubit -> !qco.qubit
    %controls_out_107, %targets_out_108 = qco.ctrl(%211) targets (%arg0 = %213) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %214 = qco.rz(%cst_21) %targets_out_108 : !qco.qubit -> !qco.qubit
    %215 = qco.sx %214 : !qco.qubit -> !qco.qubit
    %216 = qco.rz(%cst_20) %215 : !qco.qubit -> !qco.qubit
    %217 = qco.sx %183 : !qco.qubit -> !qco.qubit
    %218 = qco.rz(%cst_22) %217 : !qco.qubit -> !qco.qubit
    %controls_out_109, %targets_out_110 = qco.ctrl(%216) targets (%arg0 = %218) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %219 = qco.rz(%cst_21) %targets_out_110 : !qco.qubit -> !qco.qubit
    %220 = qco.sx %219 : !qco.qubit -> !qco.qubit
    %221 = qco.rz(%cst_20) %220 : !qco.qubit -> !qco.qubit
    %222 = qco.sx %187 : !qco.qubit -> !qco.qubit
    %223 = qco.rz(%cst_22) %222 : !qco.qubit -> !qco.qubit
    %controls_out_111, %targets_out_112 = qco.ctrl(%221) targets (%arg0 = %223) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %224 = qco.rz(%cst_21) %targets_out_112 : !qco.qubit -> !qco.qubit
    %225 = qco.sx %224 : !qco.qubit -> !qco.qubit
    %226 = qco.rz(%cst_20) %225 : !qco.qubit -> !qco.qubit
    %227 = qco.sx %192 : !qco.qubit -> !qco.qubit
    %228 = qco.rz(%cst_22) %227 : !qco.qubit -> !qco.qubit
    %controls_out_113, %targets_out_114 = qco.ctrl(%226) targets (%arg0 = %228) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %229 = qco.rz(%cst_21) %targets_out_114 : !qco.qubit -> !qco.qubit
    %230 = qco.sx %229 : !qco.qubit -> !qco.qubit
    %231 = qco.rz(%cst_20) %230 : !qco.qubit -> !qco.qubit
    %232 = qco.rz(%cst_23) %controls_out_101 : !qco.qubit -> !qco.qubit
    %233 = qco.sx %232 : !qco.qubit -> !qco.qubit
    %234 = qco.rz(%cst_22) %233 : !qco.qubit -> !qco.qubit
    %controls_out_115, %targets_out_116 = qco.ctrl(%231) targets (%arg0 = %234) {
      %275 = qco.z %arg0 : !qco.qubit -> !qco.qubit
      qco.yield %275 : !qco.qubit
    } : ({!qco.qubit}, {!qco.qubit}) -> ({!qco.qubit}, {!qco.qubit})
    %235 = qco.rz(%cst_21) %targets_out_116 : !qco.qubit -> !qco.qubit
    %236 = qco.sx %235 : !qco.qubit -> !qco.qubit
    %237 = qco.rz(%cst_22) %236 : !qco.qubit -> !qco.qubit
    %238 = qco.rz(%cst_68) %controls_out_103 : !qco.qubit -> !qco.qubit
    %239 = qco.sx %238 : !qco.qubit -> !qco.qubit
    %240 = qco.rz(%cst_40) %239 : !qco.qubit -> !qco.qubit
    %241 = qco.sx %240 : !qco.qubit -> !qco.qubit
    %242 = qco.rz(%cst_39) %241 : !qco.qubit -> !qco.qubit
    %243 = qco.sx %controls_out_105 : !qco.qubit -> !qco.qubit
    %244 = qco.rz(%cst_38) %243 : !qco.qubit -> !qco.qubit
    %245 = qco.sx %244 : !qco.qubit -> !qco.qubit
    %246 = qco.rz(%cst_37) %245 : !qco.qubit -> !qco.qubit
    %247 = qco.rz(%cst_68) %controls_out_107 : !qco.qubit -> !qco.qubit
    %248 = qco.sx %247 : !qco.qubit -> !qco.qubit
    %249 = qco.rz(%cst_36) %248 : !qco.qubit -> !qco.qubit
    %250 = qco.sx %249 : !qco.qubit -> !qco.qubit
    %251 = qco.rz(%cst_35) %250 : !qco.qubit -> !qco.qubit
    %252 = qco.rz(%cst_68) %controls_out_109 : !qco.qubit -> !qco.qubit
    %253 = qco.sx %252 : !qco.qubit -> !qco.qubit
    %254 = qco.rz(%cst_34) %253 : !qco.qubit -> !qco.qubit
    %255 = qco.sx %254 : !qco.qubit -> !qco.qubit
    %256 = qco.rz(%cst_33) %255 : !qco.qubit -> !qco.qubit
    %257 = qco.rz(%cst_32) %controls_out_111 : !qco.qubit -> !qco.qubit
    %258 = qco.sx %257 : !qco.qubit -> !qco.qubit
    %259 = qco.rz(%cst_31) %258 : !qco.qubit -> !qco.qubit
    %260 = qco.sx %259 : !qco.qubit -> !qco.qubit
    %261 = qco.rz(%cst_30) %260 : !qco.qubit -> !qco.qubit
    %262 = qco.rz(%cst_68) %controls_out_113 : !qco.qubit -> !qco.qubit
    %263 = qco.sx %262 : !qco.qubit -> !qco.qubit
    %264 = qco.rz(%cst_29) %263 : !qco.qubit -> !qco.qubit
    %265 = qco.sx %264 : !qco.qubit -> !qco.qubit
    %266 = qco.rz(%cst_28) %265 : !qco.qubit -> !qco.qubit
    %267 = qco.sx %controls_out_115 : !qco.qubit -> !qco.qubit
    %268 = qco.rz(%cst_27) %267 : !qco.qubit -> !qco.qubit
    %269 = qco.sx %268 : !qco.qubit -> !qco.qubit
    %270 = qco.rz(%cst_26) %269 : !qco.qubit -> !qco.qubit
    %271 = qco.sx %237 : !qco.qubit -> !qco.qubit
    %272 = qco.rz(%cst_25) %271 : !qco.qubit -> !qco.qubit
    %273 = qco.sx %272 : !qco.qubit -> !qco.qubit
    %274 = qco.rz(%cst_24) %273 : !qco.qubit -> !qco.qubit
    qco.sink %242 : !qco.qubit
    qco.sink %246 : !qco.qubit
    qco.sink %251 : !qco.qubit
    qco.sink %256 : !qco.qubit
    qco.sink %261 : !qco.qubit
    qco.sink %266 : !qco.qubit
    qco.sink %270 : !qco.qubit
    qco.sink %274 : !qco.qubit
    return %c0_i64 : i64
  }
}
