# Core synthesis comparison

This standalone harness compares the final PR 2578 implementation with upstream main. It writes nothing into either checkout. `corpus/manifest.json` and the referenced MLIR/QPY files are the frozen input corpus; do not regenerate between runs.

## Scope and inputs

- 24 generated MQT Core benchmarks: GHZ, QFT, W state, QPE, Grover, multiplexer, QFT adder, and Bernstein–Vazirani, each at three sizes. The original Core benchmark specification is retained with every case. Grover uses two iterations, avoiding an exponential-work scaling confound.
- 18 scalable kernels: EfficientSU2, Pauli-rotation layers, and equatorial/Z-frame layers at 4, 8, and 16 qubits, both numeric and symbolic.
- Eight two-qubit microcases separately expose inverse Pauli cancellation, equal-Pauli merging, terminal measurement frames, and equal-axis equatorial rotations. These are excluded from aggregate performance plots and retained in the raw data.
- Eight explicitly enumerated native contracts: IQM R/CZ, IBM SX/X/RZ with CX or CZ, arbitrary RX/RZ/RZZ, IBM fractional RX plus RZZ in [0, pi/2], IonQ fixed R(pi,phi)/R(pi/2,phi) plus virtual RZ and RZZ, and Rigetti fixed RX/RZ with CZ or iSWAP. The iSWAP contract is an exploratory gate set, not a claim about a current online Rigetti device. IBM fractional RX is unrestricted, matching current Bench; only RZZ has a bound. IonQ includes virtual RZ as requested.
- All targets have all-to-all connectivity and the same width as the input. This evaluates native synthesis, not routing, placement, calibration fidelity, or a provider's device availability. Angles/bounds and gate lists are identical for both versions. Missing parameter-bound APIs remain unsupported cells; the harness never drops the bounds to obtain a result.

## Run

Use separate, freshly built Release editable environments for each checkout, with the same Python/Qiskit/NumPy versions. Measured baseline checkout:

```
/home/nvidia/.codex/experiments/core-synthesis-20261003/main/.venv/bin/python
```

Branch environment:

```
/home/nvidia/.codex/worktrees/pr2578-audit/core/.venv/bin/python
```

`generate` has already written the corpus using Core's generators. Regeneration, if deliberately needed before either measurement run:

```
BRANCH/.venv/bin/python evaluate-measured.py generate --checkout BRANCH --corpus corpus
```

Run both commands serially after all builds/tests stop, on the same idle CPU affinity. Set `QISKIT_NUM_PROCS=1`, `OMP_NUM_THREADS=1`, `OPENBLAS_NUM_THREADS=1`, and `MKL_NUM_THREADS=1` in both environments. Run from this artifact directory and replace MAIN and BRANCH with the checkout paths above:

```sh
export QISKIT_NUM_PROCS=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
taskset -c 5 MAIN/.venv/bin/python evaluate-measured.py run --checkout MAIN --corpus corpus --output results-main-new --save-ir
taskset -c 5 BRANCH/.venv/bin/python evaluate-measured.py run --checkout BRANCH --corpus corpus --output results-pr2578-new --save-ir
uv run --no-project --with matplotlib --with numpy python evaluate.py plot --baseline results-main-new --branch results-pr2578-new --output plots-new
```

`--case REGEX` and `--target REGEX` restrict functional smoke checks or subsets. `--save-ir` retains each native output. Use a fresh output directory for every run. Both plot inputs must record the same corpus-manifest hash.

## Measurements and correctness

Each stage gets one discarded warm-up and at least five measured repetitions; samples and medians are retained. MLIR input parsing, native synthesis, and Qiskit export are timed independently. Source cloning happens before the synthesis timer. Generation, validation, metrics, and file I/O are outside the timers. Compiler randomness and circuit generation use seed 2578.

Record final native one-/two-qubit gates, RZ count, one-qubit gates excluding RZ, circuit depth, quantum-gate depth, two-qubit depth, scalar IR operations, and export errors. One-/two-qubit counts remain available through Core's QC counters even if Qiskit export fails. Exported nested control-flow regions are counted statically once each; depths are reported unavailable for structured control flow. Two-qubit barriers never count as gates or contribute to two-qubit depth. Source QPE/multiplexer Qiskit export has register-order restrictions, so the harness consumes the original frozen Core MLIR and does not exclude those benchmarks. A QPE smoke case successfully exports after synthesis.

Correctness evidence is deliberately separated:

- Core benchmark outputs: 512 deterministic-seed DD shots checked against each benchmark's own reference; report total variation distance, squared Hellinger fidelity, and any impossible output. Acceptance additionally requires maximum empirical/reference CDF deviation at most `sqrt(log(2/alpha)/(2*shots))`, with `alpha=1e-9`: the distribution-free Dvoretzky–Kiefer–Wolfowitz bound. The 512-shot limit is 0.14462, with false rejection probability at most 1e-9 per case under correct independent sampling (at most 8e-7 by the union bound across 800 checks). Reference probabilities are cached by benchmark specification and include unobserved outcomes; widths are at most 16 except GHZ-Z, whose complete support is all-zero/all-one. This tests declared measured behavior, not the full unitary; neither a passing distribution test nor the Monte Carlo distances prove equivalence. See [DKW bound](https://arxiv.org/abs/1107.5356).
- Synthetic/micro unitary circuits of at most four qubits: compare the entire complex unitary including global phase with `Operator.from_circuit`, accounting for initial and final `TranspileLayout` permutations.
- Larger synthetic circuits: compare deterministic random statevectors including phase. Input vectors are permuted to initial physical placement and output vectors are permuted back from final placement in O(2^n) storage; no dense unitary is constructed. Symbolic cases use three deterministic parameter bindings in [-8,8]. This is sampled-state evidence, not a full-matrix proof.
- Explicit terminal-measurement microcase: compare exact probabilities of the reported classical-bit slots using each exported physical measurement map, since dropping pre-measurement Z phases intentionally changes the underlying unitary while preserving measured behavior.

Targets that cannot be represented, synthesis failures, export failures, and validation failures are preserved distinctly in JSONL and CSV. Ratio plots use only mutually successful, validated exports and exclude microcases. Coverage plots show successful native export counts out of all attempted cases; unsupported cases never receive a zero runtime or zero gate count.

## Artifacts

Each run writes `metadata.json` and `results.jsonl`. Metadata includes checkout commit and dirty diff hash, native extension path/hash, Python/package versions, build flags/LLVM paths from CMake caches, CPU affinity/thread settings, input-manifest hash, and harness hash.

The plot command writes `raw_results.csv`, `paired_summary.json`, `comparison_metadata.json`, and paired-performance/coverage figures in PNG, PDF, and SVG. `algorithm_synthesis_ms.*`, `algorithm_native_2q.*`, and `algorithm_native_1q.*` show algorithm-by-target heatmaps with separate numeric/symbolic panels, ratio/sample-count annotations, and gray unsupported/unpaired cells. Baseline-zero count ratios are omitted. `algorithm_summary.json` holds their raw group statistics. `absolute_representatives.*` shows absolute native two-qubit counts, non-RZ one-qubit counts, and synthesis times for QFT16, numeric EfficientSU2-16, symbolic Pauli layers-16, and symbolic equatorial frames-16, including fractional IBM and IonQ where upstream main has no comparable output; missing results are marked ×. `absolute_summary.json` holds those values. Per-target medians in the plots are unweighted across the paired Core/scalable cases; consult raw rows and per-case samples before making family-specific claims.

Run `BRANCH/.venv/bin/python check_harness.py` for layout/counter checks. These cover nonidentity initial and final permutations at 2/3/5 qubits, phase-sensitive matrix/state comparisons, classical measurement maps, nested control-flow counts, barrier exclusion, and rejection of a collapsed GHZ output distribution.
