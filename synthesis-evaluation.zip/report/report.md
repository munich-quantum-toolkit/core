The final branch implements shared symbolic angle cancellation, same-generator fusion, two-generator Pauli synthesis through native Clifford frames, exact half-turn shortening, and measurement/reset frame removal. Single- and two-qubit composition share one traversal. The cleanup removes a redundant public fusion wrapper, cached operation collection, duplicate capability checks/exporter state, overlapping tests, and three superseded plans. The new functionality adds production code overall; this is a structural simplification, not a claim that the entire PR has shrunk.

The comparison uses upstream main **32f1b331430ce4d580e2780f6fa63e60f6b9a0a3** and the evaluated branch based on **fae090dfc62cfff7d06bbc1322d1256246d5b2a9**, with its exact uncommitted patch saved as [evaluated-branch.patch](evaluated-branch.patch). `publication.json` records the signed published commit; subsequent differences from the measured source are documentation only. The measured native-extension SHA256 and source diff hash are retained in each run's metadata.

**400/400 branch cases produced validated native exports, versus 271/400 on main.** On the 271 mutually successful cases, total native one-qubit counts decreased in 215 and stayed equal in 56; native two-qubit counts decreased in 17 and stayed equal in 254. There were no increases in either total. Main rejected 50 bounded-target definitions and 78 synthesis cases (the fixed-R IonQ contract and unsupported symbolic Pauli lowering); one otherwise synthesized case could not export a generated `math.sqrt`. The branch exports all of these cases.

Ratios below are **branch / main**, so lower is better. Each row uses the same 39 jointly supported Core/scalable workloads; eight small identity microcases are excluded from ratios. Unsupported capabilities have no fabricated runtime or quality ratio. Counts do not estimate hardware fidelity. The non-RZ column separates virtual Z instructions from other single-qubit gates.

| Native contract | Validated exports | Paired cases | 1Q ratio | Non-RZ 1Q ratio | 2Q ratio | Synthesis-time ratio | Export-time ratio |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| IQM R/CZ | 45/50 → 50/50 | 39 | 0.333 | 0.333 | 1.000 | 0.947 | 0.638 |
| IBM SX/X/RZ + CX | 45/50 → 50/50 | 39 | 0.818 | 0.771 | 1.000 | 0.876 | 0.823 |
| IBM SX/X/RZ + CZ | 45/50 → 50/50 | 39 | 0.883 | 0.945 | 1.000 | 0.973 | 0.912 |
| RX/RZ + unrestricted RZZ | 46/50 → 50/50 | 39 | 0.532 | 0.337 | 1.000 | 0.957 | 0.750 |
| IBM fractional RX + bounded RZZ | 0/50 → 50/50 | 0 | — | — | — | — | — |
| IonQ fixed R + virtual RZ + ZZ | 0/50 → 50/50 | 0 | — | — | — | — | — |
| Rigetti fixed RX/RZ + CZ | 45/50 → 50/50 | 39 | 0.881 | 0.946 | 1.000 | 0.964 | 0.903 |
| Fixed RX/RZ + iSWAP (exploratory) | 45/50 → 50/50 | 39 | 0.687 | 0.717 | 1.000 | 0.973 | 0.740 |

Representative results:

| Workload and target | Main | Branch |
| --- | ---: | ---: |
| QFT-16, IQM native R gates | 2,204 | 263 |
| QFT-16, IQM synthesis | 14.13 ms | 13.25 ms |
| Symbolic EfficientSU2-16, IQM R gates | 496 | 176 |
| Symbolic EfficientSU2-16, IQM synthesis | 24.32 ms | 7.81 ms |
| QFT-16, unrestricted RZZ native 2Q gates | 240 | 120 |
| QFT-16, unrestricted RZZ synthesis | 11.72 ms | 8.98 ms |
| QFT-16, IBM fractional RZZ gates | Unsupported contract | 120 |
| QFT-16, IBM fractional synthesis | Unsupported contract | 10.11 ms |

The numeric IQM W-state and Pauli-layer workloads regress in synthesis time by up to about 20%, while reducing R-gate counts by about two thirds. W-state-16 takes 3.57 → 4.20 ms with 202 → 74 R gates; Pauli-layers-16 takes 7.79 → 9.34 ms with 604 → 214 R gates. No remaining quadratic scan or repeated expensive decomposition was identified. These results favor circuit quality at a small absolute compilation cost; they do not establish that every workload gets faster. Differences near a few percent should not be overinterpreted from one machine/session.

Depth is also a tradeoff: among jointly successful cases, full circuit depth decreases in 207, stays equal in 57, and increases in seven. Six non-micro increases are QPE-16, multiplexer-7, and QFT-adder-16 on IBM/Rigetti CZ contracts; the largest is QPE-16 at 1,108 → 1,210 (9.2%). The iSWAP identity microcase increases from depth 10 to 12. Two-qubit depth never increases. Non-RZ one-qubit count increases only in W-state-16 on the exploratory fixed-RX/iSWAP contract (98 → 99), while total one-qubit count falls. Depth counts are static gate dependencies, without calibrated durations.

The corpus contains 24 generated MQT Core benchmarks: GHZ, QFT, W state, QPE, Grover, multiplexer, QFT adder, and Bernstein–Vazirani, each at three sizes. Another 18 scalable cases cover EfficientSU2, Pauli layers, and equatorial-frame layers at 4/8/16 qubits, numeric and symbolic. Eight two-qubit microcases isolate cancellation, composition, and terminal measurement frames. The full frozen specifications and checksums are in [corpus/manifest.json](corpus/manifest.json).

Both builds use Release `-O3 -DNDEBUG`, LTO, LLVM/MLIR 23.1, Python 3.14.7, Qiskit 2.5.2, and NumPy 2.5.3 on DGX Spark arm64. Runs are serial, pinned to CPU 5, with one thread, one discarded warm-up, and five timed samples per stage. Synthesis, parsing, and Qiskit export are measured separately; copying, validation, metrics, and I/O are excluded from synthesis timing. Targets use all-to-all connectivity to isolate synthesis. The study does not measure routing, real-device connectivity, calibration fidelity, or device execution. The iSWAP contract is exploratory and does not describe a current online Rigetti device. Fractional RX is unrestricted in the tested Bench contract; RZZ is bounded to [0, pi/2]. IonQ advertises virtual RZ.

Validation includes full complex matrices for synthetic circuits up to four qubits, sampled random statevectors for larger circuits, and three deterministic bindings for symbolic inputs. Layout permutations and global phase are included. Maximum matrix/state error is 1.49e-14. Measured Core benchmarks use 512 seeded DD shots and each benchmark's own complete reference distribution. The distribution-free DKW criterion accepts CDF deviation at most 0.14462 (false-rejection bound 1e-9 per correctly sampled case); the largest observed deviation is 0.046875. Impossible outcomes are rejected. These measured/sampled checks are weaker than full-unitary equivalence. The runnable harness check rejects deliberately collapsed GHZ output and tests nonidentity input/output layouts.

Local implementation validation passed 879 affected C++ tests and 785 Python MLIR/Qiskit tests, regenerated stubs, repository lint, and whole-file C++ lint. Independent matrix checks passed 720 native synthesis comparisons including reversed placement, signed quarter/half turns, and angles up to ±1e300. Bench also passes 180 optional compiler integration tests against the published Core pin. Hosted CI is separate.

The figures are available as PNG, PDF, and SVG:

- [Paired quality and runtime](plots/paired_comparison.png)
- [Native one-qubit quality by algorithm](plots/algorithm_native_1q.png)
- [Native two-qubit quality by algorithm](plots/algorithm_native_2q.png)
- [Synthesis runtime by algorithm](plots/algorithm_synthesis_ms.png)
- [Absolute results, including fractional/IonQ targets](plots/absolute_representatives.png)
- [Applicability and successful exports](plots/applicability.png)

[Raw CSV](plots/raw_results.csv), [per-target ratios](plots/paired_summary.json), [per-algorithm ratios](plots/algorithm_summary.json), individual JSONL samples, native output IR, and build metadata are included. [README.md](README.md) documents reproduction. `evaluate-measured.py` is the exact harness used for timing; `evaluate.py` differs only in plot presentation. [check_harness.py](check_harness.py) validates layouts, counts, and distribution checks.
